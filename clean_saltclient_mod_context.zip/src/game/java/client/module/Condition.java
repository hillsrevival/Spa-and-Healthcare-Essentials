package client.module;

import java.util.function.Predicate;

public class Condition {

    private Condition() {
    }

    @SuppressWarnings("unchecked")
    public static Predicate<Setting<?>> whenEqualTo(Setting<?> source, Object expected) {
        return s -> {
            Object val = source.getValue();
            if (val == null && expected == null)
                return true;
            if (val == null || expected == null)
                return false;
            return val.equals(expected);
        };
    }

    public static Predicate<Setting<?>> whenTrue(BooleanSetting source) {
        return s -> Boolean.TRUE.equals(source.getValue());
    }

    public static Predicate<Setting<?>> whenFalse(BooleanSetting source) {
        return s -> Boolean.FALSE.equals(source.getValue());
    }

    @SafeVarargs
    public static Predicate<Setting<?>> and(Predicate<Setting<?>>... conditions) {
        return s -> {
            for (Predicate<Setting<?>> c : conditions) {
                if (!c.test(s))
                    return false;
            }
            return true;
        };
    }

    @SafeVarargs
    public static Predicate<Setting<?>> or(Predicate<Setting<?>>... conditions) {
        return s -> {
            for (Predicate<Setting<?>> c : conditions) {
                if (c.test(s))
                    return true;
            }
            return false;
        };
    }

    public static Predicate<Setting<?>> always() {
        return s -> true;
    }

    public static Predicate<Setting<?>> never() {
        return s -> false;
    }
}
