package client.module;

import client.Client;
import client.utils.StrProt;

public class ModeSetting extends Setting<String> {

    private final String[] modes;

    public ModeSetting(String name, String defaultValue, String... modes) {
        super(name, StrProt.x(defaultValue));
        String[] dec = new String[modes.length];
        for (int i = 0; i < modes.length; i++) dec[i] = StrProt.x(modes[i]);
        this.modes = dec;
    }

    public String[] getModes() {
        return modes;
    }

    public void setMode(String mode) {
        this.value = mode;
        if (getParent() != null && !Client.INSTANCE.isLoading()) {
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }

    public void cycle() {
        int index = 0;
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equalsIgnoreCase(value)) {
                index = i;
                break;
            }
        }
        index = (index + 1) % modes.length;
        value = modes[index];
        if (getParent() != null && !Client.INSTANCE.isLoading()) {
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }
}
