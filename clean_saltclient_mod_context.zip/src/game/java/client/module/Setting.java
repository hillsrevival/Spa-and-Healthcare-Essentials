package client.module;

import client.Client;
import client.utils.StrProt;
import java.util.function.Predicate;

public abstract class Setting<T> {

    private final String name;

    protected T value;

    private final T defaultVal;

    private Module parent;

    private Predicate<Setting<?>> visibilityCondition;

    private String description = "";

    public Setting(String name, T defaultValue) {
        this.name = StrProt.x(name);
        this.value = defaultValue;
        this.defaultVal = defaultValue;
    }

    public T getDefault() {
        return defaultVal;
    }

    public Setting<T> withDescription(String desc) {
        this.description = desc;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public boolean hasDescription() {
        return description != null && !description.isEmpty();
    }

    public void setParent(Module parent) {
        this.parent = parent;
    }

    public Module getParent() {
        return parent;
    }

    public String getName() {
        return name;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
        if (parent != null) {
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }

    public void setVisibilityCondition(Predicate<Setting<?>> condition) {
        this.visibilityCondition = condition;
    }

    public boolean isVisible() {
        if (visibilityCondition == null)
            return true;
        return visibilityCondition.test(this);
    }
}
