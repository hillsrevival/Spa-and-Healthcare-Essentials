package client.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import client.Client;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.ResourceLocation;

public class BlockListSetting extends Setting<String[]> {

    private static final String EXCLUDED_AIR = "minecraft:air";

    private static volatile String[] registryCatalog;

    private final String[] explicitAllowed;

    private final Predicate<Block> filter;

    private String[] allowedCache;

    public BlockListSetting(String name, String[] defaultValue) {
        this(name, defaultValue, (String[]) null, null);
    }

    public BlockListSetting(String name, String[] defaultValue, String[] allowedBlocks) {
        this(name, defaultValue, allowedBlocks, null);
    }

    public BlockListSetting(String name, String[] defaultValue, Predicate<Block> filter) {
        this(name, defaultValue, null, filter);
    }

    private BlockListSetting(String name, String[] defaultValue, String[] allowedBlocks, Predicate<Block> filter) {
        super(name, defaultValue);
        this.explicitAllowed = allowedBlocks;
        this.filter = filter;
    }

    public static String[] registryBlockIds() {
        String[] catalog = registryCatalog;
        if (catalog != null) {
            return catalog;
        }
        List<String> names = new ArrayList<String>();
        for (ResourceLocation rl : Block.REGISTRY.getKeys()) {
            String id = rl.toString();
            if (!EXCLUDED_AIR.equals(id)) {
                names.add(id);
            }
        }
        Collections.sort(names);
        catalog = names.toArray(new String[0]);
        registryCatalog = catalog;
        return catalog;
    }

    public static Block lookupBlock(String id) {
        if (id == null || id.isEmpty()) {
            return null;
        }
        try {
            ResourceLocation rl = new ResourceLocation(id);
            Block block = Block.REGISTRY.getObject(rl);
            return block == Blocks.AIR ? null : block;
        } catch (Exception e) {
            return null;
        }
    }

    public String[] getAllowedBlocks() {
        if (allowedCache == null) {
            allowedCache = resolveAllowed();
        }
        return allowedCache;
    }

    private String[] resolveAllowed() {
        if (explicitAllowed != null) {
            return explicitAllowed;
        }
        String[] catalog = registryBlockIds();
        if (filter == null) {
            return catalog.clone();
        }
        List<String> out = new ArrayList<String>();
        for (String id : catalog) {
            Block block = lookupBlock(id);
            if (block != null && filter.test(block)) {
                out.add(id);
            }
        }
        return out.toArray(new String[0]);
    }

    public boolean contains(String blockName) {
        if (value == null)
            return false;
        for (String s : value) {
            if (s.equalsIgnoreCase(blockName))
                return true;
        }
        return false;
    }

    public void toggle(String blockName) {
        if (value == null)
            return;
        for (int i = 0; i < value.length; i++) {
            if (value[i].equalsIgnoreCase(blockName)) {
                String[] newValue = new String[value.length - 1];
                System.arraycopy(value, 0, newValue, 0, i);
                System.arraycopy(value, i + 1, newValue, i, value.length - i - 1);
                setValue(newValue);
                return;
            }
        }
        String[] newValue = new String[value.length + 1];
        System.arraycopy(value, 0, newValue, 0, value.length);
        newValue[value.length] = blockName;
        setValue(newValue);
    }

    public void selectAll() {
        setValue(getAllowedBlocks().clone());
    }

    public void clearAll() {
        setValue(new String[0]);
    }

    @Override
    public void setValue(String[] value) {
        this.value = value;
        if (getParent() != null && !Client.INSTANCE.isLoading()) {
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }
}
