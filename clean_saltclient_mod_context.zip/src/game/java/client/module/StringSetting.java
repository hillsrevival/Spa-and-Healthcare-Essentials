package client.module;

import client.Client;

public class StringSetting extends Setting<String> {

    public StringSetting(String name, String defaultValue) {
        super(name, client.utils.StrProt.x(defaultValue));
    }

    @Override
    public void setValue(String value) {
        this.value = value;
        if (getParent() != null && !Client.INSTANCE.isLoading()) {
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }
}
