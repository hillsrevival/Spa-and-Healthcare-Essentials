package client.module;

import client.module.impl.items.AutoTotem;
import client.module.impl.other.SchematicModule;
import client.module.impl.combat.HitSelect;
import client.module.impl.combat.KillAura;
import client.module.impl.render.FullBright;
import client.module.impl.movement.AutoSprint;
import client.module.impl.render.PlayerESP;
import client.module.impl.combat.TriggerBot;
import client.module.impl.other.AutoRespawn;
import client.module.impl.render.ChestESP;
import client.module.impl.movement.NoFall;
import client.module.impl.items.AutoArmor;
import client.module.impl.movement.BunnyHop;
import client.module.impl.movement.NoSlowdown;
import client.module.impl.movement.FastLadder;
import client.module.impl.movement.Step;
import client.module.impl.non_hack.Weather;
import client.module.impl.items.AutoEat;
import client.module.impl.render.HurtCam;
import client.module.impl.non_hack.HitColour;
import client.module.impl.non_hack.BlockHighlighter;
import client.module.impl.movement.FastPlace;
import client.module.impl.movement.Fly;
import client.module.impl.movement.BoatFly;
import client.module.impl.movement.FlyLegit;
import client.module.impl.movement.Jesus;
import client.module.impl.movement.NoClip;
import client.module.impl.movement.NoWeb;
import client.module.impl.movement.Sneak;
import client.module.impl.movement.Spider;
import client.module.impl.other.Timer;
import client.module.impl.combat.AutoSword;
import client.module.impl.combat.MultiAura;
import client.module.impl.combat.AimAssist;
import client.module.impl.combat.BowAimbot;
import client.module.impl.combat.SprintReset;
import client.module.impl.combat.JumpReset;
import client.module.impl.combat.CritTiming;
import client.module.impl.movement.SpacingController;
import client.module.impl.movement.BackTap;
import client.module.impl.combat.TickShiftLegit;
import client.module.impl.combat.AutoLeave;
import client.module.impl.combat.TPAura;
import client.module.impl.movement.Glide;
import client.module.impl.movement.HighJump;
import client.module.impl.movement.SpeedHack;
import client.module.impl.movement.AutoWalk;
import client.module.impl.movement.Blink;
import client.module.impl.render.ItemESP;
import client.module.impl.render.MobESP;
import client.module.impl.render.NameTags;
import client.module.impl.render.NoOverlay;
import client.module.impl.blocks.Nuker;
import client.module.impl.blocks.FastBreak;
import client.module.impl.blocks.AutoTool;
import client.module.impl.blocks.Scaffold;
import client.module.impl.other.AutoFish;
import client.module.impl.other.AntiAFK;
import client.module.impl.other.Panic;
import client.module.impl.other.Throw;
import client.module.impl.fun.Derp;
import client.module.impl.render.BlockESP;
import client.module.impl.render.Tracers;
import client.module.impl.render.Trajectories;
import client.module.impl.render.XRay;
import client.module.impl.render.ItemAmountHud;
import client.module.impl.other.Regen;
import client.module.impl.other.Teleport;
import client.module.impl.fun.SkinDerp;
import client.module.impl.combat.AutoClicker;
import client.module.impl.combat.Reach;
import client.module.impl.movement.AirJump;
import client.module.impl.movement.LongJump;
import client.module.impl.other.AutoSwing;
import client.module.impl.items.ChestStealer;
import client.module.impl.combat.CobwebBreaker;
import client.module.impl.other.AntiCactus;
import client.module.impl.render.SpawnerESP;
import client.module.impl.other.ScreenRecording;
import client.module.impl.non_hack.DeathCords;
import client.module.impl.other.NoDynamicFov;
import client.module.impl.chat.Spammer;
import client.module.impl.retro.FastBow;
import client.module.impl.retro.FastEat;
import client.module.impl.retro.AntiFire;
import client.module.impl.retro.AntiPotion;
import client.module.impl.retro.ForcePush;
import client.module.impl.combat.ClickAura;
import client.module.impl.combat.FightBot;
import client.module.impl.combat.Protect;
import client.module.impl.other.AutoGG;
import client.module.impl.movement.Jetpack;
import client.module.impl.movement.Follow;
import client.module.impl.movement.ElytraFollow;
import client.module.impl.combat.VelocityLegit;
import client.module.impl.combat.WindPearl;
import client.module.impl.other.PotionSaver;
import client.module.impl.other.AntiSpam;
import client.module.impl.render.Radar;
import client.module.impl.render.HealthTags;
import client.module.impl.render.TrueSight;
import client.module.impl.render.NameProtect;
import client.module.impl.fun.ChatGames;
import client.module.impl.chat.FancyChat;
import client.module.impl.chat.MassTpa;
import client.module.impl.chat.MassTpaHere;
import client.module.impl.fun.HeadRoll;
import client.module.impl.fun.ColorUi;
import client.module.impl.blocks.Liquids;
import client.module.impl.blocks.AutoMine;
import client.module.impl.blocks.Kaboom;
import client.module.impl.blocks.BonemealAura;
import client.module.impl.blocks.InstantBunker;
import client.module.impl.blocks.BuildRandom;
import client.module.impl.blocks.AutoFarm;
import client.module.impl.blocks.Tunneller;
import client.module.impl.blocks.TemplateTool;
import client.module.impl.chat.Home;
import client.module.impl.fun.Headless;
import client.module.impl.fun.Lsd;
import client.module.impl.fun.MileyCyrus;
import client.module.impl.items.KillPotion;
import client.module.impl.items.CrashChest;
import client.module.impl.items.CrashTag;
import client.module.impl.items.CmdBlock;
import client.module.impl.other.LogSpammer;
import client.module.impl.other.Baritone;
import client.module.impl.render.BaseFinder;
import client.module.impl.other.PluginFinder;
import client.module.impl.render.CaveFinder;
import client.module.impl.render.PortalESP;
import client.module.impl.render.ObsidianAncientDebrisESP;
import client.module.impl.render.Freecam;
import client.module.impl.render.RemoteView;
import client.module.impl.combat.CrystalAura;
import client.module.impl.render.TabGUI;
import client.module.impl.combat.AutoMace;
import client.module.impl.mace.ShortWindcharge;
import client.module.impl.render.FontSettings;
import client.module.impl.mace.MaceDamageHud;
import client.module.impl.mace.WindBurstChain;
import client.module.impl.mace.ElytraDiveAssist;
import client.module.impl.mace.SpearAssist;
import client.module.impl.mace.MaceKill;
import client.module.impl.mace.MaceMissCounter;
import client.module.impl.mace.AttributeSwapper;
import client.module.impl.mace.AutoStunSlam;
import client.module.impl.mace.MaceTargetFilter;
import client.module.impl.mace.WindLunge;
import client.module.impl.mace.PearlIntercept;
import client.module.impl.mace.ElytraHotSwap;
import client.module.impl.mace.AirPots;
import client.module.impl.combat.AutoSoup;
import client.module.impl.combat.Backtrack;
import client.module.impl.combat.ShieldMacro;
import client.module.impl.movement.AutoElytraFly;
import client.module.impl.movement.AutoMLG;
import client.module.impl.render.ActiveModuleHud;
import client.module.impl.render.PlayerInfoEsp;
import client.module.impl.render.TntTime;
import client.module.impl.non_hack.InventoryHud;
import client.module.impl.non_hack.Keystrokes;
import client.module.impl.non_hack.CpsDisplay;
import client.module.impl.non_hack.AutoLogin;
import client.module.impl.non_hack.UIUtils;
import client.module.impl.movement.AntiVoid;
import client.module.impl.combat.AutoGapple;
import client.module.impl.other.AntiHunger;
import client.module.impl.movement.NoRotateSet;
import client.module.impl.render.Durability;
import client.module.impl.other.AutoReconnect;
import client.module.impl.render.NoRender;
import client.module.impl.render.Hitboxes;
import client.module.impl.render.ItemGlow;
import client.module.impl.render.LogoutSpots;
import client.module.impl.render.HoleESP;
import client.module.impl.render.VoidESP;
import client.module.impl.render.TimeChanger;
import client.module.impl.combat.AutoTrap;
import client.module.impl.combat.Surround;
import client.module.impl.items.Offhand;
import client.module.impl.movement.InventoryMove;
import client.module.impl.items.AutoMend;
import client.module.impl.other.AutoXP;
import client.module.impl.blocks.VeinMiner;
import client.module.impl.blocks.AutoShear;
import client.module.impl.blocks.LiquidFill;
import client.module.impl.movement.Strafe;
import client.module.impl.movement.AntiLevitation;
import client.module.impl.movement.Snap;
import client.module.impl.render.NoBlockOverlay;
import client.module.impl.movement.AutoJump;
import client.module.impl.movement.ReverseStep;
import client.module.impl.movement.Slippy;
import client.module.impl.blocks.AutoBreed;
import client.module.impl.render.NoMiningTrace;
import client.module.impl.other.AirPlace;
import client.module.impl.other.EndermanLook;
import client.module.impl.render.Waypoints;
import client.module.impl.render.StorageESP;
import client.module.impl.render.BreakIndicators;
import client.module.impl.render.LightOverlay;
import client.module.impl.render.Trail;
import client.module.impl.combat.AntiAnvil;
import client.module.impl.combat.BowSpam;
import client.module.impl.combat.HoleFiller;
import client.module.impl.combat.SelfTrap;
import client.module.impl.combat.AutoCity;
import client.module.impl.combat.ArrowDodge;
import client.module.impl.movement.AutoMount;
import client.module.impl.movement.EntityControl;
import client.module.impl.other.NoInteract;
import client.module.impl.other.LiquidInteract;
import client.module.impl.other.Notifier;
import client.module.impl.render.NotificationHud;
import client.module.impl.movement.Clutch;
import client.module.impl.render.Animations;
import client.module.impl.render.Chams;
import client.module.impl.render.Hat;
import client.module.impl.render.JumpCircle;
import client.module.impl.render.Particles;
import client.module.impl.render.Arrows;
import client.module.impl.render.Explosions;
import client.module.impl.render.NoFog;
import client.module.impl.combat.BlockHit;
import client.module.impl.combat.AntiBot;
import client.module.impl.items.ArmorSwitch;
import client.module.impl.items.InvCleaner;
import client.module.impl.items.Throwpot;
import client.module.impl.combat.ThrowDebuff;
import client.module.impl.items.AutoHotbar;
import client.module.impl.blocks.BedBreaker;
import client.module.impl.items.AutoPearl;
import client.module.impl.items.Refill;
import client.module.impl.render.Health;
import client.module.impl.other.MurderFinder;
import client.module.impl.movement.KeepSprint;
import client.module.impl.other.AntiPacketKick;
import client.module.impl.items.ChestSwap;
import client.module.impl.render.FreeLook;
import client.module.impl.blocks.SpawnProofer;
import client.module.impl.other.SoundBlocker;
import client.module.impl.non_hack.CreamyKeys;
import client.module.impl.items.InventoryTweaks;
import client.module.impl.items.AutoSmelter;
import client.module.impl.items.AutoBrewer;
import client.module.impl.blocks.EChestFarmer;
import client.module.impl.blocks.NoGhostBlocks;
import client.module.impl.items.SelfAnvil;
import client.module.impl.combat.ExpThrower;
import client.module.impl.render.NoStatusEffects;
import client.module.impl.movement.Portals;
import client.module.impl.render.BetterTooltips;
import client.module.impl.render.CameraTweaks;
import client.module.impl.render.EntityOwner;
import client.module.impl.render.Shaders;
import client.module.impl.render.GuiBlur;
import client.module.impl.movement.AntiWaterPush;
import client.module.impl.movement.Anchor;
import client.module.impl.items.AutoNametag;
import client.module.impl.items.AutoPotion;
import client.module.impl.movement.AutoSwim;
import client.module.impl.combat.BedAura;
import client.module.impl.chat.BetterChat;
import client.module.impl.blocks.BuildHeight;
import client.module.impl.fun.FakePlayer;
import client.module.impl.render.PopChams;
import client.module.impl.movement.SafeWalk;
import client.module.impl.other.ClientSpoofer;
import client.module.impl.blocks.Tillaura;
import client.module.impl.render.TunnelESP;
import client.module.impl.render.Zoom;
import client.module.impl.non_hack.ArmorHud;
import client.module.impl.non_hack.PotionHud;
import client.module.impl.non_hack.CoordsHud;
import client.module.impl.non_hack.FPSPingHud;
import client.module.impl.render.TargetHud;
import client.module.impl.non_hack.SpeedHud;
import client.module.impl.non_hack.ClockHud;
import client.module.impl.combat.Burrow;
import client.module.impl.other.UnderY0;
import client.module.impl.other.TuffDebug;
import client.module.impl.other.ViaBlocks;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.lax1dude.eaglercraft.Keyboard;
import client.module.impl.player.Multitask;
import client.module.impl.player.MiddleClickExtra;
import client.module.impl.player.PacketLogger;
import client.module.impl.player.Rotation;
import client.module.impl.player.PacketCanceller;
import client.module.impl.combat.SelfWeb;
import client.module.impl.movement.ElytraBoost;

public class ModuleManager {

    private static final List<Module> modules = new ArrayList<>();

    private static final Map<String, Module> moduleMap = new HashMap<>();

    public static Module noDynamicFovModule;

    public static Module noStatusEffectsModule;

    public static Module noOverlayModule;

    public static Module hurtCamModule;

    public static Module hitColourModule;

    public static Multitask multitaskModule;

    public static void init() {
        if (!modules.isEmpty())
            return;
        register(new Nuker());
        register(new FastBreak());
        register(new AutoTool());
        register(new Scaffold());
        register(new Liquids());
        register(new AutoMine());
        register(new Kaboom());
        register(new BonemealAura());
        register(new InstantBunker());
        register(new BuildRandom());
        register(new AutoFarm());
        register(new Tunneller());
        register(new TemplateTool());
        register(new VeinMiner());
        register(new AutoShear());
        register(new LiquidFill());
        register(new AutoBreed());
        register(new NoGhostBlocks());
        register(new EChestFarmer());
        register(new BuildHeight());
        register(new Tillaura());
        register(new KillAura());
        register(new TriggerBot());
        register(new HitSelect());
        register(new AutoClicker());
        register(new Reach());
        register(new AutoSword());
        register(new MultiAura());
        register(new AimAssist());
        register(new BowAimbot());
        register(new SprintReset());
        register(new CritTiming());
        register(new SpacingController());
        register(new BackTap());
        register(new TickShiftLegit());
        register(new AutoLeave());
        register(new TPAura());
        register(new ClickAura());
        register(new FightBot());
        register(new Protect());
        register(new VelocityLegit());
        register(new WindPearl());
        register(new JumpReset());
        register(new CrystalAura());
        register(new AutoGapple());
        register(new AutoSoup());
        register(new Hitboxes());
        register(new AutoTrap());
        register(new Surround());
        register(new AutoMace());
        register(new ShortWindcharge());
        register(new FontSettings());
        register(new MaceDamageHud());
        register(new WindBurstChain());
        register(new ElytraDiveAssist());
        register(new SpearAssist());
        register(new MaceKill());
        register(new MaceMissCounter());
        register(new AttributeSwapper());
        register(new AutoStunSlam());
        register(new MaceTargetFilter());
        register(new WindLunge());
        register(new PearlIntercept());
        register(new ElytraHotSwap());
        register(new AirPots());
        register(new Backtrack());
        register(new ShieldMacro());
        register(new AntiAnvil());
        register(new BowSpam());
        register(new HoleFiller());
        register(new SelfTrap());
        register(new AutoCity());
        register(new ArrowDodge());
        register(new ExpThrower());
        register(new BedAura());
        register(new PopChams());
        register(new Burrow());
        register(new AutoSprint());
        register(new BunnyHop());
        register(new NoFall());
        register(new FastLadder());
        register(new Step());
        register(new NoSlowdown());
        register(new Fly());
        register(new BoatFly());
        register(new FlyLegit());
        register(new NoClip());
        register(new Spider());
        register(new Jesus());
        register(new Sneak());
        register(new NoWeb());
        register(new FastPlace());
        register(new Glide());
        register(new HighJump());
        register(new SpeedHack());
        register(new AutoWalk());
        register(new Blink());
        register(new AirJump());
        register(new LongJump());
        register(new Jetpack());
        register(new Follow());
        register(new ElytraFollow());
        register(new AutoElytraFly());
        register(new AutoMLG());
        register(new AntiVoid());
        register(new NoRotateSet());
        register(new InventoryMove());
        register(new Strafe());
        register(new AntiLevitation());
        register(new AutoJump());
        register(new ReverseStep());
        register(new Slippy());
        register(new AutoMount());
        register(new EntityControl());
        register(new Portals());
        register(new Anchor());
        register(new AntiWaterPush());
        register(new AutoSwim());
        register(new SafeWalk());
        register(new ChestESP());
        register(new SchematicModule());
        register(new PlayerESP());
        register(new FullBright());
        register(new Shaders());
        register(new GuiBlur());
        register(new ItemESP());
        register(new MobESP());
        register(new NameTags());
        register(new NoOverlay());
        register(new HurtCam());
        register(new BlockESP());
        register(new Tracers());
        register(new Trajectories());
        register(new XRay());
        register(new ItemAmountHud());
        register(new SpawnerESP());
        register(new Radar());
        register(new HealthTags());
        register(new TrueSight());
        register(new NameProtect());
        register(new BaseFinder());
        register(new PluginFinder());
        register(new CaveFinder());
        register(new PortalESP());
        register(new ObsidianAncientDebrisESP());
        register(new Freecam());
        register(new RemoteView());
        register(new TabGUI());
        register(new ActiveModuleHud());
        register(new PlayerInfoEsp());
        register(new TargetHud());
        register(new TntTime());
        register(new Durability());
        register(new NoRender());
        register(new NoStatusEffects());
        register(new BetterTooltips());
        register(new CameraTweaks());
        register(new EntityOwner());
        register(new LogoutSpots());
        register(new HoleESP());
        register(new VoidESP());
        register(new TimeChanger());
        register(new Snap());
        register(new NoBlockOverlay());
        register(new Waypoints());
        register(new StorageESP());
        register(new BreakIndicators());
        register(new LightOverlay());
        register(new Trail());
        register(new FakePlayer());
        register(new TunnelESP());
        register(new Zoom());
        register(new Keystrokes());
        register(new InventoryHud());
        register(new CpsDisplay());
        register(new ArmorHud());
        register(new PotionHud());
        register(new CoordsHud());
        register(new FPSPingHud());
        register(new SpeedHud());
        register(new ClockHud());
        register(new AutoLogin());
        {
            Module m = getModuleByName("AutoLogin");
            if (m != null)
                m.setToggled(true);
        }
        register(new UIUtils());
        register(new NoDynamicFov());
        register(new DeathCords());
        register(new CreamyKeys());
        register(new Weather());
        register(new HitColour());
        register(new BlockHighlighter());
        register(new Spammer());
        register(new FancyChat());
        register(new MassTpa());
        register(new MassTpaHere());
        register(new Home());
        register(new BetterChat());
        register(new Derp());
        register(new SkinDerp());
        register(new AutoSwing());
        register(new HeadRoll());
        register(new ColorUi());
        register(new Headless());
        register(new Lsd());
        register(new MileyCyrus());
        register(new ChatGames());
        register(new AutoArmor());
        register(new AutoEat());
        register(new AutoTotem());
        register(new ChestStealer());
        register(new CobwebBreaker());
        register(new KillPotion());
        register(new CrashChest());
        register(new CrashTag());
        register(new CmdBlock());
        register(new AutoXP());
        register(new AutoMend());
        register(new InventoryTweaks());
        register(new AutoSmelter());
        register(new AutoBrewer());
        register(new SelfAnvil());
        register(new AutoPotion());
        register(new AutoNametag());
        register(new FastBow());
        register(new FastEat());
        register(new AntiFire());
        register(new AntiPotion());
        register(new ForcePush());
        register(new AutoRespawn());
        register(new Timer());
        register(new AutoFish());
        register(new AntiAFK());
        register(new Panic());
        register(new Throw());
        register(new Regen());
        register(new Teleport());
        register(new AntiCactus());
        register(new AutoGG());
        register(new PotionSaver());
        register(new AntiSpam());
        register(new ClientSpoofer());
        register(new LogSpammer());
        register(new Baritone());
        register(new AntiHunger());
        register(new AutoReconnect());
        {
            Module m = getModuleByName("AutoReconnect");
            if (m != null)
                m.setToggled(true);
        }
        register(new Offhand());
        register(new NoMiningTrace());
        register(new AirPlace());
        register(new EndermanLook());
        register(new NoInteract());
        register(new LiquidInteract());
        register(new Notifier());
        register(new NotificationHud());
        register(new SoundBlocker());
        register(new ScreenRecording());
        register(new UnderY0());
        register(new ViaBlocks());
        register(new TuffDebug());
        register(new Clutch());
        register(new Animations());
        register(new Chams());
        register(new Hat());
        {
            Module m = getModuleByName("Hat");
            if (m != null)
                m.setToggled(true);
        }
        register(new JumpCircle());
        {
            Module m = getModuleByName("Jump Circle");
            if (m != null)
                m.setToggled(true);
        }
        register(new Particles());
        register(new Arrows());
        register(new Explosions());
        register(new NoFog());
        register(new BlockHit());
        register(new AntiBot());
        register(new ArmorSwitch());
        register(new InvCleaner());
        register(new Throwpot());
        register(new ThrowDebuff());
        register(new AutoHotbar());
        register(new BedBreaker());
        register(new AutoPearl());
        register(new Refill());
        register(new Health());
        register(new MurderFinder());
        register(new KeepSprint());
        register(new AntiPacketKick());
        register(new ChestSwap());
        register(new FreeLook());
        register(new SpawnProofer());
        register(new ItemGlow());
        register(new Multitask());
        register(new MiddleClickExtra());
        register(new PacketLogger());
        register(new Rotation());
        register(new PacketCanceller());
        register(new SelfWeb());
        register(new ElytraBoost());
        noDynamicFovModule = getModuleByName("NoDynamicFov");
        noStatusEffectsModule = getModuleByName("NoStatusEffects");
        noOverlayModule = getModuleByName("NoOverlay");
        hurtCamModule = getModuleByName("HurtCam");
        hitColourModule = getModuleByName("HitColour");
        multitaskModule = (Multitask) getModuleByName("Multitask");
    }

    private static void desc(String name, String description) {
        Module m = getModuleByName(name);
        if (m != null)
            m.setDescription(description);
    }

    public static void register(Module m) {
        modules.add(m);
        moduleMap.put(m.getName().toLowerCase(), m);
    }

    public static List<Module> getModules() {
        return modules;
    }

    public static Module getModuleByName(String name) {
        return moduleMap.get(client.utils.StrProt.x(name).toLowerCase());
    }

    public static Module getModuleByFuzzyName(String query) {
        if (query == null || query.isEmpty())
            return null;
        String q = query.toLowerCase();
        Module exact = moduleMap.get(q);
        if (exact != null)
            return exact;
        for (Module m : modules) {
            if (m.getName().toLowerCase().startsWith(q))
                return m;
        }
        if (q.length() >= 2) {
            for (Module m : modules) {
                if (matchesAbbreviation(m.getName(), q))
                    return m;
            }
        }
        for (Module m : modules) {
            if (m.getName().toLowerCase().contains(q))
                return m;
        }
        return null;
    }

    public static List<Module> searchModules(String query) {
        List<Module> results = new ArrayList<>();
        String q = query.toLowerCase();
        for (Module m : modules) {
            if (m.getName().toLowerCase().contains(q)) {
                results.add(m);
            }
        }
        return results;
    }

    private static boolean matchesAbbreviation(String name, String query) {
        String[] words = name.split("(?=[A-Z])");
        int qi = 0;
        for (String word : words) {
            if (word.isEmpty())
                continue;
            if (Character.toLowerCase(word.charAt(0)) == query.charAt(qi)) {
                qi++;
                if (qi >= query.length())
                    return true;
            }
        }
        return false;
    }

    public static List<Module> getModulesByCategory(Category c) {
        List<Module> list = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == c) {
                list.add(m);
            }
        }
        java.util.Collections.sort(list, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        return list;
    }

    public static void onKeyPressed(int keyCode) {
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getMinecraft();
        if (mc.currentScreen instanceof net.minecraft.client.gui.GuiChat)
            return;
        if (mc.currentScreen != null)
            return;
        java.util.List<Module> matches = new java.util.ArrayList<>();
        for (Module m : modules) {
            if (m.getKey() == keyCode) {
                matches.add(m);
            }
        }
        if (matches.size() > 1) {
            StringBuilder names = new StringBuilder();
            for (int i = 0; i < matches.size(); i++) {
                if (i > 0)
                    names.append(", ");
                names.append(matches.get(i).getName());
            }
            client.utils.misc.NotificationSystem.warning("Keybind conflict: " + names + " share key " + Keyboard.getKeyName(keyCode));
        }
        for (Module m : matches) {
            m.toggle();
        }
    }
}
