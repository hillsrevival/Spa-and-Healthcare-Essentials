package client.module.impl.render;

import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.utils.render.ClientFontRenderer;
import client.utils.render.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.AxisAlignedBB;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Waypoints extends Module {

    public static Waypoints INSTANCE;

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting nametag = new BooleanSetting("Nametag", true);

    private static final int MAX_WAYPOINTS = 50;

    private final LinkedHashMap<String, double[]> namedWPs = new LinkedHashMap<String, double[]>();

    private final List<double[]> waypoints = new ArrayList<>();

    private final List<String> names = new ArrayList<>();

    private boolean tabWasDown = false;

    public Waypoints() {
        super("Waypoints", Category.RENDER);
        setDescription("Saves and displays waypoint markers");
        addSetting(nametag);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
        INSTANCE = this;
    }

    public boolean addWaypoint(String name, double x, double y, double z) {
        if (namedWPs.containsKey(name)) {
            namedWPs.put(name, new double[] { x, y, z });
            syncToList();
            return true;
        }
        if (namedWPs.size() >= MAX_WAYPOINTS) {
            return false;
        }
        namedWPs.put(name, new double[] { x, y, z });
        syncToList();
        return true;
    }

    public boolean removeWaypoint(String name) {
        double[] removed = namedWPs.remove(name);
        if (removed != null) {
            syncToList();
            return true;
        }
        return false;
    }

    public double[] getWaypoint(String name) {
        return namedWPs.get(name);
    }

    public Map<String, double[]> getAllWaypoints() {
        return namedWPs;
    }

    public int getWaypointCount() {
        return namedWPs.size();
    }

    public boolean hasWaypoint(String name) {
        return namedWPs.containsKey(name);
    }

    public void clearAllWaypoints() {
        namedWPs.clear();
        syncToList();
    }

    private void syncToList() {
        waypoints.clear();
        names.clear();
        for (Map.Entry<String, double[]> entry : namedWPs.entrySet()) {
            waypoints.add(entry.getValue());
            names.add(entry.getKey());
        }
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        boolean tabDown = mc.gameSettings.keyBindPlayerList.isKeyDown();
        if (tabDown && !tabWasDown) {
            String name = "WP-" + (namedWPs.size() + 1);
            double x = mc.player.posX;
            double y = mc.player.posY;
            double z = mc.player.posZ;
            addWaypoint(name, x, y, z);
        }
        tabWasDown = tabDown;
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (waypoints.isEmpty())
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        RenderUtils.prepareGL();
        for (int i = 0; i < waypoints.size(); i++) {
            double[] wp = waypoints.get(i);
            double wx = wp[0];
            double wy = wp[1];
            double wz = wp[2];
            double dist = Math.sqrt((wx - mc.player.posX) * (wx - mc.player.posX) + (wz - mc.player.posZ) * (wz - mc.player.posZ));
            if (dist > 64)
                continue;
            AxisAlignedBB beam = new AxisAlignedBB(wx - 0.15, wy - 0.5, wz - 0.15, wx + 0.15, wy + 10, wz + 0.15).offset(-RenderUtils.camX, -RenderUtils.camY, -RenderUtils.camZ);
            RenderUtils.drawSolidBox(beam, 0.0f, 1.0f, 0.3f, 0.1f);
            AxisAlignedBB base = new AxisAlignedBB(wx - 0.5, wy - 1, wz - 0.5, wx + 0.5, wy + 0.5, wz + 0.5).offset(-RenderUtils.camX, -RenderUtils.camY, -RenderUtils.camZ);
            RenderUtils.drawSolidBox(base, 0.0f, 1.0f, 0.3f, 0.2f);
            RenderUtils.drawOutlinedBox(base, 0.0f, 1.0f, 0.3f, 0.6f);
            AxisAlignedBB node = new AxisAlignedBB(wx - 0.3, wy + 10, wz - 0.3, wx + 0.3, wy + 10.3, wz + 0.3).offset(-RenderUtils.camX, -RenderUtils.camY, -RenderUtils.camZ);
            RenderUtils.drawNode(node, 0.0f, 1.0f, 0.3f, 0.8f);
        }
        RenderUtils.restoreGL();
        if (nametag.getValue()) {
            float viewY = mc.getRenderManager().playerViewY;
            float viewX = mc.getRenderManager().playerViewX;
            for (int i = 0; i < waypoints.size(); i++) {
                double[] wp = waypoints.get(i);
                double dist = Math.sqrt((wp[0] - mc.player.posX) * (wp[0] - mc.player.posX) + (wp[2] - mc.player.posZ) * (wp[2] - mc.player.posZ));
                if (dist > 32)
                    continue;
                net.minecraft.client.renderer.EntityRenderer.drawNameplate(ClientFontRenderer.getFontRenderer(), names.get(i), (float) (wp[0] - RenderUtils.camX), (float) (wp[1] + 2.2 - RenderUtils.camY), (float) (wp[2] - RenderUtils.camZ), 0, viewY, viewX, false, false);
            }
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }
}
