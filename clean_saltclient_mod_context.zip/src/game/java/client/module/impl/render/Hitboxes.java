package client.module.impl.render;

import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.render.RenderUtils;
import net.minecraft.client.Minecraft;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import client.utils.EntityUtils;

public class Hitboxes extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting expand = new NumberSetting("Expand", 0.2, 0.1, 1.0);

    private final BooleanSetting fill = new BooleanSetting("Fill", false);

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 1.5, 0.5, 4.0);

    private final NumberSetting fillAlpha = new NumberSetting("Fill Alpha", 0.12, 0.0, 0.5);

    public Hitboxes() {
        super("Hitboxes", Category.RENDER);
        setDescription("Renders larger hitboxes around entities");
        addSetting(expand);
        addSetting(fill);
        addSetting(lineWidth);
        addSetting(fillAlpha);
        handles(HandlerType.RENDER);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        RenderUtils.prepareGL();
        EaglercraftGPU.glLineWidth(lineWidth.getValue().floatValue());
        float exp = expand.getValue().floatValue();
        for (Object obj : EntityUtils.getLoadedEntities()) {
            if (!(obj instanceof EntityPlayer))
                continue;
            EntityPlayer player = (EntityPlayer) obj;
            if (player == mc.player)
                continue;
            AxisAlignedBB box = player.getEntityBoundingBox().expand(exp, exp, exp);
            AxisAlignedBB renderBox = box.offset(-RenderUtils.camX, -RenderUtils.camY, -RenderUtils.camZ);
            if (fill.getValue()) {
                RenderUtils.drawSolidBox(renderBox, 0.0f, 1.0f, 0.0f, fillAlpha.getValue().floatValue());
            }
            RenderUtils.drawOutlinedBox(renderBox, 0.0f, 1.0f, 0.0f, 0.8f);
        }
        RenderUtils.restoreGL();
    }
}
