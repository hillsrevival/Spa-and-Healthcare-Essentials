package client.module.impl.render;

import client.event.listeners.RenderListener;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.ColorSetting;
import client.module.Condition;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.Module;
import client.module.NumberSetting;
import client.utils.render.RenderUtils;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.lax1dude.eaglercraft.opengl.WorldRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityEgg;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.projectile.EntitySnowball;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Particles extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Random random = new Random();

    private final BooleanSetting onAttack = new BooleanSetting("On Attack", false);

    private final BooleanSetting onThrow = new BooleanSetting("On Throw", false);

    private final BooleanSetting onWorld = new BooleanSetting("On World", true);

    private final ModeSetting particleMode = new ModeSetting("Shape", "Fluid", "Circle", "Star", "Diamond", "Cross", "Heart", "Fluid");

    private final NumberSetting size = new NumberSetting("Size", 0.5, 0.1, 1.0);

    private final NumberSetting lifetime = new NumberSetting("Lifetime", 2000.0, 500.0, 5000.0);

    private final NumberSetting maxParticles = new NumberSetting("Max Particles", 300.0, 50.0, 500.0);

    private final NumberSetting attackCount = new NumberSetting("Attack Count", 20.0, 5.0, 50.0);

    private final NumberSetting spread = new NumberSetting("Spread", 6.0, 1.0, 15.0);

    private final BooleanSetting rainbow = new BooleanSetting("Rainbow", true);

    private final ColorSetting color = new ColorSetting("Color", 200.0);

    private final NumberSetting fluidPoints = new NumberSetting("Fluid Points", 8.0, 4.0, 16.0);

    private final NumberSetting fluidWobble = new NumberSetting("Wobble", 0.35, 0.1, 0.8);

    private final List<Particle> attackParticles = new ArrayList<Particle>();

    private final List<Particle> throwParticles = new ArrayList<Particle>();

    private final List<Particle> worldParticles = new ArrayList<Particle>();

    private int worldCooldown = 0;

    public Particles() {
        super("Particles", Category.RENDER);
        setDescription("Custom particles for aura");
        addSetting(onAttack);
        addSetting(onThrow);
        addSetting(onWorld);
        addSetting(particleMode);
        addSetting(size);
        addSetting(lifetime);
        addSetting(maxParticles);
        addSetting(attackCount);
        addSetting(spread);
        addSetting(rainbow);
        addSetting(color);
        addSetting(fluidPoints);
        addSetting(fluidWobble);
        color.setVisibilityCondition(Condition.whenFalse(rainbow));
        fluidPoints.setVisibilityCondition(Condition.whenEqualTo(particleMode, "Fluid"));
        fluidWobble.setVisibilityCondition(Condition.whenEqualTo(particleMode, "Fluid"));
        handles(HandlerType.ATTACK, HandlerType.UPDATE, HandlerType.RENDER);
    }

    @Override
    public void onAttack(client.event.events.AttackEvent event) {
        if (!onAttack.getValue())
            return;
        if (!nullCheck())
            return;
        Entity target = event.getTarget();
        if (target == null)
            return;
        float motion = spread.getValue().floatValue();
        int count = attackCount.getValue().intValue();
        for (int i = 0; i < count; i++) {
            double px = target.posX + random.nextGaussian() * 0.3;
            double py = target.posY + target.height * 0.5 + random.nextGaussian() * 0.3;
            double pz = target.posZ + random.nextGaussian() * 0.3;
            double vx = random.nextGaussian() * motion * 0.1;
            double vy = random.nextGaussian() * motion * 0.1;
            double vz = random.nextGaussian() * motion * 0.1;
            spawnParticle(attackParticles, px, py, pz, vx, vy, vz, i);
        }
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) {
            clear();
            return;
        }
        if (onThrow.getValue()) {
            int throwBudget = 16;
            for (Entity entity : mc.world.loadedEntityList) {
                if (throwBudget <= 0)
                    break;
                if (!(entity instanceof EntityEnderPearl) && !(entity instanceof EntityArrow) && !(entity instanceof EntitySnowball) && !(entity instanceof EntityEgg))
                    continue;
                boolean isMoving = entity.prevPosX != entity.posX || entity.prevPosY != entity.posY || entity.prevPosZ != entity.posZ;
                if (!isMoving)
                    continue;
                for (int i = 0; i < 3 && throwBudget > 0; i++) {
                    double px = entity.posX + random.nextGaussian() * 0.2;
                    double py = entity.posY + random.nextGaussian() * 0.2;
                    double pz = entity.posZ + random.nextGaussian() * 0.2;
                    double vx = random.nextGaussian() * 0.5;
                    double vy = random.nextGaussian() * 0.15;
                    double vz = random.nextGaussian() * 0.5;
                    spawnParticle(throwParticles, px, py, pz, vx, vy, vz, throwParticles.size());
                    throwBudget--;
                }
            }
        }
        if (onWorld.getValue()) {
            if (++worldCooldown >= 3) {
                worldCooldown = 0;
                int r = 12;
                for (int i = 0; i < 4; i++) {
                    double px = mc.player.posX + random.nextGaussian() * r;
                    double py = mc.player.posY + random.nextDouble() * r;
                    double pz = mc.player.posZ + random.nextGaussian() * r;
                    double vx = mc.player.motionX + random.nextGaussian() * 1.0;
                    double vy = random.nextGaussian() * 0.1;
                    double vz = mc.player.motionZ + random.nextGaussian() * 1.0;
                    spawnParticle(worldParticles, px, py, pz, vx, vy, vz, worldParticles.size());
                }
            }
        }
        long life = lifetime.getValue().longValue();
        updateParticles(attackParticles, life);
        updateParticles(throwParticles, life);
        updateParticles(worldParticles, life * 2);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (attackParticles.isEmpty() && throwParticles.isEmpty() && worldParticles.isEmpty())
            return;
        float partialTicks = event.getPartialTicks();
        RenderUtils.updateCameraPos(partialTicks);
        double camX = RenderUtils.camX;
        double camY = RenderUtils.camY;
        double camZ = RenderUtils.camZ;
        long now = System.currentTimeMillis();
        long life = lifetime.getValue().longValue();
        float particleSize = 0.05F + size.getValue().floatValue() * 0.2F;
        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
        GlStateManager.disableDepth();
        GlStateManager.depthMask(false);
        RenderUtils.enableLineSmooth();
        renderParticleList(attackParticles, camX, camY, camZ, now, life * 400 / 2000, life * 600 / 2000, particleSize);
        renderParticleList(throwParticles, camX, camY, camZ, now, life * 700 / 2000, life * 1200 / 2000, particleSize);
        renderParticleList(worldParticles, camX, camY, camZ, now, life * 1500 / 4000, life * 2200 / 4000, particleSize);
        EaglercraftGPU.glLineWidth(1.0F);
        RenderUtils.disableLineSmooth();
        GlStateManager.depthMask(true);
        GlStateManager.enableDepth();
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
        GlStateManager.popMatrix();
    }

    private void spawnParticle(List<Particle> list, double x, double y, double z, double vx, double vy, double vz, int index) {
        int max = maxParticles.getValue().intValue();
        while (list.size() >= max) list.remove(0);
        float particleSize = 0.05F + size.getValue().floatValue() * 0.2F;
        float[] rgb;
        if (rainbow.getValue()) {
            float h = ((spawnCounter * 25L) % 360) / 360.0F;
            spawnCounter++;
            rgb = RenderUtils.hsbToRgb(h, 1.0F, 1.0F);
        } else {
            rgb = color.getRGBFloat();
        }
        float phaseA = random.nextFloat() * (float) Math.PI * 2.0F;
        float phaseB = random.nextFloat() * (float) Math.PI * 2.0F;
        float phaseC = random.nextFloat() * (float) Math.PI * 2.0F;
        list.add(new Particle(x, y, z, vx * 0.05, vy * 0.05, vz * 0.05, rgb[0], rgb[1], rgb[2], particleSize, System.currentTimeMillis(), phaseA, phaseB, phaseC));
    }

    private void updateParticles(List<Particle> list, long lifespan) {
        long now = System.currentTimeMillis();
        Iterator<Particle> it = list.iterator();
        while (it.hasNext()) {
            Particle p = it.next();
            double friction = 0.98;
            p.vx *= friction;
            p.vy *= friction;
            p.vy -= 0.0002;
            p.vz *= friction;
            p.x += p.vx;
            p.y += p.vy;
            p.z += p.vz;
            if (now - p.spawnTime > lifespan) {
                it.remove();
            }
        }
    }

    private void renderParticleList(List<Particle> list, double camX, double camY, double camZ, long now, long fadeInTime, long fadeOutTime, float baseSize) {
        if (list.isEmpty())
            return;
        for (Particle p : list) {
            long age = now - p.spawnTime;
            float fadeIn = age < fadeInTime ? (float) age / fadeInTime : 1.0F;
            float fadeOut = age > fadeOutTime ? 1.0F - (float) (age - fadeOutTime) / (lifetime.getValue().floatValue() - fadeOutTime) : 1.0F;
            float alpha = Math.max(0.0F, Math.min(1.0F, fadeIn * fadeOut));
            if (alpha <= 0.01F)
                continue;
            double rx = p.x - camX;
            double ry = p.y - camY;
            double rz = p.z - camZ;
            float s = baseSize * fadeIn;
            drawParticleShape(rx, ry, rz, s, p.r, p.g, p.b, alpha, p.phaseA, p.phaseB, p.phaseC, now);
        }
    }

    private void drawParticleShape(double x, double y, double z, float size, float r, float g, float b, float alpha, float phaseA, float phaseB, float phaseC, long now) {
        String shape = particleMode.getValue();
        if (shape.equals("Fluid")) {
            drawFluid(x, y, z, size, r, g, b, alpha, phaseA, phaseB, phaseC, now);
        } else if (shape.equals("Circle")) {
            drawCircle(x, y, z, size, r, g, b, alpha);
        } else if (shape.equals("Star")) {
            drawStar(x, y, z, size, r, g, b, alpha);
        } else if (shape.equals("Diamond")) {
            drawDiamond(x, y, z, size, r, g, b, alpha);
        } else if (shape.equals("Cross")) {
            drawCross(x, y, z, size, r, g, b, alpha);
        } else if (shape.equals("Heart")) {
            drawHeart(x, y, z, size, r, g, b, alpha);
        } else {
            drawFluid(x, y, z, size, r, g, b, alpha, phaseA, phaseB, phaseC, now);
        }
    }

    private void drawFluid(double x, double y, double z, float size, float r, float g, float b, float alpha, float phaseA, float phaseB, float phaseC, long now) {
        int points = fluidPoints.getValue().intValue();
        float wobble = fluidWobble.getValue().floatValue();
        float time = now * 0.003F;
        EaglercraftGPU.glLineWidth(2.5F);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        buf.begin(RealOpenGLEnums.GL_LINE_STRIP, DefaultVertexFormats.POSITION_COLOR);
        int segments = points * 4;
        for (int i = 0; i <= segments; i++) {
            float angle = (float) (Math.PI * 2.0 * i / segments);
            float radius = size;
            radius += size * wobble * (float) Math.sin(2.0 * angle + time * 1.3 + phaseA);
            radius += size * wobble * 0.5F * (float) Math.sin(3.0 * angle - time * 0.9 + phaseB);
            radius += size * wobble * 0.25F * (float) Math.sin(5.0 * angle + time * 2.1 + phaseC);
            radius *= 1.0F + 0.08F * (float) Math.sin(time * 0.7 + phaseA);
            radius = Math.max(radius, size * 0.2F);
            float px = (float) x + (float) Math.cos(angle) * radius;
            float py = (float) y + (float) Math.sin(angle) * radius;
            buf.pos(px, py, (float) z).color(r, g, b, alpha).endVertex();
        }
        tess.draw();
        EaglercraftGPU.glLineWidth(1.0F);
        buf.begin(RealOpenGLEnums.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        float innerAlpha = alpha * 0.35F;
        for (int i = 0; i < points; i++) {
            float angle = (float) (Math.PI * 2.0 * i / points);
            float outerR = size;
            outerR += size * wobble * (float) Math.sin(2.0 * angle + time * 1.3 + phaseA);
            outerR += size * wobble * 0.5F * (float) Math.sin(3.0 * angle - time * 0.9 + phaseB);
            outerR *= 1.0F + 0.08F * (float) Math.sin(time * 0.7 + phaseA);
            outerR = Math.max(outerR, size * 0.2F);
            buf.pos((float) x, (float) y, (float) z).color(r, g, b, innerAlpha).endVertex();
            buf.pos((float) x + (float) Math.cos(angle) * outerR, (float) y + (float) Math.sin(angle) * outerR, (float) z).color(r, g, b, innerAlpha).endVertex();
        }
        tess.draw();
    }

    private void drawCircle(double x, double y, double z, float size, float r, float g, float b, float alpha) {
        int segments = 12;
        EaglercraftGPU.glLineWidth(2.0F);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        buf.begin(RealOpenGLEnums.GL_LINE_STRIP, DefaultVertexFormats.POSITION_COLOR);
        for (int i = 0; i <= segments; i++) {
            float angle = (float) (Math.PI * 2.0 * i / segments);
            float px = (float) x + (float) Math.cos(angle) * size;
            float py = (float) y + (float) Math.sin(angle) * size;
            buf.pos(px, py, (float) z).color(r, g, b, alpha).endVertex();
        }
        tess.draw();
    }

    private void drawStar(double x, double y, double z, float size, float r, float g, float b, float alpha) {
        int points = 5;
        EaglercraftGPU.glLineWidth(2.0F);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        buf.begin(RealOpenGLEnums.GL_LINE_STRIP, DefaultVertexFormats.POSITION_COLOR);
        for (int i = 0; i <= points * 2; i++) {
            float angle = (float) (Math.PI * 2.0 * i / (points * 2)) - (float) Math.PI / 2;
            float radius = (i % 2 == 0) ? size : size * 0.4F;
            float px = (float) x + (float) Math.cos(angle) * radius;
            float py = (float) y + (float) Math.sin(angle) * radius;
            buf.pos(px, py, (float) z).color(r, g, b, alpha).endVertex();
        }
        tess.draw();
    }

    private void drawDiamond(double x, double y, double z, float size, float r, float g, float b, float alpha) {
        EaglercraftGPU.glLineWidth(2.0F);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        buf.begin(RealOpenGLEnums.GL_LINE_LOOP, DefaultVertexFormats.POSITION_COLOR);
        buf.pos((float) x, (float) y + size, (float) z).color(r, g, b, alpha).endVertex();
        buf.pos((float) x + size, (float) y, (float) z).color(r, g, b, alpha).endVertex();
        buf.pos((float) x, (float) y - size, (float) z).color(r, g, b, alpha).endVertex();
        buf.pos((float) x - size, (float) y, (float) z).color(r, g, b, alpha).endVertex();
        tess.draw();
    }

    private void drawCross(double x, double y, double z, float size, float r, float g, float b, float alpha) {
        EaglercraftGPU.glLineWidth(2.0F);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        buf.begin(RealOpenGLEnums.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        buf.pos((float) x - size, (float) y - size, (float) z).color(r, g, b, alpha).endVertex();
        buf.pos((float) x + size, (float) y + size, (float) z).color(r, g, b, alpha).endVertex();
        buf.pos((float) x + size, (float) y - size, (float) z).color(r, g, b, alpha).endVertex();
        buf.pos((float) x - size, (float) y + size, (float) z).color(r, g, b, alpha).endVertex();
        tess.draw();
    }

    private void drawHeart(double x, double y, double z, float size, float r, float g, float b, float alpha) {
        int segments = 20;
        EaglercraftGPU.glLineWidth(2.0F);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        buf.begin(RealOpenGLEnums.GL_LINE_STRIP, DefaultVertexFormats.POSITION_COLOR);
        for (int i = 0; i <= segments; i++) {
            float t = (float) (Math.PI * 2.0 * i / segments);
            float hx = 16.0F * (float) Math.pow(Math.sin(t), 3);
            float hy = 13.0F * (float) Math.cos(t) - 5.0F * (float) Math.cos(2 * t) - 2.0F * (float) Math.cos(3 * t) - (float) Math.cos(4 * t);
            float px = (float) x + hx * size / 17.0F;
            float py = (float) y + hy * size / 17.0F;
            buf.pos(px, py, (float) z).color(r, g, b, alpha).endVertex();
        }
        tess.draw();
    }

    private void clear() {
        attackParticles.clear();
        throwParticles.clear();
        worldParticles.clear();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        clear();
    }

    private int spawnCounter = 0;

    private static class Particle {

        double x, y, z;

        double vx, vy, vz;

        float r, g, b;

        float size;

        long spawnTime;

        float phaseA, phaseB, phaseC;

        Particle(double x, double y, double z, double vx, double vy, double vz, float r, float g, float b, float size, long spawnTime, float phaseA, float phaseB, float phaseC) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.vx = vx;
            this.vy = vy;
            this.vz = vz;
            this.r = r;
            this.g = g;
            this.b = b;
            this.size = size;
            this.spawnTime = spawnTime;
            this.phaseA = phaseA;
            this.phaseB = phaseB;
            this.phaseC = phaseC;
        }
    }
}
