package client.module.impl.render;

import client.module.NumberSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.item.EntityTNTPrimed;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.impl.fun.ColorUi;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;
import client.utils.EntityUtils;

public class TntTime extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final client.module.NumberSetting scale = new client.module.NumberSetting("Scale", 1.0, 0.5, 3.0);

    private final List<EntityTNTPrimed> cachedTnts = new ArrayList<>();

    private final List<String> cachedText = new ArrayList<>();

    public TntTime() {
        super("TntTime", Category.RENDER);
        setDescription("Shows timer above tnt until explosion");
        addSetting(scale);
        handles(HandlerType.UPDATE, HandlerType.GUI_RENDER);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        cachedTnts.clear();
        cachedText.clear();
        for (Object obj : EntityUtils.getLoadedEntities()) {
            if (obj instanceof EntityTNTPrimed) {
                EntityTNTPrimed tnt = (EntityTNTPrimed) obj;
                cachedTnts.add(tnt);
                cachedText.add(String.format("%.1fs", tnt.getFuse() / 20.0f));
            }
        }
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        List<EntityTNTPrimed> tnts = cachedTnts;
        if (tnts.isEmpty())
            return;
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        float scaleFactor = scale.getValue().floatValue();
        for (int tntIdx = 0; tntIdx < tnts.size(); tntIdx++) {
            EntityTNTPrimed tnt = tnts.get(tntIdx);
            int fuse = tnt.getFuse();
            String text = cachedText.get(tntIdx);
            int color = getFuseColor(fuse);
            double x = tnt.posX;
            double y = tnt.posY + 1.8;
            double z = tnt.posZ;
            float screenX = projectX(x, y, z);
            float screenY = projectY(x, y, z);
            if (screenX < -50 || screenX > mc.displayWidth + 50)
                continue;
            if (screenY < -50 || screenY > mc.displayHeight + 50)
                continue;
            if (screenX == Float.MAX_VALUE)
                continue;
            float displayScale = 0.025f * scaleFactor;
            float scaledX = screenX / sr.getScaleFactor();
            float scaledY = screenY / sr.getScaleFactor();
            int textWidth = ClientFontRenderer.getStringWidth(text);
            int bgAlpha = (int) (Math.min(1.0, (80 - fuse) / 40.0) * 180) + 40;
            int bgColor = (Math.min(bgAlpha, 220) << 24) | 0x000000;
            float bgLeft = scaledX - textWidth / 2.0f - 2;
            float bgRight = scaledX + textWidth / 2.0f + 2;
            float bgTop = scaledY - 1;
            float bgBottom = scaledY + 9;
            RenderUtils.prepareHUD();
            RenderUtils.drawRoundedRect2D((int) bgLeft, (int) bgTop, (int) bgRight, (int) bgBottom, 4, bgColor);
            RenderUtils.restoreHUD();
            ClientFontRenderer.drawStringWithShadow(text, (int) (scaledX - textWidth / 2.0f), (int) scaledY, color);
        }
    }

    private int getFuseColor(int fuse) {
        Module rb = client.module.ModuleManager.getModuleByName("ColorUi");
        if (rb != null && rb.isToggled()) {
            return ColorUi.getRainbowColor(255);
        }
        float ratio = Math.max(0.0f, Math.min(1.0f, fuse / 80.0f));
        int r, g, b;
        if (ratio > 0.5f) {
            float t = (ratio - 0.5f) * 2.0f;
            r = (int) (255 * (1.0f - t));
            g = 255;
        } else {
            float t = ratio * 2.0f;
            r = 255;
            g = (int) (255 * t);
        }
        b = 0;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private float projectX(double x, double y, double z) {
        double dx = x - mc.getRenderManager().viewerPosX;
        double dy = y - mc.getRenderManager().viewerPosY;
        double dz = z - mc.getRenderManager().viewerPosZ;
        float yaw = mc.getRenderManager().playerViewY * 0.017453292f;
        float pitch = mc.getRenderManager().playerViewX * 0.017453292f;
        double cosYaw = Math.cos(-yaw);
        double sinYaw = Math.sin(-yaw);
        double cosPitch = Math.cos(pitch);
        double sinPitch = Math.sin(pitch);
        double relX = dx * cosYaw - dz * sinYaw;
        double relZ = dx * sinYaw + dz * cosYaw;
        double relY = dy * cosPitch - relZ * sinPitch;
        relZ = dy * sinPitch + relZ * cosPitch;
        if (relZ < 0.1)
            return Float.MAX_VALUE;
        double halfW = mc.displayWidth / 2.0;
        return (float) (halfW + relX / relZ * halfW);
    }

    private float projectY(double x, double y, double z) {
        double dx = x - mc.getRenderManager().viewerPosX;
        double dy = y - mc.getRenderManager().viewerPosY;
        double dz = z - mc.getRenderManager().viewerPosZ;
        float yaw = mc.getRenderManager().playerViewY * 0.017453292f;
        float pitch = mc.getRenderManager().playerViewX * 0.017453292f;
        double cosYaw = Math.cos(-yaw);
        double sinYaw = Math.sin(-yaw);
        double cosPitch = Math.cos(pitch);
        double sinPitch = Math.sin(pitch);
        double relX = dx * cosYaw - dz * sinYaw;
        double relZ = dx * sinYaw + dz * cosYaw;
        double relY = dy * cosPitch - relZ * sinPitch;
        relZ = dy * sinPitch + relZ * cosPitch;
        if (relZ < 0.1)
            return Float.MAX_VALUE;
        double halfH = mc.displayHeight / 2.0;
        return (float) (halfH - relY / relZ * halfH);
    }

    private void drawRect(int left, int top, int right, int bottom, int color) {
        int a = (color >> 24) & 0xFF;
        float fa = a / 255.0f;
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        net.lax1dude.eaglercraft.opengl.GlStateManager.enableBlend();
        net.lax1dude.eaglercraft.opengl.GlStateManager.disableTexture2D();
        net.lax1dude.eaglercraft.opengl.GlStateManager.tryBlendFuncSeparate(net.lax1dude.eaglercraft.opengl.RealOpenGLEnums.GL_SRC_ALPHA, net.lax1dude.eaglercraft.opengl.RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, net.lax1dude.eaglercraft.opengl.RealOpenGLEnums.GL_ONE, net.lax1dude.eaglercraft.opengl.RealOpenGLEnums.GL_ZERO);
        net.lax1dude.eaglercraft.opengl.GlStateManager.color(r / 255.0f, g / 255.0f, b / 255.0f, fa);
        net.minecraft.client.renderer.Tessellator tess = net.minecraft.client.renderer.Tessellator.getInstance();
        net.lax1dude.eaglercraft.opengl.WorldRenderer buf = tess.getBuffer();
        buf.begin(net.lax1dude.eaglercraft.opengl.RealOpenGLEnums.GL_QUADS, net.minecraft.client.renderer.vertex.DefaultVertexFormats.POSITION);
        buf.pos(right, top, 0.0).endVertex();
        buf.pos(left, top, 0.0).endVertex();
        buf.pos(left, bottom, 0.0).endVertex();
        buf.pos(right, bottom, 0.0).endVertex();
        tess.draw();
        RenderUtils.restoreHUD();
    }
}
