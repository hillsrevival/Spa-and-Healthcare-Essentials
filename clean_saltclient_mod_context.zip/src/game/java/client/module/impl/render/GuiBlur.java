package client.module.impl.render;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import client.utils.render.GuiBlurUtil;

public class GuiBlur extends Module {

    private final NumberSetting radius = new NumberSetting("Radius", 8.0, 1.0, 20.0);

    private final NumberSetting dimAlpha = new NumberSetting("Dim", 180.0, 0.0, 255.0);

    public GuiBlur() {
        super("GuiBlur", Category.RENDER);
        setDescription("Blurs the world behind the GUI");
        addSetting(radius);
        addSetting(dimAlpha);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        GuiBlurUtil.setEnabled(true);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        GuiBlurUtil.setEnabled(false);
    }

    @Override
    public void onUpdate() {
        if (isToggled()) {
            GuiBlurUtil.setBlurRadius(radius.getValue().floatValue());
            GuiBlurUtil.setDimAlpha(dimAlpha.getValue().intValue());
        }
    }
}
