package client.module.impl.render;

import client.module.NumberSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.Entity;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.ColorSetting;
import client.utils.render.EntityEspUtils;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;
import client.utils.render.WorldToScreenProjector;
import client.utils.EntityUtils;

public class MobESP extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting tracers = new BooleanSetting("Tracers", false);

    private final BooleanSetting nametags = new BooleanSetting("Nametags", false);

    private final ModeSetting tracerColor = new ModeSetting("Tracer Color", "Default", "Default", "Red", "Green", "Blue", "Yellow", "Purple", "Pink", "Orange", "White", "Cyan", "Rainbow");

    private final ColorSetting customColor = new ColorSetting("Custom Color", 0.0);

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    private final List<EntityLiving> mobs = new ArrayList<EntityLiving>();

    private final EntityEspUtils.EntityColorFn boxColor = new EntityEspUtils.EntityColorFn() {

        @Override
        public void colorOf(Entity entity, int index, float[] out3) {
            EntityEspUtils.distanceColor(entity, 20.0, out3);
        }
    };

    private final EntityEspUtils.EntityColorFn tracerColorFn = new EntityEspUtils.EntityColorFn() {

        @Override
        public void colorOf(Entity entity, int index, float[] out3) {
            float[] c = RenderUtils.resolveTracerColor(tracerColor.getValue(), customColor.getRGBFloat(), index);
            if (c != null) {
                out3[0] = c[0];
                out3[1] = c[1];
                out3[2] = c[2];
            } else {
                EntityEspUtils.distanceColor(entity, 20.0, out3);
            }
        }
    };

    public MobESP() {
        super("MobESP", Category.RENDER);
        setDescription("Highlights mobs and passive mobs");
        addSetting(tracers);
        addSetting(nametags);
        addSetting(tracerColor);
        addSetting(customColor);
        addSetting(lineWidth);
        handles(HandlerType.UPDATE, HandlerType.RENDER, HandlerType.GUI_RENDER);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        mobs.clear();
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (entity instanceof EntityLiving && !(entity instanceof net.minecraft.entity.player.EntityPlayer)) {
                EntityLiving living = (EntityLiving) entity;
                if (!living.isDead && living.getHealth() > 0 && !living.isInvisible()) {
                    mobs.add(living);
                }
            }
        }
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (mobs.isEmpty())
            return;
        float partialTicks = event.getPartialTicks();
        RenderUtils.updateCameraPos(partialTicks);
        EntityEspUtils.drawEntityBoxes(mobs, partialTicks, boxColor, 0.2f, 0.5f, 0.05, null, lineWidth.getValue().floatValue());
        if (tracers.getValue()) {
            EntityEspUtils.drawEntityTracers(mobs, partialTicks, tracerColorFn, 0.5f, 0.5, lineWidth.getValue().floatValue());
        }
    }

    @Override
    public void onGUIRender() {
        if (!nametags.getValue())
            return;
        if (!nullCheck())
            return;
        if (mobs.isEmpty())
            return;
        net.minecraft.client.gui.ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new net.minecraft.client.gui.ScaledResolution(mc);
        for (EntityLiving mob : mobs) {
            if (mob.getDistanceToEntity(mc.player) > 64.0F)
                continue;
            double tagY = mob.posY + mob.height + 0.5;
            float[] pos = WorldToScreenProjector.project(mob.posX, tagY, mob.posZ);
            if (pos == null)
                continue;
            if (pos[0] < -40.0f || pos[1] < -40.0f || pos[0] > sr.getScaledWidth() + 40.0f || pos[1] > sr.getScaledHeight() + 40.0f)
                continue;
            String name = mob.getDisplayName().getFormattedText();
            int textW = ClientFontRenderer.getStringWidth(name);
            if (textW <= 0)
                continue;
            RenderUtils.prepareHUD();
            RenderUtils.drawRoundedRect2D(pos[0] - textW / 2.0f - 2.0f, pos[1] - 1.0f, pos[0] + textW / 2.0f + 2.0f, pos[1] + 9.0f, 3, 0xA0000000);
            RenderUtils.restoreHUD();
            ClientFontRenderer.drawCenteredStringWithShadow(name, pos[0], pos[1], 0xFFFFFFFF);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        mobs.clear();
    }
}
