package client.module.impl.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.render.ClientFontRenderer;

public class ItemAmountHud extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public ItemAmountHud() {
        super("ItemAmountHud", Category.RENDER);
        setDescription("Shows count of specific items on the HUD");
        handles(HandlerType.GUI_RENDER);
    }

    @Override
    public void onGUIRender() {
        if (mc.player == null)
            return;
        ScaledResolution sr = mc.scaledResolution;
        InventoryPlayer inv = mc.player.inventory;
        ItemStack held = inv.getStackInSlot(inv.currentItem);
        if (held.func_190926_b())
            return;
        Item heldItem = held.getItem();
        int heldMeta = held.getMetadata();
        int total = 0;
        for (int i = 0; i < inv.mainInventory.size(); i++) {
            ItemStack stack = inv.mainInventory.get(i);
            if (!stack.func_190926_b() && stack.getItem() == heldItem && stack.getMetadata() == heldMeta) {
                total += stack.func_190916_E();
            }
        }
        if (!mc.player.getHeldItemOffhand().func_190926_b()) {
            ItemStack offhand = mc.player.getHeldItemOffhand();
            if (offhand.getItem() == heldItem && offhand.getMetadata() == heldMeta) {
                total += offhand.func_190916_E();
            }
        }
        if (total <= 1)
            return;
        int screenW = sr.getScaledWidth();
        int screenH = sr.getScaledHeight();
        int hotbarCenterX = screenW / 2;
        int hotbarY = screenH - 22;
        int hotbarRightX = hotbarCenterX + 91 + 2;
        String text = String.valueOf(total);
        ClientFontRenderer.drawStringWithShadow(text, hotbarRightX, hotbarY + 6, 0xFFFFFF);
    }
}
