package client.module.impl.render;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.player.PlayerUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import client.utils.render.ClientFontRenderer;

public class Health extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public Health() {
        super("Health", Category.RENDER);
        setDescription("Displays your health in the center of your screen");
        handles(HandlerType.GUI_RENDER);
    }

    @Override
    public void onGUIRender() {
        if (mc.player == null)
            return;
        float health = PlayerUtils.getTotalHealth();
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        String text = String.format("%.1f", health);
        int centerX = sr.getScaledWidth() / 2;
        int y = sr.getScaledHeight() / 2 + 15;
        int color;
        if (health > 10.0f) {
            color = 0x00FF00;
        } else if (health > 6.0f) {
            color = 0xFFFF00;
        } else {
            color = 0xFF0000;
        }
        ClientFontRenderer.drawCenteredStringWithShadow(text, centerX, y, color);
    }
}
