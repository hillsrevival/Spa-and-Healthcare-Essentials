package client.module.impl.render;

import client.event.events.RenderFirstPersonItemEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.ModeSetting;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemStack;

public class Animations extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Mode", "Smooth", "Vanilla", "Smooth", "Exhilarated", "Push", "Spin");

    private final NumberSetting speed = new NumberSetting("Speed", 1.0, 0.5, 3.0);

    private final BooleanSetting onlySword = new BooleanSetting("Only Sword", true);

    public Animations() {
        super("Animations", Category.RENDER);
        setDescription("Custom animations");
        addSetting(mode);
        addSetting(speed);
        addSetting(onlySword);
        handles(HandlerType.RENDER_FIRST_PERSON_ITEM);
    }

    @Override
    public void onRenderFirstPersonItem(RenderFirstPersonItemEvent event) {
        if (mc.player == null)
            return;
        if (!event.isPre())
            return;
        float swingProgress = mc.player.swingProgress;
        if (swingProgress <= 0.0f || swingProgress >= 1.0f)
            return;
        if (onlySword.getValue()) {
            ItemStack held = mc.player.getHeldItemMainhand();
            if (held == null || held.func_190926_b() || !(held.getItem() instanceof ItemSword)) {
                return;
            }
        }
        String m = mode.getValue();
        if (m.equals("Vanilla"))
            return;
        float speedMult = speed.getValue().floatValue();
        switch(m) {
            case "Smooth":
                mc.player.swingProgress = Math.max(0.0f, swingProgress - 0.15f / speedMult);
                break;
            case "Exhilarated":
                mc.player.swingProgress = Math.min(1.0f, swingProgress + 0.1f * speedMult);
                break;
            case "Push":
                if (swingProgress > 0.2f && swingProgress < 0.8f) {
                    float center = 0.5f;
                    float dist = Math.abs(swingProgress - center);
                    float sharpened = swingProgress + (0.5f - dist) * 0.3f * speedMult;
                    mc.player.swingProgress = Math.max(0.0f, Math.min(1.0f, sharpened));
                }
                break;
            case "Spin":
                float bounce = (float) Math.sin(swingProgress * Math.PI * 2 * speedMult) * 0.1f;
                mc.player.swingProgress = Math.max(0.0f, Math.min(1.0f, swingProgress + bounce));
                break;
        }
    }
}
