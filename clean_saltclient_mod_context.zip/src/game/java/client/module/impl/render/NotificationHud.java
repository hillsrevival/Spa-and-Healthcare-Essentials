package client.module.impl.render;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.NotificationSystem;

public class NotificationHud extends Module {

    public NotificationHud() {
        super("Notifications", Category.RENDER);
        setDescription("Shows popup notifications on screen");
        handles(HandlerType.GUI_RENDER);
    }

    @Override
    public void onGUIRender() {
        NotificationSystem.render();
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        NotificationSystem.clear();
    }
}
