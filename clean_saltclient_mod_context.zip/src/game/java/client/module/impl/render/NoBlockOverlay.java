package client.module.impl.render;

import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.RayTraceResult;

public class NoBlockOverlay extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private RayTraceResult.Type savedType = null;

    public NoBlockOverlay() {
        super("NoBlockOverlay", Category.RENDER);
        setDescription("Removes dark overlay when inside a block");
        handles(HandlerType.RENDER, HandlerType.POST_UPDATE);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == RayTraceResult.Type.BLOCK) {
            savedType = mc.objectMouseOver.typeOfHit;
            mc.objectMouseOver.typeOfHit = RayTraceResult.Type.MISS;
        }
    }

    @Override
    public void onPostUpdate() {
        if (savedType != null && mc.objectMouseOver != null) {
            mc.objectMouseOver.typeOfHit = savedType;
            savedType = null;
        }
    }
}
