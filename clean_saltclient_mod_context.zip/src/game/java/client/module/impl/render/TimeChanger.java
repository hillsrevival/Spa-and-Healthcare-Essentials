package client.module.impl.render;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;

public class TimeChanger extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting time = new NumberSetting("Time", 6000.0, 0.0, 24000.0);

    public TimeChanger() {
        super("TimeChanger", Category.RENDER);
        setDescription("Changes client-side time of day");
        addSetting(time);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.world == null)
            return;
        long t = time.getValue().longValue();
        mc.world.setWorldTime(t);
    }
}
