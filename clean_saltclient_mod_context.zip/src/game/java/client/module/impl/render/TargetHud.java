package client.module.impl.render;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.EntityUtils;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;

public class TargetHud extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final HudElement pos = new HudElement(this, -1, -1);

    private final NumberSetting range = new NumberSetting("Range", 6.0, 1.0, 12.0);

    private EntityLivingBase target = null;

    public TargetHud() {
        super("TargetHUD", Category.RENDER);
        setDescription("Shows the nearest player's name, health, and distance");
        addSetting(range);
        handles(HandlerType.UPDATE, HandlerType.GUI_RENDER);
        pos.addSettings();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) {
            target = null;
            return;
        }
        double maxRange = range.getValue();
        target = null;
        double closest = maxRange * maxRange;
        for (EntityPlayer player : EntityUtils.getLoadedPlayers()) {
            if (player == mc.player)
                continue;
            if (player.isDead || player.getHealth() <= 0)
                continue;
            double dist = mc.player.getDistanceToEntity(player);
            if (dist <= maxRange && dist * dist < closest) {
                closest = dist * dist;
                target = player;
            }
        }
    }

    @Override
    public void onGUIRender() {
        if (target == null)
            return;
        if (!pos.shouldRender())
            return;
        String name = target.getName();
        float health = target.getHealth();
        float maxHealth = target.getMaxHealth();
        float hpPercent = Math.max(0.0f, Math.min(1.0f, health / maxHealth));
        double dist = mc.player.getDistanceToEntity(target);
        int boxW = 140;
        int boxH = 42;
        pos.updateDrag(boxW, boxH);
        int x = pos.getX();
        int y = pos.getY();
        RenderUtils.prepareHUD();
        RenderUtils.drawRoundedRect2D(x - 2, y - 2, x + boxW + 2, y + boxH + 2, 11, 0x08FFFFFF);
        RenderUtils.drawRoundedRect2D(x, y, x + boxW, y + boxH, 9, (int) (0.7f * 255) << 24 | 0x00262638);
        RenderUtils.restoreHUD();
        ClientFontRenderer.drawStringWithShadow(name, x + 4, y + 3, 0xFFAAAAAA);
        String hpText = String.format("%.1f / %.0f HP", health, maxHealth);
        ClientFontRenderer.drawStringWithShadow(hpText, x + 4, y + 15, 0xFFAAAAAA);
        int barX = x + 4;
        int barY = y + 28;
        int barW = boxW - 8;
        int barH = 6;
        RenderUtils.prepareHUD();
        RenderUtils.drawRoundedRect2D(barX, barY, barX + barW, barY + barH, 3, 0xCC1A1A1A);
        float fillW = barW * hpPercent;
        float r, g;
        if (hpPercent > 0.5f) {
            r = 2.0f * (1.0f - hpPercent);
            g = 1.0f;
        } else {
            r = 1.0f;
            g = 2.0f * hpPercent;
        }
        int fillArgb = (0xE0 << 24) | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | 0x00;
        RenderUtils.drawRoundedRect2D(barX, barY, barX + fillW, barY + barH, 3, fillArgb);
        RenderUtils.restoreHUD();
        String distText = String.format("%.1fm", dist);
        ClientFontRenderer.drawRightAlignedStringWithShadow(distText, x + boxW - 4, y + 3, 0xFFAAAAAA);
        pos.renderDragBox(x, y, boxW, boxH);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        target = null;
    }
}
