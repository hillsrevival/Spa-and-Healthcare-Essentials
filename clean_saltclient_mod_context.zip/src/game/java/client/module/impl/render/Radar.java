package client.module.impl.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.EntityUtils;

public class Radar extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting radarSize = new NumberSetting("Size", 100.0, 50.0, 200.0);

    private final NumberSetting radarRange = new NumberSetting("Range", 50.0, 10.0, 150.0);

    private final BooleanSetting background = new BooleanSetting("Background", true);

    private final HudElement pos = new HudElement(this, -1, -1);

    public Radar() {
        super("Radar", Category.RENDER);
        setDescription("2D minimap with nearby entities");
        addSetting(radarSize);
        addSetting(radarRange);
        addSetting(background);
        handles(HandlerType.GUI_RENDER);
        pos.addSettings();
    }

    @Override
    public void onGUIRender() {
        if (!pos.shouldRender())
            return;
        if (!nullCheck())
            return;
        int size = (int) radarSize.getValue().doubleValue();
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        pos.updateDrag(size, size);
        int radarX = pos.getX();
        int radarY = pos.getY();
        float halfSize = size / 2.0f;
        float scale = halfSize / (float) radarRange.getValue().doubleValue();
        RenderUtils.prepareHUD();
        if (background.getValue()) {
            RenderUtils.drawRoundedRect2D(radarX, radarY, radarX + size, radarY + size, 8, 0x80000000);
        }
        EaglercraftGPU.glLineWidth(2.0f);
        RenderUtils.enableLineSmooth();
        Tessellator tessellator = Tessellator.getInstance();
        tessellator.getWorldRenderer().begin(Tessellator.GL_LINE_LOOP, DefaultVertexFormats.POSITION_COLOR);
        tessellator.getWorldRenderer().pos(radarX, radarY, 0).color(1, 1, 1, 0.5f).endVertex();
        tessellator.getWorldRenderer().pos(radarX + size, radarY, 0).color(1, 1, 1, 0.5f).endVertex();
        tessellator.getWorldRenderer().pos(radarX + size, radarY + size, 0).color(1, 1, 1, 0.5f).endVertex();
        tessellator.getWorldRenderer().pos(radarX, radarY + size, 0).color(1, 1, 1, 0.5f).endVertex();
        tessellator.draw();
        EaglercraftGPU.glLineWidth(1.0f);
        tessellator.getWorldRenderer().begin(Tessellator.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        tessellator.getWorldRenderer().pos(radarX + halfSize, radarY, 0).color(1, 1, 1, 0.15f).endVertex();
        tessellator.getWorldRenderer().pos(radarX + halfSize, radarY + size, 0).color(1, 1, 1, 0.15f).endVertex();
        tessellator.getWorldRenderer().pos(radarX, radarY + halfSize, 0).color(1, 1, 1, 0.15f).endVertex();
        tessellator.getWorldRenderer().pos(radarX + size, radarY + halfSize, 0).color(1, 1, 1, 0.15f).endVertex();
        tessellator.draw();
        RenderUtils.disableLineSmooth();
        float yaw = mc.player.rotationYaw * 0.017453292f;
        GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (entity == mc.player)
                continue;
            if (!(entity instanceof EntityPlayer))
                continue;
            double diffX = entity.posX - mc.player.posX;
            double diffZ = entity.posZ - mc.player.posZ;
            float relX = (float) (diffX * Math.cos(yaw) - diffZ * Math.sin(yaw)) * scale;
            float relZ = (float) (diffX * Math.sin(yaw) + diffZ * Math.cos(yaw)) * scale;
            float dotX = radarX + halfSize + relX;
            float dotY = radarY + halfSize + relZ;
            dotX = Math.max(radarX + 3, Math.min(radarX + size - 3, dotX));
            dotY = Math.max(radarY + 3, Math.min(radarY + size - 3, dotY));
            float dotSize = 2.0f;
            tessellator.getWorldRenderer().begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
            tessellator.getWorldRenderer().pos(dotX - dotSize, dotY - dotSize, 0).color(1, 0.2f, 0.2f, 1).endVertex();
            tessellator.getWorldRenderer().pos(dotX + dotSize, dotY - dotSize, 0).color(1, 0.2f, 0.2f, 1).endVertex();
            tessellator.getWorldRenderer().pos(dotX + dotSize, dotY + dotSize, 0).color(1, 0.2f, 0.2f, 1).endVertex();
            tessellator.getWorldRenderer().pos(dotX - dotSize, dotY + dotSize, 0).color(1, 0.2f, 0.2f, 1).endVertex();
            tessellator.draw();
        }
        float pDotSize = 3.0f;
        tessellator.getWorldRenderer().begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        tessellator.getWorldRenderer().pos(radarX + halfSize - pDotSize, radarY + halfSize - pDotSize, 0).color(1, 1, 1, 1).endVertex();
        tessellator.getWorldRenderer().pos(radarX + halfSize + pDotSize, radarY + halfSize - pDotSize, 0).color(1, 1, 1, 1).endVertex();
        tessellator.getWorldRenderer().pos(radarX + halfSize + pDotSize, radarY + halfSize + pDotSize, 0).color(1, 1, 1, 1).endVertex();
        tessellator.getWorldRenderer().pos(radarX + halfSize - pDotSize, radarY + halfSize + pDotSize, 0).color(1, 1, 1, 1).endVertex();
        tessellator.draw();
        pos.renderDragBox(radarX, radarY, size, size);
        RenderUtils.restoreHUD();
    }
}
