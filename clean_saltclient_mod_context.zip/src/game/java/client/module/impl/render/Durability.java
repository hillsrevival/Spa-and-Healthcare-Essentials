package client.module.impl.render;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.render.HudElement;
import client.utils.render.ClientFontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextFormatting;

public class Durability extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final HudElement pos = new HudElement(this, -1, -1);

    public Durability() {
        super("Durability", Category.RENDER);
        setDescription("Shows item durability on the HUD");
        pos.addSettings();
        handles(HandlerType.GUI_RENDER);
    }

    @Override
    public void onGUIRender() {
        if (mc.player == null)
            return;
        if (!pos.shouldRender())
            return;
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        pos.updateDrag(100, 60);
        int startX, startY;
        if (!pos.isDefaultX()) {
            startX = pos.getX();
        } else {
            startX = -1;
        }
        if (!pos.isDefaultY()) {
            startY = pos.getY();
        } else {
            startY = sr.getScaledHeight() / 2 - 10;
        }
        int y = startY;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (stack.func_190926_b() || !stack.isItemStackDamageable())
                continue;
            int maxDmg = stack.getMaxDamage();
            int dmg = maxDmg - stack.getItemDamage();
            float percent = (float) dmg / maxDmg;
            if (percent >= 1.0f)
                continue;
            String color;
            if (percent > 0.5f) {
                color = TextFormatting.GREEN.toString();
            } else if (percent > 0.25f) {
                color = TextFormatting.YELLOW.toString();
            } else {
                color = TextFormatting.RED.toString();
            }
            String text = color + "" + dmg + "/" + maxDmg;
            if (startX != -1) {
                ClientFontRenderer.drawStringWithShadow(text, startX, y, 0xFFFFFF);
            } else {
                ClientFontRenderer.drawCenteredStringWithShadow(text, sr.getScaledWidth() / 2, y, 0xFFFFFF);
            }
            y += 10;
        }
        pos.renderDragBox(startX != -1 ? startX : (sr.getScaledWidth() - 100) / 2, startY, 100, y - startY);
    }
}
