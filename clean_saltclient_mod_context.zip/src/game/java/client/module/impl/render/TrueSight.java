package client.module.impl.render;

import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.utils.render.RenderUtils;
import client.utils.EntityUtils;

public class TrueSight extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting showPlayers = new BooleanSetting("Players", true);

    private final BooleanSetting showMobs = new BooleanSetting("Mobs", true);

    private final BooleanSetting showItems = new BooleanSetting("Items", true);

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    public TrueSight() {
        super("TrueSight", Category.RENDER);
        setDescription("Makes invisible entities and items visible");
        addSetting(showPlayers);
        addSetting(showMobs);
        addSetting(showItems);
        addSetting(lineWidth);
        handles(HandlerType.RENDER);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        float partialTicks = event.getPartialTicks();
        RenderUtils.updateCameraPos(partialTicks);
        RenderUtils.prepareGL();
        net.lax1dude.eaglercraft.opengl.EaglercraftGPU.glLineWidth(lineWidth.getValue().floatValue());
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (entity == mc.player)
                continue;
            if (!entity.isInvisible())
                continue;
            if (entity instanceof EntityPlayer) {
                if (!showPlayers.getValue())
                    continue;
            } else if (entity instanceof net.minecraft.entity.item.EntityItem) {
                if (!showItems.getValue())
                    continue;
            } else if (entity instanceof net.minecraft.entity.item.EntityXPOrb) {
                continue;
            } else {
                if (!showMobs.getValue())
                    continue;
            }
            double x = entity.prevPosX + (entity.posX - entity.prevPosX) * partialTicks - RenderUtils.camX;
            double y = entity.prevPosY + (entity.posY - entity.prevPosY) * partialTicks - RenderUtils.camY;
            double z = entity.prevPosZ + (entity.posZ - entity.prevPosZ) * partialTicks - RenderUtils.camZ;
            double hw = entity.width / 2.0;
            AxisAlignedBB box = new AxisAlignedBB(x - hw, y + 0.05, z - hw, x + hw, y + entity.height, z + hw);
            RenderUtils.drawSolidBox(box, 0.5f, 0.0f, 0.8f, 0.25f);
            RenderUtils.drawOutlinedBox(box, 0.8f, 0.2f, 1.0f, 0.8f);
        }
        RenderUtils.restoreGL();
    }
}
