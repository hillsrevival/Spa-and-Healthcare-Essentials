package client.module.impl.render;

import java.util.HashSet;
import java.util.Set;
import client.event.listeners.RenderListener;
import client.module.BlockListSetting;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.render.BlockEspUtils;
import client.utils.render.RenderUtils;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;

public class BlockESP extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private static final String[] DEFAULT_ORES = { "minecraft:coal_ore", "minecraft:iron_ore", "minecraft:gold_ore", "minecraft:diamond_ore", "minecraft:emerald_ore", "minecraft:lapis_ore", "minecraft:redstone_ore", "minecraft:lit_redstone_ore", "minecraft:quartz_ore" };

    private final BlockListSetting blocks = new BlockListSetting("Blocks", DEFAULT_ORES);

    private final NumberSetting range = new NumberSetting("Range", 3.0, 1.0, 6.0);

    private final BooleanSetting tracers = new BooleanSetting("Tracers", false);

    private final ModeSetting tracerColor = new ModeSetting("Tracer Color", "Default", "Default", "Rainbow", "Red", "Green", "Blue", "Yellow", "Purple", "White");

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    private final Set<Block> selectedBlocks = new HashSet<Block>();

    private String[] lastSelectionSnapshot = null;

    private final BlockEspUtils.BlockScanner scanner = new BlockEspUtils.BlockScanner();

    private final BlockEspUtils.Matcher matcher = new BlockEspUtils.Matcher() {

        @Override
        public int match(IBlockState state, int x, int y, int z) {
            return selectedBlocks.contains(state.getBlock()) ? 1 : 0;
        }
    };

    private final BlockEspUtils.ColorFn boxColor = new BlockEspUtils.ColorFn() {

        @Override
        public void colorOf(int index, int tag, float[] out3) {
            out3[0] = 0.0f;
            out3[1] = 0.75f;
            out3[2] = 1.0f;
        }
    };

    private final BlockEspUtils.ColorFn tracerColorFn = new BlockEspUtils.ColorFn() {

        @Override
        public void colorOf(int index, int tag, float[] out3) {
            float[] c = RenderUtils.resolveTracerColor(tracerColor.getValue(), null, index);
            if (c != null) {
                out3[0] = c[0];
                out3[1] = c[1];
                out3[2] = c[2];
            } else {
                out3[0] = 0.0f;
                out3[1] = 0.75f;
                out3[2] = 1.0f;
            }
        }
    };

    public BlockESP() {
        super("BlockESP", Category.RENDER);
        setDescription("Highlights specific blocks through walls");
        addSetting(blocks);
        addSetting(range);
        addSetting(tracers);
        addSetting(tracerColor);
        addSetting(lineWidth);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
        scanner.setChunksPerTick(4);
        scanner.setRescanIntervalTicks(60);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        scanner.clear();
        refreshSelectedBlocks();
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (selectedBlocks.isEmpty())
            return;
        int chunkRange = range.getValue().intValue();
        scanner.update(mc.player.chunkCoordX, mc.player.chunkCoordZ, chunkRange, 0, 255, matcher);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (scanner.size() == 0)
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        BlockEspUtils.drawScannerBoxes(scanner, boxColor, 0.3f, 0.6f, lineWidth.getValue().floatValue());
        if (tracers.getValue()) {
            BlockEspUtils.drawScannerTracers(scanner, tracerColorFn, 0.5f, lineWidth.getValue().floatValue());
        }
    }

    private void refreshSelectedBlocks() {
        String[] current = blocks.getValue();
        if (current == lastSelectionSnapshot) {
            return;
        }
        boolean same = current != null && lastSelectionSnapshot != null && current.length == lastSelectionSnapshot.length;
        if (same) {
            for (int i = 0; i < current.length; i++) {
                if (!current[i].equals(lastSelectionSnapshot[i])) {
                    same = false;
                    break;
                }
            }
        }
        if (same) {
            lastSelectionSnapshot = current;
            return;
        }
        selectedBlocks.clear();
        if (current != null) {
            for (String id : current) {
                Block block = BlockListSetting.lookupBlock(id);
                if (block != null) {
                    selectedBlocks.add(block);
                }
            }
        }
        lastSelectionSnapshot = current;
        scanner.clear();
    }

    public String getDescription() {
        if (!isToggled())
            return "";
        String name = getName() + " [";
        int total = scanner.size();
        if (total == 0)
            name += "scanning...";
        else if (total == 1)
            name += "1 block";
        else
            name += total + " blocks";
        name += "]";
        return name;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        scanner.clear();
    }
}
