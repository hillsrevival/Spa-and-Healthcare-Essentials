package client.module.impl.render;

import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;
import client.utils.render.RenderUtils;

public class LightOverlay extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 8.0, 4.0, 16.0);

    public LightOverlay() {
        super("LightOverlay", Category.RENDER);
        setDescription("Shows light levels to find mob spawn spots");
        addSetting(range);
        handles(HandlerType.RENDER);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        double px = mc.getRenderManager().viewerPosX;
        double py = mc.getRenderManager().viewerPosY;
        double pz = mc.getRenderManager().viewerPosZ;
        int rangeI = range.getValue().intValue();
        int startX = (int) Math.floor(px) - rangeI;
        int startZ = (int) Math.floor(pz) - rangeI;
        int endX = (int) Math.floor(px) + rangeI;
        int endZ = (int) Math.floor(pz) + rangeI;
        int y = (int) Math.floor(py);
        RenderUtils.prepareGL();
        net.minecraft.client.renderer.Tessellator tess = net.minecraft.client.renderer.Tessellator.getInstance();
        net.lax1dude.eaglercraft.opengl.WorldRenderer buf = tess.getBuffer();
        double by = y - py + 0.005;
        net.lax1dude.eaglercraft.opengl.GlStateManager.color(1.0f, 0.0f, 0.0f, 0.25f);
        buf.begin(net.lax1dude.eaglercraft.opengl.RealOpenGLEnums.GL_QUADS, net.minecraft.client.renderer.vertex.DefaultVertexFormats.POSITION);
        for (int x = startX; x <= endX; x++) {
            for (int z = startZ; z <= endZ; z++) {
                int light = mc.world.getLight(new BlockPos(x, y, z));
                if (light >= 4)
                    continue;
                double bx = x - px;
                double bz = z - pz;
                buf.pos(bx, by, bz).endVertex();
                buf.pos(bx + 1, by, bz).endVertex();
                buf.pos(bx + 1, by, bz + 1).endVertex();
                buf.pos(bx, by, bz + 1).endVertex();
            }
        }
        tess.draw();
        net.lax1dude.eaglercraft.opengl.GlStateManager.color(1.0f, 0.5f, 0.0f, 0.15f);
        buf.begin(net.lax1dude.eaglercraft.opengl.RealOpenGLEnums.GL_QUADS, net.minecraft.client.renderer.vertex.DefaultVertexFormats.POSITION);
        for (int x = startX; x <= endX; x++) {
            for (int z = startZ; z <= endZ; z++) {
                int light = mc.world.getLight(new BlockPos(x, y, z));
                if (light < 4 || light >= 7)
                    continue;
                double bx = x - px;
                double bz = z - pz;
                buf.pos(bx, by, bz).endVertex();
                buf.pos(bx + 1, by, bz).endVertex();
                buf.pos(bx + 1, by, bz + 1).endVertex();
                buf.pos(bx, by, bz + 1).endVertex();
            }
        }
        tess.draw();
        RenderUtils.restoreGL();
    }
}
