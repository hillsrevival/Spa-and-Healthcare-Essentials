package client.module.impl.render;

import client.module.NumberSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.Entity;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.ColorSetting;
import client.utils.render.EntityEspUtils;
import client.utils.render.RenderUtils;
import client.utils.EntityUtils;

public class ItemESP extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting tracers = new BooleanSetting("Tracers", false);

    private final ModeSetting tracerColor = new ModeSetting("Tracer Color", "Default", "Default", "Red", "Green", "Blue", "Yellow", "Purple", "Pink", "Orange", "White", "Cyan", "Rainbow");

    private final ColorSetting customColor = new ColorSetting("Custom Color", 0.0);

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    private final List<EntityItem> items = new ArrayList<EntityItem>();

    private final EntityEspUtils.EntityColorFn boxColor = new EntityEspUtils.EntityColorFn() {

        @Override
        public void colorOf(Entity entity, int index, float[] out3) {
            out3[0] = 1.0f;
            out3[1] = 1.0f;
            out3[2] = 0.0f;
        }
    };

    private final EntityEspUtils.EntityColorFn tracerColorFn = new EntityEspUtils.EntityColorFn() {

        @Override
        public void colorOf(Entity entity, int index, float[] out3) {
            float[] c = RenderUtils.resolveTracerColor(tracerColor.getValue(), customColor.getRGBFloat(), index);
            if (c != null) {
                out3[0] = c[0];
                out3[1] = c[1];
                out3[2] = c[2];
            } else {
                out3[0] = 1.0f;
                out3[1] = 1.0f;
                out3[2] = 0.0f;
            }
        }
    };

    private final EntityEspUtils.EntityBoxAdjuster itemBox = new EntityEspUtils.EntityBoxAdjuster() {

        @Override
        public void adjust(Entity entity, double[] box6) {
            double cx = (box6[0] + box6[3]) * 0.5;
            double cz = (box6[2] + box6[5]) * 0.5;
            box6[0] = cx - 0.175;
            box6[3] = cx + 0.175;
            box6[2] = cz - 0.175;
            box6[5] = cz + 0.175;
            box6[4] = box6[1] + 0.35;
        }
    };

    public ItemESP() {
        super("ItemESP", Category.RENDER);
        setDescription("Highlights dropped items on the ground through walls");
        addSetting(tracers);
        addSetting(tracerColor);
        addSetting(customColor);
        addSetting(lineWidth);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        items.clear();
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (entity instanceof EntityItem) {
                items.add((EntityItem) entity);
            }
        }
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (items.isEmpty())
            return;
        float partialTicks = event.getPartialTicks();
        RenderUtils.updateCameraPos(partialTicks);
        EntityEspUtils.drawEntityBoxes(items, partialTicks, boxColor, 0.2f, 0.5f, 0.0, itemBox, lineWidth.getValue().floatValue());
        if (tracers.getValue()) {
            EntityEspUtils.drawEntityTracers(items, partialTicks, tracerColorFn, 0.5f, 0.7, lineWidth.getValue().floatValue());
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        items.clear();
    }
}
