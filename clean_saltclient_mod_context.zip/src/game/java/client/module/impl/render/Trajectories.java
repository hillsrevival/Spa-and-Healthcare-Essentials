package client.module.impl.render;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import client.utils.world.WorldUtils;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import client.utils.render.RenderUtils;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;

public class Trajectories extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting bow = new BooleanSetting("Bow", true);

    private final BooleanSetting throwable = new BooleanSetting("Throwable", true);

    private final NumberSetting steps = new NumberSetting("Steps", 100.0, 20.0, 200.0);

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    public Trajectories() {
        super("Trajectories", Category.RENDER);
        setDescription("Shows predicted trajectory of thrown items");
        addSetting(bow);
        addSetting(throwable);
        addSetting(steps);
        addSetting(lineWidth);
        handles(HandlerType.RENDER);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        ItemStack heldItem = mc.player.getHeldItemMainhand();
        if (heldItem == null || heldItem.func_190926_b())
            return;
        boolean isBow = heldItem.getItem() == Items.BOW;
        boolean isThrowable = isThrowableItem(heldItem);
        if (isBow && !bow.getValue())
            return;
        if (isThrowable && !throwable.getValue())
            return;
        if (!isBow && !isThrowable)
            return;
        Vec3d pos = new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ);
        float yaw = mc.player.rotationYaw;
        float pitch = mc.player.rotationPitch;
        float motionFactor;
        float gravity;
        if (isBow) {
            int useDuration = mc.player.getItemInUseMaxCount();
            float charge = Math.min(useDuration / 20.0f, 1.0f);
            motionFactor = charge * 3.0f;
            gravity = 0.05f;
        } else {
            motionFactor = 1.5f;
            gravity = 0.03f;
        }
        float yawRad = (float) Math.toRadians(yaw);
        float pitchRad = (float) Math.toRadians(pitch);
        double motionX = -Math.sin(yawRad) * Math.cos(pitchRad) * motionFactor;
        double motionY = -Math.sin(pitchRad) * motionFactor;
        double motionZ = Math.cos(yawRad) * Math.cos(pitchRad) * motionFactor;
        if (isBow) {
            motionX += mc.player.motionX * 0.5;
            motionY += mc.player.motionY * 0.5;
            motionZ += mc.player.motionZ * 0.5;
        }
        RenderUtils.updateCameraPos(event.getPartialTicks());
        RenderUtils.prepareGL();
        EaglercraftGPU.glLineWidth(lineWidth.getValue().floatValue());
        int maxSteps = steps.getValue().intValue();
        double posX = pos.xCoord;
        double posY = pos.yCoord;
        double posZ = pos.zCoord;
        double prevX = posX;
        double prevY = posY;
        double prevZ = posZ;
        for (int i = 0; i < maxSteps; i++) {
            prevX = posX;
            prevY = posY;
            prevZ = posZ;
            posX += motionX;
            posY += motionY;
            posZ += motionZ;
            motionY -= gravity;
            if (!isBow) {
                motionX *= 0.99;
                motionY *= 0.99;
                motionZ *= 0.99;
            }
            if (WorldUtils.getState(new net.minecraft.util.math.BlockPos(Math.floor(posX), Math.floor(posY), Math.floor(posZ))).isFullBlock()) {
                drawTrajectorySegment(prevX, prevY, prevZ, posX, posY, posZ, event.getPartialTicks());
                break;
            }
            drawTrajectorySegment(prevX, prevY, prevZ, posX, posY, posZ, event.getPartialTicks());
        }
        RenderUtils.restoreGL();
    }

    private void drawTrajectorySegment(double x1, double y1, double z1, double x2, double y2, double z2, float partialTicks) {
        double dx1 = x1 - RenderUtils.camX;
        double dy1 = y1 - RenderUtils.camY;
        double dz1 = z1 - RenderUtils.camZ;
        double dx2 = x2 - RenderUtils.camX;
        double dy2 = y2 - RenderUtils.camY;
        double dz2 = z2 - RenderUtils.camZ;
        RenderUtils.drawLine(dx1, dy1, dz1, dx2, dy2, dz2, 1.0f, 1.0f, 1.0f, 0.5f);
    }

    private boolean isThrowableItem(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return false;
        net.minecraft.item.Item item = stack.getItem();
        return item == Items.SNOWBALL || item == Items.EGG || item == Items.ENDER_PEARL || item == Items.EXPERIENCE_BOTTLE || item == Items.FIRE_CHARGE || item == Items.SPLASH_POTION || item == Items.LINGERING_POTION || item == Items.FISHING_ROD;
    }
}
