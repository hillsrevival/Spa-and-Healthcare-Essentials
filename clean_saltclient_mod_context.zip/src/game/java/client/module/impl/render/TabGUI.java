package client.module.impl.render;

import java.util.ArrayList;
import java.util.List;
import net.lax1dude.eaglercraft.Keyboard;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModuleManager;
import client.module.impl.fun.ColorUi;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;

public class TabGUI extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private static final int KEY_UP = 0xC8;

    private static final int KEY_DOWN = 0xD0;

    private static final int KEY_LEFT = 0xCB;

    private static final int KEY_RIGHT = 0xCD;

    private static final int KEY_RETURN = 0x1C;

    private static final int LINE_HEIGHT = 12;

    private static final int X_OFFSET = 4;

    private static final int Y_OFFSET = 12;

    private static final int PADDING = 4;

    private static final int BG_ALPHA = 160;

    private int selectedTab = 0;

    private int selectedModule = 0;

    private boolean categoryExpanded = false;

    private boolean heldUp;

    private boolean heldDown;

    private boolean heldLeft;

    private boolean heldRight;

    private boolean heldReturn;

    private final List<List<Module>> categoryModules = new ArrayList<>();

    private int accentColor = 0xFF00AAFF;

    private final HudElement pos = new HudElement(this, -1, -1);

    public TabGUI() {
        super("TabGUI", Category.RENDER);
        setDescription("Compact module list using tab key navigation");
        pos.addSettings();
        handles(HandlerType.TICK, HandlerType.GUI_RENDER);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        rebuildCategoryCache();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        categoryExpanded = false;
        selectedModule = 0;
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null) {
            heldUp = heldDown = heldLeft = heldRight = heldReturn = false;
            return;
        }
        if (!Keyboard.isKeyDown(KEY_UP))
            heldUp = false;
        if (!Keyboard.isKeyDown(KEY_DOWN))
            heldDown = false;
        if (!Keyboard.isKeyDown(KEY_LEFT))
            heldLeft = false;
        if (!Keyboard.isKeyDown(KEY_RIGHT))
            heldRight = false;
        if (!Keyboard.isKeyDown(KEY_RETURN))
            heldReturn = false;
        if (categoryExpanded) {
            List<Module> mods = categoryModules.get(selectedTab);
            if (mods.isEmpty()) {
                categoryExpanded = false;
                return;
            }
            if (Keyboard.isKeyDown(KEY_DOWN) && !heldDown) {
                heldDown = true;
                selectedModule = (selectedModule + 1) % mods.size();
            }
            if (Keyboard.isKeyDown(KEY_UP) && !heldUp) {
                heldUp = true;
                selectedModule = (selectedModule - 1 + mods.size()) % mods.size();
            }
            if (Keyboard.isKeyDown(KEY_RETURN) && !heldReturn) {
                heldReturn = true;
                mods.get(selectedModule).toggle();
            }
            if (Keyboard.isKeyDown(KEY_LEFT) && !heldLeft) {
                heldLeft = true;
                categoryExpanded = false;
            }
        } else {
            int catCount = Category.values().length;
            if (Keyboard.isKeyDown(KEY_DOWN) && !heldDown) {
                heldDown = true;
                selectedTab = (selectedTab + 1) % catCount;
                selectedModule = 0;
            }
            if (Keyboard.isKeyDown(KEY_UP) && !heldUp) {
                heldUp = true;
                selectedTab = (selectedTab - 1 + catCount) % catCount;
                selectedModule = 0;
            }
            if (Keyboard.isKeyDown(KEY_RIGHT) && !heldRight) {
                heldRight = true;
                rebuildCategoryCache();
                if (!categoryModules.get(selectedTab).isEmpty()) {
                    categoryExpanded = true;
                }
            }
        }
    }

    @Override
    public void onGUIRender() {
        if (!pos.shouldRender())
            return;
        if (!nullCheck())
            return;
        rebuildCategoryCache();
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        int tabWidth = 0;
        for (Category cat : Category.values()) {
            int w = ClientFontRenderer.getStringWidth(cat.name()) + PADDING * 2 + 6;
            if (w > tabWidth)
                tabWidth = w;
        }
        int tabHeight = Category.values().length * LINE_HEIGHT;
        int totalW = tabWidth;
        int totalH = tabHeight;
        pos.updateDrag(totalW, totalH);
        int baseX = pos.getX();
        int baseY = pos.getY();
        updateAccentColor();
        Category[] cats = Category.values();
        drawBox(baseX, baseY, baseX + tabWidth, baseY + tabHeight);
        pos.renderDragBox(baseX, baseY, tabWidth, tabHeight);
        for (int i = 0; i < cats.length; i++) {
            int textY = baseY + i * LINE_HEIGHT;
            String label = cats[i].name();
            if (i == selectedTab) {
                label = (categoryExpanded ? "\u00AB " : "\u00BB ") + label;
            } else {
                label = "  " + label;
            }
            int textX = baseX + PADDING + 4;
            if (i == selectedTab) {
                Gui.drawRect(baseX, textY, baseX + tabWidth, textY + LINE_HEIGHT, accentColor | 0x33000000);
            }
            ClientFontRenderer.drawStringWithShadow(label, textX, textY + 2, 0xFFFFFF);
        }
        if (categoryExpanded && selectedTab < categoryModules.size()) {
            List<Module> mods = categoryModules.get(selectedTab);
            if (mods.isEmpty()) {
                categoryExpanded = false;
                return;
            }
            int listX = baseX + tabWidth + 3;
            int listWidth = 0;
            for (Module m : mods) {
                String name = m.getName();
                if (m.isToggled())
                    name = "\u00A7a" + name;
                int w = ClientFontRenderer.getStringWidth("\u00BB " + name) + PADDING * 2 + 4;
                if (w > listWidth)
                    listWidth = w;
            }
            int listHeight = mods.size() * LINE_HEIGHT;
            if (listX + listWidth > sr.getScaledWidth()) {
                listX = sr.getScaledWidth() - listWidth - 2;
            }
            int maxH = sr.getScaledHeight() - baseY - 4;
            int drawH = Math.min(listHeight, maxH);
            drawBox(listX, baseY, listX + listWidth, baseY + drawH);
            int scrollOffset = 0;
            if (listHeight > maxH && selectedModule > 0) {
                int visibleItems = maxH / LINE_HEIGHT;
                scrollOffset = Math.max(0, Math.min(selectedModule - visibleItems / 2, mods.size() - visibleItems));
            }
            for (int i = scrollOffset; i < mods.size() && i < scrollOffset + maxH / LINE_HEIGHT; i++) {
                Module m = mods.get(i);
                int textY = baseY + (i - scrollOffset) * LINE_HEIGHT;
                if (i == selectedModule) {
                    Gui.drawRect(listX, textY, listX + listWidth, textY + LINE_HEIGHT, accentColor | 0x33000000);
                }
                String name = m.getName();
                if (m.isToggled()) {
                    name = "\u00A7a" + name;
                } else {
                    name = "\u00A7r" + name;
                }
                if (i == selectedModule) {
                    name = "\u00BB " + name;
                } else {
                    name = "  " + name;
                }
                ClientFontRenderer.drawStringWithShadow(name, listX + PADDING + 2, textY + 2, 0xFFFFFF);
            }
        }
    }

    private void rebuildCategoryCache() {
        categoryModules.clear();
        for (Category cat : Category.values()) {
            categoryModules.add(ModuleManager.getModulesByCategory(cat));
        }
    }

    private void updateAccentColor() {
        try {
            Module rb = ModuleManager.getModuleByName("ColorUi");
            if (rb != null && rb.isToggled()) {
                accentColor = ColorUi.getRainbowColor(255);
            }
        } catch (Exception ignored) {
        }
    }

    private void drawBox(int x1, int y1, int x2, int y2) {
        Gui.drawRect(x1, y1, x2, y2, (BG_ALPHA << 24));
        RenderUtils.prepareHUD();
        Tessellator tessellator = Tessellator.getInstance();
        float r = ((accentColor >> 16) & 0xFF) / 255.0f;
        float g = ((accentColor >> 8) & 0xFF) / 255.0f;
        float b = (accentColor & 0xFF) / 255.0f;
        float a = 0.7f;
        tessellator.getWorldRenderer().begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        tessellator.getWorldRenderer().pos(x1, y1, 0).color(r, g, b, a).endVertex();
        tessellator.getWorldRenderer().pos(x2, y1, 0).color(r, g, b, a).endVertex();
        tessellator.getWorldRenderer().pos(x2, y1 + 1, 0).color(r, g, b, a).endVertex();
        tessellator.getWorldRenderer().pos(x1, y1 + 1, 0).color(r, g, b, a).endVertex();
        tessellator.draw();
        tessellator.getWorldRenderer().begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        tessellator.getWorldRenderer().pos(x1, y2 - 1, 0).color(r, g, b, a).endVertex();
        tessellator.getWorldRenderer().pos(x2, y2 - 1, 0).color(r, g, b, a).endVertex();
        tessellator.getWorldRenderer().pos(x2, y2, 0).color(r, g, b, a).endVertex();
        tessellator.getWorldRenderer().pos(x1, y2, 0).color(r, g, b, a).endVertex();
        tessellator.draw();
        tessellator.getWorldRenderer().begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        tessellator.getWorldRenderer().pos(x1, y1, 0).color(r, g, b, a).endVertex();
        tessellator.getWorldRenderer().pos(x1 + 1, y1, 0).color(r, g, b, a).endVertex();
        tessellator.getWorldRenderer().pos(x1 + 1, y2, 0).color(r, g, b, a).endVertex();
        tessellator.getWorldRenderer().pos(x1, y2, 0).color(r, g, b, a).endVertex();
        tessellator.draw();
        tessellator.getWorldRenderer().begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        tessellator.getWorldRenderer().pos(x2 - 1, y1, 0).color(r, g, b, a).endVertex();
        tessellator.getWorldRenderer().pos(x2, y1, 0).color(r, g, b, a).endVertex();
        tessellator.getWorldRenderer().pos(x2, y2, 0).color(r, g, b, a).endVertex();
        tessellator.getWorldRenderer().pos(x2 - 1, y2, 0).color(r, g, b, a).endVertex();
        tessellator.draw();
        RenderUtils.restoreHUD();
    }
}
