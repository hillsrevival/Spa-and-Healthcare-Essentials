package client.module.impl.render;

import client.event.events.PotionEffectCheckEvent;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.client.Minecraft;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;

public class AntiDebuff extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public final BooleanSetting removeNausea = new BooleanSetting("Nausea", true);

    public final BooleanSetting removeBlindness = new BooleanSetting("Blindness", true);

    public final BooleanSetting removeSlownessVisual = new BooleanSetting("Slowness Visual", true);

    public final BooleanSetting removeEffects = new BooleanSetting("Remove Effects", false);

    public AntiDebuff() {
        super("AntiDebuff", Category.RENDER);
        setDescription("Removes negative visual potion effects with per-effect toggles");
        addSetting(removeNausea);
        addSetting(removeBlindness);
        addSetting(removeSlownessVisual);
        addSetting(removeEffects);
        handles(HandlerType.POTION_EFFECT_CHECK, HandlerType.UPDATE);
    }

    @Override
    public void onPotionEffectCheck(PotionEffectCheckEvent event) {
        if (mc.player == null)
            return;
        if (event.getEntity() != mc.player)
            return;
        if (removeNausea.getValue() && event.getPotion() == MobEffects.NAUSEA) {
            event.setResult(false);
        }
        if (removeBlindness.getValue() && event.getPotion() == MobEffects.BLINDNESS) {
            event.setResult(false);
        }
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (removeEffects.getValue() && removeSlownessVisual.getValue()) {
            PotionEffect slowness = mc.player.getActivePotionEffect(MobEffects.SLOWNESS);
            if (slowness != null) {
                mc.player.removePotionEffect(MobEffects.SLOWNESS);
            }
        }
    }
}
