package client.module.impl.render;

import client.module.BooleanSetting;
import client.module.Category;
import client.module.ColorSetting;
import client.module.Module;
import client.module.NumberSetting;
import net.minecraft.item.ItemStack;

public class ItemGlow extends Module {

    private static final int VANILLA_GLINT = -8372020;

    public static final int CTX_WORLD = 0;

    public static final int CTX_HELD = 1;

    public static final int CTX_GUI = 2;

    private static ItemGlow instance;

    private final BooleanSetting glint = new BooleanSetting("Glint", true);

    private final ColorSetting glintColor = new ColorSetting("Glint Color", 262.0);

    private final BooleanSetting rgb = new BooleanSetting("RGB", false);

    private final NumberSetting rgbSpeed = new NumberSetting("RGB Speed", 1.0, 0.1, 10.0);

    private final BooleanSetting durabilityAlert = new BooleanSetting("Durability Alert", false);

    private final BooleanSetting outline = new BooleanSetting("Outline", true);

    private final ColorSetting outlineColor = new ColorSetting("Outline Color", 190.0);

    private final BooleanSetting outlineRgb = new BooleanSetting("Outline RGB", false);

    private final NumberSetting outlineThickness = new NumberSetting("Outline Thickness", 2.0, 0.5, 4.0);

    public ItemGlow() {
        super("ItemGlow", Category.RENDER);
        setDescription("lets you make items glow");
        addSetting(glint);
        addSetting(glintColor);
        addSetting(rgb);
        addSetting(rgbSpeed);
        addSetting(durabilityAlert);
        addSetting(outline);
        addSetting(outlineColor);
        addSetting(outlineRgb);
        addSetting(outlineThickness);
        instance = this;
    }

    public static boolean shouldGlow(ItemStack stack) {
        ItemGlow m = instance;
        if (m == null || !m.isToggled())
            return false;
        return stack != null && !stack.func_190926_b();
    }

    public static boolean shouldRenderGlint() {
        ItemGlow m = instance;
        if (m == null || !m.isToggled())
            return true;
        return m.glint.getValue();
    }

    public static int getGlintColor(ItemStack stack) {
        ItemGlow m = instance;
        if (m == null || !m.isToggled())
            return VANILLA_GLINT;
        int rgb;
        if (m.rgb.getValue()) {
            double speed = m.rgbSpeed.getValue();
            double hue = (System.currentTimeMillis() * 0.001 * speed * 36.0) % 360.0;
            float[] c = ColorSetting.hsbToRgb((float) (hue / 360.0), 1.0f, 1.0f);
            rgb = ((int) (c[0] * 255.0f) << 16) | ((int) (c[1] * 255.0f) << 8) | (int) (c[2] * 255.0f);
        } else {
            rgb = m.glintColor.getARGB() & 0xFFFFFF;
        }
        if (m.durabilityAlert.getValue() && isCritical(stack)) {
            rgb = blendTowardRed(rgb, 0.75);
        }
        return 0xFF000000 | rgb;
    }

    public static float[] getArmorGlintColor() {
        ItemGlow m = instance;
        if (m == null || !m.isToggled()) {
            return new float[] { 0.38F, 0.19F, 0.608F };
        }
        int c = getGlintColor(null);
        return new float[] { ((c >> 16) & 0xFF) / 255.0F, ((c >> 8) & 0xFF) / 255.0F, (c & 0xFF) / 255.0F };
    }

    public static boolean shouldOutline(ItemStack stack) {
        ItemGlow m = instance;
        if (m == null || !m.isToggled())
            return false;
        if (!m.outline.getValue())
            return false;
        return stack != null && !stack.func_190926_b();
    }

    public static float[] getOutlineColor(ItemStack stack) {
        ItemGlow m = instance;
        if (m == null || !m.isToggled())
            return new float[] { 1.0F, 1.0F, 1.0F };
        int rgb;
        if (m.outlineRgb.getValue()) {
            double speed = m.rgbSpeed.getValue();
            double hue = (System.currentTimeMillis() * 0.001 * speed * 36.0 + 120.0) % 360.0;
            float[] c = ColorSetting.hsbToRgb((float) (hue / 360.0), 1.0f, 1.0f);
            rgb = ((int) (c[0] * 255.0f) << 16) | ((int) (c[1] * 255.0f) << 8) | (int) (c[2] * 255.0f);
        } else {
            rgb = m.outlineColor.getARGB() & 0xFFFFFF;
        }
        if (m.durabilityAlert.getValue() && isCritical(stack)) {
            rgb = blendTowardRed(rgb, 0.75);
        }
        return new float[] { ((rgb >> 16) & 0xFF) / 255.0F, ((rgb >> 8) & 0xFF) / 255.0F, (rgb & 0xFF) / 255.0F };
    }

    public static int getOutlineColorARGB(ItemStack stack) {
        float[] c = getOutlineColor(stack);
        int r = (int) (c[0] * 255.0F);
        int g = (int) (c[1] * 255.0F);
        int b = (int) (c[2] * 255.0F);
        if (r < 0)
            r = 0;
        if (r > 255)
            r = 255;
        if (g < 0)
            g = 0;
        if (g > 255)
            g = 255;
        if (b < 0)
            b = 0;
        if (b > 255)
            b = 255;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    public static float getOutlineThicknessPx() {
        ItemGlow m = instance;
        return m == null ? 2.0F : m.outlineThickness.getValue().floatValue();
    }

    public static float getOutlineBandModelUnits(int ctx) {
        float px = getOutlineThicknessPx();
        switch(ctx) {
            case CTX_HELD:
                return px / 80.0F;
            case CTX_GUI:
                return px / 16.0F;
            default:
                return px / 40.0F;
        }
    }

    public static float getOutlineScale(int ctx) {
        float px = getOutlineThicknessPx();
        switch(ctx) {
            case CTX_HELD:
                return 1.0F + px / 40.0F;
            case CTX_GUI:
                return 1.0F + px / 8.0F;
            default:
                return 1.0F + px / 24.0F;
        }
    }

    private static boolean isCritical(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return false;
        if (!stack.getItem().isDamageable())
            return false;
        int max = stack.getMaxDamage();
        return max > 0 && (max - stack.getItemDamage()) / (double) max < 0.02;
    }

    private static int blendTowardRed(int rgb, double t) {
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        r += (int) ((0xE0 - r) * t);
        g += (int) ((0x20 - g) * t);
        b += (int) ((0x20 - b) * t);
        return (r << 16) | (g << 8) | b;
    }
}
