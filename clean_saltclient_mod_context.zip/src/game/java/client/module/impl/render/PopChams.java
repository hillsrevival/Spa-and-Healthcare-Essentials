package client.module.impl.render;

import client.event.events.PacketInputEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.util.math.AxisAlignedBB;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.lax1dude.eaglercraft.EaglercraftUUID;
import java.util.concurrent.ConcurrentHashMap;

public class PopChams extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting onlyOne = new BooleanSetting("Only One", false);

    private final NumberSetting renderTime = new NumberSetting("Render Time", 1.0, 0.1, 6.0);

    private final NumberSetting yModifier = new NumberSetting("Y Modifier", 0.75, -4.0, 4.0);

    private final NumberSetting scaleModifier = new NumberSetting("Scale Modifier", -0.25, -4.0, 4.0);

    private final BooleanSetting fadeOut = new BooleanSetting("Fade Out", true);

    private final NumberSetting red = new NumberSetting("Red", 1.0, 0.0, 1.0);

    private final NumberSetting green = new NumberSetting("Green", 1.0, 0.0, 1.0);

    private final NumberSetting blue = new NumberSetting("Blue", 1.0, 0.0, 1.0);

    private final NumberSetting lineAlpha = new NumberSetting("Line Alpha", 0.5, 0.0, 1.0);

    private final NumberSetting sideAlpha = new NumberSetting("Side Alpha", 0.1, 0.0, 1.0);

    private final List<GhostPlayer> ghosts = new ArrayList<>();

    public PopChams() {
        super("PopChams", Category.RENDER);
        setDescription("Shows a pop effect when an entity takes damage");
        addSetting(onlyOne);
        addSetting(renderTime);
        addSetting(yModifier);
        addSetting(scaleModifier);
        addSetting(fadeOut);
        addSetting(red);
        addSetting(green);
        addSetting(blue);
        addSetting(lineAlpha);
        addSetting(sideAlpha);
        handles(HandlerType.PACKET_INPUT, HandlerType.RENDER);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        ghosts.clear();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        ghosts.clear();
    }

    @Override
    public void onPacketInput(PacketInputEvent event) {
        if (!nullCheck())
            return;
        if (event.getPacket() instanceof SPacketEntityStatus) {
            SPacketEntityStatus packet = (SPacketEntityStatus) event.getPacket();
            if (packet.getOpCode() != 35)
                return;
            Entity entity = packet.getEntity(mc.world);
            if (!(entity instanceof EntityPlayer))
                return;
            if (entity == mc.player)
                return;
            synchronized (ghosts) {
                if (onlyOne.getValue()) {
                    EaglercraftUUID entityUUID = entity.getUniqueID();
                    ghosts.removeIf(g -> g.uuid.equals(entityUUID));
                }
                ghosts.add(new GhostPlayer((EntityPlayer) entity));
            }
        }
    }

    @Override
    public void onRender(client.event.listeners.RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        float partialTicks = event.getPartialTicks();
        synchronized (ghosts) {
            Iterator<GhostPlayer> it = ghosts.iterator();
            while (it.hasNext()) {
                GhostPlayer ghost = it.next();
                if (ghost.render(partialTicks)) {
                    it.remove();
                }
            }
        }
    }

    private class GhostPlayer {

        private final EaglercraftUUID uuid;

        private final String name;

        private double x, y, z;

        private float width, height;

        private float yaw;

        private double timer;

        private double scale;

        private long lastRenderTime;

        public GhostPlayer(EntityPlayer player) {
            this.uuid = player.getUniqueID();
            this.name = player.getName();
            float pt = 1.0f;
            this.x = player.lastTickPosX + (player.posX - player.lastTickPosX) * pt;
            this.y = player.lastTickPosY + (player.posY - player.lastTickPosY) * pt;
            this.z = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * pt;
            this.width = player.width;
            this.height = player.height;
            this.yaw = player.rotationYaw;
            this.timer = 0;
            this.scale = 1.0;
            this.lastRenderTime = System.currentTimeMillis();
        }

        public boolean render(float partialTicks) {
            long now = System.currentTimeMillis();
            double frameTime = (now - lastRenderTime) / 1000.0;
            lastRenderTime = now;
            if (frameTime <= 0.0 || frameTime > 0.1)
                frameTime = 0.05;
            timer += frameTime;
            if (timer > renderTime.getValue().doubleValue())
                return true;
            y += yModifier.getValue().doubleValue() * frameTime;
            scale += scaleModifier.getValue().doubleValue() * frameTime;
            if (scale < 0.1)
                scale = 0.1;
            float progress = (float) (timer / renderTime.getValue().doubleValue());
            float alpha = 1.0f - progress;
            if (!fadeOut.getValue())
                alpha = 1.0f;
            float r = red.getValue().floatValue();
            float g = green.getValue().floatValue();
            float b = blue.getValue().floatValue();
            float lineA = lineAlpha.getValue().floatValue() * alpha;
            float sideA = sideAlpha.getValue().floatValue() * alpha;
            double halfW = (width * scale) / 2.0;
            double h = height * scale;
            AxisAlignedBB bb = new AxisAlignedBB(x - halfW, y, z - halfW, x + halfW, y + h, z + halfW);
            client.utils.render.RenderUtils.updateCameraPos(partialTicks);
            client.utils.render.RenderUtils.prepareGL();
            client.utils.render.RenderUtils.drawOutlinedBox(bb, r, g, b, lineA);
            client.utils.render.RenderUtils.drawSolidBox(bb, r, g, b, sideA);
            client.utils.render.RenderUtils.restoreGL();
            return false;
        }
    }
}
