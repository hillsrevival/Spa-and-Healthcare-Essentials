package client.module.impl.render;

import client.module.NumberSetting;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.render.BlockEspUtils;
import client.utils.render.RenderUtils;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;

public class ObsidianAncientDebrisESP extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BlockEspUtils.BlockScanner scanner = new BlockEspUtils.BlockScanner();

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    private final BlockEspUtils.Matcher matcher = new BlockEspUtils.Matcher() {

        @Override
        public int match(IBlockState state, int x, int y, int z) {
            Block block = state.getBlock();
            if (block == Blocks.OBSIDIAN)
                return 1;
            String name = block.getUnlocalizedName();
            if (name != null) {
                String lower = name.toLowerCase();
                if (lower.contains("ancient") && lower.contains("debris")) {
                    return 1;
                }
            }
            return 0;
        }
    };

    private final BlockEspUtils.ColorFn boxColor = new BlockEspUtils.ColorFn() {

        @Override
        public void colorOf(int index, int tag, float[] out3) {
            out3[0] = 0.6f;
            out3[1] = 0.1f;
            out3[2] = 0.8f;
        }
    };

    public ObsidianAncientDebrisESP() {
        super("Obsidian/Ancient Debris ESP", Category.RENDER);
        setDescription("Highlights obsidian and ancient debris through walls");
        addSetting(lineWidth);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
        scanner.setChunksPerTick(3);
        scanner.setRescanIntervalTicks(100);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        scanner.clear();
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        scanner.update(mc.player.chunkCoordX, mc.player.chunkCoordZ, 8, 0, 255, matcher);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (scanner.size() == 0)
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        BlockEspUtils.drawScannerBoxes(scanner, boxColor, 0.2f, 0.6f, lineWidth.getValue().floatValue());
    }

    @Override
    public void onDisable() {
        super.onDisable();
        scanner.clear();
    }
}
