package client.module.impl.render;

import net.minecraft.client.Minecraft;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;

public class CameraTweaks extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting noBob = new BooleanSetting("NoBob", true);

    private final BooleanSetting noClip = new BooleanSetting("NoClip", false);

    public CameraTweaks() {
        super("CameraTweaks", Category.RENDER);
        setDescription("Adjusts camera distance, smoothness, and tilt");
        addSetting(noBob);
        addSetting(noClip);
        handles(HandlerType.UPDATE, HandlerType.CAMERA_VIEW_BOB);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (noClip.getValue() && mc.gameSettings.thirdPersonView > 0) {
            net.minecraft.client.renderer.EntityRenderer.cameraNoClip = true;
        }
    }

    @Override
    public void onCameraTransformViewBobbing(client.event.listeners.CameraTransformViewBobbingListener.CameraTransformViewBobbingEvent event) {
        if (noBob.getValue()) {
            event.setCancelled(true);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        net.minecraft.client.renderer.EntityRenderer.cameraNoClip = false;
    }
}
