package client.module.impl.render;

import client.event.events.CameraTransformViewBobbingEvent;
import client.event.events.MotionEvent;
import client.event.events.PacketInputEvent;
import client.event.events.PacketOutputEvent;
import client.event.events.RenderFirstPersonItemEvent;
import client.event.listeners.CameraTransformViewBobbingListener;
import client.event.listeners.PlayerMoveListener;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.misc.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketRespawn;
import net.minecraft.network.play.server.SPacketUpdateHealth;

public class Freecam extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting speed = new NumberSetting("Speed", 1.0, 0.05, 10.0);

    private final BooleanSetting showHands = new BooleanSetting("Show Hands", true);

    private final BooleanSetting toggleOnDeath = new BooleanSetting("Toggle On Death", true);

    private final BooleanSetting toggleOnDisconnect = new BooleanSetting("Toggle On Disconnect", true);

    private double posX;

    private double posY;

    private double posZ;

    private float rotationYaw;

    private float rotationPitch;

    private float lastHealth = -1.0F;

    public Freecam() {
        super("Freecam", Category.RENDER);
        setDescription("Lets you explore around in a fly state while your player doesn't move");
        addSetting(speed);
        addSetting(showHands);
        addSetting(toggleOnDeath);
        addSetting(toggleOnDisconnect);
        handles(HandlerType.UPDATE, HandlerType.MOTION, HandlerType.PLAYER_MOVE, HandlerType.CAMERA_VIEW_BOB, HandlerType.RENDER_FIRST_PERSON_ITEM, HandlerType.PACKET_OUTPUT, HandlerType.PACKET_INPUT);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null || mc.world == null) {
            toggle();
            return;
        }
        posX = mc.player.posX;
        posY = mc.player.posY;
        posZ = mc.player.posZ;
        rotationYaw = mc.player.rotationYaw;
        rotationPitch = mc.player.rotationPitch;
        lastHealth = mc.player.getHealth();
        client.Client.INSTANCE.freecamActive = true;
        mc.player.noClip = true;
        ChatUtils.info("Freecam enabled - fly around freely");
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        mc.player.noClip = true;
        float speedVal = speed.getValue().floatValue();
        if (mc.gameSettings.keyBindSprint.isKeyDown()) {
            speedVal *= 2.0F;
        }
        float forward = 0.0F;
        if (mc.gameSettings.keyBindForward.isKeyDown())
            forward += 1.0F;
        if (mc.gameSettings.keyBindBack.isKeyDown())
            forward -= 1.0F;
        float strafe = 0.0F;
        if (mc.gameSettings.keyBindLeft.isKeyDown())
            strafe += 1.0F;
        if (mc.gameSettings.keyBindRight.isKeyDown())
            strafe -= 1.0F;
        float yaw = mc.player.rotationYaw * 0.017453292F;
        float sin = net.minecraft.util.math.MathHelper.sin(yaw);
        float cos = net.minecraft.util.math.MathHelper.cos(yaw);
        double moveX = (strafe * cos - forward * sin) * speedVal;
        double moveZ = (forward * cos + strafe * sin) * speedVal;
        double moveY = 0.0;
        if (mc.gameSettings.keyBindJump.isKeyDown())
            moveY += speedVal;
        if (mc.gameSettings.keyBindSneak.isKeyDown())
            moveY -= speedVal;
        mc.player.motionX = moveX;
        mc.player.motionY = moveY;
        mc.player.motionZ = moveZ;
        mc.player.jumpMovementFactor = 1.0F;
        mc.player.fallDistance = 0.0F;
        mc.player.onGround = false;
    }

    @Override
    public void onMotion(MotionEvent event) {
        if (mc.player == null)
            return;
        mc.player.noClip = true;
    }

    @Override
    public void onPlayerMove(PlayerMoveListener.PlayerMoveEvent event) {
        if (mc.player == null)
            return;
        mc.player.noClip = true;
    }

    @Override
    public void onCameraTransformViewBobbing(CameraTransformViewBobbingListener.CameraTransformViewBobbingEvent event) {
        event.setCancelled(true);
    }

    @Override
    public void onRenderFirstPersonItem(RenderFirstPersonItemEvent event) {
        if (!showHands.getValue()) {
            event.setCancelled(true);
        }
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        Packet pkt = event.getPacket();
        if (pkt instanceof CPacketPlayer) {
            CPacketPlayer cp = (CPacketPlayer) pkt;
            if (cp instanceof CPacketPlayer.Position) {
                event.setPacket(new CPacketPlayer.Position(posX, posY, posZ, cp.isOnGround()));
            } else if (cp instanceof CPacketPlayer.PositionRotation) {
                event.setPacket(new CPacketPlayer.PositionRotation(posX, posY, posZ, cp.getYaw(mc.player.rotationYaw), cp.getPitch(mc.player.rotationPitch), cp.isOnGround()));
            }
        }
    }

    @Override
    public void onPacketInput(PacketInputEvent event) {
        Packet pkt = event.getPacket();
        if (pkt instanceof SPacketEntityStatus) {
            SPacketEntityStatus status = (SPacketEntityStatus) pkt;
            if (status.getOpCode() == 2 && mc.player != null && status.getEntity(mc.world) == mc.player && toggleOnDeath.getValue()) {
                ChatUtils.info("Freecam disabled - you died");
                toggle();
                return;
            }
        }
        if (pkt instanceof SPacketRespawn) {
            if (toggleOnDisconnect.getValue()) {
                ChatUtils.info("Freecam disabled - changed dimensions");
                toggle();
                return;
            }
        }
        if (pkt instanceof SPacketUpdateHealth) {
            SPacketUpdateHealth healthPkt = (SPacketUpdateHealth) pkt;
            if (lastHealth >= 0 && mc.player != null) {
                float damageTaken = lastHealth - healthPkt.getHealth();
                if (damageTaken > 0 && toggleOnDeath.getValue()) {
                }
            }
            lastHealth = healthPkt.getHealth();
        }
    }

    @Override
    public void onDisable() {
        client.Client.INSTANCE.freecamActive = false;
        if (mc.player != null) {
            mc.player.setPositionAndUpdate(posX, posY, posZ);
            mc.player.rotationYaw = rotationYaw;
            mc.player.rotationPitch = rotationPitch;
            mc.player.noClip = false;
            mc.player.motionX = 0.0;
            mc.player.motionY = 0.0;
            mc.player.motionZ = 0.0;
            if (mc.renderGlobal != null) {
                mc.renderGlobal.loadRenderers();
            }
        }
        lastHealth = -1.0F;
        ChatUtils.message("Freecam disabled - position restored");
        super.onDisable();
    }
}
