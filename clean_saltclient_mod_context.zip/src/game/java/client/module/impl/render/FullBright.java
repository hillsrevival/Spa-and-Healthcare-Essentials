package client.module.impl.render;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.client.Minecraft;

public class FullBright extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private float savedGamma = -1.0F;

    public FullBright() {
        super("Fullbright", Category.RENDER);
        setDescription("Sets everything to full brightness");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.gameSettings == null)
            return;
        savedGamma = mc.gameSettings.gammaSetting;
        mc.gameSettings.gammaSetting = 1000.0F;
        mc.entityRenderer.lightmapUpdateNeeded = true;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.gameSettings == null)
            return;
        if (savedGamma >= 0.0F) {
            mc.gameSettings.gammaSetting = savedGamma;
        } else {
            mc.gameSettings.gammaSetting = 1.0F;
        }
        savedGamma = -1.0F;
        mc.entityRenderer.lightmapUpdateNeeded = true;
    }

    @Override
    public void onUpdate() {
        if (mc.gameSettings == null)
            return;
        if (mc.gameSettings.gammaSetting < 1000.0F) {
            mc.gameSettings.gammaSetting = 1000.0F;
            mc.entityRenderer.lightmapUpdateNeeded = true;
        }
    }
}
