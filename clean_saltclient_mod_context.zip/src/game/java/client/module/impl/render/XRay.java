package client.module.impl.render;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.block.Block;
import client.event.listeners.ShouldSideBeRenderedListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;

public class XRay extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private float prevGamma = -1.0F;

    private final ModeSetting mode = new ModeSetting("Mode", "All Ores", "All Ores", "Diamonds Only", "Custom");

    public XRay() {
        super("XRay", Category.RENDER);
        setDescription("Makes ores visible through the ground");
        addSetting(mode);
        handles(HandlerType.UPDATE, HandlerType.SHOULD_SIDE_BE_RENDERED);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (prevGamma < 0) {
            prevGamma = Math.min(mc.gameSettings.gammaSetting, 1.0F);
        }
        if (mc.gameSettings.gammaSetting != 1000) {
            mc.gameSettings.gammaSetting = 1000;
        }
        if (mc.renderGlobal != null) {
            mc.renderGlobal.loadRenderers();
        }
    }

    @Override
    public void onDisable() {
        if (prevGamma >= 0) {
            mc.gameSettings.gammaSetting = prevGamma;
            prevGamma = -1.0F;
        }
        if (mc.renderGlobal != null) {
            mc.renderGlobal.loadRenderers();
        }
        super.onDisable();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (mc.gameSettings.gammaSetting < 16) {
            mc.gameSettings.gammaSetting = 16;
        }
    }

    @Override
    public void onShouldSideBeRendered(ShouldSideBeRenderedListener.ShouldSideBeRenderedEvent event) {
        if (!nullCheck())
            return;
        Block block = event.getState().getBlock();
        if (isTargetOre(block)) {
            event.setRendered(true);
        } else {
            event.setRendered(false);
        }
    }

    private boolean isTargetOre(Block block) {
        String modeVal = mode.getValue();
        if (modeVal.equals("Diamonds Only")) {
            return block == Blocks.DIAMOND_ORE;
        }
        return block == Blocks.DIAMOND_ORE || block == Blocks.EMERALD_ORE || block == Blocks.GOLD_ORE || block == Blocks.LAPIS_ORE || block == Blocks.REDSTONE_ORE || block == Blocks.LIT_REDSTONE_ORE || block == Blocks.IRON_ORE || block == Blocks.COAL_ORE;
    }
}
