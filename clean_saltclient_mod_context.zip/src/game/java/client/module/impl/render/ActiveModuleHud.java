package client.module.impl.render;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.Module;
import client.module.ModuleManager;
import client.module.Setting;
import client.module.impl.fun.ColorUi;
import client.utils.render.ClientFontRenderer;
import client.utils.render.CrystalTheme;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;

/**
 * Crystal module list: animated shard tags with a glowing edge, mode suffixes, and several styles.
 */
public class ActiveModuleHud extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting style = new ModeSetting("Style", "Shards", "Shards", "Glass", "Minimal");
    private final ModeSetting colorMode = new ModeSetting("ColorMode", "Crystal", "Crystal", "Aurora", "White", "Rainbow");
    private final BooleanSetting showSuffix = new BooleanSetting("ShowSuffix", true);
    private final BooleanSetting showCategory = new BooleanSetting("ShowCategory", false);
    private final BooleanSetting hideRender = new BooleanSetting("HideRender", false);
    private final BooleanSetting shadow = new BooleanSetting("Shadow", true);
    private final BooleanSetting sortByName = new BooleanSetting("SortByName", false);
    private final BooleanSetting animate = new BooleanSetting("Animate", true);

    private final HudElement pos = new HudElement(this, -1, 12);

    private final Map<Module, Float> anim = new HashMap<Module, Float>();

    public ActiveModuleHud() {
        super("ActiveModuleHud", Category.RENDER);
        setDescription("Crystal module list with animated shard tags");
        addSetting(style);
        addSetting(colorMode);
        addSetting(showSuffix);
        addSetting(showCategory);
        addSetting(hideRender);
        addSetting(shadow);
        addSetting(sortByName);
        addSetting(animate);
        handles(HandlerType.GUI_RENDER);
        pos.addSettings();
    }

    private String suffixOf(Module m) {
        if (!showSuffix.getValue() && !showCategory.getValue())
            return "";
        StringBuilder sb = new StringBuilder();
        if (showSuffix.getValue()) {
            for (Setting<?> s : m.getSettings()) {
                if (s instanceof ModeSetting) {
                    sb.append(((ModeSetting) s).getValue());
                    break;
                }
            }
        }
        if (showCategory.getValue()) {
            if (sb.length() > 0)
                sb.append(" ");
            sb.append("[").append(m.getCategory().name().toLowerCase()).append("]");
        }
        return sb.toString();
    }

    private int colorFor(int i, long now) {
        String mode = colorMode.getValue();
        if (mode.equals("White"))
            return 0xFFFFFFFF;
        if (mode.equals("Rainbow")) {
            Module rb = ModuleManager.getModuleByName("ColorUi");
            if (rb != null && rb.isToggled())
                return 0xFF000000 | ColorUi.getRainbowColor((float) (i * 0.08) % 1.0f);
            float h = ((now / 40L + i * 6L) % 360L) / 360.0f;
            float[] rgb = client.module.ColorSetting.hsbToRgb(h, 0.55f, 1.0f);
            return 0xFF000000 | ((int) (rgb[0] * 255) << 16) | ((int) (rgb[1] * 255) << 8) | (int) (rgb[2] * 255);
        }
        if (mode.equals("Aurora")) {
            float t = (float) ((Math.sin(now / 900.0 - i * 0.45) + 1.0) * 0.5);
            return CrystalTheme.lerp(0xFF5CF2C0, 0xFF8F7BFF, t);
        }
        float t = (float) ((Math.sin(now / 700.0 - i * 0.5) + 1.0) * 0.5);
        return CrystalTheme.lerp(CrystalTheme.ACCENT_DIM, CrystalTheme.ACCENT_BRIGHT, t);
    }

    private void quad(float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4, int argb) {
        float a = ((argb >>> 24) & 0xFF) / 255.0f;
        float r = ((argb >> 16) & 0xFF) / 255.0f;
        float g = ((argb >> 8) & 0xFF) / 255.0f;
        float b = (argb & 0xFF) / 255.0f;
        Tessellator t = Tessellator.getInstance();
        t.getWorldRenderer().begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        t.getWorldRenderer().pos(x1, y1, 0).color(r, g, b, a).endVertex();
        t.getWorldRenderer().pos(x2, y2, 0).color(r, g, b, a).endVertex();
        t.getWorldRenderer().pos(x3, y3, 0).color(r, g, b, a).endVertex();
        t.getWorldRenderer().pos(x4, y4, 0).color(r, g, b, a).endVertex();
        t.draw();
    }

    private static int withA(int color, float f) {
        int a = (int) (((color >>> 24) & 0xFF) * Math.max(0.0f, Math.min(1.0f, f)));
        return (a << 24) | (color & 0x00FFFFFF);
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (!pos.shouldRender())
            return;
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        long now = System.currentTimeMillis();
        boolean anims = animate.getValue();
        // 1. update animation targets
        List<Module> activeNow = new ArrayList<Module>();
        for (Module m : ModuleManager.getModules()) {
            if (!m.isToggled() || m == this)
                continue;
            if (hideRender.getValue() && m.getCategory() == Category.RENDER)
                continue;
            activeNow.add(m);
            if (!anim.containsKey(m))
                anim.put(m, anims ? 0.0f : 1.0f);
        }
        Iterator<Map.Entry<Module, Float>> it = anim.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Module, Float> e = it.next();
            float target = activeNow.contains(e.getKey()) ? 1.0f : 0.0f;
            float v = anims ? e.getValue() + (target - e.getValue()) * 0.18f : target;
            if (Math.abs(v - target) < 0.01f)
                v = target;
            if (v <= 0.0f && target == 0.0f) {
                it.remove();
                continue;
            }
            e.setValue(v);
        }
        if (anim.isEmpty())
            return;
        // 2. order entries
        final Map<Module, String> suffix = new HashMap<Module, String>();
        List<Module> list = new ArrayList<Module>(anim.keySet());
        for (Module m : list)
            suffix.put(m, suffixOf(m));
        if (sortByName.getValue()) {
            Collections.sort(list, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        } else {
            Collections.sort(list, (a, b) -> {
                int wa = ClientFontRenderer.getStringWidth(a.getName() + (suffix.get(a).isEmpty() ? "" : " " + suffix.get(a)));
                int wb = ClientFontRenderer.getStringWidth(b.getName() + (suffix.get(b).isEmpty() ? "" : " " + suffix.get(b)));
                return wb - wa;
            });
        }
        int pad = 4;
        int lineH = ClientFontRenderer.fontHeight() + 3;
        int maxW = 0;
        for (Module m : list) {
            String suf = suffix.get(m);
            int w = ClientFontRenderer.getStringWidth(m.getName()) + (suf.isEmpty() ? 0 : ClientFontRenderer.getStringWidth(suf) + 4) + pad * 2 + 4;
            if (w > maxW)
                maxW = w;
        }
        int totalW = maxW + pad;
        int totalH = list.size() * lineH;
        pos.updateDrag(totalW, totalH);
        int rightX;
        int finalX;
        if (pos.isDefaultX()) {
            rightX = sr.getScaledWidth() - 3;
            finalX = rightX - totalW;
        } else {
            finalX = pos.getX();
            rightX = finalX + totalW;
        }
        int y0 = pos.getY();
        String st = style.getValue();
        for (int i = 0; i < list.size(); i++) {
            Module m = list.get(i);
            float f = anim.get(m);
            String name = m.getName();
            String suf = suffix.get(m);
            int nameW = ClientFontRenderer.getStringWidth(name);
            int sufW = suf.isEmpty() ? 0 : ClientFontRenderer.getStringWidth(suf) + 4;
            int w = nameW + sufW + pad * 2 + 4;
            int slide = (int) ((1.0f - f) * (w + 8));
            int right = rightX + slide;
            int left = right - w;
            int y = y0 + i * lineH;
            int col = colorFor(i, now);
            float skew = st.equals("Shards") ? 3.0f : 0.0f;
            RenderUtils.prepareHUD();
            if (!st.equals("Minimal")) {
                int bg = st.equals("Glass") ? 0x7010263F : 0xA0070F1E;
                quad(left + skew, y, right, y, right, y + lineH, left, y + lineH, withA(bg, f));
                if (st.equals("Glass"))
                    quad(left + skew, y, right, y, right, y + 1, left + skew, y + 1, withA(CrystalTheme.withAlpha(col, 0x90), f));
            }
            quad(right - 2, y, right, y, right, y + lineH, right - 2, y + lineH, withA(col, f));
            if (st.equals("Shards")) {
                quad(left + skew, y, left + skew + 1, y, left + 1, y + lineH, left, y + lineH, withA(CrystalTheme.withAlpha(col, 0x80), f));
            }
            RenderUtils.restoreHUD();
            int tx = left + pad + (st.equals("Shards") ? 2 : 0);
            int ty = y + 2;
            int textCol = withA(col, f);
            if (shadow.getValue())
                ClientFontRenderer.drawStringWithShadow(name, tx, ty, textCol);
            else
                ClientFontRenderer.drawString(name, tx, ty, textCol);
            if (!suf.isEmpty()) {
                int dim = withA(CrystalTheme.TEXT_DIM, f);
                if (shadow.getValue())
                    ClientFontRenderer.drawStringWithShadow(suf, tx + nameW + 4, ty, dim);
                else
                    ClientFontRenderer.drawString(suf, tx + nameW + 4, ty, dim);
            }
        }
        pos.renderDragBox(finalX, y0, totalW, totalH);
    }
}
