package client.module.impl.render;

import client.event.listeners.RenderListener;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.ColorSetting;
import client.module.Condition;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.Module;
import client.module.NumberSetting;
import client.utils.render.RenderUtils;
import client.utils.misc.FriendManager;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.lax1dude.eaglercraft.opengl.WorldRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;

public class Hat extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Mode", "China Hat", "China Hat", "Halo");

    private final BooleanSetting attachToHead = new BooleanSetting("Attach To Head", false);

    private final BooleanSetting friendsHat = new BooleanSetting("Friends Hat", true);

    private final ColorSetting friendColor = new ColorSetting("Friend Color", 0.0);

    private final BooleanSetting selfHat = new BooleanSetting("Self Hat", true);

    private final ColorSetting selfColor = new ColorSetting("Self Color", 0.0);

    private final NumberSetting hatScale = new NumberSetting("Scale", 1.0, 0.5, 2.0);

    private final BooleanSetting rainbow = new BooleanSetting("Rainbow", false);

    public Hat() {
        super("Hat", Category.RENDER);
        setDescription("Draws a hat or halo above players");
        addSetting(mode);
        addSetting(attachToHead);
        addSetting(friendsHat);
        addSetting(friendColor);
        addSetting(selfHat);
        addSetting(selfColor);
        addSetting(hatScale);
        addSetting(rainbow);
        friendColor.setVisibilityCondition(Condition.and(Condition.whenTrue(friendsHat), Condition.whenFalse(rainbow)));
        selfColor.setVisibilityCondition(Condition.and(Condition.whenTrue(selfHat), Condition.whenFalse(rainbow)));
        handles(HandlerType.RENDER);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        float partialTicks = event.getPartialTicks();
        RenderUtils.updateCameraPos(partialTicks);
        double camX = RenderUtils.camX;
        double camY = RenderUtils.camY;
        double camZ = RenderUtils.camZ;
        long now = System.currentTimeMillis();
        for (EntityPlayer player : mc.world.playerEntities) {
            if (player == null || !player.isEntityAlive())
                continue;
            boolean isSelf = player == mc.player;
            boolean isFriend = !isSelf && FriendManager.isFriend(player);
            if (isSelf && !selfHat.getValue())
                continue;
            if (!isSelf && !isFriend)
                continue;
            if (isFriend && !friendsHat.getValue())
                continue;
            if (isSelf && mc.gameSettings.thirdPersonView == 0)
                continue;
            double x = player.lastTickPosX + (player.posX - player.lastTickPosX) * partialTicks - camX;
            double y = player.lastTickPosY + (player.posY - player.lastTickPosY) * partialTicks - camY;
            double z = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * partialTicks - camZ;
            double hatY = y + player.height - (player.isSneaking() ? 0.25F : 0.05F);
            float[] baseRgb;
            if (rainbow.getValue()) {
                float h = ((now / 15L) % 360L) / 360.0F;
                baseRgb = RenderUtils.hsbToRgb(h, 1.0F, 1.0F);
            } else if (isSelf) {
                baseRgb = selfColor.getRGBFloat();
            } else {
                baseRgb = friendColor.getRGBFloat();
            }
            GlStateManager.pushMatrix();
            GlStateManager.disableTexture2D();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
            GlStateManager.disableDepth();
            GlStateManager.depthMask(false);
            RenderUtils.enableLineSmooth();
            if (attachToHead.getValue()) {
                float yaw = player.prevRotationYaw + (player.rotationYaw - player.prevRotationYaw) * partialTicks;
                float pitch = player.prevRotationPitch + (player.rotationPitch - player.prevRotationPitch) * partialTicks;
                GlStateManager.translate(x, hatY, z);
                GlStateManager.rotate(-yaw, 0.0F, 1.0F, 0.0F);
                GlStateManager.rotate(pitch, 1.0F, 0.0F, 0.0F);
                float pitchAbs = Math.abs(pitch);
                float compensationY = pitchAbs / 90.0F * 0.3F;
                GlStateManager.translate(0.0F, compensationY, 0.05F);
            } else {
                GlStateManager.translate(x, hatY, z);
            }
            float scale = hatScale.getValue().floatValue();
            if (mode.getValue().equals("China Hat")) {
                drawChinaHatWireframe(scale, baseRgb, now);
            } else {
                drawHaloWireframe(scale, baseRgb, now);
            }
            EaglercraftGPU.glLineWidth(1.0F);
            RenderUtils.disableLineSmooth();
            GlStateManager.depthMask(true);
            GlStateManager.enableDepth();
            GlStateManager.disableBlend();
            GlStateManager.enableTexture2D();
            GlStateManager.popMatrix();
        }
    }

    private void drawChinaHatWireframe(float scale, float[] baseRgb, long now) {
        int meridians = 12;
        int rings = 4;
        int segments = 64;
        float radius = 0.55F * scale;
        float height = 0.3F * scale;
        EaglercraftGPU.glLineWidth(2.0F);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        buf.begin(RealOpenGLEnums.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        for (int m = 0; m < meridians; m++) {
            float angle = (float) (Math.PI * 2.0 * m / meridians);
            float[] c = meridianColor(baseRgb, m, meridians, now);
            buf.pos(0.0F, height, 0.0F).color(c[0], c[1], c[2], 0.9F).endVertex();
            buf.pos((float) Math.cos(angle) * radius, 0.0F, (float) Math.sin(angle) * radius).color(c[0], c[1], c[2], 0.7F).endVertex();
        }
        tess.draw();
        for (int ring = 1; ring <= rings; ring++) {
            float t = (float) ring / rings;
            float ringRadius = radius * t;
            float ringY = height * (1.0F - t);
            float ringAlpha = 0.4F + 0.5F * t;
            float lineW = 1.0F + 1.5F * t;
            EaglercraftGPU.glLineWidth(lineW);
            buf.begin(RealOpenGLEnums.GL_LINE_STRIP, DefaultVertexFormats.POSITION_COLOR);
            for (int i = 0; i <= segments; i++) {
                float angle = (float) (Math.PI * 2.0 * i / segments);
                float[] c = ringColor(baseRgb, i, segments, now, ringAlpha);
                buf.pos((float) Math.cos(angle) * ringRadius, ringY, (float) Math.sin(angle) * ringRadius).color(c[0], c[1], c[2], c[3]).endVertex();
            }
            tess.draw();
        }
        EaglercraftGPU.glLineWidth(1.0F);
        buf.begin(RealOpenGLEnums.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        for (int ring = 1; ring <= rings; ring++) {
            float t = (float) ring / rings;
            float ringRadius = radius * t;
            float ringY = height * (1.0F - t);
            for (int m = 0; m < meridians; m++) {
                float angle1 = (float) (Math.PI * 2.0 * m / meridians);
                float angle2 = (float) (Math.PI * 2.0 * ((m + 1) % meridians) / meridians);
                float[] c = meridianColor(baseRgb, m, meridians, now);
                buf.pos((float) Math.cos(angle1) * ringRadius, ringY, (float) Math.sin(angle1) * ringRadius).color(c[0], c[1], c[2], 0.3F).endVertex();
                buf.pos((float) Math.cos(angle2) * ringRadius, ringY, (float) Math.sin(angle2) * ringRadius).color(c[0], c[1], c[2], 0.3F).endVertex();
            }
        }
        tess.draw();
    }

    private void drawHaloWireframe(float scale, float[] baseRgb, long now) {
        int segments = 64;
        float radius = 0.4F * scale;
        float yOffset = 0.1F * scale;
        int spokes = 8;
        float rotation = (now % 12000L) / 12000.0F * 360.0F;
        for (int layer = 0; layer < 3; layer++) {
            float layerRadius = radius * (1.0F + layer * 0.1F);
            float layerAlpha = (1.0F - layer * 0.25F) * 0.8F;
            float lineWidth = 3.0F - layer * 0.7F;
            EaglercraftGPU.glLineWidth(lineWidth);
            Tessellator tess = Tessellator.getInstance();
            WorldRenderer buf = tess.getBuffer();
            buf.begin(RealOpenGLEnums.GL_LINE_STRIP, DefaultVertexFormats.POSITION_COLOR);
            for (int i = 0; i <= segments; i++) {
                float angle = (float) (Math.PI * 2.0 * i / segments);
                float[] c = ringColor(baseRgb, i, segments, now, layerAlpha);
                float pulse = 1.0F + 0.03F * (float) Math.sin(angle * 3.0 + now * 0.003);
                buf.pos((float) Math.cos(angle) * layerRadius * pulse, yOffset, (float) Math.sin(angle) * layerRadius * pulse).color(c[0], c[1], c[2], c[3]).endVertex();
            }
            tess.draw();
        }
        EaglercraftGPU.glLineWidth(1.5F);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        buf.begin(RealOpenGLEnums.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        float rotRad = (float) Math.toRadians(rotation);
        for (int s = 0; s < spokes; s++) {
            float angle = (float) (Math.PI * 2.0 * s / spokes) + rotRad;
            float[] c = ringColor(baseRgb, s * segments / spokes, segments, now, 0.5F);
            float innerR = radius * 0.3F;
            buf.pos((float) Math.cos(angle) * innerR, yOffset, (float) Math.sin(angle) * innerR).color(c[0], c[1], c[2], 0.2F).endVertex();
            float outerR = radius * 1.15F;
            buf.pos((float) Math.cos(angle) * outerR, yOffset, (float) Math.sin(angle) * outerR).color(c[0], c[1], c[2], 0.6F).endVertex();
        }
        tess.draw();
    }

    private float[] meridianColor(float[] baseRgb, int meridianIndex, int totalMeridians, long now) {
        if (rainbow.getValue()) {
            float hueShift = ((float) meridianIndex / totalMeridians) * 360.0F;
            float timeShift = (now / 15L % 360L);
            float h = ((hueShift + timeShift) % 360.0F) / 360.0F;
            return RenderUtils.hsbToRgb(h, 0.9F, 1.0F);
        }
        return baseRgb;
    }

    private float[] ringColor(float[] baseRgb, int segmentIndex, int totalSegments, long now, float alpha) {
        if (rainbow.getValue()) {
            float hueShift = ((float) segmentIndex / totalSegments) * 360.0F;
            float timeShift = (now / 15L % 360L);
            float h = ((hueShift + timeShift) % 360.0F) / 360.0F;
            float[] rgb = RenderUtils.hsbToRgb(h, 0.9F, 1.0F);
            return new float[] { rgb[0], rgb[1], rgb[2], alpha };
        }
        return new float[] { baseRgb[0], baseRgb[1], baseRgb[2], alpha };
    }
}
