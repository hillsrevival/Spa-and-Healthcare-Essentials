package client.module.impl.render;

import client.module.NumberSetting;
import java.util.ArrayList;
import java.util.List;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.ColorSetting;
import client.utils.render.EntityEspUtils;
import client.utils.render.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import client.utils.EntityUtils;

public class PlayerESP extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting tracers = new BooleanSetting("Tracers", true);

    private final ModeSetting tracerColor = new ModeSetting("Tracer Color", "Default", "Default", "Red", "Green", "Blue", "Yellow", "Purple", "Pink", "Orange", "White", "Cyan", "Rainbow");

    private final ColorSetting customColor = new ColorSetting("Custom Color", 0.0);

    private final BooleanSetting boxes = new BooleanSetting("Boxes", true);

    private final BooleanSetting showInvisible = new BooleanSetting("Show Invisible", false);

    private final BooleanSetting showSleeping = new BooleanSetting("Show Sleeping", true);

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    private final List<EntityPlayer> players = new ArrayList<EntityPlayer>();

    private final EntityEspUtils.EntityColorFn boxColor = new EntityEspUtils.EntityColorFn() {

        @Override
        public void colorOf(net.minecraft.entity.Entity entity, int index, float[] out3) {
            EntityEspUtils.distanceColor(entity, 20.0, out3);
        }
    };

    private final EntityEspUtils.EntityColorFn tracerColorFn = new EntityEspUtils.EntityColorFn() {

        @Override
        public void colorOf(net.minecraft.entity.Entity entity, int index, float[] out3) {
            float[] c = RenderUtils.resolveTracerColor(tracerColor.getValue(), customColor.getRGBFloat(), index);
            if (c != null) {
                out3[0] = c[0];
                out3[1] = c[1];
                out3[2] = c[2];
            } else {
                EntityEspUtils.distanceColor(entity, 20.0, out3);
            }
        }
    };

    public PlayerESP() {
        super("PlayerESP", Category.RENDER);
        setDescription("Highlights players through walls");
        addSetting(tracers);
        addSetting(tracerColor);
        addSetting(customColor);
        addSetting(boxes);
        addSetting(showInvisible);
        addSetting(showSleeping);
        addSetting(lineWidth);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        players.clear();
        for (EntityPlayer player : EntityUtils.getLoadedPlayers()) {
            if (player == mc.player)
                continue;
            if (player.isDead || player.getHealth() <= 0)
                continue;
            if (player.isInvisible() && !showInvisible.getValue())
                continue;
            if (player.isPlayerSleeping() && !showSleeping.getValue())
                continue;
            players.add(player);
        }
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (players.isEmpty())
            return;
        float partialTicks = event.getPartialTicks();
        RenderUtils.updateCameraPos(partialTicks);
        float lw = lineWidth.getValue().floatValue();
        if (boxes.getValue()) {
            EntityEspUtils.drawEntityBoxes(players, partialTicks, boxColor, 0.2f, 0.5f, 0.0, null, lw);
        }
        if (tracers.getValue()) {
            EntityEspUtils.drawEntityTracers(players, partialTicks, tracerColorFn, 0.5f, 0.5, lw);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        players.clear();
    }
}
