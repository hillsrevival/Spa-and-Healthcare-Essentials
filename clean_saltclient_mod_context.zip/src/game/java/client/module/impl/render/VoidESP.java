package client.module.impl.render;

import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.render.BlockEspUtils;
import client.utils.render.RenderUtils;
import client.utils.world.WorldUtils;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;

public class VoidESP extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting radius = new NumberSetting("Radius", 8.0, 2.0, 32.0);

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    private final BlockEspUtils.BlockScanner scanner = new BlockEspUtils.BlockScanner();

    private final BlockEspUtils.BoxBatch batch = new BlockEspUtils.BoxBatch();

    private final BlockEspUtils.Matcher matcher = new BlockEspUtils.Matcher() {

        @Override
        public int match(IBlockState state, int x, int y, int z) {
            if (state.getMaterial() == Material.AIR) {
                return 0;
            }
            boolean overVoid = true;
            for (int dy = 1; dy <= 5; dy++) {
                if (y - dy < 0)
                    break;
                if (!WorldUtils.isAir(x, y - dy, z)) {
                    overVoid = false;
                    break;
                }
            }
            return overVoid ? 1 : 0;
        }
    };

    public VoidESP() {
        super("VoidESP", Category.RENDER);
        setDescription("Highlights void areas");
        addSetting(radius);
        addSetting(lineWidth);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
        scanner.setChunksPerTick(2);
        scanner.setRescanIntervalTicks(40);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        int rad = radius.getValue().intValue();
        int chunkRange = (rad >> 4) + 1;
        int py = (int) Math.floor(mc.player.posY);
        int yMin = Math.max(0, py - 10);
        int yMax = Math.min(255, py + 10);
        scanner.update(mc.player.chunkCoordX, mc.player.chunkCoordZ, chunkRange, yMin, yMax, matcher);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (scanner.size() == 0)
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        final double px = mc.player.posX;
        final double pz = mc.player.posZ;
        final double rad = radius.getValue().doubleValue();
        final double rangeSq = rad * rad;
        batch.clear();
        scanner.forEachPosition(new BlockEspUtils.PositionVisitor() {

            @Override
            public void visit(int x, int y, int z, int tag) {
                double dx = x + 0.5 - px;
                double dz = z + 0.5 - pz;
                if (dx * dx + dz * dz > rangeSq)
                    return;
                batch.add(x, y, z, x + 1, y + 0.05, z + 1, 1.0f, 0.0f, 0.0f);
            }
        });
        BlockEspUtils.drawBatch(batch, 0.3f, 0.6f, lineWidth.getValue().floatValue());
    }

    @Override
    public void onDisable() {
        super.onDisable();
        scanner.clear();
        batch.clear();
    }
}
