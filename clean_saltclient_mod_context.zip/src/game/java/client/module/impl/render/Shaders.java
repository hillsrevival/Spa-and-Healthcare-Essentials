package client.module.impl.render;

import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.ImageData;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.lax1dude.eaglercraft.opengl.WorldRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.IResource;
import net.minecraft.util.ResourceLocation;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.Condition;
import java.io.Closeable;
import net.lax1dude.eaglercraft.IOUtils;
import java.util.Random;
import client.utils.render.RenderUtils;
import client.shader.ShaderPipeline;

public class Shaders extends Module {

    private static Shaders instance = null;

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ShaderPipeline pipeline = new ShaderPipeline();

    private net.minecraft.world.World lastWorld = null;

    private float lastYaw = Float.NaN;

    private float lastPitch = Float.NaN;

    private double lastPosX = Double.NaN;

    private double lastPosY = Double.NaN;

    private double lastPosZ = Double.NaN;

    private final ModeSetting skyMode = new ModeSetting("Sky", "BlackHole", "Galaxy", "BlackHole", "Off");

    private final NumberSetting skyOpacity = new NumberSetting("SkyOpacity", 0.85, 0.0, 1.0);

    private final NumberSetting skyAnimSpeed = new NumberSetting("SkyAnimSpeed", 1.0, 0.1, 5.0);

    private final BooleanSetting shootStars = new BooleanSetting("ShootingStars", true);

    private final NumberSetting starRate = new NumberSetting("StarRate", 0.008, 0.001, 0.05);

    private final BooleanSetting advanced = new BooleanSetting("Advanced", false);

    private final BooleanSetting bloom = new BooleanSetting("Bloom", true);

    private final BooleanSetting godRays = new BooleanSetting("GodRays", true);

    private final BooleanSetting chromaticAb = new BooleanSetting("ChromaticAb", true);

    private final BooleanSetting colorGrade = new BooleanSetting("ColorGrade", true);

    private final BooleanSetting fxaa = new BooleanSetting("FXAA", true);

    private final BooleanSetting motionBlur = new BooleanSetting("MotionBlur", false);

    private final BooleanSetting filmGrain = new BooleanSetting("FilmGrain", false);

    private final BooleanSetting sharpen = new BooleanSetting("Sharpen", true);

    private final BooleanSetting lensFlare = new BooleanSetting("LensFlare", true);

    private final NumberSetting bloomStrength = new NumberSetting("BloomStr", 0.5, 0.0, 2.0);

    private final NumberSetting bloomThreshold = new NumberSetting("BloomThresh", 0.7, 0.0, 1.0);

    private final NumberSetting bloomRadius = new NumberSetting("BloomRadius", 3.5, 0.5, 8.0);

    private final NumberSetting bloomPasses = new NumberSetting("BloomPasses", 4, 2, 6);

    private final NumberSetting godRayStr = new NumberSetting("GRStrength", 0.5, 0.0, 2.0);

    private final NumberSetting godRayDecay = new NumberSetting("GRDecay", 0.97, 0.9, 0.995);

    private final NumberSetting godRayDensity = new NumberSetting("GRDensity", 1.0, 0.1, 3.0);

    private final NumberSetting godRaySamples = new NumberSetting("GRSamples", 16, 8, 48);

    private final NumberSetting godRayThresh = new NumberSetting("GRThreshold", 0.8, 0.3, 1.0);

    private final NumberSetting chromaticStr = new NumberSetting("CAStrength", 0.003, 0.0, 0.04);

    private final ModeSetting chromaticMode = new ModeSetting("CAMode", "Radial", "Radial", "Directional");

    private final NumberSetting sat = new NumberSetting("Saturation", 1.15, 0.0, 2.0);

    private final NumberSetting bri = new NumberSetting("Brightness", 1.0, 0.5, 1.5);

    private final NumberSetting con = new NumberSetting("Contrast", 1.1, 0.5, 2.0);

    private final ModeSetting colorTint = new ModeSetting("ColorTint", "None", "None", "Warm", "Cool", "Vintage", "Cinematic", "Neon", "Sepia");

    private final NumberSetting colorTemp = new NumberSetting("ColorTemp", 0.0, -1.0, 1.0);

    private final NumberSetting fxaaSub = new NumberSetting("FXAASubpix", 0.25, 0.0, 2.0);

    private final NumberSetting fxaaThresh = new NumberSetting("FXAAThresh", 0.166, 0, 0.5);

    private final NumberSetting mbStr = new NumberSetting("MotionBlur Strength", 0.15, 0.0, 0.99);

    private final NumberSetting grainStr = new NumberSetting("GrainStr", 0.04, 0.0, 0.2);

    private final NumberSetting grainSpeed = new NumberSetting("GrainSpeed", 1.0, 0.1, 5.0);

    private final NumberSetting sharpenStr = new NumberSetting("SharpenStr", 0.3, 0.0, 1.0);

    private final NumberSetting flareStr = new NumberSetting("FlareStr", 0.4, 0.0, 2.0);

    private final NumberSetting flareWidth = new NumberSetting("FlareWidth", 8.0, 2.0, 20.0);

    private final NumberSetting gamma = new NumberSetting("Gamma", 1.0, 0.5, 2.5);

    private final ModeSetting toneMap = new ModeSetting("ToneMap", "Reinhard", "Reinhard", "None");

    private static final ResourceLocation GALAXY_TEX_RES = new ResourceLocation("textures/misc/Shaders_Galaxy.png");

    private static final ResourceLocation BLACKHOLE_TEX_RES = new ResourceLocation("textures/misc/Shaders_BlackHole.png");

    private ResourceLocation galaxyTex = null;

    private ResourceLocation blackholeTex = null;

    private int galaxyW = 0, galaxyH = 0;

    private int blackholeW = 0, blackholeH = 0;

    private boolean texturesLoaded = false;

    private long lastFrameTime = 0L;

    private boolean anyPostEnabled = false;

    private int lastConfigHash = 0;

    private int lastDisplayW = 0, lastDisplayH = 0;

    private static final int MAX_SHOOTING = 5;

    private final ShootingStar[] stars = new ShootingStar[MAX_SHOOTING];

    private final Random rng = new Random(42);

    private static class ShootingStar {

        boolean active = false;

        float x, y, vx, vy, life, maxLife, length;
    }

    public static boolean shouldReplaceSky() {
        return instance != null && instance.isToggled() && !"Off".equals(instance.skyMode.getValue());
    }

    public static boolean shouldEnhanceClouds() {
        return instance != null && instance.isToggled();
    }

    public static float[] getCloudEnhancement(float partialTicks) {
        if (instance == null || instance.mc.world == null)
            return null;
        float celestialAngle = instance.mc.world.getCelestialAngle(partialTicks);
        float dayFactor = (float) Math.cos(celestialAngle * 2.0f * Math.PI) * 0.5f + 0.5f;
        float r = 0.9f + dayFactor * 0.16f;
        float g = 0.95f + dayFactor * 0.05f;
        float b = 1.1f - dayFactor * 0.16f;
        float a = 0.96f;
        return new float[] { r, g, b, a };
    }

    public static boolean shouldCaptureScene() {
        return instance != null && instance.isToggled() && instance.anyPostEnabled;
    }

    public static void beginSceneCapture(int w, int h) {
        if (instance != null && instance.anyPostEnabled) {
            if (!instance.pipeline.init(w, h)) {
                instance.anyPostEnabled = false;
                GlStateManager.clear(16640);
                return;
            }
            instance.pipeline.beginSceneCapture();
        }
    }

    public static void endSceneCapture() {
        if (instance != null && instance.anyPostEnabled) {
            instance.pipeline.endSceneCapture();
        }
    }

    public static void applyPostProcess() {
        if (instance != null && instance.anyPostEnabled) {
            net.minecraft.world.World currentWorld = instance.mc.world;
            if (currentWorld != instance.lastWorld) {
                instance.pipeline.resetHistory();
                instance.lastWorld = currentWorld;
            }
            instance.pipeline.applyEffects();
        }
    }

    public static void renderCustomSky(int displayWidth, int displayHeight) {
        if (instance == null)
            return;
        instance.doRenderSky(displayWidth, displayHeight);
    }

    private ResourceLocation getCurrentTexture() {
        String m = skyMode.getValue();
        if (m.equals("Galaxy"))
            return galaxyTex;
        if (m.equals("BlackHole"))
            return blackholeTex;
        return null;
    }

    private int getCurrentTexW() {
        String m = skyMode.getValue();
        if (m.equals("Galaxy"))
            return galaxyW;
        if (m.equals("BlackHole"))
            return blackholeW;
        return 0;
    }

    private int getCurrentTexH() {
        String m = skyMode.getValue();
        if (m.equals("Galaxy"))
            return galaxyH;
        if (m.equals("BlackHole"))
            return blackholeH;
        return 0;
    }

    private void doRenderSky(int displayWidth, int displayHeight) {
        ResourceLocation tex = getCurrentTexture();
        int texW = getCurrentTexW();
        int texH = getCurrentTexH();
        if (tex == null || texW <= 0 || texH <= 0)
            return;
        float a = skyOpacity.getValue().floatValue();
        float w = displayWidth;
        float h = displayHeight;
        GlStateManager.disableFog();
        GlStateManager.matrixMode(5889);
        GlStateManager.pushMatrix();
        GlStateManager.loadIdentity();
        GlStateManager.ortho(0.0D, w, h, 0.0D, -1.0D, 1.0D);
        GlStateManager.matrixMode(5888);
        GlStateManager.pushMatrix();
        GlStateManager.loadIdentity();
        GlStateManager.enableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableDepth();
        GlStateManager.depthMask(false);
        mc.getTextureManager().bindTexture(tex);
        GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
        float fixedYaw = -33.0f * 0.01745329f;
        float panAmount = (float) Math.sin(fixedYaw) * 0.02f;
        float texAspect = (float) texW / (float) texH;
        float screenAspect = w / h;
        float u0, v0, u1, v1;
        if (screenAspect > texAspect) {
            float scale = screenAspect / texAspect;
            float crop = (scale - 1.0F) / 2.0F;
            u0 = crop + panAmount;
            v0 = 0.0F;
            u1 = 1.0F - crop + panAmount;
            v1 = 1.0F;
        } else {
            float scale = texAspect / screenAspect;
            float crop = (scale - 1.0F) / 2.0F;
            u0 = 0.0F + panAmount;
            v0 = crop;
            u1 = 1.0F + panAmount;
            v1 = 1.0F - crop;
        }
        u0 = Math.max(0.0F, Math.min(1.0F, u0));
        u1 = Math.max(0.0F, Math.min(1.0F, u1));
        v0 = Math.max(0.0F, Math.min(1.0F, v0));
        v1 = Math.max(0.0F, Math.min(1.0F, v1));
        int alphaInt = (int) (a * 255.0f);
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        wr.begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_TEX_COLOR);
        wr.pos(0, h, 0).tex(u0, v1).color(255, 255, 255, alphaInt).endVertex();
        wr.pos(w, h, 0).tex(u1, v1).color(255, 255, 255, alphaInt).endVertex();
        wr.pos(w, 0, 0).tex(u1, v0).color(255, 255, 255, alphaInt).endVertex();
        wr.pos(0, 0, 0).tex(u0, v0).color(255, 255, 255, alphaInt).endVertex();
        tessellator.draw();
        if (shootStars.getValue()) {
            GlStateManager.disableTexture2D();
            renderShootingStars(w, h, a);
        }
        GlStateManager.matrixMode(5889);
        GlStateManager.popMatrix();
        GlStateManager.matrixMode(5888);
        GlStateManager.popMatrix();
        GlStateManager.depthMask(true);
        GlStateManager.enableDepth();
        RenderUtils.restoreHUD();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    }

    private void renderShootingStars(float w, float h, float a) {
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        for (int i = 0; i < MAX_SHOOTING; i++) {
            ShootingStar ss = stars[i];
            if (ss == null || !ss.active)
                continue;
            float fade = ss.life / ss.maxLife;
            float len = ss.length * fade;
            float dx = -ss.vx * 0.0012f * len;
            float dy = -ss.vy * 0.0012f * len;
            float ssa = fade * a;
            float glowSz = 6.0f * fade;
            wr.begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
            wr.pos(ss.x - glowSz, ss.y - glowSz, 0).color(1, 1, 1, ssa * 0.9f).endVertex();
            wr.pos(ss.x + glowSz, ss.y - glowSz, 0).color(1, 1, 1, ssa * 0.9f).endVertex();
            wr.pos(ss.x + glowSz, ss.y + glowSz, 0).color(1, 1, 1, ssa * 0.9f).endVertex();
            wr.pos(ss.x - glowSz, ss.y + glowSz, 0).color(1, 1, 1, ssa * 0.9f).endVertex();
            t.draw();
            wr.begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
            for (int seg = 0; seg < 8; seg++) {
                float t1 = seg * 0.125f, t2 = (seg + 1) * 0.125f;
                float x1 = ss.x + dx * t1, y1 = ss.y + dy * t1;
                float x2 = ss.x + dx * t2, y2 = ss.y + dy * t2;
                float segA = ssa * (1.0f - t1 * 0.7f);
                float segW = Math.max(3.0f * (1.0f - t1 * 0.6f), 0.5f);
                wr.pos(x1 - segW, y1 - segW, 0).color(0.95f, 0.95f, 1.0f, segA).endVertex();
                wr.pos(x1 + segW, y1 - segW, 0).color(0.95f, 0.95f, 1.0f, segA).endVertex();
                wr.pos(x2 + segW, y2 - segW, 0).color(0.95f, 0.95f, 1.0f, segA * 0.6f).endVertex();
                wr.pos(x2 - segW, y2 - segW, 0).color(0.95f, 0.95f, 1.0f, segA * 0.6f).endVertex();
            }
            t.draw();
        }
    }

    public Shaders() {
        super("Shaders", Category.RENDER);
        setDescription("Shaders");
        instance = this;
        addSetting(skyMode);
        addSetting(bloom);
        addSetting(godRays);
        addSetting(chromaticAb);
        addSetting(colorGrade);
        addSetting(fxaa);
        addSetting(motionBlur);
        addSetting(filmGrain);
        addSetting(sharpen);
        addSetting(lensFlare);
        addSetting(bloomStrength);
        addSetting(godRayStr);
        addSetting(chromaticStr);
        addSetting(sat);
        addSetting(bri);
        addSetting(con);
        addSetting(mbStr);
        addSetting(sharpenStr);
        addSetting(flareStr);
        addSetting(advanced);
        skyOpacity.setVisibilityCondition(Condition.whenTrue(advanced));
        skyAnimSpeed.setVisibilityCondition(Condition.whenTrue(advanced));
        shootStars.setVisibilityCondition(Condition.whenTrue(advanced));
        starRate.setVisibilityCondition(Condition.whenTrue(advanced));
        addSetting(skyOpacity);
        addSetting(skyAnimSpeed);
        addSetting(shootStars);
        addSetting(starRate);
        bloomThreshold.setVisibilityCondition(Condition.whenTrue(advanced));
        bloomRadius.setVisibilityCondition(Condition.whenTrue(advanced));
        bloomPasses.setVisibilityCondition(Condition.whenTrue(advanced));
        addSetting(bloomThreshold);
        addSetting(bloomRadius);
        addSetting(bloomPasses);
        godRayDecay.setVisibilityCondition(Condition.whenTrue(advanced));
        godRayDensity.setVisibilityCondition(Condition.whenTrue(advanced));
        godRaySamples.setVisibilityCondition(Condition.whenTrue(advanced));
        godRayThresh.setVisibilityCondition(Condition.whenTrue(advanced));
        addSetting(godRayDecay);
        addSetting(godRayDensity);
        addSetting(godRaySamples);
        addSetting(godRayThresh);
        chromaticMode.setVisibilityCondition(Condition.whenTrue(advanced));
        addSetting(chromaticMode);
        colorTint.setVisibilityCondition(Condition.whenTrue(advanced));
        colorTemp.setVisibilityCondition(Condition.whenTrue(advanced));
        addSetting(colorTint);
        addSetting(colorTemp);
        fxaaSub.setVisibilityCondition(Condition.whenTrue(advanced));
        fxaaThresh.setVisibilityCondition(Condition.whenTrue(advanced));
        addSetting(fxaaSub);
        addSetting(fxaaThresh);
        grainStr.setVisibilityCondition(Condition.whenTrue(advanced));
        grainSpeed.setVisibilityCondition(Condition.whenTrue(advanced));
        addSetting(grainStr);
        addSetting(grainSpeed);
        flareWidth.setVisibilityCondition(Condition.whenTrue(advanced));
        addSetting(flareWidth);
        gamma.setVisibilityCondition(Condition.whenTrue(advanced));
        toneMap.setVisibilityCondition(Condition.whenTrue(advanced));
        addSetting(gamma);
        addSetting(toneMap);
        handles(HandlerType.UPDATE);
    }

    private void loadTextures() {
        if (texturesLoaded)
            return;
        texturesLoaded = true;
        try {
            IResource res = mc.getResourceManager().getResource(GALAXY_TEX_RES);
            ImageData d = ImageData.loadImageFile(res.getInputStream());
            if (d != null) {
                galaxyW = d.width;
                galaxyH = d.height;
                galaxyTex = mc.getTextureManager().getDynamicTextureLocation("sg", new DynamicTexture(d));
            }
            res.close();
        } catch (Exception e) {
        }
        try {
            IResource res = mc.getResourceManager().getResource(BLACKHOLE_TEX_RES);
            ImageData d = ImageData.loadImageFile(res.getInputStream());
            if (d != null) {
                blackholeW = d.width;
                blackholeH = d.height;
                blackholeTex = mc.getTextureManager().getDynamicTextureLocation("sb", new DynamicTexture(d));
            }
            res.close();
        } catch (Exception e) {
        }
    }

    private void syncPipelineConfig() {
        ShaderPipeline.Config c = pipeline.getConfig();
        c.bloomEnabled = bloom.getValue();
        c.godRaysEnabled = godRays.getValue();
        c.chromaticAbEnabled = chromaticAb.getValue();
        c.colorGradeEnabled = colorGrade.getValue();
        c.fxaaEnabled = fxaa.getValue();
        c.motionBlurEnabled = motionBlur.getValue();
        c.sharpenEnabled = sharpen.getValue();
        c.lensFlareEnabled = lensFlare.getValue();
        c.bloomStrength = bloomStrength.getValue().floatValue();
        c.bloomThreshold = bloomThreshold.getValue().floatValue();
        c.bloomRadius = bloomRadius.getValue().floatValue();
        c.bloomPasses = bloomPasses.getValue().intValue();
        c.godRayStrength = godRayStr.getValue().floatValue();
        c.godRayDecay = godRayDecay.getValue().floatValue();
        c.godRayDensity = godRayDensity.getValue().floatValue();
        c.godRaySamples = godRaySamples.getValue().intValue();
        if (mc.world != null && mc.player != null) {
            float ca = mc.world.getCelestialAngle(1.0f);
            float sunAngle = ca * 2.0f * 3.14159265f;
            float sunWorldX = -(float) Math.sin(sunAngle);
            float sunWorldY = (float) Math.cos(sunAngle);
            float yaw = mc.player.rotationYaw * 0.01745329f;
            float pitch = mc.player.rotationPitch * 0.01745329f;
            float rx = sunWorldX * (float) Math.cos(-yaw);
            float rz = -sunWorldX * (float) Math.sin(-yaw);
            float ry = sunWorldY;
            float ry2 = ry * (float) Math.cos(-pitch) - rz * (float) Math.sin(-pitch);
            float rz2 = ry * (float) Math.sin(-pitch) + rz * (float) Math.cos(-pitch);
            if (rz2 > 0.0f && mc.displayWidth > 0 && mc.displayHeight > 0) {
                float fov = mc.gameSettings.fovSetting;
                float aspect = (float) mc.displayWidth / (float) mc.displayHeight;
                float tanHalf = (float) Math.tan(fov * 0.01745329f * 0.5f);
                c.sunScreenX = Math.max(-1.0f, Math.min(2.0f, 0.5f + (rx / (rz2 * tanHalf * aspect)) * 0.5f));
                c.sunScreenY = Math.max(-1.0f, Math.min(2.0f, 0.5f - (ry2 / (rz2 * tanHalf)) * 0.5f));
            } else {
                c.sunScreenX = -10.0f;
                c.sunScreenY = -10.0f;
            }
        }
        c.chromaticStrength = chromaticStr.getValue().floatValue();
        c.saturation = sat.getValue().floatValue();
        c.brightness = bri.getValue().floatValue();
        c.contrast = con.getValue().floatValue();
        String tint = colorTint.getValue();
        if (tint.equals("Warm")) {
            c.colorTintR = 1.08f;
            c.colorTintG = 0.95f;
            c.colorTintB = 0.82f;
        } else if (tint.equals("Cool")) {
            c.colorTintR = 0.82f;
            c.colorTintG = 0.95f;
            c.colorTintB = 1.12f;
        } else if (tint.equals("Vintage")) {
            c.colorTintR = 1.12f;
            c.colorTintG = 1.0f;
            c.colorTintB = 0.82f;
        } else if (tint.equals("Cinematic")) {
            c.colorTintR = 0.95f;
            c.colorTintG = 0.95f;
            c.colorTintB = 1.12f;
            c.saturation = 0.88f;
            c.contrast = 1.2f;
        } else if (tint.equals("Neon")) {
            c.colorTintR = 1.1f;
            c.colorTintG = 0.9f;
            c.colorTintB = 1.15f;
            c.saturation = 1.5f;
        } else if (tint.equals("Sepia")) {
            c.colorTintR = 1.15f;
            c.colorTintG = 1.0f;
            c.colorTintB = 0.75f;
            c.saturation = 0.6f;
        } else {
            c.colorTintR = 1.0f;
            c.colorTintG = 1.0f;
            c.colorTintB = 1.0f;
        }
        float temp = colorTemp.getValue().floatValue();
        if (temp > 0.01f || temp < -0.01f) {
            c.colorTintR *= (1.0f + temp * 0.15f);
            c.colorTintB *= (1.0f - temp * 0.15f);
        }
        c.fxaaSubpixelQuality = fxaaSub.getValue().floatValue();
        c.fxaaEdgeThreshold = fxaaThresh.getValue().floatValue();
        c.fxaaEdgeThresholdMin = fxaaThresh.getValue().floatValue() * 0.5f;
        c.motionBlurStrength = mbStr.getValue().floatValue();
        if (c.motionBlurEnabled && mc.player != null && mc.world != null) {
            float yaw = mc.player.rotationYaw;
            float pitch = mc.player.rotationPitch;
            double px = mc.player.posX;
            double py = mc.player.posY;
            double pz = mc.player.posZ;
            if (!Float.isNaN(lastYaw)) {
                float dyaw = Math.abs(yaw - lastYaw);
                float dpitch = Math.abs(pitch - lastPitch);
                if (dyaw > 180.0f)
                    dyaw = 360.0f - dyaw;
                double dpos = Math.sqrt((px - lastPosX) * (px - lastPosX) + (py - lastPosY) * (py - lastPosY) + (pz - lastPosZ) * (pz - lastPosZ));
                if (dyaw < 0.5f && dpitch < 0.5f && dpos < 0.05) {
                    c.motionBlurStrength = 0.0f;
                }
            }
            lastYaw = yaw;
            lastPitch = pitch;
            lastPosX = px;
            lastPosY = py;
            lastPosZ = pz;
        } else {
            lastYaw = Float.NaN;
        }
        c.filmGrainStrength = filmGrain.getValue() ? grainStr.getValue().floatValue() : 0.0f;
        c.sharpenStrength = sharpenStr.getValue().floatValue();
        c.lensFlareStrength = flareStr.getValue().floatValue();
        c.lensFlareWidth = flareWidth.getValue().floatValue();
        c.gamma = gamma.getValue().floatValue();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        lastFrameTime = System.currentTimeMillis();
        for (int i = 0; i < MAX_SHOOTING; i++) stars[i] = new ShootingStar();
        loadTextures();
        anyPostEnabled = computePostEnabled();
        if (anyPostEnabled && mc.displayWidth > 0 && mc.displayHeight > 0) {
            syncPipelineConfig();
            pipeline.init(mc.displayWidth, mc.displayHeight);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        pipeline.destroy();
        anyPostEnabled = false;
    }

    private boolean computePostEnabled() {
        return bloom.getValue() || godRays.getValue() || chromaticAb.getValue() || colorGrade.getValue() || fxaa.getValue() || motionBlur.getValue() || filmGrain.getValue() || sharpen.getValue() || lensFlare.getValue() || Math.abs(gamma.getValue().floatValue() - 1.0f) > 0.01f;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        long now = System.currentTimeMillis();
        float dt = Math.min((now - lastFrameTime) * 0.001f, 0.1f);
        lastFrameTime = now;
        updateShootingStars(dt);
        boolean newPost = computePostEnabled();
        if (newPost != anyPostEnabled) {
            anyPostEnabled = newPost;
            if (anyPostEnabled) {
                syncPipelineConfig();
                lastConfigHash = computeConfigHash();
                pipeline.init(mc.displayWidth, mc.displayHeight);
                lastDisplayW = mc.displayWidth;
                lastDisplayH = mc.displayHeight;
            } else {
                pipeline.destroy();
            }
        } else if (anyPostEnabled) {
            int newHash = computeConfigHash();
            if (newHash != lastConfigHash) {
                syncPipelineConfig();
                lastConfigHash = newHash;
            }
            if (mc.displayWidth != lastDisplayW || mc.displayHeight != lastDisplayH) {
                pipeline.init(mc.displayWidth, mc.displayHeight);
                lastDisplayW = mc.displayWidth;
                lastDisplayH = mc.displayHeight;
            }
        }
    }

    private int computeConfigHash() {
        int h = 0;
        h = h * 31 + bloom.getValue().hashCode();
        h = h * 31 + godRays.getValue().hashCode();
        h = h * 31 + chromaticAb.getValue().hashCode();
        h = h * 31 + colorGrade.getValue().hashCode();
        h = h * 31 + fxaa.getValue().hashCode();
        h = h * 31 + motionBlur.getValue().hashCode();
        h = h * 31 + filmGrain.getValue().hashCode();
        h = h * 31 + sharpen.getValue().hashCode();
        h = h * 31 + lensFlare.getValue().hashCode();
        h = h * 31 + bloomStrength.getValue().hashCode();
        h = h * 31 + bloomThreshold.getValue().hashCode();
        h = h * 31 + bloomRadius.getValue().hashCode();
        h = h * 31 + bloomPasses.getValue().hashCode();
        h = h * 31 + godRayStr.getValue().hashCode();
        h = h * 31 + godRayDecay.getValue().hashCode();
        h = h * 31 + godRayDensity.getValue().hashCode();
        h = h * 31 + godRaySamples.getValue().hashCode();
        h = h * 31 + chromaticStr.getValue().hashCode();
        h = h * 31 + sat.getValue().hashCode();
        h = h * 31 + bri.getValue().hashCode();
        h = h * 31 + con.getValue().hashCode();
        h = h * 31 + mbStr.getValue().hashCode();
        h = h * 31 + grainStr.getValue().hashCode();
        h = h * 31 + sharpenStr.getValue().hashCode();
        h = h * 31 + flareStr.getValue().hashCode();
        h = h * 31 + flareWidth.getValue().hashCode();
        h = h * 31 + gamma.getValue().hashCode();
        h = h * 31 + skyOpacity.getValue().hashCode();
        return h;
    }

    private void updateShootingStars(float dt) {
        float w = mc.displayWidth;
        float h = mc.displayHeight;
        float rate = starRate.getValue().floatValue();
        for (int i = 0; i < MAX_SHOOTING; i++) {
            ShootingStar ss = stars[i];
            if (ss == null)
                continue;
            if (ss.active) {
                ss.x += ss.vx * dt;
                ss.y += ss.vy * dt;
                ss.life -= dt;
                if (ss.life <= 0 || ss.x > w + 100 || ss.y > h + 100)
                    ss.active = false;
            } else if (rng.nextFloat() < rate) {
                ss.active = true;
                ss.x = rng.nextFloat() * w * 0.6f;
                ss.y = rng.nextFloat() * h * 0.3f;
                ss.vx = 250 + rng.nextFloat() * 350;
                ss.vy = 100 + rng.nextFloat() * 180;
                ss.maxLife = 0.4f + rng.nextFloat() * 0.6f;
                ss.life = ss.maxLife;
                ss.length = 60 + rng.nextFloat() * 100;
            }
        }
    }
}
