package client.module.impl.render;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.event.events.NameFormatEvent;
import client.utils.misc.RomanNumeralUtil;
import client.utils.world.EnchantmentUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextFormatting;

public class NameTags extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting showHealth = new BooleanSetting("Show Health", true);

    private final BooleanSetting showEnchants = new BooleanSetting("Show Enchants", true);

    private final BooleanSetting showPing = new BooleanSetting("Show Ping", false);

    public NameTags() {
        super("NameTags", Category.RENDER);
        setDescription("Enhanced nametags with health and enchant info");
        addSetting(showHealth);
        addSetting(showEnchants);
        addSetting(showPing);
        handles(HandlerType.NAME_FORMAT);
    }

    @Override
    public void onNameFormat(NameFormatEvent event) {
        if (!nullCheck())
            return;
        if (!(event.getPlayer() instanceof EntityPlayer))
            return;
        EntityPlayer player = event.getPlayer();
        if (player == mc.player)
            return;
        StringBuilder sb = new StringBuilder();
        String originalName = event.getDisplayName();
        if (showHealth.getValue()) {
            float health = player.getHealth();
            String healthStr = String.format("%.0f", health);
            TextFormatting healthColor;
            if (health > 15)
                healthColor = TextFormatting.GREEN;
            else if (health > 8)
                healthColor = TextFormatting.YELLOW;
            else if (health > 0)
                healthColor = TextFormatting.RED;
            else
                healthColor = TextFormatting.DARK_RED;
            sb.append(healthColor.toString());
            sb.append(healthStr);
            sb.append(TextFormatting.WHITE.toString());
            sb.append(" ");
        }
        sb.append(originalName);
        if (showPing.getValue()) {
            try {
                net.minecraft.client.network.NetworkPlayerInfo info = mc.player.connection.getPlayerInfo(player.getUniqueID());
                int ping = info != null ? info.getResponseTime() : 0;
                sb.append(" ");
                sb.append(TextFormatting.GRAY.toString());
                sb.append(ping);
                sb.append("ms");
            } catch (Exception e) {
            }
        }
        if (showEnchants.getValue()) {
            ItemStack heldItem = player.getHeldItemMainhand();
            if (heldItem != null && !heldItem.func_190926_b()) {
                String enchants = formatEnchantments(heldItem);
                if (!enchants.isEmpty()) {
                    sb.append(TextFormatting.GRAY.toString());
                    sb.append(" [");
                    sb.append(enchants);
                    sb.append("]");
                }
            }
        }
        event.setDisplayName(sb.toString());
    }

    private String formatEnchantments(ItemStack stack) {
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        int sharp = EnchantmentUtil.getSharpness(stack);
        if (sharp > 0) {
            if (!first)
                sb.append(", ");
            sb.append("Sharp ");
            sb.append(RomanNumeralUtil.toRoman(sharp));
            first = false;
        }
        int fire = EnchantmentUtil.getFireAspect(stack);
        if (fire > 0) {
            if (!first)
                sb.append(", ");
            sb.append("Fire ");
            sb.append(RomanNumeralUtil.toRoman(fire));
            first = false;
        }
        int kb = EnchantmentUtil.getKnockback(stack);
        if (kb > 0) {
            if (!first)
                sb.append(", ");
            sb.append("KB ");
            sb.append(RomanNumeralUtil.toRoman(kb));
            first = false;
        }
        return sb.toString();
    }
}
