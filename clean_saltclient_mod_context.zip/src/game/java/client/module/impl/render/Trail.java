package client.module.impl.render;

import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import java.util.ArrayDeque;
import java.util.Deque;
import client.utils.render.RenderUtils;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;

public class Trail extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting length = new NumberSetting("Length", 30.0, 5.0, 100.0);

    private final NumberSetting red = new NumberSetting("Red", 0.3, 0.0, 1.0);

    private final NumberSetting green = new NumberSetting("Green", 0.5, 0.0, 1.0);

    private final NumberSetting blue = new NumberSetting("Blue", 1.0, 0.0, 1.0);

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    private final Deque<double[]> positions = new ArrayDeque<>();

    public Trail() {
        super("Trail", Category.RENDER);
        setDescription("Leaves a particle trail behind you");
        addSetting(length);
        addSetting(red);
        addSetting(green);
        addSetting(blue);
        addSetting(lineWidth);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        positions.addLast(new double[] { mc.player.posX, mc.player.posY, mc.player.posZ });
        int maxLen = length.getValue().intValue();
        while (positions.size() > maxLen) {
            positions.removeFirst();
        }
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (mc.player == null || positions.size() < 2)
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        RenderUtils.prepareGL();
        EaglercraftGPU.glLineWidth(lineWidth.getValue().floatValue());
        net.minecraft.client.renderer.Tessellator tess = net.minecraft.client.renderer.Tessellator.getInstance();
        net.lax1dude.eaglercraft.opengl.WorldRenderer buf = tess.getBuffer();
        float r = red.getValue().floatValue();
        float g = green.getValue().floatValue();
        float b = blue.getValue().floatValue();
        buf.begin(net.lax1dude.eaglercraft.opengl.RealOpenGLEnums.GL_LINES, net.minecraft.client.renderer.vertex.DefaultVertexFormats.POSITION);
        int i = 1;
        double[] prev = null;
        for (double[] curr : positions) {
            if (prev != null) {
                float alpha = (float) i / (float) positions.size() * 0.6f;
                net.lax1dude.eaglercraft.opengl.GlStateManager.color(r, g, b, alpha);
                buf.pos(prev[0] - RenderUtils.camX, prev[1] - RenderUtils.camY, prev[2] - RenderUtils.camZ).endVertex();
                buf.pos(curr[0] - RenderUtils.camX, curr[1] - RenderUtils.camY, curr[2] - RenderUtils.camZ).endVertex();
                i++;
            }
            prev = curr;
        }
        tess.draw();
        RenderUtils.restoreGL();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        positions.clear();
    }
}
