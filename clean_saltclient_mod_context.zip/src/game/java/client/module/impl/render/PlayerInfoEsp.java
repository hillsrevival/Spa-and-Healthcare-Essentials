package client.module.impl.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import client.event.listeners.RenderListener;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.render.RenderUtils;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.lax1dude.eaglercraft.vector.Matrix4f;
import net.lax1dude.eaglercraft.vector.Vector4f;
import java.util.ArrayList;
import java.util.List;
import client.utils.EntityUtils;

public class PlayerInfoEsp extends Module {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private final List<EntityPlayer> cachedPlayers = new ArrayList<>();

    private final List<float[]> screenPos = new ArrayList<>();

    private final NumberSetting renderDist = new NumberSetting("RenderDist", 64.0, 16.0, 128.0);

    private final BooleanSetting self = new BooleanSetting("Self", false);

    private final NumberSetting itemScale = new NumberSetting("ItemScale", 1.0, 0.5, 2.0);

    private static final float[] MODELVIEW = new float[16];

    private static final float[] PROJECTION = new float[16];

    private static final int[] VIEWPORT = new int[4];

    public PlayerInfoEsp() {
        super("PlayerInfoEsp", Category.RENDER);
        setDescription("Shows additional info above players");
        addSetting(renderDist);
        addSetting(self);
        addSetting(itemScale);
        handles(HandlerType.UPDATE, HandlerType.RENDER, HandlerType.GUI_RENDER);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        cachedPlayers.clear();
        screenPos.clear();
        double maxDist = renderDist.getValue() * renderDist.getValue();
        for (EntityPlayer player : EntityUtils.getLoadedPlayers()) {
            if (player == mc.player && !self.getValue())
                continue;
            if (player.isDead || player.getHealth() <= 0)
                continue;
            if (player.isInvisibleToPlayer(mc.player))
                continue;
            if (mc.player.getDistanceSqToEntity(player) > maxDist)
                continue;
            cachedPlayers.add(player);
            screenPos.add(null);
        }
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (cachedPlayers.isEmpty())
            return;
        float partialTicks = event.getPartialTicks();
        RenderUtils.updateCameraPos(partialTicks);
        GlStateManager.getFloat(RealOpenGLEnums.GL_MODELVIEW_MATRIX, MODELVIEW);
        GlStateManager.getFloat(RealOpenGLEnums.GL_PROJECTION_MATRIX, PROJECTION);
        EaglercraftGPU.glGetInteger(RealOpenGLEnums.GL_VIEWPORT, VIEWPORT);
        Matrix4f mv = new Matrix4f();
        Matrix4f pj = new Matrix4f();
        mv.load(MODELVIEW);
        pj.load(PROJECTION);
        Matrix4f mvp = Matrix4f.mul(pj, mv, null);
        for (int i = 0; i < cachedPlayers.size(); i++) {
            EntityPlayer player = cachedPlayers.get(i);
            double x = player.prevPosX + (player.posX - player.prevPosX) * partialTicks - RenderUtils.camX;
            double y = player.prevPosY + (player.posY - player.prevPosY) * partialTicks - RenderUtils.camY;
            double z = player.prevPosZ + (player.posZ - player.prevPosZ) * partialTicks - RenderUtils.camZ;
            float yOffset = player.height + 0.55f;
            if (player.isSneaking())
                yOffset += 0.4f;
            float[] coords = worldToScreen((float) x, (float) (y + yOffset), (float) z, mvp);
            double dist = Math.sqrt((float) x * (float) x + (float) y * (float) y + (float) z * (float) z);
            if (coords != null) {
                screenPos.set(i, new float[] { coords[0], coords[1], (float) dist });
            }
        }
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (cachedPlayers.isEmpty())
            return;
        for (int i = 0; i < cachedPlayers.size(); i++) {
            float[] coords = screenPos.get(i);
            if (coords == null)
                continue;
            float dist = coords[2];
            float baseScale = itemScale.getValue().floatValue();
            float distFactor = 2.0f / (1.0f + dist * 0.15f);
            float finalScale = baseScale * Math.max(distFactor, 0.2f);
            int itemSize = (int) (16.0f * finalScale);
            int spacing = Math.max(1, (int) (2.0f * finalScale));
            EntityPlayer player = cachedPlayers.get(i);
            ItemStack helmet = player.inventory.armorItemInSlot(3);
            ItemStack chestplate = player.inventory.armorItemInSlot(2);
            ItemStack leggings = player.inventory.armorItemInSlot(1);
            ItemStack boots = player.inventory.armorItemInSlot(0);
            ItemStack heldItem = player.getHeldItemMainhand();
            ItemStack[] items = { helmet, chestplate, leggings, boots, heldItem };
            int count = 0;
            for (ItemStack stack : items) {
                if (!stack.func_190926_b())
                    count++;
            }
            if (count == 0)
                continue;
            int padding = Math.max(1, (int) (2.0f * finalScale));
            int totalWidth = count * itemSize + (count - 1) * spacing;
            int bgWidth = totalWidth + padding * 2;
            int bgHeight = itemSize + padding * 2;
            int sx = (int) (coords[0] - bgWidth / 2.0f);
            int sy = (int) coords[1];
            ScaledResolution sr = mc.scaledResolution;
            if (sr == null)
                sr = new ScaledResolution(mc);
            if (sx + bgWidth < 0 || sx > sr.getScaledWidth() || sy + bgHeight < 0 || sy > sr.getScaledHeight()) {
                continue;
            }
            GlStateManager.disableDepth();
            RenderUtils.prepareHUD();
            net.minecraft.client.renderer.Tessellator tess = net.minecraft.client.renderer.Tessellator.getInstance();
            net.lax1dude.eaglercraft.opengl.WorldRenderer buf = tess.getBuffer();
            buf.begin(7, net.minecraft.client.renderer.vertex.DefaultVertexFormats.POSITION_COLOR);
            float left = sx;
            float top = sy;
            float right = sx + bgWidth;
            float bottom = sy + bgHeight;
            buf.pos(left, bottom, 0).color(0, 0, 0, 0.5f).endVertex();
            buf.pos(right, bottom, 0).color(0, 0, 0, 0.5f).endVertex();
            buf.pos(right, top, 0).color(0, 0, 0, 0.5f).endVertex();
            buf.pos(left, top, 0).color(0, 0, 0, 0.5f).endVertex();
            tess.draw();
            GlStateManager.enableTexture2D();
            GlStateManager.disableDepth();
            GlStateManager.disableLighting();
            mc.getRenderItem().zLevel = -100.0f;
            float renderItemSize = 16.0f * finalScale;
            float renderItemSpacing = 2.0f * finalScale;
            float renderPadding = 2.0f * finalScale;
            float renderX = sx + renderPadding;
            float renderY = sy + renderPadding;
            for (ItemStack stack : items) {
                if (!stack.func_190926_b()) {
                    GlStateManager.pushMatrix();
                    GlStateManager.translate(renderX + renderItemSize * 0.5f, renderY + renderItemSize * 0.5f, 0);
                    GlStateManager.scale(finalScale, finalScale, finalScale);
                    mc.getRenderItem().renderItemAndEffectIntoGUI(stack, (int) (-8), (int) (-8));
                    GlStateManager.popMatrix();
                    renderX += renderItemSize + renderItemSpacing;
                }
            }
            mc.getRenderItem().zLevel = 0.0f;
            GlStateManager.enableDepth();
            GlStateManager.enableLighting();
            GlStateManager.disableBlend();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        }
    }

    private static float[] worldToScreen(float x, float y, float z, Matrix4f mvp) {
        Vector4f worldPos = new Vector4f(x, y, z, 1.0f);
        Vector4f clipPos = Matrix4f.transform(mvp, worldPos, null);
        if (clipPos.w <= 0.0f)
            return null;
        float ndcX = clipPos.x / clipPos.w;
        float ndcY = clipPos.y / clipPos.w;
        float px = VIEWPORT[0] + (VIEWPORT[2] * (ndcX + 1.0f) * 0.5f);
        float py = VIEWPORT[1] + (VIEWPORT[3] * (ndcY + 1.0f) * 0.5f);
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        int sf = sr.getScaleFactor();
        float guiX = px / sf;
        float guiY = sr.getScaledHeight() - py / sf;
        return new float[] { guiX, guiY };
    }

    @Override
    public void onDisable() {
        super.onDisable();
        cachedPlayers.clear();
        screenPos.clear();
    }
}
