package client.module.impl.render;

import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.render.BlockEspUtils;
import client.utils.render.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.tileentity.TileEntityHopper;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.tileentity.TileEntityDropper;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.tileentity.TileEntityBrewingStand;

public class StorageESP extends Module {

    private static final float[] RGB_TRAPPED_CHEST = { 178f / 255f, 51f / 255f, 0f };

    private static final float[] RGB_CHEST = { 153f / 255f, 102f / 255f, 0f };

    private static final float[] RGB_ENDER_CHEST = { 51f / 255f, 0f, 204f / 255f };

    private static final float[] RGB_HOPPER = { 128f / 255f, 128f / 255f, 128f / 255f };

    private static final float[] RGB_DISPENSER = { 102f / 255f, 102f / 255f, 102f / 255f };

    private static final float[] RGB_DROPPER = { 89f / 255f, 89f / 255f, 89f / 255f };

    private static final float[] RGB_FURNACE = { 153f / 255f, 51f / 255f, 0f };

    private static final float[] RGB_BREWING_STAND = { 102f / 255f, 0f, 153f / 255f };

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 32.0, 8.0, 64.0);

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    private final BlockEspUtils.BoxBatch batch = new BlockEspUtils.BoxBatch();

    public StorageESP() {
        super("StorageESP", Category.RENDER);
        setDescription("Highlights storage blocks through walls");
        addSetting(range);
        addSetting(lineWidth);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) {
            batch.clear();
            return;
        }
        batch.clear();
        double px = mc.player.posX;
        double py = mc.player.posY;
        double pz = mc.player.posZ;
        double rangeSq = range.getValue().doubleValue();
        rangeSq *= rangeSq;
        for (TileEntity te : mc.world.loadedTileEntityList) {
            if (te == null)
                continue;
            BlockPos pos = te.getPos();
            double dx = pos.x + 0.5 - px;
            double dy = pos.y + 0.5 - py;
            double dz = pos.z + 0.5 - pz;
            if (dx * dx + dy * dy + dz * dz > rangeSq)
                continue;
            float[] rgb;
            if (te instanceof TileEntityChest) {
                rgb = mc.world.getBlockState(pos).getBlock() == net.minecraft.init.Blocks.TRAPPED_CHEST ? RGB_TRAPPED_CHEST : RGB_CHEST;
            } else if (te instanceof TileEntityEnderChest) {
                rgb = RGB_ENDER_CHEST;
            } else if (te instanceof TileEntityHopper) {
                rgb = RGB_HOPPER;
            } else if (te instanceof TileEntityDispenser) {
                rgb = RGB_DISPENSER;
            } else if (te instanceof TileEntityDropper) {
                rgb = RGB_DROPPER;
            } else if (te instanceof TileEntityFurnace) {
                rgb = RGB_FURNACE;
            } else if (te instanceof TileEntityBrewingStand) {
                rgb = RGB_BREWING_STAND;
            } else {
                continue;
            }
            batch.add(pos.x, pos.y, pos.z, pos.x + 1, pos.y + 1, pos.z + 1, rgb[0], rgb[1], rgb[2]);
        }
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (batch.isEmpty())
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        BlockEspUtils.drawBatch(batch, 0.2f, 0.5f, lineWidth.getValue().floatValue());
    }

    @Override
    public void onDisable() {
        super.onDisable();
        batch.clear();
    }
}
