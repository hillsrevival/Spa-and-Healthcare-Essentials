package client.module.impl.render;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.render.ClientFontRenderer;
import client.utils.render.RenderUtils;
import client.utils.EntityUtils;

public class EntityOwner extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final List<EntityTameable> tameables = new ArrayList<>();

    public EntityOwner() {
        super("EntityOwner", Category.RENDER);
        setDescription("Shows who owns or tamed an entity");
        handles(HandlerType.UPDATE, HandlerType.RENDER);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        tameables.clear();
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (!(entity instanceof EntityTameable))
                continue;
            EntityTameable tameable = (EntityTameable) entity;
            if (!tameable.isTamed())
                continue;
            if (tameable.getOwnerId() == null)
                continue;
            tameables.add(tameable);
        }
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (tameables.isEmpty())
            return;
        float partialTicks = event.getPartialTicks();
        for (EntityTameable tameable : tameables) {
            String ownerName = getOwnerName(tameable);
            if (ownerName == null)
                continue;
            double x = tameable.prevPosX + (tameable.posX - tameable.prevPosX) * partialTicks;
            double y = tameable.prevPosY + (tameable.posY - tameable.prevPosY) * partialTicks + tameable.height + 0.35;
            double z = tameable.prevPosZ + (tameable.posZ - tameable.prevPosZ) * partialTicks;
            float viewerYaw = mc.getRenderManager().playerViewY;
            float viewerPitch = mc.getRenderManager().playerViewX;
            EntityRenderer.drawNameplate(ClientFontRenderer.getFontRenderer(), "\u00a7e" + ownerName, (float) x, (float) y, (float) z, 0, viewerYaw, viewerPitch, false, tameable.isSneaking());
        }
    }

    private String getOwnerName(EntityTameable tameable) {
        try {
            net.minecraft.entity.EntityLivingBase owner = tameable.getOwner();
            if (owner instanceof EntityPlayer) {
                return ((EntityPlayer) owner).getName();
            }
            if (owner != null) {
                return owner.getName();
            }
        } catch (Exception e) {
            return null;
        }
        if (tameable.getOwnerId() != null) {
            String uuid = tameable.getOwnerId().toString();
            return "~" + uuid.substring(0, 8);
        }
        return null;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        tameables.clear();
    }
}
