package client.module.impl.render;

import client.Client;
import client.module.Category;
import client.module.HandlerType;
import client.module.Module;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.MathHelper;

public class FreeLook extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting sensitivity = new NumberSetting("Sensitivity", 1.0, 0.1, 2.0);

    private float savedYaw;

    private float savedPitch;

    private float cameraYaw;

    private float cameraPitch;

    private boolean initialized = false;

    public FreeLook() {
        super("FreeLook", Category.RENDER);
        setDescription("Look around without rotating your camera");
        addSetting(sensitivity);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player != null) {
            savedYaw = mc.player.rotationYaw;
            savedPitch = mc.player.rotationPitch;
            cameraYaw = savedYaw;
            cameraPitch = savedPitch;
            initialized = true;
            Client c = Client.INSTANCE;
            c.scaffoldYaw = savedYaw;
            c.scaffoldPitch = savedPitch;
            c.renderYaw = cameraYaw;
            c.renderPitch = cameraPitch;
            c.renderRotationOverride = true;
        }
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || !initialized)
            return;
        float dyaw = mc.player.rotationYaw - savedYaw;
        float dpitch = mc.player.rotationPitch - savedPitch;
        float sens = sensitivity.getValue().floatValue();
        cameraYaw += dyaw * sens;
        cameraPitch = MathHelper.clamp(cameraPitch + dpitch * sens, -90.0F, 90.0F);
        Client c = Client.INSTANCE;
        c.renderYaw = cameraYaw;
        c.renderPitch = cameraPitch;
        mc.player.rotationYaw = savedYaw;
        mc.player.rotationPitch = savedPitch;
        mc.player.prevRotationYaw = savedYaw;
        mc.player.prevRotationPitch = savedPitch;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        Client c = Client.INSTANCE;
        c.renderRotationOverride = false;
        c.renderYaw = 0.0F;
        c.renderPitch = 0.0F;
        initialized = false;
    }
}
