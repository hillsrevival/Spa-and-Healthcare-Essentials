package client.module.impl.render;

import client.module.NumberSetting;
import java.util.HashMap;
import java.util.Map;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.ColorSetting;
import client.utils.render.BlockEspUtils;
import client.utils.render.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityMobSpawner;
import net.minecraft.util.math.BlockPos;

public class SpawnerESP extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting tracers = new BooleanSetting("Tracers", false);

    private final ModeSetting tracerColor = new ModeSetting("Tracer Color", "Default", "Default", "Red", "Green", "Blue", "Yellow", "Purple", "Pink", "Orange", "White", "Cyan", "Rainbow");

    private final ColorSetting customColor = new ColorSetting("Custom Color", 0.0);

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    private final ModeSetting spawnerType = new ModeSetting("Type", "All", "All", "Zombie", "Skeleton", "Spider", "Cave Spider", "Blaze", "Creeper", "Magma Cube", "Pigman", "Silverfish", "Slime", "Witch", "Guardian", "Elder Guardian", "Wither Skeleton");

    private final Map<Long, String> typeCache = new HashMap<Long, String>();

    private Object lastWorld;

    private final BlockEspUtils.BoxBatch batch = new BlockEspUtils.BoxBatch();

    private final BlockEspUtils.ColorFn boxColor = new BlockEspUtils.ColorFn() {

        @Override
        public void colorOf(int index, int tag, float[] out3) {
            out3[0] = 0.9f;
            out3[1] = 0.2f;
            out3[2] = 0.3f;
        }
    };

    private final BlockEspUtils.ColorFn tracerColorFn = new BlockEspUtils.ColorFn() {

        @Override
        public void colorOf(int index, int tag, float[] out3) {
            float[] c = RenderUtils.resolveTracerColor(tracerColor.getValue(), customColor.getRGBFloat(), index);
            if (c != null) {
                out3[0] = c[0];
                out3[1] = c[1];
                out3[2] = c[2];
            } else {
                out3[0] = 1.0f;
                out3[1] = 0.3f;
                out3[2] = 0.4f;
            }
        }
    };

    public SpawnerESP() {
        super("SpawnerESP", Category.RENDER);
        setDescription("Highlights mob spawners through walls");
        addSetting(tracers);
        addSetting(tracerColor);
        addSetting(customColor);
        addSetting(spawnerType);
        addSetting(lineWidth);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) {
            batch.clear();
            return;
        }
        if (lastWorld != mc.world) {
            typeCache.clear();
            lastWorld = mc.world;
        }
        batch.clear();
        String filter = spawnerType.getValue();
        for (TileEntity te : mc.world.loadedTileEntityList) {
            if (!(te instanceof TileEntityMobSpawner))
                continue;
            BlockPos pos = te.getPos();
            if (!filter.equals("All") && !matchesFilter(pos, filter)) {
                continue;
            }
            batch.add(pos.x, pos.y, pos.z, pos.x + 1, pos.y + 1, pos.z + 1, 0.9f, 0.2f, 0.3f);
        }
    }

    private boolean matchesFilter(BlockPos pos, String filter) {
        String name = typeCache.get(pos.toLong());
        if (name == null) {
            name = readSpawnerMobName(pos);
            if (name == null)
                return false;
            typeCache.put(pos.toLong(), name);
        }
        String normalized = getNormalizedFilter();
        String lower = name.toLowerCase();
        return lower.equals(normalized) || lower.endsWith(normalized) || lower.contains(normalized);
    }

    private String normalizedFilterCache = null;

    private String normalizedFilterRaw = null;

    private String getNormalizedFilter() {
        String raw = spawnerType.getValue();
        if (raw != normalizedFilterRaw) {
            normalizedFilterRaw = raw;
            normalizedFilterCache = raw.replace(" ", "_").toLowerCase();
        }
        return normalizedFilterCache;
    }

    private String readSpawnerMobName(BlockPos pos) {
        TileEntity te = mc.world.getTileEntity(pos);
        if (!(te instanceof TileEntityMobSpawner))
            return null;
        NBTTagCompound nbt = te.writeToNBT(new NBTTagCompound());
        if (nbt.hasKey("SpawnData", 10)) {
            NBTTagCompound spawnData = nbt.getCompoundTag("SpawnData");
            String entityId = spawnData.getString("id");
            if (entityId.isEmpty())
                return null;
            return entityId.contains(":") ? entityId.substring(entityId.indexOf(":") + 1) : entityId;
        }
        return null;
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (batch.isEmpty())
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        BlockEspUtils.drawBatch(batch, 0.2f, 0.5f, lineWidth.getValue().floatValue());
        if (tracers.getValue()) {
            BlockEspUtils.drawBatchTracers(batch, tracerColorFn, 0.5f, lineWidth.getValue().floatValue());
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        batch.clear();
    }
}
