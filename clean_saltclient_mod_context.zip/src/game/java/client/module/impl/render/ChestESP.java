package client.module.impl.render;

import client.module.NumberSetting;
import java.util.ArrayList;
import java.util.List;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.ColorSetting;
import client.utils.render.BlockEspUtils;
import client.utils.render.EntityEspUtils;
import client.utils.render.RenderUtils;
import net.minecraft.entity.Entity;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraft.entity.item.EntityMinecartChest;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import client.utils.world.WorldUtils;
import client.utils.EntityUtils;

public class ChestESP extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting tracers = new BooleanSetting("Tracers", false);

    private final ModeSetting tracerColor = new ModeSetting("Tracer Color", "Default", "Default", "Red", "Green", "Blue", "Yellow", "Purple", "Pink", "Orange", "White", "Cyan", "Rainbow");

    private final ColorSetting customColor = new ColorSetting("Custom Color", 0.0);

    private final BooleanSetting showChests = new BooleanSetting("Normal Chests", true);

    private final BooleanSetting showTrapped = new BooleanSetting("Trapped Chests", true);

    private final BooleanSetting showEnder = new BooleanSetting("Ender Chests", true);

    private final BooleanSetting showShulkers = new BooleanSetting("Shulker Boxes", true);

    private final BooleanSetting showMinecarts = new BooleanSetting("Chest Minecarts", true);

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    private static final int TAG_NORMAL = 1;

    private static final int TAG_TRAPPED = 2;

    private static final int TAG_ENDER = 3;

    private static final int TAG_SHULKER = 4;

    private static final int TAG_MINECART = 5;

    private final BlockEspUtils.BoxBatch batch = new BlockEspUtils.BoxBatch();

    private final List<EntityMinecartChest> minecarts = new ArrayList<EntityMinecartChest>();

    private int chestCount = 0;

    private final BlockEspUtils.ColorFn tracerColorFn = new BlockEspUtils.ColorFn() {

        @Override
        public void colorOf(int index, int tag, float[] out3) {
            float[] c = RenderUtils.resolveTracerColor(tracerColor.getValue(), customColor.getRGBFloat(), index);
            if (c != null) {
                out3[0] = c[0];
                out3[1] = c[1];
                out3[2] = c[2];
            } else {
                tagColor(tag, out3);
            }
        }
    };

    private final EntityEspUtils.EntityColorFn cartColor = new EntityEspUtils.EntityColorFn() {

        @Override
        public void colorOf(Entity entity, int index, float[] out3) {
            out3[0] = 0.0f;
            out3[1] = 0.8f;
            out3[2] = 0.0f;
        }
    };

    private final EntityEspUtils.EntityColorFn cartTracerColor = new EntityEspUtils.EntityColorFn() {

        @Override
        public void colorOf(Entity entity, int index, float[] out3) {
            float[] c = RenderUtils.resolveTracerColor(tracerColor.getValue(), customColor.getRGBFloat(), index);
            if (c != null) {
                out3[0] = c[0];
                out3[1] = c[1];
                out3[2] = c[2];
            } else {
                out3[0] = 0.0f;
                out3[1] = 0.8f;
                out3[2] = 0.0f;
            }
        }
    };

    public ChestESP() {
        super("ChestESP", Category.RENDER);
        setDescription("Highlights chests and storage blocks through walls");
        addSetting(tracers);
        addSetting(tracerColor);
        addSetting(customColor);
        addSetting(showChests);
        addSetting(showTrapped);
        addSetting(showEnder);
        addSetting(showShulkers);
        addSetting(showMinecarts);
        addSetting(lineWidth);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        batch.clear();
        minecarts.clear();
        for (TileEntity te : mc.world.loadedTileEntityList) {
            if (te instanceof TileEntityChest) {
                TileEntityChest chest = (TileEntityChest) te;
                BlockPos pos = te.getPos();
                if (isDoubleChestOther(chest))
                    continue;
                AxisAlignedBB bb = getBlockBox(pos);
                bb = expandDoubleChest(chest, bb);
                if (WorldUtils.getBlock(pos) == Blocks.TRAPPED_CHEST) {
                    if (showTrapped.getValue()) {
                        batch.addTagged(bb.minX, bb.minY, bb.minZ, bb.maxX, bb.maxY, bb.maxZ, (byte) TAG_TRAPPED, 1.0f, 0.5f, 0.0f);
                    }
                } else {
                    if (showChests.getValue()) {
                        batch.addTagged(bb.minX, bb.minY, bb.minZ, bb.maxX, bb.maxY, bb.maxZ, (byte) TAG_NORMAL, 0.0f, 1.0f, 0.0f);
                    }
                }
            } else if (te instanceof TileEntityEnderChest) {
                if (!showEnder.getValue())
                    continue;
                BlockPos pos = te.getPos();
                batch.addTagged(pos.x, pos.y, pos.z, pos.x + 1, pos.y + 1, pos.z + 1, (byte) TAG_ENDER, 0.0f, 1.0f, 1.0f);
            } else if (te instanceof TileEntityShulkerBox) {
                if (!showShulkers.getValue())
                    continue;
                BlockPos pos = te.getPos();
                batch.addTagged(pos.x, pos.y, pos.z, pos.x + 1, pos.y + 1, pos.z + 1, (byte) TAG_SHULKER, 0.56f, 0.28f, 0.72f);
            }
        }
        if (showMinecarts.getValue()) {
            for (Entity entity : EntityUtils.getLoadedEntities()) {
                if (entity instanceof EntityMinecartChest) {
                    minecarts.add((EntityMinecartChest) entity);
                }
            }
        }
        chestCount = batch.size() + minecarts.size();
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (chestCount == 0)
            return;
        float partialTicks = event.getPartialTicks();
        RenderUtils.updateCameraPos(partialTicks);
        if (!batch.isEmpty()) {
            BlockEspUtils.drawBatch(batch, 0.2f, 0.5f, lineWidth.getValue().floatValue());
            if (tracers.getValue()) {
                BlockEspUtils.drawBatchTracers(batch, tracerColorFn, 0.5f, lineWidth.getValue().floatValue());
            }
        }
        if (!minecarts.isEmpty()) {
            EntityEspUtils.drawEntityBoxes(minecarts, partialTicks, cartColor, 0.2f, 0.5f, 0.05, null, lineWidth.getValue().floatValue());
            if (tracers.getValue()) {
                EntityEspUtils.drawEntityTracers(minecarts, partialTicks, cartTracerColor, 0.5f, 0.35, lineWidth.getValue().floatValue());
            }
        }
    }

    private static void tagColor(int tag, float[] out3) {
        switch(tag) {
            case TAG_TRAPPED:
                out3[0] = 1.0f;
                out3[1] = 0.5f;
                out3[2] = 0.0f;
                break;
            case TAG_ENDER:
                out3[0] = 0.0f;
                out3[1] = 1.0f;
                out3[2] = 1.0f;
                break;
            case TAG_SHULKER:
                out3[0] = 0.56f;
                out3[1] = 0.28f;
                out3[2] = 0.72f;
                break;
            case TAG_MINECART:
                out3[0] = 0.0f;
                out3[1] = 0.8f;
                out3[2] = 0.0f;
                break;
            default:
                out3[0] = 0.0f;
                out3[1] = 1.0f;
                out3[2] = 0.0f;
                break;
        }
    }

    private AxisAlignedBB getBlockBox(BlockPos pos) {
        return new AxisAlignedBB(pos.x, pos.y, pos.z, pos.x + 1, pos.y + 1, pos.z + 1);
    }

    private boolean isDoubleChestOther(TileEntityChest chest) {
        try {
            if (chest.adjacentChestXPos != null || chest.adjacentChestZPos != null) {
                return true;
            }
        } catch (Exception e) {
        }
        return false;
    }

    private AxisAlignedBB expandDoubleChest(TileEntityChest chest, AxisAlignedBB bb) {
        try {
            if (chest.adjacentChestXNeg != null) {
                BlockPos pos2 = chest.adjacentChestXNeg.getPos();
                return bb.union(getBlockBox(pos2));
            } else if (chest.adjacentChestZNeg != null) {
                BlockPos pos2 = chest.adjacentChestZNeg.getPos();
                return bb.union(getBlockBox(pos2));
            }
        } catch (Exception e) {
        }
        return bb;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        batch.clear();
        minecarts.clear();
        chestCount = 0;
    }
}
