package client.module.impl.render;

import net.minecraft.client.Minecraft;
import net.minecraft.init.MobEffects;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;

public class NoOverlay extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public NoOverlay() {
        super("NoOverlay", Category.RENDER);
        setDescription("Removes screen overlays like fire and water");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (mc.player.isPotionActive(MobEffects.BLINDNESS)) {
            mc.player.removePotionEffect(MobEffects.BLINDNESS);
        }
        if (mc.player.isPotionActive(MobEffects.NAUSEA)) {
            mc.player.removePotionEffect(MobEffects.NAUSEA);
        }
    }
}
