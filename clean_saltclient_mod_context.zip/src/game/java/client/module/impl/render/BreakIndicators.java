package client.module.impl.render;

import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;
import client.utils.render.ClientFontRenderer;

public class BreakIndicators extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting scale = new NumberSetting("Scale", 1.0, 0.5, 2.0);

    public BreakIndicators() {
        super("BreakIndicators", Category.RENDER);
        setDescription("Shows break progress above blocks being mined by others");
        addSetting(scale);
        handles(HandlerType.RENDER);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (mc.playerController == null)
            return;
        if (mc.objectMouseOver == null || mc.objectMouseOver.typeOfHit != net.minecraft.util.math.RayTraceResult.Type.BLOCK)
            return;
        BlockPos pos = mc.objectMouseOver.getBlockPos();
        float progress = mc.playerController.curBlockDamageMP;
        if (progress <= 0)
            return;
        double px = mc.getRenderManager().viewerPosX;
        double py = mc.getRenderManager().viewerPosY;
        double pz = mc.getRenderManager().viewerPosZ;
        float r, g, b;
        if (progress < 0.5f) {
            r = 1.0f;
            g = progress * 2.0f;
            b = 0.0f;
        } else {
            r = (1.0f - progress) * 2.0f;
            g = 1.0f;
            b = 0.0f;
        }
        float alpha = 0.15f + progress * 0.35f;
        mc.renderGlobal.drawSelectionBoundingBox(new net.minecraft.util.math.AxisAlignedBB(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1), r, g, b, alpha);
        int pct = (int) (progress * 100);
        String text = pct + "%";
        double screenX = projectX(pos.getX() + 0.5, pos.getY() + 1.3, pos.getZ() + 0.5);
        double screenY = projectY(pos.getX() + 0.5, pos.getY() + 1.3, pos.getZ() + 0.5);
        if (screenX > 0 && screenY > 0) {
            net.minecraft.client.gui.ScaledResolution sr = mc.scaledResolution;
            if (sr == null)
                sr = new net.minecraft.client.gui.ScaledResolution(mc);
            float sx = (float) (screenX / sr.getScaleFactor());
            float sy = (float) (screenY / sr.getScaleFactor());
            ClientFontRenderer.drawCenteredStringWithShadow(text, (int) sx, (int) sy, 0xFFFFFF);
        }
    }

    private double projectX(double x, double y, double z) {
        double dx = x - mc.getRenderManager().viewerPosX;
        double dy = y - mc.getRenderManager().viewerPosY;
        double dz = z - mc.getRenderManager().viewerPosZ;
        float yaw = mc.getRenderManager().playerViewY * 0.017453292f;
        float pitch = mc.getRenderManager().playerViewX * 0.017453292f;
        double cosYaw = Math.cos(-yaw);
        double sinYaw = Math.sin(-yaw);
        double cosPitch = Math.cos(pitch);
        double sinPitch = Math.sin(pitch);
        double relX = dx * cosYaw - dz * sinYaw;
        double relZ = dx * sinYaw + dz * cosYaw;
        double relY = dy * cosPitch - relZ * sinPitch;
        relZ = dy * sinPitch + relZ * cosPitch;
        if (relZ < 0.1)
            return -1;
        return mc.displayWidth / 2.0 + relX / relZ * (mc.displayWidth / 2.0);
    }

    private double projectY(double x, double y, double z) {
        double dx = x - mc.getRenderManager().viewerPosX;
        double dy = y - mc.getRenderManager().viewerPosY;
        double dz = z - mc.getRenderManager().viewerPosZ;
        float yaw = mc.getRenderManager().playerViewY * 0.017453292f;
        float pitch = mc.getRenderManager().playerViewX * 0.017453292f;
        double cosYaw = Math.cos(-yaw);
        double sinYaw = Math.sin(-yaw);
        double cosPitch = Math.cos(pitch);
        double sinPitch = Math.sin(pitch);
        double relX = dx * cosYaw - dz * sinYaw;
        double relZ = dx * sinYaw + dz * cosYaw;
        double relY = dy * cosPitch - relZ * sinPitch;
        relZ = dy * sinPitch + relZ * cosPitch;
        if (relZ < 0.1)
            return -1;
        return mc.displayHeight / 2.0 - relY / relZ * (mc.displayHeight / 2.0);
    }
}
