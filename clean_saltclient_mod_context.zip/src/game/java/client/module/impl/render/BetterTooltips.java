package client.module.impl.render;

import net.minecraft.client.Minecraft;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import java.util.Map;
import client.utils.render.ClientFontRenderer;

public class BetterTooltips extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting showDurability = new BooleanSetting("Durability", true);

    private final BooleanSetting showEnchants = new BooleanSetting("Enchantments", true);

    private final BooleanSetting showItemId = new BooleanSetting("ItemId", false);

    private final NumberSetting hudX = new NumberSetting("X", 5.0, 0.0, 500.0);

    private final NumberSetting hudY = new NumberSetting("Y", 80.0, 0.0, 500.0);

    public BetterTooltips() {
        super("BetterTooltips", Category.RENDER);
        setDescription("Better item tooltips with enchantment and NBT info");
        addSetting(showDurability);
        addSetting(showEnchants);
        addSetting(showItemId);
        addSetting(hudX);
        addSetting(hudY);
        handles(HandlerType.GUI_RENDER);
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held == null || held.func_190926_b())
            return;
        int x = hudX.getValue().intValue();
        int y = hudY.getValue().intValue();
        String itemName = held.getDisplayName();
        ClientFontRenderer.drawStringWithShadow(itemName, x, y, 0xFFFFFFFF);
        y += ClientFontRenderer.fontHeight() + 4;
        try {
            if (showDurability.getValue() && held.isItemStackDamageable()) {
                int maxDmg = held.getMaxDamage();
                if (maxDmg > 0) {
                    int dmg = held.getItemDamage();
                    int remaining = maxDmg - dmg;
                    float pct = (float) remaining / (float) maxDmg;
                    int r, g;
                    if (pct > 0.5f) {
                        r = (int) ((1.0f - pct) * 2.0f * 255);
                        g = 255;
                    } else {
                        r = 255;
                        g = (int) (pct * 2.0f * 255);
                    }
                    int color = (r << 16) | (g << 8) | 0xFF;
                    int pctInt = (int) (pct * 100.0f);
                    String text = "Durability: " + remaining + "/" + maxDmg + " (" + pctInt + "%)";
                    ClientFontRenderer.drawStringWithShadow(text, x, y, color);
                    y += ClientFontRenderer.fontHeight() + 2;
                    if (held.getItem() instanceof ItemArmor) {
                        ItemArmor armor = (ItemArmor) held.getItem();
                        String protText = "Protection: " + armor.damageReduceAmount;
                        ClientFontRenderer.drawStringWithShadow(protText, x, y, 0xFFAAAAFF);
                        y += ClientFontRenderer.fontHeight() + 2;
                    }
                }
            }
            if (showEnchants.getValue()) {
                Map<Enchantment, Integer> enchants = EnchantmentHelper.getEnchantments(held);
                if (enchants != null && !enchants.isEmpty()) {
                    for (Map.Entry<Enchantment, Integer> entry : enchants.entrySet()) {
                        Enchantment ench = entry.getKey();
                        int level = entry.getValue();
                        String enchName;
                        try {
                            enchName = ench.getTranslatedName(level);
                        } catch (Exception e) {
                            enchName = "Enchant " + level;
                        }
                        ClientFontRenderer.drawStringWithShadow(enchName, x, y, 0xFFAAFFAA);
                        y += ClientFontRenderer.fontHeight() + 1;
                    }
                    y += 2;
                }
            }
            if (showItemId.getValue()) {
                try {
                    int id = net.minecraft.item.Item.getIdFromItem(held.getItem());
                    String idText = "ID: " + id;
                    if (held.getMetadata() > 0) {
                        idText += ":" + held.getMetadata();
                    }
                    ClientFontRenderer.drawStringWithShadow(idText, x, y, 0xFFCCCCCC);
                } catch (Exception e) {
                    ClientFontRenderer.drawStringWithShadow("ID: ?", x, y, 0xFFCCCCCC);
                }
            }
        } catch (Exception e) {
        }
    }
}
