package client.module.impl.render;

import client.module.NumberSetting;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.ColorSetting;
import client.utils.misc.ChatUtils;
import client.utils.render.BlockEspUtils;
import client.utils.render.RenderUtils;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;

public class PortalESP extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting showNether = new BooleanSetting("Nether Portals", true);

    private final BooleanSetting showEnd = new BooleanSetting("End Portals", true);

    private final BooleanSetting showEndFrames = new BooleanSetting("End Frames", false);

    private final BooleanSetting tracers = new BooleanSetting("Tracers", true);

    private final ModeSetting tracerColor = new ModeSetting("Tracer Color", "Default", "Default", "Red", "Green", "Blue", "Yellow", "Purple", "Pink", "Orange", "White", "Cyan", "Rainbow");

    private final ColorSetting customColor = new ColorSetting("Custom Color", 0.0);

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    private final BlockEspUtils.BlockScanner scanner = new BlockEspUtils.BlockScanner();

    private final BlockEspUtils.Matcher matcher = new BlockEspUtils.Matcher() {

        @Override
        public int match(IBlockState state, int x, int y, int z) {
            Block block = state.getBlock();
            if (block == Blocks.PORTAL) {
                return showNether.getValue() ? 1 : 0;
            }
            if (block == Blocks.END_PORTAL) {
                return showEnd.getValue() ? 2 : 0;
            }
            if (block == Blocks.END_PORTAL_FRAME) {
                return showEndFrames.getValue() ? 3 : 0;
            }
            return 0;
        }
    };

    private final BlockEspUtils.ColorFn boxColor = new BlockEspUtils.ColorFn() {

        @Override
        public void colorOf(int index, int tag, float[] out3) {
            switch(tag) {
                case 2:
                    out3[0] = 0.0f;
                    out3[1] = 1.0f;
                    out3[2] = 0.0f;
                    break;
                case 3:
                    out3[0] = 1.0f;
                    out3[1] = 1.0f;
                    out3[2] = 0.0f;
                    break;
                default:
                    out3[0] = 0.6f;
                    out3[1] = 0.2f;
                    out3[2] = 1.0f;
                    break;
            }
        }
    };

    private final BlockEspUtils.ColorFn tracerColorFn = new BlockEspUtils.ColorFn() {

        @Override
        public void colorOf(int index, int tag, float[] out3) {
            float[] c = RenderUtils.resolveTracerColor(tracerColor.getValue(), customColor.getRGBFloat(), index);
            if (c != null) {
                out3[0] = c[0];
                out3[1] = c[1];
                out3[2] = c[2];
            } else {
                boxColor.colorOf(index, tag, out3);
            }
        }
    };

    public PortalESP() {
        super("PortalESP", Category.RENDER);
        setDescription("Highlights nether portal frames through walls");
        addSetting(showNether);
        addSetting(showEnd);
        addSetting(showEndFrames);
        addSetting(tracers);
        addSetting(tracerColor);
        addSetting(customColor);
        addSetting(lineWidth);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
        scanner.setChunksPerTick(3);
        scanner.setRescanIntervalTicks(100);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        scanner.clear();
        ChatUtils.message("PortalESP: Scanning for portals...");
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        scanner.update(mc.player.chunkCoordX, mc.player.chunkCoordZ, 8, 0, 255, matcher);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (scanner.size() == 0)
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        BlockEspUtils.drawScannerBoxes(scanner, boxColor, 0.25f, 0.6f, lineWidth.getValue().floatValue());
        if (tracers.getValue()) {
            BlockEspUtils.drawScannerTracers(scanner, tracerColorFn, 0.5f, lineWidth.getValue().floatValue());
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        scanner.clear();
    }
}
