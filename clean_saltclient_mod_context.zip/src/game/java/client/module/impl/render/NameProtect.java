package client.module.impl.render;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.entity.player.EntityPlayer;
import client.event.listeners.ChatInputListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.EntityUtils;

public class NameProtect extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public NameProtect() {
        super("NameProtect", Category.RENDER);
        setDescription("Hides player names in chat and tab");
        handles(HandlerType.CHAT_INPUT);
    }

    @Override
    public void onChatInput(ChatInputListener.ChatInputEvent event) {
        if (!nullCheck())
            return;
        ITextComponent original = event.getComponent();
        if (original == null)
            return;
        String unformatted = original.getUnformattedText();
        List<String> names = getPlayerNames();
        boolean anyMatch = false;
        for (String name : names) {
            if (unformatted.contains(name)) {
                anyMatch = true;
                break;
            }
        }
        if (!anyMatch)
            return;
        ITextComponent censored = censorComponent(original, names);
        event.setComponent(censored);
    }

    private ITextComponent censorComponent(ITextComponent component, List<String> names) {
        if (component instanceof TextComponentString) {
            String text = ((TextComponentString) component).getText();
            String censored = censorNames(text, names);
            if (!censored.equals(text)) {
                TextComponentString result = new TextComponentString(censored);
                result.setStyle(component.getStyle().createShallowCopy());
                for (ITextComponent sibling : component.getSiblings()) {
                    result.appendSibling(censorComponent(sibling, names));
                }
                return result;
            }
        }
        if (component instanceof TextComponentTranslation) {
            TextComponentTranslation trans = (TextComponentTranslation) component;
            String resolved = trans.getUnformattedComponentText();
            String censored = censorNames(resolved, names);
            if (!censored.equals(resolved)) {
                TextComponentString result = new TextComponentString(censored);
                result.setStyle(component.getStyle().createShallowCopy());
                for (ITextComponent sibling : component.getSiblings()) {
                    result.appendSibling(censorComponent(sibling, names));
                }
                return result;
            }
        }
        ITextComponent copy = component.createCopy();
        copy.getSiblings().clear();
        for (ITextComponent sibling : component.getSiblings()) {
            copy.appendSibling(censorComponent(sibling, names));
        }
        return copy;
    }

    private static String stars(int len) {
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) sb.append('*');
        return sb.toString();
    }

    private static String censorNames(String text, List<String> names) {
        for (String name : names) {
            if (!text.contains(name))
                continue;
            text = safeReplace(text, name);
        }
        return text;
    }

    private static String safeReplace(String text, String playerName) {
        String replacement = stars(playerName.length());
        StringBuilder result = new StringBuilder();
        int len = playerName.length();
        int i = 0;
        while (i < text.length()) {
            if (i + 1 < text.length() && text.charAt(i) == '\u00a7') {
                result.append(text.charAt(i));
                result.append(text.charAt(i + 1));
                i += 2;
                continue;
            }
            if (i + len <= text.length() && text.substring(i, i + len).equals(playerName)) {
                boolean beforeOk = (i == 0 || !Character.isLetterOrDigit(text.charAt(i - 1)));
                boolean afterOk = (i + len >= text.length() || !Character.isLetterOrDigit(text.charAt(i + len)));
                if (beforeOk && afterOk) {
                    result.append(replacement);
                    i += len;
                    continue;
                }
            }
            result.append(text.charAt(i));
            i++;
        }
        return result.toString();
    }

    private static List<String> getPlayerNames() {
        List<String> names = new ArrayList<>();
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world != null) {
            for (EntityPlayer p : EntityUtils.getLoadedPlayers()) {
                if (p != null && p.getName() != null && !p.getName().isEmpty()) {
                    names.add(p.getName());
                }
            }
        }
        if (mc.player != null && mc.player.connection != null) {
            for (NetworkPlayerInfo info : mc.player.connection.getPlayerInfoMap()) {
                String name = info.getGameProfile().getName();
                if (name != null && !name.isEmpty() && !names.contains(name)) {
                    names.add(name);
                }
            }
        }
        return names;
    }

    public static String censorString(String text) {
        Module mod = client.module.ModuleManager.getModuleByName("NameProtect");
        if (mod == null || !mod.isToggled())
            return text;
        if (text == null || text.isEmpty())
            return text;
        List<String> names = getPlayerNames();
        if (names.isEmpty())
            return text;
        return censorNames(text, names);
    }

    public static String censorAnyName(String formattedName) {
        Module mod = client.module.ModuleManager.getModuleByName("NameProtect");
        if (mod == null || !mod.isToggled())
            return formattedName;
        if (formattedName == null || formattedName.isEmpty())
            return formattedName;
        String stripped = TextFormatting.getTextWithoutFormattingCodes(formattedName);
        if (stripped == null || stripped.isEmpty())
            return formattedName;
        String stars = stars(stripped.length());
        return formattedName.replace(stripped, stars);
    }
}
