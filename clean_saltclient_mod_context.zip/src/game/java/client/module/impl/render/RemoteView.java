package client.module.impl.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import client.event.listeners.PlayerMoveListener;
import client.event.listeners.SetOpaqueCubeListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.ChatUtils;
import client.utils.EntityUtils;

public class RemoteView extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private Entity targetEntity = null;

    private double origPosX;

    private double origPosY;

    private double origPosZ;

    private float origRotationYaw;

    private float origRotationPitch;

    private boolean wasInvisible = false;

    public RemoteView() {
        super("RemoteView", Category.RENDER);
        setDescription("View the world from another player's perspective");
        handles(HandlerType.UPDATE, HandlerType.PLAYER_MOVE, HandlerType.SET_OPAQUE_CUBE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null || mc.world == null) {
            toggle();
            return;
        }
        Entity closest = null;
        double closestDist = Double.MAX_VALUE;
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (entity == mc.player)
                continue;
            if (!(entity instanceof EntityLiving))
                continue;
            if (entity.isDead)
                continue;
            double dist = mc.player.getDistanceToEntity(entity);
            if (dist < closestDist && dist <= 64.0) {
                closestDist = dist;
                closest = entity;
            }
        }
        if (closest == null) {
            ChatUtils.error("No entity found nearby!");
            toggle();
            return;
        }
        targetEntity = closest;
        origPosX = mc.player.posX;
        origPosY = mc.player.posY;
        origPosZ = mc.player.posZ;
        origRotationYaw = mc.player.rotationYaw;
        origRotationPitch = mc.player.rotationPitch;
        wasInvisible = targetEntity.isInvisible();
        targetEntity.setInvisible(true);
        mc.player.noClip = true;
        ChatUtils.message("Now viewing " + targetEntity.getName() + ".");
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (targetEntity == null || targetEntity.isDead) {
            ChatUtils.error("Target entity lost!");
            toggle();
            return;
        }
        mc.player.copyLocationAndAnglesFrom(targetEntity);
        mc.player.motionX = 0.0;
        mc.player.motionY = 0.0;
        mc.player.motionZ = 0.0;
        targetEntity.setInvisible(true);
        mc.player.noClip = true;
        mc.player.fallDistance = 0.0f;
        mc.player.onGround = false;
    }

    @Override
    public void onPlayerMove(PlayerMoveListener.PlayerMoveEvent event) {
        if (mc.player == null)
            return;
        mc.player.noClip = true;
    }

    @Override
    public void onSetOpaqueCube(SetOpaqueCubeListener.SetOpaqueCubeEvent event) {
        event.setCancelled(true);
    }

    @Override
    public void onDisable() {
        if (mc.player != null) {
            mc.player.setPositionAndUpdate(origPosX, origPosY, origPosZ);
            mc.player.rotationYaw = origRotationYaw;
            mc.player.rotationPitch = origRotationPitch;
            mc.player.noClip = false;
            mc.player.motionX = 0.0;
            mc.player.motionY = 0.0;
            mc.player.motionZ = 0.0;
            if (mc.renderGlobal != null) {
                mc.renderGlobal.loadRenderers();
            }
        }
        if (targetEntity != null) {
            ChatUtils.message("No longer viewing " + targetEntity.getName() + ".");
            targetEntity.setInvisible(wasInvisible);
            targetEntity = null;
        }
        ChatUtils.message("RemoteView disabled");
        super.onDisable();
    }
}
