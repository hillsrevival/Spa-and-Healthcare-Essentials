package client.module.impl.render;

import client.module.BooleanSetting;
import client.module.Category;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.Module;
import client.module.NumberSetting;
import client.module.StringSetting;
import client.utils.render.FontManager;

public class FontSettings extends Module {

    private final ModeSetting font = new ModeSetting("Font", "Clean", FontManager.STYLES);
    private final StringSetting custom = new StringSetting("CustomName", "Segoe UI");
    private final BooleanSetting bold = new BooleanSetting("Bold", false);
    private final BooleanSetting italic = new BooleanSetting("Italic", false);
    private final NumberSetting size = new NumberSetting("Size", 0.95, 0.7, 1.15);

    public FontSettings() {
        super("Font", Category.RENDER);
        setDescription("Replaces the font of all text in the client. Custom uses any font installed on your PC");
        addSetting(font);
        addSetting(custom);
        addSetting(bold);
        addSetting(italic);
        addSetting(size);
        handles(HandlerType.UPDATE);
    }

    private void push() {
        FontManager.request(font.getValue(), custom.getValue(), bold.getValue(), italic.getValue(), size.getValue());
        FontManager.pump();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        push();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        FontManager.reset();
        FontManager.pump();
    }

    @Override
    public void onUpdate() {
        push();
    }
}
