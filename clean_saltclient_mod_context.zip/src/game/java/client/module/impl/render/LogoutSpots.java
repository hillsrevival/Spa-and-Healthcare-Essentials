package client.module.impl.render;

import client.module.NumberSetting;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.utils.render.ClientFontRenderer;
import client.utils.render.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import java.util.ArrayList;
import java.util.List;
import client.utils.EntityUtils;

public class LogoutSpots extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting nametag = new BooleanSetting("Nametag", true);

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    private final List<String> spotNames = new ArrayList<>();

    private final List<double[]> spots = new ArrayList<>();

    private final List<String> currentNames = new ArrayList<>();

    private final List<double[]> currentPos = new ArrayList<>();

    public LogoutSpots() {
        super("LogoutSpots", Category.RENDER);
        setDescription("Marks locations of players when they disconnect");
        addSetting(nametag);
        addSetting(lineWidth);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        List<String> newNames = new ArrayList<>();
        List<double[]> newPos = new ArrayList<>();
        for (Object obj : EntityUtils.getLoadedEntities()) {
            if (!(obj instanceof EntityPlayer))
                continue;
            EntityPlayer player = (EntityPlayer) obj;
            if (player == mc.player)
                continue;
            String name = player.getName();
            newNames.add(name);
            newPos.add(new double[] { player.posX, player.posY, player.posZ });
        }
        for (int i = 0; i < currentNames.size(); i++) {
            String prevName = currentNames.get(i);
            boolean stillHere = false;
            for (int j = 0; j < newNames.size(); j++) {
                if (newNames.get(j).equals(prevName)) {
                    stillHere = true;
                    break;
                }
            }
            if (!stillHere) {
                for (int j = spotNames.size() - 1; j >= 0; j--) {
                    if (spotNames.get(j).equals(prevName)) {
                        spotNames.remove(j);
                        spots.remove(j);
                    }
                }
                spotNames.add(prevName);
                spots.add(currentPos.get(i));
            }
        }
        for (int i = spotNames.size() - 1; i >= 0; i--) {
            for (int j = 0; j < newNames.size(); j++) {
                if (spotNames.get(i).equals(newNames.get(j))) {
                    spotNames.remove(i);
                    spots.remove(i);
                    break;
                }
            }
        }
        currentNames.clear();
        currentPos.clear();
        currentNames.addAll(newNames);
        currentPos.addAll(newPos);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (spots.isEmpty())
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        RenderUtils.prepareGL();
        net.lax1dude.eaglercraft.opengl.EaglercraftGPU.glLineWidth(lineWidth.getValue().floatValue());
        for (int i = 0; i < spots.size(); i++) {
            double[] pos = spots.get(i);
            AxisAlignedBB box = new AxisAlignedBB(pos[0] - 0.5, pos[1], pos[2] - 0.5, pos[0] + 0.5, pos[1] + 1.8, pos[2] + 0.5).offset(-RenderUtils.camX, -RenderUtils.camY, -RenderUtils.camZ);
            RenderUtils.drawSolidBox(box, 1.0f, 0.2f, 0.2f, 0.2f);
            RenderUtils.drawOutlinedBox(box, 1.0f, 0.3f, 0.3f, 0.7f);
        }
        RenderUtils.restoreGL();
        if (nametag.getValue()) {
            float viewY = mc.getRenderManager().playerViewY;
            float viewX = mc.getRenderManager().playerViewX;
            for (int i = 0; i < spots.size(); i++) {
                double[] pos = spots.get(i);
                net.minecraft.client.renderer.EntityRenderer.drawNameplate(ClientFontRenderer.getFontRenderer(), spotNames.get(i), (float) pos[0], (float) pos[1] + 2.0f, (float) pos[2], 0, viewY, viewX, false, false);
            }
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        spots.clear();
        spotNames.clear();
        currentNames.clear();
        currentPos.clear();
    }
}
