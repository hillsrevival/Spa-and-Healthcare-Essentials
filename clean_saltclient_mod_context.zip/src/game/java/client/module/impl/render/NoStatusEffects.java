package client.module.impl.render;

import client.module.Category;
import client.module.Module;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;

public class NoStatusEffects extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting blindness = new BooleanSetting("Blindness", true);

    private final BooleanSetting nausea = new BooleanSetting("Nausea", true);

    private final BooleanSetting portal = new BooleanSetting("Portal", true);

    public NoStatusEffects() {
        super("NoStatusEffects", Category.RENDER);
        setDescription("Hides status effect icons from HUD");
        addSetting(blindness);
        addSetting(nausea);
        addSetting(portal);
    }

    public boolean isNauseaSuppressed() {
        return isToggled() && nausea.getValue();
    }

    public boolean isPortalSuppressed() {
        return isToggled() && portal.getValue();
    }

    public boolean isBlindnessSuppressed() {
        return isToggled() && blindness.getValue();
    }
}
