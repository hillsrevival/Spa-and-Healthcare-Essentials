package client.module.impl.render;

import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.render.BlockEspUtils;
import client.utils.render.RenderUtils;
import client.utils.world.WorldUtils;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;

public class TunnelESP extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 32, 8, 64);

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0);

    private final BlockEspUtils.BlockScanner scanner = new BlockEspUtils.BlockScanner();

    private final BlockEspUtils.BoxBatch batch = new BlockEspUtils.BoxBatch();

    private final BlockEspUtils.Matcher matcher = new BlockEspUtils.Matcher() {

        @Override
        public int match(IBlockState state, int x, int y, int z) {
            if (state.getMaterial() != Material.AIR) {
                return 0;
            }
            if (!WorldUtils.isAir(x, y + 1, z) && !WorldUtils.isAir(x, y + 2, z)) {
                return 0;
            }
            int solidSides = 0;
            if (WorldUtils.isSolid(x, y, z - 1))
                solidSides++;
            if (WorldUtils.isSolid(x, y, z + 1))
                solidSides++;
            if (WorldUtils.isSolid(x + 1, y, z))
                solidSides++;
            if (WorldUtils.isSolid(x - 1, y, z))
                solidSides++;
            if (WorldUtils.isSolid(x, y - 1, z))
                solidSides++;
            return solidSides >= 3 ? 1 : 0;
        }
    };

    public TunnelESP() {
        super("TunnelESP", Category.RENDER);
        setDescription("Highlights tunnels");
        addSetting(range);
        addSetting(lineWidth);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
        scanner.setChunksPerTick(2);
        scanner.setRescanIntervalTicks(40);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        int r = range.getValue().intValue();
        int chunkRange = (r >> 4) + 1;
        int py = (int) Math.floor(mc.player.posY);
        int yMin = Math.max(0, py - r / 4);
        int yMax = Math.min(255, py + r / 4);
        scanner.update(mc.player.chunkCoordX, mc.player.chunkCoordZ, chunkRange, yMin, yMax, matcher);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (scanner.size() == 0)
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        final double px = mc.player.posX;
        final double py = mc.player.posY;
        final double pz = mc.player.posZ;
        final double r = range.getValue().doubleValue();
        final double rangeSq = r * r;
        batch.clear();
        scanner.forEachPosition(new BlockEspUtils.PositionVisitor() {

            @Override
            public void visit(int x, int y, int z, int tag) {
                double dx = x + 0.5 - px;
                double dy = y + 0.5 - py;
                double dz = z + 0.5 - pz;
                if (dx * dx + dy * dy + dz * dz > rangeSq)
                    return;
                batch.add(x, y, z, x + 1, y + 1, z + 1, 0.5f, 0.5f, 0.0f);
            }
        });
        BlockEspUtils.drawBatch(batch, 0.0f, 0.4f, lineWidth.getValue().floatValue());
    }

    @Override
    public void onDisable() {
        super.onDisable();
        scanner.clear();
        batch.clear();
    }
}
