package client.module.impl.render;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;

public class NoRender extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting fire = new BooleanSetting("Fire", true);

    private final BooleanSetting portal = new BooleanSetting("Portal", true);

    private final BooleanSetting pumpkin = new BooleanSetting("Pumpkin", true);

    public NoRender() {
        super("NoRender", Category.RENDER);
        setDescription("Skips rendering specific entities or block types");
        addSetting(fire);
        addSetting(portal);
        addSetting(pumpkin);
        handles(HandlerType.UPDATE);
    }

    public boolean isFireSuppressed() {
        return isToggled() && fire.getValue();
    }

    public boolean isPortalSuppressed() {
        return isToggled() && portal.getValue();
    }

    public boolean isPumpkinSuppressed() {
        return isToggled() && pumpkin.getValue();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (isFireSuppressed() && mc.player.isBurning()) {
            mc.player.extinguish();
        }
    }
}
