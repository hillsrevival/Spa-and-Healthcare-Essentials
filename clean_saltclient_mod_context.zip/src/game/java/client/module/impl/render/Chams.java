package client.module.impl.render;

import client.event.listeners.RenderListener;
import client.event.events.PreRenderLivingEvent;
import client.event.events.PostRenderLivingEvent;
import client.module.Category;
import client.module.ColorSetting;
import client.module.Condition;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.NumberSetting;
import client.module.Setting;
import client.utils.render.RenderUtils;
import java.util.function.Predicate;
import net.minecraft.client.Minecraft;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;

public class Chams extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting players = new BooleanSetting("Players", true);

    private final BooleanSetting showInvisible = new BooleanSetting("Show Invisible", true);

    private final ModeSetting chamsMode = new ModeSetting("Chams Mode", "Textured", "Flat", "Textured", "Wireframe", "Skeleton");

    private final BooleanSetting glow = new BooleanSetting("Glow", true);

    private final NumberSetting glowStrength = new NumberSetting("Glow Strength", 0.5, 0.1, 1.0);

    private final NumberSetting glowLayers = new NumberSetting("Glow Layers", 3.0, 1.0, 6.0);

    private final ColorSetting glowColor = new ColorSetting("Glow Color", 0.0);

    private final NumberSetting occRed = new NumberSetting("Occ Red", 1.0, 0.0, 1.0);

    private final NumberSetting occGreen = new NumberSetting("Occ Green", 0.0, 0.0, 1.0);

    private final NumberSetting occBlue = new NumberSetting("Occ Blue", 0.0, 0.0, 1.0);

    private final NumberSetting occAlpha = new NumberSetting("Occ Alpha", 0.3, 0.0, 1.0);

    private final NumberSetting visRed = new NumberSetting("Vis Red", 0.0, 0.0, 1.0);

    private final NumberSetting visGreen = new NumberSetting("Vis Green", 1.0, 0.0, 1.0);

    private final NumberSetting visBlue = new NumberSetting("Vis Blue", 0.0, 0.0, 1.0);

    private final NumberSetting visAlpha = new NumberSetting("Vis Alpha", 0.15, 0.0, 1.0);

    private final ColorSetting skeletonColor = new ColorSetting("Skeleton Color", 0.0);

    private final NumberSetting skeletonAlpha = new NumberSetting("Skeleton Alpha", 0.8, 0.1, 1.0);

    private final NumberSetting skeletonLineWidth = new NumberSetting("Skeleton Width", 2.0, 1.0, 5.0);

    private boolean depthOverrideActive = false;

    public Chams() {
        super("Chams", Category.RENDER);
        setDescription("See players through walls in different ways");
        addSetting(players);
        addSetting(showInvisible);
        addSetting(chamsMode);
        addSetting(glow);
        addSetting(glowStrength);
        addSetting(glowLayers);
        addSetting(glowColor);
        addSetting(occRed);
        addSetting(occGreen);
        addSetting(occBlue);
        addSetting(occAlpha);
        addSetting(visRed);
        addSetting(visGreen);
        addSetting(visBlue);
        addSetting(visAlpha);
        addSetting(skeletonColor);
        addSetting(skeletonAlpha);
        addSetting(skeletonLineWidth);
        glowStrength.setVisibilityCondition(Condition.whenTrue(glow));
        glowLayers.setVisibilityCondition(Condition.whenTrue(glow));
        glowColor.setVisibilityCondition(Condition.whenTrue(glow));
        Predicate<Setting<?>> skeletonCond = Condition.whenEqualTo(chamsMode, "Skeleton");
        skeletonColor.setVisibilityCondition(skeletonCond);
        skeletonAlpha.setVisibilityCondition(skeletonCond);
        skeletonLineWidth.setVisibilityCondition(skeletonCond);
        Predicate<Setting<?>> flatOrWire = Condition.or(Condition.whenEqualTo(chamsMode, "Flat"), Condition.whenEqualTo(chamsMode, "Wireframe"));
        occRed.setVisibilityCondition(flatOrWire);
        occGreen.setVisibilityCondition(flatOrWire);
        occBlue.setVisibilityCondition(flatOrWire);
        occAlpha.setVisibilityCondition(flatOrWire);
        visRed.setVisibilityCondition(flatOrWire);
        visGreen.setVisibilityCondition(flatOrWire);
        visBlue.setVisibilityCondition(flatOrWire);
        visAlpha.setVisibilityCondition(flatOrWire);
        handles(HandlerType.RENDER, HandlerType.PRE_RENDER_LIVING, HandlerType.POST_RENDER_LIVING);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (!players.getValue())
            return;
        String mode = chamsMode.getValue();
        boolean isFlat = mode.equals("Flat");
        boolean isWireframe = mode.equals("Wireframe");
        boolean isTextured = mode.equals("Textured");
        boolean isSkeleton = mode.equals("Skeleton");
        float partialTicks = event.getPartialTicks();
        RenderUtils.updateCameraPos(partialTicks);
        boolean doGlow = glow.getValue();
        int layers = glowLayers.getValue().intValue();
        float strength = glowStrength.getValue().floatValue();
        float[] gc = glowColor.getRGBFloat();
        float[] sc = skeletonColor.getRGBFloat();
        float sa = skeletonAlpha.getValue().floatValue();
        for (EntityPlayer player : mc.world.playerEntities) {
            if (player == mc.player)
                continue;
            if (!player.isEntityAlive())
                continue;
            if (player.isInvisible() && !showInvisible.getValue())
                continue;
            double x = player.lastTickPosX + (player.posX - player.lastTickPosX) * partialTicks - RenderUtils.camX;
            double y = player.lastTickPosY + (player.posY - player.lastTickPosY) * partialTicks - RenderUtils.camY;
            double z = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * partialTicks - RenderUtils.camZ;
            float width = player.width;
            float height = player.height;
            AxisAlignedBB bb = new AxisAlignedBB(x - width / 2, y, z - width / 2, x + width / 2, y + height, z + width / 2);
            boolean canSee = mc.player.canEntityBeSeen(player);
            if (doGlow) {
                drawGlow(bb, gc[0], gc[1], gc[2], strength, layers);
            }
            if (isSkeleton) {
                drawSkeleton(x, y, z, width, height, sc[0], sc[1], sc[2], sa);
                continue;
            }
            if (isTextured) {
                continue;
            }
            float r, g, b, a;
            if (canSee) {
                r = visRed.getValue().floatValue();
                g = visGreen.getValue().floatValue();
                b = visBlue.getValue().floatValue();
                a = visAlpha.getValue().floatValue();
            } else {
                r = occRed.getValue().floatValue();
                g = occGreen.getValue().floatValue();
                b = occBlue.getValue().floatValue();
                a = occAlpha.getValue().floatValue();
            }
            if (isWireframe) {
                RenderUtils.prepareGL();
                if (!canSee) {
                    GlStateManager.disableDepth();
                }
                EaglercraftGPU.glLineWidth(2.0F);
                if (canSee) {
                    GlStateManager.enableDepth();
                }
                RenderUtils.drawOutlinedBox(bb, r, g, b, a);
                EaglercraftGPU.glLineWidth(1.0F);
                GlStateManager.enableDepth();
                RenderUtils.restoreGL();
            } else {
                if (canSee) {
                    GlStateManager.pushMatrix();
                    GlStateManager.enableBlend();
                    GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
                    GlStateManager.disableTexture2D();
                    RenderUtils.drawSolidBox(bb, r, g, b, a);
                    RenderUtils.drawOutlinedBox(bb, r, g, b, Math.min(a + 0.5f, 1.0f));
                    GlStateManager.enableTexture2D();
                    GlStateManager.disableBlend();
                    GlStateManager.popMatrix();
                } else {
                    RenderUtils.prepareGL();
                    GlStateManager.disableDepth();
                    RenderUtils.drawSolidBox(bb, r, g, b, a);
                    RenderUtils.drawOutlinedBox(bb, r, g, b, Math.min(a + 0.5f, 1.0f));
                    GlStateManager.enableDepth();
                    RenderUtils.restoreGL();
                }
            }
        }
    }

    private void drawSkeleton(double x, double y, double z, float width, float height, float sr, float sg, float sb, float sa) {
        double hw = width / 2.0;
        double feet = y;
        double hips = y + 0.95;
        double shoulders = y + 1.42;
        double headBase = y + 1.52;
        double headTop = y + 1.82;
        double armOut = hw + 0.05;
        double handY = shoulders - 0.55;
        double legSpread = 0.12;
        float lw = skeletonLineWidth.getValue().floatValue();
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
        GlStateManager.disableDepth();
        GlStateManager.disableTexture2D();
        RenderUtils.enableLineSmooth();
        EaglercraftGPU.glLineWidth(lw);
        double headHw = hw * 0.5;
        AxisAlignedBB headBB = new AxisAlignedBB(x - headHw, headBase, z - headHw, x + headHw, headTop, z + headHw);
        RenderUtils.drawOutlinedBox(headBB, sr, sg, sb, sa);
        RenderUtils.drawLine(x, headBase, z, x, hips, z, sr, sg, sb, sa);
        RenderUtils.drawLine(x - armOut, shoulders, z, x + armOut, shoulders, z, sr, sg, sb, sa);
        RenderUtils.drawLine(x - armOut, shoulders, z, x - armOut, handY, z, sr, sg, sb, sa);
        RenderUtils.drawLine(x + armOut, shoulders, z, x + armOut, handY, z, sr, sg, sb, sa);
        RenderUtils.drawLine(x - legSpread, hips, z, x - legSpread, feet, z, sr, sg, sb, sa);
        RenderUtils.drawLine(x + legSpread, hips, z, x + legSpread, feet, z, sr, sg, sb, sa);
        EaglercraftGPU.glLineWidth(1.0F);
        RenderUtils.disableLineSmooth();
        GlStateManager.enableTexture2D();
        GlStateManager.enableDepth();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    private void drawGlow(AxisAlignedBB bb, float gr, float gg, float gb, float strength, int layers) {
        double cx = (bb.minX + bb.maxX) / 2.0;
        double cy = (bb.minY + bb.maxY) / 2.0;
        double cz = (bb.minZ + bb.maxZ) / 2.0;
        double hw = (bb.maxX - bb.minX) / 2.0;
        double hh = (bb.maxY - bb.minY) / 2.0;
        double hd = (bb.maxZ - bb.minZ) / 2.0;
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
        GlStateManager.disableDepth();
        GlStateManager.disableTexture2D();
        GlStateManager.depthMask(false);
        for (int i = 1; i <= layers; i++) {
            float expand = 0.04F * i * strength;
            float layerAlpha = strength * (1.0F / (i * 0.8F + 0.5F)) * 0.35F;
            layerAlpha = Math.min(layerAlpha, 0.6F);
            double ex = hw + expand;
            double ey = hh + expand;
            double ez = hd + expand;
            AxisAlignedBB glowBB = new AxisAlignedBB(cx - ex, cy - ey, cz - ez, cx + ex, cy + ey, cz + ez);
            RenderUtils.drawSolidBox(glowBB, gr, gg, gb, layerAlpha);
        }
        GlStateManager.depthMask(true);
        GlStateManager.enableTexture2D();
        GlStateManager.enableDepth();
        GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    @Override
    public void onPreRenderLiving(PreRenderLivingEvent event) {
        if (!nullCheck())
            return;
        if (!players.getValue())
            return;
        if (!(event.getEntity() instanceof EntityPlayer))
            return;
        EntityPlayer player = (EntityPlayer) event.getEntity();
        if (player == mc.player)
            return;
        if (!player.isEntityAlive())
            return;
        if (player.isInvisible() && !showInvisible.getValue())
            return;
        String mode = chamsMode.getValue();
        if (mode.equals("Textured")) {
            GlStateManager.disableDepth();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
            depthOverrideActive = true;
            return;
        }
        if (mode.equals("Skeleton")) {
            depthOverrideActive = false;
            return;
        }
        depthOverrideActive = false;
    }

    @Override
    public void onPostRenderLiving(PostRenderLivingEvent event) {
        if (!depthOverrideActive)
            return;
        if (!(event.getEntity() instanceof EntityPlayer))
            return;
        EntityPlayer player = (EntityPlayer) event.getEntity();
        if (player == mc.player)
            return;
        GlStateManager.disableBlend();
        GlStateManager.enableDepth();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        depthOverrideActive = false;
    }
}
