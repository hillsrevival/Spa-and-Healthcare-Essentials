package client.module.impl.render;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.ColorSetting;
import client.module.NumberSetting;
import client.utils.render.RenderUtils;
import client.utils.EntityUtils;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;

public class Tracers extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 100.0, 10.0, 200.0);

    private final BooleanSetting players = new BooleanSetting("Players", true);

    private final BooleanSetting mobs = new BooleanSetting("Mobs", true);

    private final BooleanSetting items = new BooleanSetting("Items", false);

    private final ModeSetting tracerColor = new ModeSetting("Tracer Color", "Default", "Default", "Red", "Green", "Blue", "Yellow", "Purple", "Pink", "Orange", "White", "Cyan", "Rainbow");

    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 1.0, 0.5, 3.0);

    private final ColorSetting customColor = new ColorSetting("Custom Color", 0.0);

    private final List<Entity> targetEntities = new ArrayList<>();

    public Tracers() {
        super("Tracers", Category.RENDER);
        setDescription("Draws lines from you to nearby entities");
        addSetting(range);
        addSetting(players);
        addSetting(mobs);
        addSetting(items);
        addSetting(tracerColor);
        addSetting(customColor);
        addSetting(lineWidth);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        targetEntities.clear();
        double rangeVal = range.getValue();
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (entity == mc.player)
                continue;
            if (mc.player.getDistanceToEntity(entity) > rangeVal)
                continue;
            if (entity instanceof EntityPlayer) {
                if (players.getValue())
                    targetEntities.add(entity);
            } else if (entity instanceof EntityItem) {
                if (items.getValue())
                    targetEntities.add(entity);
            } else if (entity instanceof EntityMob || entity instanceof EntityAnimal) {
                if (mobs.getValue())
                    targetEntities.add(entity);
            }
        }
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (targetEntities.isEmpty())
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        RenderUtils.prepareGL();
        EaglercraftGPU.glLineWidth(lineWidth.getValue().floatValue());
        double startX = 0.0;
        double startY = 0.0;
        double startZ = 0.0;
        for (Entity entity : targetEntities) {
            double x = entity.prevPosX + (entity.posX - entity.prevPosX) * event.getPartialTicks() - RenderUtils.camX;
            double y = entity.prevPosY + (entity.posY - entity.prevPosY) * event.getPartialTicks() - RenderUtils.camY;
            double z = entity.prevPosZ + (entity.posZ - entity.prevPosZ) * event.getPartialTicks() - RenderUtils.camZ;
            double height = entity.height / 2.0;
            float[] color = getColor(entity);
            RenderUtils.drawLine(startX, startY, startZ, x, y + height, z, color[0], color[1], color[2], 0.7f);
        }
        RenderUtils.restoreGL();
    }

    private float[] getColor(Entity entity) {
        float[] custom = resolveTracerColor(targetEntities.indexOf(entity));
        if (custom != null)
            return custom;
        if (entity instanceof EntityPlayer) {
            return new float[] { 1.0f, 0.2f, 0.2f };
        } else if (entity instanceof EntityItem) {
            return new float[] { 1.0f, 1.0f, 0.2f };
        } else {
            return new float[] { 0.2f, 1.0f, 0.2f };
        }
    }

    private float[] resolveTracerColor(int index) {
        String mode = tracerColor.getValue();
        if (mode.equals("Default"))
            return null;
        if (mode.equals("Rainbow")) {
            float hue = ((System.currentTimeMillis() / 15L) + (index * 40L)) % 360L;
            return RenderUtils.hsbToRgb(hue / 360.0f, 1.0f, 1.0f);
        }
        switch(mode) {
            case "Red":
                return new float[] { 1, 0, 0 };
            case "Green":
                return new float[] { 0, 1, 0 };
            case "Blue":
                return new float[] { 0, 0.4f, 1 };
            case "Yellow":
                return new float[] { 1, 1, 0 };
            case "Purple":
                return new float[] { 0.6f, 0.2f, 1 };
            case "Pink":
                return new float[] { 1, 0.4f, 0.7f };
            case "Orange":
                return new float[] { 1, 0.5f, 0 };
            case "White":
                return new float[] { 1, 1, 1 };
            case "Cyan":
                return new float[] { 0, 1, 1 };
            case "Custom":
                return customColor.getRGBFloat();
            default:
                return null;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        targetEntities.clear();
    }
}
