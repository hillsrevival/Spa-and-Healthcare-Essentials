package client.module.impl.render;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import client.event.listeners.ShouldSideBeRenderedListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.ChatUtils;

public class CaveFinder extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private float savedGamma = 1.0f;

    public CaveFinder() {
        super("CaveFinder", Category.RENDER);
        setDescription("Highlights caves below you");
        handles(HandlerType.SHOULD_SIDE_BE_RENDERED);
    }

    @Override
    public void onShouldSideBeRendered(ShouldSideBeRenderedListener.ShouldSideBeRenderedEvent event) {
        if (!nullCheck())
            return;
        Block block = event.getState().getBlock();
        if (isUsefulInCaves(block)) {
            event.setRendered(true);
        } else {
            event.setRendered(false);
        }
    }

    private boolean isUsefulInCaves(Block b) {
        if (b == Blocks.AIR)
            return true;
        if (b == Blocks.WATER)
            return true;
        if (b == Blocks.FLOWING_WATER)
            return true;
        if (b == Blocks.LAVA)
            return true;
        if (b == Blocks.FLOWING_LAVA)
            return true;
        if (b == Blocks.TORCH)
            return true;
        if (b == Blocks.REDSTONE_TORCH)
            return true;
        if (b == Blocks.UNLIT_REDSTONE_TORCH)
            return true;
        if (b == Blocks.GLOWSTONE)
            return true;
        if (b == Blocks.SEA_LANTERN)
            return true;
        if (b == Blocks.MAGMA)
            return true;
        if (b == Blocks.CHEST)
            return true;
        if (b == Blocks.TRAPPED_CHEST)
            return true;
        if (b == Blocks.ENDER_CHEST)
            return true;
        if (b == Blocks.MOB_SPAWNER)
            return true;
        if (b == Blocks.WEB)
            return true;
        if (b == Blocks.RAIL)
            return true;
        if (b == Blocks.GOLDEN_RAIL)
            return true;
        if (b == Blocks.DETECTOR_RAIL)
            return true;
        if (b == Blocks.ACTIVATOR_RAIL)
            return true;
        if (b == Blocks.LADDER)
            return true;
        if (b == Blocks.VINE)
            return true;
        if (b == Blocks.PORTAL)
            return true;
        if (b == Blocks.END_PORTAL)
            return true;
        if (b == Blocks.STANDING_SIGN)
            return true;
        if (b == Blocks.WALL_SIGN)
            return true;
        if (b == Blocks.COAL_ORE)
            return true;
        if (b == Blocks.IRON_ORE)
            return true;
        if (b == Blocks.GOLD_ORE)
            return true;
        if (b == Blocks.DIAMOND_ORE)
            return true;
        if (b == Blocks.EMERALD_ORE)
            return true;
        if (b == Blocks.REDSTONE_ORE)
            return true;
        if (b == Blocks.LIT_REDSTONE_ORE)
            return true;
        if (b == Blocks.LAPIS_ORE)
            return true;
        if (b == Blocks.QUARTZ_ORE)
            return true;
        return false;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        savedGamma = mc.gameSettings.gammaSetting;
        mc.gameSettings.gammaSetting = 1000;
        if (mc.renderGlobal != null) {
            mc.renderGlobal.loadRenderers();
        }
        ChatUtils.info("CaveFinder enabled");
    }

    @Override
    public void onDisable() {
        if (mc.renderGlobal != null) {
            mc.renderGlobal.loadRenderers();
        }
        mc.gameSettings.gammaSetting = savedGamma;
        ChatUtils.message("CaveFinder disabled");
        super.onDisable();
    }
}
