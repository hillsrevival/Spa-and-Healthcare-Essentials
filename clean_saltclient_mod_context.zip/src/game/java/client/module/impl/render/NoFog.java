package client.module.impl.render;

import client.event.events.FogDensityEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.init.MobEffects;

public class NoFog extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting removeWater = new BooleanSetting("Remove Water Fog", true);

    private final BooleanSetting removeLava = new BooleanSetting("Remove Lava Fog", true);

    private final BooleanSetting removeBlindness = new BooleanSetting("Remove Blindness Fog", true);

    private final BooleanSetting removeNether = new BooleanSetting("Remove Nether Fog", true);

    public NoFog() {
        super("NoFog", Category.RENDER);
        setDescription("Removes fog from all dimensions and effects");
        addSetting(removeWater);
        addSetting(removeLava);
        addSetting(removeBlindness);
        addSetting(removeNether);
        handles(HandlerType.FOG_DENSITY);
    }

    @Override
    public void onFogDensity(FogDensityEvent event) {
        if (!nullCheck())
            return;
        event.setCancelled(true);
    }
}
