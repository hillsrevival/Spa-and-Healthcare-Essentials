package client.module.impl.render;

import client.event.listeners.RenderListener;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.Module;
import client.module.NumberSetting;
import client.utils.render.RenderUtils;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.lax1dude.eaglercraft.opengl.WorldRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class JumpCircle extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting circleType = new ModeSetting("Circle Type", "Classic Rings", "Classic Rings", "Layered Rings", "Shockwaves", "Gradients", "RGB Effects", "Energy Effects");

    private final ModeSetting particleStyle = new ModeSetting("Particle Style", "Enchant", "Ice", "Fire", "Nature", "Soul", "Enchant", "Wither", "Lightning", "Galaxy");

    private final ModeSetting colorScheme = new ModeSetting("Color Scheme", "Aqua", "Lime", "Emerald", "Aqua", "Sky", "Blue", "Purple", "Magenta", "Pink", "Red", "Orange", "Gold", "White", "Ice", "Fire", "Soul", "Galaxy");

    private final NumberSetting lifetime = new NumberSetting("Lifetime", 700.0, 250.0, 1500.0);

    private final NumberSetting radius = new NumberSetting("Radius", 1.6, 0.7, 3.0);

    private final NumberSetting maxCircles = new NumberSetting("Max Circles", 8, 1, 32);

    private final BooleanSetting particles = new BooleanSetting("Particles", true);

    private final BooleanSetting fade = new BooleanSetting("Fade", true);

    private final BooleanSetting onLand = new BooleanSetting("On Land", false);

    private final BooleanSetting rainbow = new BooleanSetting("Rainbow", false);

    private final List<Effect> effects = new ArrayList<Effect>();

    private boolean wasOnGround;

    private boolean wasInAir;

    public JumpCircle() {
        super("Jump Circle", Category.RENDER);
        setDescription("Animated rings and energy effects when you jump");
        handles(HandlerType.UPDATE, HandlerType.RENDER);
        addSetting(circleType);
        addSetting(particleStyle);
        addSetting(colorScheme);
        addSetting(lifetime);
        addSetting(radius);
        addSetting(maxCircles);
        addSetting(particles);
        addSetting(fade);
        addSetting(onLand);
        addSetting(rainbow);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null) {
            effects.clear();
            return;
        }
        boolean grounded = mc.player.onGround;
        if (wasOnGround && !grounded && mc.player.motionY > 0.0D) {
            spawnEffect(mc.player.posX, mc.player.posY, mc.player.posZ);
        }
        if (onLand.getValue() && wasInAir && grounded) {
            spawnEffect(mc.player.posX, mc.player.posY, mc.player.posZ);
        }
        wasOnGround = grounded;
        wasInAir = !grounded;
        long now = System.currentTimeMillis();
        long life = lifetime.getValue().longValue();
        Iterator<Effect> it = effects.iterator();
        while (it.hasNext()) {
            if (now - it.next().time > life)
                it.remove();
        }
    }

    private void spawnEffect(double x, double y, double z) {
        effects.add(new Effect(x, y, z, System.currentTimeMillis()));
        int max = maxCircles.getValue().intValue();
        while (effects.size() > max) effects.remove(0);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (mc.player == null || mc.world == null || effects.isEmpty())
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        double camX = mc.getRenderManager().viewerPosX;
        double camY = mc.getRenderManager().viewerPosY;
        double camZ = mc.getRenderManager().viewerPosZ;
        long now = System.currentTimeMillis();
        float maxLife = lifetime.getValue().floatValue();
        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
        GlStateManager.disableDepth();
        GlStateManager.depthMask(false);
        RenderUtils.enableLineSmooth();
        for (Effect effect : effects) {
            float progress = (now - effect.time) / maxLife;
            if (progress < 0.0F || progress > 1.0F)
                continue;
            float alpha = fade.getValue() ? (1.0F - progress) : 1.0F;
            float grow = easeOut(progress);
            double x = effect.x - camX;
            double y = effect.y - camY + 0.025D;
            double z = effect.z - camZ;
            float r = radius.getValue().floatValue() * (0.28F + grow * 0.72F);
            if (circleType.getValue().equalsIgnoreCase("Classic Rings")) {
                drawClassicRings(x, y, z, r, alpha, progress, now);
            } else if (circleType.getValue().equalsIgnoreCase("Energy Effects")) {
                drawEnergy(x, y, z, r, alpha, progress, now);
            } else if (circleType.getValue().equalsIgnoreCase("RGB Effects")) {
                drawRgbEffects(x, y, z, r, alpha, progress, now);
            } else {
                drawCircle(x, y, z, r, alpha, circleType.getValue(), now);
            }
            if (particles.getValue()) {
                drawParticles(x, y, z, r, alpha, particleStyle.getValue(), now, progress);
            }
        }
        EaglercraftGPU.glLineWidth(1.0F);
        RenderUtils.disableLineSmooth();
        GlStateManager.depthMask(true);
        GlStateManager.enableDepth();
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
        GlStateManager.popMatrix();
        RenderUtils.restoreHUD();
    }

    private void drawClassicRings(double x, double y, double z, float r, float alpha, float progress, long now) {
        float pulse = 1.0F + (float) Math.sin(progress * Math.PI * 5.0D) * 0.045F;
        float outer = r * pulse;
        float inner = r * 0.58F;
        float[] primary = primaryColor();
        float[] secondary = secondaryColor();
        drawRing(x, y, z, outer, alpha * 0.12F, primary, 8.0F, 64, now, true);
        drawRing(x, y, z, outer, alpha * 0.25F, primary, 5.0F, 64, now, true);
        drawRing(x, y, z, outer, alpha * 0.95F, primary, 2.6F, 64, now, true);
        drawRing(x, y + 0.012D, z, inner, alpha * 0.10F, secondary, 7.0F, 56, now, false);
        drawRing(x, y + 0.012D, z, inner, alpha * 0.28F, secondary, 4.0F, 56, now, false);
        drawRing(x, y + 0.012D, z, inner, alpha * 0.95F, secondary, 2.4F, 56, now, false);
        drawMarkers(x, y + 0.02D, z, outer, alpha * 0.85F, primary);
        float sweep = (now % 900L) / 900.0F;
        drawSweep(x, y + 0.025D, z, outer, alpha * 0.9F, primary, sweep);
    }

    private void drawRing(double x, double y, double z, float r, float alpha, float[] color, float width, int segments, long now, boolean animated) {
        EaglercraftGPU.glLineWidth(width);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        buf.begin(RealOpenGLEnums.GL_LINE_STRIP, DefaultVertexFormats.POSITION);
        int start = animated ? (int) ((now / 10L) % segments) : 0;
        for (int i = 0; i <= segments; i++) {
            int index = (i + start) % segments;
            float a = (float) (Math.PI * 2.0D * index / segments);
            float intensity = animated ? 0.82F + 0.18F * (float) Math.sin(a * 3.0D + now * 0.004D) : 1.0F;
            GlStateManager.color(color[0] * intensity, color[1] * intensity, color[2] * intensity, alpha);
            buf.pos(x + Math.cos(a) * r, y, z + Math.sin(a) * r).endVertex();
        }
        tess.draw();
        EaglercraftGPU.glLineWidth(1.0F);
    }

    private void drawSweep(double x, double y, double z, float r, float alpha, float[] color, float sweep) {
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        EaglercraftGPU.glLineWidth(3.5F);
        buf.begin(RealOpenGLEnums.GL_LINES, DefaultVertexFormats.POSITION);
        double a = sweep * Math.PI * 2.0D;
        double inner = r * 0.82D;
        double outer = r * 1.02D;
        GlStateManager.color(color[0], color[1], color[2], alpha);
        buf.pos(x + Math.cos(a) * inner, y, z + Math.sin(a) * inner).endVertex();
        buf.pos(x + Math.cos(a) * outer, y, z + Math.sin(a) * outer).endVertex();
        tess.draw();
        EaglercraftGPU.glLineWidth(1.0F);
    }

    private void drawEnergy(double x, double y, double z, float r, float alpha, float progress, long now) {
        float[] primary = primaryColor();
        float[] secondary = secondaryColor();
        float wave = 0.7F + 0.3F * (float) Math.sin(progress * Math.PI * 8.0D);
        drawRing(x, y, z, r * wave, alpha * 0.18F, primary, 7.0F, 48, now, true);
        drawRing(x, y, z, r, alpha * 0.9F, primary, 2.8F, 64, now, true);
        drawRing(x, y + 0.018D, z, r * 0.5F, alpha * 0.8F, secondary, 2.2F, 48, now, true);
        drawSweep(x, y + 0.03D, z, r, alpha, secondary, (now % 700L) / 700.0F);
    }

    private void drawCircle(double x, double y, double z, float r, float alpha, String type, long now) {
        float[] c = primaryColor();
        if (type.equalsIgnoreCase("Layered Rings")) {
            drawRing(x, y, z, r, alpha * 0.95F, c, 2.5F, 64, now, true);
            drawRing(x, y + 0.008D, z, r * 0.62F, alpha * 0.75F, secondaryColor(), 1.8F, 48, now, false);
        } else if (type.equalsIgnoreCase("Shockwaves")) {
            drawRing(x, y, z, r, alpha * 0.9F, c, 2.5F, 56, now, true);
            drawRing(x, y + 0.012D, z, r * 0.82F, alpha * 0.55F, secondaryColor(), 1.5F, 48, now, true);
        } else if (type.equalsIgnoreCase("Gradients")) {
            drawRing(x, y, z, r, alpha * 0.95F, c, 2.5F, 64, now, true);
            drawRing(x, y + 0.008D, z, r * 0.68F, alpha * 0.55F, secondaryColor(), 1.7F, 56, now, true);
        } else {
            drawRing(x, y, z, r, alpha * 0.95F, c, 2.5F, 64, now, true);
        }
    }

    private void drawRgbEffects(double x, double y, double z, float r, float alpha, float progress, long now) {
        float hue0 = ((now / 20L) % 360L) / 360.0F;
        float hue1 = (hue0 + 0.33F) % 1.0F;
        float hue2 = (hue0 + 0.66F) % 1.0F;
        float[] c0 = RenderUtils.hsbToRgb(hue0, 1.0F, 1.0F);
        float[] c1 = RenderUtils.hsbToRgb(hue1, 1.0F, 1.0F);
        float[] c2 = RenderUtils.hsbToRgb(hue2, 1.0F, 1.0F);
        drawRing(x, y, z, r, alpha * 0.9F, c0, 3.0F, 64, now, true);
        drawRing(x, y + 0.01D, z, r * 0.7F, alpha * 0.7F, c1, 2.0F, 56, now, true);
        drawRing(x, y + 0.02D, z, r * 0.45F, alpha * 0.5F, c2, 1.5F, 48, now, true);
        float sweepHue = ((now / 10L) % 360L) / 360.0F;
        drawSweep(x, y + 0.025D, z, r, alpha * 0.8F, RenderUtils.hsbToRgb(sweepHue, 1.0F, 1.0F), (now % 900L) / 900.0F);
    }

    private void drawMarkers(double x, double y, double z, float r, float alpha, float[] color) {
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        EaglercraftGPU.glLineWidth(2.0F);
        buf.begin(RealOpenGLEnums.GL_LINES, DefaultVertexFormats.POSITION);
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2.0D * i / 8.0D;
            double inner = r * 0.90D;
            double outer = r * 1.06D;
            GlStateManager.color(color[0], color[1], color[2], alpha);
            buf.pos(x + Math.cos(a) * inner, y, z + Math.sin(a) * inner).endVertex();
            buf.pos(x + Math.cos(a) * outer, y, z + Math.sin(a) * outer).endVertex();
        }
        tess.draw();
        EaglercraftGPU.glLineWidth(1.0F);
    }

    private void drawParticles(double x, double y, double z, float r, float alpha, String style, long now, float progress) {
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        buf.begin(RealOpenGLEnums.GL_LINES, DefaultVertexFormats.POSITION);
        int count = 16;
        long tick = now / 16L;
        for (int i = 0; i < count; i++) {
            double base = i * Math.PI * 2.0D / count;
            double phase = base + tick * 0.035D;
            double orbit = r * (0.52D + (i % 4) * 0.13D);
            double px = x + Math.cos(phase) * orbit;
            double pz = z + Math.sin(phase) * orbit;
            double py = y + 0.035D + ((i * 17) % 6) * 0.035D + ((tick + i * 3) % 24) * 0.008D;
            double size = 0.055D + (i % 3) * 0.025D;
            float particleAlpha = alpha * (0.45F + 0.55F * (1.0F - progress));
            float[] c = particleColor(style, i);
            GlStateManager.color(c[0], c[1], c[2], particleAlpha);
            if (style.equalsIgnoreCase("Lightning")) {
                buf.pos(px, py, pz).endVertex();
                buf.pos(px + Math.sin(phase * 5.0D) * size * 2.0D, py + size * 2.0D, pz + Math.cos(phase * 4.0D) * size * 2.0D).endVertex();
            } else {
                buf.pos(px - size, py, pz).endVertex();
                buf.pos(px + size, py, pz).endVertex();
                buf.pos(px, py - size, pz).endVertex();
                buf.pos(px, py + size, pz).endVertex();
            }
        }
        tess.draw();
        EaglercraftGPU.glLineWidth(1.0F);
    }

    private float[] particleColor(String style, int i) {
        if (style.equalsIgnoreCase("Ice"))
            return new float[] { 0.55F, 0.9F, 1.0F };
        if (style.equalsIgnoreCase("Fire"))
            return new float[] { 1.0F, 0.25F + (i % 3) * 0.12F, 0.03F };
        if (style.equalsIgnoreCase("Nature"))
            return new float[] { 0.25F, 1.0F, 0.3F };
        if (style.equalsIgnoreCase("Soul"))
            return new float[] { 0.25F, 0.65F, 1.0F };
        if (style.equalsIgnoreCase("Enchant"))
            return new float[] { 0.85F, 0.25F, 1.0F };
        if (style.equalsIgnoreCase("Wither"))
            return new float[] { 0.55F, 0.35F, 0.65F };
        if (style.equalsIgnoreCase("Lightning"))
            return new float[] { 0.75F, 0.9F, 1.0F };
        return new float[] { 0.55F, 0.35F + (i % 3) * 0.12F, 1.0F };
    }

    private float[] primaryColor() {
        if (rainbow.getValue()) {
            float hue = ((System.currentTimeMillis() / 15L) % 360L) / 360.0F;
            return RenderUtils.hsbToRgb(hue, 1.0F, 1.0F);
        }
        String s = colorScheme.getValue();
        if (s.equalsIgnoreCase("Lime"))
            return new float[] { 0.65F, 1.0F, 0.1F };
        if (s.equalsIgnoreCase("Emerald"))
            return new float[] { 0.1F, 1.0F, 0.45F };
        if (s.equalsIgnoreCase("Aqua"))
            return new float[] { 0.1F, 1.0F, 1.0F };
        if (s.equalsIgnoreCase("Sky"))
            return new float[] { 0.25F, 0.7F, 1.0F };
        if (s.equalsIgnoreCase("Blue"))
            return new float[] { 0.15F, 0.35F, 1.0F };
        if (s.equalsIgnoreCase("Purple"))
            return new float[] { 0.65F, 0.2F, 1.0F };
        if (s.equalsIgnoreCase("Magenta"))
            return new float[] { 1.0F, 0.1F, 0.8F };
        if (s.equalsIgnoreCase("Pink"))
            return new float[] { 1.0F, 0.4F, 0.7F };
        if (s.equalsIgnoreCase("Red"))
            return new float[] { 1.0F, 0.12F, 0.12F };
        if (s.equalsIgnoreCase("Orange"))
            return new float[] { 1.0F, 0.45F, 0.08F };
        if (s.equalsIgnoreCase("Gold"))
            return new float[] { 1.0F, 0.75F, 0.12F };
        if (s.equalsIgnoreCase("White"))
            return new float[] { 1.0F, 1.0F, 1.0F };
        if (s.equalsIgnoreCase("Ice"))
            return new float[] { 0.55F, 0.9F, 1.0F };
        if (s.equalsIgnoreCase("Fire"))
            return new float[] { 1.0F, 0.22F, 0.02F };
        if (s.equalsIgnoreCase("Soul"))
            return new float[] { 0.25F, 0.65F, 1.0F };
        return new float[] { 0.65F, 0.3F, 1.0F };
    }

    private float[] secondaryColor() {
        if (rainbow.getValue()) {
            float hue = (((System.currentTimeMillis() / 15L) + 120L) % 360L) / 360.0F;
            return RenderUtils.hsbToRgb(hue, 1.0F, 1.0F);
        }
        String s = colorScheme.getValue();
        if (s.equalsIgnoreCase("Lime") || s.equalsIgnoreCase("Emerald"))
            return new float[] { 0.1F, 0.95F, 1.0F };
        if (s.equalsIgnoreCase("Aqua") || s.equalsIgnoreCase("Sky") || s.equalsIgnoreCase("Ice"))
            return new float[] { 0.7F, 0.2F, 1.0F };
        if (s.equalsIgnoreCase("Blue") || s.equalsIgnoreCase("Purple") || s.equalsIgnoreCase("Soul"))
            return new float[] { 0.1F, 0.9F, 1.0F };
        if (s.equalsIgnoreCase("Magenta") || s.equalsIgnoreCase("Pink"))
            return new float[] { 0.2F, 0.75F, 1.0F };
        if (s.equalsIgnoreCase("Red") || s.equalsIgnoreCase("Orange") || s.equalsIgnoreCase("Fire"))
            return new float[] { 1.0F, 0.75F, 0.08F };
        if (s.equalsIgnoreCase("Gold"))
            return new float[] { 1.0F, 0.3F, 0.1F };
        if (s.equalsIgnoreCase("White"))
            return new float[] { 0.65F, 0.8F, 1.0F };
        return new float[] { 0.2F, 0.75F, 1.0F };
    }

    @Override
    public void onDisable() {
        super.onDisable();
        effects.clear();
        wasOnGround = false;
        wasInAir = false;
    }

    private float easeOut(float p) {
        float q = 1.0F - p;
        return 1.0F - q * q * q;
    }

    private static class Effect {

        final double x, y, z;

        final long time;

        Effect(double x, double y, double z, long time) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.time = time;
        }
    }
}
