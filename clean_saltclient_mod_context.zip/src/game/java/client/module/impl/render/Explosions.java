package client.module.impl.render;

import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import client.utils.render.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.util.math.AxisAlignedBB;

public class Explosions extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting showCrystals = new BooleanSetting("Show Crystals", true);

    private final BooleanSetting showTNT = new BooleanSetting("Show TNT", true);

    private final BooleanSetting showBlockRadius = new BooleanSetting("Block Radius", true);

    private final BooleanSetting showDamageRadius = new BooleanSetting("Damage Radius", true);

    private final BooleanSetting showBlastRing = new BooleanSetting("Blast Ring", true);

    private final NumberSetting blockRed = new NumberSetting("Block Red", 1.0, 0.0, 1.0);

    private final NumberSetting blockGreen = new NumberSetting("Block Green", 0.0, 0.0, 1.0);

    private final NumberSetting blockBlue = new NumberSetting("Block Blue", 0.0, 0.0, 1.0);

    private final NumberSetting blockAlpha = new NumberSetting("Block Alpha", 0.15, 0.0, 1.0);

    private final NumberSetting dmgRed = new NumberSetting("Dmg Red", 1.0, 0.0, 1.0);

    private final NumberSetting dmgGreen = new NumberSetting("Dmg Green", 1.0, 0.0, 1.0);

    private final NumberSetting dmgBlue = new NumberSetting("Dmg Blue", 0.0, 0.0, 1.0);

    private final NumberSetting dmgAlpha = new NumberSetting("Dmg Alpha", 0.08, 0.0, 1.0);

    private final NumberSetting crystalBlockRadius = new NumberSetting("Crystal Block R", 6.0, 1.0, 12.0);

    private final NumberSetting crystalDamageRadius = new NumberSetting("Crystal Dmg R", 12.0, 1.0, 20.0);

    private final NumberSetting tntBlockRadius = new NumberSetting("TNT Block R", 4.0, 1.0, 12.0);

    private final NumberSetting tntDamageRadius = new NumberSetting("TNT Dmg R", 8.0, 1.0, 20.0);

    public Explosions() {
        super("Explosions", Category.RENDER);
        setDescription("Shows crystal and tnt blast radius");
        addSetting(showCrystals);
        addSetting(showTNT);
        addSetting(showBlockRadius);
        addSetting(showDamageRadius);
        addSetting(showBlastRing);
        addSetting(blockRed);
        addSetting(blockGreen);
        addSetting(blockBlue);
        addSetting(blockAlpha);
        addSetting(dmgRed);
        addSetting(dmgGreen);
        addSetting(dmgBlue);
        addSetting(dmgAlpha);
        addSetting(crystalBlockRadius);
        addSetting(crystalDamageRadius);
        addSetting(tntBlockRadius);
        addSetting(tntDamageRadius);
        handles(HandlerType.RENDER);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        float partialTicks = event.getPartialTicks();
        RenderUtils.updateCameraPos(partialTicks);
        RenderUtils.prepareGL();
        if (showCrystals.getValue()) {
            for (EntityEnderCrystal crystal : mc.world.getEntitiesWithinAABB(EntityEnderCrystal.class, mc.player.getEntityBoundingBox().expand(32, 32, 32))) {
                if (crystal == null || crystal.isDead)
                    continue;
                renderBlastRadius(crystal.posX, crystal.posY, crystal.posZ, crystalBlockRadius.getValue(), crystalDamageRadius.getValue());
            }
        }
        if (showTNT.getValue()) {
            for (EntityTNTPrimed tnt : mc.world.getEntitiesWithinAABB(EntityTNTPrimed.class, mc.player.getEntityBoundingBox().expand(32, 32, 32))) {
                if (tnt == null || tnt.isDead)
                    continue;
                renderBlastRadius(tnt.posX, tnt.posY, tnt.posZ, tntBlockRadius.getValue(), tntDamageRadius.getValue());
            }
        }
        RenderUtils.restoreGL();
    }

    private void renderBlastRadius(double posX, double posY, double posZ, double blockRadius, double damageRadius) {
        double x = posX - RenderUtils.camX;
        double y = posY - RenderUtils.camY;
        double z = posZ - RenderUtils.camZ;
        if (showBlockRadius.getValue()) {
            AxisAlignedBB blockBB = new AxisAlignedBB(x - blockRadius, y - blockRadius, z - blockRadius, x + blockRadius, y + blockRadius, z + blockRadius);
            float r = blockRed.getValue().floatValue();
            float g = blockGreen.getValue().floatValue();
            float b = blockBlue.getValue().floatValue();
            float a = blockAlpha.getValue().floatValue();
            RenderUtils.drawSolidBox(blockBB, r, g, b, a);
            RenderUtils.drawOutlinedBox(blockBB, r, g, b, 0.6f);
        }
        if (showDamageRadius.getValue()) {
            AxisAlignedBB dmgBB = new AxisAlignedBB(x - damageRadius, y - damageRadius, z - damageRadius, x + damageRadius, y + damageRadius, z + damageRadius);
            float r = dmgRed.getValue().floatValue();
            float g = dmgGreen.getValue().floatValue();
            float b = dmgBlue.getValue().floatValue();
            float a = dmgAlpha.getValue().floatValue();
            RenderUtils.drawSolidBox(dmgBB, r, g, b, a);
            RenderUtils.drawOutlinedBox(dmgBB, r, g, b, 0.4f);
        }
        if (showBlastRing.getValue()) {
            float r = blockRed.getValue().floatValue();
            float g = blockGreen.getValue().floatValue();
            float b = blockBlue.getValue().floatValue();
            drawBlastRing(x, y, z, blockRadius, r, g, b, 0.5f);
        }
    }

    private void drawBlastRing(double x, double y, double z, double radius, float r, float g, float b, float a) {
        int segments = 32;
        double prevX = 0, prevZ = 0;
        for (int i = 0; i <= segments; i++) {
            double angle = (double) i / segments * Math.PI * 2.0;
            double cx = x + Math.cos(angle) * radius;
            double cz = z + Math.sin(angle) * radius;
            if (i > 0) {
                RenderUtils.drawLine(prevX, y, prevZ, cx, y, cz, r, g, b, a);
            }
            prevX = cx;
            prevZ = cz;
        }
    }
}
