package client.module.impl.render;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import client.module.ColorSetting;
import client.utils.EntityUtils;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;

public class Arrows extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting targetPlayers = new BooleanSetting("Players", true);

    private final BooleanSetting targetHostile = new BooleanSetting("Hostile Mobs", true);

    private final BooleanSetting targetPassive = new BooleanSetting("Passive Mobs", false);

    private final BooleanSetting showDistance = new BooleanSetting("Show Distance", true);

    private final NumberSetting maxDistance = new NumberSetting("Max Distance", 64.0, 16.0, 256.0);

    private final NumberSetting arrowSize = new NumberSetting("Arrow Size", 8.0, 4.0, 20.0);

    private final NumberSetting edgeMargin = new NumberSetting("Edge Margin", 20.0, 5.0, 100.0);

    private final ColorSetting playerColor = new ColorSetting("Player Color", 0.0);

    private final ColorSetting hostileColor = new ColorSetting("Hostile Color", 30.0);

    private final ColorSetting passiveColor = new ColorSetting("Passive Color", 120.0);

    public Arrows() {
        super("Arrows", Category.RENDER);
        setDescription("Shows arrows pointing to off-screen entities");
        addSetting(targetPlayers);
        addSetting(targetHostile);
        addSetting(targetPassive);
        addSetting(showDistance);
        addSetting(maxDistance);
        addSetting(arrowSize);
        addSetting(edgeMargin);
        addSetting(playerColor);
        addSetting(hostileColor);
        addSetting(passiveColor);
        handles(HandlerType.GUI_RENDER);
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (mc.currentScreen != null)
            return;
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        int screenWidth = sr.getScaledWidth();
        int screenHeight = sr.getScaledHeight();
        int centerX = screenWidth / 2;
        int centerY = screenHeight / 2;
        double screenRadius = Math.min(screenWidth, screenHeight) / 2.0 - edgeMargin.getValue();
        double maxDist = maxDistance.getValue();
        double size = arrowSize.getValue();
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (entity == mc.player)
                continue;
            if (!(entity instanceof EntityLivingBase))
                continue;
            EntityLivingBase living = (EntityLivingBase) entity;
            if (!living.isEntityAlive())
                continue;
            boolean isPlayer = living instanceof EntityPlayer;
            boolean isHostile = living instanceof EntityMob;
            boolean isPassive = living instanceof EntityAnimal;
            if (isPlayer && !targetPlayers.getValue())
                continue;
            if (isHostile && !targetHostile.getValue())
                continue;
            if (isPassive && !targetPassive.getValue())
                continue;
            if (!isPlayer && !isHostile && !isPassive)
                continue;
            if (isPlayer && client.utils.misc.FriendManager.isFriend((EntityPlayer) living))
                continue;
            double dist = mc.player.getDistanceToEntity(living);
            if (dist > maxDist)
                continue;
            double diffX = living.posX - mc.player.posX;
            double diffZ = living.posZ - mc.player.posZ;
            float yawToEntity = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
            float angleDiff = normalizeAngle(yawToEntity - mc.player.rotationYaw);
            double diffY = (living.posY + living.height / 2.0) - (mc.player.posY + mc.player.getEyeHeight());
            double horizontalDist = Math.sqrt(diffX * diffX + diffZ * diffZ);
            float pitchToEntity = (float) -Math.toDegrees(Math.atan2(diffY, horizontalDist));
            float pitchDiff = pitchToEntity - mc.player.rotationPitch;
            float[] screenPos = client.utils.render.WorldToScreenProjector.project(living.posX, living.posY + living.height / 2.0, living.posZ);
            if (screenPos != null) {
                continue;
            }
            double angleRad = Math.toRadians(angleDiff);
            double pitchRad = Math.toRadians(pitchDiff);
            double totalAngle = Math.sqrt(angleDiff * angleDiff + pitchDiff * pitchDiff);
            double clampedAngle = Math.min(totalAngle, 90.0) / totalAngle;
            double arrowX = centerX + Math.sin(angleRad) * screenRadius * clampedAngle;
            double arrowY = centerY - Math.sin(pitchRad) * screenRadius * clampedAngle;
            arrowX = Math.max(edgeMargin.getValue(), Math.min(screenWidth - edgeMargin.getValue(), arrowX));
            arrowY = Math.max(edgeMargin.getValue(), Math.min(screenHeight - edgeMargin.getValue(), arrowY));
            float[] rgb = getColor(isPlayer, isHostile);
            int argb = colorToInt(rgb);
            double sizeScale = 1.0 - (dist / maxDist) * 0.5;
            double arrowSizeScaled = size * sizeScale;
            float ax = (float) arrowX;
            float ay = (float) arrowY;
            float as = (float) arrowSizeScaled;
            RenderUtils.drawRect2D(ax - as / 2, ay - as / 2, ax + as / 2, ay + as / 2, argb);
            if (showDistance.getValue()) {
                String distText = String.format("%.0f", dist);
                ClientFontRenderer.drawCenteredStringWithShadow(distText, (float) arrowX, (float) (arrowY + as / 2 + 2), argb);
            }
        }
    }

    private float normalizeAngle(float angle) {
        while (angle > 180) angle -= 360;
        while (angle < -180) angle += 360;
        return angle;
    }

    private float[] getColor(boolean isPlayer, boolean isHostile) {
        ColorSetting cs;
        if (isPlayer)
            cs = playerColor;
        else if (isHostile)
            cs = hostileColor;
        else
            cs = passiveColor;
        return cs.getRGBFloat();
    }

    private int colorToInt(float[] rgb) {
        return 0xFF000000 | ((int) (rgb[0] * 255) << 16) | ((int) (rgb[1] * 255) << 8) | (int) (rgb[2] * 255);
    }
}
