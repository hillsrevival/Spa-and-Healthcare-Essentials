package client.module.impl.render;

import java.util.ArrayList;
import java.util.List;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.ChatUtils;
import client.utils.render.RenderUtils;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.Chunk;
import client.utils.world.WorldUtils;

public class BaseFinder extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final List<Long> scannedKeys = new ArrayList<>();

    private final List<List<AxisAlignedBB>> chunkResults = new ArrayList<>();

    private final List<AxisAlignedBB> foundBoxes = new ArrayList<>();

    private boolean resultsDirty = true;

    public BaseFinder() {
        super("BaseFinder", Category.RENDER);
        setDescription("Finds bases by highlights blocks that cant naturally generate");
        handles(HandlerType.UPDATE, HandlerType.RENDER);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        scannedKeys.clear();
        chunkResults.clear();
        foundBoxes.clear();
        resultsDirty = true;
        ChatUtils.message("BaseFinder: Scanning for man-made blocks...");
    }

    private static long chunkKey(int cx, int cz) {
        return (((long) (cx)) & 0xFFFFFFFFL) | ((((long) (cz)) & 0xFFFFFFFFL) << 32);
    }

    private boolean isChunkScanned(long key) {
        for (int i = 0; i < scannedKeys.size(); i++) {
            if (scannedKeys.get(i).longValue() == key)
                return true;
        }
        return false;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        int pcx = mc.player.chunkCoordX;
        int pcz = mc.player.chunkCoordZ;
        List<ChunkPos> loaded = new ArrayList<>();
        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                int cx = pcx + dx;
                int cz = pcz + dz;
                Chunk chunk = WorldUtils.getChunk(cx, cz);
                if (chunk != null && !chunk.isEmpty() && chunk.isLoaded()) {
                    loaded.add(new ChunkPos(cx, cz));
                }
            }
        }
        for (int i = scannedKeys.size() - 1; i >= 0; i--) {
            long key = scannedKeys.get(i).longValue();
            int cx = (int) (key & 0xFFFFFFFFL);
            int cz = (int) ((key >> 32) & 0xFFFFFFFFL);
            boolean stillLoaded = false;
            for (int j = 0; j < loaded.size(); j++) {
                ChunkPos cp = loaded.get(j);
                if (cp.chunkXPos == cx && cp.chunkZPos == cz) {
                    stillLoaded = true;
                    break;
                }
            }
            if (!stillLoaded) {
                scannedKeys.remove(i);
                chunkResults.remove(i);
                resultsDirty = true;
            }
        }
        int scanned = 0;
        for (int i = 0; i < loaded.size() && scanned < 3; i++) {
            ChunkPos cp = loaded.get(i);
            long key = chunkKey(cp.chunkXPos, cp.chunkZPos);
            if (isChunkScanned(key))
                continue;
            List<AxisAlignedBB> boxes = scanChunk(cp.chunkXPos, cp.chunkZPos);
            scannedKeys.add(key);
            chunkResults.add(boxes);
            resultsDirty = true;
            scanned++;
        }
        if (resultsDirty) {
            foundBoxes.clear();
            for (int i = 0; i < chunkResults.size(); i++) {
                List<AxisAlignedBB> boxes = chunkResults.get(i);
                for (int j = 0; j < boxes.size() && foundBoxes.size() < 8000; j++) {
                    foundBoxes.add(boxes.get(j));
                }
            }
            resultsDirty = false;
        }
    }

    private List<AxisAlignedBB> scanChunk(int cx, int cz) {
        List<AxisAlignedBB> boxes = new ArrayList<>();
        int baseX = cx << 4;
        int baseZ = cz << 4;
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                for (int y = 0; y < 256; y++) {
                    BlockPos pos = new BlockPos(baseX + x, y, baseZ + z);
                    Block block = mc.world.getBlockState(pos).getBlock();
                    if (block == Blocks.AIR)
                        continue;
                    if (isNaturalBlock(block))
                        continue;
                    if (boxes.size() >= 2000)
                        break;
                    boxes.add(new AxisAlignedBB(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1));
                }
                if (boxes.size() >= 2000)
                    break;
            }
            if (boxes.size() >= 2000)
                break;
        }
        return boxes;
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (foundBoxes.isEmpty())
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        RenderUtils.prepareGL();
        for (int i = 0; i < foundBoxes.size(); i++) {
            AxisAlignedBB bb = foundBoxes.get(i);
            AxisAlignedBB render = bb.offset(-RenderUtils.camX, -RenderUtils.camY, -RenderUtils.camZ);
            RenderUtils.drawSolidBox(render, 1.0f, 0.0f, 0.0f, 0.15f);
            RenderUtils.drawOutlinedBox(render, 1.0f, 0.0f, 0.0f, 0.5f);
        }
        RenderUtils.restoreGL();
    }

    private boolean isNaturalBlock(Block b) {
        if (b == Blocks.AIR)
            return true;
        if (b == Blocks.STONE)
            return true;
        if (b == Blocks.DIRT)
            return true;
        if (b == Blocks.GRASS)
            return true;
        if (b == Blocks.GRAVEL)
            return true;
        if (b == Blocks.SAND)
            return true;
        if (b == Blocks.CLAY)
            return true;
        if (b == Blocks.SANDSTONE)
            return true;
        if (b == Blocks.RED_SANDSTONE)
            return true;
        if (b == Blocks.HARDENED_CLAY)
            return true;
        if (b == Blocks.STAINED_HARDENED_CLAY)
            return true;
        if (b == Blocks.BEDROCK)
            return true;
        if (b == Blocks.GRASS_PATH)
            return true;
        if (b == Blocks.FARMLAND)
            return true;
        if (b == Blocks.SOUL_SAND)
            return true;
        if (b == Blocks.MYCELIUM)
            return true;
        if (b == Blocks.WATER)
            return true;
        if (b == Blocks.FLOWING_WATER)
            return true;
        if (b == Blocks.LAVA)
            return true;
        if (b == Blocks.FLOWING_LAVA)
            return true;
        if (b == Blocks.ICE)
            return true;
        if (b == Blocks.PACKED_ICE)
            return true;
        if (b == Blocks.FROSTED_ICE)
            return true;
        if (b == Blocks.COAL_ORE)
            return true;
        if (b == Blocks.IRON_ORE)
            return true;
        if (b == Blocks.GOLD_ORE)
            return true;
        if (b == Blocks.DIAMOND_ORE)
            return true;
        if (b == Blocks.EMERALD_ORE)
            return true;
        if (b == Blocks.REDSTONE_ORE)
            return true;
        if (b == Blocks.LIT_REDSTONE_ORE)
            return true;
        if (b == Blocks.LAPIS_ORE)
            return true;
        if (b == Blocks.QUARTZ_ORE)
            return true;
        if (b == Blocks.LOG)
            return true;
        if (b == Blocks.LOG2)
            return true;
        if (b == Blocks.LEAVES)
            return true;
        if (b == Blocks.LEAVES2)
            return true;
        if (b == Blocks.TALLGRASS)
            return true;
        if (b == Blocks.DEADBUSH)
            return true;
        if (b == Blocks.YELLOW_FLOWER)
            return true;
        if (b == Blocks.RED_FLOWER)
            return true;
        if (b == Blocks.DOUBLE_PLANT)
            return true;
        if (b == Blocks.VINE)
            return true;
        if (b == Blocks.RED_MUSHROOM)
            return true;
        if (b == Blocks.BROWN_MUSHROOM)
            return true;
        if (b == Blocks.RED_MUSHROOM_BLOCK)
            return true;
        if (b == Blocks.BROWN_MUSHROOM_BLOCK)
            return true;
        if (b == Blocks.MELON_BLOCK)
            return true;
        if (b == Blocks.PUMPKIN)
            return true;
        if (b == Blocks.LIT_PUMPKIN)
            return true;
        if (b == Blocks.CACTUS)
            return true;
        if (b == Blocks.REEDS)
            return true;
        if (b == Blocks.WATERLILY)
            return true;
        if (b == Blocks.SNOW_LAYER)
            return true;
        if (b == Blocks.SNOW)
            return true;
        if (b == Blocks.WEB)
            return true;
        if (b == Blocks.HAY_BLOCK)
            return true;
        if (b == Blocks.WHEAT)
            return true;
        if (b == Blocks.CARROTS)
            return true;
        if (b == Blocks.POTATOES)
            return true;
        if (b == Blocks.BEETROOTS)
            return true;
        if (b == Blocks.NETHER_WART)
            return true;
        if (b == Blocks.PUMPKIN_STEM)
            return true;
        if (b == Blocks.MELON_STEM)
            return true;
        if (b == Blocks.COCOA)
            return true;
        if (b == Blocks.MOB_SPAWNER)
            return true;
        if (b == Blocks.OBSIDIAN)
            return true;
        if (b == Blocks.MONSTER_EGG)
            return true;
        if (b == Blocks.MOSSY_COBBLESTONE)
            return true;
        if (b == Blocks.DRAGON_EGG)
            return true;
        if (b == Blocks.END_PORTAL)
            return true;
        if (b == Blocks.END_PORTAL_FRAME)
            return true;
        if (b == Blocks.PLANKS)
            return true;
        if (b == Blocks.COBBLESTONE)
            return true;
        if (b == Blocks.STONEBRICK)
            return true;
        if (b == Blocks.COBBLESTONE_WALL)
            return true;
        if (b == Blocks.STONE_STAIRS)
            return true;
        if (b == Blocks.OAK_STAIRS)
            return true;
        if (b == Blocks.SPRUCE_STAIRS)
            return true;
        if (b == Blocks.BIRCH_STAIRS)
            return true;
        if (b == Blocks.JUNGLE_STAIRS)
            return true;
        if (b == Blocks.ACACIA_STAIRS)
            return true;
        if (b == Blocks.DARK_OAK_STAIRS)
            return true;
        if (b == Blocks.STONE_SLAB)
            return true;
        if (b == Blocks.STONE_SLAB2)
            return true;
        if (b == Blocks.WOODEN_SLAB)
            return true;
        if (b == Blocks.DOUBLE_STONE_SLAB)
            return true;
        if (b == Blocks.DOUBLE_STONE_SLAB2)
            return true;
        if (b == Blocks.DOUBLE_WOODEN_SLAB)
            return true;
        if (b == Blocks.BOOKSHELF)
            return true;
        if (b == Blocks.GLASS)
            return true;
        if (b == Blocks.GLASS_PANE)
            return true;
        if (b == Blocks.WOOL)
            return true;
        if (b == Blocks.IRON_BARS)
            return true;
        if (b == Blocks.TORCH)
            return true;
        if (b == Blocks.REDSTONE_TORCH)
            return true;
        if (b == Blocks.UNLIT_REDSTONE_TORCH)
            return true;
        if (b == Blocks.LADDER)
            return true;
        if (b == Blocks.RAIL)
            return true;
        if (b == Blocks.GOLDEN_RAIL)
            return true;
        if (b == Blocks.DETECTOR_RAIL)
            return true;
        if (b == Blocks.ACTIVATOR_RAIL)
            return true;
        if (b == Blocks.CHEST)
            return true;
        if (b == Blocks.TRAPPED_CHEST)
            return true;
        if (b == Blocks.ENDER_CHEST)
            return true;
        if (b == Blocks.TNT)
            return true;
        if (b == Blocks.DISPENSER)
            return true;
        if (b == Blocks.DROPPER)
            return true;
        if (b == Blocks.LEVER)
            return true;
        if (b == Blocks.STONE_PRESSURE_PLATE)
            return true;
        if (b == Blocks.WOODEN_PRESSURE_PLATE)
            return true;
        if (b == Blocks.OAK_DOOR)
            return true;
        if (b == Blocks.IRON_DOOR)
            return true;
        if (b == Blocks.TRAPDOOR)
            return true;
        if (b == Blocks.IRON_TRAPDOOR)
            return true;
        if (b == Blocks.CRAFTING_TABLE)
            return true;
        if (b == Blocks.FURNACE)
            return true;
        if (b == Blocks.LIT_FURNACE)
            return true;
        if (b == Blocks.ANVIL)
            return true;
        if (b == Blocks.BREWING_STAND)
            return true;
        if (b == Blocks.CAULDRON)
            return true;
        if (b == Blocks.ENCHANTING_TABLE)
            return true;
        if (b == Blocks.FLOWER_POT)
            return true;
        if (b == Blocks.SKULL)
            return true;
        if (b == Blocks.OAK_FENCE)
            return true;
        if (b == Blocks.SPRUCE_FENCE)
            return true;
        if (b == Blocks.BIRCH_FENCE)
            return true;
        if (b == Blocks.JUNGLE_FENCE)
            return true;
        if (b == Blocks.DARK_OAK_FENCE)
            return true;
        if (b == Blocks.ACACIA_FENCE)
            return true;
        if (b == Blocks.OAK_FENCE_GATE)
            return true;
        if (b == Blocks.SPRUCE_FENCE_GATE)
            return true;
        if (b == Blocks.BIRCH_FENCE_GATE)
            return true;
        if (b == Blocks.JUNGLE_FENCE_GATE)
            return true;
        if (b == Blocks.DARK_OAK_FENCE_GATE)
            return true;
        if (b == Blocks.ACACIA_FENCE_GATE)
            return true;
        if (b == Blocks.JUKEBOX)
            return true;
        if (b == Blocks.BED)
            return true;
        if (b == Blocks.NETHERRACK)
            return true;
        if (b == Blocks.GLOWSTONE)
            return true;
        if (b == Blocks.NETHER_BRICK)
            return true;
        if (b == Blocks.NETHER_BRICK_FENCE)
            return true;
        if (b == Blocks.NETHER_BRICK_STAIRS)
            return true;
        if (b == Blocks.MAGMA)
            return true;
        if (b == Blocks.QUARTZ_BLOCK)
            return true;
        if (b == Blocks.QUARTZ_STAIRS)
            return true;
        if (b == Blocks.END_STONE)
            return true;
        if (b == Blocks.PURPUR_BLOCK)
            return true;
        if (b == Blocks.PURPUR_PILLAR)
            return true;
        if (b == Blocks.PURPUR_STAIRS)
            return true;
        if (b == Blocks.CHORUS_PLANT)
            return true;
        if (b == Blocks.CHORUS_FLOWER)
            return true;
        if (b == Blocks.SPONGE)
            return true;
        if (b == Blocks.PRISMARINE)
            return true;
        if (b == Blocks.SEA_LANTERN)
            return true;
        if (b == Blocks.BONE_BLOCK)
            return true;
        return false;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        scannedKeys.clear();
        chunkResults.clear();
        foundBoxes.clear();
        resultsDirty = true;
    }
}
