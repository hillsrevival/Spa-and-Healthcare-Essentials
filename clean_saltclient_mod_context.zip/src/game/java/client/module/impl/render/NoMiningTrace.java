package client.module.impl.render;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.client.Minecraft;

public class NoMiningTrace extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public NoMiningTrace() {
        super("NoMiningTrace", Category.RENDER);
        setDescription("Removes the crack overlay when mining blocks");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.renderGlobal != null) {
            mc.renderGlobal.clearMiningOverlay();
        }
    }
}
