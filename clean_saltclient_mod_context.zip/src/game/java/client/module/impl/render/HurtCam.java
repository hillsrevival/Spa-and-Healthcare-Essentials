package client.module.impl.render;

import client.module.Category;
import client.module.Module;
import client.module.NumberSetting;

public class HurtCam extends Module {

    private final NumberSetting intensity = new NumberSetting("Intensity", 1.0, 0.0, 3.0);

    public HurtCam() {
        super("HurtCam", Category.RENDER);
        setDescription("Adjust the hurt camera shake intensity (1.0 = normal, 0.0 = disabled)");
        addSetting(intensity);
    }

    public float getIntensity() {
        return intensity.getValue().floatValue();
    }
}
