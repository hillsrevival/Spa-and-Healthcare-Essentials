package client.module.impl.render;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;

public class Zoom extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting zoom = new NumberSetting("Zoom", 2.0, 1.5, 8.0);

    private float savedFovModifier = -1.0f;

    public Zoom() {
        super("Zoom", Category.RENDER);
        setDescription("Zooms in");
        addSetting(zoom);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.gameSettings == null)
            return;
        savedFovModifier = mc.gameSettings.fovSetting;
        mc.gameSettings.fovSetting = savedFovModifier / zoom.getValue().floatValue();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.gameSettings != null && savedFovModifier > 0.0f) {
            mc.gameSettings.fovSetting = savedFovModifier;
            savedFovModifier = -1.0f;
        }
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        mc.gameSettings.fovSetting = savedFovModifier / zoom.getValue().floatValue();
    }
}
