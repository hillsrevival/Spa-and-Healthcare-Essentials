package client.module.impl.render;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.render.RenderUtils;
import client.utils.EntityUtils;

public class HealthTags extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting heightOffset = new NumberSetting("Height", 0.3, 0.0, 1.0);

    private final NumberSetting barWidth = new NumberSetting("Width", 0.8, 0.4, 1.5);

    private final NumberSetting barHeight = new NumberSetting("Thickness", 0.1, 0.05, 0.3);

    private final List<EntityPlayer> players = new ArrayList<>();

    public HealthTags() {
        super("HealthTags", Category.RENDER);
        setDescription("Shows health bars above nametags");
        addSetting(heightOffset);
        addSetting(barWidth);
        addSetting(barHeight);
        handles(HandlerType.UPDATE, HandlerType.RENDER);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        players.clear();
        for (EntityPlayer player : EntityUtils.getLoadedPlayers()) {
            if (player == mc.player)
                continue;
            if (player.isDead || player.getHealth() <= 0)
                continue;
            players.add(player);
        }
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (players.isEmpty())
            return;
        float partialTicks = event.getPartialTicks();
        RenderUtils.updateCameraPos(partialTicks);
        RenderUtils.prepareGL();
        float offset = heightOffset.getValue().floatValue();
        float width = barWidth.getValue().floatValue();
        float thickness = barHeight.getValue().floatValue();
        for (EntityPlayer player : players) {
            float health = player.getHealth();
            float maxHealth = player.getMaxHealth();
            float percent = Math.max(0.0f, Math.min(1.0f, health / maxHealth));
            double x = player.prevPosX + (player.posX - player.prevPosX) * partialTicks - RenderUtils.camX;
            double y = player.prevPosY + (player.posY - player.prevPosY) * partialTicks - RenderUtils.camY + player.height + offset;
            double z = player.prevPosZ + (player.posZ - player.prevPosZ) * partialTicks - RenderUtils.camZ;
            AxisAlignedBB bgBar = new AxisAlignedBB(x - width / 2.0, y, z - 0.01, x + width / 2.0, y + thickness, z + 0.01);
            RenderUtils.drawSolidBox(bgBar, 0, 0, 0, 0.5f);
            float healthWidth = width * percent;
            float green = percent;
            float red = 1.0f - percent;
            AxisAlignedBB hpBar = new AxisAlignedBB(x - width / 2.0, y, z - 0.01, x - width / 2.0 + healthWidth, y + thickness, z + 0.01);
            RenderUtils.drawSolidBox(hpBar, red, green, 0, 0.8f);
            RenderUtils.drawOutlinedBox(bgBar, 0.3f, 0.3f, 0.3f, 0.4f);
        }
        RenderUtils.restoreGL();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        players.clear();
    }
}
