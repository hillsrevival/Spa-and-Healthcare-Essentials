package client.module.impl.items;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiBrewingStand;
import net.minecraft.init.Items;
import net.minecraft.init.PotionTypes;
import net.minecraft.inventory.ContainerBrewingStand;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionUtils;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;

public class AutoBrewer extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting delay = new NumberSetting("Delay", 3.0, 0.0, 20.0);

    private final BooleanSetting autoClose = new BooleanSetting("AutoClose", false);

    private final BooleanSetting takeOutput = new BooleanSetting("TakeOutput", true);

    private final BooleanSetting putBottles = new BooleanSetting("PutBottles", true);

    private final BooleanSetting putIngredient = new BooleanSetting("PutIngredient", true);

    private final BooleanSetting putFuel = new BooleanSetting("PutFuel", true);

    private int timer = 0;

    public AutoBrewer() {
        super("AutoBrewer", Category.ITEMS);
        setDescription("Automatically fills a brewing stand with ingredients");
        addSetting(delay);
        addSetting(autoClose);
        addSetting(takeOutput);
        addSetting(putBottles);
        addSetting(putIngredient);
        addSetting(putFuel);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!(mc.currentScreen instanceof GuiBrewingStand))
            return;
        if (timer > 0) {
            timer--;
            return;
        }
        if (!(mc.player.openContainer instanceof ContainerBrewingStand))
            return;
        ContainerBrewingStand brewing = (ContainerBrewingStand) mc.player.openContainer;
        if (takeOutput.getValue()) {
            for (int i = 0; i < 3; i++) {
                ItemStack potion = brewing.getSlot(i).getStack();
                if (potion.func_190926_b())
                    continue;
                if (PotionUtils.getPotionFromItem(potion) != PotionTypes.WATER) {
                    int brewTime = brewing.getSlot(0).getStack().func_190926_b() ? 0 : 1;
                    mc.playerController.windowClick(brewing.windowId, i, 0, net.minecraft.inventory.ClickType.QUICK_MOVE, mc.player);
                    timer = delay.getValue().intValue();
                    return;
                }
            }
        }
        if (putBottles.getValue()) {
            for (int i = 0; i < 3; i++) {
                ItemStack slot = brewing.getSlot(i).getStack();
                if (slot.func_190926_b()) {
                    int bottleSlot = findWaterBottle();
                    if (bottleSlot != -1) {
                        int containerSlot = bottleSlot < 9 ? bottleSlot + 5 : bottleSlot - 9 + 5;
                        int cSlot = bottleSlot < 9 ? bottleSlot + 32 : bottleSlot - 9 + 5;
                        mc.playerController.windowClick(brewing.windowId, cSlot, 0, net.minecraft.inventory.ClickType.QUICK_MOVE, mc.player);
                        timer = delay.getValue().intValue();
                        return;
                    }
                }
            }
        }
        if (putIngredient.getValue()) {
            ItemStack ingredientSlot = brewing.getSlot(3).getStack();
            if (ingredientSlot.func_190926_b()) {
                boolean hasBottles = false;
                for (int i = 0; i < 3; i++) {
                    ItemStack s = brewing.getSlot(i).getStack();
                    if (!s.func_190926_b() && PotionUtils.getPotionFromItem(s) == PotionTypes.WATER) {
                        hasBottles = true;
                        break;
                    }
                }
                if (hasBottles) {
                    int ingSlot = findIngredient();
                    if (ingSlot != -1) {
                        int cSlot = ingSlot < 9 ? ingSlot + 32 : ingSlot - 9 + 5;
                        mc.playerController.windowClick(brewing.windowId, cSlot, 0, net.minecraft.inventory.ClickType.QUICK_MOVE, mc.player);
                        timer = delay.getValue().intValue();
                        return;
                    }
                }
            }
        }
        if (putFuel.getValue()) {
            ItemStack fuelSlot = brewing.getSlot(4).getStack();
            if (fuelSlot.func_190926_b()) {
                int blazeSlot = findBlazePowder();
                if (blazeSlot != -1) {
                    int cSlot = blazeSlot < 9 ? blazeSlot + 32 : blazeSlot - 9 + 5;
                    mc.playerController.windowClick(brewing.windowId, cSlot, 0, net.minecraft.inventory.ClickType.QUICK_MOVE, mc.player);
                    timer = delay.getValue().intValue();
                    return;
                }
            }
        }
    }

    private int findWaterBottle() {
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.func_190926_b())
                continue;
            if (stack.getItem() == Items.POTIONITEM && PotionUtils.getPotionFromItem(stack) == PotionTypes.WATER) {
                return i;
            }
        }
        return -1;
    }

    private int findIngredient() {
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.func_190926_b())
                continue;
            if (stack.getItem() == Items.NETHER_WART || stack.getItem() == Items.GUNPOWDER || stack.getItem() == Items.DRAGON_BREATH || stack.getItem() == Items.SUGAR || stack.getItem() == Items.RABBIT_FOOT || stack.getItem() == Items.GLOWSTONE_DUST || stack.getItem() == Items.REDSTONE || stack.getItem() == Items.FERMENTED_SPIDER_EYE || stack.getItem() == Items.SPECKLED_MELON || stack.getItem() == Items.GHAST_TEAR || stack.getItem() == Items.BLAZE_POWDER || stack.getItem() == Items.MAGMA_CREAM || stack.getItem() == Items.GOLDEN_CARROT || stack.getItem() == Items.FISH || stack.getItem() == Items.SPIDER_EYE || stack.getItem() == Items.PUMPKIN_PIE) {
                return i;
            }
        }
        return -1;
    }

    private int findBlazePowder() {
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (!stack.func_190926_b() && stack.getItem() == Items.BLAZE_POWDER) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        timer = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        timer = 0;
    }
}
