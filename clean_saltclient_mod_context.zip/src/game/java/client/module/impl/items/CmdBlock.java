package client.module.impl.items;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagString;
import java.io.IOException;
import client.module.Category;
import client.module.Module;
import client.utils.misc.ChatUtils;
import client.utils.render.ClientFontRenderer;

public class CmdBlock extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private String command = "/";

    private GuiScreen prevScreen;

    public CmdBlock() {
        super("CmdBlock", Category.ITEMS);
        setDescription("Allows you to use command blocks in creative mode");
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null || mc.world == null) {
            toggle();
            return;
        }
        if (!mc.player.capabilities.isCreativeMode) {
            ChatUtils.error("CmdBlock requires Creative mode!");
            toggle();
            return;
        }
        prevScreen = mc.currentScreen;
        mc.displayGuiScreen(new GuiCmdBlock(this));
    }

    public void giveCommandBlock(String cmd) {
        if (mc.player == null)
            return;
        this.command = cmd;
        ItemStack cmdBlock = new ItemStack(Item.getItemFromBlock(Blocks.COMMAND_BLOCK), 1);
        NBTTagCompound nbt = new NBTTagCompound();
        cmdBlock.writeToNBT(nbt);
        nbt.setTag("Command", new NBTTagString(cmd));
        cmdBlock.setTagInfo("BlockEntityTag", nbt);
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == null || stack.func_190926_b()) {
                slot = i;
                break;
            }
        }
        if (slot == -1) {
            ChatUtils.error("No empty hotbar slot!");
        } else {
            mc.player.inventory.mainInventory.set(slot, cmdBlock);
            mc.player.inventory.currentItem = slot;
            mc.player.inventoryContainer.detectAndSendChanges();
            ChatUtils.success("Command Block created with: " + cmd);
        }
        toggle();
    }

    public void onCancelled() {
        if (prevScreen != null) {
            mc.displayGuiScreen(prevScreen);
        } else {
            mc.displayGuiScreen(null);
        }
        ChatUtils.message("CmdBlock cancelled");
        toggle();
    }

    public static class GuiCmdBlock extends GuiScreen {

        private final CmdBlock module;

        private GuiTextField textField;

        private GuiButton doneButton;

        private GuiButton cancelButton;

        public GuiCmdBlock(CmdBlock module) {
            this.module = module;
        }

        @Override
        public void initGui() {
            int centerX = width / 2;
            int centerY = height / 2;
            textField = new GuiTextField(0, ClientFontRenderer.getFontRenderer(), centerX - 150, centerY - 30, 300, 20);
            textField.setMaxStringLength(100);
            textField.setFocused(true);
            textField.setText(module.command);
            doneButton = new GuiButton(1, centerX - 100, centerY + 10, 90, 20, "Done");
            cancelButton = new GuiButton(2, centerX + 10, centerY + 10, 90, 20, "Cancel");
            buttonList.add(doneButton);
            buttonList.add(cancelButton);
        }

        @Override
        public void updateScreen() {
            if (textField != null) {
                textField.updateCursorCounter();
            }
        }

        @Override
        public void drawScreen(int mouseX, int mouseY, float partialTicks) {
            drawDefaultBackground();
            ClientFontRenderer.drawCenteredStringWithShadow("Enter Command Block Command", width / 2, height / 2 - 60, 0xFFFFFF);
            if (textField != null) {
                textField.drawTextBox();
            }
            super.drawScreen(mouseX, mouseY, partialTicks);
        }

        @Override
        protected void keyTyped(char typedChar, int keyCode) {
            if (textField != null) {
                textField.textboxKeyTyped(typedChar, keyCode);
            }
            if (keyCode == 28) {
                actionPerformed(doneButton);
            }
        }

        @Override
        protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
            super.mouseClicked(mouseX, mouseY, mouseButton);
            if (textField != null) {
                textField.mouseClicked(mouseX, mouseY, mouseButton);
            }
        }

        @Override
        protected void actionPerformed(GuiButton button) {
            if (button.id == 1) {
                String cmd = textField != null ? textField.getText() : "";
                if (cmd.isEmpty())
                    cmd = "/";
                module.giveCommandBlock(cmd);
            } else if (button.id == 2) {
                module.onCancelled();
            }
        }

        @Override
        public void onGuiClosed() {
        }
    }
}
