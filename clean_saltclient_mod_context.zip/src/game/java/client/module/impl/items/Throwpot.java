package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.misc.NotificationSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemSplashPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionUtils;
import net.minecraft.util.EnumHand;
import java.util.List;

public class Throwpot extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting delay = new NumberSetting("Delay", 2.0, 1.0, 10.0);

    private int savedSlot = -1;

    private int currentSlot = 0;

    private int tickCounter = 0;

    private boolean throwing = false;

    public Throwpot() {
        super("Throwpot", Category.ITEMS);
        setDescription("Automatically throws all healing potions");
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null)
            return;
        savedSlot = mc.player.inventory.currentItem;
        currentSlot = 0;
        tickCounter = 0;
        throwing = true;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!throwing)
            return;
        tickCounter++;
        int delayTicks = delay.getValue().intValue();
        if (tickCounter < delayTicks)
            return;
        tickCounter = 0;
        while (currentSlot < 9) {
            ItemStack stack = mc.player.inventory.getStackInSlot(currentSlot);
            if (stack != null && !stack.func_190926_b() && stack.getItem() instanceof ItemSplashPotion && isHealingPotion(stack)) {
                mc.player.inventory.currentItem = currentSlot;
                mc.playerController.updateController();
                mc.playerController.processRightClick(mc.player, mc.world, EnumHand.MAIN_HAND);
                currentSlot++;
                return;
            }
            currentSlot++;
        }
        if (savedSlot != -1) {
            mc.player.inventory.currentItem = savedSlot;
        }
        throwing = false;
        NotificationSystem.success("Potions thrown!");
        toggle();
    }

    private boolean isHealingPotion(ItemStack stack) {
        List<PotionEffect> effects = PotionUtils.getEffectsFromStack(stack);
        for (PotionEffect effect : effects) {
            if (effect.getPotion() == MobEffects.INSTANT_HEALTH || effect.getPotion() == MobEffects.REGENERATION) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (savedSlot != -1 && mc.player != null) {
            mc.player.inventory.currentItem = savedSlot;
        }
        throwing = false;
        savedSlot = -1;
    }
}
