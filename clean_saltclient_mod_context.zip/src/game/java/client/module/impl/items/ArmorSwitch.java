package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.ModeSetting;
import client.utils.world.InventoryClickQueue;
import client.utils.misc.NotificationSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

public class ArmorSwitch extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting targetSet = new ModeSetting("Target Set", "Diamond", "Diamond", "Gold", "Iron", "Chainmail", "Leather");

    private final NumberSetting delay = new NumberSetting("Delay", 100.0, 50.0, 500.0);

    private boolean swapping = false;

    private int swapTimer = 0;

    public ArmorSwitch() {
        super("ArmorSwitch", Category.ITEMS);
        setDescription("Quick swap between armor sets");
        addSetting(targetSet);
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        InventoryClickQueue.tick();
        if (swapping) {
            swapTimer++;
            if (swapTimer > 40 && !InventoryClickQueue.hasPending()) {
                swapping = false;
                NotificationSystem.success("Armor swapped to " + targetSet.getValue());
            }
            return;
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null)
            return;
        InventoryClickQueue.setClickDelay(delay.getValue().longValue());
        swapToTarget(targetSet.getValue());
        swapping = true;
        swapTimer = 0;
    }

    private void swapToTarget(String material) {
        ItemArmor.ArmorMaterial targetMaterial = getMaterialByName(material);
        if (targetMaterial == null)
            return;
        for (EntityEquipmentSlot slot : EntityEquipmentSlot.values()) {
            if (slot.getSlotType() != EntityEquipmentSlot.Type.ARMOR)
                continue;
            int armorSlotIndex = getArmorSlotIndex(slot);
            ItemStack current = mc.player.getItemStackFromSlot(slot);
            if (current != null && !current.func_190926_b() && current.getItem() instanceof ItemArmor) {
                ItemArmor currentArmor = (ItemArmor) current.getItem();
                if (currentArmor.getArmorMaterial() == targetMaterial) {
                    continue;
                }
            }
            int invSlot = findArmorInInventory(targetMaterial, slot);
            if (invSlot == -1)
                continue;
            if (current != null && !current.func_190926_b()) {
                InventoryClickQueue.shiftClick(armorSlotIndex);
            }
            InventoryClickQueue.shiftClick(invSlot);
        }
    }

    private int findArmorInInventory(ItemArmor.ArmorMaterial material, EntityEquipmentSlot slot) {
        for (int i = 9; i < 45; i++) {
            ItemStack stack = mc.player.inventoryContainer.getSlot(i).getStack();
            if (stack == null || stack.func_190926_b())
                continue;
            if (!(stack.getItem() instanceof ItemArmor))
                continue;
            ItemArmor armor = (ItemArmor) stack.getItem();
            if (armor.getArmorMaterial() == material && armor.armorType == slot) {
                return i;
            }
        }
        return -1;
    }

    private int getArmorSlotIndex(EntityEquipmentSlot slot) {
        switch(slot) {
            case HEAD:
                return 5;
            case CHEST:
                return 6;
            case LEGS:
                return 7;
            case FEET:
                return 8;
            default:
                return -1;
        }
    }

    private ItemArmor.ArmorMaterial getMaterialByName(String name) {
        switch(name) {
            case "Diamond":
                return ItemArmor.ArmorMaterial.DIAMOND;
            case "Gold":
                return ItemArmor.ArmorMaterial.GOLD;
            case "Iron":
                return ItemArmor.ArmorMaterial.IRON;
            case "Chainmail":
                return ItemArmor.ArmorMaterial.CHAIN;
            case "Leather":
                return ItemArmor.ArmorMaterial.LEATHER;
            default:
                return null;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        swapping = false;
        swapTimer = 0;
    }
}
