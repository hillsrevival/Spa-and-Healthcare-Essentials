package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.world.InventoryClickQueue;
import client.utils.misc.NotificationSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.item.ItemBow;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class InvCleaner extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting keepBestItems = new BooleanSetting("Keep Best Items", true);

    private final BooleanSetting dropFood = new BooleanSetting("Drop Junk Food", true);

    private final BooleanSetting dropDuplicates = new BooleanSetting("Drop Duplicates", true);

    private final BooleanSetting dropArmor = new BooleanSetting("Drop Extra Armor", true);

    private final NumberSetting delay = new NumberSetting("Click Delay", 150.0, 50.0, 500.0);

    private boolean cleaning = false;

    private int cleanTimer = 0;

    public InvCleaner() {
        super("InvCleaner", Category.ITEMS);
        setDescription("Inventory cleanup, drops junk");
        addSetting(keepBestItems);
        addSetting(dropFood);
        addSetting(dropDuplicates);
        addSetting(dropArmor);
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null)
            return;
        InventoryClickQueue.setClickDelay(delay.getValue().longValue());
        startCleaning();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        InventoryClickQueue.tick();
        if (cleaning) {
            cleanTimer++;
            if (cleanTimer > 60 && !InventoryClickQueue.hasPending()) {
                cleaning = false;
                int dropped = InventoryClickQueue.pendingCount();
                NotificationSystem.success("Inventory cleaned!");
                toggle();
            }
        }
    }

    private void startCleaning() {
        List<Integer> toDrop = new ArrayList<>();
        float bestSwordDamage = 0;
        int bestSwordSlot = -1;
        float bestPickaxeDamage = 0;
        int bestPickaxeSlot = -1;
        float bestAxeDamage = 0;
        int bestAxeSlot = -1;
        int bestBowSlot = -1;
        int[] bestArmorSlot = new int[4];
        float[] bestArmorValue = new float[4];
        for (int i = 9; i < 45; i++) {
            ItemStack stack = mc.player.inventoryContainer.getSlot(i).getStack();
            if (stack == null || stack.func_190926_b())
                continue;
            // Elytra is an Item rather than ItemArmor in this codebase. Keep it
            // explicitly so future cleanup rules cannot classify it as junk.
            if (stack.getItem() == Items.ELYTRA)
                continue;
            if (stack.getItem() instanceof ItemSword) {
                ItemSword sword = (ItemSword) stack.getItem();
                float damage = sword.getDamageVsEntity();
                if (damage > bestSwordDamage) {
                    if (bestSwordSlot != -1 && dropDuplicates.getValue()) {
                        toDrop.add(bestSwordSlot);
                    }
                    bestSwordDamage = damage;
                    bestSwordSlot = i;
                } else if (dropDuplicates.getValue()) {
                    toDrop.add(i);
                }
            } else if (stack.getItem() instanceof ItemTool) {
                ItemTool tool = (ItemTool) stack.getItem();
                float damage = tool.damageVsEntity;
                String toolClass = tool.getToolMaterialName();
                if (isPickaxe(stack)) {
                    if (damage > bestPickaxeDamage) {
                        if (bestPickaxeSlot != -1 && dropDuplicates.getValue()) {
                            toDrop.add(bestPickaxeSlot);
                        }
                        bestPickaxeDamage = damage;
                        bestPickaxeSlot = i;
                    } else if (dropDuplicates.getValue()) {
                        toDrop.add(i);
                    }
                } else if (isAxe(stack)) {
                    if (damage > bestAxeDamage) {
                        if (bestAxeSlot != -1 && dropDuplicates.getValue()) {
                            toDrop.add(bestAxeSlot);
                        }
                        bestAxeDamage = damage;
                        bestAxeSlot = i;
                    } else if (dropDuplicates.getValue()) {
                        toDrop.add(i);
                    }
                }
            } else if (stack.getItem() instanceof ItemBow) {
                if (bestBowSlot == -1) {
                    bestBowSlot = i;
                } else if (dropDuplicates.getValue()) {
                    toDrop.add(i);
                }
            } else if (stack.getItem() instanceof ItemArmor) {
                ItemArmor armor = (ItemArmor) stack.getItem();
                int slotIndex = armor.armorType.getIndex();
                float armorValue = armor.damageReduceAmount;
                if (armorValue > bestArmorValue[slotIndex]) {
                    if (bestArmorSlot[slotIndex] != 0 && dropArmor.getValue()) {
                        toDrop.add(bestArmorSlot[slotIndex]);
                    }
                    bestArmorValue[slotIndex] = armorValue;
                    bestArmorSlot[slotIndex] = i;
                } else if (dropArmor.getValue()) {
                    toDrop.add(i);
                }
            } else if (stack.getItem() instanceof ItemFood) {
                if (dropFood.getValue()) {
                    if (stack.getItem() != Items.GOLDEN_APPLE) {
                        toDrop.add(i);
                    }
                }
            }
        }
        for (int slot : toDrop) {
            InventoryClickQueue.dropSlot(slot);
        }
        cleaning = true;
        cleanTimer = 0;
    }

    private boolean isPickaxe(ItemStack stack) {
        String name = stack.getUnlocalizedName().toLowerCase();
        return name.contains("pickaxe");
    }

    private boolean isAxe(ItemStack stack) {
        String name = stack.getUnlocalizedName().toLowerCase();
        return name.contains("axe") && !name.contains("pickaxe");
    }

    @Override
    public void onDisable() {
        super.onDisable();
        cleaning = false;
        cleanTimer = 0;
    }
}
