package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.util.EnumHand;
import net.minecraft.enchantment.EnchantmentHelper;
import client.utils.world.InteractionUtils;

public class AutoMend extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting delay = new NumberSetting("Delay", 2.0, 0.0, 20.0);

    private final BooleanSetting autoSwitch = new BooleanSetting("AutoSwitch", true);

    private int timer = 0;

    private int savedSlot = -1;

    public AutoMend() {
        super("AutoMend", Category.ITEMS);
        setDescription("Automatically mends your items and armour");
        addSetting(delay);
        addSetting(autoSwitch);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (timer > 0) {
            timer--;
            return;
        }
        boolean needsMend = false;
        ItemStack mainHand = mc.player.getHeldItemMainhand();
        if (!mainHand.func_190926_b() && mainHand.isItemStackDamageable() && mainHand.getItemDamage() > 0 && hasMending(mainHand)) {
            needsMend = true;
        }
        for (int i = 0; i < 4; i++) {
            ItemStack stack = mc.player.inventory.armorInventory.get(i);
            if (!stack.func_190926_b() && stack.isItemStackDamageable() && stack.getItemDamage() > 0 && hasMending(stack)) {
                needsMend = true;
                break;
            }
        }
        if (!needsMend)
            return;
        int xpSlot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (!stack.func_190926_b() && stack.getItem() == Items.EXPERIENCE_BOTTLE) {
                xpSlot = i;
                break;
            }
        }
        if (xpSlot == -1)
            return;
        if (mc.player.experience >= 0.95f)
            return;
        if (autoSwitch.getValue() && xpSlot != mc.player.inventory.currentItem) {
            if (savedSlot == -1) {
                savedSlot = mc.player.inventory.currentItem;
            }
            mc.player.inventory.currentItem = xpSlot;
            return;
        }
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held.func_190926_b() || held.getItem() != Items.EXPERIENCE_BOTTLE)
            return;
        InteractionUtils.useItem(EnumHand.MAIN_HAND);
        mc.player.swingArm(EnumHand.MAIN_HAND);
        timer = delay.getValue().intValue();
        if (savedSlot != -1) {
            mc.player.inventory.currentItem = savedSlot;
            if (mc.player.connection != null) {
                mc.player.connection.sendPacket(new CPacketHeldItemChange(savedSlot));
            }
            savedSlot = -1;
        }
    }

    private boolean hasMending(ItemStack stack) {
        return EnchantmentHelper.getEnchantmentLevel(net.minecraft.init.Enchantments.MENDING, stack) > 0;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        timer = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (savedSlot != -1 && mc.player != null) {
            mc.player.inventory.currentItem = savedSlot;
            if (mc.player.connection != null) {
                mc.player.connection.sendPacket(new CPacketHeldItemChange(savedSlot));
            }
        }
        savedSlot = -1;
        timer = 0;
    }
}
