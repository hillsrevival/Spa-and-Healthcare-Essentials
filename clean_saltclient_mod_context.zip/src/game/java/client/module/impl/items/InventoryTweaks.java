package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemStack;

public class InventoryTweaks extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting delay = new NumberSetting("DelayTicks", 2.0, 0.0, 10.0);

    private int tickCounter = 0;

    public InventoryTweaks() {
        super("InventoryTweaks", Category.ITEMS);
        setDescription("Sorts and organizes your inventory");
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        tickCounter++;
        if (tickCounter < delay.getValue().intValue())
            return;
        tickCounter = 0;
        if (mc.currentScreen == null)
            return;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (stack.func_190926_b())
                continue;
            for (int j = i + 1; j < 9; j++) {
                ItemStack other = mc.player.inventory.mainInventory.get(j);
                if (other.func_190926_b())
                    continue;
                if (!stack.isItemEqual(other))
                    continue;
                if (!ItemStack.areItemStackTagsEqual(stack, other))
                    continue;
                int space = stack.getMaxStackSize() - stack.func_190916_E();
                if (space <= 0)
                    continue;
                int windowId = mc.player.inventoryContainer.windowId;
                mc.playerController.windowClick(windowId, j + 36, 0, net.minecraft.inventory.ClickType.PICKUP, mc.player);
                mc.playerController.windowClick(windowId, i + 36, 0, net.minecraft.inventory.ClickType.PICKUP, mc.player);
                if (!mc.player.inventory.getItemStack().func_190926_b()) {
                    mc.playerController.windowClick(windowId, j + 36, 0, net.minecraft.inventory.ClickType.PICKUP, mc.player);
                }
                return;
            }
        }
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (!stack.func_190926_b())
                continue;
            for (int j = i + 1; j < 9; j++) {
                ItemStack other = mc.player.inventory.mainInventory.get(j);
                if (other.func_190926_b())
                    continue;
                int wid = mc.player.inventoryContainer.windowId;
                mc.playerController.windowClick(wid, j + 36, 0, net.minecraft.inventory.ClickType.PICKUP, mc.player);
                mc.playerController.windowClick(wid, i + 36, 0, net.minecraft.inventory.ClickType.PICKUP, mc.player);
                return;
            }
        }
    }
}
