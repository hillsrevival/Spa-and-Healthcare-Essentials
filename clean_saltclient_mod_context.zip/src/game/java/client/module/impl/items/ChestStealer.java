package client.module.impl.items;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.item.ItemStack;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.event.events.WindowClickEvent;

public class ChestStealer extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting minDelay = new NumberSetting("Min Delay", 80.0, 0.0, 500.0);

    private final NumberSetting maxDelay = new NumberSetting("Max Delay", 150.0, 0.0, 500.0);

    private final BooleanSetting autoClose = new BooleanSetting("AutoClose", true);

    private final BooleanSetting randomize = new BooleanSetting("Randomize", true);

    private long nextClickTime = 0;

    private static boolean isStealing = false;

    public ChestStealer() {
        super("ChestStealer", Category.ITEMS);
        setDescription("Automatically steals all items from a chest");
        addSetting(minDelay);
        addSetting(maxDelay);
        addSetting(autoClose);
        addSetting(randomize);
        handles(HandlerType.UPDATE, HandlerType.WINDOW_CLICK);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!(mc.currentScreen instanceof GuiChest))
            return;
        GuiChest chestGui = (GuiChest) mc.currentScreen;
        if (!(chestGui.inventorySlots instanceof ContainerChest))
            return;
        ContainerChest chestContainer = (ContainerChest) chestGui.inventorySlots;
        long now = System.currentTimeMillis();
        if (now < nextClickTime)
            return;
        int chestSlots = chestContainer.getLowerChestInventory().getSizeInventory();
        boolean stolenAny = false;
        for (int i = 0; i < chestSlots; i++) {
            ItemStack stack = chestContainer.getLowerChestInventory().getStackInSlot(i);
            if (stack == null || stack.func_190926_b())
                continue;
            isStealing = true;
            mc.playerController.windowClick(chestContainer.windowId, i, 0, net.minecraft.inventory.ClickType.QUICK_MOVE, mc.player);
            isStealing = false;
            stolenAny = true;
            long clickDelay;
            if (randomize.getValue()) {
                long min = minDelay.getValue().longValue();
                long max = maxDelay.getValue().longValue();
                if (min > max) {
                    long t = min;
                    min = max;
                    max = t;
                }
                clickDelay = min + (long) (Math.random() * (max - min));
            } else {
                clickDelay = minDelay.getValue().longValue();
            }
            nextClickTime = now + clickDelay;
            break;
        }
        if (!stolenAny && autoClose.getValue()) {
            mc.player.closeScreen();
        }
    }

    @Override
    public void onWindowClick(WindowClickEvent event) {
        if (mc.player == null)
            return;
        if (isStealing)
            return;
        if (!(mc.currentScreen instanceof GuiChest))
            return;
        GuiChest chestGui = (GuiChest) mc.currentScreen;
        if (!(chestGui.inventorySlots instanceof ContainerChest))
            return;
        ContainerChest chest = (ContainerChest) chestGui.inventorySlots;
        int chestSlots = chest.getLowerChestInventory().getSizeInventory();
        for (int i = 0; i < chestSlots; i++) {
            net.minecraft.item.ItemStack stack = chest.getLowerChestInventory().getStackInSlot(i);
            if (stack != null && !stack.func_190926_b()) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        nextClickTime = 0;
        isStealing = false;
    }
}
