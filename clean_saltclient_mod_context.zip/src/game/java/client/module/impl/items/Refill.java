package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.world.InventoryClickQueue;
import client.utils.misc.NotificationSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;

public class Refill extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting threshold = new NumberSetting("Threshold", 16.0, 1.0, 64.0);

    private final NumberSetting delay = new NumberSetting("Delay", 150.0, 50.0, 500.0);

    private int tickCounter = 0;

    public Refill() {
        super("Refill", Category.ITEMS);
        setDescription("Refills hotbar from main inventory");
        addSetting(threshold);
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        InventoryClickQueue.setClickDelay(delay.getValue().longValue());
        tickCounter = 0;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        InventoryClickQueue.tick();
        tickCounter++;
        if (tickCounter < 20)
            return;
        tickCounter = 0;
        double thresh = threshold.getValue();
        for (int hotbarSlot = 0; hotbarSlot < 9; hotbarSlot++) {
            ItemStack hotbarStack = mc.player.inventory.getStackInSlot(hotbarSlot);
            if (hotbarStack == null || hotbarStack.func_190926_b())
                continue;
            if (!hotbarStack.isStackable())
                continue;
            if (hotbarStack.func_190916_E() >= thresh)
                continue;
            if (hotbarStack.func_190916_E() >= hotbarStack.getMaxStackSize())
                continue;
            for (int invSlot = 9; invSlot < 36; invSlot++) {
                ItemStack invStack = mc.player.inventoryContainer.getSlot(invSlot).getStack();
                if (invStack == null || invStack.func_190926_b())
                    continue;
                if (!areItemsEqual(hotbarStack, invStack))
                    continue;
                if (InventoryClickQueue.hasPending())
                    return;
                InventoryClickQueue.shiftClick(invSlot);
                return;
            }
        }
    }

    private boolean areItemsEqual(ItemStack a, ItemStack b) {
        if (a == null || b == null)
            return false;
        if (a.getItem() != b.getItem())
            return false;
        if (a.getMetadata() != b.getMetadata())
            return false;
        return true;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        tickCounter = 0;
    }
}
