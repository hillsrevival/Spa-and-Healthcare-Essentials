package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.misc.NotificationSystem;
import client.utils.combat.ProjectilePitchUtil;
import client.utils.player.InvUtils;
import client.utils.player.SlotUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;

public class AutoPearl extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting searchRange = new NumberSetting("Search Range", 10.0, 3.0, 30.0);

    private final BooleanSetting autoThrow = new BooleanSetting("Auto Throw", true);

    private final BooleanSetting preferHighGround = new BooleanSetting("Prefer High Ground", true);

    private int savedSlot = -1;

    private boolean throwing = false;

    private int tickCounter = 0;

    public AutoPearl() {
        super("AutoPearl", Category.ITEMS);
        setDescription("AutoPearl");
        addSetting(searchRange);
        addSetting(autoThrow);
        addSetting(preferHighGround);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null)
            return;
        savedSlot = -1;
        throwing = false;
        tickCounter = 0;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        tickCounter++;
        if (throwing) {
            if (tickCounter > 5) {
                if (savedSlot != -1) {
                    mc.player.inventory.currentItem = savedSlot;
                }
                throwing = false;
                tickCounter = 0;
                toggle();
            }
            return;
        }
        int pearlSlot = InvUtils.findInHotbar(stack -> stack != null && !stack.func_190926_b() && stack.getItem() == Items.ENDER_PEARL).slot() - SlotUtils.HOTBAR_START;
        if (pearlSlot == -1) {
            NotificationSystem.warning("No ender pearls in hotbar!");
            toggle();
            return;
        }
        double targetX = mc.player.posX;
        double targetY = mc.player.posY;
        double targetZ = mc.player.posZ;
        double lookX = mc.player.getLookVec().xCoord;
        double lookY = mc.player.getLookVec().yCoord;
        double lookZ = mc.player.getLookVec().zCoord;
        double range = searchRange.getValue();
        targetX = mc.player.posX + lookX * range;
        targetY = mc.player.posY + lookY * range;
        targetZ = mc.player.posZ + lookZ * range;
        float pitch = ProjectilePitchUtil.calculatePitch(targetX, targetY, targetZ, 1.5, 0.03);
        if (Float.isNaN(pitch)) {
            NotificationSystem.warning("Target too far for pearl!");
            toggle();
            return;
        }
        if (!autoThrow.getValue()) {
            mc.player.rotationPitch = pitch;
            return;
        }
        savedSlot = mc.player.inventory.currentItem;
        mc.player.inventory.currentItem = pearlSlot;
        mc.playerController.updateController();
        double diffX = targetX - mc.player.posX;
        double diffZ = targetZ - mc.player.posZ;
        mc.player.rotationYaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        mc.player.rotationPitch = pitch;
        mc.playerController.processRightClick(mc.player, mc.world, EnumHand.MAIN_HAND);
        throwing = true;
        tickCounter = 0;
        NotificationSystem.info("Pearl thrown!");
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (savedSlot != -1 && mc.player != null) {
            mc.player.inventory.currentItem = savedSlot;
        }
        throwing = false;
    }
}
