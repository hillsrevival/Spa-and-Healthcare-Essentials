package client.module.impl.items;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiFurnace;
import net.minecraft.init.Items;
import net.minecraft.inventory.ContainerFurnace;
import net.minecraft.inventory.Slot;
import net.minecraft.inventory.SlotFurnaceFuel;
import net.minecraft.inventory.SlotFurnaceOutput;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.FurnaceRecipes;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;

public class AutoSmelter extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting delay = new NumberSetting("Delay", 2.0, 0.0, 20.0);

    private final BooleanSetting autoClose = new BooleanSetting("AutoClose", false);

    private final BooleanSetting takeOutput = new BooleanSetting("TakeOutput", true);

    private final BooleanSetting putInput = new BooleanSetting("PutInput", true);

    private final BooleanSetting putFuel = new BooleanSetting("PutFuel", true);

    private int timer = 0;

    public AutoSmelter() {
        super("AutoSmelter", Category.ITEMS);
        setDescription("Automatically smelts items in a furnace");
        addSetting(delay);
        addSetting(autoClose);
        addSetting(takeOutput);
        addSetting(putInput);
        addSetting(putFuel);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!(mc.currentScreen instanceof GuiFurnace))
            return;
        if (timer > 0) {
            timer--;
            return;
        }
        if (!(mc.player.openContainer instanceof ContainerFurnace))
            return;
        ContainerFurnace furnace = (ContainerFurnace) mc.player.openContainer;
        if (takeOutput.getValue()) {
            ItemStack output = furnace.getSlot(2).getStack();
            if (!output.func_190926_b()) {
                mc.playerController.windowClick(furnace.windowId, 2, 0, net.minecraft.inventory.ClickType.QUICK_MOVE, mc.player);
                timer = delay.getValue().intValue();
                return;
            }
        }
        if (putInput.getValue()) {
            ItemStack input = furnace.getSlot(0).getStack();
            if (input.func_190926_b()) {
                int smeltableSlot = findSmeltable();
                if (smeltableSlot != -1) {
                    int containerSlot = smeltableSlot < 9 ? smeltableSlot + 30 : smeltableSlot - 6;
                    mc.playerController.windowClick(furnace.windowId, containerSlot, 0, net.minecraft.inventory.ClickType.QUICK_MOVE, mc.player);
                    timer = delay.getValue().intValue();
                    return;
                }
            }
        }
        if (putFuel.getValue()) {
            ItemStack fuel = furnace.getSlot(1).getStack();
            if (fuel.func_190926_b()) {
                int fuelSlot = findFuel();
                if (fuelSlot != -1) {
                    int containerSlot = fuelSlot < 9 ? fuelSlot + 30 : fuelSlot - 6;
                    mc.playerController.windowClick(furnace.windowId, containerSlot, 0, net.minecraft.inventory.ClickType.QUICK_MOVE, mc.player);
                    timer = delay.getValue().intValue();
                    return;
                }
            }
        }
        if (autoClose.getValue()) {
            int smeltableSlot = findSmeltable();
            int fuelSlot = findFuel();
            ItemStack output = furnace.getSlot(2).getStack();
            ItemStack input = furnace.getSlot(0).getStack();
            if (output.func_190926_b() && input.func_190926_b() && smeltableSlot == -1 && fuelSlot == -1) {
                mc.player.closeScreen();
            }
        }
    }

    private int findSmeltable() {
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.func_190926_b())
                continue;
            ItemStack result = FurnaceRecipes.instance().getSmeltingResult(stack);
            if (!result.func_190926_b())
                return i;
        }
        return -1;
    }

    private int findFuel() {
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.func_190926_b())
                continue;
            int burnTime = net.minecraft.tileentity.TileEntityFurnace.getItemBurnTime(stack);
            if (burnTime > 0)
                return i;
        }
        return -1;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        timer = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        timer = 0;
    }
}
