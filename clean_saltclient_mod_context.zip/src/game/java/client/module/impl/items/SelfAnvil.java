package client.module.impl.items;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiRepair;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Items;
import net.minecraft.inventory.ContainerRepair;
import net.minecraft.item.ItemStack;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;

public class SelfAnvil extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting delay = new NumberSetting("Delay", 3.0, 0.0, 20.0);

    private final BooleanSetting autoClose = new BooleanSetting("AutoClose", false);

    private final BooleanSetting takeResult = new BooleanSetting("TakeResult", true);

    private final BooleanSetting putItems = new BooleanSetting("PutItems", true);

    private final NumberSetting minDurability = new NumberSetting("MinDamage", 10.0, 0.0, 90.0);

    private int timer = 0;

    public SelfAnvil() {
        super("SelfAnvil", Category.ITEMS);
        setDescription("Uses an anvil to combine or repair items");
        addSetting(delay);
        addSetting(autoClose);
        addSetting(takeResult);
        addSetting(putItems);
        addSetting(minDurability);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!(mc.currentScreen instanceof GuiRepair))
            return;
        if (timer > 0) {
            timer--;
            return;
        }
        if (!(mc.player.openContainer instanceof ContainerRepair))
            return;
        ContainerRepair anvil = (ContainerRepair) mc.player.openContainer;
        if (takeResult.getValue()) {
            ItemStack result = anvil.getSlot(2).getStack();
            if (!result.func_190926_b() && anvil.maximumCost > 0) {
                if (mc.player.capabilities.isCreativeMode || mc.player.experienceLevel >= anvil.maximumCost) {
                    mc.playerController.windowClick(anvil.windowId, 2, 0, net.minecraft.inventory.ClickType.QUICK_MOVE, mc.player);
                    timer = delay.getValue().intValue();
                    return;
                }
            }
        }
        if (putItems.getValue()) {
            ItemStack slot0 = anvil.getSlot(0).getStack();
            ItemStack slot1 = anvil.getSlot(1).getStack();
            if (slot0.func_190926_b() && slot1.func_190926_b()) {
                int[] pair = findRepairPair();
                if (pair != null) {
                    int cSlot0 = pair[0] < 9 ? pair[0] + 30 : pair[0] - 6;
                    mc.playerController.windowClick(anvil.windowId, cSlot0, 0, net.minecraft.inventory.ClickType.QUICK_MOVE, mc.player);
                    timer = delay.getValue().intValue();
                    return;
                }
            } else if (!slot0.func_190926_b() && slot1.func_190926_b()) {
                int matSlot = findRepairMaterial(slot0);
                if (matSlot != -1) {
                    int cSlot = matSlot < 9 ? matSlot + 30 : matSlot - 6;
                    mc.playerController.windowClick(anvil.windowId, cSlot, 0, net.minecraft.inventory.ClickType.QUICK_MOVE, mc.player);
                    timer = delay.getValue().intValue();
                    return;
                }
            }
        }
        if (autoClose.getValue()) {
            ItemStack slot0 = anvil.getSlot(0).getStack();
            ItemStack slot1 = anvil.getSlot(1).getStack();
            ItemStack result = anvil.getSlot(2).getStack();
            if (slot0.func_190926_b() && slot1.func_190926_b() && result.func_190926_b()) {
                int[] pair = findRepairPair();
                if (pair == null) {
                    mc.player.closeScreen();
                }
            }
        }
    }

    private int findDamagedItem() {
        float minDmg = minDurability.getValue().floatValue();
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.func_190926_b())
                continue;
            if (!stack.isItemStackDamageable())
                continue;
            float dmgPercent = (float) stack.getItemDamage() / (float) stack.getMaxDamage() * 100.0f;
            if (dmgPercent >= minDmg)
                return i;
        }
        return -1;
    }

    private int[] findRepairPair() {
        int damaged = findDamagedItem();
        if (damaged == -1)
            return null;
        ItemStack damagedStack = mc.player.inventory.getStackInSlot(damaged);
        int mat = findRepairMaterial(damagedStack);
        if (mat == -1)
            return null;
        return new int[] { damaged, mat };
    }

    private int findRepairMaterial(ItemStack toRepair) {
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.func_190926_b())
                continue;
            if (stack == toRepair)
                continue;
            if (ItemStack.areItemsEqual(stack, toRepair) && !stack.isItemStackDamageable() && stack.getItem() == toRepair.getItem()) {
                return i;
            }
        }
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.func_190926_b())
                continue;
            if (stack.getItem() == Items.ENCHANTED_BOOK && !EnchantmentHelper.getEnchantments(stack).isEmpty()) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        timer = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        timer = 0;
    }
}
