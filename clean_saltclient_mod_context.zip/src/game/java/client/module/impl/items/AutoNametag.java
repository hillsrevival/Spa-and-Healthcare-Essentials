package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.util.EnumHand;
import client.utils.player.InventoryManager;
import client.utils.player.InvUtils;
import client.utils.player.FindItemResult;

public class AutoNametag extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 4.5, 2.0, 6.0);

    public AutoNametag() {
        super("AutoNametag", Category.ITEMS);
        setDescription("Automatically names entities with nametags from your inventory");
        addSetting(range);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        FindItemResult result = InvUtils.findInHotbar(net.minecraft.init.Items.NAME_TAG);
        if (!result.found())
            return;
        for (Entity entity : mc.world.loadedEntityList) {
            if (!(entity instanceof EntityAnimal))
                continue;
            if (mc.player.getDistanceToEntity(entity) > range.getValue())
                continue;
            if (entity.hasCustomName())
                continue;
            if (result.slot() != InventoryManager.getCurrentSlot()) {
                InventoryManager.switchToSlot(result.slot());
            }
            mc.playerController.interactWithEntity(mc.player, entity, EnumHand.MAIN_HAND);
            break;
        }
    }
}
