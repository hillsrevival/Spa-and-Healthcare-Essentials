package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

/** One-shot chest-slot swap. The cursor is checked before and after every transaction. */
public class ChestSwap extends Module {

    public ChestSwap() {
        super("ChestSwap", Category.ITEMS);
        setDescription("Safely swaps the equipped elytra and chestplate without leaving an item on the cursor");
    }

    @Override
    public void onEnable() {
        super.onEnable();
        swapNow();
        // ChestSwap is a one-shot action, not a persistent toggle.
        setToggled(false);
    }

    public static boolean swapNow() {
        if (mcStaticPlayerMissing())
            return false;
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getMinecraft();
        net.minecraft.client.entity.EntityPlayerSP player = mc.player;
        if (player.openContainer != player.inventoryContainer)
            return false;
        if (!isEmpty(player.inventory.getItemStack()))
            return false;

        ItemStack equipped = player.getItemStackFromSlot(EntityEquipmentSlot.CHEST);
        boolean wearingElytra = !isEmpty(equipped) && equipped.getItem() == Items.ELYTRA;
        int inventorySlot = wearingElytra ? findChestplate(player) : findElytra(player);
        if (inventorySlot < 9 || inventorySlot > 44)
            return false;

        ItemStack incoming = player.inventoryContainer.getSlot(inventorySlot).getStack();
        if (isEmpty(incoming))
            return false;
        ItemStack before = incoming.copy();
        try {
            int window = player.inventoryContainer.windowId;
            mc.playerController.windowClick(window, inventorySlot, 0, ClickType.PICKUP, player);
            mc.playerController.windowClick(window, 6, 0, ClickType.PICKUP, player);
            if (!isEmpty(player.inventory.getItemStack()))
                mc.playerController.windowClick(window, inventorySlot, 0, ClickType.PICKUP, player);
            if (!isEmpty(player.inventory.getItemStack())) {
                // Never leave a cursor-held elytra/chestplate behind. Use an empty
                // inventory slot as a recovery destination if the original slot changed.
                int empty = findEmptyInventorySlot(player);
                if (empty >= 9)
                    mc.playerController.windowClick(window, empty, 0, ClickType.PICKUP, player);
            }
        } catch (Throwable ignored) {
            // The cursor recovery below is deliberately best-effort; we never THROW.
        }
        player.inventory.markDirty();
        if (!isEmpty(player.inventory.getItemStack()))
            return false;
        ItemStack nowEquipped = player.getItemStackFromSlot(EntityEquipmentSlot.CHEST);
        return !isEmpty(nowEquipped) && nowEquipped.getItem() == before.getItem();
    }

    private static boolean mcStaticPlayerMissing() {
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getMinecraft();
        return mc.player == null || mc.world == null || mc.playerController == null;
    }

    private static boolean isEmpty(ItemStack stack) {
        return stack == null || stack.func_190926_b();
    }

    private static int findElytra(net.minecraft.entity.player.EntityPlayer player) {
        for (int i = 9; i <= 44; i++) {
            ItemStack stack = player.inventoryContainer.getSlot(i).getStack();
            if (!isEmpty(stack) && stack.getItem() == Items.ELYTRA)
                return i;
        }
        return -1;
    }

    private static int findChestplate(net.minecraft.entity.player.EntityPlayer player) {
        for (int i = 9; i <= 44; i++) {
            ItemStack stack = player.inventoryContainer.getSlot(i).getStack();
            if (!isEmpty(stack) && stack.getItem() instanceof ItemArmor
                    && ((ItemArmor) stack.getItem()).armorType == EntityEquipmentSlot.CHEST)
                return i;
        }
        return -1;
    }

    private static int findEmptyInventorySlot(net.minecraft.entity.player.EntityPlayer player) {
        for (int i = 9; i <= 44; i++) {
            if (isEmpty(player.inventoryContainer.getSlot(i).getStack()))
                return i;
        }
        return -1;
    }
}
