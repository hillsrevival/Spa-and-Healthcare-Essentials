package client.module.impl.items;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketClickWindow;

public class AutoArmor extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting useEnchantments = new BooleanSetting("Use Enchantments", true);

    private final BooleanSetting swapWhileMoving = new BooleanSetting("Swap While Moving", false);

    private final NumberSetting delay = new NumberSetting("Delay (ticks)", 2.0, 0.0, 20.0);

    private int timer = 0;

    public AutoArmor() {
        super("AutoArmor", Category.ITEMS);
        setDescription("Automatically equips the best armor from your inventory");
        addSetting(useEnchantments);
        addSetting(swapWhileMoving);
        addSetting(delay);
        handles(HandlerType.UPDATE, HandlerType.PACKET_OUTPUT);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (timer > 0) {
            timer--;
            return;
        }
        if (mc.currentScreen instanceof GuiContainer)
            return;
        if (!swapWhileMoving.getValue() && (mc.player.moveForward != 0 || mc.player.moveStrafing != 0))
            return;
        int[] bestArmorSlots = new int[] { -1, -1, -1, -1 };
        int[] bestArmorValues = new int[4];
        for (int slot = 0; slot < 4; slot++) {
            ItemStack stack = mc.player.inventory.armorItemInSlot(slot);
            // Elytra is not an ItemArmor in 1.12. Treat an equipped elytra as
            // protected chest equipment so AutoArmor cannot shift it away.
            if (slot == 2 && !isNullOrEmpty(stack) && stack.getItem() == Items.ELYTRA) {
                bestArmorValues[slot] = Integer.MAX_VALUE;
                continue;
            }
            if (isNullOrEmpty(stack) || !(stack.getItem() instanceof ItemArmor))
                continue;
            ItemArmor item = (ItemArmor) stack.getItem();
            bestArmorValues[slot] = getArmorValue(item, stack);
        }
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (isNullOrEmpty(stack) || !(stack.getItem() instanceof ItemArmor))
                continue;
            ItemArmor item = (ItemArmor) stack.getItem();
            int invSlot = armorSlotToIndex(item.armorType);
            int armorValue = getArmorValue(item, stack);
            if (armorValue > bestArmorValues[invSlot]) {
                bestArmorSlots[invSlot] = i;
                bestArmorValues[invSlot] = armorValue;
            }
        }
        ArrayList<Integer> types = new ArrayList<>(Arrays.asList(0, 1, 2, 3));
        Collections.shuffle(types);
        for (int type : types) {
            int slot = bestArmorSlots[type];
            if (slot == -1)
                continue;
            ItemStack oldArmor = mc.player.inventory.armorItemInSlot(type);
            if (!isNullOrEmpty(oldArmor) && mc.player.inventory.getFirstEmptyStack() == -1)
                continue;
            int windowSlot = slot;
            if (slot < 9)
                windowSlot += 36;
            if (!isNullOrEmpty(oldArmor)) {
                mc.playerController.windowClick(0, 8 - type, 0, ClickType.QUICK_MOVE, mc.player);
            }
            mc.playerController.windowClick(0, windowSlot, 0, ClickType.QUICK_MOVE, mc.player);
            timer = delay.getValue().intValue();
            break;
        }
    }

    @Override
    public void onPacketOutput(client.event.events.PacketOutputEvent event) {
        if (event.getPacket() instanceof CPacketClickWindow) {
            timer = delay.getValue().intValue();
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        timer = 0;
    }

    private int armorSlotToIndex(EntityEquipmentSlot slot) {
        if (slot == EntityEquipmentSlot.HEAD)
            return 3;
        if (slot == EntityEquipmentSlot.CHEST)
            return 2;
        if (slot == EntityEquipmentSlot.LEGS)
            return 1;
        if (slot == EntityEquipmentSlot.FEET)
            return 0;
        return -1;
    }

    private boolean isNullOrEmpty(ItemStack stack) {
        return stack == null || stack.func_190926_b();
    }

    private int getArmorValue(ItemArmor item, ItemStack stack) {
        int armorPoints = item.damageReduceAmount;
        int protPoints = 0;
        if (useEnchantments.getValue()) {
            int protLvl = EnchantmentHelper.getEnchantmentLevel(Enchantments.PROTECTION, stack);
            if (protLvl > 0)
                protPoints += (int) (protLvl * 1.5);
            int fireProt = EnchantmentHelper.getEnchantmentLevel(Enchantments.FIRE_PROTECTION, stack);
            int blastProt = EnchantmentHelper.getEnchantmentLevel(Enchantments.BLAST_PROTECTION, stack);
            int projectileProt = EnchantmentHelper.getEnchantmentLevel(Enchantments.PROJECTILE_PROTECTION, stack);
            protPoints += fireProt + blastProt + projectileProt;
        }
        return armorPoints * 5 + protPoints * 3;
    }
}
