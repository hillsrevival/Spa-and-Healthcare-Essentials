package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.world.InventoryClickQueue;
import client.utils.misc.NotificationSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;

public class AutoHotbar extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting delay = new NumberSetting("Click Delay", 150.0, 50.0, 500.0);

    private boolean sorting = false;

    private int sortTimer = 0;

    public AutoHotbar() {
        super("AutoHotbar", Category.ITEMS);
        setDescription("Automatically sorts your hotbar");
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null)
            return;
        InventoryClickQueue.setClickDelay(delay.getValue().longValue());
        startSorting();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        InventoryClickQueue.tick();
        if (sorting) {
            sortTimer++;
            if (sortTimer > 80 && !InventoryClickQueue.hasPending()) {
                sorting = false;
                NotificationSystem.success("Hotbar sorted!");
                toggle();
            }
        }
    }

    private void startSorting() {
        int[] best = classifyBestSlots();
        int bestSwordSlot = best[0];
        int bestPickaxeSlot = best[1];
        int bestAxeSlot = best[2];
        int bestBowSlot = best[3];
        if (bestSwordSlot != -1 && bestSwordSlot != 0) {
            InventoryClickQueue.swap(bestSwordSlot, 0);
        }
        if (bestPickaxeSlot != -1 && bestPickaxeSlot != 1) {
            InventoryClickQueue.swap(bestPickaxeSlot, 1);
        }
        if (bestAxeSlot != -1 && bestAxeSlot != 2) {
            InventoryClickQueue.swap(bestAxeSlot, 2);
        }
        if (bestBowSlot != -1 && bestBowSlot != 3) {
            InventoryClickQueue.swap(bestBowSlot, 3);
        }
        sorting = true;
        sortTimer = 0;
    }

    private int[] classifyBestSlots() {
        int bestSword = -1, bestPickaxe = -1, bestAxe = -1, firstBow = -1;
        float bestSwordValue = -1, bestPickaxeValue = -1, bestAxeValue = -1;
        for (int i = 0; i < 45; i++) {
            ItemStack stack = mc.player.inventoryContainer.getSlot(i).getStack();
            if (stack == null || stack.func_190926_b())
                continue;
            if (stack.getItem() instanceof ItemSword) {
                float damage = ((ItemSword) stack.getItem()).getDamageVsEntity();
                if (damage > bestSwordValue) {
                    bestSwordValue = damage;
                    bestSword = i;
                }
                continue;
            }
            if (stack.getItem() instanceof ItemTool) {
                String name = stack.getUnlocalizedName().toLowerCase();
                boolean isPickaxe = name.contains("pickaxe");
                boolean isAxe = !isPickaxe && name.contains("axe");
                if (isPickaxe) {
                    float damage = ((ItemTool) stack.getItem()).damageVsEntity;
                    if (damage > bestPickaxeValue) {
                        bestPickaxeValue = damage;
                        bestPickaxe = i;
                    }
                } else if (isAxe) {
                    float damage = ((ItemTool) stack.getItem()).damageVsEntity;
                    if (damage > bestAxeValue) {
                        bestAxeValue = damage;
                        bestAxe = i;
                    }
                }
                continue;
            }
            if (firstBow == -1 && stack.getItem() instanceof ItemBow) {
                firstBow = i;
            }
        }
        return new int[] { bestSword, bestPickaxe, bestAxe, firstBow };
    }

    @Override
    public void onDisable() {
        super.onDisable();
        sorting = false;
        sortTimer = 0;
    }
}
