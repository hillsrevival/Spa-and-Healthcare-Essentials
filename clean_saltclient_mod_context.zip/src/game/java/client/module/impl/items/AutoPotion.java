package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionUtils;
import client.utils.EntityUtils;
import client.utils.player.InventoryManager;
import client.utils.player.InvUtils;
import client.utils.player.FindItemResult;

public class AutoPotion extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 6.0, 3.0, 12.0);

    private final NumberSetting delay = new NumberSetting("Delay", 10, 1, 40);

    private final BooleanSetting harmful = new BooleanSetting("Harmful", true);

    private final BooleanSetting selfHeal = new BooleanSetting("Self Heal", true);

    private int timer = 0;

    public AutoPotion() {
        super("AutoPotion", Category.ITEMS);
        setDescription("Automatically drinks potions when their effects are not active");
        addSetting(range);
        addSetting(delay);
        addSetting(harmful);
        addSetting(selfHeal);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        timer = 0;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        timer++;
        if (timer < delay.getValue().intValue())
            return;
        if (selfHeal.getValue() && mc.player.getHealth() < mc.player.getMaxHealth() * 0.5f) {
            if (throwPotion(true)) {
                timer = 0;
                return;
            }
        }
        if (harmful.getValue()) {
            Entity target = EntityUtils.getClosestEntity(new EntityUtils.TargetSettings().setRange(range.getValue().floatValue()).setTargetPlayers(true).setTargetMonsters(true));
            if (target != null && throwPotion(false)) {
                timer = 0;
            }
        }
    }

    private boolean throwPotion(boolean healing) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (stack == null || stack.func_190926_b())
                continue;
            if (!(stack.getItem() instanceof ItemPotion))
                continue;
            java.util.List<PotionEffect> effects = PotionUtils.getEffectsFromStack(stack);
            if (effects.isEmpty())
                continue;
            boolean isHarmful = false;
            boolean isHealing = false;
            for (PotionEffect effect : effects) {
                if (effect.getPotion() == MobEffects.INSTANT_DAMAGE || effect.getPotion() == MobEffects.POISON || effect.getPotion() == MobEffects.SLOWNESS || effect.getPotion() == MobEffects.WEAKNESS) {
                    isHarmful = true;
                }
                if (effect.getPotion() == MobEffects.INSTANT_HEALTH || effect.getPotion() == MobEffects.REGENERATION) {
                    isHealing = true;
                }
            }
            if (healing && isHealing) {
                InventoryManager.switchToSlot(i);
                client.utils.world.InteractionUtils.useItem();
                return true;
            }
            if (!healing && isHarmful) {
                InventoryManager.switchToSlot(i);
                client.utils.world.InteractionUtils.useItem();
                return true;
            }
        }
        return false;
    }
}
