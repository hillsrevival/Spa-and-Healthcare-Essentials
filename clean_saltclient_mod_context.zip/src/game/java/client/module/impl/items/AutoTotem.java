package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.utils.player.InvUtils;
import client.utils.player.FindItemResult;
import client.utils.player.PlayerUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

public class AutoTotem extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Mode", "ALWAYS", "ALWAYS", "SMART", "STRICT");

    private final NumberSetting delay = new NumberSetting("Delay (ms)", 0.0, 0.0, 500.0);

    private final NumberSetting health = new NumberSetting("Health Threshold", 10.0, 0.0, 36.0);

    private final BooleanSetting elytraCheck = new BooleanSetting("Elytra Safety", true);

    private final BooleanSetting fallCheck = new BooleanSetting("Fall Safety", true);

    private final BooleanSetting explosionCheck = new BooleanSetting("Explosion Safety", true);

    private long nextSwapTime = 0;

    public AutoTotem() {
        super("AutoTotem", Category.ITEMS);
        setDescription("Moves a totem to your offhand");
        addSetting(mode);
        addSetting(delay);
        addSetting(health);
        addSetting(elytraCheck);
        addSetting(fallCheck);
        addSetting(explosionCheck);
        handles(HandlerType.TICK);
    }

    @Override
    public void onTick() {
        if (!nullCheck())
            return;
        long now = System.currentTimeMillis();
        if (now < nextSwapTime)
            return;
        ItemStack offhand = mc.player.getHeldItemOffhand();
        if (offhand != null && offhand.getItem() == Items.TOTEM_OF_UNDYING)
            return;
        FindItemResult result = InvUtils.find(Items.TOTEM_OF_UNDYING);
        if (!result.found() || result.count() <= 0)
            return;
        boolean shouldHold = false;
        String m = mode.getValue();
        if (m.equals("ALWAYS")) {
            shouldHold = true;
        } else if (m.equals("STRICT")) {
            shouldHold = true;
        } else if (m.equals("SMART")) {
            float totalHp = PlayerUtils.getTotalHealth();
            if (totalHp <= health.getValue())
                shouldHold = true;
            if (elytraCheck.getValue() && mc.player.isElytraFlying())
                shouldHold = true;
            if (fallCheck.getValue()) {
                float fallDmg = PlayerUtils.predictFallDamage();
                if (fallDmg >= totalHp)
                    shouldHold = true;
            }
            if (explosionCheck.getValue()) {
                float expDmg = PlayerUtils.predictExplosionDamage();
                if (expDmg >= totalHp)
                    shouldHold = true;
            }
        }
        if (!shouldHold)
            return;
        InvUtils.moveToOffhand(result.slot());
        nextSwapTime = now + delay.getValue().longValue();
    }
}
