package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import client.utils.player.PendingSlotSwitch;

public class AutoEat extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 2.0, 0.0, 10.0);

    private final PendingSlotSwitch switcher = new PendingSlotSwitch();

    public AutoEat() {
        super("AutoEat", Category.ITEMS);
        setDescription("Automatically eats food when your hunger is low");
        addSetting(switchDelay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (switcher.hasPending()) {
            if (switcher.tick()) {
                switcher.applySwitch();
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
            }
            return;
        }
        if (!mc.player.canEat(false)) {
            stopEating();
            return;
        }
        if (mc.player.getFoodStats().getFoodLevel() >= 18) {
            stopEating();
            return;
        }
        int bestSlot = -1;
        int bestFood = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == null || !(stack.getItem() instanceof ItemFood))
                continue;
            ItemFood food = (ItemFood) stack.getItem();
            int heal = food.getHealAmount(stack);
            if (heal > bestFood) {
                bestFood = heal;
                bestSlot = i;
            }
        }
        if (bestSlot == -1) {
            stopEating();
            return;
        }
        switcher.queue(bestSlot, switchDelay.getValue().intValue());
    }

    private void stopEating() {
        if (switcher.getOldSlot() == -1)
            return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
        switcher.restore();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        stopEating();
    }
}
