package client.module.impl.items;

import client.module.Category;
import client.module.Module;
import client.module.ModeSetting;
import client.utils.misc.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

public class KillPotion extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Mode", "Kill", "Kill", "Troll");

    public KillPotion() {
        super("KillPotion", Category.ITEMS);
        setDescription("Creative-only: creates exploit splash potions (Kill or Troll mode)");
        addSetting(mode);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null || mc.world == null) {
            toggle();
            return;
        }
        if (!mc.player.capabilities.isCreativeMode) {
            ChatUtils.error("KillPotion requires Creative mode!");
            toggle();
            return;
        }
        ItemStack potion = new ItemStack(Items.SPLASH_POTION, 1, 0);
        NBTTagCompound nbt = new NBTTagCompound();
        NBTTagCompound display = new NBTTagCompound();
        NBTTagList customEffects = new NBTTagList();
        if (mode.getValue().equals("Kill")) {
            display.setString("Name", "\u00a74\u00a7lKill Potion \u00a7c[Amp 125]");
            NBTTagCompound effect = new NBTTagCompound();
            effect.setByte("Id", (byte) 6);
            effect.setByte("Amplifier", (byte) 125);
            effect.setInteger("Duration", 2000);
            effect.setBoolean("Ambient", false);
            effect.setBoolean("ShowParticles", false);
            customEffects.appendTag(effect);
        } else {
            display.setString("Name", "\u00a7d\u00a7lTroll Potion \u00a75[All Effects]");
            for (int i = 1; i <= 23; i++) {
                NBTTagCompound effect = new NBTTagCompound();
                effect.setByte("Id", (byte) i);
                effect.setByte("Amplifier", (byte) 127);
                effect.setInteger("Duration", Integer.MAX_VALUE);
                effect.setBoolean("Ambient", false);
                effect.setBoolean("ShowParticles", false);
                customEffects.appendTag(effect);
            }
        }
        nbt.setTag("display", display);
        nbt.setTag("CustomPotionEffects", customEffects);
        potion.setTagCompound(nbt);
        if (mc.player.inventory != null) {
            int slot = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack s = mc.player.inventory.mainInventory.get(i);
                if (s == null || s.func_190926_b()) {
                    slot = i;
                    break;
                }
            }
            if (slot == -1)
                slot = 0;
            mc.player.inventory.mainInventory.set(slot, potion);
            mc.player.inventoryContainer.detectAndSendChanges();
            mc.player.inventory.currentItem = slot;
        }
        if (mode.getValue().equals("Kill")) {
            ChatUtils.success("Kill Potion created! Instant Damage Amp 125.");
        } else {
            ChatUtils.success("Troll Potion created! All effects at max.");
        }
        ChatUtils.info("Throw it manually.");
        toggle();
    }
}
