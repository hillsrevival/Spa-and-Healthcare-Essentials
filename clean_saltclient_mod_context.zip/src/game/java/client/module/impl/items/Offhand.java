package client.module.impl.items;

import client.module.Category;
import client.module.Condition;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.NumberSetting;
import client.utils.EntityUtils;
import client.utils.player.InvUtils;
import client.utils.player.SlotUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Items;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;

public class Offhand extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Mode", "Totem", "Totem", "Crystal", "Gapple", "Food", "Shield");

    private final ModeSetting shieldMode = new ModeSetting("Shield Mode", "Smart", "Always", "Smart");

    private final NumberSetting detectRange = new NumberSetting("DetectRange", 4.0, 1.0, 8.0);

    private final NumberSetting restoreDelay = new NumberSetting("RestoreDelay", 2.0, 0.5, 10.0);

    private final NumberSetting swapDelay = new NumberSetting("SwapDelay", 3.0, 0.0, 20.0);

    private int savedShieldSlot = -1;

    private boolean weMoved = false;

    private int calmTicks = 0;

    private long nextSwapAllowedTick = 0L;

    public Offhand() {
        super("Offhand", Category.ITEMS);
        setDescription("Manages offhand with totems, food, or shields");
        addSetting(mode);
        addSetting(shieldMode);
        addSetting(detectRange);
        addSetting(restoreDelay);
        addSetting(swapDelay);
        shieldMode.setVisibilityCondition(Condition.whenEqualTo(mode, "Shield"));
        swapDelay.setVisibilityCondition(Condition.whenEqualTo(mode, "Shield"));
        detectRange.setVisibilityCondition(Condition.and(Condition.whenEqualTo(mode, "Shield"), Condition.whenEqualTo(shieldMode, "Smart")));
        restoreDelay.setVisibilityCondition(Condition.and(Condition.whenEqualTo(mode, "Shield"), Condition.whenEqualTo(shieldMode, "Smart")));
        handles(HandlerType.TICK);
    }

    @Override
    public void onTick() {
        if (!nullCheck())
            return;
        if (mc.player.isDead || mc.player.getHealth() <= 0.0f)
            return;
        if (mc.currentScreen instanceof GuiContainer)
            return;
        String currentMode = mode.getValue();
        if ("Shield".equals(currentMode)) {
            handleShield();
        } else {
            resetShieldState();
            handleSimpleItem(currentMode);
        }
    }

    private void handleSimpleItem(String currentMode) {
        ItemStack offhand = mc.player.getHeldItemOffhand();
        if (offhand != null && !offhand.func_190926_b()) {
            if ("Totem".equals(currentMode) && offhand.getItem() == Items.TOTEM_OF_UNDYING)
                return;
            if ("Crystal".equals(currentMode) && offhand.getItem() == Items.END_CRYSTAL)
                return;
            if ("Gapple".equals(currentMode) && offhand.getItem() == Items.GOLDEN_APPLE)
                return;
            if ("Food".equals(currentMode) && offhand.getItem() instanceof ItemFood)
                return;
        }
        int targetSlot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (stack == null || stack.func_190926_b())
                continue;
            if ("Totem".equals(currentMode) && stack.getItem() == Items.TOTEM_OF_UNDYING) {
                targetSlot = i;
                break;
            }
            if ("Crystal".equals(currentMode) && stack.getItem() == Items.END_CRYSTAL) {
                targetSlot = i;
                break;
            }
            if ("Gapple".equals(currentMode) && stack.getItem() == Items.GOLDEN_APPLE) {
                targetSlot = i;
                break;
            }
            if ("Food".equals(currentMode) && stack.getItem() instanceof ItemFood) {
                targetSlot = i;
                break;
            }
        }
        if (targetSlot == -1)
            return;
        InvUtils.moveToOffhand(SlotUtils.HOTBAR_START + targetSlot);
    }

    private void handleShield() {
        ItemStack offhand = mc.player.getHeldItemOffhand();
        boolean shieldInOffhand = offhand != null && !offhand.func_190926_b() && offhand.getItem() == Items.SHIELD;
        if (shieldInOffhand) {
            if (!weMoved) {
                calmTicks = 0;
                return;
            }
            if ("Always".equals(shieldMode.getValue())) {
                calmTicks = 0;
                return;
            }
            if (isThreatNear()) {
                calmTicks = 0;
            } else {
                calmTicks++;
                int delay = (int) (restoreDelay.getValue() * 20.0);
                if (calmTicks >= delay) {
                    if (swapAllowed())
                        restoreOffhand();
                }
            }
            return;
        }
        if ("Smart".equals(shieldMode.getValue())) {
            if (!isThreatNear()) {
                resetShieldState();
                return;
            }
        }
        if (!swapAllowed())
            return;
        int slot = findShieldSlot();
        if (slot == -1) {
            resetShieldState();
            return;
        }
        nextSwapAllowedTick = mc.player.ticksExisted + swapDelay.getValue().longValue() + (long) (Math.random() * 3.0);
        InvUtils.moveToOffhand(slot);
        if (!weMoved) {
            savedShieldSlot = slot;
        }
        weMoved = true;
        calmTicks = 0;
    }

    private boolean swapAllowed() {
        return mc.player == null || mc.player.ticksExisted >= nextSwapAllowedTick;
    }

    private void restoreOffhand() {
        if (savedShieldSlot != -1 && mc.player != null) {
            InvUtils.moveToOffhand(savedShieldSlot);
        }
        resetShieldState();
    }

    private boolean isThreatNear() {
        if (!nullCheck())
            return false;
        EntityUtils.TargetSettings settings = new EntityUtils.TargetSettings().setRange(detectRange.getValue().floatValue()).setFOV(360.0f).setTargetPlayers(true).setTargetMonsters(true).setTargetAnimals(false);
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (!EntityUtils.isCorrectEntity(entity, settings))
                continue;
            if (!(entity instanceof EntityLivingBase))
                continue;
            EntityLivingBase living = (EntityLivingBase) entity;
            if (living.isEntityAlive() && living.getHealth() > 0) {
                return true;
            }
        }
        return false;
    }

    private int findShieldSlot() {
        for (int i = SlotUtils.HOTBAR_START; i <= SlotUtils.HOTBAR_END; i++) {
            ItemStack stack = mc.player.inventoryContainer.getSlot(i).getStack();
            if (stack != null && !stack.func_190926_b() && stack.getItem() == Items.SHIELD) {
                return i;
            }
        }
        for (int i = SlotUtils.MAIN_START; i <= SlotUtils.MAIN_END; i++) {
            ItemStack stack = mc.player.inventoryContainer.getSlot(i).getStack();
            if (stack != null && !stack.func_190926_b() && stack.getItem() == Items.SHIELD) {
                return i;
            }
        }
        return -1;
    }

    private void resetShieldState() {
        savedShieldSlot = -1;
        weMoved = false;
        calmTicks = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        resetShieldState();
    }
}
