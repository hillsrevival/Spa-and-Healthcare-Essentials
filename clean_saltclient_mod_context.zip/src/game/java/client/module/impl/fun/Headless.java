package client.module.impl.fun;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.CPacketPlayer;

public class Headless extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public Headless() {
        super("Headless", Category.FUN);
        setDescription("Hides your player head rendering in first person");
        handles(HandlerType.PACKET_OUTPUT);
    }

    @Override
    public void onPacketOutput(client.event.events.PacketOutputEvent event) {
        if (mc.player == null)
            return;
        Object pkt = event.getPacket();
        float fakePitch = 180.0f - mc.player.rotationPitch;
        if (pkt instanceof CPacketPlayer.PositionRotation) {
            CPacketPlayer.PositionRotation old = (CPacketPlayer.PositionRotation) pkt;
            event.setPacket(new CPacketPlayer.PositionRotation(old.getX(0), old.getY(0), old.getZ(0), old.getYaw(0), fakePitch, old.isOnGround()));
        } else if (pkt instanceof CPacketPlayer.Rotation) {
            CPacketPlayer.Rotation old = (CPacketPlayer.Rotation) pkt;
            event.setPacket(new CPacketPlayer.Rotation(old.getYaw(0), fakePitch, old.isOnGround()));
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        ChatUtils.info("Headless enabled - your head is now inverted server-side");
    }
}
