package client.module.impl.fun;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.combat.EntityFakePlayer;
import net.minecraft.client.Minecraft;

public class FakePlayer extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting distance = new NumberSetting("Distance", 3.0, 1.0, 6.0);

    private final BooleanSetting copyInv = new BooleanSetting("Copy Inv", true);

    private EntityFakePlayer fakePlayer = null;

    public FakePlayer() {
        super("FakePlayer", Category.FUN);
        setDescription("Spawns a fake player entity for testing");
        addSetting(distance);
        addSetting(copyInv);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (!nullCheck())
            return;
        fakePlayer = new EntityFakePlayer();
        float yaw = mc.player.rotationYaw;
        double x = mc.player.posX - Math.sin(Math.toRadians(yaw)) * distance.getValue();
        double z = mc.player.posZ + Math.cos(Math.toRadians(yaw)) * distance.getValue();
        fakePlayer.setPosition(x, mc.player.posY, z);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (fakePlayer != null) {
            fakePlayer.despawn();
            fakePlayer = null;
        }
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (fakePlayer == null)
            return;
        float yaw = mc.player.rotationYaw;
        double targetX = mc.player.posX - Math.sin(Math.toRadians(yaw)) * distance.getValue();
        double targetZ = mc.player.posZ + Math.cos(Math.toRadians(yaw)) * distance.getValue();
        fakePlayer.setPosition(targetX, mc.player.posY, targetZ);
    }
}
