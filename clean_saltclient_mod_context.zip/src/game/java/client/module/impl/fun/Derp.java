package client.module.impl.fun;

import net.minecraft.client.Minecraft;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import java.util.Random;
import client.utils.world.PacketUtils;

public class Derp extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Random random = new Random();

    public Derp() {
        super("Derp", Category.FUN);
        setDescription("Randomly rotates your head");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        float yaw = random.nextFloat() * 360.0f - 180.0f;
        float pitch = random.nextFloat() * 180.0f - 90.0f;
        mc.player.rotationYawHead = yaw;
        mc.player.renderYawOffset = yaw;
        mc.player.rotationPitch = pitch;
        PacketUtils.sendRotation(yaw, pitch, mc.player.onGround);
    }
}
