package client.module.impl.fun;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.misc.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;

public class MileyCyrus extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting twerkSpeed = new NumberSetting("TwerkSpeed", 5.0, 1.0, 10.0);

    private int tickCounter = 0;

    private boolean sneaking = false;

    public MileyCyrus() {
        super("MileyCyrus", Category.FUN);
        setDescription("MileyCyrus");
        addSetting(twerkSpeed);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        int threshold = 10 - twerkSpeed.getValue().intValue();
        if (threshold < 1)
            threshold = 1;
        tickCounter++;
        if (tickCounter >= threshold) {
            sneaking = !sneaking;
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), sneaking);
            tickCounter = 0;
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        tickCounter = 0;
        sneaking = false;
        ChatUtils.info("MileyCyrus enabled - twerk twerk");
    }

    @Override
    public void onDisable() {
        sneaking = false;
        if (mc.gameSettings != null) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
        }
        super.onDisable();
    }
}
