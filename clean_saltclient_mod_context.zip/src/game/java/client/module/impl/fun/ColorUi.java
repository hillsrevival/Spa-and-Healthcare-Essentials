package client.module.impl.fun;

import client.module.Category;
import client.module.ColorSetting;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.NumberSetting;

public class ColorUi extends Module {

    public static float hue = 0;

    private final ModeSetting mode = new ModeSetting("Mode", "Rainbow", "Rainbow", "Custom", "Preset");

    private final ColorSetting customColor = new ColorSetting("Custom Color", 0.0);

    private final ModeSetting preset = new ModeSetting("Preset", "Red", "Red", "Orange", "Amber", "Emerald", "Cyan", "Blue", "Indigo", "Violet", "Amethyst", "Pink", "Rose");

    private final NumberSetting speed = new NumberSetting("Speed", 0.01, 0.001, 0.05);

    private static final float[] PRESET_HUES = { 0.0f, 0.083f, 0.125f, 0.417f, 0.5f, 0.583f, 0.667f, 0.75f, 0.792f, 0.917f, 0.958f };

    private static final int[] PRESET_RGB;

    static {
        PRESET_RGB = new int[PRESET_HUES.length];
        for (int i = 0; i < PRESET_HUES.length; i++) {
            float[] rgb = ColorSetting.hsbToRgb(PRESET_HUES[i], 1.0f, 1.0f);
            PRESET_RGB[i] = ((int) (rgb[0] * 255) << 16) | ((int) (rgb[1] * 255) << 8) | (int) (rgb[2] * 255);
        }
    }

    public ColorUi() {
        super("ColorUi", Category.FUN);
        setDescription("Changes ui color");
        addSetting(mode);
        addSetting(customColor);
        addSetting(preset);
        addSetting(speed);
        preset.setVisibilityCondition(client.module.Condition.never());
        handles(HandlerType.UPDATE);
    }

    private static int getPresetRGB(String name) {
        String[] names = { "Red", "Orange", "Amber", "Emerald", "Cyan", "Blue", "Indigo", "Violet", "Amethyst", "Pink", "Rose" };
        for (int i = 0; i < names.length; i++) {
            if (names[i].equals(name)) {
                return PRESET_RGB[i];
            }
        }
        return -1;
    }

    public static boolean isCustomMode() {
        ColorUi instance = (ColorUi) client.module.ModuleManager.getModuleByName("ColorUi");
        return instance != null && instance.isToggled() && instance.mode.getValue().equals("Custom");
    }

    public static boolean isPresetMode() {
        ColorUi instance = (ColorUi) client.module.ModuleManager.getModuleByName("ColorUi");
        return instance != null && instance.isToggled() && instance.mode.getValue().equals("Preset");
    }

    public static int getCustomAccent() {
        ColorUi instance = (ColorUi) client.module.ModuleManager.getModuleByName("ColorUi");
        if (instance != null) {
            if (instance.mode.getValue().equals("Preset")) {
                int rgb = getPresetRGB(instance.preset.getValue());
                if (rgb >= 0)
                    return 0xFF000000 | rgb;
            }
            return instance.customColor.getARGB();
        }
        return 0xFFFF2222;
    }

    public static int getCustomAccent(int alpha) {
        ColorUi instance = (ColorUi) client.module.ModuleManager.getModuleByName("ColorUi");
        if (instance != null) {
            if (instance.mode.getValue().equals("Preset")) {
                int rgb = getPresetRGB(instance.preset.getValue());
                if (rgb >= 0)
                    return (alpha << 24) | rgb;
            }
            return instance.customColor.getARGB(alpha);
        }
        return (alpha << 24) | 0xFF2222;
    }

    @Override
    public void onUpdate() {
        hue += speed.getValue().floatValue();
        if (hue > 1.0f)
            hue = 0;
        preset.setVisibilityCondition(mode.getValue().equals("Preset") ? client.module.Condition.always() : client.module.Condition.never());
    }

    public static int getRainbowColor() {
        if (isCustomMode())
            return getCustomAccent();
        if (isPresetMode())
            return getCustomAccent();
        int r = (int) (Math.sin(hue * Math.PI * 2) * 127 + 128);
        int g = (int) (Math.sin((hue + 0.333f) * Math.PI * 2) * 127 + 128);
        int b = (int) (Math.sin((hue + 0.666f) * Math.PI * 2) * 127 + 128);
        return (r << 16) | (g << 8) | b;
    }

    public static int getRainbowColor(int alpha) {
        if (isCustomMode())
            return getCustomAccent(alpha);
        if (isPresetMode())
            return getCustomAccent(alpha);
        int r = (int) (Math.sin(hue * Math.PI * 2) * 127 + 128);
        int g = (int) (Math.sin((hue + 0.333f) * Math.PI * 2) * 127 + 128);
        int b = (int) (Math.sin((hue + 0.666f) * Math.PI * 2) * 127 + 128);
        return (alpha << 24) | (r << 16) | (g << 8) | b;
    }

    public static int getRainbowColor(float offset) {
        if (isCustomMode())
            return getCustomAccent();
        if (isPresetMode())
            return getCustomAccent();
        float h = hue + offset;
        if (h > 1.0f)
            h -= 1.0f;
        int r = (int) (Math.sin(h * Math.PI * 2) * 127 + 128);
        int g = (int) (Math.sin((h + 0.333f) * Math.PI * 2) * 127 + 128);
        int b = (int) (Math.sin((h + 0.666f) * Math.PI * 2) * 127 + 128);
        return (r << 16) | (g << 8) | b;
    }
}
