package client.module.impl.fun;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.player.EnumPlayerModelParts;
import java.util.Random;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;

public class SkinDerp extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Random random = new Random();

    private static final int TICK_INTERVAL = 4;

    private int tickCounter = 0;

    public SkinDerp() {
        super("SkinDerp", Category.FUN);
        setDescription("Makes skin flicker between layers");
        handles(HandlerType.TICK);
    }

    @Override
    public void onTick() {
        if (mc.player == null)
            return;
        tickCounter++;
        if (tickCounter < TICK_INTERVAL)
            return;
        tickCounter = 0;
        GameSettings settings = mc.gameSettings;
        settings.setModelPartEnabled(EnumPlayerModelParts.HAT, random.nextBoolean());
        settings.setModelPartEnabled(EnumPlayerModelParts.JACKET, random.nextBoolean());
        settings.setModelPartEnabled(EnumPlayerModelParts.LEFT_SLEEVE, random.nextBoolean());
        settings.setModelPartEnabled(EnumPlayerModelParts.RIGHT_SLEEVE, random.nextBoolean());
        settings.setModelPartEnabled(EnumPlayerModelParts.LEFT_PANTS_LEG, random.nextBoolean());
        settings.setModelPartEnabled(EnumPlayerModelParts.RIGHT_PANTS_LEG, random.nextBoolean());
    }

    @Override
    public void onEnable() {
        super.onEnable();
        tickCounter = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        tickCounter = 0;
        if (mc.gameSettings != null) {
            mc.gameSettings.setModelPartEnabled(EnumPlayerModelParts.HAT, true);
            mc.gameSettings.setModelPartEnabled(EnumPlayerModelParts.JACKET, true);
            mc.gameSettings.setModelPartEnabled(EnumPlayerModelParts.LEFT_SLEEVE, true);
            mc.gameSettings.setModelPartEnabled(EnumPlayerModelParts.RIGHT_SLEEVE, true);
            mc.gameSettings.setModelPartEnabled(EnumPlayerModelParts.LEFT_PANTS_LEG, true);
            mc.gameSettings.setModelPartEnabled(EnumPlayerModelParts.RIGHT_PANTS_LEG, true);
        }
    }
}
