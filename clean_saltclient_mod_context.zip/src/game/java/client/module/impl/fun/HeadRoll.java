package client.module.impl.fun;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;

public class HeadRoll extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting speed = new NumberSetting("Speed", 0.1, 0.01, 0.5);

    private final NumberSetting amplitude = new NumberSetting("Amplitude", 45.0, 5.0, 90.0);

    private float tickCounter = 0;

    public HeadRoll() {
        super("HeadRoll", Category.FUN);
        setDescription("Tilts your head when strafing");
        addSetting(speed);
        addSetting(amplitude);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        tickCounter = 0;
    }

    @Override
    public void onDisable() {
        if (mc.player != null) {
            mc.player.rotationPitch = 0;
        }
        super.onDisable();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        tickCounter += speed.getValue().floatValue();
        float amp = amplitude.getValue().floatValue();
        mc.player.rotationPitch = (float) (Math.sin(tickCounter) * amp);
    }
}
