package client.module.impl.fun;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;

public class Lsd extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public Lsd() {
        super("Lsd", Category.FUN);
        setDescription("A visual effect to your screen");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (mc.getRenderViewEntity() instanceof net.minecraft.entity.player.EntityPlayer) {
            mc.player.addPotionEffect(new PotionEffect(MobEffects.NAUSEA, 400, 0, false, false));
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null)
            return;
        if (!(mc.getRenderViewEntity() instanceof net.minecraft.entity.player.EntityPlayer)) {
            ChatUtils.error("Lsd requires a player view entity.");
            toggle();
            return;
        }
        mc.player.addPotionEffect(new PotionEffect(MobEffects.NAUSEA, 999999, 0, false, false));
        ChatUtils.message("Lsd enabled \u00a7ktrip balls\u00a7r");
    }

    @Override
    public void onDisable() {
        if (mc.player != null) {
            mc.player.removePotionEffect(MobEffects.NAUSEA);
        }
        ChatUtils.message("Lsd disabled");
        super.onDisable();
    }
}
