package client.module.impl.fun;

import client.event.listeners.ChatInputListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import java.util.Random;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatGames extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Random random = new Random();

    private final NumberSetting minDelay = new NumberSetting("Min Delay", 300.0, 0.0, 5000.0);

    private final NumberSetting maxDelay = new NumberSetting("Max Delay", 700.0, 0.0, 5000.0);

    private long lastAnswerTime;

    private String lastExpression = "";

    private Integer pendingAnswer = null;

    private int ticksRemaining = -1;

    private static final Pattern EXPRESSION_PATTERN = Pattern.compile("[0-9()\\s+\\-*/xX÷]+");

    public ChatGames() {
        super("ChatGames", Category.FUN);
        setDescription("Automatically answers chat game questions");
        addSetting(minDelay);
        addSetting(maxDelay);
        handles(HandlerType.CHAT_INPUT, HandlerType.UPDATE);
    }

    @Override
    public void onChatInput(ChatInputListener.ChatInputEvent event) {
        if (!nullCheck())
            return;
        String message = event.getComponent().getUnformattedText();
        if (message == null || message.isEmpty())
            return;
        Matcher matcher = EXPRESSION_PATTERN.matcher(message);
        while (matcher.find()) {
            String expression = matcher.group().trim();
            if (expression.isEmpty())
                continue;
            if (!containsOperator(expression))
                continue;
            expression = expression.replace("x", "*").replace("X", "*").replace("÷", "/").replaceAll("\\s+", "");
            if (expression.equals(lastExpression) && System.currentTimeMillis() - lastAnswerTime < 3000L)
                return;
            Integer answer = solve(expression);
            if (answer == null)
                continue;
            lastExpression = expression;
            lastAnswerTime = System.currentTimeMillis();
            int min = minDelay.getValue().intValue();
            int max = maxDelay.getValue().intValue();
            if (max < min)
                max = min;
            int delayMs = min + random.nextInt(max - min + 1);
            this.pendingAnswer = answer;
            this.ticksRemaining = Math.max(1, delayMs / 50);
            return;
        }
    }

    public void onUpdate() {
        if (!isToggled()) {
            pendingAnswer = null;
            ticksRemaining = -1;
            return;
        }
        if (pendingAnswer != null && ticksRemaining > 0) {
            ticksRemaining--;
            if (ticksRemaining <= 0) {
                if (mc.player != null) {
                    mc.player.sendChatMessage(String.valueOf(pendingAnswer));
                }
                pendingAnswer = null;
            }
        }
    }

    private boolean containsOperator(String text) {
        return text.contains("+") || text.contains("-") || text.contains("*") || text.contains("/") || text.contains("x") || text.contains("X") || text.contains("÷");
    }

    private Integer solve(String expression) {
        try {
            double value = evaluate(expression);
            if (Double.isNaN(value))
                return null;
            return (int) Math.round(value);
        } catch (Exception ignored) {
            return null;
        }
    }

    private double evaluate(String expression) {
        Stack<Double> values = new Stack<>();
        Stack<Character> operators = new Stack<>();
        int i = 0;
        while (i < expression.length()) {
            char c = expression.charAt(i);
            if (Character.isWhitespace(c)) {
                i++;
                continue;
            }
            if (c == '(') {
                operators.push(c);
                i++;
                continue;
            }
            if (Character.isDigit(c)) {
                StringBuilder number = new StringBuilder();
                while (i < expression.length()) {
                    char n = expression.charAt(i);
                    if (!Character.isDigit(n) && n != '.')
                        break;
                    number.append(n);
                    i++;
                }
                values.push(Double.parseDouble(number.toString()));
                continue;
            }
            if (c == ')') {
                while (!operators.isEmpty() && operators.peek() != '(') {
                    values.push(apply(operators.pop(), values.pop(), values.pop()));
                }
                if (!operators.isEmpty())
                    operators.pop();
                i++;
                continue;
            }
            while (!operators.isEmpty() && precedence(operators.peek()) >= precedence(c)) {
                values.push(apply(operators.pop(), values.pop(), values.pop()));
            }
            operators.push(c);
            i++;
        }
        while (!operators.isEmpty()) {
            values.push(apply(operators.pop(), values.pop(), values.pop()));
        }
        return values.pop();
    }

    private int precedence(char operator) {
        switch(operator) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            default:
                return 0;
        }
    }

    private double apply(char operator, double b, double a) {
        switch(operator) {
            case '+':
                return a + b;
            case '-':
                return a - b;
            case '*':
                return a * b;
            case '/':
                if (b == 0)
                    throw new ArithmeticException("Division by zero");
                return a / b;
            default:
                throw new IllegalArgumentException("Unknown operator: " + operator);
        }
    }
}
