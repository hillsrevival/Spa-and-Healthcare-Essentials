package client.module.impl.other;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import client.utils.world.WorldUtils;

public class LiquidInteract extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting place = new BooleanSetting("Place", true);

    public LiquidInteract() {
        super("LiquidInteract", Category.OTHER);
        setDescription("Interact with blocks while under water or lava");
        addSetting(place);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.objectMouseOver == null || mc.objectMouseOver.typeOfHit != net.minecraft.util.math.RayTraceResult.Type.MISS) {
            return;
        }
        if (!place.getValue())
            return;
        net.minecraft.util.math.BlockPos lookPos = new net.minecraft.util.math.BlockPos(mc.objectMouseOver.hitVec.xCoord, mc.objectMouseOver.hitVec.yCoord, mc.objectMouseOver.hitVec.zCoord);
        net.minecraft.block.Block block = WorldUtils.getBlock(lookPos);
        if (block == net.minecraft.init.Blocks.WATER || block == net.minecraft.init.Blocks.FLOWING_WATER || block == net.minecraft.init.Blocks.LAVA || block == net.minecraft.init.Blocks.FLOWING_LAVA) {
            for (int dy = -1; dy >= -5; dy--) {
                net.minecraft.util.math.BlockPos below = lookPos.down(-dy);
                if (mc.world.isBlockFullCube(below)) {
                    mc.objectMouseOver = new net.minecraft.util.math.RayTraceResult(new net.minecraft.util.math.Vec3d(below.getX() + 0.5, below.getY() + 1.0, below.getZ() + 0.5), net.minecraft.util.EnumFacing.UP, below);
                    break;
                }
            }
        }
    }
}
