package client.module.impl.other;

import client.event.events.PacketInputEvent;
import client.event.events.PacketOutputEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.network.play.server.SPacketDisconnect;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketEntityTeleport;
import net.minecraft.network.play.server.SPacketBlockChange;
import net.minecraft.network.play.server.SPacketConfirmTransaction;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.util.math.BlockPos;
import org.teavm.jso.JSBody;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;

public class FlagDetector extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final HudElement pos = new HudElement(this, -1, -1);

    private static final String CLOUD_URL = "https://galacticflagsfrfr.galacticflagsfrfr7123.workers.dev/";

    private static final double GRAVITY = 0.08;

    private static final double AIR_DRAG_Y = 0.98;

    private static final double AIR_DRAG_XZ = 0.91;

    private static final double DEFAULT_BLOCK_FRICTION = 0.6;

    private static final double JUMP_POWER = 0.42;

    private static final double SPRINT_JUMP_BONUS = 0.2;

    private static final double WALK_SPEED = 0.1;

    private static final double SPRINT_MULT = 1.3;

    private static final double SNEAK_MULT = 0.3;

    private static final double AIR_BONUS = 0.02;

    private static final double SPRINT_AIR_BONUS = 0.026;

    private static final double USING_ITEM_SLOWDOWN = 0.2;

    private static final double INPUT_MULT = 0.98;

    private static final double GROUND_ACCELERATION_1_12 = 0.16277136;

    private static final double OFFSET_THRESHOLD = 0.001;

    private static final double IMMEDIATE_SETBACK = 0.1;

    private static final double MAX_ADVANTAGE = 1.0;

    private static final double ADVANTAGE_CEILING = 4.0;

    private static final double SETBACK_DECAY = 0.999;

    private static final int SETBACK_VIOLATION_THRESHOLD = 1;

    private static final double BLOCK_REACH_SURVIVAL = 4.5;

    private static final double BLOCK_REACH_CREATIVE = 5.0;

    private static final double ENTITY_REACH_SURVIVAL = 3.0;

    private static final double ENTITY_REACH_CREATIVE = 6.0;

    private static final double REACH_THRESHOLD = 0.0005;

    private static final double MOVEMENT_THRESHOLD_03 = 0.03;

    private static final double HITBOX_MARGIN_18 = 0.1;

    private static final double MAX_DOUBLE_ERROR = 7.450580596923828E-9;

    private static final double FLOAT_STEP_AT_ONE = 1.1920929E-7;

    private static final String CAT_SIMULATION = "Simulation";

    private static final String CAT_MOVEMENT = "Movement";

    private static final String CAT_PACKET = "Packet";

    private static final String CAT_BLOCK = "Block";

    private static final String CAT_COMBAT = "Combat";

    private static final String CAT_SERVER = "Server";

    private int flagCount = 0;

    private String lastFlag = "None";

    private String lastCategory = "";

    private long lastFlagTime = 0;

    private final List<FlagEntry> flagLog = new ArrayList<FlagEntry>();

    private static final int MAX_LOG = 8;

    private final Map<String, Integer> categoryCounts = new LinkedHashMap<String, Integer>();

    private double prevX, prevY, prevZ;

    private double prevMotionX, prevMotionY, prevMotionZ;

    private boolean prevOnGround;

    private boolean prevSprinting;

    private boolean prevSneaking;

    private boolean hasPrevState = false;

    private double predictedX, predictedY, predictedZ;

    private double predictionOffset = 0;

    private double advantageGained = 0;

    private int simulationViolations = 0;

    private long lastAttackTime = 0;

    private int lastAttackedEntityId = -1;

    private double lastAttackedEntityHealth = 0;

    private long lastBlockPlaceTime = 0;

    private BlockPos lastBlockPlaced = null;

    private int lastPlacedBlockId = -1;

    private BlockPos lastBrokenBlock = null;

    private long lastBrokenTime = 0;

    private BlockPos lastClickedPos = null;

    private boolean expectTeleport = false;

    private long expectTeleportUntil = 0;

    private boolean lastPacketWasTeleport = false;

    private boolean pendingAttackCheck = false;

    private long pendingAttackTime = 0;

    private int pendingAttackEntityId = -1;

    private double pendingAttackEntityHealth = 0;

    private int pendingAttackTicksLeft = 0;

    private boolean wasUsingItem = false;

    private boolean wasNearGround = false;

    private boolean wasSprintingLowHunger = false;

    private boolean wasInSolid = false;

    private long lastHotbarChange = 0;

    private int lastHotbarSlot = -1;

    private static final long CLOUD_BATCH_MS = 30000;

    private long lastCloudBatch = 0;

    private final Map<String, Integer> batchCounts = new LinkedHashMap<String, Integer>();

    private final List<String> batchTypes = new ArrayList<String>();

    private int batchTotalFlags = 0;

    private long lastPlaceTickTime = 0;

    private int lastPlaceFace = -1;

    private float lastPlaceCursorX, lastPlaceCursorY, lastPlaceCursorZ;

    private BlockPos lastPlacePos = null;

    private boolean hasPlacedThisTick = false;

    private long lastBreakTickTime = 0;

    private int lastBreakFace = -1;

    private BlockPos lastBreakPos = null;

    private boolean hasBrokenThisTick = false;

    private long startBreakTime = 0;

    private BlockPos startBreakBlockPos = null;

    private double maxBlockDamage = 0;

    private long lastFinishBreak = 0;

    private double blockBreakBalance = 0;

    private double blockDelayBalance = 0;

    private BlockPos lastStartedBreakPos = null;

    private BlockPos lastCancelledBreakPos = null;

    private boolean lastBlockWasInstantBreak = false;

    private boolean sentSwingThisTick = false;

    private boolean sentBreakThisTick = false;

    private int lastInteractEntityId = -1;

    private boolean lastInteractSneaking = false;

    private boolean hasInteractedThisTick = false;

    private float lastInteractAtX, lastInteractAtY, lastInteractAtZ;

    private boolean hasInteractAtThisTick = false;

    private float lastDeltaYaw = 0;

    private float prevYaw = 0, prevPitch = 0;

    private float lastPlacedDeltaX = 0;

    private boolean hasPrevRotation = false;

    private int consecutiveDuplicateLookCount = 0;

    private boolean rotatedThisTick = false;

    private boolean aimDuplicateExempt = false;

    private double deltaDotsYaw = 0;

    private double modeYaw = 0;

    private float aimProcLastYaw = 0;

    private double deltaDotsPitch = 0;

    private double modePitch = 0;

    private float aimProcLastPitch = 0;

    private final double[] yawDivisorHistory = new double[80];

    private int yawDivisorCount = 0;

    private final double[] pitchDivisorHistory = new double[80];

    private int pitchDivisorCount = 0;

    private double lastPlacedDeltaDotsX = 0;

    private static final double MINIMUM_DIVISOR = (Math.pow(0.2f, 3) * 8.0) * 0.15 - 1e-3;

    private int lastHeldSlot = -1;

    private int noReminderTicks = 0;

    private static final int MAX_NO_REMINDER_TICKS = 20;

    private boolean lastSprinting = false;

    private int consecutiveSprintDuplicates = 0;

    private boolean lastSneaking = false;

    private boolean sneakRespawn = false;

    private int consecutiveSneakDuplicates = 0;

    private boolean sprintCFlaggedLastTick = false;

    private boolean sprintDStartedBeforeBlind = false;

    private boolean sprintEStartedThisTick = false;

    private boolean sprintEWasHardCollision = false;

    private long timerBalanceNanos = 0;

    private long knownPlayerClockNanos = 0;

    private long lastMovementClockNanos = 0;

    private static final long TIMER_CLOCK_DRIFT = 120_000_000L;

    private long lastTickNanos = 0;

    private static final String[] FLAG_KEYWORDS = { "flag", "cheat", "hack", "kick", "ban", "violation", "setback", "rubberband", "detect", "suspic", "unfair", "advantage", "modified", "client", "anticheat", "grim", "matrix", "vulcan", "negativity", "nocheatplus", "nocheat", "ac.alert", "ac.flag", "ac.kick", "simulation", "offset", "groundspoof", "nfall", "badpackets" };

    private static FlagDetector instance = null;

    public FlagDetector() {
        super("FlagDetector", Category.OTHER);
        setDescription("Detects flags and reports to devs so it gets fixed");
        pos.addSettings();
        handles(HandlerType.PACKET_INPUT, HandlerType.PACKET_OUTPUT, HandlerType.GUI_RENDER, HandlerType.TICK);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        instance = this;
        flagCount = 0;
        lastFlag = "None";
        lastCategory = "";
        flagLog.clear();
        categoryCounts.clear();
        hasPrevState = false;
        advantageGained = 0;
        simulationViolations = 0;
        lastCloudBatch = 0;
        batchCounts.clear();
        batchTypes.clear();
        batchTotalFlags = 0;
        hasPlacedThisTick = false;
        hasBrokenThisTick = false;
        hasInteractedThisTick = false;
        hasInteractAtThisTick = false;
        lastInteractEntityId = -1;
        lastPlaceFace = -1;
        lastBreakFace = -1;
        lastPlacePos = null;
        lastBreakPos = null;
        lastStartedBreakPos = null;
        lastCancelledBreakPos = null;
        startBreakBlockPos = null;
        lastFinishBreak = 0;
        blockBreakBalance = 0;
        blockDelayBalance = 0;
        lastHeldSlot = -1;
        noReminderTicks = 0;
        lastSprinting = false;
        consecutiveSprintDuplicates = 0;
        lastSneaking = false;
        sneakRespawn = false;
        consecutiveSneakDuplicates = 0;
        sprintCFlaggedLastTick = false;
        sprintDStartedBeforeBlind = false;
        sprintEStartedThisTick = false;
        sprintEWasHardCollision = false;
        hasPrevRotation = false;
        consecutiveDuplicateLookCount = 0;
        lastDeltaYaw = 0;
        lastPlacedDeltaX = 0;
        timerBalanceNanos = 0;
        lastTickNanos = 0;
        sentSwingThisTick = false;
        sentBreakThisTick = false;
        lastPlacedBlockId = -1;
        lastBlockPlaced = null;
        deltaDotsYaw = 0;
        deltaDotsPitch = 0;
        modeYaw = 0;
        modePitch = 0;
        aimProcLastYaw = 0;
        aimProcLastPitch = 0;
        yawDivisorCount = 0;
        pitchDivisorCount = 0;
        lastPlacedDeltaDotsX = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (instance == this)
            instance = null;
    }

    @Override
    public void onTick() {
        if (!nullCheck())
            return;
        if (expectTeleport && System.currentTimeMillis() > expectTeleportUntil) {
            expectTeleport = false;
        }
        if (!hasPrevState) {
            recordState();
            return;
        }
        double actualX = mc.player.posX - prevX;
        double actualY = mc.player.posY - prevY;
        double actualZ = mc.player.posZ - prevZ;
        predictMovement();
        double dx = actualX - predictedX;
        double dy = actualY - predictedY;
        double dz = actualZ - predictedZ;
        double offset = Math.sqrt(dx * dx + dy * dy + dz * dz);
        predictionOffset = offset;
        predictionOffset = offset;
        if (offset >= OFFSET_THRESHOLD) {
            advantageGained += offset;
            if (advantageGained > ADVANTAGE_CEILING) {
                advantageGained = ADVANTAGE_CEILING;
            }
            simulationViolations++;
        } else {
            advantageGained *= SETBACK_DECAY;
            if (advantageGained < 0.001)
                advantageGained = 0;
        }
        wasUsingItem = mc.player.isHandActive();
        wasNearGround = checkNearGround();
        wasSprintingLowHunger = mc.player.isSprinting() && mc.player.getFoodStats().getFoodLevel() <= 6;
        if (mc.player.inventory.currentItem != lastHotbarSlot) {
            lastHotbarSlot = mc.player.inventory.currentItem;
            lastHotbarChange = System.currentTimeMillis();
        }
        if (pendingAttackCheck && pendingAttackTicksLeft > 0) {
            pendingAttackTicksLeft--;
            net.minecraft.entity.Entity target = mc.world.getEntityByID(pendingAttackEntityId);
            if (target instanceof net.minecraft.entity.EntityLivingBase) {
                net.minecraft.entity.EntityLivingBase livingTarget = (net.minecraft.entity.EntityLivingBase) target;
                double currentHealth = livingTarget.getHealth();
                if (currentHealth < pendingAttackEntityHealth || livingTarget.hurtTime > 0 || livingTarget.deathTime > 0) {
                    pendingAttackCheck = false;
                    pendingAttackTicksLeft = 0;
                } else if (pendingAttackTicksLeft == 0) {
                    pendingAttackCheck = false;
                }
            } else {
                pendingAttackCheck = false;
                pendingAttackTicksLeft = 0;
            }
        }
        recordState();
        hasPlacedThisTick = false;
        hasBrokenThisTick = false;
        hasInteractedThisTick = false;
        hasInteractAtThisTick = false;
        rotatedThisTick = false;
        checkNoSwingBreak();
        checkBatchFlush();
    }

    private boolean checkNearGround() {
        if (mc.player == null || mc.world == null)
            return false;
        net.minecraft.util.math.AxisAlignedBB box = mc.player.getEntityBoundingBox();
        net.minecraft.util.math.AxisAlignedBB checkBox = new net.minecraft.util.math.AxisAlignedBB(box.minX + 0.2, box.minY - 0.01, box.minZ + 0.2, box.maxX - 0.2, box.minY + 0.01, box.maxZ - 0.2);
        return !mc.world.getCollisionBoxes(mc.player, checkBox).isEmpty();
    }

    private void predictMovement() {
        double velX = prevMotionX;
        double velY = prevMotionY;
        double velZ = prevMotionZ;
        boolean onGround = prevOnGround;
        boolean sprinting = prevSprinting;
        boolean sneaking = prevSneaking;
        boolean flying = mc.player.capabilities.isFlying;
        boolean usingItem = mc.player.isHandActive();
        double blockFriction = getBlockFrictionBelow();
        double movementSpeed;
        if (flying) {
            movementSpeed = mc.player.capabilities.getFlySpeed();
        } else if (onGround) {
            movementSpeed = WALK_SPEED;
            if (sprinting)
                movementSpeed *= SPRINT_MULT;
            if (sneaking)
                movementSpeed *= SNEAK_MULT;
            double friction = blockFriction * AIR_DRAG_XZ;
            movementSpeed *= (GROUND_ACCELERATION_1_12 / (friction * friction * friction));
        } else {
            movementSpeed = sprinting ? SPRINT_AIR_BONUS : AIR_BONUS;
        }
        float moveForward = mc.player.movementInput.field_192832_b;
        float moveStrafe = mc.player.movementInput.moveStrafe;
        if (sneaking) {
            moveForward *= SNEAK_MULT;
            moveStrafe *= SNEAK_MULT;
        }
        if (usingItem) {
            moveForward *= USING_ITEM_SLOWDOWN;
            moveStrafe *= USING_ITEM_SLOWDOWN;
        }
        moveForward *= INPUT_MULT;
        moveStrafe *= INPUT_MULT;
        float lengthSq = moveForward * moveForward + moveStrafe * moveStrafe;
        if (lengthSq >= 1.0E-4F) {
            float length = (float) Math.sqrt(lengthSq);
            if (length < 1.0F)
                length = 1.0F;
            float scale = (float) (movementSpeed / length);
            moveForward *= scale;
            moveStrafe *= scale;
            float yawRad = (float) Math.toRadians(mc.player.rotationYaw);
            float sin = (float) Math.sin(yawRad);
            float cos = (float) Math.cos(yawRad);
            double inputX = moveStrafe * cos - moveForward * sin;
            double inputZ = moveForward * cos + moveStrafe * sin;
            velX += inputX;
            velZ += inputZ;
        }
        if (!flying && !mc.player.hasNoGravity()) {
            velY -= GRAVITY;
        }
        double friction;
        if (onGround) {
            friction = blockFriction * AIR_DRAG_XZ;
        } else {
            friction = AIR_DRAG_XZ;
        }
        velX *= friction;
        velZ *= friction;
        velY *= AIR_DRAG_Y;
        predictedX = velX;
        predictedY = velY;
        predictedZ = velZ;
    }

    private double getBlockFrictionBelow() {
        if (mc.world == null || mc.player == null)
            return DEFAULT_BLOCK_FRICTION;
        BlockPos below = new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY - 1.0), Math.floor(mc.player.posZ));
        net.minecraft.block.Block block = mc.world.getBlockState(below).getBlock();
        return getMaterialFriction(block);
    }

    private double getMaterialFriction(net.minecraft.block.Block block) {
        double friction = DEFAULT_BLOCK_FRICTION;
        if (block == net.minecraft.init.Blocks.ICE)
            friction = 0.98;
        if (block == net.minecraft.init.Blocks.PACKED_ICE)
            friction = 0.98;
        if (block == net.minecraft.init.Blocks.SLIME_BLOCK)
            friction = 0.8;
        if (block == net.minecraft.init.Blocks.FROSTED_ICE)
            friction = 0.98;
        return friction;
    }

    private void recordState() {
        prevX = mc.player.posX;
        prevY = mc.player.posY;
        prevZ = mc.player.posZ;
        prevMotionX = mc.player.motionX;
        prevMotionY = mc.player.motionY;
        prevMotionZ = mc.player.motionZ;
        prevOnGround = mc.player.onGround;
        prevSprinting = mc.player.isSprinting();
        prevSneaking = mc.player.isSneaking();
        hasPrevState = true;
    }

    @Override
    public void onPacketInput(PacketInputEvent event) {
        if (mc.player == null)
            return;
        Packet<?> packet = event.getPacket();
        if (packet instanceof SPacketPlayerPosLook) {
            SPacketPlayerPosLook posLook = (SPacketPlayerPosLook) packet;
            double dx = posLook.getX() - mc.player.posX;
            double dy = posLook.getY() - mc.player.posY;
            double dz = posLook.getZ() - mc.player.posZ;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > 10.0 && !expectTeleport) {
                String detail = "Rubberband " + fmt(dist) + " blocks" + " (offset was " + fmt(predictionOffset) + ")" + " dx=" + fmt(Math.abs(dx)) + " dy=" + fmt(Math.abs(dy)) + " dz=" + fmt(Math.abs(dz));
                if (dist > 1.0 && !expectTeleport) {
                }
            }
        }
        if (packet instanceof SPacketEntityVelocity) {
            SPacketEntityVelocity vel = (SPacketEntityVelocity) packet;
            if (vel.getEntityID() == mc.player.getEntityId()) {
                double velX = vel.getMotionX() / 8000.0;
                double velY = vel.getMotionY() / 8000.0;
                double velZ = vel.getMotionZ() / 8000.0;
                double velMag = Math.sqrt(velX * velX + velY * velY + velZ * velZ);
                if (velMag < 0.01 && velMag >= 0) {
                    double speed = Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionY * mc.player.motionY + mc.player.motionZ * mc.player.motionZ);
                    if (speed > 0.1) {
                    }
                }
            }
        }
        if (packet instanceof SPacketBlockChange) {
            SPacketBlockChange blockChange = (SPacketBlockChange) packet;
            BlockPos blockPos = blockChange.getBlockPosition();
            if (lastBrokenBlock != null && blockPos.equals(lastBrokenBlock) && System.currentTimeMillis() - lastBrokenTime < 500) {
                String blockName = blockChange.getBlockState() != null ? blockChange.getBlockState().getBlock().getLocalizedName() : "air";
                if (!blockName.equals("air")) {
                    lastBrokenBlock = null;
                }
            }
        }
        if (packet instanceof SPacketDisconnect) {
            SPacketDisconnect disconnect = (SPacketDisconnect) packet;
            String reason = "Unknown";
            if (disconnect.getReason() != null) {
                reason = disconnect.getReason().getUnformattedText();
            }
            recordFlag(CAT_SERVER, "Kicked", "Server kicked player: " + reason, Severity.CRITICAL);
        }
        if (packet instanceof SPacketChat) {
            SPacketChat chat = (SPacketChat) packet;
            if (chat.getChatComponent() != null) {
                String msg = chat.getChatComponent().getUnformattedText().toLowerCase();
                for (String keyword : FLAG_KEYWORDS) {
                    if (msg.contains(keyword) && isLikelyAnticheatMessage(msg)) {
                        break;
                    }
                }
            }
        }
        if (packet instanceof net.minecraft.network.play.server.SPacketPlayerAbilities) {
            net.minecraft.network.play.server.SPacketPlayerAbilities abilities = (net.minecraft.network.play.server.SPacketPlayerAbilities) packet;
            if (!abilities.isFlying() && mc.player.capabilities.isFlying) {
            }
        }
        if (packet instanceof net.minecraft.network.play.server.SPacketAnimation) {
            net.minecraft.network.play.server.SPacketAnimation anim = (net.minecraft.network.play.server.SPacketAnimation) packet;
            if (anim.getAnimationType() == 1 && pendingAttackCheck && anim.getEntityID() == pendingAttackEntityId) {
                pendingAttackCheck = false;
                pendingAttackTicksLeft = 0;
            }
        }
        if (packet instanceof SPacketPlayerPosLook) {
            SPacketPlayerPosLook pl = (SPacketPlayerPosLook) packet;
            if (Math.abs(pl.getX()) > 3.0E7 || Math.abs(pl.getY()) > 3.0E7 || Math.abs(pl.getZ()) > 3.0E7 || Double.isNaN(pl.getX()) || Double.isNaN(pl.getY()) || Double.isNaN(pl.getZ())) {
            }
        }
        if (packet instanceof net.minecraft.network.play.server.SPacketDestroyEntities) {
            net.minecraft.network.play.server.SPacketDestroyEntities destroyPacket = (net.minecraft.network.play.server.SPacketDestroyEntities) packet;
            int[] entityIds = destroyPacket.getEntityIDs();
            if (pendingAttackCheck && entityIds != null) {
                for (int id : entityIds) {
                    if (id == pendingAttackEntityId) {
                        pendingAttackCheck = false;
                        pendingAttackTicksLeft = 0;
                        break;
                    }
                }
            }
        }
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        if (!nullCheck())
            return;
        Packet<?> packet = event.getPacket();
        if (packet instanceof net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock) {
            net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock placePacket = (net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock) packet;
            BlockPos clicked = placePacket.getPos();
            net.minecraft.util.EnumFacing face = placePacket.getDirection();
            int faceId = face.getIndex();
            float cursorX = placePacket.getFacingX();
            float cursorY = placePacket.getFacingY();
            float cursorZ = placePacket.getFacingZ();
            BlockPos placed = clicked.offset(face);
            lastBlockPlaced = placed;
            lastBlockPlaceTime = System.currentTimeMillis();
            lastClickedPos = clicked;
            mathFarPlace(clicked);
            mathRotationPlace(clicked);
            mathPositionPlace(clicked, faceId);
            mathAirLiquidPlace(clicked);
            mathMultiPlace(clicked, faceId, cursorX, cursorY, cursorZ);
            mathFabricatedPlace(cursorX, cursorY, cursorZ);
            mathInvalidPlaceFace(faceId);
            mathInvalidPlaceCursor(cursorX, cursorY, cursorZ);
            float deltaYaw = Math.abs(mc.player.rotationYaw - prevYaw);
            mathDuplicateRotPlace(deltaYaw);
        }
        if (packet instanceof net.minecraft.network.play.client.CPacketPlayerDigging) {
            net.minecraft.network.play.client.CPacketPlayerDigging digPacket = (net.minecraft.network.play.client.CPacketPlayerDigging) packet;
            BlockPos pos = digPacket.getPosition();
            net.minecraft.util.EnumFacing face = digPacket.getFacing();
            int faceId = face.getIndex();
            net.minecraft.network.play.client.CPacketPlayerDigging.Action mcAction = digPacket.getAction();
            int action = -1;
            if (mcAction == net.minecraft.network.play.client.CPacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                action = 0;
            } else if (mcAction == net.minecraft.network.play.client.CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK) {
                action = 1;
            } else if (mcAction == net.minecraft.network.play.client.CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK) {
                action = 2;
            }
            if (action >= 0) {
                mathFarBreak(pos, action);
                mathPositionBreakA(pos, faceId, action);
                mathInvalidBreak(faceId, action);
                mathNoSwingBreak(action);
                mathRotationBreak(pos, action);
                mathMultiBreak(pos, faceId, action);
                mathAirLiquidBreak(pos, action);
            }
        }
        if (packet instanceof net.minecraft.network.play.client.CPacketAnimation) {
            sentSwingThisTick = true;
        }
        if (packet instanceof net.minecraft.network.play.client.CPacketUseEntity) {
            net.minecraft.network.play.client.CPacketUseEntity usePacket = (net.minecraft.network.play.client.CPacketUseEntity) packet;
            int entityId = usePacket.getEntityFromWorld(mc.world) != null ? usePacket.getEntityFromWorld(mc.world).getEntityId() : -1;
            net.minecraft.entity.Entity target = usePacket.getEntityFromWorld(mc.world);
            mathSelfInteract(entityId);
            mathMultiInteractA(entityId, mc.player.isSneaking());
            if (usePacket.getAction() == net.minecraft.network.play.client.CPacketUseEntity.Action.ATTACK) {
                if (target != null) {
                    mathReach(target);
                    mathHitboxes(target);
                }
            } else if (usePacket.getAction() == net.minecraft.network.play.client.CPacketUseEntity.Action.INTERACT_AT) {
                net.minecraft.util.math.Vec3d hitVec = usePacket.getHitVec();
                if (hitVec != null && target != null) {
                    mathInvalidInteractCursor((float) hitVec.xCoord, (float) hitVec.yCoord, (float) hitVec.zCoord, target);
                    mathMultiInteractB((float) hitVec.xCoord, (float) hitVec.yCoord, (float) hitVec.zCoord);
                }
            }
        }
        if (packet instanceof net.minecraft.network.play.client.CPacketHeldItemChange) {
            net.minecraft.network.play.client.CPacketHeldItemChange heldPacket = (net.minecraft.network.play.client.CPacketHeldItemChange) packet;
            int slot = heldPacket.getSlotId();
            mathBadPacketsY(slot);
        }
        if (packet instanceof net.minecraft.network.play.client.CPacketEntityAction) {
            net.minecraft.network.play.client.CPacketEntityAction actionPacket = (net.minecraft.network.play.client.CPacketEntityAction) packet;
            net.minecraft.network.play.client.CPacketEntityAction.Action action = actionPacket.getAction();
            mathBadPacketsQ(actionPacket);
            if (action == net.minecraft.network.play.client.CPacketEntityAction.Action.START_SPRINTING) {
                onSprintStart();
            }
        }
        if (packet instanceof net.minecraft.network.play.client.CPacketSpectate) {
            mathBadPacketsK();
        }
        if (packet instanceof net.minecraft.network.play.client.CPacketPlayerDigging) {
            mathBadPacketsL((net.minecraft.network.play.client.CPacketPlayerDigging) packet);
        }
        if (packet instanceof net.minecraft.network.play.client.CPacketPlayer.PositionRotation || packet instanceof net.minecraft.network.play.client.CPacketPlayer.Position) {
            net.minecraft.network.play.client.CPacketPlayer playerPacket = (net.minecraft.network.play.client.CPacketPlayer) packet;
            double x = playerPacket.getX(0);
            double y = playerPacket.getY(0);
            double z = playerPacket.getZ(0);
            mathCrashA(x, y, z);
            if (packet instanceof net.minecraft.network.play.client.CPacketPlayer.PositionRotation) {
                float yaw = playerPacket.getYaw(mc.player.rotationYaw);
                float pitch = playerPacket.getPitch(mc.player.rotationPitch);
                mathCrashC(x, y, z, yaw, pitch);
                float deltaYaw = yaw - prevYaw;
                prevYaw = yaw;
                prevPitch = pitch;
                rotatedThisTick = true;
            } else {
                mathCrashC(x, y, z, mc.player.rotationYaw, mc.player.rotationPitch);
            }
        } else if (packet instanceof net.minecraft.network.play.client.CPacketPlayer.Rotation) {
            net.minecraft.network.play.client.CPacketPlayer playerPacket = (net.minecraft.network.play.client.CPacketPlayer) packet;
            float yaw = playerPacket.getYaw(mc.player.rotationYaw);
            float pitch = playerPacket.getPitch(mc.player.rotationPitch);
            float deltaYaw = yaw - prevYaw;
            prevYaw = yaw;
            prevPitch = pitch;
            rotatedThisTick = true;
            mathBadPacketsD(pitch);
        } else if (packet instanceof net.minecraft.network.play.client.CPacketPlayer) {
        }
    }

    private boolean isLikelyAnticheatMessage(String msg) {
        if (msg.contains("[ac]") || msg.contains("[anticheat]") || msg.contains("[grim]") || msg.contains("[matrix]") || msg.contains("[vulcan]") || msg.contains("alert:") || msg.contains("flagged") || msg.contains("violated") || msg.contains("detected") || msg.contains("ac.") || msg.contains("cheat>")) {
            return true;
        }
        int keywordCount = 0;
        for (String kw : FLAG_KEYWORDS) {
            if (msg.contains(kw))
                keywordCount++;
        }
        return keywordCount >= 2;
    }

    private void recordFlag(String category, String type, String detail, Severity severity) {
        flagCount++;
        lastFlag = type;
        lastCategory = category;
        lastFlagTime = System.currentTimeMillis();
        hudDirty = true;
        Integer catCount = categoryCounts.get(category);
        categoryCounts.put(category, catCount == null ? 1 : catCount + 1);
        FlagEntry entry = new FlagEntry(flagCount, category, type, detail, severity, System.currentTimeMillis());
        flagLog.add(0, entry);
        while (flagLog.size() > MAX_LOG) {
            flagLog.remove(flagLog.size() - 1);
        }
        batchTotalFlags++;
        String flagKey = category + "/" + type;
        Integer bCount = batchCounts.get(flagKey);
        batchCounts.put(flagKey, bCount == null ? 1 : bCount + 1);
        if (!batchTypes.contains(flagKey)) {
            batchTypes.add(flagKey);
        }
    }

    private void checkBatchFlush() {
        long now = System.currentTimeMillis();
        if (batchTotalFlags > 0 && now - lastCloudBatch >= CLOUD_BATCH_MS) {
            lastCloudBatch = now;
            sendBatchReport();
        }
    }

    private void sendBatchReport() {
        String serverIp = "unknown";
        if (mc.getCurrentServerData() != null) {
            serverIp = mc.getCurrentServerData().serverIP;
        }
        StringBuilder flagSummary = new StringBuilder();
        for (String key : batchTypes) {
            Integer count = batchCounts.get(key);
            if (count != null && count > 0) {
                if (flagSummary.length() > 0)
                    flagSummary.append(", ");
                flagSummary.append(key).append(" x").append(count);
            }
        }
        List<String> activeModules = new ArrayList<String>();
        for (client.module.Module m : client.module.ModuleManager.getModules()) {
            if (m.isToggled())
                activeModules.add(m.getName());
        }
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"flag_type\":").append(jsonStr("Batch Report")).append(",");
        json.append("\"detail\":").append(jsonStr(flagSummary.toString())).append(",");
        json.append("\"category\":").append(jsonStr("Batch")).append(",");
        json.append("\"severity\":").append(jsonStr("WARNING")).append(",");
        json.append("\"server\":").append(jsonStr(serverIp)).append(",");
        json.append("\"player_name\":").append(jsonStr(mc.player.getName())).append(",");
        json.append("\"flag_count\":").append(flagCount).append(",");
        json.append("\"batch_flags\":").append(batchTotalFlags).append(",");
        json.append("\"timestamp\":").append(System.currentTimeMillis()).append(",");
        json.append("\"prediction_offset\":").append(predictionOffset).append(",");
        json.append("\"advantage_gained\":").append(advantageGained).append(",");
        json.append("\"active_modules\":[");
        for (int i = 0; i < activeModules.size(); i++) {
            if (i > 0)
                json.append(",");
            json.append(jsonStr(activeModules.get(i)));
        }
        json.append("]");
        json.append(",\"categories\":{");
        boolean first = true;
        for (Map.Entry<String, Integer> e : categoryCounts.entrySet()) {
            if (!first)
                json.append(",");
            first = false;
            json.append(jsonStr(e.getKey())).append(":").append(e.getValue());
        }
        json.append("}");
        json.append("}");
        try {
            sendToCloud(CLOUD_URL, json.toString());
        } catch (Throwable t) {
        }
        batchCounts.clear();
        batchTypes.clear();
        batchTotalFlags = 0;
    }

    private void sendCloudReport(String category, String type, String detail, Severity severity) {
        String serverIp = "unknown";
        if (mc.getCurrentServerData() != null) {
            serverIp = mc.getCurrentServerData().serverIP;
        }
        String playerState = String.format("pos: %.1f, %.1f, %.1f | motion: %.3f, %.3f, %.3f | onGround: %b | offset: %.4f | advantage: %.4f", mc.player.posX, mc.player.posY, mc.player.posZ, mc.player.motionX, mc.player.motionY, mc.player.motionZ, mc.player.onGround, predictionOffset, advantageGained);
        List<String> activeModules = new ArrayList<String>();
        for (client.module.Module m : client.module.ModuleManager.getModules()) {
            if (m.isToggled())
                activeModules.add(m.getName());
        }
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"flag_type\":").append(jsonStr(type)).append(",");
        json.append("\"detail\":").append(jsonStr(detail)).append(",");
        json.append("\"category\":").append(jsonStr(category)).append(",");
        json.append("\"severity\":").append(jsonStr(severity.name())).append(",");
        json.append("\"server\":").append(jsonStr(serverIp)).append(",");
        json.append("\"flag_count\":").append(flagCount).append(",");
        json.append("\"timestamp\":").append(System.currentTimeMillis()).append(",");
        json.append("\"player_state\":").append(jsonStr(playerState)).append(",");
        json.append("\"prediction_offset\":").append(predictionOffset).append(",");
        json.append("\"advantage_gained\":").append(advantageGained).append(",");
        json.append("\"simulation_violations\":").append(simulationViolations).append(",");
        json.append("\"active_modules\":[");
        for (int i = 0; i < activeModules.size(); i++) {
            if (i > 0)
                json.append(",");
            json.append(jsonStr(activeModules.get(i)));
        }
        json.append("]");
        json.append(",\"categories\":{");
        boolean first = true;
        for (Map.Entry<String, Integer> e : categoryCounts.entrySet()) {
            if (!first)
                json.append(",");
            first = false;
            json.append(jsonStr(e.getKey())).append(":").append(e.getValue());
        }
        json.append("}");
        json.append("}");
        try {
            sendToCloud(CLOUD_URL, json.toString());
        } catch (Throwable t) {
        }
    }

    @JSBody(params = { "url", "json" }, script = "try{fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:json,mode:'no-cors'}).catch(function(e){});}catch(e){}")
    private static native void sendToCloud(String url, String json);

    private static String jsonStr(String s) {
        if (s == null)
            return "null";
        StringBuilder sb = new StringBuilder();
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch(c) {
                case '"':
                    sb.append("\\\"");
                    break;
                case '\\':
                    sb.append("\\\\");
                    break;
                case '\n':
                    sb.append("\\n");
                    break;
                case '\r':
                    sb.append("\\r");
                    break;
                default:
                    sb.append(c);
            }
        }
        sb.append('"');
        return sb.toString();
    }

    private final java.util.List<String> hudLines = new ArrayList<String>();

    private final java.util.List<String> hudClean = new ArrayList<String>();

    private final java.util.List<Integer> hudColors = new ArrayList<Integer>();

    private int hudMaxW = 0;

    private boolean hudDirty = true;

    private boolean hudFadeActive = false;

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (!pos.shouldRender())
            return;
        long now = System.currentTimeMillis();
        boolean fadeActive = now - lastFlagTime < 15000 && flagCount > 0;
        if (hudDirty || fadeActive != hudFadeActive) {
            hudFadeActive = fadeActive;
            hudDirty = false;
            rebuildHudLines(fadeActive);
        }
        int lineH = ClientFontRenderer.fontHeight() + 2;
        int boxW = hudMaxW + 8;
        int boxH = lineH * hudLines.size() + 6;
        pos.updateDrag(boxW, boxH);
        int x = pos.getX();
        int y = pos.getY();
        RenderUtils.prepareHUD();
        Tessellator t = Tessellator.getInstance();
        t.getWorldRenderer().begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        float bg = 0.15f;
        float bord = flagCount == 0 ? 0.2f : (flagCount > 10 ? 0.6f : 0.4f);
        addQuadVerts(t, x, y, x + boxW, y + boxH, bg, bg, 0.22f, 0.7f);
        addQuadVerts(t, x, y, x + boxW, y + 1, bord, bord, 0.15f, 0.3f);
        addQuadVerts(t, x, y + boxH - 1, x + boxW, y + boxH, bord, bord, 0.15f, 0.3f);
        addQuadVerts(t, x, y, x + 1, y + boxH, bord, bord, 0.15f, 0.3f);
        addQuadVerts(t, x + boxW - 1, y, x + boxW, y + boxH, bord, bord, 0.15f, 0.3f);
        t.draw();
        RenderUtils.restoreHUD();
        int offsetY = y + 3;
        for (int i = 0; i < hudLines.size(); i++) {
            ClientFontRenderer.drawStringWithShadow(hudClean.get(i), x + 4, offsetY, hudColors.get(i));
            offsetY += lineH;
        }
        pos.renderDragBox(x, y, boxW, boxH);
    }

    private void rebuildHudLines(boolean fadeActive) {
        hudLines.clear();
        hudClean.clear();
        hudColors.clear();
        String headerColor = flagCount == 0 ? "\u00a7a" : "\u00a7c";
        hudLines.add(headerColor + "Flags: " + flagCount);
        if (flagCount > 0) {
            hudLines.add("\u00a77" + lastCategory + "/" + lastFlag);
        }
        if (fadeActive) {
            int shown = 0;
            for (FlagEntry entry : flagLog) {
                if (shown >= 3)
                    break;
                hudLines.add("\u00a77#" + entry.id + " " + entry.type);
                shown++;
            }
        }
        hudMaxW = 0;
        for (String line : hudLines) {
            String clean = cleanFormatting(line);
            hudClean.add(clean);
            hudColors.add(parseColor(line));
            int w = ClientFontRenderer.getStringWidth(clean);
            if (w > hudMaxW)
                hudMaxW = w;
        }
    }

    private String cleanFormatting(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\u00A7' && i + 1 < s.length()) {
                i++;
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private int parseColor(String s) {
        if (s.length() >= 2 && s.charAt(0) == '\u00A7') {
            switch(s.charAt(1)) {
                case 'c':
                    return 0xFFFF5555;
                case 'e':
                    return 0xFFFFFF55;
                case 'a':
                    return 0xFF55FF55;
                case '7':
                    return 0xFFAAAAAA;
                default:
                    return 0xFFDDDDDD;
            }
        }
        return 0xFFDDDDDD;
    }

    private void addQuadVerts(Tessellator t, float x1, float y1, float x2, float y2, float r, float g, float b, float a) {
        t.getWorldRenderer().pos(x1, y2, 0).color(r, g, b, a).endVertex();
        t.getWorldRenderer().pos(x2, y2, 0).color(r, g, b, a).endVertex();
        t.getWorldRenderer().pos(x2, y1, 0).color(r, g, b, a).endVertex();
        t.getWorldRenderer().pos(x1, y1, 0).color(r, g, b, a).endVertex();
    }

    private void mathFarPlace(BlockPos pos) {
        if (!nullCheck())
            return;
        if (mc.player.isRiding())
            return;
        if (isHoldingScaffolding())
            return;
        boolean creative = mc.player.capabilities.isCreativeMode;
        double maxReach = creative ? BLOCK_REACH_CREATIVE : BLOCK_REACH_SURVIVAL;
        maxReach += Math.hypot(MOVEMENT_THRESHOLD_03, MOVEMENT_THRESHOLD_03);
        double boxMinX = pos.getX(), boxMaxX = pos.getX() + 1;
        double boxMinY = pos.getY(), boxMaxY = pos.getY() + 1;
        double boxMinZ = pos.getZ(), boxMaxZ = pos.getZ() + 1;
        double minDistSq = Double.MAX_VALUE;
        double[] eyeHeights = getPossibleEyeHeights();
        for (double eh : eyeHeights) {
            double eyeX = mc.player.posX;
            double eyeY = mc.player.posY + eh;
            double eyeZ = mc.player.posZ;
            double closestX = Math.max(boxMinX, Math.min(eyeX, boxMaxX));
            double closestY = Math.max(boxMinY, Math.min(eyeY, boxMaxY));
            double closestZ = Math.max(boxMinZ, Math.min(eyeZ, boxMaxZ));
            double dx = eyeX - closestX;
            double dy = eyeY - closestY;
            double dz = eyeZ - closestZ;
            double distSq = dx * dx + dy * dy + dz * dz;
            if (distSq < minDistSq)
                minDistSq = distSq;
        }
        if (minDistSq > maxReach * maxReach) {
            recordFlag(CAT_BLOCK, "FarPlace (math)", "Placed block at distance " + fmt(Math.sqrt(minDistSq)) + " > max " + fmt(maxReach), Severity.WARNING);
        }
    }

    private void mathRotationPlace(BlockPos pos) {
        if (!nullCheck())
            return;
        if (mc.player.isRiding())
            return;
        if (isHoldingScaffolding())
            return;
        if (didRayTraceHitBlock(pos))
            return;
        recordFlag(CAT_BLOCK, "RotationPlace (math)", "Ray trace from eye does not hit placed block", Severity.WARNING);
    }

    private void mathPositionPlace(BlockPos clickedPos, int faceId) {
        if (!nullCheck())
            return;
        if (mc.player.isRiding())
            return;
        if (isHoldingScaffolding())
            return;
        double[] eyeHeights = getPossibleEyeHeights();
        double minEyeH = Double.MAX_VALUE, maxEyeH = Double.MIN_VALUE;
        for (double h : eyeHeights) {
            minEyeH = Math.min(minEyeH, h);
            maxEyeH = Math.max(maxEyeH, h);
        }
        double mt = 0.03;
        double eyeMinY = mc.player.posY + minEyeH - mt;
        double eyeMaxY = mc.player.posY + maxEyeH + mt;
        double eyeMinX = mc.player.posX - mt;
        double eyeMaxX = mc.player.posX + mt;
        double eyeMinZ = mc.player.posZ - mt;
        double eyeMaxZ = mc.player.posZ + mt;
        double blockMinX, blockMaxX, blockMinY, blockMaxY, blockMinZ, blockMaxZ;
        if (isWeirdOrBuggyBlock(clickedPos)) {
            blockMinX = clickedPos.getX() + 1;
            blockMaxX = clickedPos.getX();
            blockMinY = clickedPos.getY() + 1;
            blockMaxY = clickedPos.getY();
            blockMinZ = clickedPos.getZ() + 1;
            blockMaxZ = clickedPos.getZ();
        } else {
            blockMinX = clickedPos.getX();
            blockMaxX = clickedPos.getX() + 1;
            blockMinY = clickedPos.getY();
            blockMaxY = clickedPos.getY() + 1;
            blockMinZ = clickedPos.getZ();
            blockMaxZ = clickedPos.getZ() + 1;
        }
        if (eyeMaxX >= blockMinX && eyeMinX <= blockMaxX && eyeMaxY >= blockMinY && eyeMinY <= blockMaxY && eyeMaxZ >= blockMinZ && eyeMinZ <= blockMaxZ) {
            return;
        }
        boolean flag = false;
        switch(faceId) {
            case 2:
                flag = eyeMinZ > blockMinZ;
                break;
            case 3:
                flag = eyeMaxZ < blockMaxZ;
                break;
            case 5:
                flag = eyeMaxX < blockMaxX;
                break;
            case 4:
                flag = eyeMinX > blockMinX;
                break;
            case 1:
                flag = eyeMaxY < blockMaxY;
                break;
            case 0:
                flag = eyeMinY > blockMinY;
                break;
        }
        if (flag) {
            recordFlag(CAT_BLOCK, "PositionPlace (math)", "Eye position on wrong side of face " + faceId, Severity.WARNING);
        }
    }

    private boolean isWeirdOrBuggyBlock(BlockPos pos) {
        if (mc.world == null)
            return false;
        net.minecraft.block.Block block = mc.world.getBlockState(pos).getBlock();
        if (block instanceof net.minecraft.block.BlockFence || block instanceof net.minecraft.block.BlockFenceGate || block instanceof net.minecraft.block.BlockWall) {
            return true;
        }
        if (block instanceof net.minecraft.block.BlockDoor || block instanceof net.minecraft.block.BlockStairs || block instanceof net.minecraft.block.BlockChest || block instanceof net.minecraft.block.BlockRedstoneWire) {
            return true;
        }
        return false;
    }

    private boolean isInstantBreak(BlockPos pos) {
        if (mc.world == null || mc.player == null)
            return false;
        net.minecraft.block.state.IBlockState state = mc.world.getBlockState(pos);
        float hardness = state.getBlockHardness(mc.world, pos);
        return hardness >= 0 && hardness <= 0.05f;
    }

    private void mathAirLiquidPlace(BlockPos clickedPos) {
        if (!nullCheck())
            return;
        if (mc.player.capabilities.isCreativeMode)
            return;
        net.minecraft.block.state.IBlockState state = mc.world.getBlockState(clickedPos);
        net.minecraft.block.Block block = state.getBlock();
        if (block == net.minecraft.init.Blocks.AIR || state.getMaterial().isLiquid()) {
            recordFlag(CAT_BLOCK, "AirLiquidPlace (math)", "Placed against " + block.getLocalizedName() + " (air/liquid)", Severity.WARNING);
        }
    }

    private void mathMultiPlace(BlockPos pos, int faceId, float cursorX, float cursorY, float cursorZ) {
        if (hasPlacedThisTick) {
            boolean faceDiff = faceId != lastPlaceFace;
            boolean cursorDiff = Math.abs(cursorX - lastPlaceCursorX) > 0.001f || Math.abs(cursorY - lastPlaceCursorY) > 0.001f || Math.abs(cursorZ - lastPlaceCursorZ) > 0.001f;
            boolean posDiff = !pos.equals(lastPlacePos);
            if (faceDiff || cursorDiff || posDiff) {
                recordFlag(CAT_BLOCK, "MultiPlace (math)", "Placed 2+ blocks in same tick with different params", Severity.WARNING);
            }
        }
        lastPlaceFace = faceId;
        lastPlaceCursorX = cursorX;
        lastPlaceCursorY = cursorY;
        lastPlaceCursorZ = cursorZ;
        lastPlacePos = pos;
        hasPlacedThisTick = true;
    }

    private void mathFabricatedPlace(float cursorX, float cursorY, float cursorZ) {
        boolean isExtended = false;
        if (mc.world != null && lastClickedPos != null) {
            net.minecraft.util.math.AxisAlignedBB box = getBlockBox(lastClickedPos);
            if (box.maxX - box.minX > 1.001 || box.maxY - box.minY > 1.001 || box.maxZ - box.minZ > 1.001) {
                isExtended = true;
            }
        }
        double maxBound = isExtended ? 1.5 : 1.0;
        double minBound = 1.0 - maxBound;
        if (cursorX < minBound - MAX_DOUBLE_ERROR || cursorY < minBound - MAX_DOUBLE_ERROR || cursorZ < minBound - MAX_DOUBLE_ERROR) {
            recordFlag(CAT_BLOCK, "FabricatedPlace (math)", String.format("Cursor below %.1f: (%.6f, %.6f, %.6f)", minBound, cursorX, cursorY, cursorZ), Severity.WARNING);
            return;
        }
        if (cursorX > maxBound + FLOAT_STEP_AT_ONE || cursorY > maxBound + FLOAT_STEP_AT_ONE || cursorZ > maxBound + FLOAT_STEP_AT_ONE) {
            recordFlag(CAT_BLOCK, "FabricatedPlace (math)", String.format("Cursor above %.1f: (%.6f, %.6f, %.6f)", maxBound, cursorX, cursorY, cursorZ), Severity.WARNING);
        }
    }

    private void mathInvalidPlaceFace(int faceId) {
        if (faceId < 0 || faceId > 5) {
            recordFlag(CAT_BLOCK, "InvalidPlaceFace (math)", "Face ID " + faceId + " is outside valid range [0,5]", Severity.CRITICAL);
        }
    }

    private void mathInvalidPlaceCursor(float cursorX, float cursorY, float cursorZ) {
        if (!Float.isFinite(cursorX) || !Float.isFinite(cursorY) || !Float.isFinite(cursorZ)) {
            recordFlag(CAT_BLOCK, "InvalidPlaceCursor (math)", "Cursor contains NaN/Infinite value", Severity.CRITICAL);
        }
    }

    private void mathDuplicateRotPlace(float deltaYaw) {
        if (!rotatedThisTick)
            return;
        if (mc.player == null)
            return;
        if (deltaYaw > 2) {
            float xDiff = Math.abs(deltaYaw - lastPlacedDeltaX);
            if (xDiff < 0.0001f) {
                recordFlag(CAT_BLOCK, "DuplicateRotPlace (math)", String.format("Duplicate yaw delta: %.4f (diff %.6f)", deltaYaw, xDiff), Severity.WARNING);
            }
        }
        lastPlacedDeltaX = deltaYaw;
        rotatedThisTick = false;
    }

    private void mathFarBreak(BlockPos pos, int action) {
        if (!nullCheck())
            return;
        if (mc.player.isRiding())
            return;
        if (action == 1)
            return;
        double minDistSq = Double.MAX_VALUE;
        double[] eyeHeights = getPossibleEyeHeights();
        double boxMinX = pos.getX(), boxMaxX = pos.getX() + 1;
        double boxMinY = pos.getY(), boxMaxY = pos.getY() + 1;
        double boxMinZ = pos.getZ(), boxMaxZ = pos.getZ() + 1;
        for (double eh : eyeHeights) {
            double eyeX = mc.player.posX;
            double eyeY = mc.player.posY + eh;
            double eyeZ = mc.player.posZ;
            double closestX = Math.max(boxMinX, Math.min(eyeX, boxMaxX));
            double closestY = Math.max(boxMinY, Math.min(eyeY, boxMaxY));
            double closestZ = Math.max(boxMinZ, Math.min(eyeZ, boxMaxZ));
            double dx = eyeX - closestX;
            double dy = eyeY - closestY;
            double dz = eyeZ - closestZ;
            double distSq = dx * dx + dy * dy + dz * dz;
            if (distSq < minDistSq)
                minDistSq = distSq;
        }
        boolean creative = mc.player.capabilities.isCreativeMode;
        double maxReach = creative ? BLOCK_REACH_CREATIVE : BLOCK_REACH_SURVIVAL;
        maxReach += Math.hypot(MOVEMENT_THRESHOLD_03, MOVEMENT_THRESHOLD_03);
        if (minDistSq > maxReach * maxReach) {
            recordFlag(CAT_BLOCK, "FarBreak (math)", "Broke block at distance " + fmt(Math.sqrt(minDistSq)) + " > max " + fmt(maxReach), Severity.WARNING);
        }
    }

    private void mathPositionBreakA(BlockPos pos, int faceId, int action) {
        if (!nullCheck())
            return;
        if (mc.player.isRiding())
            return;
        if (action == 1)
            return;
        net.minecraft.block.Block block = mc.world.getBlockState(pos).getBlock();
        if (block == net.minecraft.init.Blocks.REDSTONE_WIRE)
            return;
        double[] eyeHeights = getPossibleEyeHeights();
        double minEyeH = Double.MAX_VALUE, maxEyeH = Double.MIN_VALUE;
        for (double h : eyeHeights) {
            minEyeH = Math.min(minEyeH, h);
            maxEyeH = Math.max(maxEyeH, h);
        }
        double mt = 0;
        double eyeMinY = mc.player.posY + minEyeH - mt;
        double eyeMaxY = mc.player.posY + maxEyeH + mt;
        double eyeMinX = mc.player.posX - mt;
        double eyeMaxX = mc.player.posX + mt;
        double eyeMinZ = mc.player.posZ - mt;
        double eyeMaxZ = mc.player.posZ + mt;
        double blockMinX, blockMaxX, blockMinY, blockMaxY, blockMinZ, blockMaxZ;
        if (isWeirdOrBuggyBlock(pos)) {
            blockMinX = pos.getX() + 1;
            blockMaxX = pos.getX();
            blockMinY = pos.getY() + 1;
            blockMaxY = pos.getY();
            blockMinZ = pos.getZ() + 1;
            blockMaxZ = pos.getZ();
        } else {
            blockMinX = pos.getX();
            blockMaxX = pos.getX() + 1;
            blockMinY = pos.getY();
            blockMaxY = pos.getY() + 1;
            blockMinZ = pos.getZ();
            blockMaxZ = pos.getZ() + 1;
        }
        if (eyeMaxX >= blockMinX && eyeMinX <= blockMaxX && eyeMaxY >= blockMinY && eyeMinY <= blockMaxY && eyeMaxZ >= blockMinZ && eyeMinZ <= blockMaxZ) {
            return;
        }
        boolean flag = false;
        switch(faceId) {
            case 2:
                flag = eyeMinZ > blockMinZ;
                break;
            case 3:
                flag = eyeMaxZ < blockMaxZ;
                break;
            case 5:
                flag = eyeMaxX < blockMaxX;
                break;
            case 4:
                flag = eyeMinX > blockMinX;
                break;
            case 1:
                flag = eyeMaxY < blockMaxY;
                break;
            case 0:
                flag = eyeMinY > blockMinY;
                break;
        }
        if (flag) {
            recordFlag(CAT_BLOCK, "PositionBreakA (math)", "Eye on wrong side of break face " + faceId, Severity.WARNING);
        }
    }

    private void mathPositionBreakB(int faceId, int action) {
        if (action == 0) {
            if (faceId == lastBreakFace) {
                lastBreakFace = -1;
            }
        }
        if (lastBreakFace >= 0) {
            recordFlag(CAT_BLOCK, "PositionBreakB (math)", "Cancelled break with invalid face " + lastBreakFace, Severity.WARNING);
        }
        if (action == 1) {
            lastBreakFace = (faceId == 0 || faceId == 255) ? -1 : faceId;
        }
    }

    private void mathInvalidBreak(int faceId, int action) {
        if (faceId < 0 || faceId > 5) {
            recordFlag(CAT_BLOCK, "InvalidBreak (math)", "Break face ID " + faceId + " outside [0,5]", Severity.CRITICAL);
        }
    }

    private void mathFastBreak(BlockPos pos, int action) {
        if (!nullCheck())
            return;
        long now = System.currentTimeMillis();
        if (action == 0) {
            startBreakTime = now - (startBreakBlockPos == null ? 50 : 0);
            startBreakBlockPos = pos;
            net.minecraft.block.state.IBlockState state = mc.world.getBlockState(pos);
            float hardness = state.getBlockHardness(mc.world, pos);
            if (hardness < 0)
                hardness = 0;
            maxBlockDamage = hardness > 0 ? 1.0 / (hardness * 30) : 1.0;
            double breakDelay = now - lastFinishBreak;
            if (breakDelay >= 275) {
                blockDelayBalance *= 0.9;
            } else {
                blockDelayBalance += 300 - breakDelay;
            }
            if (blockDelayBalance > 1000) {
                recordFlag(CAT_BLOCK, "FastBreak (math)", String.format("Break delay too short: %.1fms (balance %.1f)", breakDelay, blockDelayBalance), Severity.WARNING);
            }
            double balance = Math.max(1000, 0);
            blockBreakBalance = Math.max(-balance, Math.min(balance, blockBreakBalance));
            blockDelayBalance = Math.max(-balance, Math.min(balance, blockDelayBalance));
        }
        if (action == 2 && startBreakBlockPos != null) {
            double predictedTime = Math.ceil(1.0 / Math.max(maxBlockDamage, 0.001)) * 50;
            double realTime = now - startBreakTime;
            double diff = predictedTime - realTime;
            double balance = Math.max(1000, 0);
            blockBreakBalance = Math.max(-balance, Math.min(balance, blockBreakBalance));
            if (diff < 25) {
                blockBreakBalance *= 0.9;
            } else {
                blockBreakBalance += diff;
            }
            if (blockBreakBalance > 1000) {
                recordFlag(CAT_BLOCK, "FastBreak (math)", String.format("Broke too fast: predicted %.0fms actual %.0fms (balance %.1f)", predictedTime, realTime, blockBreakBalance), Severity.WARNING);
            }
            lastFinishBreak = startBreakTime = now;
        }
    }

    private void mathNoSwingBreak(int action) {
        if (action != 1) {
            sentBreakThisTick = true;
        }
    }

    private void checkNoSwingBreak() {
        if (sentBreakThisTick && !sentSwingThisTick) {
            recordFlag(CAT_BLOCK, "NoSwingBreak (math)", "Broke block without swing animation", Severity.WARNING);
        }
        sentBreakThisTick = false;
        sentSwingThisTick = false;
    }

    private void mathRotationBreak(BlockPos pos, int action) {
        if (!nullCheck())
            return;
        if (mc.player.isRiding())
            return;
        if (action == 1)
            return;
        if (didRayTraceHitBlock(pos))
            return;
        recordFlag(CAT_BLOCK, "RotationBreak (math)", "Ray trace from eye does not hit broken block", Severity.WARNING);
    }

    private void mathWrongBreak(BlockPos pos, int action) {
        if (action == 0) {
            lastBlockWasInstantBreak = isInstantBreak(pos);
            lastCancelledBreakPos = null;
            lastStartedBreakPos = pos;
        }
        if (action == 1) {
            if (!pos.equals(lastStartedBreakPos)) {
                boolean exempt = shouldExemptWrongBreak(pos);
                if (!exempt) {
                    recordFlag(CAT_BLOCK, "WrongBreak (math)", "Cancelled digging different block than started", Severity.WARNING);
                }
            }
            lastCancelledBreakPos = pos;
            lastStartedBreakPos = null;
            return;
        }
        if (action == 2) {
            if (!pos.equals(lastCancelledBreakPos) && (!lastBlockWasInstantBreak) && !pos.equals(lastStartedBreakPos)) {
                recordFlag(CAT_BLOCK, "WrongBreak (math)", "Finished digging different block than started", Severity.WARNING);
            }
        }
    }

    private boolean shouldExemptWrongBreak(BlockPos pos) {
        if (lastStartedBreakPos == null)
            return false;
        if (pos.getY() != 4095)
            return false;
        return !isInstantBreak(pos);
    }

    private void mathMultiBreak(BlockPos pos, int faceId, int action) {
        if (action == 1)
            return;
        if (hasBrokenThisTick) {
            boolean faceDiff = faceId != lastBreakFace;
            boolean posDiff = !pos.equals(lastBreakPos);
            if (faceDiff || posDiff) {
                recordFlag(CAT_BLOCK, "MultiBreak (math)", "Broke 2+ blocks in same tick", Severity.WARNING);
            }
        }
        lastBreakFace = faceId;
        lastBreakPos = pos;
        hasBrokenThisTick = true;
    }

    private void mathAirLiquidBreak(BlockPos pos, int action) {
        if (!nullCheck())
            return;
        if (action != 0 && action != 2)
            return;
        net.minecraft.block.state.IBlockState state = mc.world.getBlockState(pos);
        net.minecraft.block.Block block = state.getBlock();
        boolean invalid = block == net.minecraft.init.Blocks.AIR || block == net.minecraft.init.Blocks.WATER || block == net.minecraft.init.Blocks.LAVA || block == net.minecraft.init.Blocks.FIRE || state.getMaterial().isLiquid();
        if (state.getBlockHardness(mc.world, pos) == -1.0f && action == 2) {
            invalid = true;
        }
        if (invalid) {
            recordFlag(CAT_BLOCK, "AirLiquidBreak (math)", "Broke invalid block: " + block.getLocalizedName(), Severity.WARNING);
        }
    }

    private void mathReach(net.minecraft.entity.Entity target) {
        if (mc.player == null || target == null)
            return;
        if (mc.player.capabilities.isCreativeMode)
            return;
        if (mc.player.isRiding())
            return;
        net.minecraft.util.math.AxisAlignedBB box = target.getEntityBoundingBox();
        if (box == null)
            return;
        double margin = HITBOX_MARGIN_18 + MOVEMENT_THRESHOLD_03;
        box = box.expand(margin, margin, margin);
        double eyeX = mc.player.posX;
        double eyeY = mc.player.posY + mc.player.getEyeHeight();
        double eyeZ = mc.player.posZ;
        double closestX = Math.max(box.minX, Math.min(eyeX, box.maxX));
        double closestY = Math.max(box.minY, Math.min(eyeY, box.maxY));
        double closestZ = Math.max(box.minZ, Math.min(eyeZ, box.maxZ));
        double dx = eyeX - closestX;
        double dy = eyeY - closestY;
        double dz = eyeZ - closestZ;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double maxReach = ENTITY_REACH_SURVIVAL + REACH_THRESHOLD;
        if (dist > maxReach) {
            recordFlag(CAT_COMBAT, "Reach (math)", String.format("Attacked from %.3f blocks > max %.3f", dist, maxReach), Severity.WARNING);
        }
    }

    private void mathHitboxes(net.minecraft.entity.Entity target) {
        if (mc.player == null || target == null)
            return;
        if (mc.player.capabilities.isCreativeMode)
            return;
        if (mc.player.isRiding())
            return;
        net.minecraft.util.math.AxisAlignedBB box = target.getEntityBoundingBox();
        if (box == null)
            return;
        double margin = HITBOX_MARGIN_18 + MOVEMENT_THRESHOLD_03;
        box = box.expand(margin, margin, margin);
        float yaw = mc.player.rotationYaw;
        float pitch = mc.player.rotationPitch;
        float rotX = (float) Math.toRadians(yaw);
        float rotY = (float) Math.toRadians(pitch);
        double xz = Math.cos(rotY);
        double lookX = -xz * Math.sin(rotX);
        double lookY = -Math.sin(rotY);
        double lookZ = xz * Math.cos(rotX);
        double eyeX = mc.player.posX;
        double eyeY = mc.player.posY + mc.player.getEyeHeight();
        double eyeZ = mc.player.posZ;
        double reach = ENTITY_REACH_SURVIVAL + 3;
        double endX = eyeX + lookX * reach;
        double endY = eyeY + lookY * reach;
        double endZ = eyeZ + lookZ * reach;
        if (!rayBoxIntersect(eyeX, eyeY, eyeZ, endX, endY, endZ, box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ)) {
            recordFlag(CAT_COMBAT, "Hitboxes (math)", "Ray trace missed entity hitbox", Severity.WARNING);
        }
    }

    private void mathSelfInteract(int entityId) {
        if (mc.player != null && entityId == mc.player.getEntityId()) {
            recordFlag(CAT_COMBAT, "SelfInteract (math)", "Player attacked self (entity " + entityId + ")", Severity.CRITICAL);
        }
    }

    private void mathInvalidInteractCursor(float vx, float vy, float vz, net.minecraft.entity.Entity target) {
        if (mc.player == null)
            return;
        if (!(target instanceof net.minecraft.entity.player.EntityPlayer))
            return;
        if (!Float.isFinite(vx) || !Float.isFinite(vy) || !Float.isFinite(vz)) {
            recordFlag(CAT_COMBAT, "InvalidInteractCursor (math)", String.format("Non-finite vector: (%.5f, %.5f, %.5f)", vx, vy, vz), Severity.WARNING);
            return;
        }
        double expansion = 0;
        double maxHorizontal = 0.3001 + expansion;
        double minVertical = -0.0001 - expansion;
        double maxVertical = 1.8001 + expansion;
        if (vy > minVertical && vy < maxVertical && Math.abs(vx) < maxHorizontal && Math.abs(vz) < maxHorizontal) {
            return;
        }
        recordFlag(CAT_COMBAT, "InvalidInteractCursor (math)", String.format("Vector outside hitbox: (%.5f, %.5f, %.5f)", vx, vy, vz), Severity.WARNING);
    }

    private void mathMultiInteractA(int entityId, boolean sneaking) {
        if (hasInteractedThisTick && (entityId != lastInteractEntityId || sneaking != lastInteractSneaking)) {
            recordFlag(CAT_COMBAT, "MultiInteractA (math)", "Interacted with multiple entities in same tick", Severity.WARNING);
        }
        lastInteractEntityId = entityId;
        lastInteractSneaking = sneaking;
        hasInteractedThisTick = true;
    }

    private void mathMultiInteractB(float vx, float vy, float vz) {
        if (hasInteractAtThisTick) {
            boolean diff = Math.abs(vx - lastInteractAtX) > 0.001f || Math.abs(vy - lastInteractAtY) > 0.001f || Math.abs(vz - lastInteractAtZ) > 0.001f;
            if (diff) {
                recordFlag(CAT_COMBAT, "MultiInteractB (math)", "Multiple INTERACT_AT with different positions in same tick", Severity.WARNING);
            }
        }
        lastInteractAtX = vx;
        lastInteractAtY = vy;
        lastInteractAtZ = vz;
        hasInteractAtThisTick = true;
    }

    private void mathBadPacketsA(int slot) {
        if (slot == lastHeldSlot && lastHeldSlot != -1) {
            recordFlag(CAT_PACKET, "BadPacketsA (math)", "Duplicate slot change: " + slot, Severity.INFO);
        }
        lastHeldSlot = slot;
    }

    private void mathBadPacketsD(float pitch) {
        if (pitch > 90 || pitch < -90) {
            recordFlag(CAT_PACKET, "BadPacketsD (math)", String.format("Invalid pitch: %.2f", pitch), Severity.CRITICAL);
        }
    }

    private void mathBadPacketsE(boolean isPositionPacket, boolean isFlyingPacket, boolean isSteerVehicle) {
        if (isPositionPacket) {
            noReminderTicks = 0;
            lastPacketWasTeleport = false;
        } else if (isFlyingPacket) {
            if (!lastPacketWasTeleport) {
                if (++noReminderTicks > MAX_NO_REMINDER_TICKS) {
                    recordFlag(CAT_PACKET, "BadPacketsE (math)", "Too many rotation-only packets: " + noReminderTicks, Severity.WARNING);
                }
            }
            lastPacketWasTeleport = false;
        } else if (isSteerVehicle) {
            noReminderTicks = 0;
        }
    }

    private void mathBadPacketsF(net.minecraft.network.play.client.CPacketEntityAction.Action action) {
        if (action == net.minecraft.network.play.client.CPacketEntityAction.Action.START_SPRINTING) {
            if (lastSprinting) {
                consecutiveSprintDuplicates++;
                if (consecutiveSprintDuplicates >= 3) {
                    recordFlag(CAT_PACKET, "BadPacketsF (math)", "3+ duplicate START_SPRINTING (already sprinting)", Severity.INFO);
                }
            } else {
                consecutiveSprintDuplicates = 0;
            }
            lastSprinting = true;
        } else if (action == net.minecraft.network.play.client.CPacketEntityAction.Action.STOP_SPRINTING) {
            if (!lastSprinting) {
                consecutiveSprintDuplicates++;
                if (consecutiveSprintDuplicates >= 3) {
                    recordFlag(CAT_PACKET, "BadPacketsF (math)", "3+ duplicate STOP_SPRINTING (not sprinting)", Severity.INFO);
                }
            } else {
                consecutiveSprintDuplicates = 0;
            }
            lastSprinting = false;
        }
    }

    private void mathBadPacketsG(net.minecraft.network.play.client.CPacketEntityAction.Action action) {
        if (action == net.minecraft.network.play.client.CPacketEntityAction.Action.START_SNEAKING) {
            if (lastSneaking && !sneakRespawn) {
                consecutiveSneakDuplicates++;
                if (consecutiveSneakDuplicates >= 3) {
                    recordFlag(CAT_PACKET, "BadPacketsG (math)", "3+ duplicate START_SNEAKING (already sneaking)", Severity.INFO);
                }
            } else {
                consecutiveSneakDuplicates = 0;
                lastSneaking = true;
            }
            sneakRespawn = false;
        } else if (action == net.minecraft.network.play.client.CPacketEntityAction.Action.STOP_SNEAKING) {
            if (!lastSneaking && !sneakRespawn) {
                consecutiveSneakDuplicates++;
                if (consecutiveSneakDuplicates >= 3) {
                    recordFlag(CAT_PACKET, "BadPacketsG (math)", "3+ duplicate STOP_SNEAKING (not sneaking)", Severity.INFO);
                }
            } else {
                consecutiveSneakDuplicates = 0;
                lastSneaking = false;
            }
            sneakRespawn = false;
        }
    }

    private void mathBadPacketsK() {
        if (mc.player == null)
            return;
        if (!mc.player.isSpectator()) {
            recordFlag(CAT_PACKET, "BadPacketsK (math)", "Sent spectate packet while not in spectator mode", Severity.WARNING);
        }
    }

    private void mathBadPacketsL(net.minecraft.network.play.client.CPacketPlayerDigging digPacket) {
        net.minecraft.network.play.client.CPacketPlayerDigging.Action action = digPacket.getAction();
        if (action == net.minecraft.network.play.client.CPacketPlayerDigging.Action.START_DESTROY_BLOCK || action == net.minecraft.network.play.client.CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK || action == net.minecraft.network.play.client.CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK) {
            return;
        }
        boolean allowLegacyFace = (action == net.minecraft.network.play.client.CPacketPlayerDigging.Action.RELEASE_USE_ITEM);
        int faceId = digPacket.getFacing().getIndex();
        boolean validFace = (faceId == 0) || (allowLegacyFace && faceId == 255);
        BlockPos pos = digPacket.getPosition();
        boolean validPos = (pos.getX() == 0 && pos.getY() == 0 && pos.getZ() == 0);
        if (!validFace || !validPos) {
            recordFlag(CAT_PACKET, "BadPacketsL (math)", "Invalid dig packet: action=" + action + " face=" + faceId + " pos=" + pos.getX() + "," + pos.getY() + "," + pos.getZ(), Severity.WARNING);
        }
    }

    private void mathBadPacketsQ(net.minecraft.network.play.client.CPacketEntityAction packet) {
        if (mc.player == null)
            return;
        int boost = packet.getAuxData();
        net.minecraft.network.play.client.CPacketEntityAction.Action action = packet.getAction();
        boolean invalid = Math.abs(boost) > 100 || (action != net.minecraft.network.play.client.CPacketEntityAction.Action.START_RIDING_JUMP && boost != 0);
        if (invalid) {
            recordFlag(CAT_PACKET, "BadPacketsQ (math)", "Invalid horse jump: boost=" + boost + " action=" + action, Severity.WARNING);
        }
    }

    private void mathBadPacketsS(net.minecraft.network.play.client.CPacketConfirmTransaction packet) {
    }

    private void mathBadPacketsY(int slot) {
        if (slot > 8 || slot < 0) {
            recordFlag(CAT_PACKET, "BadPacketsY (math)", "Out of bounds slot: " + slot, Severity.CRITICAL);
        }
    }

    private void mathCrashA(double x, double y, double z) {
        double BORDER = 2.9999999E7;
        if (Math.abs(x) > BORDER || Math.abs(z) > BORDER || Math.abs(y) > Integer.MAX_VALUE) {
            recordFlag(CAT_SERVER, "CrashA (math)", String.format("Position out of bounds: (%.1f, %.1f, %.1f)", x, y, z), Severity.CRITICAL);
        }
    }

    private void mathCrashC(double x, double y, double z, float yaw, float pitch) {
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z) || !Float.isFinite(yaw) || !Float.isFinite(pitch)) {
            recordFlag(CAT_SERVER, "CrashC (math)", String.format("Non-finite position/rotation: (%.1f, %.1f, %.1f, %.1f, %.1f)", x, y, z, yaw, pitch), Severity.CRITICAL);
        }
    }

    private void mathAimModulo360(float yaw, float deltaYaw) {
        if (yaw < 360 && yaw > -360 && Math.abs(deltaYaw) > 320 && Math.abs(lastDeltaYaw) < 30) {
            recordFlag(CAT_COMBAT, "AimModulo360 (math)", String.format("Yaw snap: deltaYaw=%.1f lastDeltaYaw=%.1f", deltaYaw, lastDeltaYaw), Severity.WARNING);
        }
        lastDeltaYaw = deltaYaw;
    }

    private void mathAimDuplicateLook(float yaw, float pitch, boolean isLookOnly) {
        if (!hasPrevRotation) {
            prevYaw = yaw;
            prevPitch = pitch;
            hasPrevRotation = true;
            consecutiveDuplicateLookCount = 0;
            return;
        }
        if (aimDuplicateExempt) {
            aimDuplicateExempt = false;
            consecutiveDuplicateLookCount = 0;
            prevYaw = yaw;
            prevPitch = pitch;
            return;
        }
        if (isLookOnly && yaw == prevYaw && pitch == prevPitch) {
            consecutiveDuplicateLookCount++;
            if (consecutiveDuplicateLookCount == 20) {
                recordFlag(CAT_COMBAT, "AimDuplicateLook (math)", String.format("20+ consecutive duplicate look-only packets: yaw=%.2f pitch=%.2f", yaw, pitch), Severity.INFO);
            }
        } else {
            consecutiveDuplicateLookCount = 0;
        }
        prevYaw = yaw;
        prevPitch = pitch;
    }

    private void mathSprintA() {
        if (mc.player == null)
            return;
        if (mc.player.capabilities.isFlying)
            return;
        if (mc.player.getFoodStats().getFoodLevel() <= 6) {
            if (mc.player.isSprinting()) {
                recordFlag(CAT_MOVEMENT, "SprintA (math)", "Sprinting with hunger " + mc.player.getFoodStats().getFoodLevel(), Severity.WARNING);
            }
        }
    }

    private void mathSprintB() {
        if (mc.player == null)
            return;
        if (mc.player.isSneaking() && mc.player.isSprinting()) {
            recordFlag(CAT_MOVEMENT, "SprintB (math)", "Sprinting while sneaking", Severity.WARNING);
        }
    }

    private void mathSprintC() {
        if (mc.player == null)
            return;
        if (mc.player.isHandActive()) {
            if (!mc.player.isInWater()) {
                if (mc.player.isSprinting()) {
                    if (sprintCFlaggedLastTick) {
                        recordFlag(CAT_MOVEMENT, "SprintC (math)", "Sprinting while using item", Severity.WARNING);
                    }
                    sprintCFlaggedLastTick = true;
                } else {
                    sprintCFlaggedLastTick = false;
                }
            }
        }
    }

    private void mathSprintD() {
        if (mc.player == null)
            return;
        boolean hasBlindness = mc.player.isPotionActive(net.minecraft.init.MobEffects.BLINDNESS);
        if (hasBlindness && !sprintDStartedBeforeBlind) {
            if (mc.player.isSprinting()) {
                recordFlag(CAT_MOVEMENT, "SprintD (math)", "Sprinting with blindness", Severity.WARNING);
            }
        }
    }

    private void mathSprintE() {
        if (mc.player == null)
            return;
        if (sprintEWasHardCollision && !sprintEStartedThisTick && !mc.player.isRiding()) {
            if (mc.player.isSprinting()) {
                recordFlag(CAT_MOVEMENT, "SprintE (math)", "Sprinting while colliding with wall", Severity.WARNING);
            }
        }
        sprintEWasHardCollision = mc.player.isCollidedHorizontally;
        sprintEStartedThisTick = false;
    }

    private void mathSprintG() {
        if (mc.player == null)
            return;
        if (mc.player.isInWater() && mc.player.isSprinting()) {
            recordFlag(CAT_MOVEMENT, "SprintG (math)", "Sprinting while in water", Severity.WARNING);
        }
    }

    private void onSprintStart() {
        sprintDStartedBeforeBlind = false;
        sprintEStartedThisTick = true;
    }

    private static final double[] EYE_HEIGHTS_NORMAL = { 1.62, 1.54, 0.4 };

    private static final double[] EYE_HEIGHTS_SNEAKING = { 1.54, 1.62, 0.4 };

    private double[] getPossibleEyeHeights() {
        if (mc.player != null && mc.player.isSneaking()) {
            return EYE_HEIGHTS_SNEAKING;
        }
        return EYE_HEIGHTS_NORMAL;
    }

    private boolean isHoldingScaffolding() {
        if (mc.player == null)
            return false;
        net.minecraft.item.ItemStack mainHand = mc.player.getHeldItemMainhand();
        net.minecraft.item.ItemStack offHand = mc.player.getHeldItemOffhand();
        return false;
    }

    private net.minecraft.util.math.AxisAlignedBB getBlockBox(BlockPos pos) {
        if (mc.world == null) {
            return new net.minecraft.util.math.AxisAlignedBB(pos);
        }
        net.minecraft.block.state.IBlockState state = mc.world.getBlockState(pos);
        try {
            return state.getSelectedBoundingBox(mc.world, pos);
        } catch (Exception e) {
            return new net.minecraft.util.math.AxisAlignedBB(pos);
        }
    }

    private boolean didRayTraceHitBlock(BlockPos pos) {
        if (mc.player == null || mc.world == null)
            return true;
        double boxMinX = pos.getX(), boxMaxX = pos.getX() + 1;
        double boxMinY = pos.getY(), boxMaxY = pos.getY() + 1;
        double boxMinZ = pos.getZ(), boxMaxZ = pos.getZ() + 1;
        double mt = 0.03;
        double[] eyeHeights = getPossibleEyeHeights();
        double minEyeH = Double.MAX_VALUE, maxEyeH = Double.MIN_VALUE;
        for (double h : eyeHeights) {
            minEyeH = Math.min(minEyeH, h);
            maxEyeH = Math.max(maxEyeH, h);
        }
        double eyeMinY2 = mc.player.posY + minEyeH - mt;
        double eyeMaxY2 = mc.player.posY + maxEyeH + mt;
        double eyeMinX2 = mc.player.posX - mt;
        double eyeMaxX2 = mc.player.posX + mt;
        double eyeMinZ2 = mc.player.posZ - mt;
        double eyeMaxZ2 = mc.player.posZ + mt;
        if (eyeMaxX2 > boxMinX && eyeMinX2 < boxMaxX && eyeMaxY2 > boxMinY && eyeMinY2 < boxMaxY && eyeMaxZ2 > boxMinZ && eyeMinZ2 < boxMaxZ) {
            return true;
        }
        float yaw = mc.player.rotationYaw;
        float pitch = mc.player.rotationPitch;
        float lastYaw = prevYaw;
        float lastPitch = prevPitch;
        float[][] lookDirs = { { yaw, pitch }, { lastYaw, pitch }, { lastYaw, lastPitch } };
        double distance = BLOCK_REACH_SURVIVAL;
        for (double eh : eyeHeights) {
            double ex = mc.player.posX;
            double ey = mc.player.posY + eh;
            double ez = mc.player.posZ;
            for (float[] dir : lookDirs) {
                float ly = dir[0], lp = dir[1];
                float rotX = (float) Math.toRadians(ly);
                float rotY = (float) Math.toRadians(lp);
                double xz = Math.cos(rotY);
                double lookX = -xz * Math.sin(rotX);
                double lookY = -Math.sin(rotY);
                double lookZ = xz * Math.cos(rotX);
                double endX = ex + lookX * distance;
                double endY = ey + lookY * distance;
                double endZ = ez + lookZ * distance;
                if (rayBoxIntersect(ex, ey, ez, endX, endY, endZ, boxMinX, boxMinY, boxMinZ, boxMaxX, boxMaxY, boxMaxZ)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean rayBoxIntersect(double x1, double y1, double z1, double x2, double y2, double z2, double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
        double dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
        double tmin = 0, tmax = 1;
        if (Math.abs(dx) < 1e-12) {
            if (x1 < minX || x1 > maxX)
                return false;
        } else {
            double t1 = (minX - x1) / dx;
            double t2 = (maxX - x1) / dx;
            if (t1 > t2) {
                double tmp = t1;
                t1 = t2;
                t2 = tmp;
            }
            tmin = Math.max(tmin, t1);
            tmax = Math.min(tmax, t2);
            if (tmin > tmax)
                return false;
        }
        if (Math.abs(dy) < 1e-12) {
            if (y1 < minY || y1 > maxY)
                return false;
        } else {
            double t1 = (minY - y1) / dy;
            double t2 = (maxY - y1) / dy;
            if (t1 > t2) {
                double tmp = t1;
                t1 = t2;
                t2 = tmp;
            }
            tmin = Math.max(tmin, t1);
            tmax = Math.min(tmax, t2);
            if (tmin > tmax)
                return false;
        }
        if (Math.abs(dz) < 1e-12) {
            if (z1 < minZ || z1 > maxZ)
                return false;
        } else {
            double t1 = (minZ - z1) / dz;
            double t2 = (maxZ - z1) / dz;
            if (t1 > t2) {
                double tmp = t1;
                t1 = t2;
                t2 = tmp;
            }
            tmin = Math.max(tmin, t1);
            tmax = Math.min(tmax, t2);
            if (tmin > tmax)
                return false;
        }
        return true;
    }

    private static String fmt(double d) {
        return String.format("%.4f", d);
    }

    public static void onBlockPlace(BlockPos placedPos, BlockPos clickedPos, int faceId, float cursorX, float cursorY, float cursorZ) {
        if (instance != null) {
            instance.lastBlockPlaced = placedPos;
            instance.lastBlockPlaceTime = System.currentTimeMillis();
            instance.lastClickedPos = clickedPos;
            instance.mathFarPlace(clickedPos);
            instance.mathRotationPlace(clickedPos);
            instance.mathPositionPlace(clickedPos, faceId);
            instance.mathAirLiquidPlace(clickedPos);
            instance.mathMultiPlace(clickedPos, faceId, cursorX, cursorY, cursorZ);
            instance.mathFabricatedPlace(cursorX, cursorY, cursorZ);
            instance.mathInvalidPlaceFace(faceId);
            instance.mathInvalidPlaceCursor(cursorX, cursorY, cursorZ);
            float deltaYaw = Math.abs(instance.mc.player.rotationYaw - instance.prevYaw);
        }
    }

    public static void onRotation(float yaw, float pitch) {
        if (instance != null) {
            instance.prevYaw = yaw;
            instance.prevPitch = pitch;
            instance.rotatedThisTick = true;
        }
    }

    public static void expectTeleport() {
        if (instance != null) {
            instance.expectTeleport = true;
            instance.expectTeleportUntil = System.currentTimeMillis() + 2000;
        }
    }

    private enum Severity {

        CRITICAL, WARNING, INFO
    }

    private static class FlagEntry {

        final int id;

        final String category;

        final String type;

        final String detail;

        final Severity severity;

        final long timestamp;

        FlagEntry(int id, String category, String type, String detail, Severity severity, long timestamp) {
            this.id = id;
            this.category = category;
            this.type = type;
            this.detail = detail;
            this.severity = severity;
            this.timestamp = timestamp;
        }
    }
}
