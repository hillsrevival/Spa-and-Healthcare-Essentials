package client.module.impl.other;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.tuff.Y0NetworkHandler;
import net.minecraft.client.Minecraft;

public class UnderY0 extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public UnderY0() {
        super("UnderY0", Category.OTHER);
        setDescription("See blocks below y0 (requires TuffX+ server)");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        Y0NetworkHandler.reset();
        Y0NetworkHandler.sendHandshake();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        Y0NetworkHandler.reset();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) {
            Y0NetworkHandler.reset();
            return;
        }
        if (!Y0NetworkHandler.isY0Active()) {
            Y0NetworkHandler.sendHandshake();
        }
    }
}
