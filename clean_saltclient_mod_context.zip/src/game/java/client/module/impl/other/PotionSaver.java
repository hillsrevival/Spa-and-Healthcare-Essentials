package client.module.impl.other;

import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.CPacketPlayer;
import client.event.events.PacketOutputEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;

public class PotionSaver extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting requirePotions = new BooleanSetting("Require Potions", true);

    public PotionSaver() {
        super("PotionSaver", Category.OTHER);
        setDescription("Pauses potion timers when standing still");
        addSetting(requirePotions);
        handles(HandlerType.PACKET_OUTPUT);
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        if (mc.player == null)
            return;
        if (mc.world == null)
            return;
        Object packet = event.getPacket();
        if (!(packet instanceof CPacketPlayer))
            return;
        if (requirePotions.getValue()) {
            if (mc.player.getActivePotionEffects().isEmpty())
                return;
        }
        if (isMoving())
            return;
        event.setCancelled(true);
    }

    private boolean isMoving() {
        if (mc.gameSettings == null)
            return false;
        if (mc.gameSettings.keyBindForward.isKeyDown())
            return true;
        if (mc.gameSettings.keyBindBack.isKeyDown())
            return true;
        if (mc.gameSettings.keyBindLeft.isKeyDown())
            return true;
        if (mc.gameSettings.keyBindRight.isKeyDown())
            return true;
        if (mc.gameSettings.keyBindJump.isKeyDown())
            return true;
        if (mc.gameSettings.keyBindSneak.isKeyDown())
            return true;
        if (mc.gameSettings.keyBindSprint.isKeyDown())
            return true;
        return false;
    }
}
