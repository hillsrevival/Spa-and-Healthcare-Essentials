package client.module.impl.other;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGameOver;

public class AutoRespawn extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private int delay = 0;

    public AutoRespawn() {
        super("AutoRespawn", Category.OTHER);
        setDescription("Automatically respawns after dying");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.currentScreen == null)
            return;
        if (mc.player.getHealth() > 0.0F) {
            delay = 0;
            return;
        }
        if (mc.currentScreen instanceof GuiGameOver) {
            if (delay < 20) {
                delay++;
                return;
            }
            mc.player.respawnPlayer();
            mc.displayGuiScreen(null);
            delay = 0;
        }
    }
}
