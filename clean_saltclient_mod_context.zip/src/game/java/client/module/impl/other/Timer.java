package client.module.impl.other;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import client.utils.misc.TimerUtils;

public class Timer extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting speed = new NumberSetting("Speed", 2.0, 0.1, 10.0);

    private final BooleanSetting randomVariation = new BooleanSetting("Random", false);

    public Timer() {
        super("Timer", Category.OTHER);
        setDescription("Speeds up or slows down the game tick rate");
        addSetting(speed);
        addSetting(randomVariation);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.timer == null)
            return;
        float base = speed.getValue().floatValue();
        if (randomVariation.getValue()) {
            float variation = (float) (Math.random() * 0.02 - 0.01);
            TimerUtils.setTimerSpeed(base + variation);
        } else {
            TimerUtils.setTimerSpeed(base);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.timer != null) {
            TimerUtils.setTimerSpeed(1.0f);
        }
    }
}
