package client.module.impl.other;

import client.event.events.PacketOutputEvent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.client.Minecraft;
import client.utils.world.WorldUtils;

public class AirPlace extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public AirPlace() {
        super("AirPlace", Category.OTHER);
        setDescription("Allows placing blocks in the air");
        handles(HandlerType.PACKET_OUTPUT);
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        if (!nullCheck())
            return;
        Object pkt = event.getPacket();
        if (!(pkt instanceof CPacketPlayerTryUseItemOnBlock))
            return;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held == null || held.func_190926_b())
            return;
        if (!(held.getItem() instanceof ItemBlock))
            return;
        CPacketPlayerTryUseItemOnBlock packet = (CPacketPlayerTryUseItemOnBlock) pkt;
        BlockPos placedOn = packet.getPos();
        if (WorldUtils.isAir(placedOn)) {
            RayTraceResult solidHit = findNearestSolidInLook();
            if (solidHit != null && solidHit.typeOfHit == RayTraceResult.Type.BLOCK) {
                event.setPacket(new CPacketPlayerTryUseItemOnBlock(solidHit.getBlockPos(), solidHit.sideHit, packet.getHand(), packet.getFacingX(), packet.getFacingY(), packet.getFacingZ()));
            }
        }
    }

    private RayTraceResult findNearestSolidInLook() {
        float pitch = mc.player.rotationPitch;
        float yaw = mc.player.rotationYaw;
        double eyeY = mc.player.posY + mc.player.getEyeHeight();
        float f1 = MathHelper.cos(-yaw * 0.017453292F - 3.1415927F);
        float f2 = MathHelper.sin(-yaw * 0.017453292F - 3.1415927F);
        float f3 = -MathHelper.cos(-pitch * 0.017453292F);
        float f4 = MathHelper.sin(-pitch * 0.017453292F);
        double lookX = f2 * f3;
        double lookY = f4;
        double lookZ = f1 * f3;
        double reach = 5.0;
        double step = 0.1;
        double prevX = mc.player.posX;
        double prevY = eyeY;
        double prevZ = mc.player.posZ;
        for (double d = 0; d < reach; d += step) {
            double x = mc.player.posX + lookX * d;
            double y = eyeY + lookY * d;
            double z = mc.player.posZ + lookZ * d;
            BlockPos bp = new BlockPos(x, y, z);
            if (!WorldUtils.isAir(bp)) {
                BlockPos prevBP = new BlockPos(prevX, prevY, prevZ);
                EnumFacing face = getFaceFromPositions(prevBP, bp);
                return new RayTraceResult(new Vec3d(prevX, prevY, prevZ), face, bp);
            }
            prevX = x;
            prevY = y;
            prevZ = z;
        }
        return null;
    }

    private EnumFacing getFaceFromPositions(BlockPos from, BlockPos to) {
        int dx = to.getX() - from.getX();
        int dy = to.getY() - from.getY();
        int dz = to.getZ() - from.getZ();
        if (dy > 0)
            return EnumFacing.DOWN;
        if (dy < 0)
            return EnumFacing.UP;
        if (dz > 0)
            return EnumFacing.NORTH;
        if (dz < 0)
            return EnumFacing.SOUTH;
        if (dx > 0)
            return EnumFacing.WEST;
        if (dx < 0)
            return EnumFacing.EAST;
        return EnumFacing.UP;
    }
}
