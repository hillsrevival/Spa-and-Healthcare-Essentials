package client.module.impl.other;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.network.play.client.CPacketPlayer;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;

public class Teleport extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting xCoord = new NumberSetting("X", 0.0, -30000.0, 30000.0);

    private final NumberSetting yCoord = new NumberSetting("Y", 64.0, 0.0, 256.0);

    private final NumberSetting zCoord = new NumberSetting("Z", 0.0, -30000.0, 30000.0);

    private final BooleanSetting teleport = new BooleanSetting("Teleport", false);

    public Teleport() {
        super("Teleport", Category.OTHER);
        addSetting(xCoord);
        addSetting(yCoord);
        addSetting(zCoord);
        addSetting(teleport);
        handles(HandlerType.TICK);
        setDescription("Instantly move to coordinates");
    }

    @Override
    public void onTick() {
        if (!nullCheck())
            return;
        if (!teleport.getValue())
            return;
        double x = xCoord.getValue();
        double y = yCoord.getValue();
        double z = zCoord.getValue();
        mc.player.setPosition(x, y, z);
        mc.player.connection.sendPacket(new CPacketPlayer.Position(x, y, z, mc.player.onGround));
        if (mc.renderGlobal != null) {
            mc.renderGlobal.loadRenderers();
        }
        teleport.setValue(false);
    }
}
