package client.module.impl.other;

import org.teavm.jso.JSBody;
import org.teavm.jso.JSObject;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;

public class ScreenRecording extends Module {

    private final BooleanSetting includeMic = new BooleanSetting("IncludeMic", false);

    private final BooleanSetting includeAudio = new BooleanSetting("IncludeAudio", true);

    private boolean recording = false;

    public ScreenRecording() {
        super("ScreenRecording", Category.OTHER);
        setDescription("Starts recording ur screen once u turn it on and ends video when you turn it off");
        addSetting(includeMic);
        addSetting(includeAudio);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (recording)
            return;
        JSObject audioStream = null;
        if (includeAudio.getValue()) {
            try {
                audioStream = net.lax1dude.eaglercraft.internal.PlatformAudio.initGameRecordingStream();
            } catch (Throwable t) {
                audioStream = null;
            }
        }
        if (includeMic.getValue()) {
            requestMicLaterJS();
        }
        boolean started = startRecordingJS(audioStream);
        if (!started) {
            endAudioTap();
            recording = false;
            setToggled(false);
            client.utils.misc.NotificationSystem.error("ScreenRecording: canvas capture is not supported here");
            return;
        }
        recording = true;
        client.utils.misc.NotificationSystem.success("ScreenRecording started");
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (!recording)
            return;
        recording = false;
        stopRecordingJS();
        endAudioTap();
        client.utils.misc.NotificationSystem.info("ScreenRecording stopped — saving video...");
    }

    @Override
    public void onUpdate() {
        if (recording && !isRecordingActiveJS()) {
            recording = false;
            endAudioTap();
            setToggled(false);
            client.utils.misc.NotificationSystem.warning("ScreenRecording stopped unexpectedly — saving what was recorded");
        }
    }

    private void endAudioTap() {
        try {
            net.lax1dude.eaglercraft.internal.PlatformAudio.endGameRecordingStream();
        } catch (Throwable t) {
        }
    }

    @JSBody(params = { "audioStream" }, script = "" + "try {" + "  if (window.__galacticRec) return false;" + "  var root = document.querySelector('._eaglercraftX_root_element') || document;" + "  var canvas = root.querySelector('._eaglercraftX_canvas_element');" + "  if (!canvas || !canvas.captureStream) return false;" + "  if (typeof MediaRecorder === 'undefined') return false;" + "  var stream = canvas.captureStream(30);" + "  if (audioStream && audioStream.getAudioTracks) {" + "    var at = audioStream.getAudioTracks();" + "    for (var i = 0; i < at.length; i++) stream.addTrack(at[i]);" + "  }" + "  var mime = '';" + "  var candidates = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm;codecs=h264,opus', 'video/webm'];" + "  for (var k = 0; k < candidates.length; k++) {" + "    try {" + "      if (MediaRecorder.isTypeSupported(candidates[k])) { mime = candidates[k]; break; }" + "    } catch (e) { }" + "  }" + "  var opts = mime ? { mimeType: mime, videoBitsPerSecond: 8000000 } : { videoBitsPerSecond: 8000000 };" + "  var rec = new MediaRecorder(stream, opts);" + "  var chunks = [];" + "  var startTime = performance.now();" + "  rec.ondataavailable = function(e) { if (e.data && e.data.size > 0) chunks.push(e.data); };" + "  rec.onstop = function() {" + "    var state = window.__galacticRec;" + "    window.__galacticRec = null;" + "    if (state && state.mic) { try { state.mic.getTracks().forEach(function(t) { t.stop(); }); } catch (e) { } }" + "    if (chunks.length === 0) return;" + "    var blob = new Blob(chunks, { type: chunks[0].type || 'video/webm' });" + "    chunks = [];" + "    var durationMs = performance.now() - startTime;" + "    var save = function(finalBlob) {" + "      var url = URL.createObjectURL(finalBlob);" + "      var d = new Date();" + "      var pad = function(n) { return (n < 10 ? '0' : '') + n; };" + "      var ds = d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate())" + "           + ' ' + pad(d.getHours()) + '-' + pad(d.getMinutes()) + '-' + pad(d.getSeconds());" + "      var a = document.createElement('a');" + "      a.href = url;" + "      a.download = 'Galactic_Recording_' + ds + '.webm';" + "      a.style.position = 'absolute';" + "      a.style.left = '0px';" + "      a.style.top = '0px';" + "      a.style.zIndex = '-100';" + "      a.style.color = 'transparent';" + "      document.body.appendChild(a);" + "      setTimeout(function() {" + "        a.click();" + "        setTimeout(function() { document.body.removeChild(a); }, 50);" + "        setTimeout(function() { URL.revokeObjectURL(url); }, 60000);" + "      }, 50);" + "    };" + "    if (window.__galacticRecHelpers && window.__galacticRecHelpers.fixWebM) {" + "      try {" + "        window.__galacticRecHelpers.fixWebM(blob, durationMs, function(fixed) { save(fixed); });" + "        return;" + "      } catch (e) { }" + "    }" + "    save(blob);" + "  };" + "  rec.onerror = function() {" + "    if (rec.state !== 'inactive') rec.stop();" + "  };" + "  rec.start(1000);" + "  window.__galacticRec = { rec: rec, mic: null };" + "  return true;" + "} catch (e) {" + "  window.__galacticRec = null;" + "  return false;" + "}")
    private static native boolean startRecordingJS(JSObject audioStream);

    @JSBody(script = "" + "if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {" + "  navigator.mediaDevices.getUserMedia({ audio: true, video: false }).then(function(s) {" + "    if (window.__galacticRec && window.__galacticRec.rec" + "        && window.__galacticRec.rec.state === 'recording') {" + "      window.__galacticRec.mic = s;" + "      var stream = window.__galacticRec.rec.stream;" + "      var t = s.getAudioTracks();" + "      for (var i = 0; i < t.length; i++) stream.addTrack(t[i]);" + "    } else {" + "      try { s.getTracks().forEach(function(t) { t.stop(); }); } catch (e) { }" + "    }" + "  }).catch(function(e) { });" + "}")
    private static native void requestMicLaterJS();

    @JSBody(script = "" + "if (window.__galacticRec && window.__galacticRec.rec" + "    && window.__galacticRec.rec.state !== 'inactive') {" + "  window.__galacticRec.rec.stop();" + "}")
    private static native void stopRecordingJS();

    @JSBody(script = "return !!window.__galacticRec;")
    private static native boolean isRecordingActiveJS();
}
