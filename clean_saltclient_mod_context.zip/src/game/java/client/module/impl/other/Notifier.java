package client.module.impl.other;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.NotificationSystem;
import client.utils.player.PlayerUtils;
import net.minecraft.client.Minecraft;

public class Notifier extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private boolean wasInCombat = false;

    private boolean notifiedLowHealth = false;

    public Notifier() {
        super("Notifier", Category.OTHER);
        setDescription("Shows alerts for certain stuff");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        boolean inCombat = mc.player.hurtTime > 0;
        if (inCombat && !wasInCombat) {
            NotificationSystem.warning("You are now in combat!");
        } else if (!inCombat && wasInCombat) {
            NotificationSystem.success("You are no longer in combat.");
        }
        wasInCombat = inCombat;
        float health = PlayerUtils.getTotalHealth();
        if (health <= 6.0f && health > 0) {
            if (!notifiedLowHealth) {
                NotificationSystem.error("Low health! " + String.format("%.1f", health) + " HP");
                notifiedLowHealth = true;
            }
        } else if (health > 6.0f) {
            notifiedLowHealth = false;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        wasInCombat = false;
        notifiedLowHealth = false;
    }
}
