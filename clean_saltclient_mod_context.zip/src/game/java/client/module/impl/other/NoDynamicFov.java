package client.module.impl.other;

import client.module.Category;
import client.module.Module;

public class NoDynamicFov extends Module {

    public NoDynamicFov() {
        super("NoDynamicFov", Category.OTHER);
        setDescription("Prevents fov from changing when sprinting");
    }
}
