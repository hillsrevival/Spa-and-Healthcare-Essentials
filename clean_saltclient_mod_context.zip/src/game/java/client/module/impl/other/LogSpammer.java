package client.module.impl.other;

import java.util.Random;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import client.utils.world.PacketUtils;
import io.netty.buffer.Unpooled;

public class LogSpammer extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Random random = new Random();

    private int tickCounter = 0;

    private static final String[] CHANNELS = { "MC|BEdit", "MC|BSign", "MC|TrSel", "MC|PickItem" };

    private byte[] rawPayload;

    private PacketBuffer payload;

    public LogSpammer() {
        super("LogSpammer", Category.OTHER);
        setDescription("LogSpammer");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        rawPayload = new byte[random.nextInt(128)];
        random.nextBytes(rawPayload);
        payload = new PacketBuffer(Unpooled.wrappedBuffer(rawPayload));
        tickCounter = 0;
        ChatUtils.info("LogSpammer enabled - sending garbage packets");
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.player.connection == null)
            return;
        tickCounter++;
        if (tickCounter < 2)
            return;
        tickCounter = 0;
        try {
            String channel = CHANNELS[random.nextInt(CHANNELS.length)];
            PacketUtils.sendCustomPayload(channel, payload);
        } catch (Exception e) {
        }
    }

    @Override
    public void onDisable() {
        tickCounter = 0;
        rawPayload = null;
        payload = null;
        ChatUtils.message("LogSpammer disabled");
        super.onDisable();
    }
}
