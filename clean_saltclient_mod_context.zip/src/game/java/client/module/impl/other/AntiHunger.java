package client.module.impl.other;

import client.event.events.PacketOutputEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.network.play.client.CPacketPlayer;

public class AntiHunger extends Module {

    public AntiHunger() {
        super("AntiHunger", Category.OTHER);
        setDescription("Stops hunger from decreasing");
        handles(HandlerType.PACKET_OUTPUT);
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        if (mc.player == null)
            return;
        if (event.getPacket() instanceof CPacketPlayer) {
            ((CPacketPlayer) event.getPacket()).setOnGround(false);
        }
    }
}
