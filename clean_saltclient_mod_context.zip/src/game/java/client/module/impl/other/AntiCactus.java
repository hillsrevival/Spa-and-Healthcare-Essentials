package client.module.impl.other;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.world.WorldUtils;

public class AntiCactus extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public AntiCactus() {
        super("AntiCactus", Category.OTHER);
        setDescription("Prevents cactus damage");
        handles(HandlerType.UPDATE);
    }

    private int lastScanX = Integer.MIN_VALUE;

    private int lastScanY = Integer.MIN_VALUE;

    private int lastScanZ = Integer.MIN_VALUE;

    private boolean lastScanFoundCactus = false;

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        int cellX = (int) Math.floor(mc.player.posX);
        int cellY = (int) Math.floor(mc.player.posY);
        int cellZ = (int) Math.floor(mc.player.posZ);
        if (cellX == lastScanX && cellY == lastScanY && cellZ == lastScanZ && !lastScanFoundCactus) {
            return;
        }
        lastScanX = cellX;
        lastScanY = cellY;
        lastScanZ = cellZ;
        lastScanFoundCactus = false;
        double px = mc.player.posX;
        double py = mc.player.posY;
        double pz = mc.player.posZ;
        double hw = mc.player.width / 2.0;
        int minX = (int) Math.floor(px - hw);
        int maxX = (int) Math.floor(px + hw);
        int minY = (int) Math.floor(py);
        int maxY = (int) Math.floor(py + mc.player.height);
        int minZ = (int) Math.floor(pz - hw);
        int maxZ = (int) Math.floor(pz + hw);
        for (int bx = minX; bx <= maxX; bx++) {
            for (int by = minY; by <= maxY; by++) {
                for (int bz = minZ; bz <= maxZ; bz++) {
                    BlockPos pos = new BlockPos(bx, by, bz);
                    if (WorldUtils.getBlock(pos) != Blocks.CACTUS) {
                        continue;
                    }
                    lastScanFoundCactus = true;
                    double cactusCenterX = bx + 0.5;
                    double cactusCenterZ = bz + 0.5;
                    double diffX = px - cactusCenterX;
                    double diffZ = pz - cactusCenterZ;
                    double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);
                    if (dist < 0.01) {
                        float yaw = mc.player.rotationYaw;
                        double yawRad = Math.toRadians(yaw);
                        diffX = -Math.sin(yawRad);
                        diffZ = Math.cos(yawRad);
                        dist = 1.0;
                    }
                    double pushStrength = 0.15;
                    mc.player.motionX += (diffX / dist) * pushStrength;
                    mc.player.motionZ += (diffZ / dist) * pushStrength;
                }
            }
        }
    }
}
