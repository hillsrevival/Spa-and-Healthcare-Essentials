package client.module.impl.other;

import client.baritone.api.Goal;
import client.baritone.api.GoalBlock;
import client.baritone.api.GoalXZ;
import client.baritone.api.GoalNearXZ;
import client.baritone.api.GoalAdjacent;
import client.baritone.api.GoalComposite;
import client.baritone.api.GoalInverted;
import client.baritone.api.GoalTwoBlocks;
import client.baritone.api.GoalGetToBlock;
import client.baritone.api.GoalStrictDirection;
import client.baritone.api.GoalYLevel;
import client.baritone.api.GoalThreeBlocks;
import client.baritone.pathing.AStarPathFinder;
import client.baritone.pathing.Path;
import client.baritone.pathing.PathNode;
import client.baritone.pathing.PathExecutor;
import client.baritone.pathing.MovementState;
import client.baritone.pathing.BlockAccess;
import client.baritone.cache.CachedWorld;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.ChatUtils;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;
import client.utils.world.InteractionUtils;
import client.utils.combat.SilentAimUtil;
import client.module.impl.render.Waypoints;
import net.minecraft.schematic.SchematicManager;
import net.minecraft.schematic.SchematicData;
import net.minecraft.block.Block;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.BlockNetherWart;
import net.minecraft.block.BlockCocoa;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemFood;
import net.minecraft.inventory.ClickType;
import net.minecraft.world.chunk.Chunk;

public class Baritone extends Module {

    private int nodesPerTick = 1200;

    public static Baritone INSTANCE;

    private double pathTimeout = 5.0;

    private boolean sprintEnabled = true;

    private boolean renderPath = true;

    private client.baritone.pathing.Path lastRenderPath = null;

    private Goal lastRenderPathGoal = null;

    private long lastRenderPathMs = 0;

    private static final long STALE_PATH_RENDER_MS = 4000L;

    private int followDist = 2;

    private int mineRadius = 32;

    private int farmRadius = 16;

    private String hudStatusLine = "";

    private String hudProgStr = "";

    private String hudEtaText = "";

    private String hudMinedStr = "";

    private String hudBuildStr = "";

    private String hudTimeStr = "";

    private int hudCacheTick = -1;

    private static final long FARM_SCAN_BUDGET_NS = 6_000_000L;

    private boolean farmScanActive = false;

    private boolean farmScanFromCommand = false;

    private int farmScanRadius = 16;

    private int farmScanChunkRadius = 2;

    private int farmScanBaseCX = 0;

    private int farmScanBaseCZ = 0;

    private int farmScanCX = 0;

    private int farmScanCZ = 0;

    private int farmScanX = 0;

    private int farmScanZ = 0;

    private int farmScanYMin = 0;

    private int farmScanYMax = 255;

    private int[] farmScanBest = null;

    private double farmScanBestSq = Double.MAX_VALUE;

    private boolean autoReplant = true;

    private boolean allowBreak = true;

    private boolean allowPlace = true;

    private boolean allowParkour = false;

    private boolean allowDiagonalAscend = false;

    private boolean allowDiagonalDescend = false;

    private boolean allowDownward = true;

    private boolean allowInventory = false;

    private boolean autoTool = true;

    private boolean assumeStep = false;

    private boolean assumeSafeWalk = false;

    private boolean autoEat = true;

    private int autoEatThreshold = 18;

    private boolean avoidance = false;

    private boolean allowWaterBucketFall = true;

    private boolean legitMine = false;

    private int legitMineYLevel = 11;

    private boolean closeDoorOnArrival = false;

    private int blockBreakSpeed = 6;

    private double blockPlacementPenalty = 20.0;

    private double costHeuristic = 3.563;

    private double avoidBreakingMultiplier = 0.1;

    private double pathCutoffFactor = 0.9;

    private int minToolDurability = 1;

    private double blockReachDistance = 4.5;

    private int maxFallHeightNoWater = 3;

    private boolean allowParkourPlace = false;

    private boolean sprintAscends = true;

    private double blockBreakAdditionalPenalty = 2.0;

    private double jumpPenalty = 2.0;

    private int movementTimeoutTicks = 100;

    private int pathCutoffMinimumLength = 30;

    private int rightClickSpeed = 4;

    private boolean allowSprint = true;

    private boolean allowParkourAscend = true;

    private boolean allowOvershootDiagonalDescend = true;

    private boolean allowPlaceInFluidsFlow = true;

    private boolean allowPlaceInFluidsSource = true;

    private boolean allowWalkOnBottomSlab = true;

    private boolean avoidUpdatingFallingBlocks = true;

    private boolean backfill = false;

    private boolean cancelOnGoalInvalidation = true;

    private boolean mineScanDroppedItems = true;

    private boolean considerPotionEffects = true;

    private int costVerificationLookahead = 5;

    private boolean smoothLook = true;

    private boolean freeLook = true;

    private boolean allowVines = false;

    private boolean blacklistClosestOnFailure = true;

    private double backtrackCostFavoringCoefficient = 0.5;

    private final java.util.ArrayList<Block> acceptableThrowawayItems = new java.util.ArrayList<Block>();

    private final java.util.ArrayList<Block> blocksToAvoidBreakingList = new java.util.ArrayList<Block>();

    private final HudElement infoOverlay = new HudElement(this, 5, 120);

    private final PathExecutor executor = new PathExecutor();

    private AStarPathFinder finder;

    private Goal currentGoal = null;

    private boolean pathRequested = false;

    private long pathTimeoutEnd = 0;

    private String goalDescription = "";

    private String followTarget = "";

    private int lastFollowX;

    private int lastFollowZ;

    private static final int FOLLOW_RECALC_DIST = 3;

    private boolean pathCompleted = false;

    private boolean pathFailed = false;

    private int pathFailCount = 0;

    private int consecutivePartials = 0;

    private double lastPartialX = 0;

    private double lastPartialZ = 0;

    private int autoEatLastTick = -100;

    private int autoEatPrevSlot = -1;

    private boolean autoEating = false;

    private String mineTargetBlock = "";

    private boolean mineContinuous = false;

    private BlockPos mineTargetPos = null;

    private boolean mining = false;

    private boolean silentAimOwned = false;

    private EnumFacing mineTargetFace = EnumFacing.UP;

    private static final double MINE_REACH = 4.5;

    private static final double MINE_START_DIST = 2.5;

    private static final double MINE_START_DIST_SQ = MINE_START_DIST * MINE_START_DIST;

    private int mineToolSlot = -1;

    private int blocksMined = 0;

    private BlockPos savedMineTargetPos = null;

    private long lastCountedMineHash;

    private boolean lastCountedMineValid = false;

    private final client.baritone.pathing.LongBoolMap mineBlacklist = new client.baritone.pathing.LongBoolMap(64);

    private static final int MINE_CANDIDATE_COUNT = 24;

    private int mineSearchRadius = 64;

    private boolean mineScanActive = false;

    private int mineScanRing = 0;

    private int mineScanRingI = 0;

    private int mineScanChunkRadius = 0;

    private int mineScanBaseCX = 0;

    private int mineScanBaseCZ = 0;

    private int mineScanYMin = 0;

    private int mineScanYMax = 0;

    private boolean mineScanApplyOnDone = false;

    private final java.util.ArrayList<int[]> mineScanResults = new java.util.ArrayList<>();

    private final java.util.ArrayList<double[]> mineScanDists = new java.util.ArrayList<>();

    private double mineScanWorstSq = Double.MAX_VALUE;

    private final BlockPos mineScanPos = new BlockPos(0, 0, 0);

    private final java.util.ArrayList<int[]> mineCandidates = new java.util.ArrayList<>();

    private long lastMineScanCompleteMs = 0;

    private long lastMineTargetChatMs = 0;

    private long lastShaftMineMs = 0;

    private long mineTargetFailHash = 0;

    private boolean mineTargetFailValid = false;

    private int mineTargetFailCount = 0;

    private static final int MINE_TARGET_FAIL_BLACKLIST = 3;

    private static final long MINE_SCAN_BUDGET_IDLE_NS = 8_000_000L;

    private static final long MINE_SCAN_BUDGET_NS = 3_000_000L;

    private static final int MINE_SCAN_Y_RANGE = 32;

    private static final long MINE_CACHE_STALE_MS = 5000L;

    private final java.util.ArrayList<int[]> anticipatedDrops = new java.util.ArrayList<>();

    private boolean dropPickupActive = false;

    private long dropPickupDeadlineMs = 0;

    private int dropPickupAttempts = 0;

    private long dropPickupCooldownUntilMs = 0;

    private static final long MINE_DROP_LOITER_MS = 4000L;

    private static final long MINE_PICKUP_MAX_MS = 10000L;

    private static final long MINE_PICKUP_COOLDOWN_MS = 15000L;

    private static final double MINE_PICKUP_RANGE_SQ = 6.0 * 6.0;

    private int mineDesiredQuantity = 0;

    private int mineQuantityTick = 0;

    private boolean exploreForBlocks = true;

    private boolean mineExploreActive = false;

    private long mineExploreNextScanMs = 0;

    private int mineExploreX = 0;

    private int mineExploreZ = 0;

    private int segmentFailStreak = 0;

    private double segFailX, segFailY, segFailZ;

    private boolean segFailPosValid = false;

    private static final int SEGMENT_FAIL_GIVEUP = 6;

    private boolean breakingObstruction = false;

    private boolean miningFirstTick = true;

    private BlockPos lastMineActualTarget = null;

    private BlockPos cachedCoveringBlock = null;

    private double cachedTracePX = 0;

    private double cachedTracePY = 0;

    private double cachedTracePZ = 0;

    private BlockPos cachedTraceTarget = null;

    private boolean farming = false;

    private BlockPos farmTargetPos = null;

    private int cropsHarvested = 0;

    private BlockPos farmReplantPos = null;

    private int farmReplantTimer = 0;

    private Block farmReplantBlock = null;

    private static final int FARM_CROP = 0;

    private static final int FARM_MELON = 1;

    private static final int FARM_STEM = 2;

    private static final int FARM_NETHER = 3;

    private static final int FARM_COCOA = 4;

    private BlockPos clickTargetPos = null;

    private int[] deathPos = null;

    private boolean died = false;

    private final java.util.ArrayList<int[]> avoidZones = new java.util.ArrayList<int[]>();

    private static final int AVOID_MAX = 20;

    private Goal lastFailedGoal = null;

    private String lastFailedDesc = "";

    private int retryCount = 0;

    private static final int MAX_RETRIES = 15;

    private long pathStartTime = 0;

    private boolean showTimer = true;

    private long lastRecalcTime = 0;

    private static final long RECALC_COOLDOWN_MS = 500;

    private final client.baritone.pathing.LongBoolMap globalVisitedPositions = new client.baritone.pathing.LongBoolMap(8192);

    private int[] selPos1 = null;

    private int[] selPos2 = null;

    private boolean building = false;

    private int buildMode = 0;

    private boolean tunneling = false;

    private int tunnelIndex = 0;

    private int tunnelHeight = 2;

    private int tunnelWidth = 1;

    private java.util.List<int[]> tunnelBlocks = null;

    private boolean savedAutoJump = true;

    private static final int BUILD_FILL = 0;

    private static final int BUILD_WALLS = 1;

    private static final int BUILD_FLOOR = 2;

    private static final int BUILD_CLEAR = 3;

    private static final int BUILD_CEILING = 4;

    private static final int BUILD_SCHEM = 5;

    private java.util.ArrayList<int[]> buildQueue = new java.util.ArrayList<int[]>();

    private java.util.ArrayList<Integer> buildQueueBlockIds = new java.util.ArrayList<Integer>();

    private int buildIndex = 0;

    private Block buildBlock = null;

    private int blocksPlaced = 0;

    private int blocksBroken = 0;

    private boolean buildPlacing = false;

    private int buildPlaceTimer = 0;

    private static final int BUILD_REACH = 4;

    private int buildRotation = 0;

    private boolean buildMirrorX = false;

    private boolean buildMirrorZ = false;

    private boolean buildSchematic = false;

    private boolean exploring = false;

    private int exploreIndex = 0;

    private int[] exploreTargetsX;

    private int[] exploreTargetsZ;

    private int exploreCenterX;

    private int exploreCenterZ;

    private boolean paused = false;

    private boolean cancelPending = false;

    private final java.util.ArrayList<Block> blacklistedOres = new java.util.ArrayList<Block>();

    private boolean throwawayDefaultsInit = false;

    private boolean avoidBreakingDefaultsInit = false;

    private boolean preCacheDone = false;

    private static final int PRECACHE_RADIUS = 4;

    public Baritone() {
        super("Baritone", Category.OTHER);
        setDescription("Baritone Port");
        infoOverlay.addSettings();
        INSTANCE = this;
        handles(HandlerType.RENDER, HandlerType.GUI_RENDER, HandlerType.TICK, HandlerType.DEATH, HandlerType.WORLD_CHANGE);
        initDefaultBlockLists();
    }

    private void initDefaultBlockLists() {
        acceptableThrowawayItems.add(Blocks.DIRT);
        acceptableThrowawayItems.add(Blocks.COBBLESTONE);
        acceptableThrowawayItems.add(Blocks.NETHERRACK);
        acceptableThrowawayItems.add(Blocks.STONE);
        acceptableThrowawayItems.add(Blocks.GRASS);
        throwawayDefaultsInit = true;
        blocksToAvoidBreakingList.add(Blocks.CRAFTING_TABLE);
        blocksToAvoidBreakingList.add(Blocks.FURNACE);
        blocksToAvoidBreakingList.add(Blocks.CHEST);
        blocksToAvoidBreakingList.add(Blocks.TRAPPED_CHEST);
        avoidBreakingDefaultsInit = true;
    }

    public void cmdGoto(String[] args) {
        pathFailed = false;
        paused = false;
        if (args.length < 1) {
            ChatUtils.error("Usage: #goto <x> <y> <z>");
            ChatUtils.error("       #goto <waypoint name>");
            return;
        }
        if (args.length == 1) {
            String wpName = args[0].toLowerCase();
            Waypoints wpMod = Waypoints.INSTANCE;
            if (wpMod != null) {
                double[] pos = wpMod.getWaypoint(wpName);
                if (pos != null) {
                    int gx = (int) Math.floor(pos[0]);
                    int gy = (int) Math.floor(pos[1]);
                    int gz = (int) Math.floor(pos[2]);
                    followTarget = "";
                    exploring = false;
                    mineTargetBlock = "";
                    setGoal(new GoalBlock(gx, gy, gz), String.format("Goto %s (%d %d %d)", wpName, gx, gy, gz));
                    ChatUtils.success("Going to waypoint \"" + wpName + "\" (" + gx + ", " + gy + ", " + gz + ")");
                    return;
                }
            }
            ChatUtils.error("Unknown waypoint: " + args[0]);
            ChatUtils.error("Usage: #goto <x> <y> <z>");
            return;
        }
        try {
            int x = Integer.parseInt(args[0]);
            int y = Integer.parseInt(args[1]);
            int z = Integer.parseInt(args[2]);
            followTarget = "";
            exploring = false;
            mineTargetBlock = "";
            setGoal(new GoalBlock(x, y, z), String.format("Goto %d %d %d", x, y, z));
            ChatUtils.success("Pathfinding to " + x + ", " + y + ", " + z);
        } catch (NumberFormatException e) {
            ChatUtils.error("Invalid coordinates: must be integers");
        }
    }

    public void cmdClick(String[] args) {
        pathFailed = false;
        pathFailCount = 0;
        paused = false;
        if (args.length < 3) {
            ChatUtils.error("Usage: #click <x> <y> <z>");
            return;
        }
        try {
            int x = Integer.parseInt(args[0]);
            int y = Integer.parseInt(args[1]);
            int z = Integer.parseInt(args[2]);
            followTarget = "";
            exploring = false;
            mineTargetBlock = "";
            clickTargetPos = new BlockPos(x, y, z);
            setGoal(new GoalAdjacent(x, y, z), String.format("Click %d %d %d", x, y, z));
            ChatUtils.success("Pathing to click " + x + ", " + y + ", " + z);
        } catch (NumberFormatException e) {
            ChatUtils.error("Invalid coordinates: must be integers");
        }
    }

    public void cmdFollow(String[] args) {
        pathFailed = false;
        pathFailCount = 0;
        if (args.length < 1) {
            ChatUtils.error("Usage: #follow <player> [distance]");
            ChatUtils.error("       #follow players [distance]");
            ChatUtils.error("       #follow entities [distance]");
            ChatUtils.error("       #follow entity <type> [distance]");
            ChatUtils.message("  distance: how close to follow (1-10, default 2)");
            return;
        }
        String name = args[0];
        if (args.length >= 2) {
            try {
                int d = Integer.parseInt(args[args.length - 1]);
                d = Math.max(1, Math.min(10, d));
                followDist = d;
                ChatUtils.message("Follow distance: " + d);
            } catch (NumberFormatException e) {
            }
        }
        if (mc.world == null) {
            ChatUtils.error("Not in-game");
            return;
        }
        if (name.equalsIgnoreCase("players")) {
            stopExplore();
            mineTargetBlock = "";
            followTarget = "players";
            currentGoal = null;
            goalDescription = "Follow players";
            pathCompleted = false;
            updateFollowGoal();
            ChatUtils.success("Now following players");
            return;
        }
        if (name.equalsIgnoreCase("entities")) {
            stopExplore();
            mineTargetBlock = "";
            followTarget = "entities";
            currentGoal = null;
            goalDescription = "Follow entities";
            pathCompleted = false;
            updateFollowGoal();
            ChatUtils.success("Now following entities");
            return;
        }
        if (name.equalsIgnoreCase("entity")) {
            if (args.length < 2) {
                ChatUtils.error("Usage: #follow entity <type> [distance]");
                return;
            }
            String entityType = args[1].toLowerCase();
            stopExplore();
            mineTargetBlock = "";
            followTarget = "entity:" + entityType;
            currentGoal = null;
            goalDescription = "Follow entity " + entityType;
            pathCompleted = false;
            updateFollowGoal();
            ChatUtils.success("Now following entity: " + entityType);
            return;
        }
        boolean found = false;
        for (net.minecraft.entity.Entity entity : mc.world.loadedEntityList) {
            if (entity instanceof EntityOtherPlayerMP && entity.getName().equalsIgnoreCase(name)) {
                found = true;
                break;
            }
        }
        if (!found) {
            ChatUtils.error("Player not found: " + name);
            return;
        }
        stopExplore();
        mineTargetBlock = "";
        followTarget = name;
        currentGoal = null;
        goalDescription = "Follow " + name;
        pathCompleted = false;
        updateFollowGoal();
        ChatUtils.success("Now following " + name + " (toggle module to walk)");
    }

    public void cmdMine(String[] args) {
        pathFailed = false;
        pathFailCount = 0;
        paused = false;
        mineBlacklist.clear();
        segmentFailStreak = 0;
        segFailPosValid = false;
        blocksMined = 0;
        lastCountedMineValid = false;
        savedMineTargetPos = null;
        if (mining) {
            stopMining();
        }
        mineDesiredQuantity = 0;
        if (args.length >= 2) {
            try {
                int qty = Integer.parseInt(args[0]);
                if (qty > 0) {
                    mineDesiredQuantity = qty;
                    String[] shifted = new String[args.length - 1];
                    System.arraycopy(args, 1, shifted, 0, shifted.length);
                    args = shifted;
                    ChatUtils.message("Will stop at " + qty + " collected");
                }
            } catch (NumberFormatException e) {
            }
        }
        if (args.length < 1) {
            ChatUtils.error("Usage: #mine <block> [radius]");
            ChatUtils.error("       #mine <qty> <block> (stop at qty)");
            ChatUtils.error("       #mine this (look at a block)");
            ChatUtils.error("       #mine ores (all ore types)");
            ChatUtils.message("Use Tab to autocomplete block names!");
            ChatUtils.message("Examples: #mine diamond_ore, #mine 64 stone,");
            ChatUtils.message("             #mine iron_ore 64 (radius 64)");
            return;
        }
        if (mc.world == null) {
            ChatUtils.error("Not in-game");
            return;
        }
        if (args[0].equalsIgnoreCase("ores")) {
            mineTargetBlock = "ores";
            followTarget = "";
            exploring = false;
            mining = false;
            mineContinuous = true;
            mineTargetPos = null;
            mineSearchRadius = 64;
            mineBlacklist.clear();
            mineCandidates.clear();
            dropPickupActive = false;
            anticipatedDrops.clear();
            dropPickupAttempts = 0;
            dropPickupCooldownUntilMs = 0;
            mineExploreActive = false;
            cancelPath();
            currentGoal = null;
            goalDescription = "";
            startMineScan(true);
            ChatUtils.message("Scanning for ores within " + mineSearchRadius + " blocks...");
            return;
        }
        if (args[0].equalsIgnoreCase("logs") || args[0].equalsIgnoreCase("log") || args[0].equalsIgnoreCase("wood") || args[0].equalsIgnoreCase("tree")) {
            mineTargetBlock = "logs";
            followTarget = "";
            exploring = false;
            mining = false;
            mineContinuous = true;
            mineTargetPos = null;
            mineSearchRadius = 64;
            mineBlacklist.clear();
            mineCandidates.clear();
            dropPickupActive = false;
            anticipatedDrops.clear();
            dropPickupAttempts = 0;
            dropPickupCooldownUntilMs = 0;
            mineExploreActive = false;
            cancelPath();
            currentGoal = null;
            goalDescription = "";
            startMineScan(true);
            ChatUtils.message("Scanning for logs within 64 blocks...");
            return;
        }
        if (args[0].equalsIgnoreCase("this")) {
            if (mc.objectMouseOver == null || mc.objectMouseOver.typeOfHit != RayTraceResult.Type.BLOCK) {
                ChatUtils.error("Not looking at a block");
                return;
            }
            BlockPos lookPos = mc.objectMouseOver.getBlockPos();
            Block lookBlock = mc.world.getBlockState(lookPos).getBlock();
            String name = getBlockRegistryName(lookBlock);
            followTarget = "";
            exploring = false;
            mineTargetBlock = name;
            mineContinuous = false;
            mining = false;
            mineTargetPos = lookPos;
            double dx = (lookPos.getX() + 0.5) - mc.player.posX;
            double dy = (lookPos.getY() + 0.5) - mc.player.posY;
            double dz = (lookPos.getZ() + 0.5) - mc.player.posZ;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist <= MINE_REACH) {
                mining = true;
                miningFirstTick = true;
                pathCompleted = true;
                executor.clearPath();
                goalDescription = "Mine " + name;
                ChatUtils.success("Mining " + name + " at " + lookPos.getX() + ", " + lookPos.getY() + ", " + lookPos.getZ());
            } else {
                setGoal(new GoalTwoBlocks(lookPos.getX(), lookPos.getY(), lookPos.getZ()), "Mine " + name + " at " + lookPos.getX() + ", " + lookPos.getY() + ", " + lookPos.getZ());
                ChatUtils.success("Found " + name + " at " + lookPos.getX() + ", " + lookPos.getY() + ", " + lookPos.getZ());
            }
            return;
        }
        String blockName = args[0].toLowerCase().replace(" ", "_");
        Block block = getBlockByName(blockName);
        if (block == null) {
            ChatUtils.error("Unknown block: " + blockName);
            ChatUtils.message("Use MC registry names like: diamond_ore, iron_ore");
            ChatUtils.message("Use Tab to autocomplete block names!");
            ChatUtils.message("Or: #mine this");
            return;
        }
        int searchRadius = 64;
        if (args.length >= 2) {
            try {
                searchRadius = Integer.parseInt(args[1]);
                searchRadius = Math.max(8, Math.min(128, searchRadius));
            } catch (NumberFormatException e) {
                ChatUtils.error("Invalid radius");
                return;
            }
        }
        followTarget = "";
        exploring = false;
        mineTargetBlock = blockName;
        mineContinuous = true;
        mining = false;
        mineTargetPos = null;
        mineSearchRadius = searchRadius;
        mineBlacklist.clear();
        mineCandidates.clear();
        dropPickupActive = false;
        anticipatedDrops.clear();
        dropPickupAttempts = 0;
        dropPickupCooldownUntilMs = 0;
        mineExploreActive = false;
        cancelPath();
        currentGoal = null;
        goalDescription = "";
        startMineScan(true);
        ChatUtils.message("Scanning for " + blockName + " within " + searchRadius + " blocks...");
    }

    public void cmdExplore(String[] args) {
        pathFailed = false;
        pathFailCount = 0;
        paused = false;
        if (mc.world == null) {
            ChatUtils.error("Not in-game");
            return;
        }
        int radius = 64;
        if (args.length >= 1) {
            try {
                radius = Integer.parseInt(args[0]);
                radius = Math.max(16, Math.min(256, radius));
            } catch (NumberFormatException e) {
                ChatUtils.error("Invalid radius");
                return;
            }
        }
        exploreCenterX = (int) Math.floor(mc.player.posX);
        exploreCenterZ = (int) Math.floor(mc.player.posZ);
        generateExploreTargets(radius);
        if (exploreTargetsX == null || exploreTargetsX.length == 0) {
            ChatUtils.error("No explore targets generated");
            return;
        }
        followTarget = "";
        mineTargetBlock = "";
        exploring = true;
        exploreIndex = 0;
        pathCompleted = false;
        setNextExploreGoal();
        ChatUtils.success("Exploring " + radius + " block radius (" + exploreTargetsX.length + " waypoints)");
    }

    public void cmdFarm(String[] args) {
        pathFailed = false;
        pathFailCount = 0;
        paused = false;
        if (mc.world == null) {
            ChatUtils.error("Not in-game");
            return;
        }
        int radius = 16;
        if (args.length >= 1) {
            try {
                radius = Integer.parseInt(args[0]);
                radius = Math.max(4, Math.min(64, radius));
            } catch (NumberFormatException e) {
                ChatUtils.error("Invalid radius");
                return;
            }
        }
        followTarget = "";
        exploring = false;
        mineTargetBlock = "";
        farming = true;
        cropsHarvested = 0;
        farmTargetPos = null;
        startFarmScan(radius, true);
        ChatUtils.success("Scanning for mature crops within " + radius + " blocks...");
    }

    public void cmdSurface(String[] args) {
        pathFailed = false;
        pathFailCount = 0;
        paused = false;
        if (mc.player == null || mc.world == null) {
            ChatUtils.error("Not in-game");
            return;
        }
        int px = (int) Math.floor(mc.player.posX);
        int pz = (int) Math.floor(mc.player.posZ);
        int surfaceY = -1;
        for (int y = 255; y >= 0; y--) {
            if (!BlockAccess.canWalkThrough(px, y, pz)) {
                surfaceY = y + 1;
                break;
            }
        }
        if (surfaceY == -1) {
            ChatUtils.error("No surface found");
            return;
        }
        int targetX = px;
        int targetZ = pz;
        int playerY = (int) Math.floor(mc.player.posY);
        if (playerY >= surfaceY) {
            for (int r = 1; r <= 32; r++) {
                boolean found = false;
                for (int dx = -r; dx <= r && !found; dx++) {
                    for (int dz = -r; dz <= r && !found; dz++) {
                        if (Math.abs(dx) != r && Math.abs(dz) != r)
                            continue;
                        int sx = px + dx;
                        int sz = pz + dz;
                        for (int y = 255; y >= 0; y--) {
                            if (!BlockAccess.canWalkThrough(sx, y, sz)) {
                                if (y + 1 > playerY) {
                                    targetX = sx;
                                    targetZ = sz;
                                    surfaceY = y + 1;
                                    found = true;
                                }
                                break;
                            }
                        }
                    }
                }
                if (found)
                    break;
            }
        }
        cancelPath();
        setGoal(new GoalXZ(targetX, targetZ), "Surface at " + targetX + ", " + targetZ);
        ChatUtils.success("Pathing to surface at " + targetX + ", " + surfaceY);
    }

    public void cmdCancel() {
        pathFailed = false;
        pathFailCount = 0;
        executor.clearPath();
        pathRequested = false;
        if (finder != null) {
            finder.cancel();
            finder = null;
        }
        if (currentGoal == null && followTarget.isEmpty() && !exploring && !mining && !building && !farming) {
            ChatUtils.message("No active path or goal");
            return;
        }
        currentGoal = null;
        goalDescription = "";
        followTarget = "";
        mineTargetBlock = "";
        mineContinuous = false;
        mineTargetPos = null;
        mineBlacklist.clear();
        dropPickupActive = false;
        anticipatedDrops.clear();
        dropPickupAttempts = 0;
        dropPickupCooldownUntilMs = 0;
        mineExploreActive = false;
        mineDesiredQuantity = 0;
        mineScanActive = false;
        mineScanApplyOnDone = false;
        mineScanResults.clear();
        mineScanDists.clear();
        mineCandidates.clear();
        lastMineScanCompleteMs = 0;
        stopMining();
        blocksMined = 0;
        lastCountedMineValid = false;
        stopExplore();
        farming = false;
        tunneling = false;
        tunnelIndex = 0;
        tunnelBlocks = null;
        farmTargetPos = null;
        farmReplantPos = null;
        farmReplantBlock = null;
        farmReplantTimer = 0;
        cropsHarvested = 0;
        clickTargetPos = null;
        lastFailedGoal = null;
        lastFailedDesc = "";
        retryCount = 0;
        pathStartTime = 0;
        paused = false;
        pathCompleted = false;
        stopBuild();
        client.Client.INSTANCE.renderRotationOverride = false;
        client.Client.INSTANCE.physicsConsistentAim = false;
        if (SilentAimUtil.isActive() && SilentAimUtil.isOwnedBy("Baritone")) {
            SilentAimUtil.endStreak();
            SilentAimUtil.onDisable("Baritone");
        }
        silentAimOwned = false;
        releaseMovementKeys();
        if (mc.gameSettings != null) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
        }
        ChatUtils.success("Path cancelled");
    }

    public void cmdProc() {
        if (mining) {
            ChatUtils.message("Process: MINING" + (mineContinuous ? " (continuous)" : ""));
            if (mineTargetPos != null) {
                ChatUtils.message("  Target: " + mineTargetPos.getX() + ", " + mineTargetPos.getY() + ", " + mineTargetPos.getZ());
            }
            if (!mineTargetBlock.isEmpty()) {
                ChatUtils.message("  Block: " + mineTargetBlock);
            }
            ChatUtils.message("  Blocks mined: " + blocksMined);
        } else if (building) {
            ChatUtils.message("Process: BUILDING (" + buildMode + ")");
            ChatUtils.message("  Progress: " + buildIndex + "/" + buildQueue.size());
            ChatUtils.message("  Placed: " + blocksPlaced + " Broken: " + blocksBroken);
        } else if (farming) {
            ChatUtils.message("Process: FARMING");
            ChatUtils.message("  Harvested: " + cropsHarvested);
        } else if (exploring) {
            ChatUtils.message("Process: EXPLORING");
            ChatUtils.message("  Waypoint " + exploreIndex + "/" + exploreTargetsX.length);
        } else if (tunneling) {
            ChatUtils.message("Process: TUNNELING");
            ChatUtils.message("  Progress: " + tunnelIndex + "/" + (tunnelBlocks != null ? tunnelBlocks.size() : 0));
            ChatUtils.message("  Size: " + tunnelHeight + "x" + tunnelWidth);
        } else if (executor.hasPath()) {
            ChatUtils.message("Process: PATHING");
            ChatUtils.message("  Progress: " + (int) (executor.getProgress() * 100) + "%");
            if (currentGoal != null) {
                ChatUtils.message("  Goal: " + goalDescription);
            }
        } else if (followTarget != null && !followTarget.isEmpty()) {
            ChatUtils.message("Process: FOLLOWING " + followTarget);
        } else {
            ChatUtils.message("Process: IDLE");
        }
        if (currentGoal != null && !mining) {
            ChatUtils.message("Goal: " + goalDescription);
        }
    }

    public void cmdVersion() {
        ChatUtils.message("Baritone port for" + " SaltClient 1.12.2");
        ChatUtils.message("Based on Baritone 26.2" + " (cabaletta/baritone)");
        ChatUtils.message("Pathfinder: A* with " + nodesPerTick + " nodes/tick");
        ChatUtils.message("Cache: " + CachedWorld.getCacheSize() + "/256 chunks");
    }

    public void cmdRetry() {
        if (lastFailedGoal == null) {
            ChatUtils.error("No failed path to retry");
            return;
        }
        if (retryCount >= MAX_RETRIES) {
            ChatUtils.error("Max retries reached (" + MAX_RETRIES + "). Try a different goal or closer target.");
            lastFailedGoal = null;
            lastFailedDesc = "";
            return;
        }
        retryCount++;
        double savedTimeout = pathTimeout;
        pathTimeout = Math.min(30, savedTimeout + retryCount * 5.0);
        pathFailed = false;
        pathFailCount = 0;
        followTarget = "";
        exploring = false;
        mineTargetBlock = "";
        currentGoal = lastFailedGoal;
        goalDescription = lastFailedDesc + " (retry " + retryCount + ")";
        pathCompleted = false;
        if (isToggled()) {
            requestPath();
        } else {
            ChatUtils.message("Goal re-set. Toggle module to execute.");
        }
        ChatUtils.success("Retrying path (attempt " + retryCount + "/" + MAX_RETRIES + ", timeout=" + (int) pathTimeout + "s)");
    }

    public void cmdAvoid(String[] args) {
        if (args.length < 1) {
            ChatUtils.error("Usage: #avoid <x> <y> <z> [radius]");
            ChatUtils.error("       #avoid list");
            ChatUtils.error("       #avoid clear");
            return;
        }
        String sub = args[0].toLowerCase();
        if (sub.equals("list") || sub.equals("l")) {
            if (avoidZones.isEmpty()) {
                ChatUtils.message("No avoidance zones");
                return;
            }
            ChatUtils.cmd("Avoidance zones (" + avoidZones.size() + "):");
            for (int i = 0; i < avoidZones.size(); i++) {
                int[] z = avoidZones.get(i);
                int r = (int) Math.sqrt(z[3]);
                ChatUtils.message("  " + z[0] + ", " + z[1] + ", " + z[2] + " (r=" + r + ")");
            }
            return;
        }
        if (sub.equals("clear") || sub.equals("c")) {
            int count = avoidZones.size();
            avoidZones.clear();
            BlockAccess.clearAvoidZones();
            ChatUtils.success("Cleared " + count + " avoidance zone(s)");
            return;
        }
        if (args.length < 3) {
            ChatUtils.error("Usage: #avoid <x> <y> <z> [radius]");
            return;
        }
        try {
            int x = Integer.parseInt(args[0]);
            int y = Integer.parseInt(args[1]);
            int z = Integer.parseInt(args[2]);
            int radius = 5;
            if (args.length >= 4) {
                radius = Integer.parseInt(args[3]);
                radius = Math.max(1, Math.min(32, radius));
            }
            if (avoidZones.size() >= AVOID_MAX) {
                ChatUtils.error("Too many zones (max " + AVOID_MAX + ")");
                return;
            }
            int rSq = radius * radius;
            avoidZones.add(new int[] { x, y, z, rSq });
            BlockAccess.setAvoidZones(avoidZones);
            ChatUtils.success("Added avoid zone at " + x + ", " + y + ", " + z + " (radius=" + radius + ")");
        } catch (NumberFormatException e) {
            ChatUtils.error("Invalid coordinates");
        }
    }

    public void cmdTimer() {
        showTimer = !showTimer;
        ChatUtils.success("Path timer " + (showTimer ? "ON" : "OFF"));
    }

    public void cmdPause() {
        if (!executor.hasPath() && !mining && !farming) {
            ChatUtils.error("Nothing to pause");
            return;
        }
        paused = !paused;
        if (paused) {
            executor.clearInputs();
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
            ChatUtils.success("Path paused");
        } else {
            ChatUtils.success("Path resumed");
        }
    }

    public void cmdHere() {
        if (mc.player == null)
            return;
        cancelPath();
        stopMining();
        farming = false;
        farmTargetPos = null;
        exploring = false;
        followTarget = "";
        clickTargetPos = null;
        paused = false;
        currentGoal = new GoalBlock((int) Math.floor(mc.player.posX), (int) Math.floor(mc.player.posY), (int) Math.floor(mc.player.posZ));
        goalDescription = "Stay here";
        pathCompleted = true;
        pathFailed = false;
        pathFailCount = 0;
        InteractionUtils.stopMining();
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
        ChatUtils.success("Staying at current position");
    }

    public void cmdGoalSave(String[] args) {
        if (currentGoal == null) {
            ChatUtils.error("No active goal");
            return;
        }
        String name;
        if (args.length >= 1) {
            name = args[0];
        } else {
            name = "goal_" + System.currentTimeMillis() % 10000;
        }
        int gx, gy, gz;
        if (executor.hasPath()) {
            int[] dest = executor.getDestination();
            if (dest != null) {
                gx = dest[0];
                gy = dest[1];
                gz = dest[2];
            } else {
                gx = (int) Math.floor(mc.player.posX);
                gy = (int) Math.floor(mc.player.posY);
                gz = (int) Math.floor(mc.player.posZ);
            }
        } else if (mineTargetPos != null) {
            gx = mineTargetPos.getX();
            gy = mineTargetPos.getY();
            gz = mineTargetPos.getZ();
        } else {
            gx = (int) Math.floor(mc.player.posX);
            gy = (int) Math.floor(mc.player.posY);
            gz = (int) Math.floor(mc.player.posZ);
        }
        if (Waypoints.INSTANCE != null) {
            Waypoints.INSTANCE.addWaypoint(name, gx, gy, gz);
        }
        ChatUtils.success("Saved goal as waypoint: " + name + " (" + gx + ", " + gy + ", " + gz + ")");
    }

    public void cmdBlacklist(String[] args) {
        if (args.length < 1) {
            if (blacklistedOres.isEmpty()) {
                ChatUtils.message("No blacklisted ores");
            } else {
                ChatUtils.message("Blacklisted ores:");
                for (int i = 0; i < blacklistedOres.size(); i++) {
                    Block b = blacklistedOres.get(i);
                    ChatUtils.message("  " + b.getLocalizedName());
                }
            }
            return;
        }
        if (args[0].equals("list")) {
            if (blacklistedOres.isEmpty()) {
                ChatUtils.message("No blacklisted ores");
            } else {
                ChatUtils.message("Blacklisted ores (" + blacklistedOres.size() + "):");
                for (int i = 0; i < blacklistedOres.size(); i++) {
                    Block b = blacklistedOres.get(i);
                    ChatUtils.message("  " + b.getLocalizedName());
                }
            }
            return;
        }
        if (args[0].equals("clear")) {
            blacklistedOres.clear();
            ChatUtils.success("Ore blacklist cleared");
            return;
        }
        Block block = getBlockByName(args[0]);
        if (block == null) {
            ChatUtils.error("Unknown block: " + args[0]);
            return;
        }
        if (!isOre(block)) {
            ChatUtils.error(args[0] + " is not an ore");
            return;
        }
        for (int i = 0; i < blacklistedOres.size(); i++) {
            if (blacklistedOres.get(i) == block) {
                blacklistedOres.remove(i);
                ChatUtils.success(block.getLocalizedName() + " removed from blacklist");
                return;
            }
        }
        blacklistedOres.add(block);
        ChatUtils.success(block.getLocalizedName() + " added to blacklist");
    }

    public void cmdAxis(String[] args) {
        if (mc.player == null)
            return;
        int targetY = 120;
        if (args.length >= 1) {
            try {
                targetY = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                ChatUtils.error("Invalid Y value");
                return;
            }
        }
        int px = (int) Math.floor(mc.player.posX);
        int pz = (int) Math.floor(mc.player.posZ);
        int axDist = Math.min(Math.abs(px), Math.abs(pz));
        int diagDist = (int) Math.round(Math.min(Math.sqrt(px * px + pz * pz) / Math.sqrt(2), Math.abs(px - pz) / Math.sqrt(2)));
        int goalX, goalZ;
        if (axDist <= diagDist) {
            if (Math.abs(px) <= Math.abs(pz)) {
                goalX = 0;
                goalZ = pz;
            } else {
                goalX = px;
                goalZ = 0;
            }
        } else {
            if (Math.abs(px - pz) <= Math.abs(px + pz)) {
                int m = (px + pz) / 2;
                goalX = m;
                goalZ = m;
            } else {
                int m = (px - pz) / 2;
                goalX = m;
                goalZ = -m;
            }
        }
        currentGoal = new GoalBlock(goalX, targetY, goalZ);
        goalDescription = "axis " + goalX + " " + targetY + " " + goalZ;
        requestPath();
        ChatUtils.success("Going to axis: " + goalX + " " + targetY + " " + goalZ);
    }

    public void cmdTunnel(String[] args) {
        if (!nullCheck())
            return;
        int height = 2;
        int width = 1;
        int length = 50;
        if (args.length >= 1) {
            try {
                height = Math.max(1, Integer.parseInt(args[0]));
            } catch (NumberFormatException e) {
            }
        }
        if (args.length >= 2) {
            try {
                width = Math.max(1, Integer.parseInt(args[1]));
            } catch (NumberFormatException e) {
            }
        }
        if (args.length >= 3) {
            try {
                length = Math.max(1, Integer.parseInt(args[2]));
            } catch (NumberFormatException e) {
            }
        }
        float yaw = mc.player.rotationYaw;
        int dx = (int) Math.round(Math.sin(-yaw * (float) Math.PI / 180.0f));
        int dz = (int) Math.round(Math.cos(-yaw * (float) Math.PI / 180.0f));
        if (Math.abs(dx) >= Math.abs(dz)) {
            dx = dx > 0 ? 1 : -1;
            dz = 0;
        } else {
            dz = dz > 0 ? 1 : -1;
            dx = 0;
        }
        int startX = (int) Math.floor(mc.player.posX);
        int startY = (int) Math.floor(mc.player.posY);
        int startZ = (int) Math.floor(mc.player.posZ);
        int endX = startX + dx * length;
        int endZ = startZ + dz * length;
        tunnelBlocks = new java.util.ArrayList<>();
        for (int i = 0; i <= length; i++) {
            int bx = startX + dx * i;
            int bz = startZ + dz * i;
            for (int h = 0; h < height; h++) {
                for (int w = 0; w < width; w++) {
                    int perpX = -dz;
                    int perpZ = dx;
                    int tx = bx + perpX * (w - width / 2);
                    int ty = startY + h;
                    int tz = bz + perpZ * (w - width / 2);
                    tunnelBlocks.add(new int[] { tx, ty, tz });
                }
            }
        }
        tunneling = true;
        tunnelIndex = 0;
        tunnelHeight = height;
        tunnelWidth = width;
        currentGoal = new GoalBlock(endX, startY, endZ);
        goalDescription = "tunnel " + height + "x" + width + "x" + length + " dir=" + dx + "," + dz;
        requestPath();
        ChatUtils.success("Tunneling " + height + "x" + width + "x" + length + " blocks forward");
    }

    public void cmdThisway(String[] args) {
        if (mc.player == null)
            return;
        if (args.length < 1) {
            ChatUtils.error("Usage: #thisway <distance>");
            return;
        }
        double dist;
        try {
            dist = Double.parseDouble(args[0]);
        } catch (NumberFormatException e) {
            ChatUtils.error("Invalid distance");
            return;
        }
        float yaw = mc.player.rotationYaw;
        double dx = -Math.sin(yaw * Math.PI / 180.0);
        double dz = Math.cos(yaw * Math.PI / 180.0);
        int originX = (int) Math.floor(mc.player.posX);
        int originZ = (int) Math.floor(mc.player.posZ);
        currentGoal = new GoalStrictDirection(originX, originZ, dx, dz, dist);
        int goalX = (int) Math.floor(mc.player.posX + dx * dist);
        int goalZ = (int) Math.floor(mc.player.posZ + dz * dist);
        goalDescription = "thisway " + (int) dist + " → " + goalX + " " + goalZ;
        requestPath();
        ChatUtils.success("Going " + (int) dist + " blocks this way → " + goalX + " " + goalZ);
    }

    public void cmdInvert() {
        if (currentGoal == null) {
            ChatUtils.error("No goal to invert. Set one first.");
            return;
        }
        currentGoal = new GoalInverted(currentGoal);
        goalDescription = "inverted(" + goalDescription + ")";
        requestPath();
        ChatUtils.success("Goal inverted — running away!");
    }

    public void cmdCome() {
        if (mc.player == null)
            return;
        float yaw = mc.player.rotationYaw;
        float pitch = mc.player.rotationPitch;
        double dx = -Math.sin(yaw * Math.PI / 180.0) * Math.cos(pitch * Math.PI / 180.0);
        double dz = Math.cos(yaw * Math.PI / 180.0) * Math.cos(pitch * Math.PI / 180.0);
        int goalX = (int) Math.floor(mc.player.posX + dx * 100);
        int goalZ = (int) Math.floor(mc.player.posZ + dz * 100);
        int goalY = (int) Math.floor(mc.player.posY);
        currentGoal = new GoalXZ(goalX, goalZ);
        goalDescription = "come " + goalX + " " + goalZ;
        requestPath();
        ChatUtils.success("Coming towards camera: " + goalX + " " + goalZ);
    }

    public void cmdEta() {
        if (mc.player == null) {
            ChatUtils.error("No player");
            return;
        }
        if (currentGoal == null) {
            ChatUtils.error("No goal set");
            return;
        }
        double px = mc.player.posX;
        double py = mc.player.posY;
        double pz = mc.player.posZ;
        int bx = (int) Math.floor(px);
        int by = (int) Math.floor(py);
        int bz = (int) Math.floor(pz);
        double goalDist = currentGoal.heuristic(bx, by, bz);
        if (goalDist >= 1_000_000) {
            ChatUtils.message("ETA: goal is at infinity");
            return;
        }
        double ticksPerBlock = sprintEnabled ? 3.564 : 4.633;
        double estTicks = goalDist * ticksPerBlock;
        double estSeconds = estTicks / 20.0;
        if (estSeconds < 60) {
            ChatUtils.message("ETA: ~" + (int) estSeconds + "s (" + (int) goalDist + " blocks)");
        } else if (estSeconds < 3600) {
            ChatUtils.message("ETA: ~" + (int) (estSeconds / 60) + "m " + (int) (estSeconds % 60) + "s (" + (int) goalDist + " blocks)");
        } else {
            ChatUtils.message("ETA: ~" + (int) (estSeconds / 3600) + "h " + (int) ((estSeconds % 3600) / 60) + "m (" + (int) goalDist + " blocks)");
        }
    }

    public void cmdFind(String[] args) {
        if (args.length < 1) {
            ChatUtils.error("Usage: #find <block>");
            return;
        }
        Block block = getBlockByName(args[0]);
        if (block == null) {
            ChatUtils.error("Unknown block: " + args[0]);
            return;
        }
        if (!nullCheck())
            return;
        int px = (int) Math.floor(mc.player.posX);
        int py = (int) Math.floor(mc.player.posY);
        int pz = (int) Math.floor(mc.player.posZ);
        int radius = mineRadius;
        int[] best = null;
        double bestDist = Double.MAX_VALUE;
        for (int x = px - radius; x <= px + radius; x++) {
            for (int z = pz - radius; z <= pz + radius; z++) {
                for (int y = 0; y <= 255; y++) {
                    if (BlockAccess.getBlock(x, y, z) == block) {
                        double d = (x - px) * (x - px) + (y - py) * (y - py) + (z - pz) * (z - pz);
                        if (d < bestDist) {
                            bestDist = d;
                            best = new int[] { x, y, z };
                        }
                    }
                }
            }
        }
        if (best != null) {
            ChatUtils.success(args[0] + " found at: " + best[0] + " " + best[1] + " " + best[2] + " (dist: " + (int) Math.sqrt(bestDist) + ")");
        } else {
            ChatUtils.error(args[0] + " not found within " + radius + " blocks (try #set mineradius)");
        }
    }

    public void cmdRepack() {
        if (!nullCheck())
            return;
        int cx = (int) Math.floor(mc.player.posX) >> 4;
        int cz = (int) Math.floor(mc.player.posZ) >> 4;
        int count = 0;
        int r = mc.gameSettings != null ? mc.gameSettings.renderDistanceChunks : 8;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                BlockAccess.repackChunk(cx + dx, cz + dz);
                count++;
            }
        }
        ChatUtils.success("Repacked " + count + " chunks");
    }

    public void cmdGc() {
        long before = Runtime.getRuntime().freeMemory();
        System.gc();
        long after = Runtime.getRuntime().freeMemory();
        long freed = (after - before) / 1024 / 1024;
        ChatUtils.success("GC freed ~" + freed + " MB");
    }

    public void cmdResetSettings() {
        pathTimeout = 20.0;
        sprintEnabled = true;
        renderPath = true;
        followDist = 2;
        mineRadius = 32;
        farmRadius = 16;
        autoReplant = true;
        allowBreak = true;
        allowPlace = true;
        allowParkour = false;
        allowDiagonalAscend = false;
        allowDiagonalDescend = false;
        allowDownward = true;
        allowInventory = false;
        autoTool = true;
        assumeStep = false;
        assumeSafeWalk = false;
        autoEat = true;
        autoEatThreshold = 18;
        avoidance = false;
        allowWaterBucketFall = true;
        legitMine = false;
        legitMineYLevel = 11;
        closeDoorOnArrival = false;
        blockBreakSpeed = 6;
        blockPlacementPenalty = 20.0;
        costHeuristic = 3.563;
        avoidBreakingMultiplier = 0.1;
        pathCutoffFactor = 0.9;
        minToolDurability = 1;
        blockReachDistance = 4.5;
        maxFallHeightNoWater = 3;
        allowParkourPlace = false;
        sprintAscends = true;
        blockBreakAdditionalPenalty = 2.0;
        jumpPenalty = 2.0;
        movementTimeoutTicks = 100;
        pathCutoffMinimumLength = 30;
        rightClickSpeed = 4;
        ChatUtils.success("All settings reset to defaults");
    }

    public void cmdSel(String[] args) {
        if (args.length < 1) {
            if (selPos1 == null && selPos2 == null) {
                ChatUtils.error("No selection");
                ChatUtils.message("Usage: #sel pos1 (or #sel 1)");
                ChatUtils.message("       #sel pos2 (or #sel 2)");
            } else {
                String p1 = selPos1 != null ? selPos1[0] + "," + selPos1[1] + "," + selPos1[2] : "not set";
                String p2 = selPos2 != null ? selPos2[0] + "," + selPos2[1] + "," + selPos2[2] : "not set";
                ChatUtils.message("Pos1: " + p1);
                ChatUtils.message("Pos2: " + p2);
                if (selPos1 != null && selPos2 != null) {
                    int minX = Math.min(selPos1[0], selPos2[0]);
                    int minY = Math.min(selPos1[1], selPos2[1]);
                    int minZ = Math.min(selPos1[2], selPos2[2]);
                    int maxX = Math.max(selPos1[0], selPos2[0]);
                    int maxY = Math.max(selPos1[1], selPos2[1]);
                    int maxZ = Math.max(selPos1[2], selPos2[2]);
                    long volume = (long) (maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1);
                    ChatUtils.message("Size: " + (maxX - minX + 1) + "x" + (maxY - minY + 1) + "x" + (maxZ - minZ + 1) + " (" + volume + " blocks)");
                }
            }
            return;
        }
        if (mc.player == null) {
            ChatUtils.error("Not in-game");
            return;
        }
        String sub = args[0].toLowerCase();
        if (sub.equals("pos1") || sub.equals("1") || sub.equals("p1")) {
            selPos1 = new int[] { (int) Math.floor(mc.player.posX), (int) Math.floor(mc.player.posY), (int) Math.floor(mc.player.posZ) };
            ChatUtils.success("Pos1 set at " + selPos1[0] + ", " + selPos1[1] + ", " + selPos1[2]);
        } else if (sub.equals("pos2") || sub.equals("2") || sub.equals("p2")) {
            selPos2 = new int[] { (int) Math.floor(mc.player.posX), (int) Math.floor(mc.player.posY), (int) Math.floor(mc.player.posZ) };
            ChatUtils.success("Pos2 set at " + selPos2[0] + ", " + selPos2[1] + ", " + selPos2[2]);
        } else if (sub.equals("clear") || sub.equals("c")) {
            selPos1 = null;
            selPos2 = null;
            ChatUtils.success("Selection cleared");
        } else {
            ChatUtils.error("Usage: #sel pos1/pos2/clear");
        }
    }

    private void cmdBuildSchem(String[] args) {
        SchematicData schem = SchematicManager.getActiveSchematic();
        if (schem == null) {
            ChatUtils.error("No schematic loaded. " + "Load one via Schematic Manager first.");
            return;
        }
        if (building) {
            stopBuild();
        }
        int offX = net.minecraft.schematic.SchematicRenderer.getRenderX();
        int offY = net.minecraft.schematic.SchematicRenderer.getRenderY();
        int offZ = net.minecraft.schematic.SchematicRenderer.getRenderZ();
        int w = schem.getWidth();
        int h = schem.getHeight();
        int l = schem.getLength();
        long volume = (long) w * h * l;
        if (volume > 10000) {
            ChatUtils.error("Schematic too large (max " + "10000 blocks, got " + volume + ")");
            return;
        }
        buildQueue.clear();
        buildQueueBlockIds.clear();
        int skipped = 0;
        for (int y = 0; y < h; y++) {
            for (int z = 0; z < l; z++) {
                for (int x = 0; x < w; x++) {
                    int id = schem.getBlockIdAt(x, y, z);
                    if (id == 0)
                        continue;
                    int worldX = x + offX;
                    int worldY = y + offY;
                    int worldZ = z + offZ;
                    Block current = BlockAccess.getBlockType(worldX, worldY, worldZ);
                    Block target = Block.getBlockById(id);
                    if (target != null && current == target) {
                        skipped++;
                        continue;
                    }
                    if (current != Blocks.AIR && !BlockAccess.canWalkThrough(worldX, worldY, worldZ) && current != target) {
                        skipped++;
                        continue;
                    }
                    buildQueue.add(new int[] { worldX, worldY, worldZ });
                    buildQueueBlockIds.add(id);
                }
            }
        }
        if (buildQueue.isEmpty()) {
            ChatUtils.error("No blocks to place " + "(" + skipped + " already correct, " + "no air positions available)");
            return;
        }
        buildQueue.clear();
        buildQueueBlockIds.clear();
        java.util.ArrayList<int[]> sorted = new java.util.ArrayList<int[]>();
        for (int y = 0; y < h; y++) {
            for (int z = 0; z < l; z++) {
                for (int x = 0; x < w; x++) {
                    int id = schem.getBlockIdAt(x, y, z);
                    if (id == 0)
                        continue;
                    int worldX = x + offX;
                    int worldY = y + offY;
                    int worldZ = z + offZ;
                    Block current = BlockAccess.getBlockType(worldX, worldY, worldZ);
                    Block target = Block.getBlockById(id);
                    if (target != null && current == target)
                        continue;
                    if (current != Blocks.AIR && !BlockAccess.canWalkThrough(worldX, worldY, worldZ) && current != target)
                        continue;
                    sorted.add(new int[] { worldX, worldY, worldZ, id });
                }
            }
        }
        final double px2 = mc.player.posX;
        final double pz2 = mc.player.posZ;
        sorted.sort((a, b) -> {
            if (a[1] != b[1])
                return a[1] - b[1];
            double da = (a[0] + 0.5 - px2) * (a[0] + 0.5 - px2) + (a[2] + 0.5 - pz2) * (a[2] + 0.5 - pz2);
            double db = (b[0] + 0.5 - px2) * (b[0] + 0.5 - px2) + (b[2] + 0.5 - pz2) * (b[2] + 0.5 - pz2);
            return Double.compare(da, db);
        });
        for (int[] s : sorted) {
            buildQueue.add(new int[] { s[0], s[1], s[2] });
            buildQueueBlockIds.add(s[3]);
        }
        java.util.HashSet<Integer> hasBlocks = new java.util.HashSet<Integer>();
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (!stack.func_190926_b()) {
                Block ib = Block.getBlockFromItem(stack.getItem());
                if (ib != null) {
                    hasBlocks.add(Block.getIdFromBlock(ib));
                }
            }
        }
        int canPlace = 0;
        for (int id : buildQueueBlockIds) {
            if (hasBlocks.contains(id))
                canPlace++;
        }
        buildMode = BUILD_SCHEM;
        buildSchematic = true;
        buildBlock = null;
        buildIndex = 0;
        blocksPlaced = 0;
        building = true;
        ChatUtils.success("Schematic build: " + buildQueue.size() + " blocks (" + canPlace + " have materials, " + skipped + " skipped)");
        goalDescription = "Building schematic: " + schem.getName();
        startBuildNavigation();
    }

    private int findHotbarSlotForBlock(Block block) {
        if (block == null)
            return -1;
        int targetId = Block.getIdFromBlock(block);
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (stack.func_190926_b())
                continue;
            Block ib = Block.getBlockFromItem(stack.getItem());
            if (ib != null && Block.getIdFromBlock(ib) == targetId) {
                return i;
            }
        }
        return -1;
    }

    public void cmdBuild(String[] args) {
        if (args.length < 1) {
            ChatUtils.message("Build commands:");
            ChatUtils.message(" #build fill <block> - fill selection");
            ChatUtils.message(" #build walls <block> - hollow walls");
            ChatUtils.message(" #build floor <block> - floor only");
            ChatUtils.message(" #build clear - break all in sel");
            ChatUtils.message(" #build rotate <0/90/180/270>");
            ChatUtils.message(" #build mirror <x/z/both/none>");
            ChatUtils.message(" #build layers <block> - layer-by-layer");
            ChatUtils.message(" #build schem - build loaded schematic");
            return;
        }
        String sub = args[0].toLowerCase();
        if (sub.equals("schem")) {
            cmdBuildSchem(args);
            return;
        }
        if (sub.equals("rotate")) {
            if (args.length < 2) {
                ChatUtils.message("Rotation: " + buildRotation + " degrees");
                return;
            }
            try {
                int rot = Integer.parseInt(args[1]);
                if (rot != 0 && rot != 90 && rot != 180 && rot != 270) {
                    ChatUtils.error("Rotation must be 0, 90, 180, or 270");
                    return;
                }
                buildRotation = rot;
                ChatUtils.success("Build rotation set to " + rot + " degrees");
            } catch (NumberFormatException e) {
                ChatUtils.error("Invalid number");
            }
            return;
        }
        if (sub.equals("mirror")) {
            if (args.length < 2) {
                ChatUtils.message("Mirror X: " + buildMirrorX + ", Z: " + buildMirrorZ);
                return;
            }
            String m = args[1].toLowerCase();
            if (m.equals("x")) {
                buildMirrorX = true;
                buildMirrorZ = false;
            } else if (m.equals("z")) {
                buildMirrorX = false;
                buildMirrorZ = true;
            } else if (m.equals("both")) {
                buildMirrorX = true;
                buildMirrorZ = true;
            } else if (m.equals("none") || m.equals("off")) {
                buildMirrorX = false;
                buildMirrorZ = false;
            } else {
                ChatUtils.error("Usage: #build mirror <x/z/both/none>");
                return;
            }
            ChatUtils.success("Mirror X: " + buildMirrorX + ", Z: " + buildMirrorZ);
            return;
        }
        if (building) {
            stopBuild();
        }
        if (sub.equals("clear")) {
            if (selPos1 == null || selPos2 == null) {
                ChatUtils.error("Set selection first (#sel)");
                return;
            }
            buildMode = BUILD_CLEAR;
            buildBlock = null;
            generateBuildQueue(BUILD_CLEAR);
            if (buildQueue.isEmpty()) {
                ChatUtils.error("No blocks to break in selection");
                return;
            }
            building = true;
            buildIndex = 0;
            blocksBroken = 0;
            ChatUtils.success("Breaking " + buildQueue.size() + " blocks");
            startBuildNavigation();
            return;
        }
        if (args.length < 2) {
            ChatUtils.error("Usage: #build " + sub + " <block>");
            return;
        }
        if (selPos1 == null || selPos2 == null) {
            ChatUtils.error("Set selection first (#sel)");
            return;
        }
        String blockName = args[1].toUpperCase();
        if (args.length > 2) {
            StringBuilder sb = new StringBuilder(blockName);
            for (int i = 2; i < args.length; i++) {
                sb.append("_").append(args[i].toUpperCase());
            }
            blockName = sb.toString();
        }
        Block target = getBlockByName(blockName);
        if (target == null) {
            target = getBlockByName(args[1].toUpperCase());
        }
        if (target == null) {
            ChatUtils.error("Unknown block: " + args[1]);
            return;
        }
        int mode;
        if (sub.equals("fill") || sub.equals("f")) {
            mode = BUILD_FILL;
        } else if (sub.equals("walls") || sub.equals("w")) {
            mode = BUILD_WALLS;
        } else if (sub.equals("floor")) {
            mode = BUILD_FLOOR;
        } else if (sub.equals("ceiling")) {
            mode = BUILD_CEILING;
        } else {
            ChatUtils.error("Usage: #build fill/walls/floor/clear" + "/ceiling");
            return;
        }
        buildMode = mode;
        buildBlock = target;
        generateBuildQueue(mode);
        if (buildQueue.isEmpty()) {
            ChatUtils.error("No positions to build");
            return;
        }
        building = true;
        buildIndex = 0;
        blocksPlaced = 0;
        goalDescription = "Building " + target.getLocalizedName();
        ChatUtils.success("Build queue: " + buildQueue.size() + " positions");
        startBuildNavigation();
    }

    private void generateBuildQueue(int mode) {
        buildQueue.clear();
        if (selPos1 == null || selPos2 == null)
            return;
        int minX = Math.min(selPos1[0], selPos2[0]);
        int minY = Math.min(selPos1[1], selPos2[1]);
        int minZ = Math.min(selPos1[2], selPos2[2]);
        int maxX = Math.max(selPos1[0], selPos2[0]);
        int maxY = Math.max(selPos1[1], selPos2[1]);
        int maxZ = Math.max(selPos1[2], selPos2[2]);
        int cx = (minX + maxX) / 2;
        int cz = (minZ + maxZ) / 2;
        long volume = (long) (maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1);
        if (volume > 10000) {
            ChatUtils.error("Selection too large (max 10000 blocks)");
            return;
        }
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    boolean include = false;
                    boolean isEdgeX = (x == minX || x == maxX);
                    boolean isEdgeY = (y == minY || y == maxY);
                    boolean isEdgeZ = (z == minZ || z == maxZ);
                    switch(mode) {
                        case BUILD_FILL:
                            include = true;
                            break;
                        case BUILD_WALLS:
                            include = isEdgeX || isEdgeY || isEdgeZ;
                            break;
                        case BUILD_FLOOR:
                            include = (y == minY);
                            break;
                        case BUILD_CEILING:
                            include = (y == maxY);
                            break;
                        case BUILD_CLEAR:
                            include = true;
                            break;
                    }
                    if (!include)
                        continue;
                    if (mode != BUILD_CLEAR) {
                        Block current = BlockAccess.getBlockType(x, y, z);
                        if (current == buildBlock)
                            continue;
                        if (current != Blocks.AIR && !BlockAccess.canWalkThrough(x, y, z)) {
                            continue;
                        }
                    } else {
                        Block current = BlockAccess.getBlockType(x, y, z);
                        if (current == Blocks.AIR)
                            continue;
                    }
                    int tx = x - cx;
                    int tz = z - cz;
                    if (buildMirrorX)
                        tx = -tx;
                    if (buildMirrorZ)
                        tz = -tz;
                    if (buildRotation == 90) {
                        int tmp = tx;
                        tx = -tz;
                        tz = tmp;
                    } else if (buildRotation == 180) {
                        tx = -tx;
                        tz = -tz;
                    } else if (buildRotation == 270) {
                        int tmp = tx;
                        tx = tz;
                        tz = -tmp;
                    }
                    int fx = tx + cx;
                    int fz = tz + cz;
                    buildQueue.add(new int[] { fx, y, fz });
                }
            }
        }
        buildRotation = 0;
        buildMirrorX = false;
        buildMirrorZ = false;
        final java.util.ArrayList<int[]> q = buildQueue;
        final double playerX = mc.player.posX;
        final double playerZ = mc.player.posZ;
        q.sort((a, b) -> {
            if (a[1] != b[1])
                return a[1] - b[1];
            double da = (a[0] + 0.5 - playerX) * (a[0] + 0.5 - playerX) + (a[2] + 0.5 - playerZ) * (a[2] + 0.5 - playerZ);
            double db = (b[0] + 0.5 - playerX) * (b[0] + 0.5 - playerX) + (b[2] + 0.5 - playerZ) * (b[2] + 0.5 - playerZ);
            return Double.compare(da, db);
        });
    }

    private void startBuildNavigation() {
        if (buildIndex >= buildQueue.size()) {
            finishBuild();
            return;
        }
        int[] target = buildQueue.get(buildIndex);
        int[] standPos = findBuildStandPos(target[0], target[1], target[2]);
        if (standPos == null) {
            ChatUtils.message("Skipping unreachable: " + target[0] + "," + target[1] + "," + target[2]);
            buildIndex++;
            startBuildNavigation();
            return;
        }
        if (mining) {
            stopMining();
        }
        currentGoal = new GoalBlock(standPos[0], standPos[1], standPos[2]);
        goalDescription = "Build step " + (buildIndex + 1) + "/" + buildQueue.size();
        requestPath();
    }

    private int[] findBuildStandPos(int tx, int ty, int tz) {
        int[][] offsets = { { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 }, { 1, 1 }, { -1, 1 }, { 1, -1 }, { -1, -1 }, { 0, 0 } };
        int bestDist = Integer.MAX_VALUE;
        int[] best = null;
        int px = (int) Math.floor(mc.player.posX);
        int pz = (int) Math.floor(mc.player.posZ);
        for (int[] off : offsets) {
            int sx = tx + off[0];
            int sy = ty;
            int sz = tz + off[1];
            if (!BlockAccess.canWalkThrough(sx, sy, sz))
                continue;
            if (!BlockAccess.canWalkThrough(sx, sy + 1, sz))
                continue;
            if (!BlockAccess.canWalkOn(sx, sy - 1, sz))
                continue;
            if (!BlockAccess.isLoaded(sx, sz))
                continue;
            if (BlockAccess.isDangerous(sx, sy, sz))
                continue;
            int dist = Math.abs(sx - px) + Math.abs(sz - pz);
            if (dist < bestDist) {
                bestDist = dist;
                best = new int[] { sx, sy, sz };
            }
        }
        return best;
    }

    private void tickBuild() {
        if (!building)
            return;
        if (buildIndex >= buildQueue.size()) {
            finishBuild();
            return;
        }
        int[] target = buildQueue.get(buildIndex);
        double dx = (target[0] + 0.5) - mc.player.posX;
        double dy = (target[1] + 0.5) - (mc.player.posY + 1.62);
        double dz = (target[2] + 0.5) - mc.player.posZ;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist > BUILD_REACH) {
            if (!executor.hasPath()) {
                startBuildNavigation();
            }
            return;
        }
        if (buildPlaceTimer > 0) {
            buildPlaceTimer--;
            return;
        }
        if (buildMode == BUILD_CLEAR) {
            BlockPos bpos = new BlockPos(target[0], target[1], target[2]);
            float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
            mc.player.rotationYaw = yaw;
            mc.player.rotationPitch = (float) Math.toDegrees(-Math.asin(dy / dist));
            EnumFacing clearFace = findBestMineFace(bpos);
            if (clearFace == null) {
                buildPlaceTimer = 2;
                return;
            }
            mc.objectMouseOver = new RayTraceResult(new Vec3d(target[0] + 0.5 + clearFace.getFrontOffsetX() * 0.5, target[1] + 0.5 + clearFace.getFrontOffsetY() * 0.5, target[2] + 0.5 + clearFace.getFrontOffsetZ() * 0.5), clearFace, bpos);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), true);
            buildPlacing = true;
            buildPlaceTimer = 5;
        } else {
            if (buildSchematic && buildIndex < buildQueueBlockIds.size()) {
                int targetId = buildQueueBlockIds.get(buildIndex);
                Block targetBlock = Block.getBlockById(targetId);
                int slot = findHotbarSlotForBlock(targetBlock);
                if (slot == -1) {
                    ChatUtils.message("Skipping: no " + (targetBlock != null ? targetBlock.getLocalizedName() : "block id " + targetId) + " in hotbar");
                    buildIndex++;
                    if (buildIndex >= buildQueue.size()) {
                        finishBuild();
                    } else {
                        startBuildNavigation();
                    }
                    return;
                }
                mc.player.inventory.currentItem = slot;
            }
            BlockPos adjPos = findAdjacentBlock(target[0], target[1], target[2]);
            if (adjPos == null) {
                buildIndex++;
                startBuildNavigation();
                return;
            }
            EnumFacing face = getFaceTowards(adjPos.getX(), adjPos.getY(), adjPos.getZ(), target[0], target[1], target[2]);
            float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
            mc.player.rotationYaw = yaw;
            mc.player.rotationPitch = (float) Math.toDegrees(-Math.asin(dy / dist));
            InteractionUtils.placeBlock(adjPos, face);
            blocksPlaced++;
            buildPlacing = false;
            buildPlaceTimer = 3;
            BlockAccess.invalidateAt(target[0], target[1], target[2]);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
            buildIndex++;
            if (buildIndex >= buildQueue.size()) {
                finishBuild();
            } else {
                startBuildNavigation();
            }
        }
    }

    private BlockPos findAdjacentBlock(int tx, int ty, int tz) {
        int[][] faces = { { 0, -1, 0 }, { 0, 1, 0 }, { 0, 0, -1 }, { 0, 0, 1 }, { -1, 0, 0 }, { 1, 0, 0 } };
        for (int[] f : faces) {
            int ax = tx + f[0];
            int ay = ty + f[1];
            int az = tz + f[2];
            Block atBlock = BlockAccess.getBlockType(ax, ay, az);
            if (atBlock != Blocks.AIR) {
                return new BlockPos(ax, ay, az);
            }
        }
        return null;
    }

    private EnumFacing getFaceTowards(int fx, int fy, int fz, int tx, int ty, int tz) {
        int dx = tx - fx;
        int dy = ty - fy;
        int dz = tz - fz;
        int adx = Math.abs(dx);
        int ady = Math.abs(dy);
        int adz = Math.abs(dz);
        if (ady >= adx && ady >= adz) {
            return dy > 0 ? EnumFacing.UP : EnumFacing.DOWN;
        } else if (adx >= adz) {
            return dx > 0 ? EnumFacing.EAST : EnumFacing.WEST;
        } else {
            return dz > 0 ? EnumFacing.SOUTH : EnumFacing.NORTH;
        }
    }

    private void checkBuildBreak() {
        if (!building || !buildPlacing || buildMode != BUILD_CLEAR)
            return;
        if (buildIndex >= buildQueue.size())
            return;
        int[] target = buildQueue.get(buildIndex);
        Block current = BlockAccess.getBlockType(target[0], target[1], target[2]);
        if (current == Blocks.AIR) {
            blocksBroken++;
            buildPlacing = false;
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
            buildIndex++;
            BlockAccess.invalidateAt(target[0], target[1], target[2]);
            if (buildIndex >= buildQueue.size()) {
                finishBuild();
            } else {
                startBuildNavigation();
            }
        }
    }

    private void finishBuild() {
        if (buildMode == BUILD_CLEAR) {
            ChatUtils.success("Build clear done: " + blocksBroken + " blocks broken");
        } else if (buildSchematic) {
            ChatUtils.success("Schematic build done: " + blocksPlaced + " blocks placed");
        } else {
            ChatUtils.success("Build done: " + blocksPlaced + " blocks placed");
        }
        building = false;
        buildPlacing = false;
        buildSchematic = false;
        buildQueue.clear();
        buildQueueBlockIds.clear();
        buildBlock = null;
        currentGoal = null;
        goalDescription = "";
        cancelPath();
    }

    private void stopBuild() {
        building = false;
        buildPlacing = false;
        buildSchematic = false;
        buildQueue.clear();
        buildQueueBlockIds.clear();
        buildBlock = null;
        blocksPlaced = 0;
        blocksBroken = 0;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
    }

    public void cmdCount(String[] args) {
        if (args.length < 1) {
            ChatUtils.error("Usage: #count <block> [radius]");
            return;
        }
        if (mc.world == null) {
            ChatUtils.error("Not in-game");
            return;
        }
        String blockName = args[0].toLowerCase().replace(" ", "_");
        Block block = getBlockByName(blockName);
        if (block == null) {
            if (blockName.equals("ores")) {
                int radius = 64;
                if (args.length >= 2) {
                    try {
                        radius = Integer.parseInt(args[1]);
                        radius = Math.max(8, Math.min(128, radius));
                    } catch (NumberFormatException e) {
                    }
                }
                int count = countBlocksOre(radius);
                ChatUtils.cmd("Found " + count + " ore(s) within " + radius + " blocks");
            } else {
                ChatUtils.error("Unknown block: " + blockName);
            }
            return;
        }
        int radius = 64;
        if (args.length >= 2) {
            try {
                radius = Integer.parseInt(args[1]);
                radius = Math.max(8, Math.min(128, radius));
            } catch (NumberFormatException e) {
                ChatUtils.error("Invalid radius");
                return;
            }
        }
        int count = countBlock(block, radius);
        ChatUtils.cmd("Found " + count + " " + blockName.replace("_", " ") + " within " + radius + " blocks");
    }

    private int countBlock(Block block, int radius) {
        if (mc.player == null || mc.world == null)
            return 0;
        int pcx = (int) Math.floor(mc.player.posX);
        int pcy = (int) Math.floor(mc.player.posY);
        int pcz = (int) Math.floor(mc.player.posZ);
        int count = 0;
        int chunkRadius = (radius >> 4) + 1;
        int yMin = Math.max(0, pcy - radius);
        int yMax = Math.min(255, pcy + radius);
        for (int cx = -chunkRadius; cx <= chunkRadius; cx++) {
            for (int cz = -chunkRadius; cz <= chunkRadius; cz++) {
                int chunkX = (pcx >> 4) + cx;
                int chunkZ = (pcz >> 4) + cz;
                Chunk chunk = mc.world.getChunkFromChunkCoords(chunkX, chunkZ);
                if (chunk == null || !chunk.isLoaded())
                    continue;
                for (int x = 0; x < 16; x++) {
                    for (int z = 0; z < 16; z++) {
                        for (int y = yMin; y <= yMax; y++) {
                            BlockPos pos = new BlockPos((chunkX << 4) + x, y, (chunkZ << 4) + z);
                            if (chunk.getBlockState(pos).getBlock() == block) {
                                count++;
                            }
                        }
                    }
                }
            }
        }
        return count;
    }

    private int countBlocksOre(int radius) {
        if (mc.player == null || mc.world == null)
            return 0;
        int pcx = (int) Math.floor(mc.player.posX);
        int pcy = (int) Math.floor(mc.player.posY);
        int pcz = (int) Math.floor(mc.player.posZ);
        int count = 0;
        int chunkRadius = (radius >> 4) + 1;
        int yMin = Math.max(0, pcy - radius);
        int yMax = Math.min(128, pcy + radius);
        for (int cx = -chunkRadius; cx <= chunkRadius; cx++) {
            for (int cz = -chunkRadius; cz <= chunkRadius; cz++) {
                int chunkX = (pcx >> 4) + cx;
                int chunkZ = (pcz >> 4) + cz;
                Chunk chunk = mc.world.getChunkFromChunkCoords(chunkX, chunkZ);
                if (chunk == null || !chunk.isLoaded())
                    continue;
                for (int x = 0; x < 16; x++) {
                    for (int z = 0; z < 16; z++) {
                        for (int y = yMin; y <= yMax; y++) {
                            BlockPos pos = new BlockPos((chunkX << 4) + x, y, (chunkZ << 4) + z);
                            if (isOre(chunk.getBlockState(pos).getBlock())) {
                                count++;
                            }
                        }
                    }
                }
            }
        }
        return count;
    }

    public void cmdBack() {
        pathFailed = false;
        pathFailCount = 0;
        if (deathPos == null) {
            ChatUtils.error("No death position recorded");
            ChatUtils.message("Die once first, then use #back");
            return;
        }
        if (mc.player == null) {
            ChatUtils.error("Not in-game");
            return;
        }
        int px = (int) Math.floor(mc.player.posX);
        int py = (int) Math.floor(mc.player.posY);
        int pz = (int) Math.floor(mc.player.posZ);
        if (px == deathPos[0] && py == deathPos[1] && pz == deathPos[2]) {
            ChatUtils.message("Already at last death position");
            return;
        }
        followTarget = "";
        exploring = false;
        mineTargetBlock = "";
        died = false;
        setGoal(new GoalBlock(deathPos[0], deathPos[1], deathPos[2]), "Back to death (" + deathPos[0] + ", " + deathPos[1] + ", " + deathPos[2] + ")");
        ChatUtils.success("Returning to death position (" + deathPos[0] + ", " + deathPos[1] + ", " + deathPos[2] + ")");
    }

    public void cmdGoal(String[] args) {
        if (mc.player == null) {
            ChatUtils.error("Not in-game");
            return;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("clear")) {
            currentGoal = null;
            goalDescription = "";
            cancelPath();
            ChatUtils.success("Goal cleared");
            return;
        }
        if (args.length >= 1) {
            try {
                if (args.length == 1) {
                    int y = Integer.parseInt(args[0]);
                    setGoal(new GoalYLevel(y), "Goal Y=" + y);
                    ChatUtils.success("Goal set: Y=" + y);
                    return;
                } else if (args.length == 2) {
                    int x = Integer.parseInt(args[0]);
                    int z = Integer.parseInt(args[1]);
                    setGoal(new GoalXZ(x, z), "Goal XZ " + x + " " + z);
                    ChatUtils.success("Goal set: XZ " + x + ", " + z);
                    return;
                } else {
                    int x = Integer.parseInt(args[0]);
                    int y = Integer.parseInt(args[1]);
                    int z = Integer.parseInt(args[2]);
                    setGoal(new GoalBlock(x, y, z), "Goal " + x + " " + y + " " + z);
                    ChatUtils.success("Goal set: " + x + ", " + y + ", " + z);
                    return;
                }
            } catch (NumberFormatException e) {
                ChatUtils.error("Invalid coordinates");
                return;
            }
        }
        if (currentGoal == null && followTarget.isEmpty() && !exploring && deathPos == null) {
            ChatUtils.message("No goal set. Use #goto or #follow");
            return;
        }
        if (currentGoal == null && followTarget.isEmpty() && !exploring) {
            ChatUtils.message("Death position: " + deathPos[0] + ", " + deathPos[1] + ", " + deathPos[2]);
            ChatUtils.message("Use #back to return");
            return;
        }
        ChatUtils.message("Goal: " + goalDescription);
        ChatUtils.message("Module: " + (isToggled() ? "ON" : "OFF"));
        if (exploring) {
            ChatUtils.message("Explore progress: " + exploreIndex + "/" + exploreTargetsX.length);
        }
        if (blocksMined > 0) {
            ChatUtils.message("Blocks mined: " + blocksMined);
        }
        if (cropsHarvested > 0) {
            ChatUtils.message("Crops harvested: " + cropsHarvested);
        }
        if (deathPos != null) {
            ChatUtils.message("Death pos: " + deathPos[0] + ", " + deathPos[1] + ", " + deathPos[2]);
        }
        if (executor.hasPath()) {
            ChatUtils.message("Progress: " + String.format("%.0f%%", executor.getProgress() * 100));
            int[] dest = executor.getDestination();
            if (dest != null) {
                ChatUtils.message("Destination: " + dest[0] + ", " + dest[1] + ", " + dest[2]);
            }
        } else if (pathRequested) {
            ChatUtils.message("Status: calculating path...");
        } else if (pathCompleted) {
            ChatUtils.message("Status: arrived");
        } else {
            ChatUtils.message("Status: idle (toggle module to execute)");
        }
    }

    public void cmdPath() {
        if (!executor.hasPath() && !pathRequested) {
            ChatUtils.message("No path");
            return;
        }
        if (pathRequested && finder != null) {
            ChatUtils.message("Path: calculating...");
            ChatUtils.message("Nodes explored: " + finder.getNumNodes());
        }
        if (executor.hasPath()) {
            Path p = executor.getPath();
            ChatUtils.message("Path length: " + p.length() + " positions");
            ChatUtils.message("Progress: " + String.format("%.0f%%", executor.getProgress() * 100));
            int remaining = p.length() - executor.getCurrentTargetIndex();
            double eta = remaining * 0.35;
            if (eta > 60) {
                ChatUtils.message("ETA: " + String.format("%.1f", eta / 60.0) + "m");
            } else {
                ChatUtils.message("ETA: " + String.format("%.0f", eta) + "s");
            }
        }
    }

    private static final String SET_HELP = "Settings: timeout, sprint, render, followdist," + " mineradius, farmradius, replant, timer," + " allowBreak, allowPlace, allowParkour," + " allowParkourPlace, sprintAscends," + " allowDiagonalAscend, allowDiagonalDescend," + " allowDownward, allowInventory, autoTool," + " assumeStep, assumeSafeWalk, autoEat," + " autoEatThreshold, avoidance," + " allowWaterBucketFall, legitMine," + " legitMineYLevel, closeDoor," + " blockBreakSpeed, blockPlacementPenalty," + " blockBreakAdditionalPenalty, jumpPenalty," + " costHeuristic, avoidBreakingMultiplier," + " pathCutoffFactor, pathCutoffMinimumLength," + " movementTimeoutTicks, rightClickSpeed," + " minToolDurability, nodesPerTick, maxNodes," + " stuckThreshold, blockReachDistance," + " maxFallHeightNoWater";

    public void cmdSet(String[] args) {
        if (args.length < 1) {
            ChatUtils.message("Usage: #set <setting> [value]");
            ChatUtils.message(SET_HELP);
            return;
        }
        String setting = args[0].toLowerCase();
        if (setting.equals("timer")) {
            showTimer = !showTimer;
            ChatUtils.success("Timer " + (showTimer ? "ON" : "OFF"));
            return;
        }
        if (args.length == 1) {
            BooleanSettingResult r = toggleBoolSetting(setting);
            if (r != null) {
                ChatUtils.success(setting + " = " + r.value);
                return;
            }
            ChatUtils.error("Usage: #set <setting> <value>");
            ChatUtils.message(SET_HELP);
            return;
        }
        String value = args[1].toLowerCase();
        BooleanSettingResult br = setBoolSetting(setting, value);
        if (br != null) {
            ChatUtils.success(setting + " = " + br.value);
            return;
        }
        switch(setting) {
            case "timeout":
                try {
                    double v = Double.parseDouble(value);
                    pathTimeout = Math.max(1, Math.min(30, v));
                    ChatUtils.success("timeout = " + (int) pathTimeout + "s");
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "radius":
                try {
                    int r = Integer.parseInt(value);
                    r = Math.max(8, Math.min(128, r));
                    ChatUtils.success("radius = " + r);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "retries":
                try {
                    int r = Integer.parseInt(value);
                    r = Math.max(0, Math.min(10, r));
                    ChatUtils.success("retries = " + r);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "followdist":
                try {
                    int d = Integer.parseInt(value);
                    d = Math.max(1, Math.min(10, d));
                    followDist = d;
                    ChatUtils.success("followdist = " + d);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "mineradius":
                try {
                    int r = Integer.parseInt(value);
                    mineRadius = Math.max(1, Math.min(128, r));
                    ChatUtils.success("mineradius = " + mineRadius);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "farmradius":
                try {
                    int r = Integer.parseInt(value);
                    farmRadius = Math.max(1, Math.min(128, r));
                    ChatUtils.success("farmradius = " + farmRadius);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "blockbreakspeed":
                try {
                    int r = Integer.parseInt(value);
                    blockBreakSpeed = Math.max(1, r);
                    ChatUtils.success("blockBreakSpeed = " + blockBreakSpeed);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "blockplacementpenalty":
                try {
                    double d = Double.parseDouble(value);
                    blockPlacementPenalty = Math.max(0, d);
                    ChatUtils.success("blockPlacementPenalty = " + blockPlacementPenalty);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "costheuristic":
                try {
                    double d = Double.parseDouble(value);
                    costHeuristic = Math.max(1.0, Math.min(10.0, d));
                    ChatUtils.success("costHeuristic = " + costHeuristic);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "avoidbreakingmultiplier":
                try {
                    double d = Double.parseDouble(value);
                    avoidBreakingMultiplier = Math.max(0, d);
                    ChatUtils.success("avoidBreakingMultiplier = " + avoidBreakingMultiplier);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "pathcutofffactor":
                try {
                    double d = Double.parseDouble(value);
                    pathCutoffFactor = Math.max(0.1, Math.min(1.0, d));
                    ChatUtils.success("pathCutoffFactor = " + pathCutoffFactor);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "mintooldurability":
                try {
                    int n = Integer.parseInt(value);
                    minToolDurability = Math.max(0, n);
                    ChatUtils.success("minToolDurability = " + minToolDurability);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "blockreachdistance":
                try {
                    double d = Double.parseDouble(value);
                    blockReachDistance = Math.max(1, Math.min(6, d));
                    ChatUtils.success("blockReachDistance = " + blockReachDistance);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "maxfallheightnowater":
                try {
                    int r = Integer.parseInt(value);
                    maxFallHeightNoWater = Math.max(1, Math.min(256, r));
                    ChatUtils.success("maxFallHeightNoWater = " + maxFallHeightNoWater);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "blockbreakadditionalpenalty":
                try {
                    double d = Double.parseDouble(value);
                    blockBreakAdditionalPenalty = Math.max(0, d);
                    ChatUtils.success("blockBreakAdditionalPenalty = " + blockBreakAdditionalPenalty);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "jumppenalty":
                try {
                    double d = Double.parseDouble(value);
                    jumpPenalty = Math.max(0, d);
                    ChatUtils.success("jumpPenalty = " + jumpPenalty);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "movementtimeoutticks":
                try {
                    int r = Integer.parseInt(value);
                    movementTimeoutTicks = Math.max(10, Math.min(600, r));
                    ChatUtils.success("movementTimeoutTicks = " + movementTimeoutTicks);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "pathcutoffminimumlength":
                try {
                    int r = Integer.parseInt(value);
                    pathCutoffMinimumLength = Math.max(5, Math.min(1000, r));
                    ChatUtils.success("pathCutoffMinimumLength = " + pathCutoffMinimumLength);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "rightclickspeed":
                try {
                    int r = Integer.parseInt(value);
                    rightClickSpeed = Math.max(1, Math.min(20, r));
                    ChatUtils.success("rightClickSpeed = " + rightClickSpeed);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "nodespertick":
                try {
                    int r = Integer.parseInt(value);
                    nodesPerTick = Math.max(100, Math.min(10000, r));
                    ChatUtils.success("nodesPerTick = " + nodesPerTick);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "maxnodes":
                try {
                    int r = Integer.parseInt(value);
                    AStarPathFinder.cfgMaxNodes = Math.max(1000, Math.min(1000000, r));
                    ChatUtils.success("maxNodes = " + AStarPathFinder.cfgMaxNodes);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "stuckthreshold":
                try {
                    int r = Integer.parseInt(value);
                    PathExecutor.cfgStuckThreshold = Math.max(5, Math.min(200, r));
                    ChatUtils.success("stuckThreshold = " + PathExecutor.cfgStuckThreshold);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "autoeatthreshold":
                try {
                    int r = Integer.parseInt(value);
                    autoEatThreshold = Math.max(1, Math.min(20, r));
                    ChatUtils.success("autoEatThreshold = " + autoEatThreshold);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "legitmineylevel":
                try {
                    int r = Integer.parseInt(value);
                    legitMineYLevel = Math.max(0, Math.min(255, r));
                    ChatUtils.success("legitMineYLevel = " + legitMineYLevel);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "costverificationlookahead":
                try {
                    int r = Integer.parseInt(value);
                    costVerificationLookahead = Math.max(0, Math.min(50, r));
                    ChatUtils.success("costVerificationLookahead = " + costVerificationLookahead);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            case "backtrackcostfavoringcoefficient":
                try {
                    double d = Double.parseDouble(value);
                    backtrackCostFavoringCoefficient = Math.max(0, Math.min(2.0, d));
                    ChatUtils.success("backtrackCostFavoringCoefficient = " + backtrackCostFavoringCoefficient);
                } catch (NumberFormatException e) {
                    ChatUtils.error("Invalid number");
                }
                break;
            default:
                ChatUtils.error("Unknown setting: " + setting);
                ChatUtils.message(SET_HELP);
                break;
        }
    }

    private static class BooleanSettingResult {

        final boolean value;

        BooleanSettingResult(boolean v) {
            value = v;
        }
    }

    private BooleanSettingResult toggleBoolSetting(String name) {
        switch(name) {
            case "allowbreak":
                allowBreak = !allowBreak;
                return new BooleanSettingResult(allowBreak);
            case "allowplace":
                allowPlace = !allowPlace;
                return new BooleanSettingResult(allowPlace);
            case "allowparkour":
                allowParkour = !allowParkour;
                return new BooleanSettingResult(allowParkour);
            case "allowdiagonalascend":
                allowDiagonalAscend = !allowDiagonalAscend;
                return new BooleanSettingResult(allowDiagonalAscend);
            case "allowdiagonaldescend":
                allowDiagonalDescend = !allowDiagonalDescend;
                return new BooleanSettingResult(allowDiagonalDescend);
            case "allowdownward":
                allowDownward = !allowDownward;
                return new BooleanSettingResult(allowDownward);
            case "allowinventory":
                allowInventory = !allowInventory;
                return new BooleanSettingResult(allowInventory);
            case "autotool":
                autoTool = !autoTool;
                return new BooleanSettingResult(autoTool);
            case "assumestep":
                assumeStep = !assumeStep;
                return new BooleanSettingResult(assumeStep);
            case "assumesafewalk":
                assumeSafeWalk = !assumeSafeWalk;
                return new BooleanSettingResult(assumeSafeWalk);
            case "sprint":
                sprintEnabled = !sprintEnabled;
                return new BooleanSettingResult(sprintEnabled);
            case "render":
                renderPath = !renderPath;
                return new BooleanSettingResult(renderPath);
            case "replant":
                autoReplant = !autoReplant;
                return new BooleanSettingResult(autoReplant);
            case "autoeat":
                autoEat = !autoEat;
                return new BooleanSettingResult(autoEat);
            case "avoidance":
                avoidance = !avoidance;
                return new BooleanSettingResult(avoidance);
            case "allowwaterbucketfall":
                allowWaterBucketFall = !allowWaterBucketFall;
                return new BooleanSettingResult(allowWaterBucketFall);
            case "legitmine":
                legitMine = !legitMine;
                return new BooleanSettingResult(legitMine);
            case "closedoor":
                closeDoorOnArrival = !closeDoorOnArrival;
                return new BooleanSettingResult(closeDoorOnArrival);
            case "allowparkourplace":
                allowParkourPlace = !allowParkourPlace;
                return new BooleanSettingResult(allowParkourPlace);
            case "sprintascends":
                sprintAscends = !sprintAscends;
                return new BooleanSettingResult(sprintAscends);
            case "allowsprint":
                allowSprint = !allowSprint;
                return new BooleanSettingResult(allowSprint);
            case "allowparkourascend":
                allowParkourAscend = !allowParkourAscend;
                return new BooleanSettingResult(allowParkourAscend);
            case "allowovershootdiagonaldescend":
                allowOvershootDiagonalDescend = !allowOvershootDiagonalDescend;
                return new BooleanSettingResult(allowOvershootDiagonalDescend);
            case "allowplaceinfluidsflow":
                allowPlaceInFluidsFlow = !allowPlaceInFluidsFlow;
                return new BooleanSettingResult(allowPlaceInFluidsFlow);
            case "allowplaceinfluidssource":
                allowPlaceInFluidsSource = !allowPlaceInFluidsSource;
                return new BooleanSettingResult(allowPlaceInFluidsSource);
            case "allowwalkonbottomslab":
                allowWalkOnBottomSlab = !allowWalkOnBottomSlab;
                return new BooleanSettingResult(allowWalkOnBottomSlab);
            case "avoidupdatingfallingblocks":
                avoidUpdatingFallingBlocks = !avoidUpdatingFallingBlocks;
                return new BooleanSettingResult(avoidUpdatingFallingBlocks);
            case "backfill":
                backfill = !backfill;
                return new BooleanSettingResult(backfill);
            case "cancelongoalinvalidation":
                cancelOnGoalInvalidation = !cancelOnGoalInvalidation;
                return new BooleanSettingResult(cancelOnGoalInvalidation);
            case "minescandropppeditems":
                mineScanDroppedItems = !mineScanDroppedItems;
                return new BooleanSettingResult(mineScanDroppedItems);
            case "considerpotioneffects":
                considerPotionEffects = !considerPotionEffects;
                return new BooleanSettingResult(considerPotionEffects);
            case "smoothlook":
                smoothLook = !smoothLook;
                return new BooleanSettingResult(smoothLook);
            case "freelook":
                freeLook = !freeLook;
                return new BooleanSettingResult(freeLook);
            case "allowvines":
                allowVines = !allowVines;
                return new BooleanSettingResult(allowVines);
            case "blacklistclosestonfailure":
                blacklistClosestOnFailure = !blacklistClosestOnFailure;
                return new BooleanSettingResult(blacklistClosestOnFailure);
            default:
                return null;
        }
    }

    private BooleanSettingResult setBoolSetting(String name, String value) {
        boolean v;
        if (value.equals("true") || value.equals("on") || value.equals("1")) {
            v = true;
        } else if (value.equals("false") || value.equals("off") || value.equals("0")) {
            v = false;
        } else {
            return null;
        }
        switch(name) {
            case "allowbreak":
                allowBreak = v;
                return new BooleanSettingResult(v);
            case "allowplace":
                allowPlace = v;
                return new BooleanSettingResult(v);
            case "allowparkour":
                allowParkour = v;
                return new BooleanSettingResult(v);
            case "allowdiagonalascend":
                allowDiagonalAscend = v;
                return new BooleanSettingResult(v);
            case "allowdiagonaldescend":
                allowDiagonalDescend = v;
                return new BooleanSettingResult(v);
            case "allowdownward":
                allowDownward = v;
                return new BooleanSettingResult(v);
            case "allowinventory":
                allowInventory = v;
                return new BooleanSettingResult(v);
            case "autotool":
                autoTool = v;
                return new BooleanSettingResult(v);
            case "assumestep":
                assumeStep = v;
                return new BooleanSettingResult(v);
            case "assumesafewalk":
                assumeSafeWalk = v;
                return new BooleanSettingResult(v);
            case "sprint":
                sprintEnabled = v;
                return new BooleanSettingResult(v);
            case "render":
                renderPath = v;
                return new BooleanSettingResult(v);
            case "replant":
                autoReplant = v;
                return new BooleanSettingResult(v);
            case "autoeat":
                autoEat = v;
                return new BooleanSettingResult(v);
            case "avoidance":
                avoidance = v;
                return new BooleanSettingResult(v);
            case "allowwaterbucketfall":
                allowWaterBucketFall = v;
                return new BooleanSettingResult(v);
            case "legitmine":
                legitMine = v;
                return new BooleanSettingResult(v);
            case "closedoor":
                closeDoorOnArrival = v;
                return new BooleanSettingResult(v);
            case "allowparkourplace":
                allowParkourPlace = v;
                return new BooleanSettingResult(v);
            case "sprintascends":
                sprintAscends = v;
                return new BooleanSettingResult(v);
            case "allowsprint":
                allowSprint = v;
                return new BooleanSettingResult(v);
            case "allowparkourascend":
                allowParkourAscend = v;
                return new BooleanSettingResult(v);
            case "allowovershootdiagonaldescend":
                allowOvershootDiagonalDescend = v;
                return new BooleanSettingResult(v);
            case "allowplaceinfluidsflow":
                allowPlaceInFluidsFlow = v;
                return new BooleanSettingResult(v);
            case "allowplaceinfluidssource":
                allowPlaceInFluidsSource = v;
                return new BooleanSettingResult(v);
            case "allowwalkonbottomslab":
                allowWalkOnBottomSlab = v;
                return new BooleanSettingResult(v);
            case "avoidupdatingfallingblocks":
                avoidUpdatingFallingBlocks = v;
                return new BooleanSettingResult(v);
            case "backfill":
                backfill = v;
                return new BooleanSettingResult(v);
            case "cancelongoalinvalidation":
                cancelOnGoalInvalidation = v;
                return new BooleanSettingResult(v);
            case "minescandropppeditems":
                mineScanDroppedItems = v;
                return new BooleanSettingResult(v);
            case "considerpotioneffects":
                considerPotionEffects = v;
                return new BooleanSettingResult(v);
            case "smoothlook":
                smoothLook = v;
                return new BooleanSettingResult(v);
            case "freelook":
                freeLook = v;
                return new BooleanSettingResult(v);
            case "allowvines":
                allowVines = v;
                return new BooleanSettingResult(v);
            case "blacklistclosestonfailure":
                blacklistClosestOnFailure = v;
                return new BooleanSettingResult(v);
            default:
                return null;
        }
    }

    public void cmdWaypoint(String[] args) {
        if (args.length < 1) {
            ChatUtils.error("Usage: #wp save <name>");
            ChatUtils.error("       #wp here (auto-named)");
            ChatUtils.error("       #wp <name>  (go to waypoint)");
            ChatUtils.error("       #wp list");
            ChatUtils.error("       #wp del <name>");
            ChatUtils.error("       #wp clear");
            return;
        }
        if (mc.player == null) {
            ChatUtils.error("Not in-game");
            return;
        }
        String sub = args[0].toLowerCase();
        Waypoints wpMod = Waypoints.INSTANCE;
        if (wpMod == null) {
            ChatUtils.error("Waypoints module not available");
            return;
        }
        if (sub.equals("save") || sub.equals("s")) {
            if (args.length < 2) {
                ChatUtils.error("Usage: #wp save <name>");
                return;
            }
            String name = args[1].toLowerCase();
            if (wpMod.hasWaypoint(name)) {
                double x = mc.player.posX;
                double y = mc.player.posY;
                double z = mc.player.posZ;
                wpMod.addWaypoint(name, x, y, z);
                ChatUtils.success("Updated waypoint \"" + name + "\" at " + (int) Math.floor(x) + ", " + (int) Math.floor(y) + ", " + (int) Math.floor(z));
                return;
            }
            double x = mc.player.posX;
            double y = mc.player.posY;
            double z = mc.player.posZ;
            if (!wpMod.addWaypoint(name, x, y, z)) {
                ChatUtils.error("Too many waypoints (max 50)");
                return;
            }
            ChatUtils.success("Saved waypoint \"" + name + "\" at " + (int) Math.floor(x) + ", " + (int) Math.floor(y) + ", " + (int) Math.floor(z));
            return;
        }
        if (sub.equals("here") || sub.equals("h")) {
            String name = "WP-" + (wpMod.getWaypointCount() + 1);
            double x = mc.player.posX;
            double y = mc.player.posY;
            double z = mc.player.posZ;
            if (!wpMod.addWaypoint(name, x, y, z)) {
                ChatUtils.error("Too many waypoints (max 50)");
                return;
            }
            ChatUtils.success("Saved " + name + " at " + (int) Math.floor(x) + ", " + (int) Math.floor(y) + ", " + (int) Math.floor(z));
            return;
        }
        if (sub.equals("list") || sub.equals("l")) {
            java.util.Map<String, double[]> all = wpMod.getAllWaypoints();
            if (all.isEmpty()) {
                ChatUtils.message("No waypoints saved");
                return;
            }
            ChatUtils.cmd("Waypoints (" + all.size() + "):");
            for (java.util.Map.Entry<String, double[]> entry : all.entrySet()) {
                double[] pos = entry.getValue();
                ChatUtils.message("  " + entry.getKey() + ": " + (int) Math.floor(pos[0]) + ", " + (int) Math.floor(pos[1]) + ", " + (int) Math.floor(pos[2]));
            }
            return;
        }
        if (sub.equals("del") || sub.equals("d") || sub.equals("remove") || sub.equals("r")) {
            if (args.length < 2) {
                ChatUtils.error("Usage: #wp del <name>");
                return;
            }
            String name = args[1].toLowerCase();
            if (wpMod.removeWaypoint(name)) {
                ChatUtils.success("Deleted waypoint \"" + name + "\"");
            } else {
                ChatUtils.error("Unknown waypoint: " + name);
            }
            return;
        }
        if (sub.equals("clear") || sub.equals("c")) {
            int count = wpMod.getWaypointCount();
            if (count == 0) {
                ChatUtils.message("No waypoints to clear");
                return;
            }
            wpMod.clearAllWaypoints();
            ChatUtils.success("Cleared " + count + " waypoint(s)");
            return;
        }
        String name = sub;
        double[] pos = wpMod.getWaypoint(name);
        if (pos == null) {
            ChatUtils.error("Unknown waypoint: " + name);
            ChatUtils.message("Use #wp list to see saved waypoints");
            return;
        }
        pathFailed = false;
        pathFailCount = 0;
        followTarget = "";
        exploring = false;
        mineTargetBlock = "";
        int gx = (int) Math.floor(pos[0]);
        int gy = (int) Math.floor(pos[1]);
        int gz = (int) Math.floor(pos[2]);
        setGoal(new GoalBlock(gx, gy, gz), "Waypoint \"" + name + "\"");
        ChatUtils.success("Going to waypoint \"" + name + "\" (" + gx + ", " + gy + ", " + gz + ")");
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (died && deathPos != null) {
            RenderUtils.updateCameraPos(event.getPartialTicks());
            RenderUtils.prepareGL();
            double dx = deathPos[0] - RenderUtils.camX;
            double dy = deathPos[1] - RenderUtils.camY;
            double dz = deathPos[2] - RenderUtils.camZ;
            AxisAlignedBB beam = new AxisAlignedBB(dx + 0.35, dy - 0.5, dz + 0.35, dx + 0.65, dy + 10, dz + 0.65);
            RenderUtils.drawSolidBox(beam, 1.0f, 0.1f, 0.1f, 0.15f);
            AxisAlignedBB base = new AxisAlignedBB(dx, dy - 1, dz, dx + 1, dy + 0.5, dz + 1);
            RenderUtils.drawSolidBox(base, 1.0f, 0.1f, 0.1f, 0.2f);
            RenderUtils.drawOutlinedBox(base, 1.0f, 0.1f, 0.1f, 0.6f);
            RenderUtils.restoreGL();
        }
        if (!renderPath)
            return;
        Path p = executor.getPath();
        boolean stale = false;
        if (p == null || p.length() == 0) {
            long now = System.currentTimeMillis();
            boolean recalculating = pathRequested || (currentGoal != null && !pathCompleted && !mining && !building);
            if (recalculating && lastRenderPath != null && lastRenderPath.length() > 0 && lastRenderPathGoal == currentGoal && now - lastRenderPathMs < STALE_PATH_RENDER_MS) {
                p = lastRenderPath;
                stale = true;
            }
        } else {
            lastRenderPath = p;
            lastRenderPathGoal = currentGoal;
            lastRenderPathMs = System.currentTimeMillis();
        }
        if (p == null || p.length() == 0)
            return;
        float partialTicks = event.getPartialTicks();
        RenderUtils.updateCameraPos(partialTicks);
        RenderUtils.prepareGL();
        int startIdx = stale ? 0 : Math.max(0, executor.getCurrentTargetIndex());
        for (int i = startIdx; i < p.length() - 1; i++) {
            double ax = p.posX[i] + 0.5 - RenderUtils.camX;
            double ay = p.posY[i] + 0.2 - RenderUtils.camY;
            double az = p.posZ[i] + 0.5 - RenderUtils.camZ;
            double bx = p.posX[i + 1] + 0.5 - RenderUtils.camX;
            double by = p.posY[i + 1] + 0.2 - RenderUtils.camY;
            double bz = p.posZ[i + 1] + 0.5 - RenderUtils.camZ;
            double dxP = p.posX[i] + 0.5 - mc.player.posX;
            double dzP = p.posZ[i] + 0.5 - mc.player.posZ;
            double distToPlayer = Math.sqrt(dxP * dxP + dzP * dzP);
            float alpha = (float) Math.max(0.15, 0.9 - distToPlayer / 40.0);
            float r, g, bl;
            if (stale) {
                r = 0.3f;
                g = 0.6f;
                bl = 1.0f;
                alpha *= 0.55f;
            } else if (i < executor.getCurrentTargetIndex()) {
                r = 0.2f;
                g = 0.4f;
                bl = 1.0f;
                alpha *= 0.5f;
            } else {
                r = 0.0f;
                g = 1.0f;
                bl = 0.3f;
            }
            RenderUtils.drawLine(ax, ay, az, bx, by, bz, r, g, bl, alpha);
        }
        int[] dest = p.getDest();
        if (dest != null && !stale) {
            double dx = dest[0] - RenderUtils.camX;
            double dy = dest[1] - RenderUtils.camY;
            double dz = dest[2] - RenderUtils.camZ;
            float time = (System.currentTimeMillis() % 2000) / 2000.0f;
            float pulse = 0.5f + time * 1.5f;
            AxisAlignedBB goalBox = new AxisAlignedBB(dx, dy - pulse + 1, dz, dx + 1, dy + 1 + pulse, dz + 1);
            float goalAlpha = 0.4f + time * 0.3f;
            RenderUtils.drawSolidBox(goalBox, 1.0f, 0.3f, 0.1f, goalAlpha * 0.15f);
            RenderUtils.drawOutlinedBox(goalBox, 1.0f, 0.3f, 0.1f, goalAlpha);
        }
        RenderUtils.restoreGL();
        if (mining && mineTargetPos != null) {
            double mx = mineTargetPos.getX() - RenderUtils.camX;
            double my = mineTargetPos.getY() - RenderUtils.camY;
            double mz = mineTargetPos.getZ() - RenderUtils.camZ;
            AxisAlignedBB mineBox = new AxisAlignedBB(mx, my, mz, mx + 1, my + 1, mz + 1);
            RenderUtils.drawOutlinedBox(mineBox, 1.0f, 0.5f, 0.0f, 0.9f);
        }
        if (farmTargetPos != null) {
            double fx = farmTargetPos.getX() - RenderUtils.camX;
            double fy = farmTargetPos.getY() - RenderUtils.camY;
            double fz = farmTargetPos.getZ() - RenderUtils.camZ;
            AxisAlignedBB farmBox = new AxisAlignedBB(fx, fy, fz, fx + 1, fy + 1, fz + 1);
            RenderUtils.drawOutlinedBox(farmBox, 0.2f, 0.8f, 0.1f, 0.9f);
        }
        if (!avoidZones.isEmpty()) {
            RenderUtils.updateCameraPos(event.getPartialTicks());
            RenderUtils.prepareGL();
            for (int i = 0; i < avoidZones.size(); i++) {
                int[] z = avoidZones.get(i);
                int r = (int) Math.sqrt(z[3]);
                double ax = z[0] - r - RenderUtils.camX;
                double ay = z[1] - r - RenderUtils.camY;
                double az = z[2] - r - RenderUtils.camZ;
                double size = r * 2 + 1;
                AxisAlignedBB avoidBox = new AxisAlignedBB(ax, ay, az, ax + size, ay + size, az + size);
                RenderUtils.drawSolidBox(avoidBox, 1.0f, 0.0f, 0.0f, 0.08f);
                RenderUtils.drawOutlinedBox(avoidBox, 1.0f, 0.2f, 0.2f, 0.4f);
            }
            RenderUtils.restoreGL();
        }
        if (selPos1 != null && selPos2 != null) {
            RenderUtils.updateCameraPos(event.getPartialTicks());
            RenderUtils.prepareGL();
            int minX = Math.min(selPos1[0], selPos2[0]);
            int minY = Math.min(selPos1[1], selPos2[1]);
            int minZ = Math.min(selPos1[2], selPos2[2]);
            int maxX = Math.max(selPos1[0], selPos2[0]);
            int maxY = Math.max(selPos1[1], selPos2[1]);
            int maxZ = Math.max(selPos1[2], selPos2[2]);
            double sx = minX - RenderUtils.camX;
            double sy = minY - RenderUtils.camY;
            double sz = minZ - RenderUtils.camZ;
            double ex = maxX + 1 - RenderUtils.camX;
            double ey = maxY + 1 - RenderUtils.camY;
            double ez = maxZ + 1 - RenderUtils.camZ;
            AxisAlignedBB selBox = new AxisAlignedBB(sx, sy, sz, ex, ey, ez);
            RenderUtils.drawSolidBox(selBox, 0.2f, 0.4f, 1.0f, 0.06f);
            RenderUtils.drawOutlinedBox(selBox, 0.3f, 0.5f, 1.0f, 0.7f);
            RenderUtils.restoreGL();
        }
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (!infoOverlay.shouldRender())
            return;
        if (!isToggled() && !executor.hasPath() && currentGoal == null)
            return;
        int nowTick = mc.player.ticksExisted;
        if (hudCacheTick != nowTick && (hudCacheTick < 0 || nowTick - hudCacheTick >= 2)) {
            hudCacheTick = nowTick;
            rebuildHudStrings();
        }
        int lineH = ClientFontRenderer.fontHeight() + 2;
        String status;
        int detailLines = 0;
        int progressPct = 0;
        if (paused) {
            status = "\u00a78PAUSED";
        } else if (pathRequested && finder != null) {
            status = "\u00a7eCalculating...";
        } else if (mining && mineTargetPos != null) {
            status = "\u00a7dMining";
            detailLines = 1;
        } else if (building) {
            status = "\u00a7e" + (buildMode == BUILD_CLEAR ? "Clearing" : "Building");
            detailLines = 1;
        } else if (executor.hasPath()) {
            Path p = executor.getPath();
            int total = p != null ? p.length() : 0;
            progressPct = total > 0 ? (int) (executor.getProgress() * 100) : 0;
            status = "\u00a7aFollowing";
            detailLines = 2;
        } else if (pathCompleted) {
            status = "\u00a72Done";
        } else if (pathFailed && currentGoal != null) {
            status = "\u00a7cFailed";
        } else if (currentGoal != null) {
            status = "\u00a76Idle";
        } else {
            status = "\u00a77No goal";
        }
        int lines = 2 + detailLines;
        if (mining)
            lines += 1;
        if (building)
            lines += 1;
        if (showTimer && pathStartTime > 0 && (executor.hasPath() || pathRequested || mining || pathCompleted)) {
            lines += 1;
        }
        int boxW = 155;
        int boxH = lines * lineH + 8;
        infoOverlay.updateDrag(boxW, boxH);
        int x = infoOverlay.getX();
        int y = infoOverlay.getY();
        RenderUtils.prepareHUD();
        Tessellator t = Tessellator.getInstance();
        t.getWorldRenderer().begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        addQuadVerts(t, x, y, x + boxW, y + boxH, 0.1f, 0.1f, 0.15f, 0.75f);
        t.draw();
        RenderUtils.restoreHUD();
        int offsetY = y + 4;
        ClientFontRenderer.drawStringWithShadow("\u00a7lBaritone", x + 4, offsetY, 0xFFFFFFFF);
        offsetY += lineH;
        ClientFontRenderer.drawStringWithShadow(hudStatusLine.isEmpty() ? status : hudStatusLine, x + 4, offsetY, 0xFFAAAAAA);
        offsetY += lineH;
        if (detailLines >= 1) {
            ClientFontRenderer.drawStringWithShadow(hudProgStr, x + 4, offsetY, 0xFFAAAAAA);
            offsetY += lineH;
        }
        if (detailLines >= 2) {
            ClientFontRenderer.drawStringWithShadow(hudEtaText, x + 4, offsetY, 0xFFAAAAAA);
            offsetY += lineH;
        }
        if (mining && blocksMined > 0) {
            ClientFontRenderer.drawStringWithShadow(hudMinedStr, x + 4, offsetY, 0xFFAAAAAA);
            offsetY += lineH;
        }
        if (building) {
            ClientFontRenderer.drawStringWithShadow(hudBuildStr, x + 4, offsetY, 0xFFAAAAAA);
            offsetY += lineH;
        }
        if (showTimer && pathStartTime > 0) {
            ClientFontRenderer.drawStringWithShadow(hudTimeStr, x + 4, offsetY, 0xFFAAAAAA);
        }
        infoOverlay.renderDragBox(x, y, boxW, boxH);
    }

    private void rebuildHudStrings() {
        String status;
        if (paused) {
            status = "\u00a78PAUSED";
        } else if (pathRequested && finder != null) {
            status = "\u00a7eCalculating..." + " (" + finder.getNumNodes() + " nodes)";
        } else if (mining && mineTargetPos != null) {
            float progress = mc.playerController.curBlockDamageMP;
            int pct = Math.min(100, (int) (progress * 100));
            status = "\u00a7dMining " + pct + "%";
        } else if (building) {
            String action = buildMode == BUILD_CLEAR ? "Clearing" : "Building";
            status = "\u00a7e" + action + " " + buildIndex + "/" + buildQueue.size();
        } else if (executor.hasPath()) {
            status = "\u00a7aFollowing";
        } else if (pathCompleted) {
            status = "\u00a72Done";
        } else if (pathFailed && currentGoal != null) {
            status = "\u00a7cFailed";
        } else if (currentGoal != null) {
            status = "\u00a76Idle";
        } else {
            status = "\u00a77No goal";
        }
        hudStatusLine = status;
        if (!goalDescription.isEmpty()) {
            hudStatusLine = status + " \u00a77- " + goalDescription;
        }
        if (executor.hasPath()) {
            Path p = executor.getPath();
            int total = p != null ? p.length() : 0;
            int current = executor.getCurrentTargetIndex();
            hudProgStr = "Progress: " + (total > 0 ? (int) (executor.getProgress() * 100) : 0) + "%";
            hudEtaText = String.format("ETA: %.1fs", (total - current) * 0.6);
        } else if (mining && mineTargetPos != null) {
            hudProgStr = "Progress: " + Math.min(100, (int) (mc.playerController.curBlockDamageMP * 100)) + "%";
        }
        hudMinedStr = "Mined: " + blocksMined;
        if (mineDesiredQuantity > 0) {
            hudMinedStr += " / " + mineDesiredQuantity;
        }
        hudBuildStr = buildMode == BUILD_CLEAR ? "Broken: " + blocksBroken : "Placed: " + blocksPlaced;
        if (pathStartTime > 0) {
            long elapsed = System.currentTimeMillis() - pathStartTime;
            int secs = (int) (elapsed / 1000);
            int mins = secs / 60;
            secs = secs % 60;
            if (mins > 0) {
                hudTimeStr = String.format("Time: %dm %ds", mins, secs);
            } else {
                hudTimeStr = "Time: " + secs + "s";
            }
        } else {
            hudTimeStr = "";
        }
    }

    private void addQuadVerts(Tessellator t, float x1, float y1, float x2, float y2, float r, float g, float b, float a) {
        t.getWorldRenderer().pos(x1, y2, 0).color(r, g, b, a).endVertex();
        t.getWorldRenderer().pos(x2, y2, 0).color(r, g, b, a).endVertex();
        t.getWorldRenderer().pos(x2, y1, 0).color(r, g, b, a).endVertex();
        t.getWorldRenderer().pos(x1, y1, 0).color(r, g, b, a).endVertex();
    }

    private Block getBlockByName(String name) {
        if (name == null || name.isEmpty())
            return null;
        String lower = name.toLowerCase();
        try {
            net.minecraft.util.ResourceLocation rl = new net.minecraft.util.ResourceLocation(lower);
            if (Block.REGISTRY.containsKey(rl)) {
                return Block.REGISTRY.getObject(rl);
            }
        } catch (Exception ignored) {
        }
        if (!lower.startsWith("minecraft:")) {
            try {
                net.minecraft.util.ResourceLocation rl = new net.minecraft.util.ResourceLocation("minecraft:" + lower);
                if (Block.REGISTRY.containsKey(rl)) {
                    return Block.REGISTRY.getObject(rl);
                }
            } catch (Exception ignored) {
            }
        }
        try {
            int id = Integer.parseInt(lower);
            Block block = Block.getBlockById(id);
            if (block != null)
                return block;
        } catch (NumberFormatException ignored) {
        }
        switch(lower) {
            case "wheat":
                return Blocks.WHEAT;
            case "carrot":
                return Blocks.CARROTS;
            case "potato":
                return Blocks.POTATOES;
            case "beetroot":
                return Blocks.BEETROOTS;
            case "sugar_cane":
                return Blocks.REEDS;
            case "reeds":
                return Blocks.REEDS;
            case "melon":
                return Blocks.MELON_BLOCK;
            case "workbench":
                return Blocks.CRAFTING_TABLE;
            case "mossy_cobble":
                return Blocks.MOSSY_COBBLESTONE;
            case "cobble_stairs":
                return Blocks.STONE_STAIRS;
            case "nether_fence":
                return Blocks.NETHER_BRICK_FENCE;
            case "hay_bale":
                return Blocks.HAY_BLOCK;
            case "spawner":
                return Blocks.MOB_SPAWNER;
            case "magma_block":
                return Blocks.MAGMA;
            case "blue_ice":
                return Blocks.PACKED_ICE;
            case "white_clay":
                return Blocks.STAINED_HARDENED_CLAY;
            case "ender_portal_frame":
                return Blocks.END_PORTAL_FRAME;
            case "oak_log":
                return Blocks.LOG;
            case "spruce_log":
                return Blocks.LOG;
            case "birch_log":
                return Blocks.LOG;
            case "jungle_log":
                return Blocks.LOG;
            case "acacia_log":
                return Blocks.LOG2;
            case "dark_oak_log":
                return Blocks.LOG2;
            case "oak_wood":
                return Blocks.LOG;
            case "spruce_wood":
                return Blocks.LOG;
            case "birch_wood":
                return Blocks.LOG;
            case "jungle_wood":
                return Blocks.LOG;
            case "acacia_wood":
                return Blocks.LOG2;
            case "dark_oak_wood":
                return Blocks.LOG2;
            case "oak_planks":
                return Blocks.PLANKS;
            case "spruce_planks":
                return Blocks.PLANKS;
            case "birch_planks":
                return Blocks.PLANKS;
            case "jungle_planks":
                return Blocks.PLANKS;
            case "acacia_planks":
                return Blocks.PLANKS;
            case "dark_oak_planks":
                return Blocks.PLANKS;
            case "log":
                return Blocks.LOG;
            case "wood":
                return Blocks.LOG;
            case "planks":
                return Blocks.PLANKS;
            case "cobble":
                return Blocks.COBBLESTONE;
            case "stone_brick":
                return Blocks.STONEBRICK;
            case "nether_brick":
                return Blocks.NETHER_BRICK;
            case "redstone_block":
                return Blocks.REDSTONE_BLOCK;
            case "lapis_block":
                return Blocks.LAPIS_BLOCK;
            case "emerald_block":
                return Blocks.EMERALD_BLOCK;
            case "gold_block":
                return Blocks.GOLD_BLOCK;
            case "iron_block":
                return Blocks.IRON_BLOCK;
            case "diamond_block":
                return Blocks.DIAMOND_BLOCK;
            case "coal_block":
                return Blocks.COAL_BLOCK;
            default:
                return null;
        }
    }

    private static String getBlockRegistryName(Block block) {
        if (block == null)
            return "";
        try {
            net.minecraft.util.ResourceLocation rl = Block.REGISTRY.getNameForObject(block);
            if (rl != null)
                return rl.getResourcePath();
        } catch (Exception ignored) {
        }
        try {
            String un = block.getUnlocalizedName();
            if (un.startsWith("tile."))
                un = un.substring(5);
            int dot = un.indexOf('.');
            if (dot > 0)
                un = un.substring(0, dot);
            return un;
        } catch (Exception ignored) {
        }
        return "unknown";
    }

    private static String[] allBlockNames = null;

    private String[] getAllBlockNames() {
        if (allBlockNames != null)
            return allBlockNames;
        java.util.ArrayList<String> names = new java.util.ArrayList<String>();
        try {
            for (Block block : Block.REGISTRY) {
                String n = getBlockRegistryName(block);
                if (n != null && !n.isEmpty() && !n.equals("air")) {
                    names.add(n);
                }
            }
        } catch (Exception ignored) {
        }
        String[] friendlyNames = { "oak_log", "spruce_log", "birch_log", "jungle_log", "acacia_log", "dark_oak_log", "oak_wood", "spruce_wood", "birch_wood", "jungle_wood", "acacia_wood", "dark_oak_wood", "oak_planks", "spruce_planks", "birch_planks", "jungle_planks", "acacia_planks", "dark_oak_planks", "oak_stairs", "spruce_stairs", "birch_stairs", "jungle_stairs", "acacia_stairs", "dark_oak_stairs", "sugar_cane", "cobble", "melon" };
        for (String fn : friendlyNames) {
            if (!names.contains(fn)) {
                names.add(fn);
            }
        }
        java.util.Collections.sort(names);
        allBlockNames = names.toArray(new String[names.size()]);
        return allBlockNames;
    }

    private String[] tabCompleteBlock(String prefix) {
        if (prefix == null || prefix.isEmpty())
            return null;
        String lower = prefix.toLowerCase();
        String[] all = getAllBlockNames();
        java.util.ArrayList<String> matches = new java.util.ArrayList<String>();
        for (String name : all) {
            if (name.startsWith(lower)) {
                matches.add(name);
            }
        }
        if (matches.isEmpty())
            return null;
        return matches.toArray(new String[matches.size()]);
    }

    public String[] tabCompleteBlockPublic(String prefix) {
        return tabCompleteBlock(prefix);
    }

    private boolean isExposed(int x, int y, int z) {
        if (BlockAccess.canWalkThrough(x + 1, y, z))
            return true;
        if (BlockAccess.canWalkThrough(x - 1, y, z))
            return true;
        if (BlockAccess.canWalkThrough(x, y + 1, z))
            return true;
        if (BlockAccess.canWalkThrough(x, y - 1, z))
            return true;
        if (BlockAccess.canWalkThrough(x, y, z + 1))
            return true;
        if (BlockAccess.canWalkThrough(x, y, z - 1))
            return true;
        return false;
    }

    private boolean shouldAvoidBreaking(int x, int y, int z) {
        Block block = BlockAccess.getBlockType(x, y, z);
        if (blocksToAvoidBreakingList.contains(block)) {
            return true;
        }
        if (block == Blocks.ICE || block == Blocks.PACKED_ICE) {
            return true;
        }
        if (block instanceof net.minecraft.block.BlockSilverfish) {
            return true;
        }
        int[][] adj = { { x + 1, y, z }, { x - 1, y, z }, { x, y, z + 1 }, { x, y, z - 1 }, { x, y + 1, z } };
        for (int i = 0; i < adj.length; i++) {
            Block adjBlock = BlockAccess.getBlockType(adj[i][0], adj[i][1], adj[i][2]);
            if (adjBlock == Blocks.WATER || adjBlock == Blocks.FLOWING_WATER || adjBlock == Blocks.LAVA || adjBlock == Blocks.FLOWING_LAVA) {
                return true;
            }
        }
        if (avoidUpdatingFallingBlocks) {
            if (BlockAccess.wouldTriggerFallingBlock(x, y, z)) {
                return true;
            }
        }
        return false;
    }

    private boolean isAvoidBreaking(BlockPos pos) {
        return shouldAvoidBreaking(pos.getX(), pos.getY(), pos.getZ());
    }

    private int[] findNearestBlock(Block block, int radius) {
        if (mc.player == null || mc.world == null)
            return null;
        int pcx = (int) Math.floor(mc.player.posX);
        int pcy = (int) Math.floor(mc.player.posY);
        int pcz = (int) Math.floor(mc.player.posZ);
        int[] best = null;
        double bestDist = Double.MAX_VALUE;
        int chunkRadius = (radius >> 4) + 1;
        int yMin = Math.max(0, pcy - radius);
        int yMax = Math.min(255, pcy + radius);
        BlockPos mutPos = new BlockPos(0, 0, 0);
        for (int cx = -chunkRadius; cx <= chunkRadius; cx++) {
            for (int cz = -chunkRadius; cz <= chunkRadius; cz++) {
                int chunkX = (pcx >> 4) + cx;
                int chunkZ = (pcz >> 4) + cz;
                Chunk chunk = mc.world.getChunkFromChunkCoords(chunkX, chunkZ);
                if (chunk == null || !chunk.isLoaded())
                    continue;
                int baseX = chunkX << 4;
                int baseZ = chunkZ << 4;
                for (int x = 0; x < 16; x++) {
                    for (int z = 0; z < 16; z++) {
                        int wx = baseX + x;
                        int wz = baseZ + z;
                        double dxBase = wx - mc.player.posX;
                        double dzBase = wz - mc.player.posZ;
                        double xzDistSq = dxBase * dxBase + dzBase * dzBase;
                        if (xzDistSq > bestDist)
                            continue;
                        for (int y = yMin; y <= yMax; y++) {
                            double dyBase = y - mc.player.posY;
                            double distSq = xzDistSq + dyBase * dyBase;
                            if (distSq > bestDist)
                                continue;
                            mutPos.setPos(wx, y, wz);
                            if (chunk.getBlockState(mutPos).getBlock() == block && !shouldAvoidBreaking(wx, y, wz)) {
                                if (legitMine && !isExposed(wx, y, wz)) {
                                    continue;
                                }
                                bestDist = distSq;
                                best = new int[] { wx, y, wz };
                            }
                        }
                    }
                }
            }
        }
        return best;
    }

    private void generateExploreTargets(int radius) {
        int chunkRadius = Math.max(1, radius / 16);
        int maxTargets = chunkRadius * chunkRadius * 4 + 4;
        int[] txList = new int[maxTargets];
        int[] tzList = new int[maxTargets];
        int count = 0;
        int x = 0, z = 0;
        int dx = 1, dz = 0;
        int segLen = 1;
        int segPassed = 0;
        int turnCount = 0;
        for (int i = 0; i < maxTargets * 2; i++) {
            int bx = exploreCenterX + x * 16;
            int bz = exploreCenterZ + z * 16;
            if (x * x + z * z <= chunkRadius * chunkRadius && count < maxTargets) {
                txList[count] = bx;
                tzList[count] = bz;
                count++;
            }
            x += dx;
            z += dz;
            segPassed++;
            if (segPassed >= segLen) {
                segPassed = 0;
                turnCount++;
                int tmp = dx;
                dx = -dz;
                dz = tmp;
                if (turnCount % 2 == 0)
                    segLen++;
            }
        }
        exploreTargetsX = new int[count];
        exploreTargetsZ = new int[count];
        System.arraycopy(txList, 0, exploreTargetsX, 0, count);
        System.arraycopy(tzList, 0, exploreTargetsZ, 0, count);
    }

    private void setNextExploreGoal() {
        if (exploreTargetsX == null || exploreIndex >= exploreTargetsX.length) {
            ChatUtils.success("Exploration complete!");
            stopExplore();
            return;
        }
        int tx = exploreTargetsX[exploreIndex];
        int tz = exploreTargetsZ[exploreIndex];
        int ty = (int) Math.floor(mc.player.posY);
        for (int y = Math.min(ty + 10, 255); y >= Math.max(ty - 20, 0); y--) {
            if (BlockAccess.canWalkOn(tx, y - 1, tz) && BlockAccess.canWalkThrough(tx, y, tz) && BlockAccess.canWalkThrough(tx, y + 1, tz)) {
                ty = y;
                break;
            }
        }
        setGoal(new GoalBlock(tx, ty, tz), String.format("Explore %d/%d (%d, %d)", exploreIndex + 1, exploreTargetsX.length, tx, tz));
        exploreIndex++;
    }

    private void stopExplore() {
        exploring = false;
        exploreIndex = 0;
        exploreTargetsX = null;
        exploreTargetsZ = null;
    }

    private void setGoal(Goal goal, String description) {
        cancelPath();
        this.currentGoal = goal;
        this.goalDescription = description;
        this.pathCompleted = false;
        this.pathFailed = false;
        this.pathFailCount = 0;
        this.retryCount = 0;
        this.lastFailedGoal = null;
        this.pathStartTime = System.currentTimeMillis();
        this.segmentFailStreak = 0;
        this.segFailPosValid = false;
        this.globalVisitedPositions.clear();
        this.lastRecalcTime = 0;
        if (goal != null && isToggled()) {
            requestPath();
        }
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            cancelPath();
            return;
        }
        if (mc.player.isDead && (currentGoal != null || mining || farming || building || followTarget != null)) {
            mc.player.respawnPlayer();
            return;
        }
        if (paused) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
            return;
        }
        if (cancelPending && executor.safeToCancel()) {
            cancelPath();
        }
        boolean baritoneActive = executor.hasPath() || mining || building || farming || pathRequested;
        if (baritoneActive) {
            if (executor.hasPath()) {
            } else if (mining) {
                releaseMovementKeys();
                mc.player.setSprinting(false);
            } else {
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), false);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), false);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), false);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), false);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
                mc.player.setSprinting(false);
            }
        }
        if (!preCacheDone && baritoneActive) {
            preCacheDone = BlockAccess.preCache((int) mc.player.posX, (int) mc.player.posY, (int) mc.player.posZ, PRECACHE_RADIUS);
        }
        if (mineScanActive) {
            tickMineScan();
        }
        if (farmScanActive) {
            tickFarmScan();
        }
        if (mineDesiredQuantity > 0 && mineContinuous && !mineTargetBlock.isEmpty() && ++mineQuantityTick >= 20) {
            mineQuantityTick = 0;
            int have = countMatchingMineItems();
            if (have >= mineDesiredQuantity) {
                ChatUtils.success("Have " + have + " " + mineTargetBlock + " - done");
                mineDesiredQuantity = 0;
                stopMining();
                mineContinuous = false;
                mineTargetBlock = "";
                mineTargetPos = null;
                cancelPath();
                currentGoal = null;
                goalDescription = "";
                dropPickupActive = false;
                anticipatedDrops.clear();
                mineExploreActive = false;
                return;
            }
        }
        if (!mining && baritoneActive) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
        }
        if (autoEat && baritoneActive) {
            tickAutoEat();
        }
        if (baritoneActive && !mc.player.onGround) {
            tryWaterBucketFall();
        }
        if (followTarget != null && !followTarget.isEmpty()) {
            updateFollowGoal();
        }
        if (avoidance && baritoneActive) {
            updateMobAvoidance();
        }
        if (pathRequested && finder != null && !finder.isDone()) {
            if (System.currentTimeMillis() >= pathTimeoutEnd) {
                Path best = finder.step(0);
                if (best != null && best.length() > 0) {
                    executor.setPath(best);
                    pathFailed = false;
                    pathFailCount = 0;
                    consecutivePartials++;
                    if (consecutivePartials > 4) {
                        double progressX = mc.player.posX - lastPartialX;
                        double progressZ = mc.player.posZ - lastPartialZ;
                        double progressSq = progressX * progressX + progressZ * progressZ;
                        if (progressSq < 4.0) {
                            pathFailed = true;
                            pathFailCount = MAX_RETRIES;
                            consecutivePartials = 0;
                            ChatUtils.error("Not making progress toward goal" + " (4 partial paths, <2 blocks)");
                            ChatUtils.message("Use #retry or move closer");
                            pathRequested = false;
                            finder = null;
                            return;
                        }
                        consecutivePartials = 0;
                        lastPartialX = mc.player.posX;
                        lastPartialZ = mc.player.posZ;
                    }
                    ChatUtils.message("Path segment found (" + best.length() + " positions, continuing)");
                } else {
                    pathFailCount++;
                    pathFailed = true;
                    lastFailedGoal = currentGoal;
                    lastFailedDesc = goalDescription;
                    ChatUtils.message("Path timed out (" + finder.getNumNodes() + " nodes, try closer goal)");
                    ChatUtils.message("Use #retry to try again");
                }
                pathRequested = false;
                finder = null;
            } else {
                Path result = finder.step(nodesPerTick);
                if (result != null) {
                    if (result.length() > 0) {
                        executor.setPath(result);
                        pathFailed = false;
                        pathFailCount = 0;
                        int[] dest = result.getDest();
                        boolean partial = currentGoal != null && dest != null && !currentGoal.isInGoal(dest[0], dest[1], dest[2]);
                        if (partial) {
                            consecutivePartials++;
                            if (consecutivePartials > 4) {
                                double progressX = mc.player.posX - lastPartialX;
                                double progressZ = mc.player.posZ - lastPartialZ;
                                double progressSq = progressX * progressX + progressZ * progressZ;
                                if (progressSq < 4.0) {
                                    pathFailed = true;
                                    pathFailCount = MAX_RETRIES;
                                    consecutivePartials = 0;
                                    ChatUtils.error("Not making progress toward" + " goal (4 partial paths," + " <2 blocks)");
                                    ChatUtils.message("Use #retry or move closer");
                                    pathRequested = false;
                                    finder = null;
                                    return;
                                }
                                consecutivePartials = 0;
                                lastPartialX = mc.player.posX;
                                lastPartialZ = mc.player.posZ;
                            }
                            ChatUtils.message("Path segment found (" + result.length() + " positions, continuing)");
                        } else {
                            consecutivePartials = 0;
                            ChatUtils.success("Path found (" + result.length() + " positions)");
                        }
                    } else if (currentGoal != null && currentGoal.isInGoal((int) Math.floor(mc.player.posX), (int) Math.floor(mc.player.posY), (int) Math.floor(mc.player.posZ))) {
                        int tpx = (int) Math.floor(mc.player.posX);
                        int tpy = (int) Math.floor(mc.player.posY);
                        int tpz = (int) Math.floor(mc.player.posZ);
                        executor.setPath(new Path(tpx, tpy, tpz, new PathNode(tpx, tpy, tpz, currentGoal), 1));
                        pathFailed = false;
                        pathFailCount = 0;
                    } else {
                        pathFailCount++;
                        pathFailed = true;
                        lastFailedGoal = currentGoal;
                        lastFailedDesc = goalDescription;
                        ChatUtils.error("No path found");
                        ChatUtils.message("Use #retry to try again");
                    }
                    pathRequested = false;
                    finder = null;
                }
            }
        }
        if (baritoneActive) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
        }
        if (executor.hasPath()) {
            boolean done = executor.tick(sprintEnabled);
            MovementState es = executor.getState();
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), es.forward);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), es.back);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), es.left);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), es.right);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), es.jump);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), es.sneak);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), es.sprint);
            if (done) {
                BlockPos readyMineTarget = null;
                if (!mineTargetBlock.isEmpty() && mineTargetPos != null) {
                    BlockPos cand = mineTargetPos;
                    double mdx = (cand.getX() + 0.5) - mc.player.posX;
                    double mdy = (cand.getY() + 0.5) - mc.player.posY;
                    double mdz = (cand.getZ() + 0.5) - mc.player.posZ;
                    double mdSq = mdx * mdx + mdy * mdy + mdz * mdz;
                    if (mdSq <= MINE_REACH * MINE_REACH) {
                        Block candBlock = mc.world.getBlockState(cand).getBlock();
                        if (candBlock != Blocks.AIR && matchesMineTarget(candBlock) && !isPlayerSupport(cand.getX(), cand.getY(), cand.getZ())) {
                            readyMineTarget = cand;
                        }
                    } else if (mineContinuous) {
                        BlockPos near = findMineTargetNearPlayer();
                        if (near != null) {
                            mineTargetPos = near;
                            readyMineTarget = near;
                        }
                    }
                }
                if (readyMineTarget != null) {
                    mineTargetPos = readyMineTarget;
                    mining = true;
                    miningFirstTick = true;
                    pathCompleted = true;
                    executor.clearPath();
                    mc.player.setSprinting(false);
                    KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
                } else if (mineContinuous && !mineTargetBlock.isEmpty()) {
                    executor.clearPath();
                    pathCompleted = false;
                    advanceToNextMineTarget();
                } else if (farming && farmTargetPos != null) {
                    farming = false;
                    pathCompleted = true;
                    executor.clearPath();
                    mc.player.setSprinting(false);
                    KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
                    tickFarm();
                } else if (clickTargetPos != null) {
                    executor.clearPath();
                    pathCompleted = true;
                    mc.player.setSprinting(false);
                    KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
                    lookAtBlock(clickTargetPos, true);
                    EnumFacing face = findBestMineFace(clickTargetPos);
                    if (face == null)
                        face = EnumFacing.UP;
                    InteractionUtils.placeBlock(clickTargetPos, face);
                    mc.player.swingArm(EnumHand.MAIN_HAND);
                    ChatUtils.success("Clicked " + clickTargetPos.getX() + ", " + clickTargetPos.getY() + ", " + clickTargetPos.getZ());
                    clickTargetPos = null;
                    currentGoal = null;
                    goalDescription = "";
                } else if (building && !buildPlacing) {
                    pathCompleted = true;
                    executor.clearPath();
                    mc.player.setSprinting(false);
                    KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
                    tickBuild();
                } else if (exploring && isToggled()) {
                    pathCompleted = true;
                    executor.clearPath();
                    ChatUtils.success("Arrived at destination");
                    setNextExploreGoal();
                } else {
                    if (currentGoal != null && currentGoal.isInGoal((int) Math.floor(mc.player.posX), (int) Math.floor(mc.player.posY), (int) Math.floor(mc.player.posZ))) {
                        if (followTarget.isEmpty()) {
                            pathCompleted = true;
                            currentGoal = null;
                            goalDescription = "";
                        }
                        ChatUtils.success("Arrived at destination");
                        executor.clearPath();
                    } else {
                        executor.clearPath();
                        pathCompleted = false;
                        ChatUtils.message("Path segment complete, continuing...");
                    }
                }
            } else if (!executor.hasPath()) {
                onSegmentLost();
            } else if (executor.isStuck()) {
                int[] ob = executor.getObstructingBlock();
                if (ob != null && !mining && !building && !farming) {
                    BlockPos obPos = new BlockPos(ob[0], ob[1], ob[2]);
                    if (!isAvoidBreaking(obPos)) {
                        startBreakingObstruction(obPos);
                    }
                }
                if (!mining) {
                    int[] nudgeTarget = executor.getCurrentTarget();
                    boolean jumpHelps = nudgeTarget != null && nudgeTarget[1] - (int) Math.floor(mc.player.posY) <= 1;
                    if (mc.player.onGround && jumpHelps) {
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), true);
                    } else {
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), false);
                    }
                    long now = System.currentTimeMillis();
                    long nudgeJitter = ((long) (mc.player.posX * 31 + mc.player.posZ * 17) & 0x7FL);
                    long nudgePhase = (now + nudgeJitter) % 650;
                    if (nudgePhase < 150) {
                        if (((now + nudgeJitter) / 150) % 2 == 0) {
                            KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), true);
                            KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), false);
                        } else {
                            KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), false);
                            KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), true);
                        }
                    } else {
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), false);
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), false);
                    }
                    if (now - lastRecalcTime < RECALC_COOLDOWN_MS) {
                    } else if (currentGoal != null) {
                        lastRecalcTime = now;
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), false);
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), false);
                        ChatUtils.message("Stuck, recalculating...");
                        requestPath();
                    }
                }
            } else if (executor.isPathInvalidated()) {
                int[] ob = executor.getObstructingBlock();
                if (ob != null && !mining && !building && !farming) {
                    BlockPos obPos = new BlockPos(ob[0], ob[1], ob[2]);
                    if (!isAvoidBreaking(obPos)) {
                        startBreakingObstruction(obPos);
                    }
                }
                if (!mining) {
                    long now = System.currentTimeMillis();
                    if (now - lastRecalcTime < RECALC_COOLDOWN_MS) {
                    } else if (currentGoal != null) {
                        lastRecalcTime = now;
                        ChatUtils.message("Path blocked, recalculating...");
                        requestPath();
                    }
                }
            } else if (!mining && !building && !farming) {
                int[] lm = executor.getLookaheadMineBlock();
                if (lm != null) {
                    BlockPos lmPos = new BlockPos(lm[0], lm[1], lm[2]);
                    if (!isAvoidBreaking(lmPos)) {
                        startBreakingObstruction(lmPos);
                    }
                }
            }
        }
        if (mineContinuous && !mining && !mineTargetBlock.isEmpty() && mc.player.onGround && executor.hasPath() && executor.safeToCancel()) {
            checkShaftMineDirect();
        }
        if (mining && mineTargetPos != null) {
            tickMine();
        }
        if (building) {
            checkBuildBreak();
            if (buildPlacing && buildMode == BUILD_CLEAR) {
            } else if (buildPlacing) {
                tickBuild();
            }
        }
        if (farming && farmReplantPos != null && farmReplantTimer > 0) {
            farmReplantTimer--;
            if (farmReplantTimer == 0) {
                tryReplant();
            }
        }
        if (pathRequested && finder != null && finder.isDone()) {
            pathFailCount++;
            pathFailed = true;
            lastFailedGoal = currentGoal;
            lastFailedDesc = goalDescription;
            ChatUtils.message("No path found (" + finder.getNumNodes() + " nodes explored)");
            ChatUtils.message("Use #retry to try again");
            pathRequested = false;
            finder = null;
        }
        if (pathFailed && mineContinuous && !mineTargetBlock.isEmpty() && !breakingObstruction) {
            pathFailed = false;
            pathFailCount = 0;
            consecutivePartials = 0;
            if (mineTargetPos != null) {
                mineBlacklist.put(PathNode.longHash(mineTargetPos.getX(), mineTargetPos.getY(), mineTargetPos.getZ()));
                ChatUtils.message("Blacklisting unreachable target, " + "trying next...");
            } else if (dropPickupActive) {
                dropPickupActive = false;
                anticipatedDrops.clear();
                dropPickupAttempts = 0;
                dropPickupCooldownUntilMs = System.currentTimeMillis() + MINE_PICKUP_COOLDOWN_MS;
            }
            advanceToNextMineTarget();
        }
        boolean needRepath = !executor.hasPath() && !pathRequested && !pathFailed && !mining && !building;
        if (needRepath && (currentGoal != null && !pathCompleted || (!followTarget.isEmpty() && !pathCompleted))) {
            requestPath();
        }
        if (!followTarget.isEmpty() && pathCompleted) {
            pathCompleted = false;
        }
    }

    @Override
    public void onWorldChange(client.event.events.WorldChangeEvent event) {
        globalVisitedPositions.clear();
        client.baritone.cache.CachedWorld.clearAll();
        client.baritone.cache.CachedWorld.resetPreCache();
        preCacheDone = false;
        if (executor != null) {
            executor.setPath(null);
        }
        pathFailed = false;
        pathFailCount = 0;
        pathRequested = false;
        finder = null;
        ChatUtils.message("World changed - Baritone state reset");
    }

    private void tickMine() {
        if (mc.player == null || mineTargetPos == null) {
            stopMining();
            return;
        }
        if (silentAimOwned) {
            SilentAimUtil.endStreak();
            SilentAimUtil.onDisable("Baritone");
            silentAimOwned = false;
            client.Client.INSTANCE.physicsConsistentAim = false;
            client.Client.INSTANCE.renderRotationOverride = false;
        }
        if (mc.world.getBlockState(mineTargetPos).getBlock() == Blocks.AIR) {
            long goneHash = PathNode.longHash(mineTargetPos.getX(), mineTargetPos.getY(), mineTargetPos.getZ());
            if (!breakingObstruction && (!lastCountedMineValid || lastCountedMineHash != goneHash)) {
                blocksMined++;
                lastCountedMineHash = goneHash;
                lastCountedMineValid = true;
                dropPickupAttempts = 0;
                anticipatedDrops.add(new int[] { mineTargetPos.getX(), mineTargetPos.getY(), mineTargetPos.getZ(), (int) Math.min(System.currentTimeMillis() + MINE_DROP_LOITER_MS, Integer.MAX_VALUE) });
                if (anticipatedDrops.size() > 32) {
                    anticipatedDrops.remove(0);
                }
            }
            BlockAccess.invalidateAt(mineTargetPos.getX(), mineTargetPos.getY(), mineTargetPos.getZ());
            if (breakingObstruction) {
                stopMining();
                return;
            }
            if (cancelOnGoalInvalidation && executor.hasPath()) {
                cancelPath();
            }
            if (mineContinuous && !mineTargetBlock.isEmpty()) {
                if (!tryVeinMine()) {
                    advanceToNextMineTarget();
                }
            } else {
                stopMining();
                mineTargetPos = null;
                currentGoal = null;
                goalDescription = "";
            }
            return;
        }
        if (!breakingObstruction && !matchesMineTarget(mc.world.getBlockState(mineTargetPos).getBlock())) {
            BlockAccess.invalidateAt(mineTargetPos.getX(), mineTargetPos.getY(), mineTargetPos.getZ());
            if (cancelOnGoalInvalidation && executor.hasPath()) {
                cancelPath();
            }
            if (mineContinuous && !mineTargetBlock.isEmpty()) {
                if (!tryVeinMine()) {
                    advanceToNextMineTarget();
                }
            } else {
                stopMining();
                mineTargetPos = null;
                currentGoal = null;
                goalDescription = "";
            }
            return;
        }
        boolean isShaftMine = false;
        {
            int ppx = (int) Math.floor(mc.player.posX);
            int ppy = (int) Math.floor(mc.player.posY);
            int ppz = (int) Math.floor(mc.player.posZ);
            isShaftMine = mineTargetPos.getX() == ppx && mineTargetPos.getZ() == ppz && mineTargetPos.getY() >= ppy && mineTargetPos.getY() <= ppy + 2 && mc.player.onGround;
        }
        double dx = (mineTargetPos.getX() + 0.5) - mc.player.posX;
        double dy = (mineTargetPos.getY() + 0.5) - mc.player.posY;
        double dz = (mineTargetPos.getZ() + 0.5) - mc.player.posZ;
        double distSq = dx * dx + dy * dy + dz * dz;
        if (distSq > MINE_REACH * MINE_REACH) {
            if (breakingObstruction) {
                breakingObstruction = false;
                executor.setWalkWhileBreaking(false);
            }
            if (mineContinuous) {
                setGoal(new GoalTwoBlocks(mineTargetPos.getX(), mineTargetPos.getY(), mineTargetPos.getZ()), "Mine " + mineTargetBlock + " at " + mineTargetPos.getX() + ", " + mineTargetPos.getY() + ", " + mineTargetPos.getZ());
            }
            stopMining();
            return;
        }
        boolean closeEnoughToMine = distSq <= MINE_START_DIST_SQ || breakingObstruction || isShaftMine;
        if (!closeEnoughToMine) {
            boolean pathMayBringUsCloser = executor.hasPath() || pathRequested;
            if (pathMayBringUsCloser) {
                lookAtBlock(mineTargetPos, true);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
                return;
            }
        }
        BlockPos actualTarget = mineTargetPos;
        {
            double px = mc.player.posX;
            double py = mc.player.posY + mc.player.getEyeHeight();
            double pz = mc.player.posZ;
            boolean needRetrace = cachedTraceTarget == null || !cachedTraceTarget.equals(mineTargetPos) || (px - cachedTracePX) * (px - cachedTracePX) + (py - cachedTracePY) * (py - cachedTracePY) + (pz - cachedTracePZ) * (pz - cachedTracePZ) > 0.01;
            if (needRetrace) {
                Vec3d eyePos = new Vec3d(px, py, pz);
                Vec3d targetCenter = new Vec3d(mineTargetPos.getX() + 0.5, mineTargetPos.getY() + 0.5, mineTargetPos.getZ() + 0.5);
                RayTraceResult hit = mc.world.rayTraceBlocks(eyePos, targetCenter, false, true, false);
                cachedTracePX = px;
                cachedTracePY = py;
                cachedTracePZ = pz;
                cachedTraceTarget = mineTargetPos;
                cachedCoveringBlock = null;
                if (hit != null && hit.typeOfHit == RayTraceResult.Type.BLOCK) {
                    BlockPos hitPos = hit.getBlockPos();
                    if (!hitPos.equals(mineTargetPos) && BlockAccess.isMineable(hitPos.getX(), hitPos.getY(), hitPos.getZ())) {
                        cachedCoveringBlock = hitPos;
                    }
                }
            }
            if (cachedCoveringBlock != null) {
                if (mc.world.getBlockState(cachedCoveringBlock).getBlock() == Blocks.AIR) {
                    cachedCoveringBlock = null;
                    cachedTraceTarget = null;
                } else {
                    actualTarget = cachedCoveringBlock;
                }
            }
        }
        if (mineToolSlot == -1 || !actualTarget.equals(lastMineActualTarget)) {
            switchToBestTool(actualTarget);
            mineToolSlot = mc.player.inventory.currentItem;
        }
        lastMineActualTarget = actualTarget;
        lookAtBlock(actualTarget, true);
        if (!executor.isWalkWhileBreaking()) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
            mc.player.setSprinting(false);
        } else {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
            mc.player.setSprinting(false);
        }
        EnumFacing targetFace = findBestMineFace(actualTarget);
        RayTraceResult lookRayHit = null;
        if (targetFace == null) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
            return;
        }
        {
            double lfx = actualTarget.getX() + 0.5 + targetFace.getFrontOffsetX() * 0.5;
            double lfy = actualTarget.getY() + 0.5 + targetFace.getFrontOffsetY() * 0.5;
            double lfz = actualTarget.getZ() + 0.5 + targetFace.getFrontOffsetZ() * 0.5;
            double ldx = lfx - mc.player.posX;
            double ldy = lfy - (mc.player.posY + mc.player.getEyeHeight());
            double ldz = lfz - mc.player.posZ;
            double ldistXZ = Math.sqrt(ldx * ldx + ldz * ldz);
            if (ldistXZ < 0.01)
                ldistXZ = 0.01;
            float reqYaw = (float) Math.toDegrees(Math.atan2(ldz, ldx)) - 90.0f;
            float reqPitch = (float) -Math.toDegrees(Math.atan2(ldy, ldistXZ));
            float currentYaw = mc.player.rotationYaw;
            float currentPitch = mc.player.rotationPitch;
            float yawErr = Math.abs(MathHelper.wrapDegrees(reqYaw - currentYaw));
            float pitchErr = Math.abs(reqPitch - currentPitch);
            boolean rayTraceValid = false;
            {
                Vec3d eye = new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ);
                float rtYaw = mc.player.rotationYaw;
                float rtPitch = mc.player.rotationPitch;
                double yawRad = Math.toRadians(rtYaw);
                double pitchRad = Math.toRadians(rtPitch);
                double lookX = -Math.sin(yawRad) * Math.cos(pitchRad);
                double lookY = -Math.sin(pitchRad);
                double lookZ = Math.cos(yawRad) * Math.cos(pitchRad);
                Vec3d lookEnd = eye.addVector(lookX * MINE_REACH, lookY * MINE_REACH, lookZ * MINE_REACH);
                RayTraceResult rtHit = mc.world.rayTraceBlocks(eye, lookEnd, false, true, false);
                lookRayHit = rtHit;
                rayTraceValid = rtHit != null && rtHit.typeOfHit == RayTraceResult.Type.BLOCK && rtHit.getBlockPos().equals(actualTarget);
            }
            if (miningFirstTick) {
                if (yawErr < 5.0f && pitchErr < 10.0f && rayTraceValid) {
                    miningFirstTick = false;
                } else {
                    KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
                    return;
                }
            }
        }
        EnumFacing packetFace = targetFace;
        Vec3d hitVec;
        if (lookRayHit != null && lookRayHit.typeOfHit == RayTraceResult.Type.BLOCK && lookRayHit.getBlockPos().equals(actualTarget) && lookRayHit.sideHit != null) {
            packetFace = lookRayHit.sideHit;
            hitVec = lookRayHit.hitVec;
        } else {
            hitVec = new Vec3d(actualTarget.getX() + 0.5 + packetFace.getDirectionVec().x * 0.5, actualTarget.getY() + 0.5 + packetFace.getDirectionVec().y * 0.5, actualTarget.getZ() + 0.5 + packetFace.getDirectionVec().z * 0.5);
        }
        mc.objectMouseOver = new RayTraceResult(hitVec, packetFace, actualTarget);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), true);
    }

    private int[] findMineStandPos(int tx, int ty, int tz) {
        if (mc.player == null || mc.world == null)
            return null;
        double px = mc.player.posX;
        double py = mc.player.posY;
        double pz = mc.player.posZ;
        int[][] goalTwoBlocks = { { tx, ty, tz }, { tx, ty - 1, tz } };
        for (int[] pos : goalTwoBlocks) {
            if (isWalkableStand(pos[0], pos[1], pos[2]) && !BlockAccess.isDangerous(pos[0], pos[1], pos[2])) {
                return pos;
            }
        }
        int[][] adjacent = { { tx + 1, ty, tz }, { tx - 1, ty, tz }, { tx, ty, tz + 1 }, { tx, ty, tz - 1 }, { tx + 1, ty - 1, tz }, { tx - 1, ty - 1, tz }, { tx, ty - 1, tz + 1 }, { tx, ty - 1, tz - 1 }, { tx + 1, ty + 1, tz }, { tx - 1, ty + 1, tz }, { tx, ty + 1, tz + 1 }, { tx, ty + 1, tz - 1 } };
        int[] bestAdjacent = null;
        double bestAdjDist = Double.MAX_VALUE;
        for (int[] pos : adjacent) {
            if (isWalkableStand(pos[0], pos[1], pos[2]) && !BlockAccess.isDangerous(pos[0], pos[1], pos[2])) {
                double d = (pos[0] + 0.5 - px) * (pos[0] + 0.5 - px) + (pos[1] - py) * (pos[1] - py) + (pos[2] + 0.5 - pz) * (pos[2] + 0.5 - pz);
                if (d < bestAdjDist) {
                    bestAdjDist = d;
                    bestAdjacent = pos;
                }
            }
        }
        if (bestAdjacent != null)
            return bestAdjacent;
        int[][] diagonal = { { tx + 1, ty, tz + 1 }, { tx + 1, ty, tz - 1 }, { tx - 1, ty, tz + 1 }, { tx - 1, ty, tz - 1 }, { tx + 1, ty - 1, tz + 1 }, { tx + 1, ty - 1, tz - 1 }, { tx - 1, ty - 1, tz + 1 }, { tx - 1, ty - 1, tz - 1 } };
        int[] bestDiag = null;
        double bestDiagDist = Double.MAX_VALUE;
        for (int[] pos : diagonal) {
            if (isWalkableStand(pos[0], pos[1], pos[2]) && !BlockAccess.isDangerous(pos[0], pos[1], pos[2])) {
                double d = (pos[0] + 0.5 - px) * (pos[0] + 0.5 - px) + (pos[1] - py) * (pos[1] - py) + (pos[2] + 0.5 - pz) * (pos[2] + 0.5 - pz);
                if (d < bestDiagDist) {
                    bestDiagDist = d;
                    bestDiag = pos;
                }
            }
        }
        if (bestDiag != null)
            return bestDiag;
        int reachInt = (int) MINE_REACH;
        double reachSq = MINE_REACH * MINE_REACH;
        int[] best = null;
        double bestDist = Double.MAX_VALUE;
        for (int ddx = -reachInt; ddx <= reachInt; ddx++) {
            for (int ddy = -reachInt; ddy <= reachInt; ddy++) {
                for (int ddz = -reachInt; ddz <= reachInt; ddz++) {
                    if (ddx == 0 && ddy == 0 && ddz == 0)
                        continue;
                    double distToOreSq = (double) (ddx * ddx) + (double) (ddy * ddy) + (double) (ddz * ddz);
                    if (distToOreSq > reachSq)
                        continue;
                    int sx = tx + ddx;
                    int sy = ty + ddy;
                    int sz = tz + ddz;
                    if (!isWalkableStand(sx, sy, sz))
                        continue;
                    if (BlockAccess.isDangerous(sx, sy, sz))
                        continue;
                    if (distToOreSq < bestDist) {
                        bestDist = distToOreSq;
                        if (best == null) {
                            best = new int[] { sx, sy, sz };
                        } else {
                            best[0] = sx;
                            best[1] = sy;
                            best[2] = sz;
                        }
                    }
                }
            }
        }
        return best;
    }

    private boolean isWalkableStand(int x, int y, int z) {
        return BlockAccess.canWalkThrough(x, y, z) && BlockAccess.canWalkThrough(x, y + 1, z) && (BlockAccess.canWalkOn(x, y - 1, z) || BlockAccess.isWater(x, y, z));
    }

    private void startBreakingObstruction(BlockPos obPos) {
        if (!allowBreak)
            return;
        executor.setWalkWhileBreaking(true);
        executor.clearInvalidation();
        savedMineTargetPos = mineTargetPos;
        mining = true;
        miningFirstTick = true;
        breakingObstruction = true;
        mineTargetPos = obPos;
        mineTargetFace = findBestMineFace(obPos);
        switchToBestTool(obPos);
        mineToolSlot = mc.player.inventory.currentItem;
        mc.player.setSprinting(false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
    }

    private void stopMining() {
        mining = false;
        mineToolSlot = -1;
        miningFirstTick = true;
        breakingObstruction = false;
        if (savedMineTargetPos != null) {
            mineTargetPos = savedMineTargetPos;
            savedMineTargetPos = null;
        }
        lastMineActualTarget = null;
        cachedCoveringBlock = null;
        cachedTraceTarget = null;
        executor.setWalkWhileBreaking(false);
        if (silentAimOwned) {
            SilentAimUtil.endStreak();
            SilentAimUtil.onDisable("Baritone");
            silentAimOwned = false;
            client.Client.INSTANCE.physicsConsistentAim = false;
        }
        executor.clearInvalidation();
        InteractionUtils.stopMining();
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
    }

    private void lookAtBlock(BlockPos pos, boolean fast) {
        double px = mc.player.posX;
        double eyeY = mc.player.posY + mc.player.getEyeHeight();
        double pz = mc.player.posZ;
        EnumFacing aimFace = findBestMineFace(pos);
        double targetX, targetY, targetZ;
        if (aimFace != null) {
            targetX = pos.getX() + 0.5 + aimFace.getFrontOffsetX() * 0.5;
            targetY = pos.getY() + 0.5 + aimFace.getFrontOffsetY() * 0.5;
            targetZ = pos.getZ() + 0.5 + aimFace.getFrontOffsetZ() * 0.5;
        } else {
            targetX = pos.getX() + 0.5;
            targetY = pos.getY() + 0.5;
            targetZ = pos.getZ() + 0.5;
        }
        double dx = targetX - px;
        double dy = targetY - eyeY;
        double dz = targetZ - pz;
        double distXZ = Math.sqrt(dx * dx + dz * dz);
        if (distXZ < 0.01) {
            double nudge = 0.1;
            float curYaw = mc.player.rotationYaw;
            dx = -Math.sin(Math.toRadians(curYaw)) * nudge;
            dz = Math.cos(Math.toRadians(curYaw)) * nudge;
            distXZ = nudge;
        }
        float targetYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, distXZ));
        float yawDiff = MathHelper.wrapDegrees(targetYaw - mc.player.rotationYaw);
        float pitchDiff = targetPitch - mc.player.rotationPitch;
        if (fast) {
            if (Math.abs(yawDiff) > 20.0f) {
                mc.player.rotationYaw += Math.copySign(20.0f, yawDiff);
            } else {
                mc.player.rotationYaw = targetYaw;
            }
            if (Math.abs(pitchDiff) > 15.0f) {
                mc.player.rotationPitch += Math.copySign(15.0f, pitchDiff);
            } else {
                mc.player.rotationPitch = targetPitch;
            }
        } else {
            if (Math.abs(yawDiff) > 60.0f) {
                mc.player.rotationYaw += Math.copySign(60.0f, yawDiff);
            } else if (Math.abs(yawDiff) > 1.0f) {
                mc.player.rotationYaw += yawDiff * 0.5f;
            }
            if (Math.abs(pitchDiff) > 60.0f) {
                mc.player.rotationPitch += Math.copySign(60.0f, pitchDiff);
            } else if (Math.abs(pitchDiff) > 1.0f) {
                mc.player.rotationPitch += pitchDiff * 0.5f;
            }
        }
        mc.player.rotationYaw = MathHelper.wrapDegrees(mc.player.rotationYaw);
    }

    private static double fastSqrt(double x) {
        if (x <= 0)
            return 0;
        double halfX = 0.5 * x;
        long i = Double.doubleToRawLongBits(x);
        i = 0x5FE6EB50B7E0000L - (i >> 1);
        double invSqrt = Double.longBitsToDouble(i);
        invSqrt *= (1.5 - halfX * invSqrt * invSqrt);
        invSqrt *= (1.5 - halfX * invSqrt * invSqrt);
        return x * invSqrt;
    }

    private EnumFacing findBestMineFace(BlockPos pos) {
        double px = mc.player.posX;
        double py = mc.player.posY + mc.player.getEyeHeight();
        double pz = mc.player.posZ;
        double cx = pos.getX() + 0.5;
        double cy = pos.getY() + 0.5;
        double cz = pos.getZ() + 0.5;
        double minBX = pos.getX();
        double minBY = pos.getY();
        double minBZ = pos.getZ();
        double maxBX = minBX + 1;
        double maxBY = minBY + 1;
        double maxBZ = minBZ + 1;
        double bestSideDist = Double.MAX_VALUE;
        EnumFacing bestSideFace = null;
        double bestVertDist = Double.MAX_VALUE;
        EnumFacing bestVertFace = null;
        Vec3d eyePos = new Vec3d(px, py, pz);
        EnumFacing[] faces = EnumFacing.values();
        for (int i = 0; i < faces.length; i++) {
            EnumFacing f = faces[i];
            boolean eyeConsistent;
            switch(f) {
                case NORTH:
                    eyeConsistent = pz <= minBZ;
                    break;
                case SOUTH:
                    eyeConsistent = pz >= maxBZ;
                    break;
                case WEST:
                    eyeConsistent = px <= minBX;
                    break;
                case EAST:
                    eyeConsistent = px >= maxBX;
                    break;
                case UP:
                    eyeConsistent = py >= maxBY;
                    break;
                case DOWN:
                    eyeConsistent = py <= minBY;
                    break;
                default:
                    eyeConsistent = false;
                    break;
            }
            if (!eyeConsistent)
                continue;
            double fx = cx + f.getFrontOffsetX() * 0.5;
            double fy = cy + f.getFrontOffsetY() * 0.5;
            double fz = cz + f.getFrontOffsetZ() * 0.5;
            Vec3d faceVec = new Vec3d(fx, fy, fz);
            RayTraceResult hit = mc.world.rayTraceBlocks(eyePos, faceVec, false, true, false);
            if (hit == null || hit.typeOfHit != RayTraceResult.Type.BLOCK || !hit.getBlockPos().equals(pos) || hit.sideHit != f) {
                continue;
            }
            double d = (px - fx) * (px - fx) + (py - fy) * (py - fy) + (pz - fz) * (pz - fz);
            boolean isSide = f == EnumFacing.NORTH || f == EnumFacing.SOUTH || f == EnumFacing.EAST || f == EnumFacing.WEST;
            if (isSide && d < bestSideDist) {
                bestSideDist = d;
                bestSideFace = f;
            } else if (!isSide && d < bestVertDist) {
                bestVertDist = d;
                bestVertFace = f;
            }
        }
        if (bestSideFace != null)
            return bestSideFace;
        if (bestVertFace != null)
            return bestVertFace;
        Vec3d centerVec = new Vec3d(cx, cy, cz);
        RayTraceResult centerHit = mc.world.rayTraceBlocks(eyePos, centerVec, false, true, false);
        if (centerHit != null && centerHit.typeOfHit == RayTraceResult.Type.BLOCK && centerHit.getBlockPos().equals(pos) && centerHit.sideHit != null) {
            return centerHit.sideHit;
        }
        return null;
    }

    private void switchToBestTool(BlockPos pos) {
        if (mc.player == null)
            return;
        if (!autoTool)
            return;
        IBlockState state = mc.world.getBlockState(pos);
        int bestSlot = -1;
        float bestSpeed = -1.0f;
        boolean bestCanHarvest = false;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (stack.func_190926_b())
                continue;
            if (stack.getMaxDamage() > 0 && stack.getMaxDamage() - stack.getItemDamage() <= minToolDurability) {
                continue;
            }
            float speed = stack.getStrVsBlock(state);
            boolean canHarvest = stack.getItem().canHarvestBlock(state);
            if (bestSlot == -1 || (canHarvest && !bestCanHarvest) || (canHarvest == bestCanHarvest && speed > bestSpeed)) {
                bestSlot = i;
                bestSpeed = speed;
                bestCanHarvest = canHarvest;
            }
        }
        if (bestSlot < 0 && allowInventory) {
            for (int i = 9; i < 36; i++) {
                ItemStack stack = mc.player.inventory.mainInventory.get(i);
                if (stack.func_190926_b())
                    continue;
                if (stack.getMaxDamage() > 0 && stack.getMaxDamage() - stack.getItemDamage() <= minToolDurability) {
                    continue;
                }
                float speed = stack.getStrVsBlock(state);
                boolean canHarvest = stack.getItem().canHarvestBlock(state);
                if (bestSlot == -1 || (canHarvest && !bestCanHarvest) || (canHarvest == bestCanHarvest && speed > bestSpeed)) {
                    int hotbar = moveToHotbar(i);
                    if (hotbar >= 0) {
                        bestSlot = hotbar;
                        bestSpeed = speed;
                        bestCanHarvest = canHarvest;
                    }
                }
            }
        }
        if (bestSlot >= 0 && bestSpeed > 1.0f && bestSlot != mc.player.inventory.currentItem) {
            mc.player.inventory.currentItem = bestSlot;
        }
    }

    private int moveToHotbar(int invSlot) {
        if (!allowInventory)
            return -1;
        if (mc.player == null)
            return -1;
        if (invSlot < 9 || invSlot > 35)
            return -1;
        int emptySlot = -1;
        for (int i = 0; i < 9; i++) {
            if (mc.player.inventory.mainInventory.get(i).func_190926_b()) {
                emptySlot = i;
                break;
            }
        }
        if (emptySlot < 0)
            return -1;
        int windowSlot = invSlot + 9;
        int hotbarWindowSlot = emptySlot + 36;
        mc.playerController.windowClick(mc.player.openContainer.windowId, windowSlot, emptySlot, ClickType.SWAP, mc.player);
        return emptySlot;
    }

    private int ensureBlockInHotbar(Block block) {
        if (mc.player == null)
            return -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.inventory.mainInventory.get(i);
            if (!s.func_190926_b() && s.getItem() instanceof ItemBlock && ((ItemBlock) s.getItem()).getBlock() == block) {
                return i;
            }
        }
        for (int i = 9; i < 36; i++) {
            ItemStack s = mc.player.inventory.mainInventory.get(i);
            if (!s.func_190926_b() && s.getItem() instanceof ItemBlock && ((ItemBlock) s.getItem()).getBlock() == block) {
                return moveToHotbar(i);
            }
        }
        return -1;
    }

    public double getBlockReachDistance() {
        return blockReachDistance;
    }

    private boolean isOre(Block block) {
        if (block == Blocks.DIAMOND_ORE || block == Blocks.IRON_ORE || block == Blocks.GOLD_ORE || block == Blocks.COAL_ORE || block == Blocks.LAPIS_ORE || block == Blocks.REDSTONE_ORE || block == Blocks.EMERALD_ORE || block == Blocks.QUARTZ_ORE) {
            for (int i = 0; i < blacklistedOres.size(); i++) {
                if (blacklistedOres.get(i) == block) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    private boolean isLog(Block block) {
        return block == Blocks.LOG || block == Blocks.LOG2;
    }

    private int[] findNearestLog(int radius) {
        if (mc.player == null || mc.world == null)
            return null;
        int pcx = (int) Math.floor(mc.player.posX);
        int pcy = (int) Math.floor(mc.player.posY);
        int pcz = (int) Math.floor(mc.player.posZ);
        int[] best = null;
        double bestDist = Double.MAX_VALUE;
        int chunkRadius = (radius >> 4) + 1;
        int yMin = Math.max(0, pcy - radius);
        int yMax = Math.min(255, pcy + radius);
        for (int cx = -chunkRadius; cx <= chunkRadius; cx++) {
            for (int cz = -chunkRadius; cz <= chunkRadius; cz++) {
                int chunkX = (pcx >> 4) + cx;
                int chunkZ = (pcz >> 4) + cz;
                Chunk chunk = mc.world.getChunkFromChunkCoords(chunkX, chunkZ);
                if (chunk == null || !chunk.isLoaded())
                    continue;
                int worldXBase = chunkX << 4;
                int worldZBase = chunkZ << 4;
                for (int lx = 0; lx < 16; lx++) {
                    for (int lz = 0; lz < 16; lz++) {
                        int wx = worldXBase + lx;
                        int wz = worldZBase + lz;
                        double dxC = wx + 0.5 - mc.player.posX;
                        double dzC = wz + 0.5 - mc.player.posZ;
                        double xzDistSq = dxC * dxC + dzC * dzC;
                        if (xzDistSq > bestDist)
                            continue;
                        for (int y = yMin; y <= yMax; y++) {
                            if (isLog(chunk.getBlockState(lx, y, lz).getBlock())) {
                                double dx = wx + 0.5 - mc.player.posX;
                                double dy = y + 0.5 - mc.player.posY;
                                double dz = wz + 0.5 - mc.player.posZ;
                                double d = dx * dx + dy * dy + dz * dz;
                                if (d < bestDist) {
                                    bestDist = d;
                                    if (best == null)
                                        best = new int[3];
                                    best[0] = wx;
                                    best[1] = y;
                                    best[2] = wz;
                                }
                            }
                        }
                    }
                }
            }
        }
        return best;
    }

    private int[] findNearestOre(int radius) {
        if (mc.player == null || mc.world == null)
            return null;
        int pcx = (int) Math.floor(mc.player.posX);
        int pcy = (int) Math.floor(mc.player.posY);
        int pcz = (int) Math.floor(mc.player.posZ);
        int[] best = null;
        double bestDist = Double.MAX_VALUE;
        int chunkRadius = (radius >> 4) + 1;
        int yMin = Math.max(0, pcy - radius);
        int yMax = Math.min(128, pcy + radius);
        for (int cx = -chunkRadius; cx <= chunkRadius; cx++) {
            for (int cz = -chunkRadius; cz <= chunkRadius; cz++) {
                int chunkX = (pcx >> 4) + cx;
                int chunkZ = (pcz >> 4) + cz;
                Chunk chunk = mc.world.getChunkFromChunkCoords(chunkX, chunkZ);
                if (chunk == null || !chunk.isLoaded())
                    continue;
                int worldXBase = chunkX << 4;
                int worldZBase = chunkZ << 4;
                for (int lx = 0; lx < 16; lx++) {
                    for (int lz = 0; lz < 16; lz++) {
                        int wx = worldXBase + lx;
                        int wz = worldZBase + lz;
                        double dxC = wx + 0.5 - mc.player.posX;
                        double dzC = wz + 0.5 - mc.player.posZ;
                        double xzDistSq = dxC * dxC + dzC * dzC;
                        if (xzDistSq > bestDist)
                            continue;
                        for (int y = yMin; y <= yMax; y++) {
                            Block b = chunk.getBlockState(lx, y, lz).getBlock();
                            if (isOre(b)) {
                                double dx = wx + 0.5 - mc.player.posX;
                                double dy = y + 0.5 - mc.player.posY;
                                double dz = wz + 0.5 - mc.player.posZ;
                                double dist = dx * dx + dy * dy + dz * dz;
                                if (dist < bestDist) {
                                    bestDist = dist;
                                    if (best == null)
                                        best = new int[3];
                                    best[0] = wx;
                                    best[1] = y;
                                    best[2] = wz;
                                }
                            }
                        }
                    }
                }
            }
        }
        return best;
    }

    private java.util.ArrayList<int[]> findAllOres(int radius, int maxResults) {
        java.util.ArrayList<int[]> results = new java.util.ArrayList<>();
        if (mc.player == null || mc.world == null)
            return results;
        int pcx = (int) Math.floor(mc.player.posX);
        int pcy = (int) Math.floor(mc.player.posY);
        int pcz = (int) Math.floor(mc.player.posZ);
        int chunkRadius = (radius >> 4) + 1;
        int yMin = Math.max(0, pcy - radius);
        int yMax = Math.min(128, pcy + radius);
        BlockPos mutPos = new BlockPos(0, 0, 0);
        for (int cx = -chunkRadius; cx <= chunkRadius; cx++) {
            for (int cz = -chunkRadius; cz <= chunkRadius; cz++) {
                int chunkX = (pcx >> 4) + cx;
                int chunkZ = (pcz >> 4) + cz;
                net.minecraft.world.chunk.Chunk chunk = mc.world.getChunkFromChunkCoords(chunkX, chunkZ);
                if (chunk == null || !chunk.isLoaded())
                    continue;
                int baseX = chunkX << 4;
                int baseZ = chunkZ << 4;
                for (int x = 0; x < 16; x++) {
                    for (int z = 0; z < 16; z++) {
                        int wx = baseX + x;
                        int wz = baseZ + z;
                        for (int y = yMin; y <= yMax; y++) {
                            mutPos.setPos(wx, y, wz);
                            Block b = chunk.getBlockState(mutPos).getBlock();
                            if (isOre(b) && !shouldAvoidBreaking(wx, y, wz)) {
                                if (legitMine && !isExposed(wx, y, wz)) {
                                    continue;
                                }
                                results.add(new int[] { wx, y, wz });
                                if (results.size() >= maxResults) {
                                    return results;
                                }
                            }
                        }
                    }
                }
            }
        }
        return results;
    }

    private boolean tryVeinMine() {
        if (mc.player == null)
            return false;
        Block target = null;
        boolean checkOre = false;
        boolean checkLog = false;
        if (mineTargetBlock.equals("ores")) {
            checkOre = true;
        } else if (mineTargetBlock.equals("logs")) {
            checkLog = true;
        } else {
            target = getBlockByName(mineTargetBlock);
            if (target == null)
                return false;
        }
        int px = (int) Math.floor(mc.player.posX);
        int py = (int) Math.floor(mc.player.posY);
        int pz = (int) Math.floor(mc.player.posZ);
        int[][] offsets = { { 1, 0, 0 }, { -1, 0, 0 }, { 0, 1, 0 }, { 0, -1, 0 }, { 0, 0, 1 }, { 0, 0, -1 }, { 1, 1, 0 }, { -1, 1, 0 }, { 1, -1, 0 }, { -1, -1, 0 }, { 1, 0, 1 }, { -1, 0, 1 }, { 1, 0, -1 }, { -1, 0, -1 }, { 0, 1, 1 }, { 0, 1, -1 }, { 0, -1, 1 }, { 0, -1, -1 }, { 1, 1, 1 }, { -1, 1, 1 }, { 1, -1, 1 }, { -1, -1, 1 }, { 1, 1, -1 }, { -1, 1, -1 }, { 1, -1, -1 }, { -1, -1, -1 } };
        int bestBx = 0, bestBy = 0, bestBz = 0;
        double bestVeinDistSq = Double.MAX_VALUE;
        for (int i = 0; i < offsets.length; i++) {
            if (offsets[i][0] == 0 && offsets[i][2] == 0 && offsets[i][1] == -1) {
                continue;
            }
            int bx = px + offsets[i][0];
            int by = py + offsets[i][1];
            int bz = pz + offsets[i][2];
            Block found = mc.world.getBlockState(new BlockPos(bx, by, bz)).getBlock();
            boolean match;
            if (checkOre) {
                match = isOre(found);
            } else if (checkLog) {
                match = isLog(found);
            } else {
                match = (found == target);
            }
            if (match) {
                if (shouldAvoidBreaking(bx, by, bz)) {
                    continue;
                }
                if (mineBlacklist.get(PathNode.longHash(bx, by, bz)) == 1) {
                    continue;
                }
                double dx = (bx + 0.5) - mc.player.posX;
                double dy = (by + 0.5) - mc.player.posY;
                double dz = (bz + 0.5) - mc.player.posZ;
                double distSq = dx * dx + dy * dy + dz * dz;
                if (distSq <= MINE_REACH * MINE_REACH && distSq < bestVeinDistSq) {
                    bestVeinDistSq = distSq;
                    bestBx = bx;
                    bestBy = by;
                    bestBz = bz;
                }
            }
        }
        if (bestVeinDistSq < Double.MAX_VALUE) {
            mineTargetPos = new BlockPos(bestBx, bestBy, bestBz);
            mining = true;
            miningFirstTick = true;
            mineToolSlot = -1;
            return true;
        }
        return false;
    }

    private void advanceToNextMineTarget() {
        if (!nullCheck())
            return;
        revalidateMineCandidates();
        if (collectNearbyDrops()) {
            return;
        }
        long now = System.currentTimeMillis();
        if (!mineCandidates.isEmpty()) {
            applyMineScanCandidates(mineCandidates);
            if (!mineScanActive && now - lastMineScanCompleteMs > MINE_CACHE_STALE_MS) {
                startMineScan(false);
            }
            return;
        }
        if (mineExploreActive) {
            setNextMineExploreGoal();
            return;
        }
        stopMining();
        if (executor.hasPath() || pathRequested) {
            cancelPath();
        }
        currentGoal = null;
        goalDescription = "";
        if (mineScanActive) {
            mineScanApplyOnDone = true;
            return;
        }
        startMineScan(true);
    }

    private void revalidateMineCandidates() {
        if (mineCandidates.isEmpty() || mc.player == null || mc.world == null) {
            return;
        }
        for (int i = mineCandidates.size() - 1; i >= 0; i--) {
            int[] p = mineCandidates.get(i);
            if (mineBlacklist.get(PathNode.longHash(p[0], p[1], p[2])) == 1) {
                mineCandidates.remove(i);
                continue;
            }
            mineScanPos.setPos(p[0], p[1], p[2]);
            if (!mc.world.isBlockLoaded(mineScanPos)) {
                continue;
            }
            Block cur = mc.world.getBlockState(mineScanPos).getBlock();
            if (cur == Blocks.AIR || !matchesMineTarget(cur)) {
                mineCandidates.remove(i);
            }
        }
        int n = mineCandidates.size();
        double[] dists = new double[n];
        for (int i = 0; i < n; i++) {
            int[] p = mineCandidates.get(i);
            double dx = (p[0] + 0.5) - mc.player.posX;
            double dy = (p[1] + 0.5) - mc.player.posY;
            double dz = (p[2] + 0.5) - mc.player.posZ;
            dists[i] = dx * dx + dy * dy + dz * dz;
        }
        for (int i = 1; i < n; i++) {
            int[] pos = mineCandidates.get(i);
            double d = dists[i];
            int j = i - 1;
            while (j >= 0 && dists[j] > d) {
                mineCandidates.set(j + 1, mineCandidates.get(j));
                dists[j + 1] = dists[j];
                j--;
            }
            mineCandidates.set(j + 1, pos);
            dists[j + 1] = d;
        }
    }

    private void applyMineScanCandidates(java.util.ArrayList<int[]> candidates) {
        if (mc.player == null || candidates.isEmpty()) {
            if (mineContinuous && exploreForBlocks && mc.player != null && !mineTargetBlock.isEmpty()) {
                if (!mineExploreActive) {
                    ChatUtils.message("No " + mineTargetBlock + " nearby - exploring for more" + " (#stop to cancel)");
                    startMineExplore();
                } else {
                    setNextMineExploreGoal();
                }
                return;
            }
            ChatUtils.message("No more " + mineTargetBlock + " nearby");
            mineContinuous = false;
            stopMining();
            mineTargetPos = null;
            currentGoal = null;
            goalDescription = "";
            dropPickupActive = false;
            anticipatedDrops.clear();
            dropPickupAttempts = 0;
            dropPickupCooldownUntilMs = 0;
            mineExploreActive = false;
            return;
        }
        if (mining && mineTargetPos != null && mc.world != null && mc.world.getBlockState(mineTargetPos).getBlock() != Blocks.AIR) {
            return;
        }
        int bestI = 0;
        double bestSq = Double.MAX_VALUE;
        for (int i = 0; i < candidates.size(); i++) {
            int[] p = candidates.get(i);
            if (isPlayerSupport(p[0], p[1], p[2])) {
                continue;
            }
            if (mineBlacklist.get(PathNode.longHash(p[0], p[1], p[2])) == 1) {
                continue;
            }
            double dx = (p[0] + 0.5) - mc.player.posX;
            double dy = (p[1] + 0.5) - mc.player.posY;
            double dz = (p[2] + 0.5) - mc.player.posZ;
            double dsq = dx * dx + dy * dy + dz * dz;
            if (dsq < bestSq) {
                bestSq = dsq;
                bestI = i;
            }
        }
        if (bestI != 0) {
            int[] tmp = candidates.get(0);
            candidates.set(0, candidates.get(bestI));
            candidates.set(bestI, tmp);
        }
        stopMining();
        int[] first = candidates.get(0);
        if (mc.world != null && bestSq <= MINE_REACH * MINE_REACH) {
            BlockPos direct = new BlockPos(first[0], first[1], first[2]);
            Block db = mc.world.getBlockState(direct).getBlock();
            if (db != Blocks.AIR && matchesMineTarget(db) && mineBlacklist.get(PathNode.longHash(first[0], first[1], first[2])) != 1 && !isPlayerSupport(first[0], first[1], first[2])) {
                executor.clearPath();
                if (finder != null) {
                    finder.cancel();
                    finder = null;
                }
                pathRequested = false;
                pathCompleted = false;
                pathFailed = false;
                pathFailCount = 0;
                consecutivePartials = 0;
                segmentFailStreak = 0;
                segFailPosValid = false;
                currentGoal = null;
                goalDescription = "Mine " + mineTargetBlock;
                mineTargetPos = direct;
                mining = true;
                miningFirstTick = true;
                mineToolSlot = -1;
                mc.player.setSprinting(false);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
                throttleMineTargetChat(first);
                return;
            }
        }
        mineTargetPos = new BlockPos(first[0], first[1], first[2]);
        pathCompleted = false;
        pathFailed = false;
        pathFailCount = 0;
        Goal composite = buildMineCompositeGoal(candidates);
        if (!mining && executor.hasPath() && currentGoal != null) {
            int[] dest = executor.getDestination();
            boolean oldInGoal = currentGoal.isInGoal(dest[0], dest[1], dest[2]);
            boolean newInGoal = composite.isInGoal(dest[0], dest[1], dest[2]);
            if (oldInGoal && newInGoal) {
                currentGoal = composite;
                goalDescription = "Mine " + mineTargetBlock + " (" + candidates.size() + " targets)";
                throttleMineTargetChat(first);
                return;
            }
        }
        setGoal(composite, "Mine " + mineTargetBlock + " (" + candidates.size() + " targets)");
        throttleMineTargetChat(first);
    }

    private void throttleMineTargetChat(int[] first) {
        long now = System.currentTimeMillis();
        if (now - lastMineTargetChatMs < 2000L)
            return;
        lastMineTargetChatMs = now;
        ChatUtils.success("Found next " + mineTargetBlock + " at " + first[0] + ", " + first[1] + ", " + first[2]);
    }

    private boolean matchesMineDrop(ItemStack stack) {
        if (stack == null || stack.func_190926_b()) {
            return false;
        }
        net.minecraft.item.Item it = stack.getItem();
        if (mineTargetBlock.equals("ores")) {
            if (it instanceof net.minecraft.item.ItemBlock) {
                return isOre(Block.getBlockFromItem(it));
            }
            return it == net.minecraft.init.Items.DIAMOND || it == net.minecraft.init.Items.COAL || it == net.minecraft.init.Items.REDSTONE || it == net.minecraft.init.Items.EMERALD || (it == net.minecraft.init.Items.DYE && stack.getMetadata() == 4);
        }
        if (mineTargetBlock.equals("logs")) {
            return it instanceof net.minecraft.item.ItemBlock && isLog(Block.getBlockFromItem(it));
        }
        Block target = getBlockByName(mineTargetBlock);
        if (target == null) {
            return false;
        }
        if (Item.getItemFromBlock(target) == it) {
            return true;
        }
        return target == Blocks.STONE && it == Item.getItemFromBlock(Blocks.COBBLESTONE);
    }

    private int countMatchingMineItems() {
        if (mc.player == null)
            return 0;
        int total = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (stack.func_190926_b())
                continue;
            if (matchesMineDrop(stack)) {
                total += stack.func_190916_E();
            }
        }
        return total;
    }

    private boolean collectNearbyDrops() {
        if (mc.player == null || mc.world == null) {
            return false;
        }
        long now = System.currentTimeMillis();
        if (now < dropPickupCooldownUntilMs) {
            dropPickupActive = false;
            anticipatedDrops.clear();
            dropPickupAttempts = 0;
            return false;
        }
        for (int i = anticipatedDrops.size() - 1; i >= 0; i--) {
            if (anticipatedDrops.get(i)[3] < now) {
                anticipatedDrops.remove(i);
            }
        }
        if (dropPickupActive && (now > dropPickupDeadlineMs || anticipatedDrops.isEmpty())) {
            dropPickupActive = false;
            anticipatedDrops.clear();
            dropPickupAttempts = 0;
            return false;
        }
        if (dropPickupActive) {
            if (executor.hasPath() || pathRequested) {
                return true;
            }
            dropPickupAttempts++;
            if (dropPickupAttempts >= 2) {
                dropPickupActive = false;
                anticipatedDrops.clear();
                dropPickupCooldownUntilMs = now + MINE_PICKUP_COOLDOWN_MS;
                return false;
            }
            dropPickupActive = false;
        }
        java.util.ArrayList<int[]> drops = null;
        for (int ei = 0; ei < mc.world.loadedEntityList.size(); ei++) {
            net.minecraft.entity.Entity e = mc.world.loadedEntityList.get(ei);
            if (!(e instanceof net.minecraft.entity.item.EntityItem)) {
                continue;
            }
            net.minecraft.entity.item.EntityItem item = (net.minecraft.entity.item.EntityItem) e;
            if (item.isDead) {
                continue;
            }
            if (!matchesMineDrop(item.getEntityItem())) {
                continue;
            }
            double dsq = mc.player.getDistanceSqToEntity(item);
            if (dsq > MINE_PICKUP_RANGE_SQ) {
                continue;
            }
            if (drops == null) {
                drops = new java.util.ArrayList<>();
            }
            drops.add(new int[] { (int) Math.floor(item.posX), (int) Math.floor(item.posY), (int) Math.floor(item.posZ) });
        }
        for (int i = anticipatedDrops.size() - 1; i >= 0; i--) {
            int[] p = anticipatedDrops.get(i);
            boolean entityNear = false;
            if (drops != null) {
                for (int j = 0; j < drops.size(); j++) {
                    int[] d = drops.get(j);
                    int ddx = d[0] - p[0];
                    int ddy = d[1] - p[1];
                    int ddz = d[2] - p[2];
                    if (ddx * ddx + ddy * ddy + ddz * ddz <= 9) {
                        entityNear = true;
                        break;
                    }
                }
            }
            if (entityNear || now + 800L < p[3]) {
                if (entityNear) {
                    anticipatedDrops.remove(i);
                }
                continue;
            }
            anticipatedDrops.remove(i);
        }
        if (!anticipatedDrops.isEmpty() && drops == null) {
            drops = new java.util.ArrayList<>();
        }
        for (int i = 0; i < anticipatedDrops.size(); i++) {
            int[] p = anticipatedDrops.get(i);
            drops.add(new int[] { p[0], p[1], p[2] });
        }
        if (drops == null || drops.isEmpty()) {
            return false;
        }
        double nearestDropSq = Double.MAX_VALUE;
        for (int i = 0; i < drops.size(); i++) {
            double ddx = drops.get(i)[0] + 0.5 - mc.player.posX;
            double ddy = drops.get(i)[1] + 0.5 - mc.player.posY;
            double ddz = drops.get(i)[2] + 0.5 - mc.player.posZ;
            double dsq = ddx * ddx + ddy * ddy + ddz * ddz;
            if (dsq < nearestDropSq) {
                nearestDropSq = dsq;
            }
        }
        if (nearestDropSq <= 2.25) {
            dropPickupActive = false;
            anticipatedDrops.clear();
            dropPickupAttempts = 0;
            return false;
        }
        int goalCount = Math.min(drops.size(), 8);
        Goal[] goals = new Goal[goalCount];
        for (int i = 0; i < goalCount; i++) {
            goals[i] = new GoalBlock(drops.get(i)[0], drops.get(i)[1], drops.get(i)[2]);
        }
        stopMining();
        mineTargetPos = null;
        dropPickupActive = true;
        dropPickupDeadlineMs = now + MINE_PICKUP_MAX_MS;
        setGoal(new GoalComposite(goals), "Collecting drops (" + drops.size() + ")");
        return true;
    }

    private void startMineExplore() {
        if (mc.player == null)
            return;
        mineExploreActive = true;
        stopMining();
        mineTargetPos = null;
        mineExploreX = (int) Math.floor(mc.player.posX);
        mineExploreZ = (int) Math.floor(mc.player.posZ);
        mineExploreNextScanMs = System.currentTimeMillis() + 6000L;
        if (mineTargetBlock.equals("ores") && mc.player.posY > 20) {
            setGoal(new GoalYLevel(12), "Exploring for ores (descending to Y12)");
        } else {
            setNextMineExploreGoal();
        }
    }

    private void setNextMineExploreGoal() {
        if (mc.player == null)
            return;
        float yaw = mc.player.rotationYaw;
        yaw += (float) ((Math.random() - 0.5) * 90.0);
        double rad = Math.toRadians(yaw);
        int dist = 40;
        int tx = (int) Math.floor(mc.player.posX - Math.sin(rad) * dist);
        int tz = (int) Math.floor(mc.player.posZ + Math.cos(rad) * dist);
        mineExploreX = tx;
        mineExploreZ = tz;
        setGoal(new GoalNearXZ(tx, tz, 8), "Exploring for " + mineTargetBlock);
        if (!mineScanActive) {
            startMineScan(false);
        }
    }

    private boolean matchesMineTarget(Block b) {
        if (mineTargetBlock.equals("ores")) {
            return isOre(b);
        }
        if (mineTargetBlock.equals("logs")) {
            return isLog(b);
        }
        Block target = getBlockByName(mineTargetBlock);
        return target != null && b == target;
    }

    private void startMineScan(boolean applyOnDone) {
        if (!nullCheck())
            return;
        int pcx = (int) Math.floor(mc.player.posX);
        int pcz = (int) Math.floor(mc.player.posZ);
        int pcy = (int) Math.floor(mc.player.posY);
        mineScanChunkRadius = Math.min((mineSearchRadius >> 4) + 1, 8);
        mineScanBaseCX = pcx >> 4;
        mineScanBaseCZ = pcz >> 4;
        mineScanYMin = Math.max(0, pcy - MINE_SCAN_Y_RANGE);
        mineScanYMax = Math.min(128, pcy + MINE_SCAN_Y_RANGE);
        mineScanRing = 0;
        mineScanRingI = 0;
        mineScanApplyOnDone = applyOnDone;
        mineScanResults.clear();
        mineScanDists.clear();
        mineScanWorstSq = Double.MAX_VALUE;
        mineScanActive = true;
    }

    private void tickMineScan() {
        if (mc.player == null || mc.world == null) {
            mineScanActive = false;
            return;
        }
        long budget = (executor.hasPath() || pathRequested || mining) ? MINE_SCAN_BUDGET_NS : MINE_SCAN_BUDGET_IDLE_NS;
        long deadline = System.nanoTime() + budget;
        while (mineScanActive && System.nanoTime() < deadline) {
            scanRingCell();
            advanceScanCursor();
            if (!mineScanActive)
                break;
            if (mineScanApplyOnDone && mineScanRing >= 2 && !mineScanResults.isEmpty()) {
                applyMineScanCandidates(new java.util.ArrayList<>(mineScanResults));
                mineScanApplyOnDone = false;
            }
        }
    }

    private void scanRingCell() {
        int r = mineScanRing;
        int i = mineScanRingI;
        int dx, dz;
        if (r == 0) {
            dx = 0;
            dz = 0;
        } else {
            int side = 2 * r;
            if (i < side) {
                dx = -r + i;
                dz = -r;
            } else if (i < 2 * side) {
                dx = r;
                dz = -r + (i - side);
            } else if (i < 3 * side) {
                dx = r - (i - 2 * side);
                dz = r;
            } else {
                dx = -r;
                dz = r - (i - 3 * side);
            }
        }
        scanOneChunk(mineScanBaseCX + dx, mineScanBaseCZ + dz);
    }

    private void advanceScanCursor() {
        mineScanRingI++;
        int cells = mineScanRing == 0 ? 1 : 8 * mineScanRing;
        if (mineScanRingI >= cells) {
            mineScanRing++;
            mineScanRingI = 0;
            if (mineScanRing > mineScanChunkRadius) {
                finishMineScan();
            }
        }
    }

    private void scanOneChunk(int chunkX, int chunkZ) {
        Chunk chunk = mc.world.getChunkFromChunkCoords(chunkX, chunkZ);
        if (chunk == null || !chunk.isLoaded())
            return;
        boolean canPillar = client.baritone.pathing.BlockAccess.getPlaceableBlockSlot() >= 0;
        int playerFeetY = (int) Math.floor(mc.player.posY);
        int baseX = chunkX << 4;
        int baseZ = chunkZ << 4;
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                int wx = baseX + x;
                int wz = baseZ + z;
                double dxBase = wx + 0.5 - mc.player.posX;
                double dzBase = wz + 0.5 - mc.player.posZ;
                double xzDistSq = dxBase * dxBase + dzBase * dzBase;
                if (xzDistSq > mineScanWorstSq)
                    continue;
                for (int y = mineScanYMin; y <= mineScanYMax; y++) {
                    double dyBase = y + 0.5 - mc.player.posY;
                    double distSq = xzDistSq + dyBase * dyBase;
                    if (distSq > mineScanWorstSq)
                        continue;
                    mineScanPos.setPos(wx, y, wz);
                    Block b = chunk.getBlockState(mineScanPos).getBlock();
                    if (!matchesMineTarget(b))
                        continue;
                    if (shouldAvoidBreaking(wx, y, wz))
                        continue;
                    if (mineBlacklist.get(PathNode.longHash(wx, y, wz)) == 1)
                        continue;
                    if (legitMine && !isExposed(wx, y, wz))
                        continue;
                    if (!canPillar && y > playerFeetY + 2) {
                        mineScanPos.setPos(wx, y - 1, wz);
                        Block below = chunk.getBlockState(mineScanPos).getBlock();
                        if (below == Blocks.AIR) {
                            mineScanPos.setPos(wx, y - 2, wz);
                            Block below2 = chunk.getBlockState(mineScanPos).getBlock();
                            if (below2 == Blocks.AIR) {
                                continue;
                            }
                        }
                    }
                    if (mineScanResults.size() < MINE_CANDIDATE_COUNT) {
                        mineScanResults.add(new int[] { wx, y, wz });
                        mineScanDists.add(new double[] { distSq });
                        if (mineScanResults.size() == MINE_CANDIDATE_COUNT) {
                            recomputeMineScanWorst();
                        }
                    } else if (distSq < mineScanWorstSq) {
                        int worstI = 0;
                        double worst = mineScanDists.get(0)[0];
                        for (int di = 1; di < mineScanDists.size(); di++) {
                            double dv = mineScanDists.get(di)[0];
                            if (dv > worst) {
                                worst = dv;
                                worstI = di;
                            }
                        }
                        mineScanResults.set(worstI, new int[] { wx, y, wz });
                        mineScanDists.set(worstI, new double[] { distSq });
                        recomputeMineScanWorst();
                    }
                }
            }
        }
    }

    private void recomputeMineScanWorst() {
        mineScanWorstSq = 0;
        for (int di = 0; di < mineScanDists.size(); di++) {
            double dv = mineScanDists.get(di)[0];
            if (dv > mineScanWorstSq)
                mineScanWorstSq = dv;
        }
    }

    private void finishMineScan() {
        mineScanActive = false;
        for (int i = 1; i < mineScanResults.size(); i++) {
            int[] pos = mineScanResults.get(i);
            double d = mineScanDists.get(i)[0];
            int j = i - 1;
            while (j >= 0 && mineScanDists.get(j)[0] > d) {
                mineScanResults.set(j + 1, mineScanResults.get(j));
                mineScanDists.set(j + 1, mineScanDists.get(j));
                j--;
            }
            mineScanResults.set(j + 1, pos);
            mineScanDists.set(j + 1, new double[] { d });
        }
        if (mineScanResults.size() > MINE_CANDIDATE_COUNT) {
            mineScanResults.subList(MINE_CANDIDATE_COUNT, mineScanResults.size()).clear();
            mineScanDists.subList(MINE_CANDIDATE_COUNT, mineScanDists.size()).clear();
        }
        mineCandidates.clear();
        mineCandidates.addAll(mineScanResults);
        revalidateMineCandidates();
        lastMineScanCompleteMs = System.currentTimeMillis();
        if (mineScanApplyOnDone) {
            mineScanApplyOnDone = false;
            applyMineScanCandidates(mineCandidates);
        } else if (mineExploreActive && !mineCandidates.isEmpty()) {
            mineExploreActive = false;
            applyMineScanCandidates(mineCandidates);
        }
    }

    private Goal buildMineCompositeGoal(java.util.ArrayList<int[]> candidates) {
        Goal[] goals = new Goal[candidates.size()];
        for (int i = 0; i < candidates.size(); i++) {
            int[] p = candidates.get(i);
            boolean fallingAbove = false;
            if (mc.world != null) {
                IBlockState above = mc.world.getBlockState(new BlockPos(p[0], p[1] + 1, p[2]));
                if (above.getBlock() instanceof net.minecraft.block.BlockFalling) {
                    fallingAbove = true;
                }
            }
            goals[i] = fallingAbove ? new GoalTwoBlocks(p[0], p[1], p[2]) : new GoalThreeBlocks(p[0], p[1], p[2]);
        }
        return new GoalComposite(goals);
    }

    private boolean isPlayerSupport(int x, int y, int z) {
        if (mc.player == null || !mc.player.onGround) {
            return false;
        }
        return x == (int) Math.floor(mc.player.posX) && z == (int) Math.floor(mc.player.posZ) && y == (int) Math.floor(mc.player.posY) - 1;
    }

    private BlockPos findMineTargetNearPlayer() {
        if (mc.player == null || mc.world == null)
            return null;
        int px = (int) Math.floor(mc.player.posX);
        int py = (int) Math.floor(mc.player.posY);
        int pz = (int) Math.floor(mc.player.posZ);
        BlockPos best = null;
        double bestSq = MINE_REACH * MINE_REACH;
        BlockPos check = new BlockPos(0, 0, 0);
        for (int dy = -2; dy <= 3; dy++) {
            for (int dx = -5; dx <= 5; dx++) {
                for (int dz = -5; dz <= 5; dz++) {
                    if (dx == 0 && dz == 0 && dy < 0) {
                        continue;
                    }
                    int wx = px + dx;
                    int wy = py + dy;
                    int wz = pz + dz;
                    double ddx = (wx + 0.5) - mc.player.posX;
                    double ddy = (wy + 0.5) - mc.player.posY;
                    double ddz = (wz + 0.5) - mc.player.posZ;
                    double dsq = ddx * ddx + ddy * ddy + ddz * ddz;
                    if (dsq >= bestSq)
                        continue;
                    check.setPos(wx, wy, wz);
                    Block b = mc.world.getBlockState(check).getBlock();
                    if (!matchesMineTarget(b))
                        continue;
                    if (shouldAvoidBreaking(wx, wy, wz))
                        continue;
                    if (mineBlacklist.get(PathNode.longHash(wx, wy, wz)) == 1)
                        continue;
                    if (legitMine && !isExposed(wx, wy, wz))
                        continue;
                    bestSq = dsq;
                    best = new BlockPos(wx, wy, wz);
                }
            }
        }
        return best;
    }

    private void checkShaftMineDirect() {
        if (!nullCheck())
            return;
        long now = System.currentTimeMillis();
        if (now - lastShaftMineMs < 1500L)
            return;
        int px = (int) Math.floor(mc.player.posX);
        int py = (int) Math.floor(mc.player.posY);
        int pz = (int) Math.floor(mc.player.posZ);
        BlockPos check = new BlockPos(0, 0, 0);
        for (int dy = 1; dy <= 2; dy++) {
            check.setPos(px, py + dy, pz);
            Block b = mc.world.getBlockState(check).getBlock();
            if (!matchesMineTarget(b))
                continue;
            if (shouldAvoidBreaking(px, py + dy, pz))
                continue;
            if (mineBlacklist.get(PathNode.longHash(px, py + dy, pz)) == 1)
                continue;
            lastShaftMineMs = now;
            mineTargetPos = new BlockPos(px, py + dy, pz);
            mining = true;
            miningFirstTick = true;
            mineToolSlot = -1;
            cancelPath();
            mc.player.setSprinting(false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
            ChatUtils.message("Mining " + mineTargetBlock + " directly above");
            return;
        }
    }

    private void onSegmentLost() {
        if (mc.player == null)
            return;
        if (mineContinuous && !mineTargetBlock.isEmpty() && mineTargetPos != null && !breakingObstruction) {
            long tHash = PathNode.longHash(mineTargetPos.getX(), mineTargetPos.getY(), mineTargetPos.getZ());
            if (mineTargetFailValid && mineTargetFailHash == tHash) {
                mineTargetFailCount++;
            } else {
                mineTargetFailHash = tHash;
                mineTargetFailValid = true;
                mineTargetFailCount = 1;
            }
            if (mineTargetFailCount >= MINE_TARGET_FAIL_BLACKLIST) {
                mineTargetFailCount = 0;
                mineTargetFailValid = false;
                mineBlacklist.put(tHash);
                ChatUtils.message("Mine target unreachable" + " — blacklisting, next...");
                segmentFailStreak = 0;
                segFailPosValid = false;
                consecutivePartials = 0;
                advanceToNextMineTarget();
                return;
            }
        }
        if (segFailPosValid) {
            double pdx = mc.player.posX - segFailX;
            double pdy = mc.player.posY - segFailY;
            double pdz = mc.player.posZ - segFailZ;
            double pdSq = pdx * pdx + pdy * pdy + pdz * pdz;
            segmentFailStreak = pdSq > 4.0 ? 1 : segmentFailStreak + 1;
        } else {
            segmentFailStreak = 1;
        }
        segFailX = mc.player.posX;
        segFailY = mc.player.posY;
        segFailZ = mc.player.posZ;
        segFailPosValid = true;
        if (segmentFailStreak >= SEGMENT_FAIL_GIVEUP) {
            segmentFailStreak = 0;
            segFailPosValid = false;
            pathFailed = true;
            pathFailCount = MAX_RETRIES;
            lastFailedGoal = currentGoal;
            lastFailedDesc = goalDescription;
            ChatUtils.error("Path keeps failing at the same spot" + " — giving up");
            ChatUtils.message("Use #retry to try again");
        } else {
            ChatUtils.message("Path lost — recalculating from" + " current position");
        }
    }

    private int classifyCrop(BlockPos pos) {
        if (mc.world == null)
            return -1;
        IBlockState state = mc.world.getBlockState(pos);
        Block b = state.getBlock();
        if (b instanceof BlockCrops)
            return FARM_CROP;
        if (b == Blocks.MELON_BLOCK || b == Blocks.PUMPKIN)
            return FARM_MELON;
        if (b == Blocks.REEDS || b == Blocks.CACTUS)
            return FARM_STEM;
        if (b == Blocks.NETHER_WART)
            return FARM_NETHER;
        if (b == Blocks.COCOA)
            return FARM_COCOA;
        return -1;
    }

    private boolean isCropMature(BlockPos pos) {
        if (mc.world == null)
            return false;
        IBlockState state = mc.world.getBlockState(pos);
        Block b = state.getBlock();
        if (b instanceof BlockCrops) {
            int maxAge = ((BlockCrops) b).getMaxAge();
            int age = ((Integer) state.getValue(BlockCrops.AGE)).intValue();
            return age >= maxAge;
        }
        if (b == Blocks.MELON_BLOCK || b == Blocks.PUMPKIN)
            return true;
        if (b == Blocks.REEDS) {
            return mc.world.getBlockState(pos.down()).getBlock() == Blocks.REEDS;
        }
        if (b == Blocks.CACTUS) {
            return mc.world.getBlockState(pos.down()).getBlock() == Blocks.CACTUS;
        }
        if (b == Blocks.NETHER_WART) {
            int age = ((Integer) state.getValue(BlockNetherWart.AGE)).intValue();
            return age >= 3;
        }
        if (b == Blocks.COCOA) {
            int age = ((Integer) state.getValue(BlockCocoa.AGE)).intValue();
            return age >= 2;
        }
        return false;
    }

    private void tickFarm() {
        if (mc.player == null || farmTargetPos == null) {
            if (farmScanActive)
                return;
            farming = false;
            return;
        }
        if (!isCropMature(farmTargetPos)) {
            advanceToNextCrop();
            return;
        }
        double dx = (farmTargetPos.getX() + 0.5) - mc.player.posX;
        double dy = (farmTargetPos.getY() + 0.5) - mc.player.posY;
        double dz = (farmTargetPos.getZ() + 0.5) - mc.player.posZ;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist > MINE_REACH) {
            farming = false;
            setGoal(new GoalAdjacent(farmTargetPos.getX(), farmTargetPos.getY(), farmTargetPos.getZ()), "Farm at " + farmTargetPos.getX() + ", " + farmTargetPos.getY() + ", " + farmTargetPos.getZ());
            return;
        }
        int cropType = classifyCrop(farmTargetPos);
        lookAtBlock(farmTargetPos, true);
        EnumFacing face = findBestMineFace(farmTargetPos);
        if (face == null)
            face = EnumFacing.UP;
        if (cropType == FARM_CROP) {
            InteractionUtils.placeBlock(farmTargetPos, face);
            mc.player.swingArm(EnumHand.MAIN_HAND);
            cropsHarvested++;
            farmReplantPos = farmTargetPos;
            farmReplantBlock = mc.world.getBlockState(farmTargetPos).getBlock();
            farmReplantTimer = 3;
        } else if (cropType == FARM_MELON) {
            mc.playerController.clickBlock(farmTargetPos, face);
            mc.player.swingArm(EnumHand.MAIN_HAND);
            cropsHarvested++;
            farmReplantPos = null;
            farmReplantBlock = null;
            farmReplantTimer = 0;
            farmTargetPos = null;
            advanceToNextCrop();
            return;
        } else if (cropType == FARM_STEM) {
            BlockPos breakPos = farmTargetPos;
            Block below = mc.world.getBlockState(farmTargetPos.down()).getBlock();
            if (below == Blocks.REEDS || below == Blocks.CACTUS) {
                mc.playerController.clickBlock(breakPos, face);
            } else {
                breakPos = farmTargetPos.up();
                mc.playerController.clickBlock(breakPos, face);
            }
            mc.player.swingArm(EnumHand.MAIN_HAND);
            cropsHarvested++;
            farmReplantPos = null;
            farmReplantBlock = null;
            farmReplantTimer = 0;
            farmTargetPos = null;
            advanceToNextCrop();
            return;
        } else if (cropType == FARM_NETHER) {
            mc.playerController.clickBlock(farmTargetPos, face);
            mc.player.swingArm(EnumHand.MAIN_HAND);
            cropsHarvested++;
            farmReplantPos = farmTargetPos;
            farmReplantBlock = Blocks.NETHER_WART;
            farmReplantTimer = 3;
        } else if (cropType == FARM_COCOA) {
            mc.playerController.clickBlock(farmTargetPos, face);
            mc.player.swingArm(EnumHand.MAIN_HAND);
            cropsHarvested++;
            farmReplantPos = farmTargetPos;
            farmReplantBlock = Blocks.COCOA;
            farmReplantTimer = 3;
        } else {
            advanceToNextCrop();
            return;
        }
        farmTargetPos = null;
    }

    private void tryReplant() {
        if (farmReplantPos == null) {
            advanceToNextCrop();
            return;
        }
        if (!autoReplant) {
            farmReplantPos = null;
            farmReplantBlock = null;
            advanceToNextCrop();
            return;
        }
        Block currentBlock = mc.world.getBlockState(farmReplantPos).getBlock();
        if (currentBlock != Blocks.AIR) {
            farmReplantPos = null;
            farmReplantBlock = null;
            advanceToNextCrop();
            return;
        }
        Block below = mc.world.getBlockState(farmReplantPos.down()).getBlock();
        int seedSlot = -1;
        if (farmReplantBlock == Blocks.NETHER_WART) {
            if (below != Blocks.SOUL_SAND) {
                farmReplantPos = null;
                farmReplantBlock = null;
                advanceToNextCrop();
                return;
            }
            seedSlot = findItemSlot("nether_wart");
        } else if (farmReplantBlock == Blocks.COCOA) {
            seedSlot = findCocoaBeanSlot();
        } else {
            if (below != Blocks.FARMLAND) {
                farmReplantPos = null;
                farmReplantBlock = null;
                advanceToNextCrop();
                return;
            }
            seedSlot = findSeedSlot();
        }
        if (seedSlot == -1) {
            farmReplantPos = null;
            farmReplantBlock = null;
            advanceToNextCrop();
            return;
        }
        mc.player.inventory.currentItem = seedSlot;
        double dx = (farmReplantPos.getX() + 0.5) - mc.player.posX;
        double dz = (farmReplantPos.getZ() + 0.5) - mc.player.posZ;
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        mc.player.rotationYaw = yaw;
        mc.player.rotationPitch = 0;
        mc.playerController.processRightClickBlock(mc.player, mc.world, farmReplantPos, EnumFacing.UP, new Vec3d(farmReplantPos.getX() + 0.5, farmReplantPos.getY() + 1.0, farmReplantPos.getZ() + 0.5), EnumHand.MAIN_HAND);
        mc.player.swingArm(EnumHand.MAIN_HAND);
        BlockAccess.invalidateAt(farmReplantPos.getX(), farmReplantPos.getY(), farmReplantPos.getZ());
        farmReplantPos = null;
        farmReplantBlock = null;
        advanceToNextCrop();
    }

    private int findSeedSlot() {
        if (mc.player == null)
            return -1;
        for (int i = 0; i < 9; i++) {
            net.minecraft.item.ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.func_190926_b())
                continue;
            String name = stack.getItem().getUnlocalizedName().toLowerCase();
            if (name.contains("seed") || name.contains("wheat") || name.equals("item.carrot") || name.equals("item.potato") || name.equals("item.beetroot") || name.contains("melon") || name.contains("pumpkin")) {
                return i;
            }
        }
        return -1;
    }

    private int findItemSlot(String contains) {
        if (mc.player == null)
            return -1;
        String lower = contains.toLowerCase();
        for (int i = 0; i < 9; i++) {
            net.minecraft.item.ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.func_190926_b())
                continue;
            String name = stack.getItem().getUnlocalizedName().toLowerCase();
            if (name.contains(lower)) {
                return i;
            }
        }
        return -1;
    }

    private int findCocoaBeanSlot() {
        if (mc.player == null)
            return -1;
        for (int i = 0; i < 9; i++) {
            net.minecraft.item.ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.func_190926_b())
                continue;
            String name = stack.getItem().getUnlocalizedName().toLowerCase();
            if (name.contains("dye") && stack.getMetadata() == 3) {
                return i;
            }
        }
        return -1;
    }

    private void startFarmScan(int radius, boolean fromCommand) {
        if (!nullCheck())
            return;
        farmScanFromCommand = fromCommand;
        farmScanRadius = radius;
        farmScanChunkRadius = (radius >> 4) + 1;
        farmScanBaseCX = (int) Math.floor(mc.player.posX) >> 4;
        farmScanBaseCZ = (int) Math.floor(mc.player.posZ) >> 4;
        int pcy = (int) Math.floor(mc.player.posY);
        farmScanYMin = Math.max(0, pcy - radius);
        farmScanYMax = Math.min(255, pcy + radius);
        farmScanCX = -farmScanChunkRadius;
        farmScanCZ = -farmScanChunkRadius;
        farmScanX = 0;
        farmScanZ = 0;
        farmScanBest = null;
        farmScanBestSq = Double.MAX_VALUE;
        farmScanActive = true;
    }

    private void tickFarmScan() {
        if (mc.player == null || mc.world == null) {
            farmScanActive = false;
            return;
        }
        long deadline = System.nanoTime() + FARM_SCAN_BUDGET_NS;
        while (farmScanActive && farming && System.nanoTime() < deadline) {
            scanOneFarmColumn();
        }
        if (farmScanActive && !farming) {
            farmScanActive = false;
            farmScanBest = null;
        }
    }

    private void scanOneFarmColumn() {
        int chunkX = farmScanBaseCX + farmScanCX;
        int chunkZ = farmScanBaseCZ + farmScanCZ;
        Chunk chunk = mc.world.getChunkFromChunkCoords(chunkX, chunkZ);
        if (chunk == null || !chunk.isLoaded()) {
            advanceFarmScanCursor();
            return;
        }
        int baseX = (chunkX << 4) + farmScanX;
        int baseZ = (chunkZ << 4) + farmScanZ;
        for (int y = farmScanYMin; y <= farmScanYMax; y++) {
            BlockPos pos = new BlockPos(baseX, y, baseZ);
            IBlockState bs = chunk.getBlockState(pos);
            Block b = bs.getBlock();
            boolean mature = false;
            if (b instanceof BlockCrops) {
                int maxAge = ((BlockCrops) b).getMaxAge();
                int age = ((Integer) bs.getValue(BlockCrops.AGE)).intValue();
                mature = age >= maxAge;
            } else if (b == Blocks.MELON_BLOCK || b == Blocks.PUMPKIN) {
                mature = true;
            } else if (b == Blocks.REEDS) {
                Block below = chunk.getBlockState(pos.down()).getBlock();
                mature = (below == Blocks.REEDS);
            } else if (b == Blocks.CACTUS) {
                Block below = chunk.getBlockState(pos.down()).getBlock();
                mature = (below == Blocks.CACTUS);
            } else if (b == Blocks.NETHER_WART) {
                int age = ((Integer) bs.getValue(BlockNetherWart.AGE)).intValue();
                mature = (age >= 3);
            } else if (b == Blocks.COCOA) {
                int age = ((Integer) bs.getValue(BlockCocoa.AGE)).intValue();
                mature = (age >= 2);
            }
            if (!mature)
                continue;
            double ddx = pos.getX() - mc.player.posX;
            double ddy = pos.getY() - mc.player.posY;
            double ddz = pos.getZ() - mc.player.posZ;
            double d = ddx * ddx + ddy * ddy + ddz * ddz;
            if (d < farmScanBestSq) {
                farmScanBestSq = d;
                farmScanBest = new int[] { pos.getX(), pos.getY(), pos.getZ() };
            }
        }
        advanceFarmScanCursor();
    }

    private void advanceFarmScanCursor() {
        farmScanZ++;
        if (farmScanZ > 15) {
            farmScanZ = 0;
            farmScanX++;
            if (farmScanX > 15) {
                farmScanX = 0;
                farmScanCZ++;
                if (farmScanCZ > farmScanChunkRadius) {
                    farmScanCZ = -farmScanChunkRadius;
                    farmScanCX++;
                    if (farmScanCX > farmScanChunkRadius) {
                        finishFarmScan();
                    }
                }
            }
        }
    }

    private void finishFarmScan() {
        farmScanActive = false;
        int[] best = farmScanBest;
        farmScanBest = null;
        if (mc.player == null)
            return;
        if (!farming)
            return;
        if (best != null) {
            farmTargetPos = new BlockPos(best[0], best[1], best[2]);
            pathCompleted = false;
            pathFailed = false;
            pathFailCount = 0;
            farming = true;
            if (farmScanFromCommand) {
                setGoal(new GoalAdjacent(best[0], best[1], best[2]), "Farm at " + best[0] + ", " + best[1] + ", " + best[2]);
                ChatUtils.success("Found crop at " + best[0] + ", " + best[1] + ", " + best[2]);
            } else {
                setGoal(new GoalAdjacent(best[0], best[1], best[2]), "Farm (" + cropsHarvested + " harvested)");
            }
        } else {
            if (farmScanFromCommand) {
                ChatUtils.error("No mature crops within " + farmScanRadius + " blocks");
            } else {
                ChatUtils.success("Farming complete! Harvested " + cropsHarvested + " crop(s)");
            }
            farming = false;
            farmTargetPos = null;
            currentGoal = null;
            goalDescription = "";
        }
    }

    private void advanceToNextCrop() {
        if (!farmScanActive) {
            startFarmScan(farmRadius, false);
        }
    }

    private void requestPath() {
        if (mc.player == null || currentGoal == null)
            return;
        if (pathFailCount >= MAX_RETRIES) {
            pathFailed = true;
            lastFailedGoal = currentGoal;
            lastFailedDesc = goalDescription;
            ChatUtils.error("Giving up after " + MAX_RETRIES + " failed paths (goal may be unreachable)");
            ChatUtils.message("Use #retry to try again");
            pathFailCount = 0;
            pathRequested = false;
            finder = null;
            return;
        }
        int startX = (int) Math.floor(mc.player.posX);
        int startY = (int) Math.floor(mc.player.posY);
        int startZ = (int) Math.floor(mc.player.posZ);
        if (BlockAccess.canWalkOn(startX, startY, startZ) && !BlockAccess.canWalkThrough(startX, startY, startZ) && !BlockAccess.isClimbable(startX, startY, startZ) && !BlockAccess.isWater(startX, startY, startZ)) {
            ChatUtils.error("Inside solid block, can't pathfind");
            pathFailed = true;
            return;
        }
        preCacheDone = BlockAccess.preCache(startX, startY, startZ, PRECACHE_RADIUS);
        Path prevPath = executor.getPath();
        if (prevPath != null) {
            for (int i = 0; i < prevPath.length(); i++) {
                globalVisitedPositions.put(PathNode.longHash(prevPath.posX[i], prevPath.posY[i], prevPath.posZ[i]));
            }
        }
        if (globalVisitedPositions.size() > 4000) {
            globalVisitedPositions.clear();
            if (prevPath != null) {
                int start = Math.max(0, prevPath.length() - 3000);
                for (int i = start; i < prevPath.length(); i++) {
                    globalVisitedPositions.put(PathNode.longHash(prevPath.posX[i], prevPath.posY[i], prevPath.posZ[i]));
                }
            }
        }
        AStarPathFinder.cfgAllowBreak = allowBreak;
        AStarPathFinder.cfgAllowPlace = allowPlace;
        AStarPathFinder.cfgAllowParkour = allowParkour;
        AStarPathFinder.cfgAllowDiagonalAscend = allowDiagonalAscend;
        AStarPathFinder.cfgAllowDiagonalDescend = allowDiagonalDescend;
        AStarPathFinder.cfgAllowDownward = allowDownward;
        AStarPathFinder.cfgBlockPlacementPenalty = blockPlacementPenalty;
        AStarPathFinder.cfgAvoidBreakingMultiplier = avoidBreakingMultiplier;
        AStarPathFinder.cfgCostHeuristic = costHeuristic;
        AStarPathFinder.cfgPathCutoffFactor = pathCutoffFactor;
        AStarPathFinder.cfgAllowInventory = allowInventory;
        AStarPathFinder.cfgAllowParkourPlace = allowParkourPlace;
        AStarPathFinder.cfgSprintAscends = sprintAscends;
        AStarPathFinder.cfgBlockBreakAdditionalPenalty = blockBreakAdditionalPenalty;
        AStarPathFinder.cfgJumpPenalty = jumpPenalty;
        AStarPathFinder.cfgMovementTimeoutTicks = movementTimeoutTicks;
        AStarPathFinder.cfgPathCutoffMinimumLength = pathCutoffMinimumLength;
        AStarPathFinder.cfgRightClickSpeed = rightClickSpeed;
        AStarPathFinder.cfgAllowSprint = allowSprint;
        AStarPathFinder.cfgAllowParkourAscend = allowParkourAscend;
        AStarPathFinder.cfgAllowOvershootDiagonalDescend = allowOvershootDiagonalDescend;
        AStarPathFinder.cfgAllowPlaceInFluidsFlow = allowPlaceInFluidsFlow;
        AStarPathFinder.cfgAllowPlaceInFluidsSource = allowPlaceInFluidsSource;
        AStarPathFinder.cfgAllowWalkOnBottomSlab = allowWalkOnBottomSlab;
        AStarPathFinder.cfgAvoidUpdatingFallingBlocks = avoidUpdatingFallingBlocks;
        AStarPathFinder.cfgCancelOnGoalInvalidation = cancelOnGoalInvalidation;
        AStarPathFinder.cfgConsiderPotionEffects = considerPotionEffects;
        AStarPathFinder.cfgCostVerificationLookahead = costVerificationLookahead;
        AStarPathFinder.cfgBacktrackCostFavoringCoefficient = backtrackCostFavoringCoefficient;
        AStarPathFinder.cfgAllowVines = allowVines;
        PathExecutor.cfgAssumeStep = assumeStep;
        PathExecutor.cfgAssumeSafeWalk = assumeSafeWalk;
        PathExecutor.cfgCloseDoorOnArrival = closeDoorOnArrival;
        finder = new AStarPathFinder(startX, startY, startZ, currentGoal, prevPath, globalVisitedPositions);
        finder.init();
        pathRequested = true;
        pathTimeoutEnd = System.currentTimeMillis() + (long) (pathTimeout * 1000);
        if (consecutivePartials == 0) {
            lastPartialX = mc.player.posX;
            lastPartialZ = mc.player.posZ;
        }
    }

    private void cancelPath() {
        if (executor.hasPath() && !executor.safeToCancel()) {
            cancelPending = true;
            return;
        }
        executor.clearPath();
        pathRequested = false;
        pathFailed = false;
        pathFailCount = 0;
        pathCompleted = false;
        consecutivePartials = 0;
        segmentFailStreak = 0;
        segFailPosValid = false;
        if (finder != null) {
            finder.cancel();
            finder = null;
        }
        cancelPending = false;
    }

    private void tickAutoEat() {
        if (mc.player == null)
            return;
        int foodLevel = mc.player.getFoodStats().getFoodLevel();
        float saturation = mc.player.getFoodStats().getSaturationLevel();
        if (foodLevel >= 20 && saturation >= 2.0f)
            return;
        if (foodLevel >= autoEatThreshold)
            return;
        int tick = (int) (System.nanoTime() / 50_000_000L);
        if (tick - autoEatLastTick < 30)
            return;
        if (mining)
            return;
        int bestSlot = -1;
        float bestSat = -1;
        int bestHeal = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (stack.func_190926_b())
                continue;
            if (!(stack.getItem() instanceof ItemFood))
                continue;
            ItemFood food = (ItemFood) stack.getItem();
            int heal = food.getHealAmount(stack);
            float sat = food.getSaturationModifier(stack);
            if (sat > bestSat || (sat == bestSat && heal > bestHeal)) {
                bestSat = sat;
                bestHeal = heal;
                bestSlot = i;
            }
        }
        if (bestSlot == -1)
            return;
        int prevSlot = mc.player.inventory.currentItem;
        mc.player.inventory.currentItem = bestSlot;
        mc.playerController.processRightClick(mc.player, mc.world, EnumHand.MAIN_HAND);
        mc.player.inventory.currentItem = prevSlot;
        autoEatLastTick = tick;
    }

    private boolean tryWaterBucketFall() {
        if (!allowWaterBucketFall)
            return false;
        if (mc.player == null)
            return false;
        if (mc.player.onGround)
            return false;
        if (mc.player.motionY > -0.8)
            return false;
        int bucketSlot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (stack.func_190926_b())
                continue;
            if (stack.getItem() == net.minecraft.init.Items.WATER_BUCKET) {
                bucketSlot = i;
                break;
            }
        }
        if (bucketSlot == -1)
            return false;
        int prevSlot = mc.player.inventory.currentItem;
        mc.player.inventory.currentItem = bucketSlot;
        BlockPos feetPos = new BlockPos((int) Math.floor(mc.player.posX), (int) Math.floor(mc.player.posY) - 1, (int) Math.floor(mc.player.posZ));
        mc.playerController.processRightClickBlock(mc.player, mc.world, feetPos, EnumFacing.UP, new Vec3d(mc.player.posX, feetPos.getY() + 1, mc.player.posZ), EnumHand.MAIN_HAND);
        mc.player.inventory.currentItem = prevSlot;
        return true;
    }

    private void updateMobAvoidance() {
        if (!nullCheck())
            return;
        java.util.List<int[]> mobZones = new java.util.ArrayList<>();
        final int MOB_AVOID_RADIUS_SQ = 64;
        for (net.minecraft.entity.Entity entity : mc.world.loadedEntityList) {
            if (!(entity instanceof net.minecraft.entity.monster.EntityMob))
                continue;
            if (entity.isDead)
                continue;
            double dx = entity.posX - mc.player.posX;
            double dz = entity.posZ - mc.player.posZ;
            if (dx * dx + dz * dz > 1024)
                continue;
            boolean dangerous = true;
            if (entity instanceof net.minecraft.entity.monster.EntitySpider) {
                float brightness = mc.player.getBrightness();
                if (brightness >= 0.5f)
                    dangerous = false;
            } else if (entity instanceof net.minecraft.entity.monster.EntityPigZombie) {
                net.minecraft.entity.monster.EntityPigZombie pigZ = (net.minecraft.entity.monster.EntityPigZombie) entity;
                if (!pigZ.isAngry())
                    dangerous = false;
            } else if (entity instanceof net.minecraft.entity.monster.EntityEnderman) {
                net.minecraft.entity.monster.EntityEnderman ender = (net.minecraft.entity.monster.EntityEnderman) entity;
                if (!ender.isScreaming())
                    dangerous = false;
            }
            if (!dangerous)
                continue;
            int ex = (int) Math.floor(entity.posX);
            int ey = (int) Math.floor(entity.posY);
            int ez = (int) Math.floor(entity.posZ);
            mobZones.add(new int[] { ex, ey, ez, MOB_AVOID_RADIUS_SQ, ey });
        }
        if (!mobZones.isEmpty()) {
            java.util.List<int[]> combined = new java.util.ArrayList<>(avoidZones);
            combined.addAll(mobZones);
            BlockAccess.setAvoidZones(combined);
        } else {
            if (!avoidZones.isEmpty()) {
                BlockAccess.setAvoidZones(avoidZones);
            } else {
                BlockAccess.clearAvoidZones();
            }
        }
    }

    private void updateFollowGoal() {
        if (followTarget.equals("players") || followTarget.equals("entities") || followTarget.startsWith("entity:")) {
            net.minecraft.entity.Entity closest = null;
            double closestDistSq = Double.MAX_VALUE;
            String filterType = followTarget.startsWith("entity:") ? followTarget.substring(7) : null;
            for (net.minecraft.entity.Entity entity : mc.world.loadedEntityList) {
                if (entity == mc.player)
                    continue;
                boolean match = false;
                if (followTarget.equals("players")) {
                    match = entity instanceof EntityOtherPlayerMP;
                } else if (followTarget.equals("entities")) {
                    match = !(entity instanceof net.minecraft.entity.item.EntityItem) && !(entity instanceof net.minecraft.entity.projectile.EntityArrow);
                } else if (filterType != null) {
                    String cls = entity.getClass().getSimpleName().toLowerCase().replace("entity", "");
                    match = cls.contains(filterType);
                }
                if (!match)
                    continue;
                double dSq = mc.player.getDistanceSqToEntity(entity);
                if (dSq < closestDistSq) {
                    closestDistSq = dSq;
                    closest = entity;
                }
            }
            if (closest != null) {
                int tx = (int) Math.floor(closest.posX);
                int tz = (int) Math.floor(closest.posZ);
                int ddx = tx - lastFollowX;
                int ddz = tz - lastFollowZ;
                if (Math.abs(ddx) < FOLLOW_RECALC_DIST && Math.abs(ddz) < FOLLOW_RECALC_DIST && executor.hasPath()) {
                    return;
                }
                if (executor.hasPath()) {
                    executor.clearPath();
                }
                lastFollowX = tx;
                lastFollowZ = tz;
                currentGoal = new GoalNearXZ(tx, tz, followDist);
                pathCompleted = false;
                if (isToggled()) {
                    requestPath();
                }
                return;
            }
            ChatUtils.message("No matching entity found for " + followTarget);
            return;
        }
        for (net.minecraft.entity.Entity entity : mc.world.loadedEntityList) {
            if (entity instanceof EntityOtherPlayerMP && entity.getName().equalsIgnoreCase(followTarget)) {
                EntityOtherPlayerMP target = (EntityOtherPlayerMP) entity;
                int tx = (int) Math.floor(target.posX);
                int tz = (int) Math.floor(target.posZ);
                int ddx = tx - lastFollowX;
                int ddz = tz - lastFollowZ;
                if (Math.abs(ddx) < FOLLOW_RECALC_DIST && Math.abs(ddz) < FOLLOW_RECALC_DIST && executor.hasPath()) {
                    return;
                }
                if (executor.hasPath()) {
                    executor.clearPath();
                }
                lastFollowX = tx;
                lastFollowZ = tz;
                currentGoal = new GoalNearXZ(tx, tz, followDist);
                pathCompleted = false;
                if (executor.hasPath()) {
                    cancelPath();
                }
                if (isToggled()) {
                    requestPath();
                }
                return;
            }
        }
        if (!followTarget.isEmpty()) {
            ChatUtils.message("Lost sight of " + followTarget);
            followTarget = "";
            currentGoal = null;
            cancelPath();
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.gameSettings != null) {
            savedAutoJump = mc.gameSettings.autoJump;
            mc.gameSettings.autoJump = false;
        }
        pathRequested = false;
        pathFailed = false;
        pathFailCount = 0;
        finder = null;
        executor.clearPath();
        pathCompleted = false;
        if (currentGoal != null) {
            requestPath();
        }
    }

    @Override
    public void onDeath() {
        if (mc.player != null) {
            deathPos = new int[] { (int) Math.floor(mc.player.posX), (int) Math.floor(mc.player.posY), (int) Math.floor(mc.player.posZ) };
            died = true;
            cancelPath();
            currentGoal = null;
            goalDescription = "";
            followTarget = "";
            mineTargetBlock = "";
            stopMining();
            farming = false;
            farmTargetPos = null;
            lastFailedGoal = null;
            lastFailedDesc = "";
            retryCount = 0;
            pathStartTime = 0;
            stopExplore();
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        cancelPath();
        stopMining();
        blocksMined = 0;
        lastCountedMineValid = false;
        stopBuild();
        mineScanActive = false;
        farmScanActive = false;
        farmScanBest = null;
        mineScanApplyOnDone = false;
        mineScanResults.clear();
        mineScanDists.clear();
        mineCandidates.clear();
        lastMineScanCompleteMs = 0;
        dropPickupActive = false;
        anticipatedDrops.clear();
        dropPickupAttempts = 0;
        dropPickupCooldownUntilMs = 0;
        mineExploreActive = false;
        mineDesiredQuantity = 0;
        releaseMovementKeys();
        if (mc.gameSettings != null) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
        }
        BlockAccess.clearCache();
        if (mc.gameSettings != null) {
            mc.gameSettings.autoJump = savedAutoJump;
        }
        client.Client.INSTANCE.renderRotationOverride = false;
        client.Client.INSTANCE.physicsConsistentAim = false;
        if (SilentAimUtil.isActive() && SilentAimUtil.isOwnedBy("Baritone")) {
            SilentAimUtil.endStreak();
            SilentAimUtil.onDisable("Baritone");
        }
        silentAimOwned = false;
    }

    public boolean isAcceptableThrowawayItem(Block block) {
        return acceptableThrowawayItems.contains(block);
    }

    public boolean isBlockToAvoidBreaking(Block block) {
        return blocksToAvoidBreakingList.contains(block);
    }

    public boolean getAllowSprint() {
        return allowSprint;
    }

    public boolean getSmoothLook() {
        return smoothLook;
    }

    public boolean getFreeLook() {
        return freeLook;
    }

    public boolean getCancelOnGoalInvalidation() {
        return cancelOnGoalInvalidation;
    }

    public boolean getMineScanDroppedItems() {
        return mineScanDroppedItems;
    }

    public boolean getBackfill() {
        return backfill;
    }
}
