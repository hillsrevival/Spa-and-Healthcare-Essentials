package client.module.impl.other;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.server.SPacketTabComplete;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextFormatting;
import client.event.listeners.ChatInputListener;
import client.event.events.PacketInputEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.ChatUtils;
import client.utils.world.PacketUtils;

public class PluginFinder extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private int stage = 0;

    private int waitTicks = 0;

    private static final int METHOD_TIMEOUT = 60;

    private boolean waitingForTab = false;

    private static final Set<String> VANILLA_COMMANDS = new HashSet<>(Arrays.asList("advancement", "attribute", "ban", "ban-ip", "banlist", "blockdata", "clear", "clone", "debug", "defaultgamemode", "deop", "difficulty", "effect", "enchant", "entitydata", "execute", "fill", "gamemode", "gamerule", "give", "help", "kick", "kill", "list", "me", "msg", "op", "pardon", "pardon-ip", "particle", "playsound", "publish", "recipe", "reload", "replaceitem", "save-all", "save-off", "save-on", "say", "scoreboard", "seed", "setblock", "setidletimeout", "setworldspawn", "spawnpoint", "spreadplayers", "stats", "stop", "summon", "tell", "tellraw", "testfor", "testforblock", "testforblocks", "time", "title", "tp", "trigger", "unban", "unban-ip", "weather", "whitelist", "worldborder", "xp", "team", "achievement", "broadcast", "togglefalling", "home", "spawn", "warp", "plugins", "bukkit:plugins", "pl", "about", "ver", "version", "?", "bukkit:help", "bukkit:ver", "bukkit:version", "bukkit:about", "bukkit:pl"));

    public PluginFinder() {
        super("PluginFinder", Category.OTHER);
        setDescription("Find what plugins a server is using");
        handles(HandlerType.CHAT_INPUT, HandlerType.PACKET_INPUT, HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null || mc.player.connection == null) {
            toggle();
            return;
        }
        stage = 0;
        waitTicks = 0;
        waitingForTab = false;
        ChatUtils.message(TextFormatting.GRAY + "Trying " + TextFormatting.WHITE + "/plugins" + TextFormatting.GRAY + "...");
        mc.player.sendChatMessage("/plugins");
    }

    @Override
    public void onChatInput(ChatInputListener.ChatInputEvent event) {
        if (stage == 2)
            return;
        ITextComponent comp = event.getComponent();
        if (comp == null)
            return;
        String text = comp.getUnformattedText();
        if (text.contains("Plugins (") || text.contains("plugins (")) {
            event.setCancelled(true);
            int parenOpen = text.indexOf('(');
            int parenClose = text.indexOf(')', parenOpen);
            int colonIdx = text.indexOf(':', parenClose);
            if (colonIdx > 0) {
                String pluginList = text.substring(colonIdx + 1).trim();
                String[] parts = pluginList.split("[,\\u00a7]+");
                List<String> plugins = new ArrayList<>();
                for (String part : parts) {
                    String cleaned = part.trim().replaceAll("(?i)^and\\s+", "").replaceAll("[^a-zA-Z0-9_\\-]", "");
                    if (cleaned.length() > 0) {
                        plugins.add(cleaned);
                    }
                }
                if (plugins.isEmpty()) {
                    ChatUtils.message(TextFormatting.YELLOW + "Server returned a plugin list but it was empty.");
                } else {
                    displayResults(plugins);
                }
            } else {
                ChatUtils.message(TextFormatting.YELLOW + "Could not parse plugin list from server response.");
            }
            toggle();
        }
    }

    @Override
    public void onPacketInput(PacketInputEvent event) {
        if (!waitingForTab)
            return;
        if (!(event.getPacket() instanceof SPacketTabComplete))
            return;
        SPacketTabComplete packet = (SPacketTabComplete) event.getPacket();
        String[] matches = packet.getMatches();
        waitingForTab = false;
        if (matches == null || matches.length == 0) {
            ChatUtils.message(TextFormatting.RED + "No plugins detected.");
            toggle();
            return;
        }
        Set<String> plugins = new HashSet<>();
        for (String match : matches) {
            String cmd = match.startsWith("/") ? match.substring(1) : match;
            int colon = cmd.indexOf(':');
            if (colon > 0) {
                String prefix = cmd.substring(0, colon).toLowerCase();
                plugins.add(prefix);
            } else {
                String base = cmd.toLowerCase();
                int space = base.indexOf(' ');
                if (space > 0)
                    base = base.substring(0, space);
                if (!VANILLA_COMMANDS.contains(base)) {
                    plugins.add(base);
                }
            }
        }
        if (plugins.isEmpty()) {
            ChatUtils.message(TextFormatting.RED + "No plugin commands found.");
            toggle();
            return;
        }
        displayResults(new ArrayList<>(plugins));
        toggle();
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (waitingForTab) {
            waitTicks++;
            if (waitTicks > METHOD_TIMEOUT * 2) {
                waitingForTab = false;
                ChatUtils.message(TextFormatting.RED + "PluginFinder timed out.");
                toggle();
            }
            return;
        }
        if (stage >= 2)
            return;
        waitTicks++;
        if (waitTicks <= METHOD_TIMEOUT)
            return;
        waitTicks = 0;
        stage++;
        if (stage == 1) {
            ChatUtils.message(TextFormatting.GRAY + "Trying " + TextFormatting.WHITE + "/bukkit:plugins" + TextFormatting.GRAY + "...");
            mc.player.sendChatMessage("/bukkit:plugins");
        } else if (stage == 2) {
            ChatUtils.message(TextFormatting.GRAY + "Trying " + TextFormatting.WHITE + "tab-complete" + TextFormatting.GRAY + "...");
            waitingForTab = true;
            waitTicks = 0;
            PacketUtils.sendTabComplete("/", null, false);
        } else {
            ChatUtils.message(TextFormatting.RED + "Could not detect plugins — all methods failed.");
            toggle();
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        stage = 0;
        waitTicks = 0;
        waitingForTab = false;
    }

    private void displayResults(List<String> plugins) {
        java.util.Collections.sort(plugins, String.CASE_INSENSITIVE_ORDER);
        ChatUtils.message(TextFormatting.GREEN + "" + TextFormatting.BOLD + "Plugins detected (" + plugins.size() + "):");
        ChatUtils.message(TextFormatting.GRAY + "-------------------");
        StringBuilder line = new StringBuilder();
        for (int i = 0; i < plugins.size(); i++) {
            if (line.length() > 0)
                line.append(TextFormatting.GRAY).append(", ");
            line.append(TextFormatting.AQUA).append(plugins.get(i));
            if ((i + 1) % 6 == 0 || i == plugins.size() - 1) {
                ChatUtils.message(line.toString());
                line = new StringBuilder();
            }
        }
        ChatUtils.message(TextFormatting.GRAY + "-------------------");
        String method;
        if (stage == 0)
            method = "/plugins";
        else if (stage == 1)
            method = "/bukkit:plugins";
        else
            method = "tab-complete";
        ChatUtils.message(TextFormatting.DARK_GRAY + "Method: " + method);
    }
}
