package client.module.impl.other;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.tuff.ViaBlocksHandler;
import net.minecraft.client.Minecraft;

public class ViaBlocks extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public ViaBlocks() {
        super("ViaBlocks", Category.OTHER);
        setDescription("Show modern version blocks (requires TuffX+ server)");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        ViaBlocksHandler.reset();
        ViaBlocksHandler.sendHandshake();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        ViaBlocksHandler.reset();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) {
            ViaBlocksHandler.reset();
            return;
        }
        if (!ViaBlocksHandler.isActive()) {
            ViaBlocksHandler.sendHandshake();
        }
    }
}
