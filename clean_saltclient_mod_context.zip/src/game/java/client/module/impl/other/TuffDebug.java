package client.module.impl.other;

import client.module.Category;
import client.module.Module;
import client.tuff.TuffDebugLog;
import client.tuff.Y0NetworkHandler;
import client.tuff.ViaBlocksHandler;
import io.netty.buffer.Unpooled;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketCustomPayload;

public class TuffDebug extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public TuffDebug() {
        super("TuffDebug", Category.OTHER);
        setDescription("Debug Y0/ViaBlocks:");
    }

    @Override
    public void onEnable() {
        super.onEnable();
        TuffDebugLog.startSession();
        if (mc.player == null || mc.player.connection == null) {
            TuffDebugLog.log("[DEBUG] No player/connection — cannot re-send");
            return;
        }
        try {
            byte[] tuffChannels = "viablocks:data\u0000viablocks:handshake\u0000eagler:below_y0\u0000viaentities:data\u0000entities:handshake\u0000eagler:tuffactions".getBytes();
            PacketBuffer regBuf = new PacketBuffer(Unpooled.buffer());
            regBuf.writeBytes(tuffChannels);
            mc.player.connection.sendPacket(new CPacketCustomPayload("REGISTER", regBuf));
            TuffDebugLog.log("[DEBUG] Re-sent MC|Register");
        } catch (Exception e) {
            TuffDebugLog.log("[DEBUG] MC|Register FAILED: " + e.getMessage());
        }
        TuffDebugLog.log("[DEBUG] Forcing Y0 handshake resend (wasSent=" + Y0NetworkHandler.wasHandshakeSent() + ")");
        Y0NetworkHandler.forceResendHandshake();
        TuffDebugLog.log("[DEBUG] Forcing VB handshake resend (wasSent=" + ViaBlocksHandler.wasHandshakeSent() + ")");
        ViaBlocksHandler.forceResendHandshake();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        TuffDebugLog.stopSession();
        String report = TuffDebugLog.getReport();
        GuiScreen.setClipboardString(report);
        TuffDebugLog.reset();
    }
}
