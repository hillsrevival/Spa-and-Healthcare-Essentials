package client.module.impl.other;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.event.listeners.KeyPressListener;
import client.event.listeners.RenderListener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import client.gui.GuiSchematicManager;
import net.minecraft.schematic.SchematicRenderer;

public class SchematicModule extends Module {

    public SchematicModule() {
        super("Schematic Manager", Category.OTHER);
        setDescription("Schematics, Litematica port");
        handles(HandlerType.KEY_PRESS, HandlerType.RENDER);
    }

    @Override
    public void onKeyPress(KeyPressListener.KeyPressEvent event) {
        if (event.getKeyCode() == this.getKey() && this.getKey() != -1) {
            openSchematicMenu();
        }
    }

    private void openSchematicMenu() {
        Minecraft mc = Minecraft.getMinecraft();
        GuiScreen currentScreen = mc.currentScreen;
        mc.displayGuiScreen(new GuiSchematicManager(currentScreen));
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        SchematicRenderer.renderWorldOverlay(event.getPartialTicks());
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }
}
