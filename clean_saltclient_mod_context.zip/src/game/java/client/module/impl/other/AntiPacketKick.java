package client.module.impl.other;

import client.event.events.PacketOutputEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.network.play.client.CPacketKeepAlive;
import net.minecraft.network.play.client.CPacketTabComplete;
import net.minecraft.network.play.client.CPacketCustomPayload;

public class AntiPacketKick extends Module {

    private long lastKeepAliveKey = Long.MIN_VALUE;

    private long lastTabComplete = 0;

    private long lastCustomPayload = 0;

    private static final long MIN_TABCOMPLETE_INTERVAL = 500;

    private static final long MIN_PAYLOAD_INTERVAL = 200;

    public AntiPacketKick() {
        super("AntiPacketKick", Category.OTHER);
        setDescription("Prevents getting kicked for too many packets");
        handles(HandlerType.PACKET_OUTPUT);
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        if (mc.player == null)
            return;
        long now = System.currentTimeMillis();
        if (event.getPacket() instanceof CPacketKeepAlive) {
            long key = ((CPacketKeepAlive) event.getPacket()).getKey();
            if (key == lastKeepAliveKey) {
                event.setCancelled(true);
            } else {
                lastKeepAliveKey = key;
            }
            return;
        }
        if (event.getPacket() instanceof CPacketTabComplete) {
            if (now - lastTabComplete < MIN_TABCOMPLETE_INTERVAL) {
                event.setCancelled(true);
                return;
            }
            lastTabComplete = now;
        }
        if (event.getPacket() instanceof CPacketCustomPayload) {
            if (now - lastCustomPayload < MIN_PAYLOAD_INTERVAL) {
                event.setCancelled(true);
                return;
            }
            lastCustomPayload = now;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        lastKeepAliveKey = Long.MIN_VALUE;
    }
}
