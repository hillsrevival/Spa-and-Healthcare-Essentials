package client.module.impl.other;

import client.module.Category;
import client.module.Module;
import client.module.ModuleManager;

public class Panic extends Module {

    public Panic() {
        super("Panic", Category.OTHER);
        setDescription("Instantly disables all active modules");
    }

    @Override
    public void onEnable() {
        super.onEnable();
        Module.setSuppressToggleNotifications(true);
        for (Module mod : ModuleManager.getModules()) {
            if (mod.isToggled() && mod != this) {
                mod.setToggled(false);
            }
        }
        setToggled(false);
        Module.setSuppressToggleNotifications(false);
        client.utils.misc.NotificationSystem.warning("All modules disabled (Panic)");
    }
}
