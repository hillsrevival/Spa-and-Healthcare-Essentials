package client.module.impl.other;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Items;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.server.SPacketSoundEffect;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import client.event.events.PacketInputEvent;
import client.utils.player.FindItemResult;
import client.utils.player.InvUtils;
import client.utils.player.SlotUtils;
import client.utils.world.InventoryClickQueue;
import java.util.Random;

public class AutoFish extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Random rand = new Random();

    private final BooleanSetting overfill = new BooleanSetting("Overfill", false);

    private final NumberSetting recastDelay = new NumberSetting("Recast Delay", 15.0, 5.0, 40.0);

    private final NumberSetting reactionDelay = new NumberSetting("Reaction", 3.0, 0.0, 15.0);

    private int timer;

    private int reactionTimer = -1;

    public AutoFish() {
        super("AutoFish", Category.OTHER);
        setDescription("Automatically catches fish when a bobber is in the water");
        addSetting(overfill);
        addSetting(recastDelay);
        addSetting(reactionDelay);
        handles(HandlerType.UPDATE, HandlerType.PACKET_INPUT);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        InventoryClickQueue.tick();
        if (reactionTimer > 0) {
            reactionTimer--;
            if (reactionTimer == 0) {
                doRightClick();
            }
            return;
        }
        if (!overfill.getValue() && mc.player.inventory.getFirstEmptyStack() == -1) {
            toggle();
            return;
        }
        FindItemResult rodHotbar = InvUtils.findInHotbar(Items.FISHING_ROD);
        int rodSlot = rodHotbar.found() ? rodHotbar.slot() - SlotUtils.HOTBAR_START : -1;
        if (rodSlot != -1) {
            if (mc.player.inventory.currentItem != rodSlot) {
                mc.player.inventory.currentItem = rodSlot;
                return;
            }
            if (timer > 0) {
                timer--;
                return;
            }
            if (mc.player.fishEntity != null)
                return;
            doRightClick();
            return;
        }
        if (InventoryClickQueue.hasPending())
            return;
        FindItemResult rodInv = InvUtils.find(stack -> stack != null && !stack.func_190926_b() && stack.getItem() instanceof ItemFishingRod);
        int rodInInv = rodInv.found() && rodInv.isMain() ? rodInv.slot() : -1;
        if (rodInInv == -1) {
            toggle();
            return;
        }
        FindItemResult emptyHotbar = InvUtils.findInHotbar(stack -> stack.func_190926_b());
        int hotbarSlot = emptyHotbar.found() ? emptyHotbar.slot() : SlotUtils.HOTBAR_START + mc.player.inventory.currentItem;
        InventoryClickQueue.swap(rodInInv, hotbarSlot);
    }

    @Override
    public void onPacketInput(PacketInputEvent event) {
        if (!nullCheck())
            return;
        if (!(event.getPacket() instanceof SPacketSoundEffect))
            return;
        SPacketSoundEffect sound = (SPacketSoundEffect) event.getPacket();
        if (sound.getSound() != null && sound.getSound().getSoundName().getResourcePath().equals("entity.bobber.splash")) {
            int delay = reactionDelay.getValue().intValue() + (rand.nextInt(3) - 1);
            if (delay <= 0) {
                doRightClick();
            } else {
                reactionTimer = delay;
            }
        }
    }

    private void doRightClick() {
        ItemStack stack = mc.player.getHeldItemMainhand();
        if (stack == null || !(stack.getItem() instanceof ItemFishingRod))
            return;
        mc.rightClickMouse();
        int base = recastDelay.getValue().intValue();
        timer = base + (rand.nextInt(5) - 2);
        if (timer < 3)
            timer = 3;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        timer = 0;
        reactionTimer = -1;
    }
}
