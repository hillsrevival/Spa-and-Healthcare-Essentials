package client.module.impl.other;

import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.utils.misc.ChatUtils;

public class AutoGG extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting message = new ModeSetting("Message", "gg", "gg", "GG", "gg ez", "gf", "Good Game!", "gg no re", "GG WP");

    private boolean shouldSend = false;

    private int delayTicks = 0;

    public AutoGG() {
        super("AutoGG", Category.OTHER);
        setDescription("Automatically sends gg in chat when a game ends");
        addSetting(message);
        handles(HandlerType.DEATH, HandlerType.UPDATE);
    }

    @Override
    public void onDeath() {
        if (mc.player == null)
            return;
        shouldSend = true;
        delayTicks = 5;
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (shouldSend) {
            if (delayTicks > 0) {
                delayTicks--;
                return;
            }
            String msg = message.getValue();
            try {
                mc.player.sendChatMessage(msg);
            } catch (Exception e) {
                if (mc.ingameGUI != null && mc.ingameGUI.getChatGUI() != null) {
                    mc.ingameGUI.getChatGUI().printChatMessage(new TextComponentString(msg));
                }
            }
            shouldSend = false;
            delayTicks = 0;
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        shouldSend = false;
        delayTicks = 0;
        ChatUtils.message("AutoGG enabled");
    }

    @Override
    public void onDisable() {
        super.onDisable();
        shouldSend = false;
        delayTicks = 0;
    }
}
