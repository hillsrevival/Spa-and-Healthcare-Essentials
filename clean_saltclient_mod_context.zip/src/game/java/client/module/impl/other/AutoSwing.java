package client.module.impl.other;

import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumHand;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class AutoSwing extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting delay = new NumberSetting("Delay", 0.0, 0.0, 10.0);

    private int tickCounter = 0;

    public AutoSwing() {
        super("AutoSwing", Category.OTHER);
        setDescription("Automatically swings your arm when attacking");
        addSetting(delay);
        handles(HandlerType.POST_UPDATE);
    }

    @Override
    public void onPostUpdate() {
        if (mc.player == null)
            return;
        int delayTicks = delay.getValue().intValue();
        if (tickCounter > 0) {
            tickCounter--;
            return;
        }
        mc.player.swingArm(EnumHand.MAIN_HAND);
        tickCounter = delayTicks;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        tickCounter = 0;
    }
}
