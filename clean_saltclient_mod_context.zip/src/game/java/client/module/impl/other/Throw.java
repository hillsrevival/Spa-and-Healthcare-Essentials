package client.module.impl.other;

import net.minecraft.client.Minecraft;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import java.util.Random;

public class Throw extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Random rand = new Random();

    private final NumberSetting amount = new NumberSetting("Amount", 5.0, 2.0, 64.0);

    private final NumberSetting delay = new NumberSetting("Delay", 2.0, 1.0, 10.0);

    private int tickCounter = 0;

    public Throw() {
        super("Throw", Category.OTHER);
        setDescription("Increases throw distance for items and bottles");
        addSetting(amount);
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        tickCounter++;
        if (tickCounter < delay.getValue().intValue())
            return;
        tickCounter = 0;
        if ((mc.rightClickDelayTimer == 4 || mc.rightClickDelayTimer == 0) && mc.gameSettings.keyBindUseItem.isKeyDown()) {
            if (mc.objectMouseOver == null || mc.player.getHeldItemMainhand() == null)
                return;
            if (mc.player.getHeldItemMainhand().func_190926_b())
                return;
            int count = Math.min(amount.getValue().intValue(), 3);
            for (int i = 0; i < count - 1; i++) {
                mc.rightClickMouse();
            }
        }
    }
}
