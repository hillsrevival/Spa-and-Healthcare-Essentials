package client.module.impl.other;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.client.Minecraft;

public class NoInteract extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public NoInteract() {
        super("NoInteract", Category.OTHER);
        setDescription("Prevents interacting with blocks and entities");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (mc.gameSettings.keyBindUseItem.isKeyDown()) {
            mc.objectMouseOver = null;
        }
    }
}
