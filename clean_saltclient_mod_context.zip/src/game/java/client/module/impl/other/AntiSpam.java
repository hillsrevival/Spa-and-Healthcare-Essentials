package client.module.impl.other;

import net.minecraft.client.Minecraft;
import client.event.listeners.ChatInputListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class AntiSpam extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting delay = new NumberSetting("Delay", 5.0, 1.0, 30.0);

    private String lastMessage = "";

    private int lastMessageTick = -999;

    public AntiSpam() {
        super("AntiSpam", Category.OTHER);
        setDescription("Filters duplicate or spam chat messages");
        addSetting(delay);
        handles(HandlerType.CHAT_INPUT, HandlerType.UPDATE);
    }

    @Override
    public void onChatInput(ChatInputListener.ChatInputEvent event) {
        String text = event.getComponent().getUnformattedText();
        int delayTicks = delay.getValue().intValue() * 20;
        if (text.equals(lastMessage) && (tickCounter - lastMessageTick) < delayTicks) {
            event.setCancelled(true);
            return;
        }
        lastMessage = text;
        lastMessageTick = tickCounter;
    }

    private int tickCounter = 0;

    @Override
    public void onUpdate() {
        tickCounter++;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        lastMessage = "";
        lastMessageTick = -999;
        tickCounter = 0;
    }
}
