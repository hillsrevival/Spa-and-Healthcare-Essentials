package client.module.impl.other;

import client.event.events.PlaySoundAtEntityEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.NumberSetting;
import client.module.Condition;
import net.minecraft.util.SoundCategory;

public class SoundBlocker extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Master Volume", "Master Volume", "Cancel Sounds");

    private final NumberSetting volume = new NumberSetting("Volume", 0.0, 0.0, 100.0);

    private final BooleanSetting cancelExplosions = new BooleanSetting("Explosions", true);

    private final BooleanSetting cancelBlaze = new BooleanSetting("Blaze Shots", true);

    private final BooleanSetting cancelWither = new BooleanSetting("Wither", true);

    private final BooleanSetting cancelAnvil = new BooleanSetting("Anvil", true);

    private float savedMasterVolume = -1.0f;

    private float lastAppliedVolume = Float.NaN;

    public SoundBlocker() {
        super("SoundBlocker", Category.OTHER);
        setDescription("Blocks specific game sounds");
        addSetting(mode);
        addSetting(volume);
        addSetting(cancelExplosions);
        addSetting(cancelBlaze);
        addSetting(cancelWither);
        addSetting(cancelAnvil);
        handles(HandlerType.UPDATE, HandlerType.PLAY_SOUND);
        cancelExplosions.setVisibilityCondition(Condition.whenEqualTo(mode, "Cancel Sounds"));
        cancelBlaze.setVisibilityCondition(Condition.whenEqualTo(mode, "Cancel Sounds"));
        cancelWither.setVisibilityCondition(Condition.whenEqualTo(mode, "Cancel Sounds"));
        cancelAnvil.setVisibilityCondition(Condition.whenEqualTo(mode, "Cancel Sounds"));
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (!mode.getValue().equals("Master Volume")) {
            restoreMasterVolume();
            return;
        }
        float vol = volume.getValue().floatValue() / 100.0f;
        if (Float.isNaN(lastAppliedVolume) || lastAppliedVolume != vol) {
            if (savedMasterVolume < 0.0f) {
                savedMasterVolume = mc.gameSettings.getSoundLevel(SoundCategory.MASTER);
            }
            mc.gameSettings.setSoundLevel(SoundCategory.MASTER, vol);
            lastAppliedVolume = vol;
        }
    }

    @Override
    public void onPlaySoundAtEntity(PlaySoundAtEntityEvent event) {
        if (!mode.getValue().equals("Cancel Sounds"))
            return;
        String sound = event.getSoundName();
        if (sound == null)
            return;
        if (cancelExplosions.getValue() && sound.contains("entity.generic.explode")) {
            event.setCancelled(true);
        }
        if (cancelBlaze.getValue() && sound.contains("entity.blaze.shoot")) {
            event.setCancelled(true);
        }
        if (cancelWither.getValue() && sound.contains("entity.wither")) {
            event.setCancelled(true);
        }
        if (cancelAnvil.getValue() && sound.contains("block.anvil")) {
            event.setCancelled(true);
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        savedMasterVolume = -1.0f;
        lastAppliedVolume = Float.NaN;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        restoreMasterVolume();
    }

    private void restoreMasterVolume() {
        if (mc != null && mc.gameSettings != null && savedMasterVolume >= 0.0f) {
            mc.gameSettings.setSoundLevel(SoundCategory.MASTER, savedMasterVolume);
        }
        savedMasterVolume = -1.0f;
        lastAppliedVolume = Float.NaN;
    }
}
