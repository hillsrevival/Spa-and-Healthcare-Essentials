package client.module.impl.other;

import client.event.events.PacketInputEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.text.TextComponentString;
import java.util.HashSet;
import java.util.Set;
import client.utils.render.ClientFontRenderer;

public class MurderFinder extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Set<Integer> murdererIds = new HashSet<>();

    public MurderFinder() {
        super("MurderFinder", Category.OTHER);
        setDescription("Identifies the murderer in Murder Mystery");
        handles(HandlerType.UPDATE, HandlerType.GUI_RENDER);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        for (EntityPlayer player : mc.world.playerEntities) {
            if (player == mc.player)
                continue;
            ItemStack heldItem = player.getHeldItemMainhand();
            boolean armed = heldItem != null && !heldItem.func_190926_b() && (heldItem.getItem() == Items.IRON_SWORD || heldItem.getItem() == Items.STONE_SWORD || heldItem.getItem() == Items.GOLDEN_SWORD || heldItem.getItem() == Items.DIAMOND_SWORD || heldItem.getItem() == Items.WOODEN_SWORD);
            if (armed)
                murdererIds.add(player.getEntityId());
            else
                murdererIds.remove(player.getEntityId());
        }
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (murdererIds.isEmpty())
            return;
        net.minecraft.client.gui.ScaledResolution sr = mc.scaledResolution;
        if (sr == null) {
            sr = new net.minecraft.client.gui.ScaledResolution(mc);
        }
        int y = 40;
        for (int id : murdererIds) {
            Entity entity = mc.world.getEntityByID(id);
            if (!(entity instanceof EntityPlayer))
                continue;
            EntityPlayer murderer = (EntityPlayer) entity;
            String text = "Murderer: " + murderer.getName();
            int cx = sr.getScaledWidth() / 2;
            ClientFontRenderer.drawCenteredStringWithShadow(text, cx, y, 0xFF0000);
            y += 12;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        murdererIds.clear();
    }
}
