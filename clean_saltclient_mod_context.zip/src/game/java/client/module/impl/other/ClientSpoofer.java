package client.module.impl.other;

import client.event.events.PacketOutputEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.StringSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.CPacketCustomPayload;
import net.minecraft.network.PacketBuffer;
import io.netty.buffer.Unpooled;

public class ClientSpoofer extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final StringSetting brand = new StringSetting("Brand", "");

    public ClientSpoofer() {
        super("ClientSpoofer", Category.OTHER);
        setDescription("Spoof your client, remove default text");
        addSetting(brand);
        handles(HandlerType.PACKET_OUTPUT);
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        if (!(event.getPacket() instanceof CPacketCustomPayload))
            return;
        CPacketCustomPayload packet = (CPacketCustomPayload) event.getPacket();
        if (packet.getChannelName() != null && packet.getChannelName().equals("MC|Brand")) {
            String spoofed = brand.getValue();
            PacketBuffer buf = new PacketBuffer(Unpooled.buffer());
            buf.writeString(spoofed);
            event.setPacket(new CPacketCustomPayload("MC|Brand", buf));
        }
    }
}
