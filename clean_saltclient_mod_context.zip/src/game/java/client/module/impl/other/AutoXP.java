package client.module.impl.other;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.world.InteractionUtils;

public class AutoXP extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting delay = new NumberSetting("Delay", 2.0, 0.0, 20.0);

    private final BooleanSetting autoSwitch = new BooleanSetting("AutoSwitch", true);

    private int timer = 0;

    public AutoXP() {
        super("AutoXP", Category.OTHER);
        setDescription("Uses experience bottles automatically");
        addSetting(delay);
        addSetting(autoSwitch);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (timer > 0) {
            timer--;
            return;
        }
        int bottleSlot = findXPBottle();
        if (bottleSlot == -1) {
            toggle();
            return;
        }
        if (autoSwitch.getValue() && bottleSlot != mc.player.inventory.currentItem) {
            mc.player.inventory.currentItem = bottleSlot;
            return;
        }
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held.func_190926_b() || held.getItem() != Items.EXPERIENCE_BOTTLE)
            return;
        InteractionUtils.useItem(EnumHand.MAIN_HAND);
        mc.player.swingArm(EnumHand.MAIN_HAND);
        timer = delay.getValue().intValue();
    }

    private int findXPBottle() {
        client.utils.player.FindItemResult r = client.utils.player.InvUtils.findInHotbar(net.minecraft.init.Items.EXPERIENCE_BOTTLE);
        return r.found() ? r.slot() - client.utils.player.SlotUtils.HOTBAR_START : -1;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        timer = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        timer = 0;
    }
}
