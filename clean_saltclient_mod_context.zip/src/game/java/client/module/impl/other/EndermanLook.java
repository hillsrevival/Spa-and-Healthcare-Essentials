package client.module.impl.other;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.monster.EntityEnderman;

public class EndermanLook extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public EndermanLook() {
        super("EndermanLook", Category.OTHER);
        setDescription("Prevents the camera from looking at endermen");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.objectMouseOver == null)
            return;
        if (mc.objectMouseOver.typeOfHit != net.minecraft.util.math.RayTraceResult.Type.ENTITY)
            return;
        if (mc.objectMouseOver.entityHit instanceof EntityEnderman) {
            if (mc.player.rotationPitch > -60.0f) {
                mc.player.rotationPitch = -65.0f;
            }
        }
    }
}
