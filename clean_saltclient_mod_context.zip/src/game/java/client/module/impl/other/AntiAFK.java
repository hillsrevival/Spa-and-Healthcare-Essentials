package client.module.impl.other;

import net.minecraft.client.Minecraft;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import java.util.Random;

public class AntiAFK extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Random random = new Random();

    private final NumberSetting interval = new NumberSetting("Interval", 40.0, 20.0, 100.0);

    private final NumberSetting yawChange = new NumberSetting("Yaw Change", 30.0, 5.0, 90.0);

    private int timer;

    public AntiAFK() {
        super("AntiAFK", Category.OTHER);
        setDescription("Stops you from being kicked due to afk by moving a bit");
        addSetting(interval);
        addSetting(yawChange);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (mc.player.getHealth() <= 0) {
            toggle();
            return;
        }
        if (timer > 0) {
            timer--;
            mc.gameSettings.keyBindJump.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), mc.player.isInWater());
            return;
        }
        int yawRange = yawChange.getValue().intValue();
        float yaw = mc.player.rotationYaw + random.nextInt(yawRange * 2) - yawRange;
        mc.player.rotationYaw = yaw;
        mc.player.rotationYawHead = yaw;
        mc.gameSettings.keyBindForward.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), true);
        if (mc.player.onGround) {
            mc.player.jump();
        }
        int base = interval.getValue().intValue();
        timer = base + random.nextInt(21) - 10;
        if (timer < 10)
            timer = 10;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        releaseMovementKeys();
        timer = 0;
    }
}
