package client.module.impl.other;

import net.minecraft.client.Minecraft;
import client.utils.world.PacketUtils;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class Regen extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting speed = new NumberSetting("Speed", 5.0, 1.0, 10.0);

    public Regen() {
        super("Regen", Category.OTHER);
        setDescription("Regenerates health faster");
        addSetting(speed);
        handles(HandlerType.TICK);
    }

    @Override
    public void onTick() {
        if (!nullCheck())
            return;
        if (mc.player.getHealth() >= mc.player.getMaxHealth())
            return;
        if (mc.player.capabilities.isCreativeMode)
            return;
        if (mc.player.getFoodStats().getFoodLevel() < 18)
            return;
        int packets = speed.getValue().intValue();
        for (int i = 0; i < packets; i++) {
            PacketUtils.sendPosition(mc.player.posX, mc.player.posY + 0.0000001 * (i + 1), mc.player.posZ, mc.player.onGround);
        }
    }
}
