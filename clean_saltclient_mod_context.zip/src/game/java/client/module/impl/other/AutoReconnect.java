package client.module.impl.other;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import net.minecraft.client.multiplayer.ServerData;

public class AutoReconnect extends Module {

    private final NumberSetting time = new NumberSetting("DelaySec", 3.5, 0.0, 60.0);

    private final BooleanSetting button = new BooleanSetting("HideButtons", false);

    public static ServerData lastServerConnection;

    public static String lastServerAddress;

    public AutoReconnect() {
        super("AutoReconnect", Category.OTHER);
        setDescription("Automatically reconnects to the server if the connection fails");
        addSetting(time);
        addSetting(button);
        handles(HandlerType.UPDATE);
    }

    public double getDelaySeconds() {
        return time.getValue();
    }

    public boolean isHideButtons() {
        return button.getValue();
    }

    public static AutoReconnect get() {
        client.module.Module m = client.module.ModuleManager.getModuleByName("AutoReconnect");
        return m instanceof AutoReconnect ? (AutoReconnect) m : null;
    }

    @Override
    public void onUpdate() {
    }
}
