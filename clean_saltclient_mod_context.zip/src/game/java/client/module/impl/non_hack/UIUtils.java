package client.module.impl.non_hack;

import java.util.ArrayList;
import java.util.List;
import net.lax1dude.eaglercraft.Keyboard;
import net.lax1dude.eaglercraft.Mouse;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.Container;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketClickWindow;
import net.minecraft.network.play.client.CPacketCloseWindow;
import net.minecraft.network.play.client.CPacketEnchantItem;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketUpdateSign;
import client.Client;
import client.event.Event;
import client.event.Listener;
import client.event.events.KeyPressEvent;
import client.event.events.PacketOutputEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.ChatUtils;
import client.utils.world.PacketUtils;
import client.utils.render.ClientFontRenderer;

public class UIUtils extends Module {

    public static boolean chatFieldFocused = false;

    private final Minecraft mc = Minecraft.getMinecraft();

    private boolean sendPackets = true;

    private boolean delayPackets = false;

    private boolean signNoPacket = false;

    private boolean inGUIChat = false;

    private boolean clientWakeUp = false;

    private final List<Packet<?>> delayedPackets = new ArrayList<Packet<?>>();

    private GuiScreen savedContainerScreen = null;

    private Container savedContainer = null;

    private int savedWindowId = 0;

    private boolean needsClientWake = false;

    private boolean wasMouseDown = false;

    private short lastActionNumber = 0;

    private GuiTextField chatField = null;

    private boolean chatFocused = false;

    private final Listener keyListener = new Listener() {

        @Override
        public void onEvent(Event event) {
            if (!isToggled())
                return;
            handleKeyInput((KeyPressEvent) event);
        }
    };

    public UIUtils() {
        super("UIUtils", Category.NON_HACK);
        setDescription("Dupe utils");
        handles(HandlerType.PACKET_OUTPUT, HandlerType.TICK, HandlerType.GUI_RENDER);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        delayedPackets.clear();
        savedContainerScreen = null;
        savedContainer = null;
        savedWindowId = 0;
        needsClientWake = false;
        wasMouseDown = false;
        chatFocused = false;
        chatFieldFocused = false;
        sendPackets = true;
        delayPackets = false;
        signNoPacket = false;
        inGUIChat = false;
        clientWakeUp = false;
        chatField = new GuiTextField(999, ClientFontRenderer.getFontRenderer(), 5, 245, 160, 20);
        chatField.setMaxStringLength(256);
        chatField.setFocused(false);
        chatField.setEnableBackgroundDrawing(true);
        chatField.setVisible(true);
        Client.bus().register(KeyPressEvent.class, keyListener);
        ChatUtils.info("UIUtils enabled");
    }

    @Override
    public void onDisable() {
        Client.bus().unregister(KeyPressEvent.class, keyListener);
        chatFieldFocused = false;
        chatFocused = false;
        if (!delayedPackets.isEmpty() && mc.player != null && mc.player.connection != null) {
            for (Packet<?> pkt : delayedPackets) {
                PacketUtils.send(pkt);
            }
            ChatUtils.message("Released " + delayedPackets.size() + " delayed packet(s)");
        }
        delayedPackets.clear();
        savedContainerScreen = null;
        savedContainer = null;
        needsClientWake = false;
        ChatUtils.message("UIUtils disabled");
        super.onDisable();
    }

    private void handleKeyInput(KeyPressEvent event) {
        if (mc.player == null)
            return;
        int keyCode = event.getKeyCode();
        char typedChar = Keyboard.getEventCharacter();
        if (chatFocused && chatField != null) {
            if (keyCode == 28) {
                sendChatMessage();
                return;
            }
            if (keyCode == 1) {
                unfocusChat();
                return;
            }
            chatField.textboxKeyTyped(typedChar, keyCode);
            return;
        }
    }

    private void unfocusChat() {
        chatFocused = false;
        chatFieldFocused = false;
        if (chatField != null) {
            chatField.setFocused(false);
        }
    }

    private void focusChat() {
        chatFocused = true;
        chatFieldFocused = true;
        if (chatField != null) {
            chatField.setFocused(true);
        }
    }

    private void sendChatMessage() {
        if (chatField == null)
            return;
        String msg = chatField.getText().trim();
        chatField.setText("");
        if (msg.isEmpty())
            return;
        if (mc.player == null || mc.player.connection == null)
            return;
        PacketUtils.sendChatMessage(msg);
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        if (mc.player == null)
            return;
        Packet<?> packet = event.getPacket();
        if (packet instanceof CPacketClickWindow) {
            lastActionNumber = ((CPacketClickWindow) packet).getActionNumber();
        }
        if (!sendPackets && !delayPackets) {
            if (packet instanceof CPacketClickWindow || packet instanceof CPacketEnchantItem) {
                event.setCancelled(true);
            }
        }
        if (delayPackets) {
            if (packet instanceof CPacketClickWindow || packet instanceof CPacketEnchantItem) {
                delayedPackets.add(packet);
                event.setCancelled(true);
            }
        }
        if (signNoPacket && packet instanceof CPacketUpdateSign) {
            event.setCancelled(true);
        }
        if (clientWakeUp && packet instanceof CPacketEntityAction) {
            CPacketEntityAction action = (CPacketEntityAction) packet;
            if (action.getAction() == CPacketEntityAction.Action.STOP_SLEEPING) {
                event.setCancelled(true);
                needsClientWake = true;
            }
        }
    }

    @Override
    public void onTick() {
        if (mc.player == null)
            return;
        if (chatField != null) {
            chatField.updateCursorCounter();
        }
        if (needsClientWake) {
            needsClientWake = false;
            if (mc.player.isPlayerSleeping()) {
                mc.player.wakeUpPlayer(true, true, false);
                mc.displayGuiScreen(null);
                ChatUtils.message("Client wake up (no packet sent)");
            }
        }
    }

    private void executeCloseWithoutPacket() {
        if (mc.currentScreen == null)
            return;
        if (!(mc.currentScreen instanceof GuiContainer))
            return;
        unfocusChat();
        mc.displayGuiScreen(null);
    }

    private void executeDeSync() {
        if (mc.player == null || mc.currentScreen == null)
            return;
        if (!(mc.currentScreen instanceof GuiContainer))
            return;
        int windowId = mc.player.openContainer.windowId;
        if (mc.player.connection != null) {
            PacketUtils.sendCloseWindow(windowId);
            ChatUtils.message("De-sync: sent close packet for window " + windowId);
        }
    }

    private void flushDelayedPackets() {
        if (delayedPackets.isEmpty())
            return;
        if (mc.player == null || mc.player.connection == null)
            return;
        int count = delayedPackets.size();
        for (Packet<?> pkt : delayedPackets) {
            PacketUtils.send(pkt);
        }
        delayedPackets.clear();
        ChatUtils.message("Sent " + count + " delayed packet(s)");
    }

    private void executeSaveGUI() {
        if (mc.player == null || mc.currentScreen == null)
            return;
        if (!(mc.currentScreen instanceof GuiContainer))
            return;
        savedContainerScreen = mc.currentScreen;
        savedContainer = mc.player.openContainer;
        savedWindowId = mc.player.openContainer.windowId;
        ChatUtils.message("Saved GUI (window " + savedWindowId + ")");
    }

    private void executeRestoreGUI() {
        if (savedContainerScreen == null) {
            ChatUtils.warning("No saved GUI to restore");
            return;
        }
        if (mc.player == null)
            return;
        GuiScreen toRestore = savedContainerScreen;
        int restoredId = savedWindowId;
        savedContainerScreen = null;
        savedContainer = null;
        mc.displayGuiScreen(toRestore);
        ChatUtils.message("Restored GUI (window " + restoredId + ")");
    }

    private void executeDisconnectAndSend() {
        if (mc.player == null || mc.player.connection == null)
            return;
        delayPackets = false;
        for (Packet<?> pkt : delayedPackets) {
            PacketUtils.send(pkt);
        }
        delayedPackets.clear();
        unfocusChat();
        if (mc.world != null) {
            mc.world.sendQuittingDisconnectingPacket();
        }
        mc.loadWorld(null);
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        boolean containerOpen = (mc.currentScreen instanceof GuiContainer);
        boolean isMouseDown = Mouse.isButtonDown(0);
        boolean justClicked = isMouseDown && !wasMouseDown;
        wasMouseDown = isMouseDown;
        if (!containerOpen) {
            if (chatFocused)
                unfocusChat();
            return;
        }
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        int screenWidth = sr.getScaledWidth();
        int screenHeight = sr.getScaledHeight();
        int mx = (int) ((double) Mouse.getX() * screenWidth / (double) mc.displayWidth);
        int my = screenHeight - (int) ((double) Mouse.getY() * screenHeight / (double) mc.displayHeight) - 1;
        Container container = mc.player.openContainer;
        int windowId = container.windowId;
        int btnW = 160;
        int btnH = 16;
        int btnGap = 4;
        int curX = 5;
        int curY = 5;
        ClientFontRenderer.drawStringWithShadow("Sync Id: " + windowId, 200, 5, 0xFFFFFF);
        ClientFontRenderer.drawStringWithShadow("Action #: " + lastActionNumber, 200, 17, 0xFFFFFF);
        ClientFontRenderer.drawStringWithShadow("Queued: " + delayedPackets.size(), 200, 29, 0xFFFFFF);
        curY = drawButton(mx, my, justClicked, curX, curY, btnW, btnH, "Close without packet", 0xFFAAAAAA, 0xFF3333, () -> executeCloseWithoutPacket());
        curY += btnGap;
        curY = drawButton(mx, my, justClicked, curX, curY, btnW, btnH, "De-sync", 0xFFAAAAAA, 0xFF3333, () -> executeDeSync());
        curY += btnGap;
        curY = drawToggleButton(mx, my, justClicked, curX, curY, btnW, btnH, "Send packets: " + sendPackets, sendPackets, (v) -> {
            sendPackets = v;
        });
        curY += btnGap;
        curY = drawToggleButton(mx, my, justClicked, curX, curY, btnW, btnH, "Delay packets: " + delayPackets, delayPackets, (v) -> {
            boolean was = delayPackets;
            delayPackets = v;
            if (was && !v)
                flushDelayedPackets();
        });
        curY += btnGap;
        curY = drawButton(mx, my, justClicked, curX, curY, btnW, btnH, "Save GUI", 0xFFAAAAAA, 0xFFCC00, () -> executeSaveGUI());
        curY += btnGap;
        curY = drawButton(mx, my, justClicked, curX, curY, btnW + 20, btnH, "Disconnect && send packets", 0xFFAAAAAA, 0xFF6666, () -> executeDisconnectAndSend());
        curY += btnGap + 4;
        Gui.drawRect(curX, curY, curX + btnW, curY + 1, 0x60FF3333);
        curY += 4;
        curY = drawToggleButton(mx, my, justClicked, curX, curY, btnW, btnH, "No Sign Packet: " + signNoPacket, signNoPacket, (v) -> {
            signNoPacket = v;
        });
        curY += btnGap;
        curY = drawToggleButton(mx, my, justClicked, curX, curY, btnW, btnH, "GUI Chat: " + inGUIChat, inGUIChat, (v) -> {
            inGUIChat = v;
            if (!v)
                unfocusChat();
        });
        curY += btnGap;
        curY = drawToggleButton(mx, my, justClicked, curX, curY, btnW, btnH, "Client Wake Up: " + clientWakeUp, clientWakeUp, (v) -> {
            clientWakeUp = v;
        });
        curY += btnGap + 4;
        String restoreLabel = "Restore GUI" + (savedContainerScreen != null ? " (" + savedWindowId + ")" : " (none)");
        curY = drawButton(mx, my, justClicked, curX, curY, btnW, btnH, restoreLabel, savedContainerScreen != null ? 0xFFAAAAAA : 0xFF555555, 0xFFCC00, () -> executeRestoreGUI());
        if (inGUIChat && chatField != null) {
            if (justClicked) {
                chatField.mouseClicked(mx, my, 0);
                chatFocused = chatField.isFocused();
                chatFieldFocused = chatFocused;
            }
            chatField.drawTextBox();
        }
    }

    @FunctionalInterface
    private interface ClickAction {

        void run();
    }

    private int drawToggleButton(int mx, int my, boolean justClicked, int x, int y, int w, int h, String label, boolean isOn, java.util.function.Consumer<Boolean> setter) {
        boolean hovered = (mx >= x && mx <= x + w && my >= y && my <= y + h);
        int bgColor = isOn ? 0xC0333333 : 0xC0222222;
        if (hovered)
            bgColor = isOn ? 0xD0444444 : 0xD0333333;
        Gui.drawRect(x, y, x + w, y + h, bgColor);
        int borderColor = isOn ? 0xFF3333 : 0xFF555555;
        if (hovered)
            borderColor = isOn ? 0xFF5555 : 0xFF777777;
        Gui.drawRect(x, y, x + w, y + 1, borderColor);
        Gui.drawRect(x, y + h - 1, x + w, y + h, borderColor);
        Gui.drawRect(x, y, x + 1, y + h, borderColor);
        Gui.drawRect(x + w - 1, y, x + w, y + h, borderColor);
        int dotColor = isOn ? 0xFF3333 : 0xFF444444;
        Gui.drawRect(x + 4, y + (h - 6) / 2, x + 10, y + (h - 6) / 2 + 6, dotColor);
        int textColor = isOn ? 0xFFFFFFFF : 0xFFAAAAAA;
        ClientFontRenderer.drawStringWithShadow(label, x + 16, y + (h - ClientFontRenderer.fontHeight()) / 2, textColor);
        if (justClicked && hovered) {
            setter.accept(!isOn);
        }
        return y + h;
    }

    private int drawButton(int mx, int my, boolean justClicked, int x, int y, int w, int h, String label, int textCol, int accentCol, ClickAction action) {
        boolean hovered = (mx >= x && mx <= x + w && my >= y && my <= y + h);
        int bgColor = 0xB0202020;
        if (hovered)
            bgColor = 0xC0404040;
        Gui.drawRect(x, y, x + w, y + h, bgColor);
        Gui.drawRect(x, y, x + 2, y + h, accentCol);
        int textColor = hovered ? 0xFFFFFFFF : textCol;
        ClientFontRenderer.drawStringWithShadow(label, x + 6, y + (h - ClientFontRenderer.fontHeight()) / 2, textColor);
        if (justClicked && hovered) {
            action.run();
        }
        return y + h;
    }
}
