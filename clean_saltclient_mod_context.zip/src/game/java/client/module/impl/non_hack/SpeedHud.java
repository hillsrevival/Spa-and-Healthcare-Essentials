package client.module.impl.non_hack;

import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;

public class SpeedHud extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final HudElement pos = new HudElement(this, -1, -1);

    private double prevX = 0;

    private double prevZ = 0;

    private double speed = 0;

    private long lastTime = 0;

    public SpeedHud() {
        super("SpeedHud", Category.NON_HACK);
        setDescription("Shows your current speed in blocks per second");
        pos.addSettings();
        handles(HandlerType.UPDATE, HandlerType.GUI_RENDER);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        long now = System.currentTimeMillis();
        if (lastTime > 0) {
            double dt = (now - lastTime) / 1000.0;
            if (dt > 0) {
                double dx = mc.player.posX - prevX;
                double dz = mc.player.posZ - prevZ;
                double instantSpeed = Math.sqrt(dx * dx + dz * dz) / dt;
                speed = speed * 0.8 + instantSpeed * 0.2;
            }
        }
        prevX = mc.player.posX;
        prevZ = mc.player.posZ;
        lastTime = now;
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (!pos.shouldRender())
            return;
        String text = String.format("Speed: %.1f b/s", speed);
        int boxW = ClientFontRenderer.getStringWidth(text) + 8;
        int boxH = ClientFontRenderer.fontHeight() + 8;
        pos.updateDrag(boxW, boxH);
        int x = pos.getX();
        int y = pos.getY();
        RenderUtils.drawHudPanel(x, y, boxW, boxH, 0.7f);
        ClientFontRenderer.drawStringWithShadow(text, x + 4, y + 4, 0xFFAAAAAA);
        pos.renderDragBox(x, y, boxW, boxH);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        speed = 0;
        lastTime = 0;
    }
}
