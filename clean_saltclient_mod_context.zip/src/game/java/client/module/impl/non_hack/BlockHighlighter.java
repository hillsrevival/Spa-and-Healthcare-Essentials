package client.module.impl.non_hack;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ColorSetting;
import client.module.NumberSetting;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.minecraft.client.renderer.Tessellator;
import net.lax1dude.eaglercraft.opengl.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import client.event.listeners.RenderListener;

public class BlockHighlighter extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting lineWidth = new NumberSetting("Line Width", 2.0, 0.5, 5.0);

    private final NumberSetting boxAlpha = new NumberSetting("Box Alpha", 80.0, 0.0, 255.0);

    public BlockHighlighter() {
        super("BlockHighlighter", Category.NON_HACK);
        setDescription("Highlights the block you look at");
        addSetting(lineWidth);
        addSetting(boxAlpha);
        handles(HandlerType.RENDER);
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!nullCheck())
            return;
        if (mc.objectMouseOver == null)
            return;
        if (mc.objectMouseOver.typeOfHit != RayTraceResult.Type.BLOCK)
            return;
        BlockPos pos = mc.objectMouseOver.getBlockPos();
        if (pos == null)
            return;
        RenderUtils.updateCameraPos(event.getPartialTicks());
        double camX = mc.getRenderManager().viewerPosX;
        double camY = mc.getRenderManager().viewerPosY;
        double camZ = mc.getRenderManager().viewerPosZ;
        double bx = pos.getX() - camX;
        double by = pos.getY() - camY;
        double bz = pos.getZ() - camZ;
        int accent = ClickGUI.getAccent();
        float r = ((accent >> 16) & 0xFF) / 255.0f;
        float g = ((accent >> 8) & 0xFF) / 255.0f;
        float b = (accent & 0xFF) / 255.0f;
        float alpha = boxAlpha.getValue().floatValue() / 255.0f;
        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
        GlStateManager.disableDepth();
        AxisAlignedBB box = new AxisAlignedBB(bx, by, bz, bx + 1, by + 1, bz + 1);
        RenderUtils.drawOutlinedBox(box, r, g, b, alpha);
        RenderUtils.drawSolidBox(box, r * 0.3f, g * 0.3f, b * 0.3f, alpha * 0.3f);
        Vec3d eyePos = mc.player.getPositionEyes(event.getPartialTicks());
        double eyeX = eyePos.xCoord - camX;
        double eyeY = eyePos.yCoord - camY;
        double eyeZ = eyePos.zCoord - camZ;
        double targetX = bx + 0.5;
        double targetY = by + 0.5;
        double targetZ = bz + 0.5;
        net.lax1dude.eaglercraft.opengl.EaglercraftGPU.glLineWidth(lineWidth.getValue().floatValue());
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        buf.begin(RealOpenGLEnums.GL_LINES, DefaultVertexFormats.POSITION);
        GlStateManager.color(r, g, b, 0.8f);
        buf.pos(eyeX, eyeY, eyeZ).endVertex();
        buf.pos(targetX, targetY, targetZ).endVertex();
        tess.draw();
        EaglercraftGPU.glLineWidth(1.0f);
        GlStateManager.enableDepth();
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
        GlStateManager.popMatrix();
        RenderUtils.restoreHUD();
    }

    private static class ClickGUI {

        static int getAccent() {
            return client.gui.clickgui.ClickGUI.getAccent();
        }
    }
}
