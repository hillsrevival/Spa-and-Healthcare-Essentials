package client.module.impl.non_hack;

import client.module.BooleanSetting;
import client.module.Category;
import client.module.ColorSetting;
import client.module.Module;

public class HitColour extends Module {

    private final ColorSetting color = new ColorSetting("Color", 0.0);

    private final BooleanSetting removeColor = new BooleanSetting("Remove Color", false);

    public HitColour() {
        super("HitColour", Category.NON_HACK);
        setDescription("Change the color entities flash when hit (or remove it entirely)");
        addSetting(color);
        addSetting(removeColor);
    }

    public boolean shouldRemoveColor() {
        return removeColor.getValue();
    }

    public float[] getCustomColor() {
        return color.getRGBFloat();
    }
}
