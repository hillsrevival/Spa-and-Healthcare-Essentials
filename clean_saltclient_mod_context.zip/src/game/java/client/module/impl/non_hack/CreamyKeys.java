package client.module.impl.non_hack;

import java.util.Random;
import client.Client;
import client.event.Listener;
import client.event.events.KeyPressEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.NumberSetting;
import net.lax1dude.eaglercraft.Mouse;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;

public class CreamyKeys extends Module {

    private final Random random = new Random();

    private static final String[] KEY_PACK_NAMES = { "Cherry MX Blue", "Cherry MX Red", "Cherry MX Brown", "Cherry MX Black" };

    private static final String[] KEY_EVENT_PREFIXES = { "keyboards.cherrymx_blue_abs", "keyboards.cherrymx_red_abs", "keyboards.cherrymx_brown_abs", "keyboards.cherrymx_black_abs" };

    private static final int KEY_VARIANT_COUNT = 40;

    private static final String[] HIT_PACK_NAMES = { "Hit", "Hit 2", "Hit 3", "Hit 4", "Ponk", "Laser", "Corsair LMB", "Corsair MMB" };

    private static final String[] HIT_EVENT_NAMES = { "bundled_keyboards.hit", "bundled_keyboards.hit1", "bundled_keyboards.hit2", "bundled_keyboards.hit4", "bundled_keyboards.ponk", "bundled_keyboards.laser", "bundled_keyboards.corsair_lmb", "bundled_keyboards.corsair_mmb" };

    private final ModeSetting keySound = new ModeSetting("Key Sound", "Cherry MX Blue", KEY_PACK_NAMES);

    private final ModeSetting hitSound = new ModeSetting("Hit Sound", "Hit", HIT_PACK_NAMES);

    private final NumberSetting volume = new NumberSetting("Volume", 1.0, 0.1, 2.0);

    private final NumberSetting pitch = new NumberSetting("Pitch", 1.0, 0.5, 1.5);

    private final Listener keyListener = event -> {
        if (event instanceof KeyPressEvent) {
            playKeySound();
        }
    };

    private boolean prevLMB = false;

    private boolean prevRMB = false;

    public CreamyKeys() {
        super("CreamyKeys", Category.NON_HACK);
        setDescription("Plays a creamy key sound every time you press a key");
        addSetting(keySound);
        addSetting(hitSound);
        addSetting(volume);
        addSetting(pitch);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        Client.bus().register(KeyPressEvent.class, keyListener);
        prevLMB = false;
        prevRMB = false;
    }

    @Override
    public void onDisable() {
        Client.bus().unregister(KeyPressEvent.class, keyListener);
        super.onDisable();
    }

    @Override
    public void onUpdate() {
        boolean lmb = Mouse.isButtonDown(0);
        boolean rmb = Mouse.isButtonDown(1);
        if (lmb && !prevLMB) {
            playHitSound();
        }
        if (rmb && !prevRMB) {
            playHitSound();
        }
        prevLMB = lmb;
        prevRMB = rmb;
    }

    private void playKeySound() {
        int index = indexOf(KEY_PACK_NAMES, keySound.getValue());
        String eventPrefix = KEY_EVENT_PREFIXES[index];
        int variant = random.nextInt(KEY_VARIANT_COUNT) + 1;
        String eventName = String.format("%s.key_%02d", eventPrefix, variant);
        playSound(eventName);
    }

    private void playHitSound() {
        int index = indexOf(HIT_PACK_NAMES, hitSound.getValue());
        playSound(HIT_EVENT_NAMES[index]);
    }

    private void playSound(String eventName) {
        float vol = volume.getValue().floatValue();
        float pitchVal = pitch.getValue().floatValue();
        try {
            Minecraft.getMinecraft().getSoundHandler().playSound(new PositionedSoundRecord(new ResourceLocation("creamykeys", eventName), SoundCategory.MASTER, vol, pitchVal, false, 0, ISound.AttenuationType.NONE, 0.0F, 0.0F, 0.0F));
        } catch (Exception e) {
        }
    }

    private static int indexOf(String[] array, String value) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].equalsIgnoreCase(value)) {
                return i;
            }
        }
        return 0;
    }
}
