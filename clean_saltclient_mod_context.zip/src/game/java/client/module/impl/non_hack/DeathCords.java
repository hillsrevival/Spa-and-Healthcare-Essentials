package client.module.impl.non_hack;

import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import client.event.listeners.DeathListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;

public class DeathCords extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final HudElement pos = new HudElement(this, 300, 4);

    private boolean defaulted = false;

    private int deathX = 0;

    private int deathY = 0;

    private int deathZ = 0;

    private String deathDim = "Overworld";

    private boolean hasDeath = false;

    public DeathCords() {
        super("DeathCords", Category.NON_HACK);
        setDescription("Saves and displays coordinates where you last died");
        pos.addSettings();
        handles(HandlerType.DEATH, HandlerType.GUI_RENDER);
    }

    @Override
    public void onDeath() {
        if (mc.player == null)
            return;
        deathX = (int) mc.player.posX;
        deathY = (int) mc.player.posY;
        deathZ = (int) mc.player.posZ;
        int dimId = mc.player.dimension;
        if (dimId == -1) {
            deathDim = "Nether";
        } else if (dimId == 1) {
            deathDim = "End";
        } else {
            deathDim = "Overworld";
        }
        hasDeath = true;
    }

    @Override
    public void onGUIRender() {
        if (!hasDeath)
            return;
        if (!nullCheck())
            return;
        if (!pos.shouldRender())
            return;
        String line1 = "Death: " + deathX + ", " + deathY + ", " + deathZ;
        String line2 = "Dim: " + deathDim;
        int boxW = Math.max(ClientFontRenderer.getStringWidth(line1), ClientFontRenderer.getStringWidth(line2)) + 16;
        int boxH = 30;
        pos.updateDrag(boxW, boxH);
        int x = pos.getX();
        int y = pos.getY();
        if (!defaulted) {
            defaulted = true;
            ScaledResolution sr = mc.scaledResolution;
            if (sr == null)
                sr = new ScaledResolution(mc);
            pos.getPosX().setValue((double) (sr.getScaledWidth() - boxW - 4));
            pos.getPosY().setValue((double) 4);
            x = pos.getX();
            y = pos.getY();
        }
        RenderUtils.drawHudPanel(x, y, boxW, boxH, 0.7f);
        ClientFontRenderer.drawStringWithShadow(line1, x + 8, y + (boxH - ClientFontRenderer.fontHeight()) / 2 - 7, 0xFFAAAAAA);
        ClientFontRenderer.drawStringWithShadow(line2, x + 8, y + (boxH - ClientFontRenderer.fontHeight()) / 2 + 7, 0xFFAAAAAA);
        pos.renderDragBox(x, y, boxW, boxH);
    }
}
