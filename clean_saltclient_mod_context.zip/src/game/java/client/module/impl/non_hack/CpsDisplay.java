package client.module.impl.non_hack;

import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import client.event.listeners.LeftClickListener;
import client.event.listeners.RightClickListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.ClickRateTracker;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;

public class CpsDisplay extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final HudElement pos = new HudElement(this, 12, 112);

    private final ClickRateTracker leftTracker = new ClickRateTracker();

    private final ClickRateTracker rightTracker = new ClickRateTracker();

    public CpsDisplay() {
        super("CpsDisplay", Category.NON_HACK);
        setDescription("Shows your clicks per second on the hud");
        pos.addSettings();
        handles(HandlerType.LEFT_CLICK, HandlerType.RIGHT_CLICK, HandlerType.GUI_RENDER);
    }

    @Override
    public void onLeftClick(LeftClickListener.LeftClickEvent event) {
        leftTracker.recordClick();
    }

    @Override
    public void onRightClick(RightClickListener.RightClickEvent event) {
        rightTracker.recordClick();
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (!pos.shouldRender())
            return;
        int lCps = leftTracker.getCPS();
        int rCps = rightTracker.getCPS();
        int boxW = 120;
        int boxH = 28;
        pos.updateDrag(boxW, boxH);
        int x = pos.getX();
        int y = pos.getY();
        RenderUtils.drawHudPanel(x, y, boxW, boxH, 0.7f);
        ClientFontRenderer.drawStringWithShadow("LMB: " + lCps + " CPS", x + 6, y + (boxH - ClientFontRenderer.fontHeight()) / 2 - 7, 0xFFAAAAAA);
        ClientFontRenderer.drawStringWithShadow("RMB: " + rCps + " CPS", x + 6, y + (boxH - ClientFontRenderer.fontHeight()) / 2 + 7, 0xFFAAAAAA);
        pos.renderDragBox(x, y, boxW, boxH);
    }
}
