package client.module.impl.non_hack;

import net.lax1dude.eaglercraft.EaglercraftUUID;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;

public class FPSPingHud extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final HudElement pos = new HudElement(this, -1, -1);

    public FPSPingHud() {
        super("FPSPingHud", Category.NON_HACK);
        setDescription("Shows your fps and server ping");
        pos.addSettings();
        handles(HandlerType.GUI_RENDER);
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (!pos.shouldRender())
            return;
        int fps = Minecraft.getDebugFPS();
        int ping = getPing();
        int lineH = ClientFontRenderer.fontHeight() + 2;
        int boxW = 100;
        int boxH = lineH * 2 + 8;
        pos.updateDrag(boxW, boxH);
        int x = pos.getX();
        int y = pos.getY();
        RenderUtils.drawHudPanel(x, y, boxW, boxH, 0.7f);
        int offsetY = y + 4;
        int fpsColor = fps >= 60 ? 0xFF55FF55 : (fps >= 30 ? 0xFFFFFF55 : 0xFFFF5555);
        ClientFontRenderer.drawStringWithShadow("FPS: " + fps, x + 4, offsetY, fpsColor);
        offsetY += lineH;
        int pingColor = ping >= 0 ? (ping < 50 ? 0xFF55FF55 : (ping < 100 ? 0xFFFFFF55 : 0xFFFF5555)) : 0xFFAAAAAA;
        ClientFontRenderer.drawStringWithShadow("Ping: " + (ping >= 0 ? ping + "ms" : "N/A"), x + 4, offsetY, pingColor);
        pos.renderDragBox(x, y, boxW, boxH);
    }

    private int getPing() {
        if (mc.player == null || mc.getConnection() == null)
            return -1;
        try {
            EaglercraftUUID uuid = mc.player.getUniqueID();
            NetworkPlayerInfo info = mc.getConnection().getPlayerInfo(uuid);
            if (info != null) {
                return info.getResponseTime();
            }
        } catch (Exception e) {
        }
        return -1;
    }
}
