package client.module.impl.non_hack;

import net.minecraft.client.Minecraft;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;

public class CoordsHud extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final HudElement pos = new HudElement(this, -1, -1);

    public CoordsHud() {
        super("CoordsHud", Category.NON_HACK);
        setDescription("Shows your coordinates with overworld/nether conversion");
        pos.addSettings();
        handles(HandlerType.GUI_RENDER);
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (!pos.shouldRender())
            return;
        int dim = mc.world.provider.getDimensionType().getId();
        double px = mc.player.posX;
        double py = mc.player.posY;
        double pz = mc.player.posZ;
        int lines;
        if (dim == 0 || dim == -1) {
            lines = 3;
        } else {
            lines = 1;
        }
        int lineH = ClientFontRenderer.fontHeight() + 2;
        int boxW = 140;
        int boxH = lines * lineH + 8;
        pos.updateDrag(boxW, boxH);
        int x = pos.getX();
        int y = pos.getY();
        RenderUtils.drawHudPanel(x, y, boxW, boxH, 0.7f);
        int offsetY = y + 4;
        String coords = String.format("%.1f / %.1f / %.1f", px, py, pz);
        ClientFontRenderer.drawStringWithShadow(coords, x + 4, offsetY, 0xFFAAAAAA);
        offsetY += lineH;
        if (dim == 0) {
            String nether = String.format("Nether: %.1f / %.1f", px / 8.0, pz / 8.0);
            ClientFontRenderer.drawStringWithShadow(nether, x + 4, offsetY, 0xFF555555);
        } else if (dim == -1) {
            String overworld = String.format("Overworld: %.1f / %.1f", px * 8.0, pz * 8.0);
            ClientFontRenderer.drawStringWithShadow(overworld, x + 4, offsetY, 0xFF55AAFF);
        }
        pos.renderDragBox(x, y, boxW, boxH);
    }
}
