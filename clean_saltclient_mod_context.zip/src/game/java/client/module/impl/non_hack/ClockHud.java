package client.module.impl.non_hack;

import java.util.Calendar;
import org.teavm.jso.JSBody;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.ModeSetting;
import client.module.Module;
import client.module.HandlerType;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;

public class ClockHud extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final HudElement pos = new HudElement(this, -1, -1);

    private final ModeSetting dateFormat = new ModeSetting("Date Format", "M/D/Y", "None", "M/D/Y", "D/M/Y");

    private final ModeSetting timeFormat = new ModeSetting("Time Format", "24-hour", "None", "12-hour", "24-hour");

    private final BooleanSetting showTimezone = new BooleanSetting("Show Timezone", true);

    public ClockHud() {
        super("ClockHud", Category.NON_HACK);
        setDescription("Shows current date and/or time on the HUD");
        addSetting(dateFormat);
        addSetting(timeFormat);
        addSetting(showTimezone);
        pos.addSettings();
        handles(HandlerType.GUI_RENDER);
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (!pos.shouldRender())
            return;
        long second = System.currentTimeMillis() / 1000L;
        if (second != cachedSecond) {
            cachedSecond = second;
            rebuildLines();
        }
        java.util.List<String> lines = cachedLines;
        int lineH = ClientFontRenderer.fontHeight() + 2;
        int maxW = 0;
        for (String line : lines) {
            int w = ClientFontRenderer.getStringWidth(line);
            if (w > maxW)
                maxW = w;
        }
        int boxW = maxW + 8;
        int boxH = lineH * lines.size() + 6;
        pos.updateDrag(boxW, boxH);
        int x = pos.getX();
        int y = pos.getY();
        if (pos.isDefaultX()) {
            net.minecraft.client.gui.ScaledResolution sr = mc.scaledResolution;
            if (sr == null)
                sr = new net.minecraft.client.gui.ScaledResolution(mc);
            x = sr.getScaledWidth() - boxW - 5;
            pos.getPosX().setValue((double) x);
        }
        RenderUtils.drawHudPanel(x, y, boxW, boxH, 0.7f);
        int offsetY = y + 3;
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            int color;
            if (i == 0 && !dateFormat.getValue().equals("None")) {
                color = 0xFFCCCCCC;
            } else if (i == lines.size() - 1 && showTimezone.getValue()) {
                color = 0xFF888888;
            } else {
                color = 0xFFDDDDDD;
            }
            ClientFontRenderer.drawStringWithShadow(line, x + 4, offsetY, color);
            offsetY += lineH;
        }
        pos.renderDragBox(x, y, boxW, boxH);
    }

    private final java.util.List<String> cachedLines = new java.util.ArrayList<String>();

    private long cachedSecond = -1;

    private void rebuildLines() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        int hour24 = cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);
        cachedLines.clear();
        String dateMode = dateFormat.getValue();
        if (!dateMode.equals("None")) {
            String dateStr;
            if (dateMode.equals("M/D/Y")) {
                dateStr = month + "/" + day + "/" + year;
            } else {
                dateStr = day + "/" + month + "/" + year;
            }
            cachedLines.add(dateStr);
        }
        String timeMode = timeFormat.getValue();
        if (!timeMode.equals("None")) {
            String timeStr;
            if (timeMode.equals("12-hour")) {
                int hour12 = hour24 % 12;
                if (hour12 == 0)
                    hour12 = 12;
                String ampm = hour24 < 12 ? "AM" : "PM";
                timeStr = String.format("%d:%02d %s", hour12, minute, ampm);
            } else {
                timeStr = String.format("%d:%02d", hour24, minute);
            }
            cachedLines.add(timeStr);
        }
        if (showTimezone.getValue()) {
            cachedLines.add(getTimezoneString());
        }
        if (cachedLines.isEmpty()) {
            cachedLines.add(String.format("%d:%02d", hour24, minute));
        }
    }

    private static String getTimezoneString() {
        int offsetMinutes = -getTimezoneOffsetMinutes();
        if (offsetMinutes == 0)
            return "UTC+00:00";
        String sign = offsetMinutes > 0 ? "+" : "-";
        int absMinutes = Math.abs(offsetMinutes);
        int hours = absMinutes / 60;
        int mins = absMinutes % 60;
        return String.format("UTC%s%02d:%02d", sign, hours, mins);
    }

    @JSBody(script = "return new Date().getTimezoneOffset();")
    private static native int getTimezoneOffsetMinutes();
}
