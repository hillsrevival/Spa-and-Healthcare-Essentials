package client.module.impl.non_hack;

import java.util.Collection;
import net.minecraft.client.Minecraft;
import net.minecraft.potion.PotionEffect;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;

public class PotionHud extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final HudElement pos = new HudElement(this, -1, -1);

    public PotionHud() {
        super("PotionHud", Category.NON_HACK);
        setDescription("Shows your active potion effects with duration");
        pos.addSettings();
        handles(HandlerType.GUI_RENDER);
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (!pos.shouldRender())
            return;
        Collection<PotionEffect> effects = mc.player.getActivePotionEffects();
        if (effects.isEmpty())
            return;
        int lineH = ClientFontRenderer.fontHeight() + 2;
        int boxW = 120;
        int boxH = effects.size() * lineH + 8;
        pos.updateDrag(boxW, boxH);
        int x = pos.getX();
        int y = pos.getY();
        RenderUtils.drawHudPanel(x, y, boxW, boxH, 0.7f);
        int offsetY = y + 4;
        for (PotionEffect effect : effects) {
            String name = effect.getPotion().getName();
            int amp = effect.getAmplifier();
            if (amp > 0) {
                name += " " + toRoman(amp + 1);
            }
            int duration = effect.getDuration();
            String time;
            if (duration > 32767) {
                time = "**:**";
            } else {
                int sec = duration / 20;
                int min = sec / 60;
                sec = sec % 60;
                time = String.format("%d:%02d", min, sec);
            }
            int potionColor = effect.getPotion().getLiquidColor() | 0xFF000000;
            ClientFontRenderer.drawStringWithShadow(name, x + 4, offsetY, potionColor);
            ClientFontRenderer.drawRightAlignedStringWithShadow(time, x + boxW - 4, offsetY, 0xFFAAAAAA);
            offsetY += lineH;
        }
        pos.renderDragBox(x, y, boxW, boxH);
    }

    private static String toRoman(int num) {
        switch(num) {
            case 1:
                return "I";
            case 2:
                return "II";
            case 3:
                return "III";
            case 4:
                return "IV";
            case 5:
                return "V";
            default:
                return num + "";
        }
    }
}
