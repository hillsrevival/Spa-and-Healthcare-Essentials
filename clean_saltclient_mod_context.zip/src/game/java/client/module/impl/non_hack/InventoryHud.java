package client.module.impl.non_hack;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.item.ItemStack;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.minecraft.client.renderer.Tessellator;
import net.lax1dude.eaglercraft.opengl.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.render.HudElement;
import client.utils.render.ClientFontRenderer;

public class InventoryHud extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting scale = new NumberSetting("Scale", 1.0, 0.5, 2.0);

    private final BooleanSetting showCount = new BooleanSetting("ShowCount", true);

    private final HudElement pos = new HudElement(this, -1, -1);

    private static final int SLOT_SIZE = 18;

    private static final int ROWS = 3;

    private static final int COLS = 9;

    private static final int START_SLOT = 9;

    public InventoryHud() {
        super("InventoryHud", Category.NON_HACK);
        setDescription("Shows your inventory contents on the hud");
        addSetting(scale);
        addSetting(showCount);
        handles(HandlerType.GUI_RENDER);
        pos.addSettings();
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (!pos.shouldRender())
            return;
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        float scaleFactor = scale.getValue().floatValue();
        RenderItem ri = mc.getRenderItem();
        int slotSize = (int) (SLOT_SIZE * scaleFactor);
        int padding = Math.max(1, (int) (2 * scaleFactor));
        int gap = Math.max(1, (int) (2 * scaleFactor));
        int gridW = COLS * slotSize + (COLS - 1) * gap + padding * 2;
        int gridH = ROWS * slotSize + (ROWS - 1) * gap + padding * 2;
        pos.updateDrag(gridW, gridH);
        int x, y;
        if (pos.isDefaultX()) {
            x = (sr.getScaledWidth() - gridW) / 2;
        } else {
            x = pos.getX();
        }
        if (pos.isDefaultY()) {
            y = sr.getScaledHeight() - gridH - 52;
        } else {
            y = pos.getY();
        }
        drawRect(x, y, x + gridW, y + gridH, 0xC0101010);
        drawRect(x, y, x + gridW, y + 1, 0xFF444444);
        drawRect(x, y + gridH - 1, x + gridW, y + gridH, 0xFF444444);
        drawRect(x, y, x + 1, y + gridH, 0xFF444444);
        drawRect(x + gridW - 1, y, x + gridW, y + gridH, 0xFF444444);
        GlStateManager.enableBlend();
        GlStateManager.enableDepth();
        GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                int slotIndex = START_SLOT + row * COLS + col;
                ItemStack stack = mc.player.inventory.mainInventory.get(slotIndex);
                int slotX = x + padding + col * (slotSize + gap);
                int slotY = y + padding + row * (slotSize + gap);
                boolean empty = stack.func_190926_b();
                drawRect(slotX, slotY, slotX + slotSize, slotY + slotSize, empty ? 0x60111111 : 0x40202020);
                if (!empty) {
                    GlStateManager.pushMatrix();
                    float itemScale = slotSize / 16.0f;
                    int centeredX = slotX + (slotSize - (int) (16 * itemScale)) / 2;
                    int centeredY = slotY + (slotSize - (int) (16 * itemScale)) / 2;
                    ri.renderItemAndEffectIntoGUI(stack, centeredX, centeredY);
                    GlStateManager.popMatrix();
                    if (showCount.getValue() && stack.func_190916_E() > 1) {
                        String count = String.valueOf(stack.func_190916_E());
                        if (scaleFactor < 0.8f) {
                            ClientFontRenderer.drawRightAlignedString(count, slotX + slotSize - 1, slotY + slotSize - ClientFontRenderer.fontHeight(), 0xFFFFFF);
                        } else {
                            ClientFontRenderer.drawRightAlignedStringWithShadow(count, slotX + slotSize - 1, slotY + slotSize - ClientFontRenderer.fontHeight(), 0xFFFFFF);
                        }
                    }
                }
            }
        }
        GlStateManager.disableDepth();
        GlStateManager.disableBlend();
        pos.renderDragBox(x, y, gridW, gridH);
    }

    private void drawRect(int left, int top, int right, int bottom, int color) {
        int a = (color >> 24) & 0xFF;
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        GlStateManager.disableTexture2D();
        GlStateManager.color(r / 255.0f, g / 255.0f, b / 255.0f, a / 255.0f);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        buf.begin(RealOpenGLEnums.GL_QUADS, DefaultVertexFormats.POSITION);
        buf.pos(right, top, 0.0).endVertex();
        buf.pos(left, top, 0.0).endVertex();
        buf.pos(left, bottom, 0.0).endVertex();
        buf.pos(right, bottom, 0.0).endVertex();
        tess.draw();
        GlStateManager.enableTexture2D();
    }
}
