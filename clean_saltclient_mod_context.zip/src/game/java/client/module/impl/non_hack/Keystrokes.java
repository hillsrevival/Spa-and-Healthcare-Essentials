package client.module.impl.non_hack;

import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.settings.GameSettings;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.ModeSetting;
import client.module.Module;
import client.module.HandlerType;
import client.module.ColorSetting;
import client.module.NumberSetting;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;

public class Keystrokes extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting rounded = new BooleanSetting("Rounded", true);

    private final ModeSetting colorMode = new ModeSetting("Color", "Default", "Default", "Red", "Green", "Blue", "Yellow", "Purple", "Pink", "Orange", "White", "Cyan", "Rainbow", "Custom");

    private final NumberSetting opacity = new NumberSetting("Opacity", 0.6, 0.1, 1.0);

    private final ColorSetting customColor = new ColorSetting("Custom Color", 120.0);

    private final HudElement pos = new HudElement(this, 12, 12);

    public Keystrokes() {
        super("Keystrokes", Category.NON_HACK);
        setDescription("Displays your key presses on screen");
        addSetting(rounded);
        addSetting(colorMode);
        addSetting(opacity);
        addSetting(customColor);
        handles(HandlerType.GUI_RENDER);
        pos.addSettings();
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (!pos.shouldRender())
            return;
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        GameSettings gs = mc.gameSettings;
        boolean wDown = gs.keyBindForward.isKeyDown();
        boolean aDown = gs.keyBindLeft.isKeyDown();
        boolean sDown = gs.keyBindBack.isKeyDown();
        boolean dDown = gs.keyBindRight.isKeyDown();
        boolean spaceDown = gs.keyBindJump.isKeyDown();
        int keySize = 38;
        int gap = 3;
        int fullWidth = keySize * 3 + gap * 2;
        int spaceWidth = fullWidth;
        int totalH = keySize * 2 + gap * 2 + 14;
        pos.updateDrag(fullWidth, totalH);
        int baseX = pos.getX();
        int baseY = pos.getY();
        float alpha = opacity.getValue().floatValue();
        boolean useRounded = rounded.getValue();
        int rad = useRounded ? 6 : 0;
        float[] restColor = resolveRestColor();
        float[] pressColor = resolvePressColor(restColor);
        int wx = baseX + keySize + gap;
        int wy = baseY;
        drawKeyBg(wx, wy, keySize, keySize, rad, wDown, restColor, pressColor, alpha);
        int rowY = baseY + keySize + gap;
        drawKeyBg(baseX, rowY, keySize, keySize, rad, aDown, restColor, pressColor, alpha);
        drawKeyBg(baseX + keySize + gap, rowY, keySize, keySize, rad, sDown, restColor, pressColor, alpha);
        drawKeyBg(baseX + keySize * 2 + gap * 2, rowY, keySize, keySize, rad, dDown, restColor, pressColor, alpha);
        int spY = rowY + keySize + gap;
        drawKeyBg(baseX, spY, spaceWidth, 14, useRounded ? 4 : 0, spaceDown, restColor, pressColor, alpha);
        int textColor;
        if (colorMode.getValue().equals("Rainbow")) {
            float hue = (System.currentTimeMillis() % 3000L) / 3000.0f;
            float[] rc = hsbToRgb(hue, 0.3f, 1.0f);
            textColor = 0xFF000000 | ((int) (rc[0] * 255) << 16) | ((int) (rc[1] * 255) << 8) | (int) (rc[2] * 255);
        } else {
            textColor = 0xFFCCCCCC;
        }
        drawKeyLabel(wx, wy, keySize, keySize, wDown, "W", textColor);
        drawKeyLabel(baseX, rowY, keySize, keySize, aDown, "A", textColor);
        drawKeyLabel(baseX + keySize + gap, rowY, keySize, keySize, sDown, "S", textColor);
        drawKeyLabel(baseX + keySize * 2 + gap * 2, rowY, keySize, keySize, dDown, "D", textColor);
        drawKeyLabel(baseX, spY, spaceWidth, 14, spaceDown, "", textColor);
        pos.renderDragBox(baseX, baseY, fullWidth, totalH);
    }

    private float[] resolveRestColor() {
        String mode = colorMode.getValue();
        if (mode.equals("Default")) {
            return new float[] { 40 / 255f, 40 / 255f, 60 / 255f };
        }
        if (mode.equals("Rainbow")) {
            float hue = (System.currentTimeMillis() % 5000L) / 5000.0f;
            return hsbToRgb(hue, 0.6f, 0.25f);
        }
        float[] c = getSolidColor(mode);
        return new float[] { c[0] * 0.25f, c[1] * 0.25f, c[2] * 0.25f };
    }

    private float[] resolvePressColor(float[] restColor) {
        String mode = colorMode.getValue();
        if (mode.equals("Default")) {
            return new float[] { 80 / 255f, 80 / 255f, 120 / 255f };
        }
        if (mode.equals("Rainbow")) {
            float hue = (System.currentTimeMillis() % 5000L) / 5000.0f;
            return hsbToRgb(hue, 0.8f, 0.7f);
        }
        float[] c = getSolidColor(mode);
        return new float[] { c[0] * 0.6f, c[1] * 0.6f, c[2] * 0.6f };
    }

    private float[] getSolidColor(String mode) {
        switch(mode) {
            case "Red":
                return new float[] { 1, 0, 0 };
            case "Green":
                return new float[] { 0, 1, 0 };
            case "Blue":
                return new float[] { 0, 0.4f, 1 };
            case "Yellow":
                return new float[] { 1, 1, 0 };
            case "Purple":
                return new float[] { 0.6f, 0.2f, 1 };
            case "Pink":
                return new float[] { 1, 0.4f, 0.7f };
            case "Orange":
                return new float[] { 1, 0.5f, 0 };
            case "White":
                return new float[] { 1, 1, 1 };
            case "Cyan":
                return new float[] { 0, 1, 1 };
            case "Custom":
                return customColor.getRGBFloat();
            default:
                return new float[] { 1, 1, 1 };
        }
    }

    private float[] hsbToRgb(float h, float s, float b) {
        int i = (int) (h * 6.0f);
        float f = h * 6.0f - i;
        float p = b * (1.0f - s);
        float q = b * (1.0f - f * s);
        float t = b * (1.0f - (1.0f - f) * s);
        switch(i % 6) {
            case 0:
                return new float[] { b, t, p };
            case 1:
                return new float[] { q, b, p };
            case 2:
                return new float[] { p, b, t };
            case 3:
                return new float[] { p, q, b };
            case 4:
                return new float[] { t, p, b };
            case 5:
                return new float[] { b, p, q };
            default:
                return new float[] { 1, 1, 1 };
        }
    }

    private void drawKeyBg(int x, int y, int w, int h, int rad, boolean pressed, float[] restColor, float[] pressColor, float alpha) {
        float[] c = pressed ? pressColor : restColor;
        int argb = packColor(c[0], c[1], c[2], alpha);
        if (rad > 0) {
            RenderUtils.drawRoundedRect2D(x, y, x + w, y + h, rad, argb);
        } else {
            RenderUtils.drawRect2D(x, y, x + w, y + h, argb);
        }
        float ba = alpha * (pressed ? 0.7f : 0.4f);
        float bcr = Math.min(c[0] + 0.15f, 1.0f);
        float bcg = Math.min(c[1] + 0.15f, 1.0f);
        float bcb = Math.min(c[2] + 0.15f, 1.0f);
        int borderArgb = packColor(bcr, bcg, bcb, ba);
        if (rad > 0) {
            RenderUtils.drawRoundedStroke2D(x, y, x + w, y + h, rad, 1.5f, borderArgb);
        } else {
            RenderUtils.drawRect2D(x, y, x + w, y + 1, borderArgb);
            RenderUtils.drawRect2D(x, y + h - 1, x + w, y + h, borderArgb);
            RenderUtils.drawRect2D(x, y, x + 1, y + h, borderArgb);
            RenderUtils.drawRect2D(x + w - 1, y, x + w, y + h, borderArgb);
        }
    }

    private int packColor(float r, float g, float b, float a) {
        return ((int) (a * 255) << 24) | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    private void drawKeyLabel(int x, int y, int w, int h, boolean pressed, String label, int baseColor) {
        if (label.isEmpty())
            return;
        int labelX = x + w / 2;
        int labelY = y + (h - ClientFontRenderer.fontHeight()) / 2;
        if (pressed) {
            ClientFontRenderer.drawCenteredStringWithShadow(label, labelX, labelY, 0xFFFFFFFF);
        } else {
            ClientFontRenderer.drawCenteredStringWithShadow(label, labelX, labelY, baseColor);
        }
    }
}
