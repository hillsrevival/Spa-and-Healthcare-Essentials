package client.module.impl.non_hack;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.item.ItemStack;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.minecraft.client.renderer.Tessellator;
import net.lax1dude.eaglercraft.opengl.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.render.HudElement;
import client.utils.render.ClientFontRenderer;

public class ArmorHud extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting scale = new NumberSetting("Scale", 1.0, 0.5, 2.0);

    private final BooleanSetting percentage = new BooleanSetting("Percentage", false);

    private final HudElement pos = new HudElement(this, -1, -1);

    private static final int SLOT_SIZE = 18;

    private static final int ARMOR_SLOTS = 4;

    public ArmorHud() {
        super("ArmorHud", Category.NON_HACK);
        setDescription("Shows your equipped armor with durability bars");
        addSetting(scale);
        addSetting(percentage);
        handles(HandlerType.GUI_RENDER);
        pos.addSettings();
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (!pos.shouldRender())
            return;
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        float scaleFactor = scale.getValue().floatValue();
        RenderItem ri = mc.getRenderItem();
        int slotSize = (int) (SLOT_SIZE * scaleFactor);
        int padding = Math.max(1, (int) (2 * scaleFactor));
        int gap = Math.max(1, (int) (2 * scaleFactor));
        int gridW = slotSize + padding * 2;
        int gridH = ARMOR_SLOTS * slotSize + (ARMOR_SLOTS - 1) * gap + padding * 2;
        pos.updateDrag(gridW, gridH);
        int x, y;
        if (pos.isDefaultX()) {
            x = sr.getScaledWidth() - gridW - 5;
        } else {
            x = pos.getX();
        }
        if (pos.isDefaultY()) {
            y = (sr.getScaledHeight() - gridH) / 2;
        } else {
            y = pos.getY();
        }
        drawRect(x, y, x + gridW, y + gridH, 0xC0101010);
        drawRect(x, y, x + gridW, y + 1, 0xFF444444);
        drawRect(x, y + gridH - 1, x + gridW, y + gridH, 0xFF444444);
        drawRect(x, y, x + 1, y + gridH, 0xFF444444);
        drawRect(x + gridW - 1, y, x + gridW, y + gridH, 0xFF444444);
        GlStateManager.enableBlend();
        GlStateManager.enableDepth();
        GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
        for (int i = 3; i >= 0; i--) {
            ItemStack stack = mc.player.inventory.armorInventory.get(i);
            int row = 3 - i;
            int slotX = x + padding;
            int slotY = y + padding + row * (slotSize + gap);
            boolean empty = stack.func_190926_b();
            drawRect(slotX, slotY, slotX + slotSize, slotY + slotSize, empty ? 0x60111111 : 0x40202020);
            if (!empty) {
                GlStateManager.pushMatrix();
                ri.renderItemAndEffectIntoGUI(stack, slotX, slotY);
                GlStateManager.popMatrix();
                if (stack.getItem().isDamageable()) {
                    float dur = (float) (stack.getMaxDamage() - stack.getItemDamage()) / stack.getMaxDamage();
                    int barY = slotY + slotSize - 2;
                    int barW = (int) (slotSize * dur);
                    int red, green;
                    if (dur > 0.5f) {
                        red = (int) (510 * (1.0f - dur));
                        green = 255;
                    } else {
                        red = 255;
                        green = (int) (510 * dur);
                    }
                    int durColor = (red << 16) | (green << 8);
                    drawRect(slotX, barY, slotX + slotSize, barY + 2, 0xFF000000);
                    if (barW > 0) {
                        drawRect(slotX, barY, slotX + barW, barY + 2, durColor | 0xFF000000);
                    }
                    if (percentage.getValue()) {
                        int pct = (int) (dur * 100);
                        String pctStr = pct + "%";
                        int textY = slotY + 1;
                        ClientFontRenderer.drawStringWithShadow(pctStr, slotX + 1, textY, durColor | 0xFF000000);
                    }
                }
            }
        }
        GlStateManager.disableDepth();
        GlStateManager.disableBlend();
        pos.renderDragBox(x, y, gridW, gridH);
    }

    private void drawRect(int left, int top, int right, int bottom, int color) {
        int a = (color >> 24) & 0xFF;
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        GlStateManager.disableTexture2D();
        GlStateManager.color(r / 255.0f, g / 255.0f, b / 255.0f, a / 255.0f);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer buf = tess.getBuffer();
        buf.begin(RealOpenGLEnums.GL_QUADS, DefaultVertexFormats.POSITION);
        buf.pos(right, top, 0.0).endVertex();
        buf.pos(left, top, 0.0).endVertex();
        buf.pos(left, bottom, 0.0).endVertex();
        buf.pos(right, bottom, 0.0).endVertex();
        tess.draw();
        GlStateManager.enableTexture2D();
    }
}
