package client.module.impl.non_hack;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import client.config.AutoLoginConfig;
import client.event.events.PacketInputEvent;
import client.event.listeners.ChatOutputListener.ChatOutputEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;

public class AutoLogin extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final AutoLoginConfig config = new AutoLoginConfig();

    private static final int STATE_IDLE = 0;

    private static final int STATE_CAPTURING = 1;

    private static final int STATE_VERIFYING = 2;

    private static final int STATE_AUTO_LOGINED = 3;

    private static final int STATE_COOLDOWN = 4;

    private int state = STATE_IDLE;

    private long stateTimer = 0L;

    private String pendingPassword = null;

    private String currentServerUrl = null;

    private boolean wasAutoLogin = false;

    private static final long VERIFY_MS = 4000L;

    private static final long KICK_CHECK_MS = 2000L;

    private static final long COOLDOWN_MS = 1500L;

    private static final long JOIN_DELAY_MS = 1000L;

    private static final long SEND_MIN_INTERVAL_MS = 1000L;

    private static final int MAX_SENDS_PER_JOIN = 4;

    private static long lastSendTime = 0L;

    private long joinTime = 0L;

    private boolean sentAutoLogin = false;

    private int sendsUsed = 0;

    private boolean wasConnected = false;

    public AutoLogin() {
        super("AutoLogin", Category.NON_HACK);
        setDescription("Auto logs in for servers that have /login");
        handles(HandlerType.UPDATE, HandlerType.PACKET_INPUT, HandlerType.CHAT_OUTPUT, HandlerType.CHAT_INPUT);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        config.load();
        resetState();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        resetState();
    }

    @Override
    public void onUpdate() {
        boolean connected = (mc.player != null && mc.world != null);
        if (wasConnected && !connected) {
            handleDisconnect();
        }
        wasConnected = connected;
        if (!connected) {
            if (state != STATE_IDLE)
                resetState();
            return;
        }
        ServerData sd = mc.getCurrentServerData();
        if (sd == null)
            return;
        String url = toServerId(sd.serverIP);
        if (url == null || url.isEmpty())
            return;
        if (!url.equals(currentServerUrl)) {
            resetState();
            currentServerUrl = url;
            joinTime = System.currentTimeMillis();
            sentAutoLogin = false;
            sendsUsed = 0;
            if (!config.has(url)) {
                state = STATE_CAPTURING;
            }
        }
        long now = System.currentTimeMillis();
        switch(state) {
            case STATE_IDLE:
                if (!sentAutoLogin && config.has(currentServerUrl) && now - joinTime > JOIN_DELAY_MS) {
                    trySendLogin();
                }
                break;
            case STATE_CAPTURING:
                break;
            case STATE_VERIFYING:
                if (now - stateTimer >= VERIFY_MS) {
                    config.put(currentServerUrl, pendingPassword);
                    pendingPassword = null;
                    state = STATE_IDLE;
                }
                break;
            case STATE_AUTO_LOGINED:
                if (now - stateTimer >= 1000L * sendsUsed && sendsUsed < MAX_SENDS_PER_JOIN) {
                    trySendLogin();
                    break;
                }
                if (now - stateTimer >= KICK_CHECK_MS + 1000L * sendsUsed) {
                    state = STATE_IDLE;
                    wasAutoLogin = false;
                }
                break;
            case STATE_COOLDOWN:
                if (now - stateTimer >= COOLDOWN_MS) {
                    state = STATE_IDLE;
                    wasAutoLogin = false;
                }
                break;
        }
    }

    private void handleDisconnect() {
        if (wasAutoLogin && state == STATE_AUTO_LOGINED) {
            if (currentServerUrl != null) {
                config.remove(currentServerUrl);
            }
        }
        if (state == STATE_VERIFYING) {
            pendingPassword = null;
        }
        resetState();
        currentServerUrl = null;
    }

    @Override
    public void onPacketInput(PacketInputEvent event) {
        if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketDisconnect) {
            handleDisconnect();
            return;
        }
        if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketJoinGame) {
            ServerData sd = mc.getCurrentServerData();
            if (sd != null) {
                String url = toServerId(sd.serverIP);
                if (url != null && !url.equals(currentServerUrl)) {
                    resetState();
                    currentServerUrl = url;
                    joinTime = System.currentTimeMillis();
                    sentAutoLogin = false;
                    if (!config.has(url)) {
                        state = STATE_CAPTURING;
                    }
                } else if (url != null && url.equals(currentServerUrl)) {
                    joinTime = System.currentTimeMillis();
                    sentAutoLogin = false;
                    if (!config.has(url)) {
                        state = STATE_CAPTURING;
                    }
                }
            }
        }
    }

    @Override
    public void onChatOutput(ChatOutputEvent event) {
        if (event.isAutomatic())
            return;
        String msg = event.getMessage();
        if (msg == null)
            return;
        String lower = msg.toLowerCase().trim();
        if (lower.startsWith("/login ") || lower.startsWith("/l ")) {
            if (state == STATE_AUTO_LOGINED)
                return;
            String pw = extractPassword(msg);
            if (pw != null && !pw.isEmpty() && currentServerUrl != null) {
                pendingPassword = pw;
                state = STATE_VERIFYING;
                stateTimer = System.currentTimeMillis();
                wasAutoLogin = false;
            }
        }
    }

    private void trySendLogin() {
        if (mc.player == null || currentServerUrl == null)
            return;
        String pw = config.get(currentServerUrl);
        if (pw == null)
            return;
        long now = System.currentTimeMillis();
        if (now - lastSendTime < SEND_MIN_INTERVAL_MS)
            return;
        if (sendsUsed >= MAX_SENDS_PER_JOIN)
            return;
        try {
            mc.player.sendChatMessage("/login " + pw, true);
            lastSendTime = now;
            sendsUsed++;
            sentAutoLogin = true;
            wasAutoLogin = true;
            state = STATE_AUTO_LOGINED;
            stateTimer = now;
        } catch (Throwable t) {
        }
    }

    @Override
    public void onChatInput(client.event.listeners.ChatInputListener.ChatInputEvent event) {
        if (event.getComponent() == null)
            return;
        String text = event.getComponent().getUnformattedText();
        if (text == null)
            return;
        if (isLoginFailureMessage(text)) {
            if (state == STATE_AUTO_LOGINED) {
                if (currentServerUrl != null) {
                    config.remove(currentServerUrl);
                }
                state = STATE_COOLDOWN;
                stateTimer = System.currentTimeMillis();
                wasAutoLogin = false;
            } else if (state == STATE_VERIFYING) {
                pendingPassword = null;
                state = STATE_COOLDOWN;
                stateTimer = System.currentTimeMillis();
            }
            return;
        }
        if (isAuthSettledMessage(text)) {
            if (state == STATE_AUTO_LOGINED) {
                state = STATE_IDLE;
                wasAutoLogin = false;
            } else if (state == STATE_VERIFYING && pendingPassword != null && currentServerUrl != null) {
                config.put(currentServerUrl, pendingPassword);
                pendingPassword = null;
                state = STATE_IDLE;
            }
            return;
        }
        if (isLoginPromptMessage(text)) {
            if (state == STATE_IDLE || state == STATE_AUTO_LOGINED) {
                trySendLogin();
            }
        }
    }

    private boolean isLoginPromptMessage(String text) {
        String t = text.toLowerCase();
        return t.contains("please login") || t.contains("please log in") || t.contains("not logged in") || t.contains("must login") || t.contains("must log in") || t.contains("login with") || t.contains("log in with") || t.contains("use /login") || t.contains("/login") || t.contains("login required") || t.contains("register or login") || t.contains("to log in") || t.contains("to login") || t.contains("you are not logged");
    }

    private boolean isAuthSettledMessage(String text) {
        String t = text.toLowerCase();
        if (isLoginPromptMessage(t))
            return false;
        return t.contains("logged in") || t.contains("login successful") || t.contains("successfully logged") || t.contains("login correct") || t.contains("login accepted") || t.contains("welcome back") || t.contains("session continued");
    }

    private boolean isLoginFailureMessage(String text) {
        String t = text.toLowerCase();
        if (t.contains("wrong password") || t.contains("incorrect password") || t.contains("invalid password") || t.contains("login failed") || t.contains("too many attempts") || t.contains("too many logins")) {
            return true;
        }
        return (t.contains("wrong") || t.contains("incorrect") || t.contains("invalid")) && t.contains("password");
    }

    private String extractPassword(String msg) {
        String trimmed = msg.trim();
        int space = -1;
        String lowerTrimmed = trimmed.toLowerCase();
        if (lowerTrimmed.startsWith("/login ")) {
            space = trimmed.indexOf(' ');
        } else if (lowerTrimmed.startsWith("/l ") && !lowerTrimmed.startsWith("/login")) {
            space = trimmed.indexOf(' ');
        }
        if (space < 0 || space >= trimmed.length() - 1)
            return null;
        return trimmed.substring(space + 1).trim();
    }

    private String toServerId(String serverIP) {
        if (serverIP == null)
            return null;
        String s = serverIP.trim().toLowerCase();
        if (s.startsWith("wss://"))
            s = s.substring(6);
        else if (s.startsWith("ws://"))
            s = s.substring(5);
        if (s.endsWith("/"))
            s = s.substring(0, s.length() - 1);
        return s;
    }

    private void resetState() {
        state = STATE_IDLE;
        stateTimer = 0L;
        pendingPassword = null;
        wasAutoLogin = false;
        sentAutoLogin = false;
        sendsUsed = 0;
    }
}
