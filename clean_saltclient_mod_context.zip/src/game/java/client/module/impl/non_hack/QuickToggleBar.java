package client.module.impl.non_hack;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.module.ModuleManager;
import client.utils.render.HudElement;
import client.utils.render.ClientFontRenderer;
import client.utils.misc.NotificationSystem;
import client.event.listeners.KeyPressListener;
import net.lax1dude.eaglercraft.Keyboard;

public class QuickToggleBar extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private static final int NUM_SLOTS = 5;

    private static final int SLOT_WIDTH = 70;

    private static final int SLOT_HEIGHT = 28;

    private static final int SLOT_GAP = 2;

    private static final String[] assignedModules = new String[NUM_SLOTS];

    private final NumberSetting scale = new NumberSetting("Scale", 1.0, 0.5, 2.0);

    private final BooleanSetting showWhenEmpty = new BooleanSetting("Show Empty", false);

    public QuickToggleBar() {
        super("QuickToggleBar", Category.NON_HACK);
        setDescription("5-slot quick toggle bar (press 1-5). Assign with .quickbar <slot> <module>");
        addSetting(scale);
        addSetting(showWhenEmpty);
        handles(HandlerType.GUI_RENDER, HandlerType.KEY_PRESS, HandlerType.TICK);
    }

    public static boolean assignSlot(int slot, String moduleName) {
        if (slot < 0 || slot >= NUM_SLOTS)
            return false;
        if (moduleName == null || moduleName.equals("-") || moduleName.isEmpty()) {
            assignedModules[slot] = null;
            return true;
        }
        Module mod = ModuleManager.getModuleByFuzzyName(moduleName);
        if (mod == null)
            return false;
        assignedModules[slot] = mod.getName();
        return true;
    }

    public static String getAssignedModule(int slot) {
        if (slot < 0 || slot >= NUM_SLOTS)
            return null;
        return assignedModules[slot];
    }

    public static int getNumSlots() {
        return NUM_SLOTS;
    }

    @Override
    public void onKeyPress(KeyPressListener.KeyPressEvent event) {
        if (!nullCheck())
            return;
        if (mc.currentScreen != null)
            return;
        int slot = -1;
        if (event.getKeyCode() >= Keyboard.KEY_1 && event.getKeyCode() <= Keyboard.KEY_5) {
            slot = event.getKeyCode() - Keyboard.KEY_1;
        }
        if (slot < 0 || slot >= NUM_SLOTS)
            return;
        String modName = assignedModules[slot];
        if (modName == null) {
            NotificationSystem.warning("Slot " + (slot + 1) + " is empty. Assign with .quickbar " + (slot + 1) + " <module>");
            return;
        }
        Module mod = ModuleManager.getModuleByFuzzyName(modName);
        if (mod == null) {
            NotificationSystem.error("Module not found: " + modName);
            return;
        }
        mod.toggle();
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        boolean hasAssigned = false;
        for (String s : assignedModules) {
            if (s != null) {
                hasAssigned = true;
                break;
            }
        }
        if (!hasAssigned && !showWhenEmpty.getValue())
            return;
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        float scaleFactor = scale.getValue().floatValue();
        int slotW = (int) (SLOT_WIDTH * scaleFactor);
        int slotH = (int) (SLOT_HEIGHT * scaleFactor);
        int gap = (int) (SLOT_GAP * scaleFactor);
        int totalW = NUM_SLOTS * slotW + (NUM_SLOTS - 1) * gap;
        int barY = sr.getScaledHeight() - slotH - 20;
        int startX = (sr.getScaledWidth() - totalW) / 2;
        for (int i = 0; i < NUM_SLOTS; i++) {
            int slotX = startX + i * (slotW + gap);
            String modName = assignedModules[i];
            boolean isOn = false;
            if (modName != null) {
                Module mod = ModuleManager.getModuleByFuzzyName(modName);
                if (mod != null)
                    isOn = mod.isToggled();
            }
            int bgAlpha = 200;
            int bgColor = modName == null ? (0x404040 | (bgAlpha << 24)) : (isOn ? (0x1A4D1A | (bgAlpha << 24)) : (0x4D1A1A | (bgAlpha << 24)));
            Gui.drawRect(slotX, barY, slotX + slotW, barY + slotH, bgColor);
            int borderColor = modName == null ? 0xFF333333 : (isOn ? 0xFF22CC22 : 0xFFCC2222);
            Gui.drawRect(slotX, barY, slotX + slotW, barY + 1, borderColor);
            Gui.drawRect(slotX, barY + slotH - 1, slotX + slotW, barY + slotH, borderColor);
            Gui.drawRect(slotX, barY, slotX + 1, barY + slotH, borderColor);
            Gui.drawRect(slotX + slotW - 1, barY, slotX + slotW, barY + slotH, borderColor);
            String numStr = String.valueOf(i + 1);
            ClientFontRenderer.drawStringWithShadow(numStr, slotX + 3, barY + 2, 0xFFFFFFAA);
            String displayName = modName == null ? "Empty" : modName;
            if (displayName.length() > 9)
                displayName = displayName.substring(0, 8) + ".";
            int nameWidth = ClientFontRenderer.getStringWidth(displayName);
            ClientFontRenderer.drawStringWithShadow(displayName, slotX + (slotW - nameWidth) / 2, barY + (slotH / 2) - 4, modName == null ? 0xFF888888 : 0xFFFFFFFF);
            String stateStr = modName == null ? "" : (isOn ? "ON" : "OFF");
            int stateColor = modName == null ? 0xFF888888 : (isOn ? 0xFF22CC22 : 0xFFCC2222);
            int stateWidth = ClientFontRenderer.getStringWidth(stateStr);
            ClientFontRenderer.drawStringWithShadow(stateStr, slotX + (slotW - stateWidth) / 2, barY + slotH - 10, stateColor);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }
}
