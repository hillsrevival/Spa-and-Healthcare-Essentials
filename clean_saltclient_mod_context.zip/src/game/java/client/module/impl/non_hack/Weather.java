package client.module.impl.non_hack;

import client.module.Category;
import client.module.ModeSetting;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.client.Minecraft;
import net.minecraft.world.World;

public class Weather extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Weather", "Clear", "Default", "Clear", "Rain", "Thunder");

    private float savedRainStrength = 0.0f;

    private float savedThunderStrength = 0.0f;

    private boolean hasSavedValues = false;

    public Weather() {
        super("Weather", Category.NON_HACK);
        setDescription("Visually change the weather (client-side only)");
        addSetting(mode);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.world == null)
            return;
        if (!hasSavedValues) {
            savedRainStrength = mc.world.getRainStrength(1.0f);
            savedThunderStrength = mc.world.getThunderStrength(1.0f);
            hasSavedValues = true;
        }
        String currentMode = mode.getValue();
        if (currentMode.equals("Clear")) {
            mc.world.setRainStrength(0.0f);
            mc.world.setThunderStrength(0.0f);
        } else if (currentMode.equals("Rain")) {
            mc.world.setRainStrength(1.0f);
            mc.world.setThunderStrength(0.0f);
        } else if (currentMode.equals("Thunder")) {
            mc.world.setRainStrength(1.0f);
            mc.world.setThunderStrength(1.0f);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.world != null && hasSavedValues) {
            mc.world.setRainStrength(savedRainStrength);
            mc.world.setThunderStrength(savedThunderStrength);
        }
        hasSavedValues = false;
        savedRainStrength = 0.0f;
        savedThunderStrength = 0.0f;
    }
}
