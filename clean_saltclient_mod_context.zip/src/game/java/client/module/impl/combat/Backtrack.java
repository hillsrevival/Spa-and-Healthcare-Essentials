package client.module.impl.combat;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.event.events.PacketInputEvent;
import client.event.events.TickEvent;
import client.event.events.WorldChangeEvent;
import client.event.listeners.RenderListener;
import client.utils.combat.BacktrackUtils;
import client.utils.combat.BacktrackUtils.EncodedPositionState;
import client.utils.combat.BacktrackUtils.PositionSnapshot;
import client.utils.render.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.network.play.server.SPacketEntity;
import net.minecraft.network.play.server.SPacketEntityTeleport;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketDestroyEntities;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.math.AxisAlignedBB;

public class Backtrack extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting latency = new NumberSetting("Latency", 50.0, 0.0, 500.0);

    private final BooleanSetting renderServerPos = new BooleanSetting("RenderPos", true);

    private static final double AUTO_TARGET_RANGE = 6.0;

    private int activeTargetId = -1;

    private boolean targetSetByCombat = false;

    private boolean delayingPackets = false;

    private PositionSnapshot lastTargetSnapshot = null;

    private final Map<Integer, EncodedPositionState> entityStates = new HashMap<>();

    private final Map<Packet<?>, Long> queuedPackets = new LinkedHashMap<>();

    private long lastReleaseAt = 0L;

    private double currentRenderX, currentRenderY, currentRenderZ;

    private double previousRenderX, previousRenderY, previousRenderZ;

    private double targetRenderX, targetRenderY, targetRenderZ;

    private int interpolationSteps = 0;

    private static Backtrack instance = null;

    public Backtrack() {
        super("Backtrack", Category.COMBAT);
        setDescription("Delay enemy packets to hit their previous position");
        addSetting(latency);
        addSetting(renderServerPos);
        handles(HandlerType.TICK, HandlerType.PACKET_INPUT, HandlerType.WORLD_CHANGE, HandlerType.RENDER);
        instance = this;
    }

    public static void setTarget(EntityLivingBase entity) {
        if (instance == null || !instance.isToggled())
            return;
        if (entity == null) {
            instance.targetSetByCombat = false;
            return;
        }
        int entityId = entity.getEntityId();
        if (entityId != instance.activeTargetId) {
            instance.activeTargetId = entityId;
            instance.lastTargetSnapshot = null;
            instance.delayingPackets = false;
            EncodedPositionState state = instance.entityStates.get(entityId);
            if (state != null) {
                PositionSnapshot snap = state.toSnapshot();
                instance.resetRenderPosition(snap.x, snap.y, snap.z);
            } else if (instance.mc.world != null) {
                instance.resetRenderPosition(entity.posX, entity.posY, entity.posZ);
            }
            instance.flushQueuedPackets();
        }
        instance.targetSetByCombat = true;
    }

    public static void onAttack() {
        if (instance == null || !instance.isToggled())
            return;
        instance.flushQueuedPackets();
    }

    public static boolean isDelayingFor(EntityLivingBase entity) {
        if (instance == null || !instance.isToggled())
            return false;
        return instance.delayingPackets && entity != null && entity.getEntityId() == instance.activeTargetId;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        resetState();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        flushQueuedPackets();
        resetState();
    }

    @Override
    public void onWorldChange(WorldChangeEvent event) {
        resetState();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            flushQueuedPackets();
            activeTargetId = -1;
            return;
        }
        if (!targetSetByCombat || activeTargetId == -1) {
            EntityLivingBase closest = findClosestEnemy();
            if (closest != null) {
                int newId = closest.getEntityId();
                if (newId != activeTargetId) {
                    activeTargetId = newId;
                    lastTargetSnapshot = null;
                    delayingPackets = false;
                    EncodedPositionState state = entityStates.get(newId);
                    if (state != null) {
                        PositionSnapshot snap = state.toSnapshot();
                        resetRenderPosition(snap.x, snap.y, snap.z);
                    } else {
                        resetRenderPosition(closest.posX, closest.posY, closest.posZ);
                    }
                    flushQueuedPackets();
                }
            } else {
                if (activeTargetId != -1) {
                    activeTargetId = -1;
                    lastTargetSnapshot = null;
                    delayingPackets = false;
                    flushQueuedPackets();
                }
            }
        }
        if (activeTargetId != -1) {
            Entity target = mc.world.getEntityByID(activeTargetId);
            if (target == null || !target.isEntityAlive() || !(target instanceof EntityLivingBase)) {
                activeTargetId = -1;
                lastTargetSnapshot = null;
                delayingPackets = false;
                targetSetByCombat = false;
                flushQueuedPackets();
            }
        }
        if (!queuedPackets.isEmpty()) {
            if (mc.player.connection != null) {
                long now = System.currentTimeMillis();
                Iterator<Map.Entry<Packet<?>, Long>> it = queuedPackets.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry<Packet<?>, Long> entry = it.next();
                    if (now < entry.getValue()) {
                        break;
                    }
                    replayPacket(entry.getKey());
                    it.remove();
                }
            } else {
                queuedPackets.clear();
            }
        }
        previousRenderX = currentRenderX;
        previousRenderY = currentRenderY;
        previousRenderZ = currentRenderZ;
        if (activeTargetId != -1 && interpolationSteps > 0) {
            currentRenderX += (targetRenderX - currentRenderX) / interpolationSteps;
            currentRenderY += (targetRenderY - currentRenderY) / interpolationSteps;
            currentRenderZ += (targetRenderZ - currentRenderZ) / interpolationSteps;
            interpolationSteps--;
        }
        targetSetByCombat = false;
    }

    private EntityLivingBase findClosestEnemy() {
        if (mc.player == null || mc.world == null)
            return null;
        client.utils.combat.TargetSelector.Criteria c = new client.utils.combat.TargetSelector.Criteria();
        c.targetPlayers = true;
        c.targetHostile = false;
        c.targetPassive = false;
        c.targetInvisible = true;
        c.hitThroughWalls = true;
        c.range = AUTO_TARGET_RANGE;
        c.fov = 360.0;
        c.aimLeadTicks = -1.0;
        return client.utils.combat.TargetSelector.selectTarget(c, "Distance");
    }

    @Override
    public void onPacketInput(PacketInputEvent event) {
        if (!isToggled())
            return;
        if (mc.player == null || mc.world == null) {
            flushQueuedPackets();
            activeTargetId = -1;
            return;
        }
        Packet<?> receivedPacket = event.getPacket();
        if (receivedPacket instanceof SPacketPlayerPosLook) {
            flushQueuedPackets();
            return;
        }
        if (receivedPacket instanceof SPacketEntityVelocity) {
            SPacketEntityVelocity velPacket = (SPacketEntityVelocity) receivedPacket;
            if (velPacket.getEntityID() == mc.player.getEntityId()) {
                flushQueuedPackets();
                return;
            }
        }
        PositionSnapshot latestSnapshot = null;
        boolean hasPositionData = false;
        if (receivedPacket instanceof SPacketEntity) {
            SPacketEntity entityPacket = (SPacketEntity) receivedPacket;
            hasPositionData = (entityPacket.getX() != 0 || entityPacket.getY() != 0 || entityPacket.getZ() != 0);
            Entity entity = entityPacket.getEntity(mc.world);
            if (entity != null) {
                int entityId = entity.getEntityId();
                EncodedPositionState state = entityStates.get(entityId);
                if (state != null) {
                    state.applyRelativeMove(entityPacket.getX(), entityPacket.getY(), entityPacket.getZ());
                } else {
                    if (entity instanceof EntityLivingBase) {
                        state = EncodedPositionState.fromEntity((EntityLivingBase) entity);
                        state.applyRelativeMove(entityPacket.getX(), entityPacket.getY(), entityPacket.getZ());
                        entityStates.put(entityId, state);
                    }
                }
                if (entityId == activeTargetId && state != null) {
                    latestSnapshot = state.toSnapshot();
                    setTargetRenderPosition(latestSnapshot.x, latestSnapshot.y, latestSnapshot.z);
                }
            }
        }
        if (receivedPacket instanceof SPacketEntityTeleport) {
            SPacketEntityTeleport teleportPacket = (SPacketEntityTeleport) receivedPacket;
            int entityId = teleportPacket.getEntityId();
            hasPositionData = true;
            long encX = floor(teleportPacket.getX() * BacktrackUtils.POSITION_SCALE);
            long encY = floor(teleportPacket.getY() * BacktrackUtils.POSITION_SCALE);
            long encZ = floor(teleportPacket.getZ() * BacktrackUtils.POSITION_SCALE);
            EncodedPositionState state = new EncodedPositionState(encX, encY, encZ);
            entityStates.put(entityId, state);
            if (entityId == activeTargetId) {
                latestSnapshot = state.toSnapshot();
                setTargetRenderPosition(latestSnapshot.x, latestSnapshot.y, latestSnapshot.z);
            }
        }
        if (receivedPacket instanceof SPacketDestroyEntities) {
            SPacketDestroyEntities destroyPacket = (SPacketDestroyEntities) receivedPacket;
            for (int removedId : destroyPacket.getEntityIDs()) {
                entityStates.remove(removedId);
                if (removedId == activeTargetId) {
                    activeTargetId = -1;
                    lastTargetSnapshot = null;
                    targetSetByCombat = false;
                    flushQueuedPackets();
                }
            }
            return;
        }
        if (activeTargetId == -1) {
            if (!queuedPackets.isEmpty()) {
                flushQueuedPackets();
            }
            return;
        }
        if (!hasPositionData) {
            return;
        }
        if (latestSnapshot == null) {
            return;
        }
        delayingPackets = shouldDelaySnapshot(latestSnapshot);
        lastTargetSnapshot = latestSnapshot;
        if (delayingPackets) {
            event.setCancelled(true);
            queuePacket(receivedPacket);
        } else if (!queuedPackets.isEmpty()) {
            flushQueuedPackets();
        }
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!renderServerPos.getValue())
            return;
        if (activeTargetId == -1)
            return;
        if (mc.world == null)
            return;
        Entity entity = mc.world.getEntityByID(activeTargetId);
        if (!(entity instanceof EntityLivingBase))
            return;
        EntityLivingBase target = (EntityLivingBase) entity;
        float partialTicks = event.getPartialTicks();
        double interpX = previousRenderX + (currentRenderX - previousRenderX) * partialTicks;
        double interpY = previousRenderY + (currentRenderY - previousRenderY) * partialTicks;
        double interpZ = previousRenderZ + (currentRenderZ - previousRenderZ) * partialTicks;
        double renderX = mc.getRenderManager().viewerPosX;
        double renderY = mc.getRenderManager().viewerPosY;
        double renderZ = mc.getRenderManager().viewerPosZ;
        double halfWidth = target.width / 2.0;
        AxisAlignedBB box = new AxisAlignedBB(interpX - halfWidth - renderX, interpY - renderY, interpZ - halfWidth - renderZ, interpX + halfWidth - renderX, interpY + target.height - renderY, interpZ + halfWidth - renderZ);
        RenderUtils.updateCameraPos(partialTicks);
        RenderUtils.prepareGL();
        RenderUtils.drawSolidBox(box, 0.02f, 0.52f, 0.41f, 0.25f);
        RenderUtils.drawOutlinedBox(box, 0.02f, 0.52f, 0.41f, 0.6f);
        RenderUtils.restoreGL();
    }

    private boolean shouldDelaySnapshot(PositionSnapshot snapshot) {
        if (lastTargetSnapshot == null)
            return false;
        if (mc.player == null)
            return false;
        PositionSnapshot playerEye = BacktrackUtils.playerEyeSnapshot(mc.player);
        double previousDistance = BacktrackUtils.rayIntersectionDistance(playerEye, lastTargetSnapshot);
        double newDistance = BacktrackUtils.rayIntersectionDistance(playerEye, snapshot);
        return newDistance > previousDistance;
    }

    private void queuePacket(Packet<?> packet) {
        long delayMs = latency.getValue().longValue();
        if (delayMs < 1)
            delayMs = 1;
        long releaseAt = System.currentTimeMillis() + delayMs;
        if (releaseAt < lastReleaseAt) {
            releaseAt = lastReleaseAt + 1L;
        }
        lastReleaseAt = releaseAt;
        queuedPackets.put(packet, releaseAt);
    }

    private void flushQueuedPackets() {
        lastReleaseAt = 0L;
        if (queuedPackets.isEmpty())
            return;
        if (mc.player != null && mc.player.connection != null) {
            for (Packet<?> packet : queuedPackets.keySet()) {
                replayPacket(packet);
            }
        }
        queuedPackets.clear();
    }

    @SuppressWarnings("unchecked")
    private void replayPacket(Packet<?> packet) {
        if (mc.player == null || mc.player.connection == null)
            return;
        try {
            ((Packet<INetHandlerPlayClient>) packet).processPacket(mc.player.connection);
        } catch (Exception e) {
        }
    }

    private void setTargetRenderPosition(double x, double y, double z) {
        targetRenderX = x;
        targetRenderY = y;
        targetRenderZ = z;
        interpolationSteps = 3;
    }

    private void resetRenderPosition(double x, double y, double z) {
        currentRenderX = previousRenderX = targetRenderX = x;
        currentRenderY = previousRenderY = targetRenderY = y;
        currentRenderZ = previousRenderZ = targetRenderZ = z;
        interpolationSteps = 0;
    }

    private void resetState() {
        entityStates.clear();
        queuedPackets.clear();
        activeTargetId = -1;
        delayingPackets = false;
        targetSetByCombat = false;
        lastTargetSnapshot = null;
        resetRenderPosition(0, 0, 0);
    }

    private static long floor(double value) {
        long l = (long) value;
        return value < (double) l ? l - 1L : l;
    }
}
