package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.misc.NotificationSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemSplashPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionUtils;
import net.minecraft.util.EnumHand;
import java.util.List;

public class ThrowDebuff extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 6.0, 3.0, 12.0);

    private final NumberSetting delay = new NumberSetting("Delay", 3.0, 1.0, 10.0);

    private int savedSlot = -1;

    private int tickCounter = 0;

    private boolean throwing = false;

    public ThrowDebuff() {
        super("ThrowDebuff", Category.COMBAT);
        setDescription("Throws debuff potions at nearby opponents");
        addSetting(range);
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        tickCounter++;
        int delayTicks = delay.getValue().intValue();
        if (throwing) {
            if (tickCounter < delayTicks)
                return;
            tickCounter = 0;
            if (savedSlot != -1) {
                mc.player.inventory.currentItem = savedSlot;
            }
            throwing = false;
            return;
        }
        if (tickCounter < delayTicks * 5)
            return;
        tickCounter = 0;
        int potionSlot = findDebuffPotion();
        if (potionSlot == -1)
            return;
        EntityPlayer target = findNearestTarget();
        if (target == null)
            return;
        savedSlot = mc.player.inventory.currentItem;
        mc.player.inventory.currentItem = potionSlot;
        mc.playerController.updateController();
        double horizontalDist = Math.sqrt((target.posX - mc.player.posX) * (target.posX - mc.player.posX) + (target.posZ - mc.player.posZ) * (target.posZ - mc.player.posZ));
        net.minecraft.util.math.Vec3d aimPoint = new net.minecraft.util.math.Vec3d(target.posX, target.posY + target.height / 2.0 + horizontalDist * 0.2, target.posZ);
        float[] rots = client.utils.movement.RotationUtils.getNeededRotations(aimPoint);
        mc.player.rotationYaw = rots[0];
        mc.player.rotationPitch = rots[1];
        mc.playerController.processRightClick(mc.player, mc.world, EnumHand.MAIN_HAND);
        throwing = true;
        tickCounter = 0;
    }

    private int findDebuffPotion() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == null || stack.func_190926_b())
                continue;
            if (!(stack.getItem() instanceof ItemSplashPotion))
                continue;
            List<PotionEffect> effects = PotionUtils.getEffectsFromStack(stack);
            for (PotionEffect effect : effects) {
                if (effect.getPotion() == MobEffects.POISON || effect.getPotion() == MobEffects.WEAKNESS || effect.getPotion() == MobEffects.SLOWNESS) {
                    return i;
                }
            }
        }
        return -1;
    }

    private EntityPlayer findNearestTarget() {
        client.utils.combat.TargetSelector.Criteria c = new client.utils.combat.TargetSelector.Criteria();
        c.targetPlayers = true;
        c.targetHostile = false;
        c.targetPassive = false;
        c.targetInvisible = true;
        c.hitThroughWalls = true;
        c.range = range.getValue();
        c.fov = 360.0;
        c.aimLeadTicks = -1.0;
        return (EntityPlayer) client.utils.combat.TargetSelector.selectTarget(c, "Distance");
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (savedSlot != -1 && mc.player != null) {
            mc.player.inventory.currentItem = savedSlot;
        }
        throwing = false;
        savedSlot = -1;
    }
}
