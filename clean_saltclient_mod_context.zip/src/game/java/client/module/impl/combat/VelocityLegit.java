package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.utils.combat.CombatContext;
import client.utils.movement.MovementUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.MathHelper;

public class VelocityLegit extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting horizontalReduction = new NumberSetting("Horizontal %", 5.0, 0.0, 15.0);

    private final NumberSetting verticalReduction = new NumberSetting("Vertical %", 3.0, 0.0, 15.0);

    private final BooleanSetting onlyCombat = new BooleanSetting("Only Combat", true);

    private final ModeSetting mode = new ModeSetting("Mode", "Reduce", "Reduce", "Random");

    private final BooleanSetting landingRetap = new BooleanSetting("Landing Re-Tap", true);

    private final NumberSetting landingTapDuration = new NumberSetting("Landing Tap Duration", 5.0, 1.0, 8.0);

    private boolean managingForward = false;

    private boolean managingBack = false;

    private boolean managingLeft = false;

    private boolean managingRight = false;

    private int ticksInPhase = 0;

    private int phaseDuration = 0;

    private boolean awaitingLanding = false;

    public VelocityLegit() {
        super("VelocityLegit", Category.COMBAT);
        setDescription("Reduces knockback by counter tapping into it");
        addSetting(horizontalReduction);
        addSetting(verticalReduction);
        addSetting(onlyCombat);
        addSetting(mode);
        addSetting(landingRetap);
        addSetting(landingTapDuration);
        handles(HandlerType.TICK);
    }

    @Override
    public void onTick() {
        if (!nullCheck())
            return;
        if (mc.player.hurtTime > 0 && mc.player.hurtTime == mc.player.maxHurtTime) {
            if (shouldCounterTap()) {
                startCounterTap();
            }
        }
        if (awaitingLanding && mc.player.onGround) {
            awaitingLanding = false;
            startLandingTap();
        }
        if (phaseDuration > 0) {
            ticksInPhase++;
            if (ticksInPhase >= phaseDuration) {
                endCounterTap();
            }
        }
    }

    private boolean shouldCounterTap() {
        if (mc.player == null)
            return false;
        if (onlyCombat.getValue()) {
            long ticksSinceAttack = CombatContext.getTicksSinceMyAttack();
            long ticksSinceOpponentSwing = CombatContext.getTicksSinceOpponentSwing();
            if (ticksSinceAttack > 60 && ticksSinceOpponentSwing > 60) {
                return false;
            }
        }
        return true;
    }

    private void startCounterTap() {
        if (mc.player == null)
            return;
        double kbX = mc.player.motionX;
        double kbZ = mc.player.motionZ;
        double mag = Math.sqrt(kbX * kbX + kbZ * kbZ);
        if (mag < 0.08D) {
            return;
        }
        if (client.utils.combat.CombatContext.isJumpResetRecent(1)) {
            endCounterTap();
            awaitingLanding = landingRetap.getValue();
            phaseDuration = 0;
            return;
        }
        float yawRad = mc.player.rotationYaw * 0.017453292F;
        float sin = MathHelper.sin(yawRad);
        float cos = MathHelper.cos(yawRad);
        double counterX = -kbX / mag;
        double counterZ = -kbZ / mag;
        double[] scores = new double[] { (-sin) * counterX + (cos) * counterZ, (sin) * counterX + (-cos) * counterZ, (cos) * counterX + (sin) * counterZ, (-cos) * counterX + (-sin) * counterZ };
        int bestIdx = 0;
        for (int i = 1; i < 4; i++) {
            if (scores[i] > scores[bestIdx])
                bestIdx = i;
        }
        if (scores[bestIdx] <= 0.05D) {
            return;
        }
        int secondIdx = -1;
        for (int i = 0; i < 4; i++) {
            if (i != bestIdx && scores[i] >= 0.5D * scores[bestIdx]) {
                if (secondIdx < 0 || scores[i] > scores[secondIdx]) {
                    secondIdx = i;
                }
            }
        }
        pressIfFree(bestIdx);
        if (secondIdx >= 0) {
            pressIfFree(secondIdx);
        }
        int base = (int) Math.round(horizontalReduction.getValue() / 5.0D);
        base = Math.max(1, Math.min(3, base));
        if (mode.getValue().equals("Random")) {
            base = Math.max(1, base + (int) (Math.random() * 3.0D) - 1);
        }
        int air = 0;
        if (verticalReduction.getValue() > 0.0D && mc.player.motionY > 0.05D) {
            air = (int) Math.round(verticalReduction.getValue() / 3.0D);
            air = Math.max(1, Math.min(5, air));
        }
        phaseDuration = base + air;
        ticksInPhase = 0;
        awaitingLanding = landingRetap.getValue() && air > 0;
    }

    private void startLandingTap() {
        if (mc.player == null)
            return;
        if (!shouldCounterTap())
            return;
        double driftX = mc.player.motionX;
        double driftZ = mc.player.motionZ;
        double mag = Math.sqrt(driftX * driftX + driftZ * driftZ);
        if (mag < 0.02D) {
            return;
        }
        float yawRad = mc.player.rotationYaw * 0.017453292F;
        float sin = MathHelper.sin(yawRad);
        float cos = MathHelper.cos(yawRad);
        double counterX = -driftX / mag;
        double counterZ = -driftZ / mag;
        double scoreW = (-sin) * counterX + (cos) * counterZ;
        double scoreS = (sin) * counterX + (-cos) * counterZ;
        double scoreA = (cos) * counterX + (sin) * counterZ;
        double scoreD = (-cos) * counterX + (-sin) * counterZ;
        int bestIdx = 0;
        double bestScore = scoreW;
        if (scoreS > bestScore) {
            bestIdx = 1;
            bestScore = scoreS;
        }
        if (scoreA > bestScore) {
            bestIdx = 2;
            bestScore = scoreA;
        }
        if (scoreD > bestScore) {
            bestIdx = 3;
            bestScore = scoreD;
        }
        if (bestScore <= 0.05D) {
            return;
        }
        int secondIdx = -1;
        double secondScore = 0.0D;
        for (int i = 0; i < 4; i++) {
            double s = i == 0 ? scoreW : i == 1 ? scoreS : i == 2 ? scoreA : scoreD;
            if (i != bestIdx && s >= 0.5D * bestScore) {
                if (secondIdx < 0 || s > secondScore) {
                    secondIdx = i;
                    secondScore = s;
                }
            }
        }
        pressIfFree(bestIdx);
        if (secondIdx >= 0) {
            pressIfFree(secondIdx);
        }
        int duration = (int) Math.round(landingTapDuration.getValue());
        duration = Math.max(1, Math.min(8, duration));
        if (mode.getValue().equals("Random")) {
            duration = Math.max(1, duration + (int) (Math.random() * 3.0D) - 1);
        }
        phaseDuration = ticksInPhase + duration;
    }

    private void pressIfFree(int idx) {
        switch(idx) {
            case 0:
                if (managingForward || !mc.gameSettings.keyBindForward.isKeyDown()) {
                    MovementUtils.holdForward(true);
                    managingForward = true;
                }
                break;
            case 1:
                if (managingBack || !mc.gameSettings.keyBindBack.isKeyDown()) {
                    MovementUtils.holdBack(true);
                    managingBack = true;
                }
                break;
            case 2:
                if (managingLeft || !mc.gameSettings.keyBindLeft.isKeyDown()) {
                    MovementUtils.holdLeft(true);
                    managingLeft = true;
                }
                break;
            case 3:
                if (managingRight || !mc.gameSettings.keyBindRight.isKeyDown()) {
                    MovementUtils.holdRight(true);
                    managingRight = true;
                }
                break;
            default:
                break;
        }
    }

    private void endCounterTap() {
        if (mc.player == null)
            return;
        if (managingForward)
            MovementUtils.holdForward(false);
        if (managingBack)
            MovementUtils.holdBack(false);
        if (managingLeft)
            MovementUtils.holdLeft(false);
        if (managingRight)
            MovementUtils.holdRight(false);
        managingForward = false;
        managingBack = false;
        managingLeft = false;
        managingRight = false;
        phaseDuration = 0;
        ticksInPhase = 0;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        managingForward = false;
        managingBack = false;
        managingLeft = false;
        managingRight = false;
        phaseDuration = 0;
        ticksInPhase = 0;
        awaitingLanding = false;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        endCounterTap();
        awaitingLanding = false;
    }
}
