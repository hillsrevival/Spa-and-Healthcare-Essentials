package client.module.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.world.InteractionUtils;

public class AutoSword extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private int oldSlot = -1;

    private int timer;

    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 2.0, 1.0, 5.0);

    private final NumberSetting holdTime = new NumberSetting("Hold Ticks", 4.0, 2.0, 10.0);

    private final BooleanSetting silentSwitch = new BooleanSetting("Silent", false);

    public AutoSword() {
        super("AutoSword", Category.COMBAT);
        setDescription("Switches to a sword when attacking");
        addSetting(switchDelay);
        addSetting(holdTime);
        addSetting(silentSwitch);
        handles(HandlerType.UPDATE, HandlerType.ATTACK);
    }

    @Override
    public void onAttack(client.event.events.AttackEvent event) {
        if (mc.player == null)
            return;
        if (timer > 0)
            return;
        Entity target = event.getTarget();
        int bestSlot = (target instanceof EntityLivingBase) ? client.utils.combat.ItemStackScoreUtil.findBestWeaponSlot((EntityLivingBase) target) : client.utils.combat.ItemStackScoreUtil.findBestWeaponSlot();
        if (bestSlot == -1 || bestSlot == mc.player.inventory.currentItem)
            return;
        if (oldSlot == -1)
            oldSlot = mc.player.inventory.currentItem;
        mc.player.inventory.currentItem = bestSlot;
        timer = (int) (double) holdTime.getValue();
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (timer > 0) {
            timer--;
            return;
        }
        if (oldSlot != -1) {
            mc.player.inventory.currentItem = oldSlot;
            oldSlot = -1;
        }
        if (!client.utils.combat.AttackKeyController.isAttackKeyDown())
            return;
        if (mc.objectMouseOver == null)
            return;
        if (mc.objectMouseOver.entityHit == null)
            return;
        setSlot();
    }

    private void setSlot() {
        if (mc.player == null)
            return;
        Entity target = (mc.objectMouseOver != null) ? mc.objectMouseOver.entityHit : null;
        int bestSlot;
        if (target instanceof EntityLivingBase) {
            bestSlot = client.utils.combat.ItemStackScoreUtil.findBestWeaponSlot((EntityLivingBase) target);
        } else {
            bestSlot = client.utils.combat.ItemStackScoreUtil.findBestWeaponSlot();
        }
        if (bestSlot == -1)
            return;
        if (oldSlot == -1)
            oldSlot = mc.player.inventory.currentItem;
        int delay = (int) (double) switchDelay.getValue();
        int randomizedDelay = delay > 0 ? delay + (int) (Math.random() * 2) : 0;
        timer = randomizedDelay + (int) (double) holdTime.getValue();
        mc.player.inventory.currentItem = bestSlot;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (oldSlot != -1 && mc.player != null) {
            mc.player.inventory.currentItem = oldSlot;
            oldSlot = -1;
        }
        timer = 0;
    }
}
