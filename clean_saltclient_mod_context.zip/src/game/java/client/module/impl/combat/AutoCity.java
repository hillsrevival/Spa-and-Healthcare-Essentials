package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;
import client.utils.EntityUtils;

public class AutoCity extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 5.0, 2.0, 6.0);

    private final BooleanSetting antiSelfTrap = new BooleanSetting("AntiSelfTrap", true);

    public AutoCity() {
        super("AutoCity", Category.COMBAT);
        setDescription("Automatically breaks blocks around other players");
        addSetting(range);
        addSetting(antiSelfTrap);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        client.utils.player.FindItemResult pick = client.utils.player.InvUtils.findInHotbar(stack -> stack != null && !stack.func_190926_b() && stack.getItem() instanceof net.minecraft.item.ItemPickaxe);
        int pickSlot = pick.found() ? pick.slot() - client.utils.player.SlotUtils.HOTBAR_START : -1;
        if (pickSlot == -1)
            return;
        double rangeD = range.getValue().doubleValue();
        client.utils.combat.TargetSelector.Criteria c = new client.utils.combat.TargetSelector.Criteria();
        c.targetPlayers = true;
        c.targetHostile = false;
        c.targetPassive = false;
        c.targetInvisible = true;
        c.hitThroughWalls = true;
        c.range = rangeD;
        c.fov = 360.0;
        c.aimLeadTicks = -1.0;
        EntityPlayer target = (EntityPlayer) client.utils.combat.TargetSelector.selectTarget(c, "Distance");
        if (target == null)
            return;
        int tx = (int) Math.floor(target.posX);
        int ty = (int) Math.floor(target.posY);
        int tz = (int) Math.floor(target.posZ);
        BlockPos[] toBreak = new BlockPos[4];
        int breakCount = 0;
        EnumFacing[] facings = new EnumFacing[4];
        for (EnumFacing facing : new EnumFacing[] { EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.EAST, EnumFacing.WEST }) {
            BlockPos pos = new BlockPos(tx, ty, tz).offset(facing);
            if (WorldUtils.getBlock(pos) == Blocks.OBSIDIAN || WorldUtils.getBlock(pos) == Blocks.WEB) {
                toBreak[breakCount] = pos;
                facings[breakCount] = facing;
                breakCount++;
            }
        }
        if (breakCount == 0)
            return;
        if (antiSelfTrap.getValue()) {
            int myX = (int) Math.floor(mc.player.posX);
            int myZ = (int) Math.floor(mc.player.posZ);
            for (int i = 0; i < breakCount; i++) {
                if (toBreak[i].getX() == myX && toBreak[i].getZ() == myZ) {
                    return;
                }
            }
        }
        int savedSlot = mc.player.inventory.currentItem;
        mc.player.inventory.currentItem = pickSlot;
        BlockPos targetPos = toBreak[0];
        InteractionUtils.breakBlock(targetPos, facings[0].getOpposite());
        mc.player.inventory.currentItem = savedSlot;
    }
}
