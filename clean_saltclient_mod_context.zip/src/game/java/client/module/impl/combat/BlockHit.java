package client.module.impl.combat;

import client.event.events.PacketOutputEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketPlayerDigging;

public class BlockHit extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting onlySword = new BooleanSetting("Only Sword", true);

    public BlockHit() {
        super("BlockHit", Category.COMBAT);
        setDescription("Prevents server from knowing you stopped blocking");
        addSetting(onlySword);
        handles(HandlerType.PACKET_OUTPUT);
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        if (mc.player == null)
            return;
        if (!(event.getPacket() instanceof CPacketPlayerDigging))
            return;
        CPacketPlayerDigging packet = (CPacketPlayerDigging) event.getPacket();
        if (packet.getAction() != CPacketPlayerDigging.Action.RELEASE_USE_ITEM)
            return;
        if (onlySword.getValue()) {
            ItemStack held = mc.player.getHeldItemMainhand();
            if (held == null || held.func_190926_b() || !(held.getItem() instanceof ItemSword)) {
                return;
            }
        }
        event.setCancelled(true);
    }
}
