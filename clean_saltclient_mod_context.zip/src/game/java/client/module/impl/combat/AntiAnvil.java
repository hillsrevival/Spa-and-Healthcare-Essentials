package client.module.impl.combat;

import client.event.listeners.RightClickListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.RayTraceResult;

public class AntiAnvil extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public AntiAnvil() {
        super("AntiAnvil", Category.COMBAT);
        setDescription("Prevents the anvil gui from opening when you click a anvil");
        handles(HandlerType.RIGHT_CLICK);
    }

    @Override
    public void onRightClick(RightClickListener.RightClickEvent event) {
        if (!nullCheck())
            return;
        if (mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == RayTraceResult.Type.BLOCK) {
            if (mc.world.getBlockState(mc.objectMouseOver.getBlockPos()).getBlock() == Blocks.ANVIL) {
                event.setCancelled(true);
            }
        }
    }
}
