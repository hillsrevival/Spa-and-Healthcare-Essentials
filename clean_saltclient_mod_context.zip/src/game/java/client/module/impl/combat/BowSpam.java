package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

public class BowSpam extends Module {

    private int drawTicks = 0;

    private boolean repressing = false;

    private final Minecraft mc = Minecraft.getMinecraft();

    public BowSpam() {
        super("BowSpam", Category.COMBAT);
        setDescription("Spams bow shots");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held == null || held.getItem() != Items.BOW)
            return;
        if (mc.currentScreen != null)
            return;
        if (mc.player.isHandActive()) {
            drawTicks++;
            if (drawTicks >= 20) {
                drawTicks = 0;
                mc.playerController.onStoppedUsingItem(mc.player);
                net.minecraft.client.settings.KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
                repressing = true;
            }
        } else {
            drawTicks = 0;
            if (repressing) {
                repressing = false;
                net.minecraft.client.settings.KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
            }
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        net.minecraft.client.settings.KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
        repressing = false;
        drawTicks = 0;
    }
}
