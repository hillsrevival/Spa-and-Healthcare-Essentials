package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.combat.CombatContext;
import client.utils.misc.TimerUtils;
import net.minecraft.client.Minecraft;

public class TickShiftLegit extends Module {

    private double depositedThisFill = 0.0;

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting maxBank = new NumberSetting("Max Bank", 5.0, 1.0, 20.0);

    private final NumberSetting minBankToShift = new NumberSetting("Min Bank To Shift", 2.0, 1.0, 10.0);

    private final NumberSetting shiftSpeed = new NumberSetting("Shift Speed", 1.1, 1.01, 1.2);

    private final NumberSetting shiftDuration = new NumberSetting("Shift Duration", 2.0, 1.0, 5.0);

    private final BooleanSetting onlyWhenTargeted = new BooleanSetting("Only When Targeted", true);

    private double bankedTicks = 0.0;

    private int shiftRemaining = 0;

    private double ticksReleasedByShift = 0.0;

    private double leadSpentThisBank = 0.0;

    private long lastTickNanos = 0;

    public TickShiftLegit() {
        super("TickShiftLegit", Category.COMBAT);
        setDescription("Banks tick pauses and releases them on attack");
        addSetting(maxBank);
        addSetting(minBankToShift);
        addSetting(shiftSpeed);
        addSetting(shiftDuration);
        addSetting(onlyWhenTargeted);
        handles(HandlerType.TICK, HandlerType.ATTACK);
    }

    @Override
    public void onTick() {
        if (!nullCheck())
            return;
        long now = System.nanoTime();
        long expectedNanos = 50_000_000L;
        if (lastTickNanos > 0) {
            long elapsed = now - lastTickNanos;
            if (elapsed > expectedNanos) {
                double excessTicks = (double) (elapsed - expectedNanos) / (double) expectedNanos;
                if (excessTicks <= 4.0) {
                    bankedTicks += excessTicks;
                    double max = maxBank.getValue();
                    if (bankedTicks > max)
                        bankedTicks = max;
                    depositedThisFill = Math.min(depositedThisFill + excessTicks, max);
                }
            }
        }
        lastTickNanos = now;
        if (shiftRemaining > 0) {
            float speed = TimerUtils.getTimerSpeed();
            if (speed > 1.0f) {
                ticksReleasedByShift += 1.0 - (1.0 / (double) speed);
            }
            shiftRemaining--;
            if (shiftRemaining <= 0) {
                bankedTicks -= ticksReleasedByShift;
                if (bankedTicks < 0)
                    bankedTicks = 0;
                leadSpentThisBank += ticksReleasedByShift;
                ticksReleasedByShift = 0.0;
                TimerUtils.setTimerSpeed(1.0f);
                if (bankedTicks <= 0.0) {
                    leadSpentThisBank = 0.0;
                    depositedThisFill = 0.0;
                }
            }
        }
    }

    @Override
    public void onAttack(client.event.events.AttackEvent event) {
        if (mc.player == null)
            return;
        if (onlyWhenTargeted.getValue() && CombatContext.getTarget() == null) {
            return;
        }
        double minBank_ = minBankToShift.getValue();
        if (bankedTicks < minBank_)
            return;
        if (shiftRemaining > 0)
            return;
        float speed = shiftSpeed.getValue().floatValue();
        int duration = (int) (double) shiftDuration.getValue();
        double shiftGain = duration * (1.0 - 1.0 / (double) speed);
        double leadBudget = depositedThisFill * (1.0 - 1.0 / (double) speed);
        if (leadSpentThisBank + shiftGain > leadBudget)
            return;
        TimerUtils.setTimerSpeed(speed);
        shiftRemaining = duration;
        ticksReleasedByShift = 0.0;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        bankedTicks = 0;
        shiftRemaining = 0;
        ticksReleasedByShift = 0.0;
        leadSpentThisBank = 0.0;
        lastTickNanos = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        TimerUtils.setTimerSpeed(1.0f);
        bankedTicks = 0;
        shiftRemaining = 0;
        ticksReleasedByShift = 0.0;
        leadSpentThisBank = 0.0;
    }
}
