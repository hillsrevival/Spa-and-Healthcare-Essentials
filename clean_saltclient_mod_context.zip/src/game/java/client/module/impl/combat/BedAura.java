package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import client.utils.player.InventoryManager;
import client.utils.player.InvUtils;
import client.utils.player.FindItemResult;
import client.utils.player.PlayerUtils;
import client.utils.combat.CombatUtils;
import client.utils.combat.ExplosionDamageUtil;
import client.utils.EntityUtils;
import client.utils.movement.RotationUtils;
import client.utils.world.WorldUtils;
import client.utils.world.BlockUtils;

public class BedAura extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 5.0, 3.0, 8.0);

    private final NumberSetting delay = new NumberSetting("Delay", 5.0, 1.0, 20.0);

    private final NumberSetting detonateDelay = new NumberSetting("DetonateDelay", 2.0, 1.0, 10.0);

    private final NumberSetting maxSelfDamage = new NumberSetting("MaxSelfDmg", 8.0, 0.0, 20.0);

    private final NumberSetting minHealth = new NumberSetting("MinHealth", 8.0, 1.0, 20.0);

    private final BooleanSetting antiSuicide = new BooleanSetting("AntiSuicide", true);

    private final BooleanSetting autoSwitch = new BooleanSetting("Auto Switch", true);

    private final BooleanSetting rotate = new BooleanSetting("Rotate", true);

    private BlockPos armedBed = null;

    private int armTimer = 0;

    private int timer = 0;

    private int originalSlot = -1;

    private float spoofPrevYaw = 0.0f;

    private float spoofPrevPitch = 0.0f;

    private boolean rotationSpoofed = false;

    public BedAura() {
        super("BedAura", Category.COMBAT);
        setDescription("Places and detonates beds to damage nearby players");
        addSetting(range);
        addSetting(delay);
        addSetting(detonateDelay);
        addSetting(maxSelfDamage);
        addSetting(minHealth);
        addSetting(antiSuicide);
        addSetting(autoSwitch);
        addSetting(rotate);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        timer = 0;
        originalSlot = -1;
        armedBed = null;
        armTimer = 0;
        rotationSpoofed = false;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        restoreSlot();
        armedBed = null;
        armTimer = 0;
        rotationSpoofed = false;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        int dimension = mc.player.dimension;
        if (dimension != -1 && dimension != 1) {
            armedBed = null;
            return;
        }
        if (!CombatUtils.isWeaponReady(0.8f))
            return;
        if (armedBed != null) {
            if (isBedAt(armedBed)) {
                armTimer++;
                if (armTimer >= detonateDelay.getValue().intValue()) {
                    detonateBed(armedBed);
                }
            } else {
                armedBed = null;
                armTimer = 0;
            }
            return;
        }
        timer++;
        if (timer < delay.getValue().intValue())
            return;
        if (PlayerUtils.getTotalHealth() < minHealth.getValue())
            return;
        Entity target = EntityUtils.getClosestEntity(new EntityUtils.TargetSettings().setRange(range.getValue().floatValue()).setTargetPlayers(true).setTargetMonsters(true));
        if (target == null)
            return;
        FindItemResult bed = InvUtils.findInHotbar(Item.getItemFromBlock(Blocks.BED));
        if (!bed.found())
            return;
        BlockPos targetPos = new BlockPos(target);
        BlockPos placePos = findBedPlacePos(targetPos);
        if (placePos == null)
            return;
        float selfDmg = ExplosionDamageUtil.predictBedDamage(mc.player, placePos.getX() + 0.5, placePos.getY() + 0.5, placePos.getZ() + 0.5);
        if (selfDmg > maxSelfDamage.getValue())
            return;
        if (antiSuicide.getValue() && PlayerUtils.getTotalHealth() - selfDmg <= 0) {
            return;
        }
        if (autoSwitch.getValue()) {
            originalSlot = InventoryManager.getCurrentSlot();
            InventoryManager.switchToSlot(bed.slot());
        }
        EnumFacing face = BlockUtils.getDirectionBetween(placePos, targetPos);
        if (face != null) {
            if (rotate.getValue()) {
                rotateTo(placePos);
            }
            client.utils.world.InteractionUtils.placeBlock(placePos.down(), net.minecraft.util.EnumFacing.UP);
            restoreRotation();
            timer = 0;
            armedBed = placePos;
            armTimer = 0;
        }
        restoreSlot();
    }

    private void detonateBed(BlockPos pos) {
        int heldSlot = mc.player.inventory.currentItem;
        if (heldSlot >= 0 && heldSlot < 9 && mc.player.inventory.getStackInSlot(heldSlot) != null && mc.player.inventory.getStackInSlot(heldSlot).getItem() == Item.getItemFromBlock(Blocks.BED)) {
            int safeSlot = -1;
            for (int i = 0; i < 9; i++) {
                net.minecraft.item.ItemStack s = mc.player.inventory.getStackInSlot(i);
                if (s == null || s.func_190926_b() || s.getItem() != Item.getItemFromBlock(Blocks.BED)) {
                    safeSlot = i;
                    break;
                }
            }
            if (safeSlot == -1) {
                detonateWithHand(pos, EnumHand.OFF_HAND);
                return;
            }
            if (originalSlot == -1)
                originalSlot = heldSlot;
            mc.player.inventory.currentItem = safeSlot;
        }
        detonateWithHand(pos, EnumHand.MAIN_HAND);
    }

    private void detonateWithHand(BlockPos pos, EnumHand hand) {
        if (!nullCheck())
            return;
        if (!isBedAt(pos))
            return;
        if (rotate.getValue()) {
            rotateTo(pos);
        }
        Vec3d hitVec = new Vec3d(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
        mc.playerController.processRightClickBlock(mc.player, mc.world, pos, EnumFacing.UP, hitVec, hand);
        mc.player.swingArm(hand);
        restoreRotation();
        armedBed = null;
        armTimer = 0;
        restoreSlot();
    }

    private void rotateTo(BlockPos pos) {
        if (mc.player == null)
            return;
        Vec3d center = new Vec3d(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
        float[] rotations = RotationUtils.getNeededRotations(center);
        spoofPrevYaw = mc.player.rotationYaw;
        spoofPrevPitch = mc.player.rotationPitch;
        rotationSpoofed = true;
        mc.player.rotationYaw = rotations[0];
        mc.player.rotationPitch = rotations[1];
    }

    private void restoreRotation() {
        if (rotationSpoofed && mc.player != null) {
            mc.player.rotationYaw = spoofPrevYaw;
            mc.player.rotationPitch = spoofPrevPitch;
        }
        rotationSpoofed = false;
    }

    private boolean isBedAt(BlockPos pos) {
        if (mc.world == null || pos == null)
            return false;
        return mc.world.getBlockState(pos).getBlock() == Blocks.BED;
    }

    private BlockPos findBedPlacePos(BlockPos targetPos) {
        BlockPos[] offsets = { targetPos.north(), targetPos.south(), targetPos.east(), targetPos.west(), targetPos.north().up(), targetPos.south().up() };
        for (BlockPos pos : offsets) {
            if (WorldUtils.isReplaceable(pos) && WorldUtils.isSolid(pos.down())) {
                return pos;
            }
        }
        return null;
    }

    private void restoreSlot() {
        if (mc.player != null && originalSlot != -1) {
            InventoryManager.switchToSlot(originalSlot);
            originalSlot = -1;
        }
    }
}
