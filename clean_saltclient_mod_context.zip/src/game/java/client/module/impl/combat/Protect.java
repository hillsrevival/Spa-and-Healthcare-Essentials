package client.module.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.Vec3d;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.combat.TargetSelector;
import client.utils.movement.RotationUtils;
import client.utils.combat.CombatUtils;
import client.utils.world.PacketUtils;
import client.utils.combat.CombatAttackExecutor;

public class Protect extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 3.03, 1.0, 3.03);

    private final NumberSetting fov = new NumberSetting("FOV", 90.0, 30.0, 360.0);

    private final NumberSetting rotSpeed = new NumberSetting("Rot Speed", 40.0, 10.0, 180.0);

    private final NumberSetting minCPS = new NumberSetting("Min CPS", 8.0, 1.0, 12.0);

    private final NumberSetting maxCPS = new NumberSetting("Max CPS", 12.0, 1.0, 12.0);

    private final NumberSetting minCooldown = new NumberSetting("Min Cooldown", 50.0, 0.0, 100.0);

    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 1.0, 0.0, 10.0);

    private final BooleanSetting swing = new BooleanSetting("Swing Arm", true);

    private int delayCounter = 0;

    private final CombatUtils.AttackTimer attackTimer = new CombatUtils.AttackTimer();

    public Protect() {
        super("Protect", Category.COMBAT);
        setDescription("Attacks entities that hit you");
        addSetting(range);
        addSetting(fov);
        addSetting(rotSpeed);
        addSetting(minCPS);
        addSetting(maxCPS);
        addSetting(minCooldown);
        addSetting(switchDelay);
        addSetting(swing);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.player.hurtTime <= 0) {
            delayCounter = 0;
            return;
        }
        if (delayCounter > 0) {
            delayCounter--;
            return;
        }
        float threshold = (float) (minCooldown.getValue() / 100.0F);
        if (!CombatUtils.isWeaponReady(threshold))
            return;
        if (!attackTimer.canAttack((int) (double) minCPS.getValue(), (int) (double) maxCPS.getValue()))
            return;
        TargetSelector.Criteria c = new TargetSelector.Criteria();
        c.targetPlayers = true;
        c.targetHostile = true;
        c.targetPassive = true;
        c.targetInvisible = true;
        c.hitThroughWalls = false;
        c.range = range.getValue();
        c.fov = fov.getValue();
        c.aimLeadTicks = -1.0;
        EntityLivingBase target = TargetSelector.selectTarget(c, "Distance");
        if (target == null)
            return;
        float speed = rotSpeed.getValue().floatValue();
        Vec3d aimPoint = new Vec3d(target.posX, target.posY + (double) target.getEyeHeight() * 0.6, target.posZ);
        float[] neededRot = RotationUtils.getNeededRotations(aimPoint);
        float[] needed = RotationUtils.smoothRotate(mc.player.rotationYaw, mc.player.rotationPitch, neededRot[0], neededRot[1], speed);
        float[] fixed = RotationUtils.fixRotations(needed[0], needed[1]);
        if (!RotationUtils.isRotationOnEntity(fixed[0], fixed[1], target, range.getValue()))
            return;
        float prevYaw = mc.player.rotationYaw;
        float prevPitch = mc.player.rotationPitch;
        if (mc.player.connection != null) {
            PacketUtils.sendRotation(fixed[0], fixed[1], mc.player.onGround);
        }
        mc.player.rotationYaw = fixed[0];
        mc.player.rotationPitch = fixed[1];
        CombatAttackExecutor.directAttack(target, range.getValue(), swing.getValue());
        mc.player.rotationYaw = prevYaw;
        mc.player.rotationPitch = prevPitch;
        RotationUtils.resetRotation();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        RotationUtils.resetRotation();
        delayCounter = 0;
    }
}
