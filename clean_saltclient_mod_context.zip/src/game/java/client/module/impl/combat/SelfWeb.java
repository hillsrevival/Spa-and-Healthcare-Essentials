package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;
import client.utils.misc.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class SelfWeb extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Mode", "Normal", "Normal", "Smart");

    private final BooleanSetting doubles = new BooleanSetting("DoublePlace", false);

    private final BooleanSetting turnOff = new BooleanSetting("AutoToggle", true);

    public SelfWeb() {
        super("SelfWeb", Category.COMBAT);
        setDescription("Places webs at your own feet to prevent crystal damage");
        addSetting(mode);
        addSetting(doubles);
        addSetting(turnOff);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mode.getValue().equals("Smart")) {
            client.utils.combat.TargetSelector.Criteria c = new client.utils.combat.TargetSelector.Criteria();
            c.targetPlayers = true;
            c.targetHostile = false;
            c.targetPassive = false;
            c.targetInvisible = true;
            c.hitThroughWalls = true;
            c.range = 6.0;
            c.fov = 360.0;
            c.aimLeadTicks = -1.0;
            if (client.utils.combat.TargetSelector.selectTarget(c, "Distance") == null) {
                return;
            }
        }
        placeWeb();
    }

    private void placeWeb() {
        int webSlot = findItemInHotbar(Item.getItemFromBlock(Blocks.WEB));
        if (webSlot == -1) {
            ChatUtils.warning("No webs in hotbar");
            if (turnOff.getValue())
                toggle();
            return;
        }
        BlockPos feetPos = new BlockPos(mc.player);
        BlockPos headPos = feetPos.up();
        int savedSlot = mc.player.inventory.currentItem;
        mc.player.inventory.currentItem = webSlot;
        mc.player.connection.sendPacket(new net.minecraft.network.play.client.CPacketHeldItemChange(webSlot));
        placeBlockAt(feetPos);
        if (doubles.getValue()) {
            placeBlockAt(headPos);
        }
        mc.player.inventory.currentItem = savedSlot;
        mc.player.connection.sendPacket(new net.minecraft.network.play.client.CPacketHeldItemChange(savedSlot));
        if (turnOff.getValue()) {
            toggle();
        }
    }

    private void placeBlockAt(BlockPos pos) {
        for (EnumFacing face : EnumFacing.values()) {
            BlockPos neighbor = pos.offset(face);
            if (WorldUtils.isAir(neighbor))
                continue;
            if (WorldUtils.isAir(pos)) {
                Vec3d hitVec = new Vec3d(neighbor.getX() + 0.5, neighbor.getY() + 0.5, neighbor.getZ() + 0.5);
                InteractionUtils.placeBlock(neighbor, face.getOpposite(), hitVec, net.minecraft.util.EnumHand.MAIN_HAND);
                return;
            }
        }
    }

    private int findItemInHotbar(Item item) {
        client.utils.player.FindItemResult r = client.utils.player.InvUtils.findInHotbar(item);
        return r.found() ? r.slot() - client.utils.player.SlotUtils.HOTBAR_START : -1;
    }
}
