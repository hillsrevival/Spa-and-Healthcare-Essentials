package client.module.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class AutoLeave extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting health = new NumberSetting("Health", 4.0, 1.0, 19.0);

    public AutoLeave() {
        super("AutoLeave", Category.COMBAT);
        setDescription("Automatically leaves the server when your health is low");
        addSetting(health);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (mc.player.capabilities.isCreativeMode)
            return;
        if (mc.isSingleplayer())
            return;
        if (mc.getConnection() != null && mc.getConnection().getPlayerInfoMap().size() <= 1)
            return;
        float threshold = health.getValue().floatValue();
        if (mc.player.getHealth() + mc.player.getAbsorptionAmount() <= threshold) {
            mc.world.sendQuittingDisconnectingPacket();
            mc.loadWorld(null);
            toggle();
        }
    }
}
