package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class HoleFiller extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 4.0, 1.0, 6.0);

    private final BooleanSetting rotate = new BooleanSetting("Rotate", true);

    public HoleFiller() {
        super("HoleFiller", Category.COMBAT);
        setDescription("Fills in holes around you with blocks");
        addSetting(range);
        addSetting(rotate);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        int blockSlot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (stack != null && !stack.func_190926_b() && stack.getItem() instanceof net.minecraft.item.ItemBlock) {
                blockSlot = i;
                break;
            }
        }
        if (blockSlot == -1)
            return;
        double px = mc.player.posX;
        double py = mc.player.posY;
        double pz = mc.player.posZ;
        double rangeD = range.getValue().doubleValue();
        int rangeI = (int) Math.ceil(rangeD);
        for (int x = -rangeI; x <= rangeI; x++) {
            for (int z = -rangeI; z <= rangeI; z++) {
                int checkX = (int) Math.floor(px) + x;
                int checkZ = (int) Math.floor(pz) + z;
                int checkY = (int) Math.floor(py);
                double dx = checkX + 0.5 - px;
                double dz = checkZ + 0.5 - pz;
                if (dx * dx + dz * dz > range.getValue() * range.getValue())
                    continue;
                if (checkX == (int) Math.floor(px) && checkZ == (int) Math.floor(pz) && WorldUtils.isAir(new BlockPos((int) Math.floor(px), checkY, (int) Math.floor(pz))))
                    continue;
                BlockPos pos = new BlockPos(checkX, checkY, checkZ);
                if (!WorldUtils.isAir(pos))
                    continue;
                if (!WorldUtils.isAir(pos.up()))
                    continue;
                int solidWalls = 0;
                if (mc.world.isBlockFullCube(pos.down())) {
                    for (EnumFacing facing : new EnumFacing[] { EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.EAST, EnumFacing.WEST }) {
                        if (mc.world.isBlockFullCube(pos.offset(facing))) {
                            solidWalls++;
                        }
                    }
                }
                if (solidWalls >= 3) {
                    int savedSlot = mc.player.inventory.currentItem;
                    mc.player.inventory.currentItem = blockSlot;
                    if (rotate.getValue()) {
                        Vec3d hitVec = new Vec3d(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
                        InteractionUtils.placeBlock(pos.down(), EnumFacing.UP, hitVec, EnumHand.MAIN_HAND);
                    } else {
                        Vec3d hitVec = new Vec3d(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
                        InteractionUtils.placeBlock(pos.down(), EnumFacing.UP, hitVec, EnumHand.MAIN_HAND);
                    }
                    mc.player.inventory.currentItem = savedSlot;
                    return;
                }
            }
        }
    }
}
