package client.module.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import client.utils.misc.TickTimer;
import client.utils.player.FindItemResult;
import client.utils.player.InvUtils;
import client.utils.player.SlotUtils;
import java.util.Random;

public class AutoSoup extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Random rand = new Random();

    private final NumberSetting health = new NumberSetting("Health", 10.0, 1.0, 19.0);

    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 2.0, 0.0, 10.0);

    private final BooleanSetting dropBowl = new BooleanSetting("Drop Bowl", true);

    private final client.utils.player.PendingSlotSwitch switcher = new client.utils.player.PendingSlotSwitch();

    private boolean eating = false;

    private int inactiveTicks = 0;

    public AutoSoup() {
        super("AutoSoup", Category.COMBAT);
        setDescription("Automatically eats soup or stew when your health is low");
        addSetting(health);
        addSetting(switchDelay);
        addSetting(dropBowl);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (switcher.hasPending()) {
            if (switcher.tick()) {
                switcher.applySwitch();
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
                eating = true;
                inactiveTicks = 0;
            }
            return;
        }
        if (eating) {
            if (!mc.player.isHandActive()) {
                inactiveTicks++;
                if (inactiveTicks >= 3) {
                    stopEating();
                }
            } else {
                inactiveTicks = 0;
            }
            return;
        }
        if (mc.player.getHealth() > health.getValue().floatValue())
            return;
        if (mc.currentScreen != null)
            return;
        if (mc.player.isHandActive())
            return;
        if (!mc.player.getFoodStats().needFood())
            return;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held != null && isSoup(held)) {
            switcher.queue(mc.player.inventory.currentItem, switchDelay.getValue().intValue());
            return;
        }
        FindItemResult hotbarSoup = InvUtils.findInHotbar(stack -> stack != null && isSoup(stack));
        if (hotbarSoup.found()) {
            switcher.queue(hotbarSoup.slot() - SlotUtils.HOTBAR_START, switchDelay.getValue().intValue());
            return;
        }
        FindItemResult invSoup = InvUtils.find(stack -> stack != null && isSoup(stack));
        if (invSoup.found() && SlotUtils.isMain(invSoup.slot())) {
            InvUtils.shiftClick(invSoup.slot());
        }
    }

    private void stopEating() {
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
        if (mc.player != null) {
            if (dropBowl.getValue()) {
                ItemStack held = mc.player.getHeldItemMainhand();
                if (held != null && held.getItem() == Items.BOWL) {
                    InvUtils.drop(SlotUtils.HOTBAR_START + mc.player.inventory.currentItem);
                }
            }
            switcher.restore();
        }
        eating = false;
        inactiveTicks = 0;
    }

    private static boolean isSoup(ItemStack stack) {
        Item item = stack.getItem();
        return item == Items.MUSHROOM_STEW || item == Items.RABBIT_STEW || item == Items.BEETROOT_SOUP;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        stopEating();
    }
}
