package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.NumberSetting;
import client.utils.combat.CombatUtils;
import client.utils.world.MaceUtils;
import client.utils.movement.RotationUtils;
import client.utils.player.InvUtils;
import client.utils.player.SlotUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import client.utils.EntityUtils;

public class ShieldMacro extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Mode", "AutoBlock", "AutoBlock", "Toggle");

    private final BooleanSetting offhandMode = new BooleanSetting("Offhand", false);

    private final NumberSetting detectRange = new NumberSetting("DetectRange", 4.0, 1.0, 6.0);

    private final NumberSetting detectFOV = new NumberSetting("DetectFOV", 180.0, 30.0, 360.0);

    private final BooleanSetting targetPlayers = new BooleanSetting("TargetPlayers", true);

    private final BooleanSetting targetMobs = new BooleanSetting("TargetMobs", true);

    private final BooleanSetting targetAnimals = new BooleanSetting("TargetAnimals", false);

    private final NumberSetting raiseDelay = new NumberSetting("RaiseDelay", 0.0, 0.0, 5.0);

    private final NumberSetting dropDelay = new NumberSetting("DropDelay", 1.0, 0.0, 5.0);

    private final NumberSetting reRaiseDelay = new NumberSetting("ReRaiseDelay", 2.0, 0.0, 10.0);

    private final NumberSetting swapDelay = new NumberSetting("SwapDelay", 0.0, 0.0, 5.0);

    private final ModeSetting shieldSlotMode = new ModeSetting("ShieldSlot", "Auto", "Auto", "1", "2", "3", "4", "5", "6", "7", "8", "9");

    private static final int STATE_IDLE = 0;

    private static final int STATE_RAISING = 1;

    private static final int STATE_BLOCKING = 2;

    private static final int STATE_DROPPING = 3;

    private static final int STATE_RE_RAISING = 4;

    private int state = STATE_IDLE;

    private int stateTimer = 0;

    private int savedSlot = -1;

    private boolean offhandHeldShield = false;

    private ItemStack savedOffhand = null;

    private int savedShieldSlot = -1;

    public ShieldMacro() {
        super("ShieldMacro", Category.COMBAT);
        setDescription("Uses your shield whenever you're about to get hit");
        addSetting(mode);
        addSetting(offhandMode);
        addSetting(detectRange);
        addSetting(detectFOV);
        addSetting(targetPlayers);
        addSetting(targetMobs);
        addSetting(targetAnimals);
        addSetting(raiseDelay);
        addSetting(dropDelay);
        addSetting(reRaiseDelay);
        addSetting(swapDelay);
        addSetting(shieldSlotMode);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        resetState();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        restoreOriginalSlot();
        restoreOffhand();
        resetState();
    }

    private void resetState() {
        state = STATE_IDLE;
        stateTimer = 0;
        savedSlot = -1;
        offhandHeldShield = false;
        savedOffhand = null;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (stateTimer > 0) {
            stateTimer--;
        }
        Entity threat = findNearestThreat();
        switch(state) {
            case STATE_IDLE:
                handleIdle(threat);
                break;
            case STATE_RAISING:
                handleRaising();
                break;
            case STATE_BLOCKING:
                handleBlocking(threat);
                break;
            case STATE_DROPPING:
                handleDropping(threat);
                break;
            case STATE_RE_RAISING:
                handleReRaising(threat);
                break;
        }
    }

    private void handleIdle(Entity threat) {
        if (threat == null)
            return;
        int delay = humanize(raiseDelay.getValue().intValue());
        if (delay <= 0) {
            raiseShield();
            state = STATE_BLOCKING;
        } else {
            state = STATE_RAISING;
            stateTimer = delay;
        }
    }

    private void handleRaising() {
        if (stateTimer <= 0) {
            raiseShield();
            state = STATE_BLOCKING;
        }
    }

    private void handleBlocking(Entity threat) {
        if (threat == null) {
            restoreOriginalSlot();
            restoreOffhand();
            state = STATE_IDLE;
            return;
        }
        if (mode.getValue().equals("Toggle") && mc.player.swingProgress > 0.0F) {
            dropShield();
            state = STATE_DROPPING;
            stateTimer = humanize(dropDelay.getValue().intValue());
        }
    }

    private void handleDropping(Entity threat) {
        if (stateTimer <= 0) {
            raiseShield();
            state = STATE_RE_RAISING;
            stateTimer = humanize(reRaiseDelay.getValue().intValue());
        }
    }

    private void handleReRaising(Entity threat) {
        if (stateTimer <= 0) {
            raiseShield();
            if (threat != null) {
                state = STATE_BLOCKING;
            } else {
                restoreOriginalSlot();
                restoreOffhand();
                state = STATE_IDLE;
            }
        }
    }

    private void raiseShield() {
        if (mc.player == null)
            return;
        int shield = resolveShieldSlot();
        if (shield == -1)
            return;
        if (offhandMode.getValue()) {
            ItemStack currentOffhand = mc.player.getHeldItemOffhand();
            if (currentOffhand != null && !currentOffhand.func_190926_b() && savedOffhand == null) {
                savedOffhand = currentOffhand.copy();
            }
            if (currentOffhand != null && currentOffhand.getItem() == Items.SHIELD) {
                offhandHeldShield = true;
                return;
            }
            int containerSlot = shield + SlotUtils.HOTBAR_START;
            InvUtils.moveToOffhand(containerSlot);
            savedShieldSlot = containerSlot;
            offhandHeldShield = true;
            net.minecraft.client.settings.KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
            int delay = humanize(swapDelay.getValue().intValue());
            if (delay > 0) {
                stateTimer += delay;
            }
        } else {
            if (shield != mc.player.inventory.currentItem) {
                if (savedSlot == -1) {
                    savedSlot = mc.player.inventory.currentItem;
                }
                mc.player.inventory.currentItem = shield;
            }
        }
        net.minecraft.client.settings.KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
    }

    private void dropShield() {
        if (mc.player == null)
            return;
        net.minecraft.client.settings.KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
        if (!offhandMode.getValue()) {
            restoreOriginalSlot();
        }
    }

    private void restoreOriginalSlot() {
        net.minecraft.client.settings.KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
        if (savedSlot != -1 && mc.player != null) {
            mc.player.inventory.currentItem = savedSlot;
            savedSlot = -1;
        }
    }

    private void restoreOffhand() {
        if (!offhandHeldShield || mc.player == null)
            return;
        if (savedShieldSlot != -1) {
            InvUtils.moveToOffhand(savedShieldSlot);
        }
        savedShieldSlot = -1;
        offhandHeldShield = false;
        savedOffhand = null;
    }

    private Entity findNearestThreat() {
        if (mc.player == null || mc.world == null)
            return null;
        double range = detectRange.getValue().doubleValue();
        float fov = detectFOV.getValue().floatValue();
        Entity best = null;
        double bestDist = range;
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (entity == mc.player)
                continue;
            if (!entity.isEntityAlive())
                continue;
            if (!(entity instanceof EntityLivingBase))
                continue;
            EntityLivingBase living = (EntityLivingBase) entity;
            if (living.getHealth() <= 0)
                continue;
            if (!isValidTargetType(living))
                continue;
            double dist = CombatUtils.getReachDistance(living);
            if (dist > bestDist)
                continue;
            if (fov < 360.0F) {
                float angle = RotationUtils.getAngleToClientRotation(new Vec3d(entity.posX, entity.posY + entity.getEyeHeight() / 2.0, entity.posZ));
                if (angle > fov / 2.0F)
                    continue;
            }
            if (!isEntityFacingUs(living))
                continue;
            bestDist = dist;
            best = entity;
        }
        return best;
    }

    private boolean isEntityFacingUs(EntityLivingBase entity) {
        if (mc.player == null)
            return false;
        double dx = mc.player.posX - entity.posX;
        double dz = mc.player.posZ - entity.posZ;
        float entityYaw = entity.rotationYaw;
        float angleToUs = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
        float diff = Math.abs(RotationUtils.wrapDegrees(entityYaw - angleToUs));
        return diff < 60.0F;
    }

    private boolean isValidTargetType(EntityLivingBase entity) {
        if (entity instanceof EntityPlayer) {
            return targetPlayers.getValue();
        } else if (entity instanceof net.minecraft.entity.monster.EntityMob || entity instanceof net.minecraft.entity.monster.EntitySlime) {
            return targetMobs.getValue();
        } else if (entity instanceof net.minecraft.entity.passive.EntityAnimal || entity instanceof net.minecraft.entity.passive.EntityAmbientCreature || entity instanceof net.minecraft.entity.passive.EntityWaterMob || entity instanceof net.minecraft.entity.monster.EntityGolem) {
            return targetAnimals.getValue();
        }
        return targetMobs.getValue();
    }

    private int resolveShieldSlot() {
        String mode = shieldSlotMode.getValue();
        if (mode.equals("Auto")) {
            return MaceUtils.findShieldSlot();
        }
        int slot = Integer.parseInt(mode) - 1;
        return (slot >= 0 && slot <= 8) ? slot : -1;
    }

    private int humanize(int baseDelay) {
        if (baseDelay <= 0)
            return 0;
        return baseDelay + (Math.random() < 0.3 ? 1 : 0);
    }
}
