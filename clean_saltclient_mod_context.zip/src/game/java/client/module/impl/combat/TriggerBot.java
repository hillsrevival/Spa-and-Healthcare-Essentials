package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.utils.combat.CombatUtils;
import client.utils.misc.FriendManager;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import client.utils.combat.CombatAttackExecutor;
import client.utils.world.InteractionUtils;
import net.minecraft.util.math.RayTraceResult;

public class TriggerBot extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting minCooldown = new NumberSetting("Min Cooldown", 50.0, 0.0, 100.0);

    private final BooleanSetting targetPlayers = new BooleanSetting("Target Players", true);

    private final ModeSetting mobMode = new ModeSetting("Mobs", "Hostile", "Hostile", "Passive", "Both");

    private final BooleanSetting targetInvisible = new BooleanSetting("Target Invisible", true);

    private final BooleanSetting swingArm = new BooleanSetting("Swing Arm", true);

    private final BooleanSetting dynamicReach = new BooleanSetting("Dynamic Reach", true);

    private final NumberSetting minCPS = new NumberSetting("Min CPS", 8.0, 1.0, 20.0);

    private final NumberSetting maxCPS = new NumberSetting("Max CPS", 14.0, 1.0, 20.0);

    private final CombatUtils.AttackTimer attackTimer = new CombatUtils.AttackTimer();

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT);
        setDescription("Attacks entities under your crosshair");
        addSetting(minCooldown);
        addSetting(targetPlayers);
        addSetting(mobMode);
        addSetting(targetInvisible);
        addSetting(swingArm);
        addSetting(dynamicReach);
        addSetting(minCPS);
        addSetting(maxCPS);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.currentScreen != null)
            return;
        float threshold = (float) (minCooldown.getValue() / 100.0F);
        if (!CombatUtils.isWeaponReady(threshold))
            return;
        if (!attackTimer.canAttack(minCPS.getValue().intValue(), maxCPS.getValue().intValue()))
            return;
        RayTraceResult result = mc.objectMouseOver;
        if (result == null || result.typeOfHit != RayTraceResult.Type.ENTITY)
            return;
        Entity hit = result.entityHit;
        if (!(hit instanceof EntityLivingBase))
            return;
        EntityLivingBase target = (EntityLivingBase) hit;
        if (target.hurtTime > 0)
            return;
        if (target instanceof EntityPlayer && !targetPlayers.getValue())
            return;
        if (target instanceof net.minecraft.entity.monster.IMob) {
            if (!mobMode.getValue().equals("Hostile") && !mobMode.getValue().equals("Both"))
                return;
        } else if (target instanceof EntityAnimal || (!(target instanceof EntityPlayer) && !(target instanceof net.minecraft.entity.monster.IMob))) {
            if (!mobMode.getValue().equals("Passive") && !mobMode.getValue().equals("Both"))
                return;
        }
        if (target.isInvisible() && !targetInvisible.getValue())
            return;
        if (target.isDead || target.getHealth() <= 0)
            return;
        if (FriendManager.isFriend(target))
            return;
        if (!client.utils.combat.AttackControlClaim.shouldAttack("TriggerBot", 50)) {
            return;
        }
        double reach = dynamicReach.getValue() ? client.utils.combat.ReachBalancer.getEffectiveReach(target) : 3.03;
        CombatAttackExecutor.directAttack(target, reach);
        client.utils.combat.OpponentHealthTracker.recordAttack(target, false);
    }
}
