package client.module.impl.combat;

import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.combat.AimUtils;
import client.utils.combat.CombatUtils;
import client.utils.combat.TargetSelector;
import client.utils.movement.RotationUtils;
import client.utils.combat.CombatAttackExecutor;
import client.utils.world.PacketUtils;
import client.utils.EntityUtils;

public class TPAura extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Random random = new Random();

    private final NumberSetting range = new NumberSetting("Range", 6.0, 1.0, 10.0);

    private final NumberSetting minCooldown = new NumberSetting("Min Cooldown", 50.0, 0.0, 100.0);

    private final BooleanSetting targetPlayers = new BooleanSetting("Target Players", true);

    private final BooleanSetting targetMobs = new BooleanSetting("Target Mobs", true);

    private final CombatUtils.AttackTimer attackTimer = new CombatUtils.AttackTimer();

    public TPAura() {
        super("TP-Aura", Category.COMBAT);
        setDescription("Attacks entities by teleporting to them and back");
        addSetting(range);
        addSetting(minCooldown);
        addSetting(targetPlayers);
        addSetting(targetMobs);
        handles(HandlerType.TICK, HandlerType.UPDATE);
    }

    private EntityLivingBase tickTarget = null;

    private boolean rotatedThisTick = false;

    private float prevYaw = 0.0f;

    private float prevPitch = 0.0f;

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            tickTarget = null;
            return;
        }
        EntityLivingBase target = findTarget();
        if (target == null) {
            tickTarget = null;
            return;
        }
        float threshold = (float) (minCooldown.getValue() / 100.0F);
        if (!CombatUtils.isWeaponReady(threshold)) {
            tickTarget = null;
            return;
        }
        if (!attackTimer.canAttack(4, 8)) {
            tickTarget = null;
            return;
        }
        float[] rotations = RotationUtils.getNeededRotations(AimUtils.predictAimPoint(target, RotationUtils.AimPoint.CENTER, AimUtils.getLatencyLeadTicks()));
        rotations = RotationUtils.fixRotations(rotations[0], rotations[1]);
        prevYaw = mc.player.rotationYaw;
        prevPitch = mc.player.rotationPitch;
        mc.player.rotationYaw = rotations[0];
        mc.player.rotationPitch = rotations[1];
        rotatedThisTick = true;
        tickTarget = target;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        EntityLivingBase target = tickTarget;
        tickTarget = null;
        if (target == null)
            return;
        if (!EntityUtils.isAlive(target))
            return;
        if (client.utils.misc.FriendManager.isFriend(target))
            return;
        double offsetX = random.nextInt(3) * 2 - 2;
        double offsetZ = random.nextInt(3) * 2 - 2;
        double tpX = target.posX + offsetX;
        double tpY = target.posY;
        double tpZ = target.posZ + offsetZ;
        mc.player.setPosition(tpX, tpY, tpZ);
        if (mc.player.connection != null) {
            PacketUtils.sendPosition(tpX, tpY, tpZ, mc.player.onGround);
        }
        CombatAttackExecutor.directAttack(target, range.getValue());
        client.utils.combat.OpponentHealthTracker.recordAttack(target, false);
        if (rotatedThisTick) {
            mc.player.rotationYaw = prevYaw;
            mc.player.rotationPitch = prevPitch;
            rotatedThisTick = false;
        }
        RotationUtils.resetRotation();
    }

    private EntityLivingBase findTarget() {
        TargetSelector.Criteria c = new TargetSelector.Criteria();
        c.targetPlayers = targetPlayers.getValue();
        c.targetHostile = targetMobs.getValue();
        c.targetPassive = true;
        c.targetInvisible = true;
        c.hitThroughWalls = true;
        c.range = range.getValue();
        c.fov = 360.0;
        c.aimLeadTicks = -1.0;
        return TargetSelector.selectTarget(c, "Distance");
    }

    @Override
    public void onDisable() {
        super.onDisable();
        RotationUtils.resetRotation();
    }
}
