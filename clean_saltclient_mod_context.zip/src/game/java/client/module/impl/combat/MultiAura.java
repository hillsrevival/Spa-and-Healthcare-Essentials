package client.module.impl.combat;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.EntityUtils;
import client.utils.combat.AimUtils;
import client.utils.combat.CombatAttackExecutor;
import client.utils.combat.CombatUtils;
import client.utils.combat.TargetSelector;
import client.utils.movement.RotationUtils;

public class MultiAura extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 3.03, 1.0, 4.5);

    private final NumberSetting fov = new NumberSetting("FOV", 360.0, 30.0, 360.0);

    private final NumberSetting minCooldown = new NumberSetting("Min Cooldown", 50.0, 0.0, 100.0);

    private final BooleanSetting hitThroughWalls = new BooleanSetting("Hit Through Walls", false);

    private final BooleanSetting targetPlayers = new BooleanSetting("Target Players", true);

    private final BooleanSetting targetMobs = new BooleanSetting("Target Mobs", true);

    private final BooleanSetting targetAnimals = new BooleanSetting("Target Animals", false);

    private final BooleanSetting targetInvisible = new BooleanSetting("Target Invisible", true);

    private final BooleanSetting gcdFix = new BooleanSetting("GCD Fix", true);

    private final BooleanSetting moveCorrect = new BooleanSetting("Move Correct", false);

    private final client.module.ModeSetting targetPolicy = new client.module.ModeSetting("Target Policy", "Focus", "Focus", "Round Robin");

    private final CombatUtils.AttackTimer attackTimer = new CombatUtils.AttackTimer();

    private EntityLivingBase tickTarget = null;

    private boolean rotatedThisTick = false;

    private float prevYaw = 0.0f;

    private float prevPitch = 0.0f;

    private int targetCursor = 0;

    private float savedMoveForward = 0.0f;

    private float savedMoveStrafe = 0.0f;

    private TargetSelector.Criteria criteriaCache = null;

    private int criteriaTick = -1;

    public MultiAura() {
        super("MultiAura", Category.COMBAT);
        setDescription("Attacks multiple targets at the same time");
        addSetting(range);
        addSetting(fov);
        addSetting(minCooldown);
        addSetting(hitThroughWalls);
        addSetting(targetPlayers);
        addSetting(targetMobs);
        addSetting(targetAnimals);
        addSetting(targetInvisible);
        addSetting(gcdFix);
        addSetting(moveCorrect);
        addSetting(targetPolicy);
        handles(HandlerType.TICK, HandlerType.UPDATE);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            tickTarget = null;
            return;
        }
        client.utils.combat.OpponentTracker.configure(range.getValue(), 360.0, targetPlayers.getValue(), targetMobs.getValue(), targetAnimals.getValue(), targetInvisible.getValue(), hitThroughWalls.getValue(), "Distance");
        client.utils.combat.OpponentTracker.update();
        float threshold = (float) (minCooldown.getValue() / 100.0F);
        if (!CombatUtils.isWeaponReady(threshold)) {
            tickTarget = null;
            return;
        }
        if (!attackTimer.canAttack(6, 12)) {
            tickTarget = null;
            return;
        }
        List<EntityLivingBase> targets = getTargets();
        if (targets.isEmpty()) {
            tickTarget = null;
            return;
        }
        EntityLivingBase entity;
        if (targetPolicy.getValue().equals("Round Robin")) {
            entity = targets.get(Math.floorMod(targetCursor++, targets.size()));
        } else {
            entity = pickFocusTarget(targets);
        }
        Vec3d aimPoint = AimUtils.predictAimPoint(entity, RotationUtils.AimPoint.CENTER, AimUtils.getLatencyLeadTicks());
        float[] rotations = RotationUtils.getNeededRotations(aimPoint);
        if (gcdFix.getValue()) {
            rotations = RotationUtils.fixRotations(rotations[0], rotations[1]);
        }
        prevYaw = mc.player.rotationYaw;
        prevPitch = mc.player.rotationPitch;
        savedMoveForward = mc.player.movementInput.field_192832_b;
        savedMoveStrafe = mc.player.movementInput.moveStrafe;
        mc.player.rotationYaw = rotations[0];
        mc.player.rotationPitch = rotations[1];
        if (moveCorrect.getValue()) {
            float[] corrected = RotationUtils.correctMovement(savedMoveForward, savedMoveStrafe, prevYaw, rotations[0]);
            mc.player.movementInput.field_192832_b = corrected[0];
            mc.player.movementInput.moveStrafe = corrected[1];
        }
        rotatedThisTick = true;
        tickTarget = entity;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (tickTarget == null) {
            if (rotatedThisTick) {
                mc.player.rotationYaw = prevYaw;
                mc.player.rotationPitch = prevPitch;
                rotatedThisTick = false;
            }
            return;
        }
        EntityLivingBase target = tickTarget;
        tickTarget = null;
        if (!EntityUtils.isAlive(target) || !CombatUtils.isReachValid(target, range.getValue())) {
            mc.player.rotationYaw = prevYaw;
            mc.player.rotationPitch = prevPitch;
            rotatedThisTick = false;
            return;
        }
        if (!client.utils.combat.AttackControlClaim.shouldAttack("MultiAura", 80)) {
            mc.player.rotationYaw = prevYaw;
            mc.player.rotationPitch = prevPitch;
            rotatedThisTick = false;
            return;
        }
        if (CombatAttackExecutor.directAttack(target, range.getValue())) {
            boolean crit = AimUtils.isCritPossibleExtended();
            client.utils.combat.OpponentHealthTracker.recordAttack(target, crit);
        }
        mc.player.rotationYaw = prevYaw;
        mc.player.rotationPitch = prevPitch;
        if (moveCorrect.getValue()) {
            mc.player.movementInput.field_192832_b = savedMoveForward;
            mc.player.movementInput.moveStrafe = savedMoveStrafe;
        }
        rotatedThisTick = false;
        RotationUtils.resetRotation();
    }

    private List<EntityLivingBase> getTargets() {
        int tick = mc.player != null ? mc.player.ticksExisted : -1;
        if (criteriaCache == null || criteriaTick != tick) {
            criteriaTick = tick;
            criteriaCache = new TargetSelector.Criteria();
            criteriaCache.targetPlayers = targetPlayers.getValue();
            criteriaCache.targetHostile = targetMobs.getValue();
            criteriaCache.targetPassive = targetAnimals.getValue();
            criteriaCache.targetInvisible = targetInvisible.getValue();
            criteriaCache.hitThroughWalls = hitThroughWalls.getValue();
            criteriaCache.range = range.getValue();
            criteriaCache.fov = fov.getValue();
            criteriaCache.aimLeadTicks = -1.0;
        }
        return TargetSelector.getValidTargets(criteriaCache);
    }

    private EntityLivingBase pickFocusTarget(List<EntityLivingBase> targets) {
        EntityLivingBase best = null;
        double bestScore = Double.MAX_VALUE;
        for (EntityLivingBase t : targets) {
            float health = t.getHealth();
            if (t instanceof EntityPlayer) {
                health += ((EntityPlayer) t).getAbsorptionAmount();
            }
            double dist = CombatUtils.getReachDistance(t);
            double score = (health / 4.0) + dist * 0.05;
            if (score < bestScore) {
                bestScore = score;
                best = t;
            }
        }
        return best;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        tickTarget = null;
        rotatedThisTick = false;
        RotationUtils.resetRotation();
    }
}
