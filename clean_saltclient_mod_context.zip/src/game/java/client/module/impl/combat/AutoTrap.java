package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;
import client.utils.EntityUtils;

public class AutoTrap extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 4.0, 2.0, 6.0);

    private final NumberSetting delay = new NumberSetting("Delay", 2.0, 0.0, 10.0);

    private int tickCounter = 0;

    public AutoTrap() {
        super("AutoTrap", Category.COMBAT);
        setDescription("Places blocks around a player to trap them");
        addSetting(range);
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        tickCounter++;
        int delayTicks = delay.getValue().intValue();
        if (delayTicks > 0 && tickCounter % delayTicks != 0)
            return;
        client.utils.combat.TargetSelector.Criteria c = new client.utils.combat.TargetSelector.Criteria();
        c.targetPlayers = true;
        c.targetHostile = false;
        c.targetPassive = false;
        c.targetInvisible = true;
        c.hitThroughWalls = true;
        c.range = range.getValue();
        c.fov = 360.0;
        c.aimLeadTicks = -1.0;
        EntityPlayer target = (EntityPlayer) client.utils.combat.TargetSelector.selectTarget(c, "Distance");
        if (target == null)
            return;
        int blockSlot = findBlockSlot();
        if (blockSlot == -1)
            return;
        int savedSlot = mc.player.inventory.currentItem;
        double tx = target.posX;
        double ty = target.posY;
        double tz = target.posZ;
        BlockPos[] positions = { new BlockPos(tx, ty - 1, tz), new BlockPos(tx + 1, ty, tz), new BlockPos(tx - 1, ty, tz), new BlockPos(tx, ty, tz + 1), new BlockPos(tx, ty, tz - 1) };
        boolean placed = false;
        for (BlockPos pos : positions) {
            if (WorldUtils.isAir(pos) || WorldUtils.getBlock(pos) == Blocks.AIR) {
                mc.player.inventory.currentItem = blockSlot;
                EnumFacing dir = getPlaceableSide(pos);
                if (dir != null) {
                    BlockPos neighbor = pos.offset(dir);
                    InteractionUtils.placeBlock(neighbor, dir.getOpposite(), client.utils.world.BlockUtils.faceCenter(neighbor, dir.getOpposite()), EnumHand.MAIN_HAND);
                    placed = true;
                    break;
                }
            }
        }
        mc.player.inventory.currentItem = savedSlot;
    }

    private int findBlockSlot() {
        client.utils.player.FindItemResult r = client.utils.player.InvUtils.findInHotbar(stack -> stack != null && !stack.func_190926_b() && stack.getItem() instanceof ItemBlock);
        return r.found() ? r.slot() - client.utils.player.SlotUtils.HOTBAR_START : -1;
    }

    private EnumFacing getPlaceableSide(BlockPos pos) {
        return client.utils.world.BlockUtils.findPlaceableSide(pos);
    }
}
