package client.module.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemBow;
import net.minecraft.util.math.Vec3d;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.combat.TargetSelector;
import client.utils.movement.RotationUtils;
import client.utils.EntityUtils;

public class BowAimbot extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting fov = new NumberSetting("FOV", 90.0, 30.0, 360.0);

    private final BooleanSetting predict = new BooleanSetting("Predict", true);

    private final NumberSetting speed = new NumberSetting("Speed", 30.0, 5.0, 360.0);

    private final BooleanSetting gcdFix = new BooleanSetting("GCD Fix", true);

    private EntityLivingBase target;

    public BowAimbot() {
        super("BowAimbot", Category.COMBAT);
        setDescription("Aims your bow at entities");
        addSetting(fov);
        addSetting(predict);
        addSetting(speed);
        addSetting(gcdFix);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!mc.player.isHandActive()) {
            target = null;
            return;
        }
        if (mc.player.getHeldItemMainhand() == null || !(mc.player.getHeldItemMainhand().getItem() instanceof ItemBow)) {
            target = null;
            return;
        }
        if (target != null && !EntityUtils.isAlive(target)) {
            target = null;
        }
        if (target != null) {
            double distToTarget = mc.player.getDistanceToEntity(target);
            if (distToTarget > 50.0 || getAngleToTarget(target) > fov.getValue() / 2.0) {
                target = null;
            }
        }
        if (target == null) {
            target = findTarget();
            if (target == null)
                return;
        }
        double d = mc.player.getDistanceToEntity(target);
        float velocity = (72000.0f - mc.player.getItemInUseCount()) / 20.0f;
        velocity = (velocity * velocity + velocity * 2.0f) / 3.0f;
        if (velocity > 1)
            velocity = 1;
        double arrowSpeed = velocity * 3.0;
        double posX = target.posX;
        double posY = target.posY + target.height * 0.5;
        double posZ = target.posZ;
        if (predict.getValue()) {
            int arrowTicks = client.utils.combat.ProjectilePitchUtil.calculateTimeToTarget(target, arrowSpeed);
            if (arrowTicks > 0 && arrowTicks < 60) {
                Vec3d predicted = client.utils.combat.PlayerSimulationUtil.predictWithFallback(target, arrowTicks);
                posX = predicted.xCoord;
                posY = predicted.yCoord + target.height * 0.5;
                posZ = predicted.zCoord;
            } else {
                posX += (target.posX - target.prevPosX) * d * 0.1;
                posZ += (target.posZ - target.prevPosZ) * d * 0.1;
            }
        }
        double relX = posX - mc.player.posX;
        double relZ = posZ - mc.player.posZ;
        double relY = posY - (mc.player.posY + mc.player.getEyeHeight());
        float targetYaw = (float) Math.toDegrees(Math.atan2(relZ, relX)) - 90.0f;
        double hDist = Math.sqrt(relX * relX + relZ * relZ);
        float neededPitch = client.utils.combat.ProjectilePitchUtil.calculatePitch(posX, posY, posZ, velocity * 3.0f, 0.05);
        if (Float.isNaN(neededPitch)) {
            neededPitch = (float) -Math.toDegrees(Math.atan2(relY, hDist));
        }
        float rotSpeed = (float) (double) speed.getValue();
        float[] smoothRots = RotationUtils.smoothRotate(mc.player.rotationYaw, mc.player.rotationPitch, targetYaw, neededPitch, rotSpeed);
        if (gcdFix.getValue()) {
            smoothRots = RotationUtils.fixRotations(smoothRots[0], smoothRots[1]);
        }
        mc.player.rotationYaw = smoothRots[0];
        mc.player.rotationPitch = smoothRots[1];
    }

    private float getAngleToTarget(EntityLivingBase t) {
        return RotationUtils.getAngleToEntity(t);
    }

    private EntityLivingBase findTarget() {
        TargetSelector.Criteria c = new TargetSelector.Criteria();
        c.targetPlayers = true;
        c.targetHostile = true;
        c.targetPassive = true;
        c.targetInvisible = false;
        c.hitThroughWalls = true;
        c.range = 50.0;
        c.fov = fov.getValue();
        c.aimLeadTicks = -1.0;
        return TargetSelector.selectTarget(c, "Distance");
    }

    @Override
    public void onDisable() {
        super.onDisable();
        target = null;
    }
}
