package client.module.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.combat.AimUtils;
import client.utils.combat.CombatUtils;
import client.utils.movement.RotationUtils;
import client.utils.combat.CombatAttackExecutor;
import client.utils.misc.FriendManager;
import client.utils.EntityUtils;

public class ClickAura extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting minCPS = new NumberSetting("Min CPS", 9.0, 1.0, 15.0);

    private final NumberSetting maxCPS = new NumberSetting("Max CPS", 14.0, 1.0, 15.0);

    private final NumberSetting minCooldown = new NumberSetting("Min Cooldown", 50.0, 0.0, 100.0);

    private final BooleanSetting swingArm = new BooleanSetting("Swing Arm", true);

    private final BooleanSetting gcdFix = new BooleanSetting("GCD Fix", true);

    private final BooleanSetting failswingCheck = new BooleanSetting("No Failswing", true);

    private final CombatUtils.AttackTimer attackTimer = new CombatUtils.AttackTimer();

    private EntityLivingBase tickTarget = null;

    private boolean rotatedThisTick = false;

    private float prevYaw = 0.0f;

    private float prevPitch = 0.0f;

    private float targetYaw = 0.0f;

    private float targetPitch = 0.0f;

    public ClickAura() {
        super("ClickAura", Category.COMBAT);
        setDescription("Attacks the entity you are looking at when you click");
        addSetting(minCPS);
        addSetting(maxCPS);
        addSetting(minCooldown);
        addSetting(swingArm);
        addSetting(gcdFix);
        addSetting(failswingCheck);
        handles(HandlerType.TICK, HandlerType.UPDATE);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        attackTimer.reset();
        tickTarget = null;
        rotatedThisTick = false;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            tickTarget = null;
            return;
        }
        if (!client.utils.combat.AttackKeyController.isAttackKeyDown()) {
            tickTarget = null;
            return;
        }
        if (mc.objectMouseOver == null) {
            tickTarget = null;
            return;
        }
        if (mc.objectMouseOver.entityHit == null) {
            tickTarget = null;
            return;
        }
        Entity target = mc.objectMouseOver.entityHit;
        if (!(target instanceof EntityLivingBase))
            return;
        if (target == mc.player)
            return;
        EntityLivingBase living = (EntityLivingBase) target;
        if (!EntityUtils.isAlive(living))
            return;
        if (FriendManager.isFriend(living))
            return;
        float threshold = (float) (minCooldown.getValue() / 100.0F);
        if (!CombatUtils.isWeaponReady(threshold))
            return;
        if (!attackTimer.canAttack((int) (double) minCPS.getValue(), (int) (double) maxCPS.getValue()))
            return;
        prevYaw = mc.player.rotationYaw;
        prevPitch = mc.player.rotationPitch;
        float[] rotations = RotationUtils.getNeededRotations(AimUtils.predictAimPoint(living, RotationUtils.AimPoint.CENTER, AimUtils.getLatencyLeadTicks()));
        if (gcdFix.getValue()) {
            rotations = RotationUtils.fixRotations(rotations[0], rotations[1]);
        }
        mc.player.rotationYaw = rotations[0];
        mc.player.rotationPitch = rotations[1];
        targetYaw = rotations[0];
        targetPitch = rotations[1];
        rotatedThisTick = true;
        tickTarget = living;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        EntityLivingBase living = tickTarget;
        tickTarget = null;
        if (living == null) {
            if (rotatedThisTick) {
                mc.player.rotationYaw = prevYaw;
                mc.player.rotationPitch = prevPitch;
                rotatedThisTick = false;
            }
            return;
        }
        if (!EntityUtils.isAlive(living)) {
            if (rotatedThisTick) {
                mc.player.rotationYaw = prevYaw;
                mc.player.rotationPitch = prevPitch;
                rotatedThisTick = false;
            }
            return;
        }
        if (!CombatUtils.isReachValid(living, 3.03)) {
            if (rotatedThisTick) {
                mc.player.rotationYaw = prevYaw;
                mc.player.rotationPitch = prevPitch;
                rotatedThisTick = false;
            }
            return;
        }
        if (failswingCheck.getValue()) {
            if (!RotationUtils.isRotationOnEntity(targetYaw, targetPitch, living, 3.03)) {
                if (rotatedThisTick) {
                    mc.player.rotationYaw = prevYaw;
                    mc.player.rotationPitch = prevPitch;
                    rotatedThisTick = false;
                }
                return;
            }
        }
        if (!mc.player.canEntityBeSeen(living)) {
            if (rotatedThisTick) {
                mc.player.rotationYaw = prevYaw;
                mc.player.rotationPitch = prevPitch;
                rotatedThisTick = false;
            }
            return;
        }
        if (!client.utils.combat.AttackControlClaim.shouldAttack("ClickAura", 90)) {
            if (rotatedThisTick) {
                mc.player.rotationYaw = prevYaw;
                mc.player.rotationPitch = prevPitch;
                rotatedThisTick = false;
            }
            return;
        }
        CombatAttackExecutor.directAttack(living, 3.03);
        client.utils.combat.OpponentHealthTracker.recordAttack(living, false);
        if (rotatedThisTick) {
            mc.player.rotationYaw = prevYaw;
            mc.player.rotationPitch = prevPitch;
            rotatedThisTick = false;
        }
    }
}
