package client.module.impl.combat;

import client.module.Module;
import client.module.HandlerType;
import client.module.Category;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import client.utils.movement.RotationUtils;
import client.utils.player.InvUtils;
import client.utils.player.FindItemResult;
import client.utils.player.PlayerUtils;
import client.utils.player.SlotUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import client.utils.combat.CombatAttackExecutor;
import client.utils.world.InteractionUtils;
import client.utils.combat.CombatUtils;
import client.utils.world.WorldUtils;
import client.utils.EntityUtils;
import client.utils.combat.SilentAimUtil;
import client.utils.misc.FriendManager;

public class CrystalAura extends Module {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final Random random = new Random();

    private final NumberSetting placeRange = new NumberSetting("PlaceRange", 4.5, 1.0, 6.0);

    private final NumberSetting attackRange = new NumberSetting("AttackRange", 4.5, 1.0, 6.0);

    private final BooleanSetting autoPlace = new BooleanSetting("AutoPlace", true);

    private final BooleanSetting autoAttack = new BooleanSetting("AutoAttack", true);

    private final BooleanSetting antiSelfDamage = new BooleanSetting("AntiSelfDmg", true);

    private final BooleanSetting antiSuicide = new BooleanSetting("AntiSuicide", true);

    private final BooleanSetting swingArm = new BooleanSetting("SwingArm", true);

    private final BooleanSetting targetPlayers = new BooleanSetting("TargetPlayers", true);

    private final BooleanSetting targetMobs = new BooleanSetting("TargetMobs", false);

    private final BooleanSetting hitThroughWalls = new BooleanSetting("ThroughWalls", false);

    private final BooleanSetting rotate = new BooleanSetting("Rotate", true);

    private final BooleanSetting silentAim = new BooleanSetting("SilentAim", true);

    private final BooleanSetting gcdFix = new BooleanSetting("GCD Fix", true);

    private final BooleanSetting integerGCD = new BooleanSetting("Integer GCD", true);

    private final BooleanSetting sinusoidalJitter = new BooleanSetting("Sinusoidal Jitter", true);

    private final BooleanSetting piController = new BooleanSetting("PI Controller", false);

    private final BooleanSetting movementCorrection = new BooleanSetting("Move Correct", true);

    private final BooleanSetting switchBack = new BooleanSetting("SwitchBack", true);

    private final NumberSetting maxSelfDamage = new NumberSetting("MaxSelfDmg", 10.0, 0.0, 20.0);

    private final NumberSetting minHealth = new NumberSetting("MinHealth", 6.0, 1.0, 20.0);

    private final NumberSetting minEnemyDist = new NumberSetting("MinEnemyDist", 1.5, 0.0, 6.0);

    private final NumberSetting attackDelay = new NumberSetting("AttackDelay", 2.0, 0.0, 15.0);

    private final NumberSetting placeDelay = new NumberSetting("PlaceDelay", 2.0, 0.0, 15.0);

    private final BooleanSetting randomDelay = new BooleanSetting("RandomDelay", true);

    private final NumberSetting rotSpeed = new NumberSetting("RotSpeed", 30.0, 5.0, 180.0);

    private final NumberSetting maxAngleDiff = new NumberSetting("MaxAngle", 180.0, 5.0, 180.0);

    private final NumberSetting reactionDelay = new NumberSetting("ReactDelay", 0.0, 0.0, 15.0);

    private int attackTimer = 0;

    private int placeTimer = 0;

    private int lastSlot = -1;

    private Entity tickTarget = null;

    private BlockPos tickPlacePos = null;

    private int tickPlaceSlot = -1;

    private float lastServerYaw = 0.0f;

    private float lastServerPitch = 0.0f;

    private float prevServerYaw = 0.0f;

    private float prevServerPitch = 0.0f;

    private boolean sentRotation = false;

    private boolean silentAimOwned = false;

    private final List<Entity> targetsBuffer = new ArrayList<>();

    private int targetsCacheTick = -1;

    private final Comparator<Entity> targetDistComparator = Comparator.comparingDouble(e -> mc.player.getDistanceToEntity(e));

    private client.module.impl.combat.AntiBot cachedAntiBot;

    public CrystalAura() {
        super("CrystalAura", Category.COMBAT);
        setDescription("Places and breaks crystals to damage other players.");
        addSetting(placeRange);
        addSetting(attackRange);
        addSetting(autoPlace);
        addSetting(autoAttack);
        addSetting(antiSelfDamage);
        addSetting(antiSuicide);
        addSetting(swingArm);
        addSetting(targetPlayers);
        addSetting(targetMobs);
        addSetting(rotate);
        addSetting(silentAim);
        addSetting(gcdFix);
        addSetting(integerGCD);
        addSetting(sinusoidalJitter);
        addSetting(piController);
        addSetting(movementCorrection);
        addSetting(switchBack);
        addSetting(maxSelfDamage);
        addSetting(minHealth);
        addSetting(minEnemyDist);
        addSetting(attackDelay);
        addSetting(placeDelay);
        addSetting(randomDelay);
        addSetting(rotSpeed);
        addSetting(maxAngleDiff);
        addSetting(reactionDelay);
        handles(HandlerType.TICK, HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        attackTimer = 0;
        placeTimer = 0;
        lastSlot = -1;
        targetsCacheTick = -1;
        client.module.Module antiBotMod = client.module.ModuleManager.getModuleByName("AntiBot");
        cachedAntiBot = antiBotMod instanceof client.module.impl.combat.AntiBot ? (client.module.impl.combat.AntiBot) antiBotMod : null;
        tickTarget = null;
        tickPlacePos = null;
        tickPlaceSlot = -1;
        lastServerYaw = 0.0f;
        lastServerPitch = 0.0f;
        if (silentAim.getValue()) {
            silentAimOwned = SilentAimUtil.onEnable("CrystalAura");
            if (silentAimOwned) {
                SilentAimUtil.initPIController();
            }
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (SilentAimUtil.isOwnedBy("CrystalAura")) {
            SilentAimUtil.restore();
            SilentAimUtil.restoreMovementKeys();
            SilentAimUtil.onDisable("CrystalAura");
            SilentAimUtil.resetIntegerDelta();
            SilentAimUtil.resetPIController();
            SilentAimUtil.resetJitterState();
        }
        silentAimOwned = false;
        restoreSlot();
        tickTarget = null;
        tickPlacePos = null;
        tickPlaceSlot = -1;
        targetsCacheTick = -1;
        targetsBuffer.clear();
    }

    @Override
    public void onTick() {
        if (silentAimOwned && !SilentAimUtil.isOwnedBy("CrystalAura")) {
            silentAimOwned = false;
        } else if (!silentAimOwned && silentAim.getValue() && !SilentAimUtil.isActive()) {
            silentAimOwned = SilentAimUtil.onEnable("CrystalAura");
            if (silentAimOwned) {
                SilentAimUtil.initPIController();
            }
        }
        if (!silentAim.getValue() || !silentAimOwned) {
            tickTarget = null;
            return;
        }
        if (mc.player == null || mc.world == null) {
            tickTarget = null;
            return;
        }
        if (!CombatUtils.isWeaponReady(0.9f)) {
            tickTarget = null;
            return;
        }
        List<Entity> targets = getTargets();
        if (targets.isEmpty()) {
            tickTarget = null;
            return;
        }
        Entity crystal = getBestCrystalToAttack();
        if (crystal != null) {
            tickTarget = crystal;
            Vec3d lookAt = new Vec3d(crystal.posX, crystal.posY + crystal.height / 2.0, crystal.posZ);
            if (!sentRotation) {
                lastServerYaw = mc.player.rotationYaw;
                lastServerPitch = mc.player.rotationPitch;
            }
            prevServerYaw = lastServerYaw;
            prevServerPitch = lastServerPitch;
            sentRotation = false;
            float[] needed = RotationUtils.getNeededRotations(lookAt);
            float targetYaw = needed[0];
            float targetPitch = needed[1];
            if (piController.getValue()) {
                double dist = mc.player.getDistanceToEntity(crystal);
                float angleDiff = RotationUtils.getAngleDifference(lastServerYaw, lastServerPitch, targetYaw, targetPitch);
                float[] adjusted = SilentAimUtil.piAimAdjustment(lastServerYaw, lastServerPitch, targetYaw, targetPitch, prevServerYaw, prevServerPitch, dist, 0.0, angleDiff < 15.0f);
                targetYaw = adjusted[0];
                targetPitch = adjusted[1];
            }
            if (integerGCD.getValue()) {
                float speed = rotSpeed.getValue().floatValue();
                float mouseScale = SilentAimUtil.getMouseScale();
                float rotPerStep = mouseScale * 0.15f;
                float stepsPerTick = rotPerStep > 0.001f ? speed / rotPerStep : 10.0f;
                SilentAimUtil.faceTargetSmoothGCD(targetYaw, targetPitch, stepsPerTick, sinusoidalJitter.getValue());
            } else {
                float speed = rotSpeed.getValue().floatValue();
                float[] smoothRots = RotationUtils.smoothRotate(lastServerYaw, lastServerPitch, targetYaw, targetPitch, speed);
                if (sinusoidalJitter.getValue()) {
                    smoothRots[0] += SilentAimUtil.getSinusoidalYawJitter();
                    smoothRots[1] += SilentAimUtil.getSinusoidalPitchJitter();
                }
                if (gcdFix.getValue()) {
                    smoothRots = RotationUtils.fixRotations(lastServerYaw, lastServerPitch, smoothRots[0], smoothRots[1]);
                }
                SilentAimUtil.setupSilentRotation(smoothRots[0], smoothRots[1]);
            }
            lastServerYaw = mc.player.rotationYaw;
            lastServerPitch = mc.player.rotationPitch;
            sentRotation = true;
            if (movementCorrection.getValue()) {
                SilentAimUtil.applyMovementCorrection(SilentAimUtil.getRealYaw(), lastServerYaw);
            }
            return;
        }
        int slot = findCrystalSlot();
        if (slot == -1) {
            tickTarget = null;
            return;
        }
        BlockPos placePos = getBestPlacePosition(targets);
        if (placePos != null) {
            tickPlacePos = placePos;
            tickPlaceSlot = slot;
            Vec3d hitVec = new Vec3d(placePos.getX() + 0.5, placePos.getY() + 1.0, placePos.getZ() + 0.5);
            if (!sentRotation) {
                lastServerYaw = mc.player.rotationYaw;
                lastServerPitch = mc.player.rotationPitch;
            }
            prevServerYaw = lastServerYaw;
            prevServerPitch = lastServerPitch;
            sentRotation = false;
            float[] needed = RotationUtils.getNeededRotations(hitVec);
            float targetYaw = needed[0];
            float targetPitch = needed[1];
            if (piController.getValue()) {
                double dist = mc.player.getDistance(placePos.getX() + 0.5, placePos.getY() + 1.0, placePos.getZ() + 0.5);
                float angleDiff = RotationUtils.getAngleDifference(lastServerYaw, lastServerPitch, targetYaw, targetPitch);
                float[] adjusted = SilentAimUtil.piAimAdjustment(lastServerYaw, lastServerPitch, targetYaw, targetPitch, prevServerYaw, prevServerPitch, dist, 0.0, angleDiff < 15.0f);
                targetYaw = adjusted[0];
                targetPitch = adjusted[1];
            }
            if (integerGCD.getValue()) {
                float speed = rotSpeed.getValue().floatValue();
                float mouseScale = SilentAimUtil.getMouseScale();
                float rotPerStep = mouseScale * 0.15f;
                float stepsPerTick = rotPerStep > 0.001f ? speed / rotPerStep : 10.0f;
                SilentAimUtil.faceTargetSmoothGCD(targetYaw, targetPitch, stepsPerTick, sinusoidalJitter.getValue());
            } else {
                float speed = rotSpeed.getValue().floatValue();
                float[] smoothRots = RotationUtils.smoothRotate(lastServerYaw, lastServerPitch, targetYaw, targetPitch, speed);
                if (sinusoidalJitter.getValue()) {
                    smoothRots[0] += SilentAimUtil.getSinusoidalYawJitter();
                    smoothRots[1] += SilentAimUtil.getSinusoidalPitchJitter();
                }
                if (gcdFix.getValue()) {
                    smoothRots = RotationUtils.fixRotations(lastServerYaw, lastServerPitch, smoothRots[0], smoothRots[1]);
                }
                SilentAimUtil.setupSilentRotation(smoothRots[0], smoothRots[1]);
            }
            lastServerYaw = mc.player.rotationYaw;
            lastServerPitch = mc.player.rotationPitch;
            sentRotation = true;
            if (movementCorrection.getValue()) {
                SilentAimUtil.applyMovementCorrection(SilentAimUtil.getRealYaw(), lastServerYaw);
            }
            return;
        }
        tickTarget = null;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (attackTimer > 0)
            attackTimer--;
        if (placeTimer > 0)
            placeTimer--;
        if (PlayerUtils.getTotalHealth() < minHealth.getValue()) {
            return;
        }
        if (autoAttack.getValue() && attackTimer <= 0) {
            if (silentAim.getValue() && tickTarget != null && tickTarget.isEntityAlive() && tickTarget instanceof EntityEnderCrystal) {
                Entity crystal = tickTarget;
                double reach = mc.player.getPositionEyes(1.0f).distanceTo(crystalHitVec(crystal));
                if (reach <= attackRange.getValue()) {
                    CombatAttackExecutor.directAttack(crystal, (float) reach + 0.1f, swingArm.getValue());
                }
                SilentAimUtil.restore();
                tickTarget = null;
                tickPlacePos = null;
                attackTimer = getDelay(attackDelay);
                return;
            }
            SilentAimUtil.restore();
            List<Entity> targets = getTargets();
            if (targets.isEmpty()) {
                tickTarget = null;
                return;
            }
            Entity crystal = getBestCrystalToAttack();
            if (crystal != null) {
                boolean success = attackCrystal(crystal);
                if (success) {
                    attackTimer = getDelay(attackDelay);
                    return;
                }
            }
        }
        if (autoPlace.getValue() && placeTimer <= 0) {
            if (silentAim.getValue() && tickPlacePos != null && tickPlaceSlot != -1) {
                boolean success = placeCrystal(tickPlacePos, tickPlaceSlot);
                if (success) {
                    placeTimer = getDelay(placeDelay);
                }
                SilentAimUtil.restore();
                tickTarget = null;
                tickPlacePos = null;
                tickPlaceSlot = -1;
                return;
            }
            SilentAimUtil.restore();
            int slot = findCrystalSlot();
            if (slot == -1)
                return;
            List<Entity> targets = getTargets();
            if (targets.isEmpty())
                return;
            BlockPos placePos = getBestPlacePosition(targets);
            if (placePos == null)
                return;
            boolean success = placeCrystal(placePos, slot);
            if (success) {
                placeTimer = getDelay(placeDelay);
            }
        }
    }

    private int getDelay(NumberSetting setting) {
        int base = setting.getValue().intValue();
        if (randomDelay.getValue()) {
            base += random.nextInt(3) - 1;
            if (base < 0)
                base = 0;
        }
        return base;
    }

    private boolean attackCrystal(Entity crystal) {
        if (!CombatUtils.isWeaponReady(0.9f))
            return false;
        Vec3d eyes = mc.player.getPositionEyes(1.0f);
        Vec3d eyeTarget = crystalHitVec(crystal);
        if (eyes.distanceTo(eyeTarget) > attackRange.getValue())
            return false;
        Vec3d lookAt = eyeTarget;
        float[] rotations = RotationUtils.getNeededRotations(lookAt);
        if (rotate.getValue()) {
            float prevYaw = mc.player.rotationYaw;
            float prevPitch = mc.player.rotationPitch;
            float[] smoothRots = RotationUtils.smoothRotate(prevYaw, prevPitch, rotations[0], rotations[1], rotSpeed.getValue().floatValue());
            float angleDiff = Math.abs(smoothRots[0] - rotations[0]) + Math.abs(smoothRots[1] - rotations[1]);
            if (angleDiff > maxAngleDiff.getValue().floatValue()) {
                return false;
            }
            mc.player.rotationYaw = smoothRots[0];
            mc.player.rotationPitch = smoothRots[1];
            CombatAttackExecutor.directAttack(crystal, attackRange.getValue().floatValue(), swingArm.getValue());
            mc.player.rotationYaw = prevYaw;
            mc.player.rotationPitch = prevPitch;
        } else {
            CombatAttackExecutor.directAttack(crystal, attackRange.getValue().floatValue(), swingArm.getValue());
        }
        return true;
    }

    private boolean placeCrystal(BlockPos pos, int crystalSlot) {
        lastSlot = mc.player.inventory.currentItem;
        if (crystalSlot >= SlotUtils.HOTBAR_START && crystalSlot <= SlotUtils.HOTBAR_END) {
            mc.player.inventory.currentItem = crystalSlot - SlotUtils.HOTBAR_START;
        } else {
            lastSlot = -1;
        }
        EnumHand hand = EnumHand.MAIN_HAND;
        ItemStack offhand = mc.player.getHeldItemOffhand();
        if (!offhand.func_190926_b() && offhand.getItem() == Items.END_CRYSTAL) {
            hand = EnumHand.OFF_HAND;
            if (crystalSlot == SlotUtils.OFFHAND) {
                lastSlot = -1;
            }
        }
        Vec3d hitVec = new Vec3d(pos.x + 0.5, pos.y + 1.0, pos.z + 0.5);
        if (rotate.getValue()) {
            float prevYaw = mc.player.rotationYaw;
            float prevPitch = mc.player.rotationPitch;
            float[] rotations = RotationUtils.getNeededRotations(hitVec);
            float[] smoothRots = RotationUtils.smoothRotate(prevYaw, prevPitch, rotations[0], rotations[1], rotSpeed.getValue().floatValue());
            float angleDiff = Math.abs(smoothRots[0] - rotations[0]) + Math.abs(smoothRots[1] - rotations[1]);
            if (angleDiff > maxAngleDiff.getValue().floatValue()) {
                if (switchBack.getValue() && lastSlot != -1) {
                    mc.player.inventory.currentItem = lastSlot;
                    lastSlot = -1;
                }
                return false;
            }
            mc.player.rotationYaw = smoothRots[0];
            mc.player.rotationPitch = smoothRots[1];
            InteractionUtils.placeBlock(pos, EnumFacing.UP, new Vec3d(pos.x + 0.5, pos.y + 1.0, pos.z + 0.5), hand);
            if (swingArm.getValue()) {
                mc.player.swingArm(hand);
            }
            mc.player.rotationYaw = prevYaw;
            mc.player.rotationPitch = prevPitch;
        } else {
            InteractionUtils.placeBlock(pos, EnumFacing.UP, new Vec3d(pos.x + 0.5, pos.y + 1.0, pos.z + 0.5), hand);
            if (swingArm.getValue()) {
                mc.player.swingArm(hand);
            }
        }
        if (switchBack.getValue() && lastSlot != -1) {
            mc.player.inventory.currentItem = lastSlot;
            lastSlot = -1;
        }
        return true;
    }

    private Entity getBestCrystalToAttack() {
        Entity best = null;
        double bestDistSq = Double.MAX_VALUE;
        double attackRangeSq = attackRange.getValue() * attackRange.getValue();
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (!(entity instanceof EntityEnderCrystal))
                continue;
            if (entity.isDead)
                continue;
            double dsq = mc.player.getDistanceSqToEntity(entity);
            if (dsq > attackRangeSq)
                continue;
            if (!hitThroughWalls.getValue() && !mc.player.canEntityBeSeen(entity)) {
                continue;
            }
            if (antiSelfDamage.getValue()) {
                float selfDmg = client.utils.combat.ExplosionDamageUtil.predictCrystalDamage(mc.player, entity.posX, entity.posY, entity.posZ);
                if (selfDmg > maxSelfDamage.getValue())
                    continue;
            }
            if (dsq < bestDistSq) {
                bestDistSq = dsq;
                best = entity;
            }
        }
        return best;
    }

    private BlockPos getBestPlacePosition(List<Entity> targets) {
        BlockPos bestPos = null;
        double bestScore = Double.MAX_VALUE;
        int pX = (int) Math.floor(mc.player.posX);
        int pY = (int) Math.floor(mc.player.posY);
        int pZ = (int) Math.floor(mc.player.posZ);
        int range = (int) Math.ceil(placeRange.getValue()) + 1;
        Vec3d placeEyes = mc.player.getPositionEyes(1.0f);
        double eyeX = placeEyes.xCoord;
        double eyeY = placeEyes.yCoord;
        double eyeZ = placeEyes.zCoord;
        double px = mc.player.posX;
        double py = mc.player.posY;
        double pz = mc.player.posZ;
        double placeRangeSq = placeRange.getValue() * placeRange.getValue();
        double maxEyeDistSq = 4.5 * 4.5;
        double maxTargetDistSq = 6.0 * 6.0;
        double minEnemyDistSq = minEnemyDist.getValue() * minEnemyDist.getValue();
        for (int x = -range; x <= range; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -range; z <= range; z++) {
                    double cx = pX + x + 0.5;
                    double cy = pY + y + 1.0;
                    double cz = pZ + z + 0.5;
                    double dpx = cx - px;
                    double dpy = cy - py;
                    double dpz = cz - pz;
                    if (dpx * dpx + dpy * dpy + dpz * dpz > placeRangeSq)
                        continue;
                    double dex = cx - eyeX;
                    double dey = cy - eyeY;
                    double dez = cz - eyeZ;
                    if (dex * dex + dey * dey + dez * dez > maxEyeDistSq)
                        continue;
                    BlockPos pos = new BlockPos(pX + x, pY + y, pZ + z);
                    int failReason = validatePlacePos(pos);
                    if (failReason != 0)
                        continue;
                    float posSelfDmg = 0.0f;
                    if (antiSelfDamage.getValue()) {
                        posSelfDmg = client.utils.combat.ExplosionDamageUtil.predictCrystalDamage(mc.player, pos);
                        if (posSelfDmg > maxSelfDamage.getValue())
                            continue;
                    }
                    if (antiSuicide.getValue()) {
                        if (PlayerUtils.getTotalHealth() - posSelfDmg <= 0) {
                            continue;
                        }
                    }
                    for (Entity target : targets) {
                        double tdx = target.posX - cx;
                        double tdy = target.posY - cy;
                        double tdz = target.posZ - cz;
                        double distSq = tdx * tdx + tdy * tdy + tdz * tdz;
                        if (distSq > maxTargetDistSq)
                            continue;
                        if (distSq < minEnemyDistSq)
                            continue;
                        if (distSq < bestScore) {
                            bestScore = distSq;
                            bestPos = pos;
                        }
                    }
                }
            }
        }
        return bestPos;
    }

    private int validatePlacePos(BlockPos pos) {
        net.minecraft.block.Block block = WorldUtils.getBlock(pos);
        if (block != Blocks.OBSIDIAN && block != Blocks.BEDROCK) {
            return 1;
        }
        BlockPos above = pos.up();
        if (!WorldUtils.isAir(above) && !WorldUtils.getState(above).getBlock().isReplaceable(mc.world, above)) {
            return 2;
        }
        BlockPos twoAbove = pos.up(2);
        if (!WorldUtils.isAir(twoAbove) && !WorldUtils.getState(twoAbove).getBlock().isReplaceable(mc.world, twoAbove)) {
            return 3;
        }
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (entity instanceof EntityEnderCrystal && !entity.isDead) {
                double dx = entity.posX - (pos.x + 0.5);
                double dy = entity.posY - (pos.y + 1.0);
                double dz = entity.posZ - (pos.z + 0.5);
                if (dx * dx + dy * dy + dz * dz < 1.0) {
                    return 4;
                }
            }
        }
        return 0;
    }

    private List<Entity> getTargets() {
        int tick = mc.player != null ? mc.player.ticksExisted : -1;
        if (targetsCacheTick == tick) {
            return targetsBuffer;
        }
        targetsCacheTick = tick;
        targetsBuffer.clear();
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (entity == mc.player)
                continue;
            if (entity.isDead)
                continue;
            if (FriendManager.isFriend(entity))
                continue;
            if (cachedAntiBot != null && cachedAntiBot.isToggled() && entity instanceof EntityPlayer && cachedAntiBot.isBot(entity)) {
                continue;
            }
            double dist = mc.player.getDistanceToEntity(entity);
            if (dist > placeRange.getValue() + 3.0)
                continue;
            if (entity instanceof EntityPlayer && targetPlayers.getValue()) {
                targetsBuffer.add(entity);
            } else if (entity instanceof net.minecraft.entity.EntityLivingBase && !(entity instanceof EntityPlayer) && !(entity instanceof EntityEnderCrystal) && targetMobs.getValue()) {
                targetsBuffer.add(entity);
            }
        }
        targetsBuffer.sort(targetDistComparator);
        return targetsBuffer;
    }

    private int findCrystalSlot() {
        ItemStack offhand = mc.player.getHeldItemOffhand();
        if (!offhand.func_190926_b() && offhand.getItem() == Items.END_CRYSTAL) {
            return SlotUtils.OFFHAND;
        }
        FindItemResult result = InvUtils.findInHotbar(Items.END_CRYSTAL);
        if (result.found())
            return result.slot();
        result = InvUtils.find(Items.END_CRYSTAL);
        if (result.found())
            return result.slot();
        return -1;
    }

    private void restoreSlot() {
        if (lastSlot != -1 && mc.player != null) {
            mc.player.inventory.currentItem = lastSlot;
            lastSlot = -1;
        }
    }

    private Vec3d crystalHitVec(Entity crystal) {
        return new Vec3d(crystal.posX, crystal.posY + crystal.height / 2.0, crystal.posZ);
    }
}
