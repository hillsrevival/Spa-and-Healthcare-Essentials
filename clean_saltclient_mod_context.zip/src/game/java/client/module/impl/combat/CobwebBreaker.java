package client.module.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemShears;
import net.minecraft.item.ItemTool;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.state.IBlockState;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.misc.ChatUtils;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class CobwebBreaker extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private int oldSlot = -1;

    private int switchBackTimer = 0;

    private boolean breaking = false;

    private final NumberSetting range = new NumberSetting("Range", 4.5, 1.0, 6.0);

    private final NumberSetting holdTime = new NumberSetting("Hold Ticks", 4.0, 2.0, 15.0);

    private final BooleanSetting autoSwitch = new BooleanSetting("AutoSwitch", true);

    private final BooleanSetting debug = new BooleanSetting("Debug", false);

    public CobwebBreaker() {
        super("CobwebBreaker", Category.COMBAT);
        setDescription("Automatically breaks cobwebs");
        addSetting(range);
        addSetting(holdTime);
        addSetting(autoSwitch);
        addSetting(debug);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.player.capabilities.isCreativeMode)
            return;
        if (oldSlot != -1) {
            if (switchBackTimer <= 0) {
                mc.player.inventory.currentItem = oldSlot;
                oldSlot = -1;
                breaking = false;
            } else {
                switchBackTimer--;
            }
            return;
        }
        BlockPos cobweb = findNearbyCobweb();
        if (cobweb == null)
            return;
        if (debug.getValue()) {
            ChatUtils.info("CobwebBreaker: found cobweb at " + cobweb.getX() + ", " + cobweb.getY() + ", " + cobweb.getZ());
        }
        if (autoSwitch.getValue()) {
            int toolSlot = findBestTool();
            if (toolSlot != -1 && toolSlot != mc.player.inventory.currentItem) {
                oldSlot = mc.player.inventory.currentItem;
                mc.player.inventory.currentItem = toolSlot;
            }
        }
        if (mc.playerController != null) {
            InteractionUtils.breakBlock(cobweb);
            if (mc.player != null) {
                mc.player.swingArm(EnumHand.MAIN_HAND);
            }
        }
        if (debug.getValue()) {
            ChatUtils.info("CobwebBreaker: broke cobweb");
        }
        breaking = true;
        switchBackTimer = holdTime.getValue().intValue();
    }

    private BlockPos findNearbyCobweb() {
        int blockRange = (int) Math.ceil(range.getValue());
        double rangeSq = range.getValue() * range.getValue();
        BlockPos playerPos = new BlockPos(mc.player);
        for (int x = -blockRange; x <= blockRange; x++) {
            for (int y = -blockRange; y <= blockRange; y++) {
                for (int z = -blockRange; z <= blockRange; z++) {
                    BlockPos pos = playerPos.add(x, y, z);
                    double distSq = mc.player.getDistanceSq(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
                    if (distSq > rangeSq)
                        continue;
                    IBlockState state = WorldUtils.getState(pos);
                    if (state.getBlock() == Blocks.WEB) {
                        return pos;
                    }
                }
            }
        }
        return null;
    }

    private int findBestTool() {
        int bestSlot = -1;
        float bestSpeed = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == null || stack.func_190926_b())
                continue;
            if (stack.getItem() instanceof ItemShears) {
                return i;
            }
            if (stack.getItem() instanceof ItemSword) {
                float damage = ((ItemSword) stack.getItem()).getDamageVsEntity();
                if (damage > bestSpeed) {
                    bestSpeed = damage;
                    bestSlot = i;
                }
            }
            if (stack.getItem() instanceof ItemTool) {
                float speed = ((ItemTool) stack.getItem()).getStrVsBlock(stack, Blocks.WEB.getDefaultState());
                if (speed > bestSpeed) {
                    bestSpeed = speed;
                    bestSlot = i;
                }
            }
        }
        if (debug.getValue() && bestSlot == -1) {
            ChatUtils.info("CobwebBreaker: no tool found!");
        }
        return bestSlot;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (oldSlot != -1 && mc.player != null) {
            mc.player.inventory.currentItem = oldSlot;
            oldSlot = -1;
        }
        switchBackTimer = 0;
        breaking = false;
    }
}
