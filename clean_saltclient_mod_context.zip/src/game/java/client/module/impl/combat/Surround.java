package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class Surround extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting shift = new BooleanSetting("AutoShift", true);

    private final NumberSetting delay = new NumberSetting("Delay", 0.0, 0.0, 5.0);

    private int tickCounter = 0;

    public Surround() {
        super("Surround", Category.COMBAT);
        setDescription("Places blocks around you");
        addSetting(shift);
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!mc.player.onGround)
            return;
        tickCounter++;
        int delayTicks = delay.getValue().intValue();
        if (delayTicks > 0 && tickCounter % (delayTicks + 1) != 0)
            return;
        int blockSlot = findBlockSlot();
        if (blockSlot == -1)
            return;
        double px = mc.player.posX;
        double py = mc.player.posY;
        double pz = mc.player.posZ;
        BlockPos[] positions = { new BlockPos(Math.floor(px) + 1, Math.floor(py), Math.floor(pz)), new BlockPos(Math.floor(px) - 1, Math.floor(py), Math.floor(pz)), new BlockPos(Math.floor(px), Math.floor(py), Math.floor(pz) + 1), new BlockPos(Math.floor(px), Math.floor(py), Math.floor(pz) - 1) };
        boolean sneaking = false;
        int savedSlot = mc.player.inventory.currentItem;
        for (BlockPos pos : positions) {
            if (WorldUtils.isAir(pos)) {
                if (shift.getValue() && !mc.player.isSneaking() && isOverEdge(pos)) {
                    mc.gameSettings.keyBindSneak.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), true);
                    sneaking = true;
                }
                mc.player.inventory.currentItem = blockSlot;
                EnumFacing dir = getPlaceableSide(pos);
                if (dir != null) {
                    BlockPos neighbor = pos.offset(dir);
                    InteractionUtils.placeBlock(neighbor, dir.getOpposite(), client.utils.world.BlockUtils.faceCenter(neighbor, dir.getOpposite()), EnumHand.MAIN_HAND);
                }
            }
        }
        if (sneaking) {
            mc.gameSettings.keyBindSneak.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
        }
        mc.player.inventory.currentItem = savedSlot;
        toggle();
    }

    private boolean isOverEdge(BlockPos pos) {
        for (int dx = -1; dx <= 1; dx += 2) {
            for (int dz = -1; dz <= 1; dz += 2) {
                BlockPos check = pos.add(dx, -1, dz);
                if (WorldUtils.isAir(check))
                    return true;
            }
        }
        return false;
    }

    private int findBlockSlot() {
        client.utils.player.FindItemResult r = client.utils.player.InvUtils.findInHotbar(stack -> stack != null && !stack.func_190926_b() && stack.getItem() instanceof ItemBlock);
        return r.found() ? r.slot() - client.utils.player.SlotUtils.HOTBAR_START : -1;
    }

    private EnumFacing getPlaceableSide(BlockPos pos) {
        return client.utils.world.BlockUtils.findPlaceableSide(pos);
    }
}
