package client.module.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.combat.TargetSelector;
import client.utils.world.InteractionUtils;

public class ExpThrower extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting delay = new NumberSetting("Delay", 2.0, 0.0, 20.0);

    private final NumberSetting range = new NumberSetting("Range", 8.0, 1.0, 20.0);

    private final BooleanSetting autoSwitch = new BooleanSetting("AutoSwitch", true);

    private final BooleanSetting playersOnly = new BooleanSetting("PlayersOnly", false);

    private int timer = 0;

    public ExpThrower() {
        super("ExpThrower", Category.COMBAT);
        setDescription("Throws experience bottles automatically");
        addSetting(delay);
        addSetting(range);
        addSetting(autoSwitch);
        addSetting(playersOnly);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (timer > 0) {
            timer--;
            return;
        }
        int bottleSlot = findXPBottle();
        if (bottleSlot == -1) {
            return;
        }
        Entity target = findTarget();
        if (target == null)
            return;
        float rangeVal = range.getValue().floatValue();
        int savedSlot = mc.player.inventory.currentItem;
        if (autoSwitch.getValue() && bottleSlot != savedSlot) {
            mc.player.inventory.currentItem = bottleSlot;
        }
        net.minecraft.util.math.Vec3d aimPoint = new net.minecraft.util.math.Vec3d(target.posX, target.posY + target.getEyeHeight() / 2.0, target.posZ);
        float[] rots = client.utils.movement.RotationUtils.getNeededRotations(aimPoint);
        float yaw = rots[0];
        float pitch = rots[1] - 10.0f;
        mc.player.rotationYaw = yaw;
        mc.player.rotationPitch = pitch;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (!held.func_190926_b() && held.getItem() == Items.EXPERIENCE_BOTTLE) {
            InteractionUtils.useItem(EnumHand.MAIN_HAND);
            mc.player.swingArm(EnumHand.MAIN_HAND);
            timer = delay.getValue().intValue();
        }
        if (autoSwitch.getValue() && savedSlot != bottleSlot) {
            mc.player.inventory.currentItem = savedSlot;
        }
    }

    private Entity findTarget() {
        TargetSelector.Criteria c = new TargetSelector.Criteria();
        c.targetPlayers = true;
        c.targetHostile = !playersOnly.getValue();
        c.targetPassive = false;
        c.targetInvisible = true;
        c.hitThroughWalls = true;
        c.range = range.getValue();
        c.fov = 360.0;
        c.aimLeadTicks = -1.0;
        return TargetSelector.selectTarget(c, "Distance");
    }

    private int findXPBottle() {
        client.utils.player.FindItemResult r = client.utils.player.InvUtils.findInHotbar(net.minecraft.init.Items.EXPERIENCE_BOTTLE);
        return r.found() ? r.slot() - client.utils.player.SlotUtils.HOTBAR_START : -1;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        timer = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        timer = 0;
    }
}
