package client.module.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.combat.ReachBalancer;
import client.utils.render.ClientFontRenderer;

public class Reach extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting distanceThreshold = new NumberSetting("Distance", 3.5, 3.0, 6.0);

    private final BooleanSetting showHud = new BooleanSetting("Show HUD", true);

    private float displayDistance = -1.0F;

    public Reach() {
        super("Reach", Category.COMBAT);
        setDescription("Sets the target reach used by combat modules that respect ReachBalancer; it cannot extend server-side reach");
        addSetting(distanceThreshold);
        addSetting(showHud);
        handles(HandlerType.TICK, HandlerType.UPDATE, HandlerType.GUI_RENDER);
    }

    @Override
    public void onTick() {
        if (!nullCheck())
            return;
        double configured = distanceThreshold.getValue();
        // Keep the configured limit real. The previous 0.03 approach bonus meant a
        // slider value of 6.0 still produced an effective limit near 3.03 blocks.
        ReachBalancer.configure(configured, configured, configured, 0.0, 0.0);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) {
            displayDistance = -1.0F;
            return;
        }
        if (mc.objectMouseOver != null && mc.objectMouseOver.entityHit != null) {
            Entity target = mc.objectMouseOver.entityHit;
            displayDistance = (float) client.utils.combat.CombatUtils.getReachDistance(target);
        } else {
            displayDistance = -1.0F;
        }
    }

    @Override
    public void onGUIRender() {
        if (!showHud.getValue())
            return;
        if (displayDistance < 0.0F)
            return;
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        float dist = displayDistance;
        double threshold = distanceThreshold.getValue();
        int color;
        if (dist <= threshold) {
            color = 0x55FF55;
        } else {
            color = 0xFF5555;
        }
        String text = String.format("%.1f", dist);
        int x = sr.getScaledWidth() / 2 + 5;
        int y = sr.getScaledHeight() / 2 - 8;
        ClientFontRenderer.drawStringWithShadow(text, x, y, color);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        displayDistance = -1.0F;
        ReachBalancer.configure(3.0, 3.03, 2.6, 0.03, 0.08);
    }
}
