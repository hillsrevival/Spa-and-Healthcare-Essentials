package client.module.impl.combat;

import client.event.events.EntityJoinWorldEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class AntiBot extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting tabListCheck = new BooleanSetting("Tab List Check", true);

    private final BooleanSetting pingCheck = new BooleanSetting("Ping Check", true);

    private final BooleanSetting removeBots = new BooleanSetting("Remove Bots", false);

    private final Set<Integer> botIds = new HashSet<>();

    private final java.util.Map<Integer, Long> joinTimes = new java.util.HashMap<>();

    private int pruneCounter = 0;

    private static final long PING_GRACE_MS = 2000L;

    public AntiBot() {
        super("AntiBot", Category.COMBAT);
        setDescription("Detects and filters bot players");
        addSetting(tabListCheck);
        addSetting(pingCheck);
        addSetting(removeBots);
        handles(HandlerType.ENTITY_JOIN_WORLD, HandlerType.UPDATE);
    }

    @Override
    public void onEntityJoinWorld(EntityJoinWorldEvent event) {
        if (!nullCheck())
            return;
        Entity entity = event.getEntity();
        if (!(entity instanceof EntityPlayer))
            return;
        if (entity == mc.player)
            return;
        EntityPlayer player = (EntityPlayer) entity;
        checkAndMark(player);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        for (EntityPlayer player : mc.world.playerEntities) {
            if (player == mc.player)
                continue;
            if (botIds.contains(player.getEntityId()))
                continue;
            checkAndMark(player);
        }
        if (mc.getConnection() != null) {
            java.util.Map<Integer, EntityPlayer> loadedById = new java.util.HashMap<>();
            for (EntityPlayer player : mc.world.playerEntities) {
                loadedById.put(player.getEntityId(), player);
            }
            java.util.Iterator<Integer> it = botIds.iterator();
            while (it.hasNext()) {
                int id = it.next();
                EntityPlayer marked = loadedById.get(id);
                if (marked == null)
                    continue;
                NetworkPlayerInfo info = mc.getConnection().getPlayerInfo(marked.getGameProfile().getId());
                if ((tabListCheck.getValue() && info != null) || (info != null && info.getResponseTime() > 0)) {
                    it.remove();
                }
            }
            if (++pruneCounter >= 200) {
                pruneCounter = 0;
                joinTimes.keySet().retainAll(loadedById.keySet());
            }
        }
    }

    private void checkAndMark(EntityPlayer player) {
        boolean isBot = false;
        int id = player.getEntityId();
        long now = System.currentTimeMillis();
        Long firstSeen = joinTimes.get(id);
        if (firstSeen == null) {
            firstSeen = now;
            joinTimes.put(id, now);
        }
        if (tabListCheck.getValue()) {
            NetworkPlayerInfo info = mc.getConnection().getPlayerInfo(player.getGameProfile().getId());
            if (info == null) {
                isBot = true;
            }
        }
        if (!isBot && pingCheck.getValue() && now - firstSeen >= PING_GRACE_MS) {
            NetworkPlayerInfo info = mc.getConnection().getPlayerInfo(player.getGameProfile().getId());
            if (info != null && info.getResponseTime() == 0) {
                isBot = true;
            }
        }
        if (isBot) {
            botIds.add(player.getEntityId());
        }
    }

    public boolean isBot(Entity entity) {
        if (entity == null)
            return false;
        return botIds.contains(entity.getEntityId());
    }

    public boolean isBot(int entityId) {
        return botIds.contains(entityId);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        botIds.clear();
        joinTimes.clear();
    }
}
