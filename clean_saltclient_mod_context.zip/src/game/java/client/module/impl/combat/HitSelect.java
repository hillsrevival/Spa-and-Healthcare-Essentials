package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.utils.combat.CombatContext;
import client.utils.combat.CombatDecisionMaker;
import net.minecraft.client.Minecraft;

public class HitSelect extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Mode", "Aggressive", "Aggressive", "Smart", "Defensive");

    private final NumberSetting chance = new NumberSetting("Chance", 100.0, 0.0, 100.0);

    private final BooleanSetting skipRetreating = new BooleanSetting("Skip Retreating", true);

    private final BooleanSetting skipAirborne = new BooleanSetting("Skip Airborne", false);

    private final BooleanSetting skipHurtTarget = new BooleanSetting("Skip Hurt Target", false);

    private long lastGateRollTick = -1000L;

    private boolean gateAllowsThisCycle = true;

    private net.minecraft.entity.EntityLivingBase lastGateTarget = null;

    public HitSelect() {
        super("HitSelect", Category.COMBAT);
        setDescription("Only swings at favorable moments");
        addSetting(mode);
        addSetting(chance);
        addSetting(skipRetreating);
        addSetting(skipAirborne);
        addSetting(skipHurtTarget);
        handles(HandlerType.TICK);
    }

    @Override
    public void onTick() {
        if (!nullCheck())
            return;
        CombatDecisionMaker.configureTactical(true, skipRetreating.getValue(), skipAirborne.getValue(), false, false, mode.getValue());
        CombatDecisionMaker.configureSkipHurtTarget(skipHurtTarget.getValue());
        if (CombatContext.shouldEngage()) {
            double chanceVal = chance.getValue();
            if (chanceVal < 100.0) {
                long now = CombatContext.getCurrentTick();
                long period = Math.max(1L, Math.round(CombatContext.getMyAttackPeriod()));
                net.minecraft.entity.EntityLivingBase target = CombatContext.getTarget();
                boolean targetChanged = target != lastGateTarget;
                if (now - lastGateRollTick >= period || targetChanged) {
                    lastGateRollTick = now;
                    lastGateTarget = target;
                    gateAllowsThisCycle = Math.random() * 100.0 <= chanceVal;
                }
                if (!gateAllowsThisCycle) {
                    CombatContext.setShouldEngage(false, "chance-gate");
                }
            }
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        CombatDecisionMaker.configureTactical(true, skipRetreating.getValue(), skipAirborne.getValue(), false, false, mode.getValue());
    }

    @Override
    public void onDisable() {
        super.onDisable();
        CombatDecisionMaker.configureTactical(false, true, true, false, false, "Aggressive");
    }
}
