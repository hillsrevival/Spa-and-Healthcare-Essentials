package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.utils.combat.CombatContext;
import client.utils.combat.TargetPrediction;
import client.utils.movement.MovementUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;

public class SprintReset extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting(// Default: only toggle sprint flag, don't touch W key
    "Mode", "Sprint-Stop", "Sprint-Stop", "W-Tap", "Both");

    private final NumberSetting resetDelay = new NumberSetting("Reset Delay", 2.0, 1.0, 5.0);

    private final BooleanSetting adaptiveDelay = new BooleanSetting("Adaptive Delay", true);

    private final BooleanSetting onlyWhenMoving = new BooleanSetting("Only When Moving", false);

    private final BooleanSetting onlyWhenOnGround = new BooleanSetting("Only When On Ground", true);

    private int ticksSinceAttack = 999;

    private boolean inStopPhase = false;

    private boolean savedForwardKey = false;

    public SprintReset() {
        super("SprintReset", Category.COMBAT);
        setDescription("Maximizes knockback by sprint resetting on attack");
        addSetting(mode);
        addSetting(resetDelay);
        addSetting(adaptiveDelay);
        addSetting(onlyWhenMoving);
        addSetting(onlyWhenOnGround);
        handles(HandlerType.ATTACK, HandlerType.UPDATE, HandlerType.SET_SPRINTING);
    }

    @Override
    public void onAttack(client.event.events.AttackEvent event) {
        if (mc.player == null)
            return;
        if (inStopPhase) {
            ticksSinceAttack = 0;
            return;
        }
        lastAttackHadSprint = mc.player.isSprinting();
        if (onlyWhenMoving.getValue() && !MovementUtils.isMoving())
            return;
        if (onlyWhenOnGround.getValue() && !MovementUtils.isOnGround())
            return;
        ticksSinceAttack = 0;
        inStopPhase = true;
        String m = mode.getValue();
        if (m.equals("W-Tap") || m.equals("Both")) {
            savedForwardKey = mc.gameSettings.keyBindForward.isKeyDown();
            MovementUtils.holdForward(false);
        }
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!inStopPhase)
            return;
        ticksSinceAttack++;
        int delay = computeWalkDuration();
        if (ticksSinceAttack >= delay) {
            String m = mode.getValue();
            if (m.equals("W-Tap") || m.equals("Both")) {
                MovementUtils.holdForward(savedForwardKey);
            }
            inStopPhase = false;
            MovementUtils.reSprint();
            ticksSinceAttack = 999;
        }
    }

    @Override
    public void onSetSprinting(client.event.events.SetSprintingEvent event) {
        if (mc.player == null)
            return;
        if (event.getEntity() != mc.player)
            return;
        if (!inStopPhase)
            return;
        if (event.isNewSprintingState()) {
            event.setCancelled(true);
        }
    }

    private boolean lastAttackHadSprint = true;

    private int computeWalkDuration() {
        int configured = (int) (double) resetDelay.getValue();
        if (!adaptiveDelay.getValue())
            return configured;
        EntityLivingBase target = CombatContext.getTarget();
        if (target == null || mc.player == null || mc.world == null) {
            return configured;
        }
        double dirX = target.posX - mc.player.posX;
        double dirZ = target.posZ - mc.player.posZ;
        double len = Math.sqrt(dirX * dirX + dirZ * dirZ);
        if (len < 0.1)
            return configured;
        double predicted = TargetPrediction.predictKnockbackDisplacement(target, lastAttackHadSprint, 12);
        double probeDist = Math.max(1.0, Math.min(predicted, 4.0));
        net.minecraft.util.math.Vec3d start = new net.minecraft.util.math.Vec3d(target.posX, target.posY + target.height * 0.5, target.posZ);
        net.minecraft.util.math.Vec3d end = new net.minecraft.util.math.Vec3d(target.posX + dirX / len * probeDist, target.posY + target.height * 0.5, target.posZ + dirZ / len * probeDist);
        net.minecraft.util.math.RayTraceResult hit = mc.world.rayTraceBlocks(start, end);
        if (hit != null && hit.typeOfHit == net.minecraft.util.math.RayTraceResult.Type.BLOCK) {
            return Math.min(5, configured + 2);
        }
        return 1;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        inStopPhase = false;
        ticksSinceAttack = 999;
    }

    @Override
    public void onDisable() {
        if (inStopPhase) {
            MovementUtils.holdForward(savedForwardKey);
        }
        super.onDisable();
        if (mc.player != null && MovementUtils.canSprint()) {
            MovementUtils.setSprinting(true);
        }
        inStopPhase = false;
        ticksSinceAttack = 999;
    }

    public boolean isInStopPhase() {
        return inStopPhase;
    }
}
