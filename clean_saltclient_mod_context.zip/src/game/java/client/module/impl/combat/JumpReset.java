package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.util.math.Vec3d;
import net.lax1dude.eaglercraft.Keyboard;
import java.util.Random;

public class JumpReset extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting chance = new NumberSetting("Chance", 100.0, 0.0, 100.0);

    private final NumberSetting accuracy = new NumberSetting("Accuracy", 60.0, 0.0, 100.0);

    private final BooleanSetting onlyWhenTargeting = new BooleanSetting("Only when targeting", false);

    private final BooleanSetting waterCheck = new BooleanSetting("Water check", true);

    private final BooleanSetting skipWhileBridging = new BooleanSetting("Skip while bridging", true);

    private boolean waitingForReset;

    private boolean shouldJump;

    private boolean jumping;

    private int retryTicks;

    private double motionX;

    private double motionY;

    private double motionZ;

    private final Random random = new Random();

    public JumpReset() {
        super("JumpReset", Category.COMBAT);
        setDescription("Reduces knockback by jumping the exact tick it lands");
        addSetting(chance);
        addSetting(accuracy);
        addSetting(onlyWhenTargeting);
        addSetting(waterCheck);
        addSetting(skipWhileBridging);
        handles(HandlerType.TICK, HandlerType.PACKET_INPUT, HandlerType.POST_UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        resetState();
    }

    @Override
    public void onDisable() {
        releaseJumpKey();
        resetState();
        super.onDisable();
    }

    private void resetState() {
        waitingForReset = false;
        shouldJump = false;
        retryTicks = 0;
    }

    @Override
    public void onPacketInput(client.event.events.PacketInputEvent event) {
        if (!nullCheck())
            return;
        if (!(event.getPacket() instanceof SPacketEntityVelocity))
            return;
        SPacketEntityVelocity packet = (SPacketEntityVelocity) event.getPacket();
        if (packet.getEntityID() != mc.player.getEntityId())
            return;
        if ((packet.getMotionX() == 0 && packet.getMotionZ() == 0) || packet.getMotionY() < 0)
            return;
        if (!shouldReduce())
            return;
        client.utils.combat.CombatContext.recordJumpReset();
        this.motionX = packet.getMotionX() / 8000.0;
        this.motionY = packet.getMotionY() / 8000.0;
        this.motionZ = packet.getMotionZ() / 8000.0;
        this.waitingForReset = true;
    }

    private boolean shouldReduce() {
        if (jumping)
            return false;
        if (mc.player.isPotionActive(MobEffects.LEVITATION))
            return false;
        if (waterCheck.getValue() && (mc.player.isInWater() || mc.player.isInLava()))
            return false;
        if (mc.player.isSneaking())
            return false;
        if (skipWhileBridging.getValue() && isScaffoldToggled())
            return false;
        if (onlyWhenTargeting.getValue() && !isFacingTarget())
            return false;
        return random.nextInt(100) < chance.getValue();
    }

    private boolean isScaffoldToggled() {
        Module scaffold = client.module.ModuleManager.getModuleByName("Scaffold");
        return scaffold != null && scaffold.isToggled();
    }

    private boolean isFacingTarget() {
        Vec3d look = mc.player.getLookVec();
        for (EntityPlayer other : mc.world.playerEntities) {
            if (other == null || other == mc.player)
                continue;
            double dx = other.posX - mc.player.posX;
            double dy = other.posY + other.height * 0.5 - (mc.player.posY + mc.player.getEyeHeight());
            double dz = other.posZ - mc.player.posZ;
            double distSq = dx * dx + dy * dy + dz * dz;
            if (distSq > 36.0)
                continue;
            double len = Math.sqrt(distSq);
            if (len < 1.0E-4)
                continue;
            if (look.xCoord * dx / len + look.yCoord * dy / len + look.zCoord * dz / len > 0.5) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onTick() {
        if (mc.player == null)
            return;
        if (waitingForReset) {
            if (round3(mc.player.motionX) == round3(motionX) && round3(mc.player.motionY) == round3(motionY) && round3(mc.player.motionZ) == round3(motionZ)) {
                waitingForReset = false;
                retryTicks = 0;
                if (!mc.gameSettings.keyBindJump.isKeyDown()) {
                    shouldJump = true;
                }
            }
        }
        if (shouldJump) {
            if (retryTicks >= 2) {
                shouldJump = false;
                return;
            }
            if (random.nextInt(100) >= accuracy.getValue()) {
                retryTicks++;
                return;
            }
            if (mc.player.isSneaking() || !mc.player.onGround) {
                shouldJump = false;
                return;
            }
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), true);
            jumping = true;
            shouldJump = false;
            client.utils.combat.CombatContext.recordJumpReset();
        }
    }

    @Override
    public void onPostUpdate() {
        releaseJumpKey();
    }

    private void releaseJumpKey() {
        if (!jumping)
            return;
        boolean screenBlocking = mc.currentScreen != null && !mc.currentScreen.allowUserInput;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), !screenBlocking && Keyboard.isKeyDown(mc.gameSettings.keyBindJump.getKeyCode()));
        jumping = false;
    }

    private static double round3(double v) {
        return Math.round(v * 1000.0) / 1000.0;
    }
}
