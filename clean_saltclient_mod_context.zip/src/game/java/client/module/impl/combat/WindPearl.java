package client.module.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.NumberSetting;
import client.event.events.WorldChangeEvent;
import client.utils.misc.ChatUtils;
import client.utils.world.InteractionUtils;
import client.utils.world.MaceUtils;

public class WindPearl extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Mode", "Classic", "Classic", "Boost");

    private final NumberSetting pitch = new NumberSetting("Pitch", 90.0, 45.0, 90.0);

    private final NumberSetting delay = new NumberSetting("Delay", 0.0, 0.0, 10.0);

    private final NumberSetting boostDelay = new NumberSetting("Boost Delay", 6.0, 2.0, 40.0);

    private enum Phase {

        VALIDATE,
        BOOST_AIM,
        BOOST_FIRE,
        BOOST_RIDE,
        PEARL_AIM,
        PEARL_THROW,
        CHARGE_WAIT
    }

    private Phase phase = Phase.VALIDATE;

    private int waitTicks = 0;

    private int savedSlot = -1;

    private float savedPitch = 0.0f;

    public WindPearl() {
        super("WindPearl", Category.MACE);
        setDescription("Throws a enderpearl then windcharge to let you go high in mace pvp");
        addSetting(mode);
        addSetting(pitch);
        addSetting(delay);
        addSetting(boostDelay);
        handles(HandlerType.UPDATE, HandlerType.WORLD_CHANGE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.currentScreen != null || mc.player.openContainer != mc.player.inventoryContainer)
            return;
        switch(phase) {
            case VALIDATE:
                phaseValidate();
                break;
            case BOOST_AIM:
                phaseBoostAim();
                break;
            case BOOST_FIRE:
                phaseBoostFire();
                break;
            case BOOST_RIDE:
                phaseBoostRide();
                break;
            case PEARL_AIM:
                phasePearlAim();
                break;
            case PEARL_THROW:
                phasePearlThrow();
                break;
            case CHARGE_WAIT:
                phaseChargeWait();
                break;
        }
    }

    private void phaseValidate() {
        boolean boost = "Boost".equalsIgnoreCase(mode.getValue());
        int chargesNeeded = boost ? 2 : 1;
        if (findPearlSlot() == -1) {
            ChatUtils.error("WindPearl: no ender pearl in the hotbar");
            setToggled(false);
            return;
        }
        if (countWindCharges() < chargesNeeded) {
            ChatUtils.error("WindPearl: needs " + chargesNeeded + (chargesNeeded > 1 ? " wind charges" : " wind charge") + " in the hotbar");
            setToggled(false);
            return;
        }
        savedSlot = mc.player.inventory.currentItem;
        savedPitch = mc.player.rotationPitch;
        phase = boost ? Phase.BOOST_AIM : Phase.PEARL_AIM;
    }

    private void phaseBoostAim() {
        mc.player.rotationPitch = 90.0f;
        phase = Phase.BOOST_FIRE;
    }

    private void phaseBoostFire() {
        mc.player.jump();
        if (!fireWindCharge()) {
            abort("WindPearl: ran out of wind charges");
            return;
        }
        waitTicks = boostDelay.getValue().intValue();
        phase = Phase.BOOST_RIDE;
    }

    private void phaseBoostRide() {
        if (waitTicks > 0) {
            waitTicks--;
            return;
        }
        phase = Phase.PEARL_AIM;
    }

    private void phasePearlAim() {
        mc.player.rotationPitch = -pitch.getValue().floatValue();
        phase = Phase.PEARL_THROW;
    }

    private void phasePearlThrow() {
        int pearlSlot = findPearlSlot();
        if (pearlSlot == -1) {
            abort("WindPearl: ender pearl gone");
            return;
        }
        mc.player.inventory.currentItem = pearlSlot;
        InteractionUtils.useItem(EnumHand.MAIN_HAND);
        mc.player.swingArm(EnumHand.MAIN_HAND);
        waitTicks = delay.getValue().intValue();
        phase = Phase.CHARGE_WAIT;
    }

    private void phaseChargeWait() {
        if (waitTicks > 0) {
            waitTicks--;
            mc.player.rotationPitch = -pitch.getValue().floatValue();
            return;
        }
        if (!fireWindCharge()) {
            abort("WindPearl: ran out of wind charges");
            return;
        }
        ChatUtils.success("WindPearl combo launched");
        setToggled(false);
    }

    private boolean fireWindCharge() {
        int chargeSlot = MaceUtils.findWindChargeSlot();
        if (chargeSlot == -1)
            return false;
        mc.player.inventory.currentItem = chargeSlot;
        InteractionUtils.useItem(EnumHand.MAIN_HAND);
        mc.player.swingArm(EnumHand.MAIN_HAND);
        return true;
    }

    private void abort(String message) {
        ChatUtils.error(message);
        setToggled(false);
    }

    private int findPearlSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack != null && !stack.func_190926_b() && stack.getItem() == Items.ENDER_PEARL) {
                return i;
            }
        }
        return -1;
    }

    private int countWindCharges() {
        int count = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack != null && !stack.func_190926_b() && MaceUtils.isWindCharge(stack)) {
                count += stack.func_190916_E();
            }
        }
        return count;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        resetState();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.player != null && savedSlot != -1) {
            mc.player.inventory.currentItem = savedSlot;
            mc.player.rotationPitch = savedPitch;
        }
        resetState();
    }

    @Override
    public void onWorldChange(WorldChangeEvent event) {
        setToggled(false);
        resetState();
    }

    private void resetState() {
        phase = Phase.VALIDATE;
        waitTicks = 0;
        savedSlot = -1;
        savedPitch = 0.0f;
    }
}
