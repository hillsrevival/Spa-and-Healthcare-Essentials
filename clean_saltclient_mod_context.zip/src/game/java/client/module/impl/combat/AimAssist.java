package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.NumberSetting;
import client.utils.movement.RotationUtils;
import client.utils.combat.AimUtils;
import client.utils.combat.RotationProfile;
import client.utils.combat.TargetSelector;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.Vec3d;

public class AimAssist extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting preset = new ModeSetting("Preset", "Custom", "Custom", "Snap", "Track", "Lazy", "Legit");

    private String lastPreset = null;

    private final NumberSetting rotationSpeed = new NumberSetting("Speed", 20.0, 5.0, 360.0);

    private final ModeSetting aimPoint = new ModeSetting("AimPoint", "Body", "Center", "Head", "Body", "Nearest");

    private final NumberSetting jitter = new NumberSetting("Jitter", 0.5, 0.0, 5.0);

    private final BooleanSetting gcdFix = new BooleanSetting("GCD Fix", true);

    private final NumberSetting range = new NumberSetting("Range", 6.0, 1.0, 10.0);

    private final ModeSetting priority = new ModeSetting("Priority", "Angle", "Distance", "Angle", "Health");

    private final NumberSetting fov = new NumberSetting("FOV", 360.0, 30.0, 360.0);

    private final BooleanSetting targetPlayers = new BooleanSetting("Players", true);

    private final ModeSetting mobMode = new ModeSetting("Mobs", "Hostile", "Hostile", "Passive", "Both");

    private final BooleanSetting targetInvisible = new BooleanSetting("Invisible", true);

    private EntityLivingBase currentTarget;

    public AimAssist() {
        super("AimAssist", Category.COMBAT);
        setDescription("Aims your crosshair at entities");
        addSetting(preset);
        addSetting(rotationSpeed);
        addSetting(aimPoint);
        addSetting(jitter);
        addSetting(gcdFix);
        addSetting(range);
        addSetting(priority);
        addSetting(fov);
        addSetting(targetPlayers);
        addSetting(mobMode);
        addSetting(targetInvisible);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        String presetName = preset.getValue();
        if (lastPreset == null || !lastPreset.equals(presetName)) {
            lastPreset = presetName;
            if (!presetName.equals("Custom")) {
                RotationProfile.Params params = RotationProfile.getParams(RotationProfile.Profile.valueOf(presetName.toUpperCase()));
                rotationSpeed.setValue((double) params.rotationSpeed);
                jitter.setValue((double) params.jitter);
            }
        }
        if (mc.currentScreen != null)
            return;
        EntityLivingBase target = findTarget();
        if (target == null) {
            currentTarget = null;
            return;
        }
        currentTarget = target;
        RotationUtils.AimPoint aim = RotationUtils.AimPoint.BODY;
        String aimStr = aimPoint.getValue();
        if (aimStr.equals("Head"))
            aim = RotationUtils.AimPoint.HEAD;
        else if (aimStr.equals("Center"))
            aim = RotationUtils.AimPoint.CENTER;
        else if (aimStr.equals("Nearest"))
            aim = RotationUtils.AimPoint.NEAREST;
        Vec3d point = AimUtils.predictAimPoint(target, aim, AimUtils.getLatencyLeadTicks());
        float[] needed = RotationUtils.getNeededRotations(point);
        float speed = (float) (double) rotationSpeed.getValue();
        float[] smoothRots = RotationUtils.smoothRotate(mc.player.rotationYaw, mc.player.rotationPitch, needed[0], needed[1], speed);
        if (jitter.getValue() > 0) {
            smoothRots = RotationUtils.addJitter(smoothRots[0], smoothRots[1], (float) (double) jitter.getValue());
        }
        if (gcdFix.getValue()) {
            smoothRots = RotationUtils.fixRotations(smoothRots[0], smoothRots[1]);
        }
        mc.player.rotationYaw = smoothRots[0];
        mc.player.rotationPitch = smoothRots[1];
    }

    @Override
    public void onDisable() {
        super.onDisable();
        currentTarget = null;
        RotationUtils.resetRotation();
    }

    private EntityLivingBase findTarget() {
        TargetSelector.Criteria c = new TargetSelector.Criteria();
        c.targetPlayers = targetPlayers.getValue();
        TargetSelector.Criteria.applyMobMode(c, mobMode.getValue());
        c.targetInvisible = targetInvisible.getValue();
        c.hitThroughWalls = false;
        c.range = range.getValue();
        c.fov = fov.getValue();
        c.aimLeadTicks = -1.0;
        return TargetSelector.selectTarget(c, priority.getValue());
    }
}
