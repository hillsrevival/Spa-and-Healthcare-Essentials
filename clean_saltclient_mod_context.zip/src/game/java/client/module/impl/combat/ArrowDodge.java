package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.util.math.Vec3d;
import client.utils.EntityUtils;

public class ArrowDodge extends Module {

    private final java.util.HashMap<Integer, Integer> dodgeCooldown = new java.util.HashMap<>();

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting dodgeSpeed = new NumberSetting("Speed", 0.5, 0.1, 1.5);

    public ArrowDodge() {
        super("ArrowDodge", Category.COMBAT);
        setDescription("Automatically strafes to dodge arrows");
        addSetting(dodgeSpeed);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        double dodgeD = dodgeSpeed.getValue().doubleValue();
        for (Object obj : EntityUtils.getLoadedEntities()) {
            if (!(obj instanceof EntityArrow))
                continue;
            EntityArrow arrow = (EntityArrow) obj;
            double dist = mc.player.getDistanceToEntity(arrow);
            if (dist > 10 || dist < 1)
                continue;
            Vec3d arrowVel = new Vec3d(arrow.motionX, arrow.motionY, arrow.motionZ);
            Vec3d toPlayer = new Vec3d(mc.player.posX - arrow.posX, mc.player.posY + mc.player.getEyeHeight() - arrow.posY, mc.player.posZ - arrow.posZ);
            double arrowSpeed = arrowVel.lengthVector();
            if (arrowSpeed < 0.1)
                continue;
            Vec3d arrowDir = arrowVel.normalize();
            Vec3d toPlayerDir = toPlayer.normalize();
            double dot = arrowDir.dotProduct(toPlayerDir);
            if (dot < 0.8)
                continue;
            Integer until = dodgeCooldown.get(Integer.valueOf(arrow.getEntityId()));
            if (until != null && arrow.ticksExisted < until.intValue())
                continue;
            double perpX = -arrow.motionZ;
            double perpZ = arrow.motionX;
            double perpLen = Math.sqrt(perpX * perpX + perpZ * perpZ);
            if (perpLen > 0.01) {
                perpX /= perpLen;
                perpZ /= perpLen;
                double intensity = dodgeD * (1.0 - dist / 10.0);
                double vx = mc.player.motionX + perpX * intensity;
                double vz = mc.player.motionZ + perpZ * intensity;
                double hspeed = Math.sqrt(vx * vx + vz * vz);
                if (hspeed > 0.35) {
                    double scale = 0.35 / hspeed;
                    vx *= scale;
                    vz *= scale;
                }
                mc.player.motionX = vx;
                mc.player.motionZ = vz;
                dodgeCooldown.put(arrow.getEntityId(), Integer.valueOf(arrow.ticksExisted + 5));
            }
        }
    }
}
