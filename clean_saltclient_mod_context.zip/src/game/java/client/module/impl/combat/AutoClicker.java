package client.module.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.utils.combat.CombatAttackExecutor;
import client.utils.combat.CombatUtils;
import client.utils.world.InteractionUtils;

public class AutoClicker extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting button = new ModeSetting("Button", "Left", "Left", "Right");

    private final BooleanSetting holdToClick = new BooleanSetting("Hold to Click", true);

    private final NumberSetting minCPS = new NumberSetting("Min CPS", 9.0, 1.0, 20.0);

    private final NumberSetting maxCPS = new NumberSetting("Max CPS", 14.0, 1.0, 20.0);

    private final BooleanSetting hold = new BooleanSetting("Hold", true);

    private final BooleanSetting cooldownCheck = new BooleanSetting("Cooldown Check", true);

    private final NumberSetting minCooldown = new NumberSetting("Min Cooldown", 50.0, 0.0, 100.0);

    private final BooleanSetting swingArm = new BooleanSetting("Swing Arm", true);

    private final BooleanSetting hitOnHitBoxOnly = new BooleanSetting("Hit On HitBox Only", true);

    private final CombatUtils.AttackTimer attackTimer = new CombatUtils.AttackTimer();

    public AutoClicker() {
        super("AutoClicker", Category.COMBAT);
        setDescription("Clicks automatically");
        addSetting(button);
        addSetting(holdToClick);
        addSetting(minCPS);
        addSetting(maxCPS);
        addSetting(hold);
        addSetting(cooldownCheck);
        addSetting(minCooldown);
        addSetting(swingArm);
        addSetting(hitOnHitBoxOnly);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.currentScreen != null)
            return;
        boolean isLeft = button.getValue().equals("Left");
        if (isLeft) {
            if (!holdToClick.getValue() || mc.gameSettings.keyBindAttack.isKeyDown()) {
                doLeftClick();
            }
        } else {
            if (hold.getValue()) {
                doRightHold();
            } else {
                if (!holdToClick.getValue() || mc.gameSettings.keyBindUseItem.isKeyDown()) {
                    doRightClick();
                }
            }
        }
    }

    private void doLeftClick() {
        int min = (int) Math.round(minCPS.getValue());
        int max = (int) Math.round(maxCPS.getValue());
        if (max < min)
            max = min;
        if (!attackTimer.canAttack(min, max))
            return;
        if (cooldownCheck.getValue()) {
            float threshold = (float) (minCooldown.getValue() / 100.0F);
            if (!CombatUtils.isWeaponReady(threshold))
                return;
        }
        if (hitOnHitBoxOnly.getValue()) {
            if (mc.objectMouseOver == null)
                return;
            if (mc.objectMouseOver.entityHit == null)
                return;
            Entity target = mc.objectMouseOver.entityHit;
            if (!(target instanceof EntityLivingBase))
                return;
            EntityLivingBase living = (EntityLivingBase) target;
            if (!living.isEntityAlive())
                return;
            CombatAttackExecutor.directAttack(living, 3.03, swingArm.getValue());
        } else {
            KeyBinding.onTick(mc.gameSettings.keyBindAttack.getKeyCode());
        }
    }

    private void doRightHold() {
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
    }

    private void doRightClick() {
        int min = (int) (double) minCPS.getValue();
        int max = (int) (double) maxCPS.getValue();
        if (!attackTimer.canAttack(min, max))
            return;
        if (mc.rightClickDelayTimer > 0)
            return;
        if (mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == net.minecraft.util.math.RayTraceResult.Type.BLOCK) {
            BlockPos pos = mc.objectMouseOver.getBlockPos();
            EnumFacing facing = mc.objectMouseOver.sideHit;
            Vec3d hitVec = mc.objectMouseOver.hitVec;
            InteractionUtils.placeBlock(pos, facing, hitVec, EnumHand.MAIN_HAND);
            mc.player.swingArm(EnumHand.MAIN_HAND);
        } else {
            mc.rightClickMouse();
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        attackTimer.reset();
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
    }
}
