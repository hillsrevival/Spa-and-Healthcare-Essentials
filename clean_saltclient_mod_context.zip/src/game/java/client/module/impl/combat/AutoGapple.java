package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.player.FindItemResult;
import client.utils.player.InvUtils;
import client.utils.player.SlotUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Items;
import java.util.Random;

public class AutoGapple extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Random rand = new Random();

    private final NumberSetting health = new NumberSetting("Health", 10.0, 1.0, 19.0);

    private final NumberSetting switchDelay = new NumberSetting("SwitchDelay", 2.0, 0.0, 10.0);

    private final client.utils.player.PendingSlotSwitch switcher = new client.utils.player.PendingSlotSwitch();

    private boolean eating = false;

    private int actualSwitchDelay = 0;

    private int inactiveTicks = 0;

    public AutoGapple() {
        super("AutoGapple", Category.COMBAT);
        setDescription("Automatically eats golden apples when your health is low");
        addSetting(health);
        addSetting(switchDelay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (switcher.hasPending()) {
            if (switcher.tick()) {
                switcher.applySwitch();
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
                eating = true;
            }
            return;
        }
        if (eating) {
            if (!mc.player.isHandActive()) {
                inactiveTicks++;
                if (inactiveTicks >= 3) {
                    stopEating();
                }
            } else {
                inactiveTicks = 0;
            }
            return;
        }
        float hp = mc.player.getHealth() + mc.player.getAbsorptionAmount();
        float maxHp = mc.player.getMaxHealth();
        float hpPercent = (hp / maxHp) * 20.0f;
        if (hpPercent > health.getValue().floatValue())
            return;
        if (mc.player.isHandActive())
            return;
        if (mc.currentScreen != null)
            return;
        FindItemResult result = InvUtils.findInHotbar(stack -> stack.getItem() == Items.GOLDEN_APPLE && stack.getMetadata() == 0);
        if (!result.found()) {
            float realHp = mc.player.getHealth() + mc.player.getAbsorptionAmount();
            if (realHp > 4.0f)
                return;
            result = InvUtils.findInHotbar(stack -> stack.getItem() == Items.GOLDEN_APPLE && stack.getMetadata() == 1);
        }
        int slot = result.found() ? result.slot() - SlotUtils.HOTBAR_START : -1;
        if (slot == -1)
            return;
        switcher.queue(slot, switchDelay.getValue().intValue());
    }

    private void stopEating() {
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
        switcher.restore();
        eating = false;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        stopEating();
    }
}
