package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.NumberSetting;
import client.utils.movement.RotationUtils;
import client.utils.combat.CombatUtils;
import client.utils.combat.SilentAimUtil;
import client.utils.combat.CombatAttackExecutor;
import client.utils.combat.CombatContext;
import client.utils.combat.CombatDecisionMaker;
import client.utils.combat.OpponentTracker;
import client.utils.combat.OpponentHealthTracker;
import client.utils.combat.EntityMotionDeviationUtil;
import client.utils.EntityUtils;
import client.utils.GrimBypass;
import client.utils.world.MaceUtils;
import client.Client;
import client.module.impl.combat.Backtrack;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.Vec3d;

public class AutoMace extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private static final double ACQUIRE_MARGIN = 4.0;

    private static final float ROT_SPEED_MIN = 60.0f;

    private static final float ROT_SPEED_MAX = 80.0f;

    private static final int SLOT_RESTORE_GRACE = 2;

    private static final int ATTACK_PRIORITY = 95;

    private final NumberSetting minFallDist = new NumberSetting("MinFall", 3.0, 1.0, 20.0);

    private final NumberSetting range = new NumberSetting("Range", 3.03, 1.0, 3.03);

    private final NumberSetting leadTicks = new NumberSetting("LeadTicks", 2.0, 1.0, 4.0);

    private final BooleanSetting autoSwap = new BooleanSetting("AutoSwap", true);

    private final BooleanSetting swingArm = new BooleanSetting("SwingArm", true);

    private final BooleanSetting targetPlayers = new BooleanSetting("TargetPlayers", true);

    private final BooleanSetting targetMobs = new BooleanSetting("TargetMobs", true);

    private final BooleanSetting targetAnimals = new BooleanSetting("TargetAnimals", false);

    private final BooleanSetting guiCheck = new BooleanSetting("GUICheck", true);

    private final ModeSetting aimPoint = new ModeSetting("AimPoint", "Body", "Center", "Head", "Body", "Nearest");

    private final BooleanSetting gcdFix = new BooleanSetting("GCDFix", true);

    private final NumberSetting jitter = new NumberSetting("Jitter", 0.5, 0.0, 3.0);

    private final BooleanSetting failswingCheck = new BooleanSetting("Failswing", true);

    private final NumberSetting fov = new NumberSetting("FOV", 360.0, 30.0, 360.0);

    private final ModeSetting slotMode = new ModeSetting("MaceSlot", "Default", "Default", "1", "2", "3", "4", "5", "6", "7", "8", "9");

    private int lastSlot = -1;

    private int activeMaceSlot = -1;

    private int attackDelay = 0;

    private boolean silentOwned = false;

    private int pauseTicks = 0;

    private int disarmTicks = 0;

    private float lastServerYaw = 0.0f;

    private float lastServerPitch = 0.0f;

    private EntityLivingBase armedTarget = null;

    private EntityLivingBase tickTarget = null;

    private double tickReach = 3.03;

    private boolean canAttack = false;

    public AutoMace() {
        super("AutoMace", Category.MACE);
        setDescription("Smash with the mace while falling");
        addSetting(minFallDist);
        addSetting(range);
        leadTicks.setStep(1.0);
        addSetting(leadTicks);
        addSetting(autoSwap);
        addSetting(swingArm);
        addSetting(targetPlayers);
        addSetting(targetMobs);
        addSetting(targetAnimals);
        addSetting(aimPoint);
        addSetting(gcdFix);
        addSetting(jitter);
        addSetting(failswingCheck);
        addSetting(fov);
        addSetting(guiCheck);
        addSetting(slotMode);
        handles(HandlerType.TICK, HandlerType.UPDATE, HandlerType.WORLD_CHANGE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        lastSlot = -1;
        activeMaceSlot = -1;
        attackDelay = 0;
        disarmTicks = 0;
        pauseTicks = 0;
        tickTarget = null;
        armedTarget = null;
        canAttack = false;
        silentOwned = false;
        if (mc.player != null) {
            lastServerYaw = mc.player.rotationYaw;
            lastServerPitch = mc.player.rotationPitch;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        SilentAimUtil.restoreMovementKeys();
        SilentAimUtil.setRotationCritical("AutoMace", false);
        boolean ownedClaim = SilentAimUtil.isOwnedBy("AutoMace");
        if (ownedClaim) {
            SilentAimUtil.endStreak();
        }
        SilentAimUtil.onDisable("AutoMace");
        if (ownedClaim) {
            Client.INSTANCE.physicsConsistentAim = false;
        }
        silentOwned = false;
        restoreSlot();
        tickTarget = null;
        armedTarget = null;
        canAttack = false;
        attackDelay = 0;
        disarmTicks = 0;
        RotationUtils.resetRotation();
    }

    @Override
    public void onWorldChange(client.event.events.WorldChangeEvent event) {
        restoreSlot();
        SilentAimUtil.setRotationCritical("AutoMace", false);
        tickTarget = null;
        armedTarget = null;
        canAttack = false;
        attackDelay = 0;
        disarmTicks = 0;
        pauseTicks = 0;
        lastSlot = -1;
        OpponentTracker.onWorldChange();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            tickTarget = null;
            canAttack = false;
            return;
        }
        if (attackDelay > 0)
            attackDelay--;
        if (guiCheck.getValue() && mc.currentScreen != null) {
            pauseTicks = 1;
        }
        if (pauseTicks > 0) {
            pauseTicks--;
            tickTarget = null;
            canAttack = false;
            SilentAimUtil.setRotationCritical("AutoMace", false);
            if (silentOwned) {
                boolean pausedConverged = SilentAimUtil.tickTowardQuant(SilentAimUtil.getRealYaw(), SilentAimUtil.getRealPitch(), 25f, 55f, false, false);
                SilentAimUtil.restoreMovementKeys();
                if (pausedConverged) {
                    releaseIdleClaim();
                }
            }
            return;
        }
        if (silentOwned && !SilentAimUtil.isOwnedBy("AutoMace")) {
            silentOwned = false;
            SilentAimUtil.setRotationCritical("AutoMace", false);
        }
        if (SilentAimUtil.isActive()) {
            lastServerYaw = SilentAimUtil.getServerYaw();
            lastServerPitch = SilentAimUtil.getServerPitch();
        } else {
            lastServerYaw = mc.player.rotationYaw;
            lastServerPitch = mc.player.rotationPitch;
        }
        boolean falling = !mc.player.onGround && !mc.player.isInWater() && !mc.player.isOnLadder() && mc.player.fallDistance >= minFallDist.getValue().floatValue();
        int maceSlot = -1;
        EntityLivingBase target = null;
        if (falling) {
            maceSlot = resolveMaceSlot();
            boolean maceUsable = maceSlot != -1 && (autoSwap.getValue() || maceSlot == mc.player.inventory.currentItem);
            if (maceUsable) {
                double attackReach = Math.min(range.getValue(), MaceUtils.MAX_GRIM_REACH);
                target = findTarget(attackReach + ACQUIRE_MARGIN);
            }
        }
        if (target == null) {
            idleTick();
            return;
        }
        disarmTicks = 0;
        armedTarget = target;
        if (maceSlot != mc.player.inventory.currentItem) {
            if (lastSlot == -1)
                lastSlot = mc.player.inventory.currentItem;
            activeMaceSlot = maceSlot;
            mc.player.inventory.currentItem = maceSlot;
        }
        double effReach = Math.min(range.getValue(), MaceUtils.MAX_GRIM_REACH);
        OpponentTracker.configure(effReach, fov.getValue(), targetPlayers.getValue(), targetMobs.getValue(), targetAnimals.getValue(), false, false, "Distance");
        CombatContext.beginTick();
        OpponentTracker.update();
        CombatDecisionMaker.configureTactical(false);
        RotationUtils.AimPoint aim = parseAimPoint(aimPoint.getValue());
        Vec3d aimVec = RotationUtils.getAimPoint(target, aim);
        int lead = leadTicks.getValue().intValue();
        Vec3d predicted = client.utils.combat.PlayerSimulationUtil.predictWithFallback(target, lead);
        aimVec = aimVec.add(new Vec3d(predicted.xCoord - target.posX, predicted.yCoord - target.posY, predicted.zCoord - target.posZ));
        aimVec = aimVec.subtract(new Vec3d(mc.player.motionX * lead, mc.player.onGround ? 0.0 : mc.player.motionY * lead, mc.player.motionZ * lead));
        GrimBypass.Config config = new GrimBypass.Config().withRotationSpeed(45.0f).withAimPoint(aim).withJitter(jitter.getValue().floatValue()).withVariance(0.25f).withGCD(gcdFix.getValue()).withNoFailswing(true).withMaxReach(effReach).withFailswingThreshold(5.0f);
        GrimBypass.RotationResult result = GrimBypass.applyRotation(aimVec, lastServerYaw, lastServerPitch, config);
        if (!silentOwned && SilentAimUtil.forceTake("AutoMace")) {
            silentOwned = true;
            SilentAimUtil.startStreak();
            Client.INSTANCE.physicsConsistentAim = true;
        }
        if (silentOwned) {
            SilentAimUtil.setRotationCritical("AutoMace", true);
            SilentAimUtil.tickTowardQuant(result.yaw, result.pitch, ROT_SPEED_MIN, ROT_SPEED_MAX, true, false);
            lastServerYaw = SilentAimUtil.getServerYaw();
            lastServerPitch = SilentAimUtil.getServerPitch();
        } else {
            lastServerYaw = SilentAimUtil.getServerYaw();
            lastServerPitch = SilentAimUtil.getServerPitch();
        }
        canAttack = RotationUtils.isRotationOnEntity(lastServerYaw, lastServerPitch, target, effReach);
        if (!canAttack) {
            double dirX = -Math.sin(Math.toRadians(lastServerYaw)) * Math.cos(Math.toRadians(lastServerPitch));
            double dirY = -Math.sin(Math.toRadians(lastServerPitch));
            double dirZ = Math.cos(Math.toRadians(lastServerYaw)) * Math.cos(Math.toRadians(lastServerPitch));
            Vec3d eyePos = mc.player.getPositionEyes(1.0f);
            double deviation = EntityMotionDeviationUtil.calculateDeviation(eyePos.xCoord, eyePos.yCoord, eyePos.zCoord, dirX, dirY, dirZ, aimVec.xCoord, aimVec.yCoord, aimVec.zCoord, target.width, target.height, 0.0);
            if (deviation < 0.1) {
                canAttack = true;
            }
        }
        tickTarget = target;
        tickReach = effReach;
        Backtrack.setTarget(target);
        if (canAttack) {
            executeAttackPreFlying();
        }
    }

    private void idleTick() {
        tickTarget = null;
        canAttack = false;
        SilentAimUtil.setRotationCritical("AutoMace", false);
        armedTarget = null;
        disarmTicks++;
        if (silentOwned) {
            boolean converged = SilentAimUtil.tickTowardQuant(SilentAimUtil.getRealYaw(), SilentAimUtil.getRealPitch(), 25f, 55f, false, false);
            SilentAimUtil.restoreMovementKeys();
            if (converged) {
                releaseIdleClaim();
            }
        }
        if (disarmTicks >= SLOT_RESTORE_GRACE) {
            restoreSlot();
        }
    }

    private void releaseIdleClaim() {
        if (!silentOwned)
            return;
        if (SilentAimUtil.isOwnedBy("AutoMace")) {
            SilentAimUtil.endStreak();
            SilentAimUtil.onDisable("AutoMace");
            Client.INSTANCE.physicsConsistentAim = false;
        }
        silentOwned = false;
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) {
            SilentAimUtil.restoreMovementKeys();
            return;
        }
        if (guiCheck.getValue() && mc.currentScreen != null) {
            pauseTicks = 1;
        }
        if (pauseTicks > 0) {
            pauseTicks--;
            SilentAimUtil.restoreMovementKeys();
            tickTarget = null;
            canAttack = false;
            return;
        }
        if (silentOwned) {
            SilentAimUtil.restoreMovementKeys();
        }
        if (tickTarget != null && tickTarget.isEntityAlive()) {
            SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindForward);
            SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindLeft);
            SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindRight);
            SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindBack);
        }
        tickTarget = null;
        canAttack = false;
    }

    private void executeAttackPreFlying() {
        EntityLivingBase target = tickTarget;
        if (target == null || !canAttack)
            return;
        if (!CombatContext.shouldEngage()) {
            canAttack = false;
            return;
        }
        if (failswingCheck.getValue() && !RotationUtils.isRotationOnEntity(lastServerYaw, lastServerPitch, target, tickReach)) {
            canAttack = false;
            return;
        }
        if (!target.isEntityAlive() || target.getHealth() <= 0) {
            canAttack = false;
            return;
        }
        if (!CombatUtils.isReachValid(target, tickReach)) {
            canAttack = false;
            return;
        }
        if (attackDelay > 0) {
            canAttack = false;
            return;
        }
        if (!client.utils.combat.AttackControlClaim.shouldAttack("AutoMace", ATTACK_PRIORITY)) {
            canAttack = false;
            return;
        }
        int maceSlot = resolveMaceSlot();
        int axeSlot = findAxeSlot(maceSlot);
        boolean preCrit = !mc.player.onGround && mc.player.fallDistance > 0.0f && !mc.player.isInWater() && mc.player.isSprinting();
        if (axeSlot != -1 && maceSlot != -1 && axeSlot != maceSlot && target.isActiveItemStackBlocking()) {
            boolean smashed = false;
            try {
                mc.player.inventory.currentItem = axeSlot;
                CombatAttackExecutor.directAttack(target, tickReach);
                mc.player.inventory.currentItem = maceSlot;
                smashed = CombatAttackExecutor.executePreFlyingAttack(target, tickReach, swingArm.getValue());
            } finally {
                // Never strand the player on the axe if an interaction throws.
                mc.player.inventory.currentItem = maceSlot;
            }
            if (smashed) {
                Backtrack.onAttack();
                attackDelay = 1;
                OpponentHealthTracker.recordAttack(target, preCrit);
            }
        } else {
            boolean attacked = CombatAttackExecutor.executePreFlyingAttack(target, tickReach, swingArm.getValue());
            if (attacked) {
                Backtrack.onAttack();
                attackDelay = 1;
                OpponentHealthTracker.recordAttack(target, preCrit);
            }
        }
        canAttack = false;
    }

    private EntityLivingBase findTarget(double acquireReach) {
        EntityUtils.TargetSettings settings = new EntityUtils.TargetSettings().setRange((float) acquireReach).setFOV(fov.getValue().floatValue()).setTargetPlayers(targetPlayers.getValue()).setTargetMonsters(targetMobs.getValue()).setTargetAnimals(targetAnimals.getValue());
        if (armedTarget != null && EntityUtils.isCorrectEntity(armedTarget, settings) && CombatUtils.getReachDistance(armedTarget) <= acquireReach + 1.0 && client.module.impl.mace.MaceTargetFilter.allows(armedTarget)) {
            return armedTarget;
        }
        EntityLivingBase best = null;
        double bestReach = acquireReach;
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (!(entity instanceof EntityLivingBase))
                continue;
            if (!EntityUtils.isCorrectEntity(entity, settings))
                continue;
            if (!client.module.impl.mace.MaceTargetFilter.allows((EntityLivingBase) entity))
                continue;
            double dist = CombatUtils.getReachDistance(entity);
            if (dist <= bestReach) {
                bestReach = dist;
                best = (EntityLivingBase) entity;
            }
        }
        return best;
    }

    private RotationUtils.AimPoint parseAimPoint(String mode) {
        switch(mode) {
            case "Head":
                return RotationUtils.AimPoint.HEAD;
            case "Nearest":
                return RotationUtils.AimPoint.NEAREST;
            case "Center":
                return RotationUtils.AimPoint.CENTER;
            default:
                return RotationUtils.AimPoint.BODY;
        }
    }

    private int resolveMaceSlot() {
        String mode = slotMode.getValue();
        if (mode.equals("Default")) {
            return MaceUtils.findMaceSlot();
        }
        int slot;
        try {
            slot = Integer.parseInt(mode) - 1;
        } catch (NumberFormatException ignored) {
            return -1;
        }
        if (slot >= 0 && slot <= 8 && MaceUtils.isMaceSlot(slot)) {
            return slot;
        }
        return -1;
    }

    private int findAxeSlot(int excludeSlot) {
        if (mc.player == null)
            return -1;
        for (int i = 0; i < 9; i++) {
            if (i == excludeSlot)
                continue;
            net.minecraft.item.ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == null || stack.func_190926_b())
                continue;
            net.minecraft.item.Item item = stack.getItem();
            if (item instanceof net.minecraft.item.ItemAxe) {
                if (MaceUtils.isMaceSlot(i))
                    continue;
                return i;
            }
        }
        return -1;
    }

    private void restoreSlot() {
        if (lastSlot != -1 && mc.player != null) {
            // Respect a manual hotbar change made while AutoMace was armed.
            if (activeMaceSlot < 0 || mc.player.inventory.currentItem == activeMaceSlot)
                mc.player.inventory.currentItem = lastSlot;
            lastSlot = -1;
            activeMaceSlot = -1;
        }
    }
}
