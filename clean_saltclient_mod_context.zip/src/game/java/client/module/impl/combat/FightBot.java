package client.module.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.combat.AimUtils;
import client.utils.combat.CombatAttackExecutor;
import client.utils.combat.TargetSelector;
import client.utils.movement.RotationUtils;
import client.utils.combat.CombatUtils;
import client.utils.EntityUtils;

public class FightBot extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 3.03, 1.0, 4.5);

    private final NumberSetting minCooldown = new NumberSetting("Min Cooldown", 50.0, 0.0, 100.0);

    private final BooleanSetting swing = new BooleanSetting("Swing Arm", true);

    private final BooleanSetting hitThroughWalls = new BooleanSetting("ThroughWalls", false);

    private EntityLivingBase tickTarget = null;

    private boolean rotatedThisTick = false;

    private float prevYaw = 0.0f;

    private float prevPitch = 0.0f;

    public FightBot() {
        super("FightBot", Category.COMBAT);
        setDescription("Attacks nearby entities");
        addSetting(range);
        addSetting(minCooldown);
        addSetting(swing);
        handles(HandlerType.TICK, HandlerType.UPDATE);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            tickTarget = null;
            return;
        }
        float threshold = (float) (minCooldown.getValue() / 100.0F);
        if (!CombatUtils.isWeaponReady(threshold)) {
            tickTarget = null;
            return;
        }
        TargetSelector.Criteria c = new TargetSelector.Criteria();
        c.targetPlayers = false;
        c.targetHostile = true;
        c.targetPassive = false;
        c.targetInvisible = true;
        c.hitThroughWalls = hitThroughWalls.getValue();
        c.range = range.getValue();
        c.fov = 360.0;
        c.aimLeadTicks = -1.0;
        EntityLivingBase target = TargetSelector.selectTarget(c, "Distance");
        if (target == null) {
            tickTarget = null;
            return;
        }
        float[] rotations = RotationUtils.getNeededRotations(AimUtils.predictAimPoint(target, RotationUtils.AimPoint.CENTER, AimUtils.getLatencyLeadTicks()));
        prevYaw = mc.player.rotationYaw;
        prevPitch = mc.player.rotationPitch;
        mc.player.rotationYaw = rotations[0];
        mc.player.rotationPitch = rotations[1];
        rotatedThisTick = true;
        tickTarget = target;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        EntityLivingBase target = tickTarget;
        tickTarget = null;
        if (target == null)
            return;
        if (!EntityUtils.isAlive(target))
            return;
        if (!CombatUtils.isReachValid(target, range.getValue()))
            return;
        CombatAttackExecutor.directAttack(target, range.getValue(), swing.getValue());
        client.utils.combat.OpponentHealthTracker.recordAttack(target, false);
        if (rotatedThisTick) {
            mc.player.rotationYaw = prevYaw;
            mc.player.rotationPitch = prevPitch;
            rotatedThisTick = false;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        tickTarget = null;
        rotatedThisTick = false;
    }
}
