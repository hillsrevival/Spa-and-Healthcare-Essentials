package client.module.impl.combat;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class SelfTrap extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting delay = new NumberSetting("Delay", 2.0, 1.0, 10.0);

    private int tickCounter = 0;

    public SelfTrap() {
        super("SelfTrap", Category.COMBAT);
        setDescription("Places obsidian above your head");
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        tickCounter++;
        int delayTicks = delay.getValue().intValue();
        if (tickCounter < delayTicks)
            return;
        tickCounter = 0;
        int blockSlot = findSolidBlock();
        if (blockSlot == -1)
            return;
        int playerX = (int) Math.floor(mc.player.posX);
        int playerY = (int) Math.floor(mc.player.posY);
        int playerZ = (int) Math.floor(mc.player.posZ);
        BlockPos headAbovePos = new BlockPos(playerX, playerY + 2, playerZ);
        if (!WorldUtils.isAir(headAbovePos))
            return;
        EnumFacing[] facings = { EnumFacing.DOWN, EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.EAST, EnumFacing.WEST, EnumFacing.UP };
        for (EnumFacing facing : facings) {
            BlockPos neighbor = headAbovePos.offset(facing);
            if (!WorldUtils.isAir(neighbor)) {
                int savedSlot = mc.player.inventory.currentItem;
                mc.player.inventory.currentItem = blockSlot;
                InteractionUtils.placeBlock(neighbor, facing.getOpposite(), new Vec3d(neighbor.x + 0.5 + facing.getOpposite().getFrontOffsetX() * 0.5, neighbor.y + 0.5 + facing.getOpposite().getFrontOffsetY() * 0.5, neighbor.z + 0.5 + facing.getOpposite().getFrontOffsetZ() * 0.5), EnumHand.MAIN_HAND);
                mc.player.inventory.currentItem = savedSlot;
                return;
            }
        }
    }

    private int findSolidBlock() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == null || stack.func_190926_b())
                continue;
            if (stack.getItem() instanceof ItemBlock) {
                ItemBlock itemBlock = (ItemBlock) stack.getItem();
                if (itemBlock.getBlock() == Blocks.OBSIDIAN) {
                    return i;
                }
            }
        }
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == null || stack.func_190926_b())
                continue;
            if (stack.getItem() instanceof ItemBlock) {
                ItemBlock itemBlock = (ItemBlock) stack.getItem();
                if (itemBlock.getBlock() != Blocks.AIR && itemBlock.getBlock() != Blocks.TNT && itemBlock.getBlock() != Blocks.SAND && itemBlock.getBlock() != Blocks.GRAVEL) {
                    return i;
                }
            }
        }
        return -1;
    }
}
