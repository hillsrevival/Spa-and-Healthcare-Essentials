package client.module.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class Burrow extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Mode", "Any Block", "Any Block", "Obby Only");

    private final BooleanSetting autoDisable = new BooleanSetting("AutoDisable", true);

    private boolean done = false;

    public Burrow() {
        super("Burrow", Category.COMBAT);
        setDescription("Places a block at your feet and clips inside it");
        addSetting(mode);
        addSetting(autoDisable);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        done = false;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (done)
            return;
        if (!mc.player.onGround)
            return;
        BlockPos feetPos = new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY), Math.floor(mc.player.posZ));
        if (!WorldUtils.isAir(feetPos)) {
            if (autoDisable.getValue())
                toggle();
            return;
        }
        int blockSlot = findBlockSlot();
        if (blockSlot == -1)
            return;
        EnumFacing dir = null;
        for (EnumFacing facing : EnumFacing.values()) {
            BlockPos neighbor = feetPos.offset(facing);
            if (!WorldUtils.isAir(neighbor)) {
                dir = facing;
                break;
            }
        }
        if (dir == null)
            return;
        BlockPos neighbor = feetPos.offset(dir);
        Vec3d hitVec = new Vec3d(neighbor.getX() + 0.5, neighbor.getY() + 0.5, neighbor.getZ() + 0.5);
        int savedSlot = mc.player.inventory.currentItem;
        mc.player.inventory.currentItem = blockSlot;
        InteractionUtils.placeBlock(neighbor, dir.getOpposite(), hitVec, EnumHand.MAIN_HAND);
        mc.player.setPosition(Math.floor(mc.player.posX) + 0.5, feetPos.getY(), Math.floor(mc.player.posZ) + 0.5);
        mc.player.inventory.currentItem = savedSlot;
        done = true;
        if (autoDisable.getValue())
            toggle();
    }

    private int findBlockSlot() {
        boolean obbyOnly = mode.getValue().equals("Obby Only");
        client.utils.player.FindItemResult r = client.utils.player.InvUtils.findInHotbar(stack -> {
            if (stack == null || stack.func_190926_b())
                return false;
            if (!(stack.getItem() instanceof ItemBlock))
                return false;
            if (obbyOnly) {
                return ((ItemBlock) stack.getItem()).getBlock() == Blocks.OBSIDIAN;
            }
            return true;
        });
        return r.found() ? r.slot() - client.utils.player.SlotUtils.HOTBAR_START : -1;
    }
}
