package client.module.impl.combat;

import java.util.Random;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.event.events.AttackEvent;
import client.utils.combat.CombatAttackExecutor;
import client.utils.combat.CombatContext;
import client.utils.world.PacketUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

public class CritTiming extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Random random = new Random();

    private final ModeSetting mode = new ModeSetting("Mode", "Jump", "Packet", "Jump", "Mini-Jump");

    private final BooleanSetting onlyFirstHit = new BooleanSetting("Only First Hit", true);

    private final BooleanSetting skipAirborne = new BooleanSetting("Skip Airborne Targets", true);

    private final BooleanSetting skipRetreating = new BooleanSetting("Skip Retreating Targets", true);

    private final BooleanSetting requireOnGround = new BooleanSetting("Require On Ground", true);

    private final NumberSetting maxComboForCrit = new NumberSetting("Max Combo For Crit", 2.0, 1.0, 10.0);

    private final BooleanSetting smartCritPicker = new BooleanSetting("Smart Crit Picker", true);

    private final NumberSetting killOverkillMargin = new NumberSetting("Kill Overkill Margin", 0.5, 0.0, 3.0);

    private final BooleanSetting burstFinish = new BooleanSetting("Burst Finish", false);

    private boolean critUsedThisCombo = false;

    private boolean weDroppedSprint = false;

    public CritTiming() {
        super("CritTiming", Category.COMBAT);
        setDescription("Times crits to the first hit of each combo");
        addSetting(mode);
        addSetting(onlyFirstHit);
        addSetting(skipAirborne);
        addSetting(skipRetreating);
        addSetting(requireOnGround);
        addSetting(maxComboForCrit);
        addSetting(smartCritPicker);
        addSetting(killOverkillMargin);
        addSetting(burstFinish);
        handles(HandlerType.ATTACK, HandlerType.TICK, HandlerType.POST_UPDATE);
    }

    @Override
    public void onAttack(AttackEvent event) {
        if (mc.player == null)
            return;
        Entity target = event.getTarget();
        if (target == null)
            return;
        if (!(target instanceof EntityLivingBase))
            return;
        EntityLivingBase livingTarget = (EntityLivingBase) target;
        if (mc.player.isInWater() || mc.player.isInLava())
            return;
        if (mc.player.isOnLadder())
            return;
        if (mc.player.isInWeb)
            return;
        if (mc.player.isRiding())
            return;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held == null || held.func_190926_b())
            return;
        if (!(held.getItem() instanceof ItemSword))
            return;
        boolean killHit = smartCritPicker.getValue() && isKillHit(livingTarget, held);
        if (mc.player.isSprinting()) {
            if (!killHit)
                return;
            mc.player.setSprinting(false);
            weDroppedSprint = true;
        }
        if (!killHit) {
            if (onlyFirstHit.getValue() && critUsedThisCombo) {
                return;
            }
            int playerCombo = CombatContext.getPlayerComboCount();
            if (playerCombo > (int) (double) maxComboForCrit.getValue()) {
                return;
            }
            if (skipAirborne.getValue() && CombatContext.isOpponentAirborne()) {
                return;
            }
            if (skipRetreating.getValue()) {
                double approach = client.utils.combat.TargetPrediction.getApproachVelocity(livingTarget);
                if (approach < -0.05)
                    return;
            }
        }
        if (requireOnGround.getValue() && !mc.player.onGround)
            return;
        sendCritPackets();
        critUsedThisCombo = true;
        CombatContext.setCanCritNow(true);
    }

    private boolean isKillHit(EntityLivingBase target, ItemStack held) {
        float health = client.utils.combat.OpponentHealthTracker.getEstimatedHealth(target);
        if (target instanceof EntityPlayer) {
            health += ((EntityPlayer) target).getAbsorptionAmount();
        }
        float critDamage = client.utils.combat.OpponentHealthTracker.calculateAttackDamage(held, target, true);
        float window = critDamage + killOverkillMargin.getValue().floatValue();
        if (burstFinish.getValue()) {
            window += critDamage;
        }
        return health <= window;
    }

    @Override
    public void onTick() {
        if (mc.player == null)
            return;
        if (weDroppedSprint) {
            weDroppedSprint = false;
            client.utils.combat.SprintPolicy.reSprintAfterAttack();
        }
        if (CombatContext.getLastHitter() == -1) {
            critUsedThisCombo = false;
        }
        if (CombatContext.getPlayerComboCount() == 0 && CombatContext.getOpponentComboCount() == 0) {
            critUsedThisCombo = false;
        }
    }

    @Override
    public void onPostUpdate() {
        CombatAttackExecutor.releaseJumpKey();
    }

    private void sendCritPackets() {
        String m = mode.getValue();
        if (m.equals("Jump")) {
            sendJumpCrit();
        } else if (m.equals("Mini-Jump")) {
            sendMiniJumpCrit();
        } else {
            sendPacketCrit();
        }
    }

    private void sendPacketCrit() {
        if (!mc.player.onGround)
            return;
        if (mc.player.hurtTime > 0) {
            sendJumpCrit();
            return;
        }
        double hSpeed = Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ);
        if (hSpeed >= 0.028) {
            sendJumpCrit();
            return;
        }
        double posX = mc.player.posX;
        double posY = mc.player.posY;
        double posZ = mc.player.posZ;
        double micro = 0.0001 + random.nextDouble() * 0.0002;
        PacketUtils.sendPosition(posX, posY + micro, posZ, false);
        PacketUtils.sendPosition(posX, posY, posZ, false);
    }

    private void sendJumpCrit() {
        if (!mc.player.onGround)
            return;
        CombatAttackExecutor.injectVanillaJump();
    }

    private void sendMiniJumpCrit() {
        if (!mc.player.onGround)
            return;
        CombatAttackExecutor.injectVanillaJump();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        critUsedThisCombo = false;
        weDroppedSprint = false;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (weDroppedSprint && mc.player != null) {
            client.utils.movement.MovementUtils.reSprint();
        }
        weDroppedSprint = false;
        critUsedThisCombo = false;
        CombatContext.setCanCritNow(false);
    }

    public boolean isSprintDropped() {
        return weDroppedSprint;
    }
}
