package client.module.impl.combat;

import java.util.List;
import client.event.listeners.RenderListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.ModuleManager;
import client.utils.combat.AimUtils;
import client.utils.combat.CombatContext;
import client.utils.combat.CombatDecisionMaker;
import client.utils.combat.TargetSelector;
import client.utils.combat.CombatTracker;
import client.utils.combat.CombatUtils;
import client.utils.EntityUtils;
import client.utils.GrimBypass;
import client.utils.combat.CombatAttackExecutor;
import client.utils.combat.OpponentTracker;
import client.utils.render.RenderUtils;
import client.utils.movement.RotationUtils;
import client.utils.combat.SilentAimUtil;
import client.Client;
import client.utils.combat.EntityMotionDeviationUtil;
import client.utils.movement.InertialFloatSmoother;
import client.module.impl.combat.Backtrack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;

public class KillAura extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 3.03, 1.0, 6.0);

    private final NumberSetting swingRange = new NumberSetting("Swing Range", 3.2, 1.0, 6.0);

    private final ModeSetting priority = new ModeSetting("Priority", "Distance", "Distance", "Angle", "Health");

    private final NumberSetting fov = new NumberSetting("FOV", 360.0, 30.0, 360.0);

    private final BooleanSetting hitThroughWalls = new BooleanSetting("Hit Through Walls", false);

    private final BooleanSetting targetPlayers = new BooleanSetting("Target Players", true);

    private final ModeSetting mobMode = new ModeSetting("Mobs", "Hostile", "Hostile", "Passive", "Both", "None");

    private final BooleanSetting targetInvisible = new BooleanSetting("Target Invisible", true);

    private final ModeSetting aimPoint = new ModeSetting("Aim Point", "Body", "Center", "Head", "Body", "Nearest");

    private final NumberSetting rotationSpeed = new NumberSetting("Rot Speed", 60.0, 5.0, 180.0);

    private final NumberSetting jitter = new NumberSetting("Jitter", 1.0, 0.0, 5.0);

    private final NumberSetting rotVariance = new NumberSetting("Rot Variance", 25.0, 0.0, 50.0);

    private final BooleanSetting gcdFix = new BooleanSetting("GCD Fix", true);

    private final BooleanSetting silentAim = new BooleanSetting("SilentAim", true);

    private final BooleanSetting inertialSmooth = new BooleanSetting("Inertial Smooth", false);

    private final BooleanSetting perfectSwing = new BooleanSetting("Perfect Swing", true);

    private final BooleanSetting raceMode = new BooleanSetting("Race Mode", false);

    private final NumberSetting minAPS = new NumberSetting("Min APS", 6.0, 1.0, 20.0);

    private final NumberSetting maxAPS = new NumberSetting("Max APS", 12.0, 1.0, 20.0);

    private final BooleanSetting autoUnblock = new BooleanSetting("Auto Unblock", false);

    private final BooleanSetting showTarget = new BooleanSetting("Show Target", false);

    private final BooleanSetting disableOnDeath = new BooleanSetting("Disable On Death", true);

    private final BooleanSetting guiCheck = new BooleanSetting("GUI Check", true);

    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 0.5, 0.0, 10.0);

    private final NumberSetting predictionTicks = new NumberSetting("Prediction Ticks", 1.0, 0.0, 3.0);

    private final BooleanSetting latencyPrediction = new BooleanSetting("Latency Prediction", true);

    private Module hitSelectModule = null;

    private Module reachModule = null;

    private double getAimLeadTicks() {
        return AimUtils.getAimLeadTicks(latencyPrediction.getValue(), predictionTicks.getValue());
    }

    private final BooleanSetting advanced = new BooleanSetting("Advanced", false);

    private EntityLivingBase renderTarget;

    private float lastPartialTicks = 0.0f;

    private EntityLivingBase tickTarget = null;

    private EntityLivingBase manualTarget = null;

    private double manualReach = 3.03;

    private boolean manualCanAttack = false;

    private boolean silentAimOwned = false;

    private boolean canAttack = false;

    private float lastServerYaw = 0.0f;

    private float lastServerPitch = 0.0f;

    private EntityLivingBase currentLockedTarget = null;

    private int currentSwitchDelay = 0;

    private final CombatUtils.AttackTimer attackTimer = new CombatUtils.AttackTimer();

    private int pauseTicks = 0;

    private double lastEffectiveReach = 3.03;

    private final InertialFloatSmoother yawSmoother = new InertialFloatSmoother();

    private final InertialFloatSmoother pitchSmoother = new InertialFloatSmoother();

    public KillAura() {
        super("KillAura", Category.COMBAT);
        setDescription("Attack entities around you");
        addSetting(range);
        addSetting(swingRange);
        addSetting(priority);
        addSetting(fov);
        addSetting(hitThroughWalls);
        addSetting(targetPlayers);
        addSetting(mobMode);
        addSetting(targetInvisible);
        addSetting(aimPoint);
        addSetting(rotationSpeed);
        addSetting(jitter);
        addSetting(rotVariance);
        addSetting(gcdFix);
        addSetting(silentAim);
        addSetting(inertialSmooth);
        addSetting(perfectSwing);
        addSetting(raceMode);
        addSetting(minAPS);
        addSetting(maxAPS);
        addSetting(autoUnblock);
        addSetting(showTarget);
        addSetting(disableOnDeath);
        addSetting(guiCheck);
        addSetting(switchDelay);
        addSetting(predictionTicks);
        addSetting(latencyPrediction);
        addSetting(advanced);
        swingRange.setVisibilityCondition(client.module.Condition.whenTrue(advanced));
        rotVariance.setVisibilityCondition(client.module.Condition.whenTrue(advanced));
        gcdFix.setVisibilityCondition(client.module.Condition.whenTrue(advanced));
        inertialSmooth.setVisibilityCondition(client.module.Condition.whenTrue(advanced));
        predictionTicks.setVisibilityCondition(client.module.Condition.whenTrue(advanced));
        latencyPrediction.setVisibilityCondition(client.module.Condition.whenTrue(advanced));
        switchDelay.setVisibilityCondition(client.module.Condition.whenTrue(advanced));
        minAPS.setVisibilityCondition(client.module.Condition.whenFalse(perfectSwing));
        maxAPS.setVisibilityCondition(client.module.Condition.whenFalse(perfectSwing));
        handles(HandlerType.TICK, HandlerType.UPDATE, HandlerType.RENDER, HandlerType.WORLD_CHANGE);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            tickTarget = null;
            canAttack = false;
            manualTarget = null;
            manualCanAttack = false;
            return;
        }
        OpponentTracker.configure(range.getValue(), fov.getValue(), targetPlayers.getValue(), mobMode.getValue().equals("Hostile") || mobMode.getValue().equals("Both"), mobMode.getValue().equals("Passive") || mobMode.getValue().equals("Both"), targetInvisible.getValue(), hitThroughWalls.getValue(), priority.getValue());
        CombatDecisionMaker.configureTactical(hitSelectModule != null && hitSelectModule.isToggled());
        OpponentTracker.update();
        if (silentAimOwned && !SilentAimUtil.isOwnedBy("KillAura")) {
            silentAimOwned = false;
        } else if (!silentAimOwned && silentAim.getValue()) {
            if (!SilentAimUtil.isActive()) {
                if (!getValidTargets().isEmpty()) {
                    silentAimOwned = SilentAimUtil.onEnable("KillAura");
                }
            } else if (!getValidTargets().isEmpty() && SilentAimUtil.forceTake("KillAura")) {
                silentAimOwned = true;
            }
            if (silentAimOwned) {
                SilentAimUtil.startStreak();
                Client.INSTANCE.physicsConsistentAim = true;
            }
        }
        if (!silentAim.getValue() || !silentAimOwned) {
            if (silentAimOwned && !silentAim.getValue()) {
                releaseIdleClaim();
            }
            if (SilentAimUtil.isOwnedBy("KillAura")) {
                SilentAimUtil.endStreak();
                Client.INSTANCE.physicsConsistentAim = false;
            }
            tickTarget = null;
            canAttack = false;
            if (!SilentAimUtil.isActive() || SilentAimUtil.isOwnedBy("KillAura")) {
                runManualRotationTick();
                if (manualCanAttack && manualTarget != null && client.utils.combat.AttackControlClaim.shouldAttack("KillAura", 100)) {
                    boolean attacked = CombatAttackExecutor.executePreFlyingAttack(manualTarget, manualReach);
                    if (attacked) {
                        Backtrack.onAttack();
                        boolean crit = AimUtils.isCritPossible();
                        client.utils.combat.OpponentHealthTracker.recordAttack(manualTarget, crit);
                    }
                }
                manualTarget = null;
                manualCanAttack = false;
            }
            return;
        }
        if (guiCheck.getValue() && mc.currentScreen != null) {
            pauseTicks = 1;
        }
        if (pauseTicks > 0) {
            pauseTicks--;
            boolean pausedConverged = false;
            if (silentAimOwned) {
                pausedConverged = SilentAimUtil.tickTowardQuant(SilentAimUtil.getRealYaw(), SilentAimUtil.getRealPitch(), 25f, 55f, false, false);
                SilentAimUtil.restoreMovementKeys();
            }
            if (pausedConverged) {
                releaseIdleClaim();
            }
            tickTarget = null;
            canAttack = false;
            return;
        }
        if (disableOnDeath.getValue() && (mc.player.isDead || mc.player.getHealth() <= 0.0f)) {
            SilentAimUtil.restoreMovementKeys();
            toggle();
            return;
        }
        if (perfectSwing.getValue() && !isSwingReady()) {
            SilentAimUtil.tickTowardQuant(SilentAimUtil.getRealYaw(), SilentAimUtil.getRealPitch(), 25f, 55f, false, false);
            SilentAimUtil.restoreMovementKeys();
            tickTarget = null;
            canAttack = false;
            return;
        }
        if (!perfectSwing.getValue() && !attackTimer.canAttack(minAPS.getValue().intValue(), maxAPS.getValue().intValue())) {
            SilentAimUtil.tickTowardQuant(SilentAimUtil.getRealYaw(), SilentAimUtil.getRealPitch(), 25f, 55f, false, false);
            SilentAimUtil.restoreMovementKeys();
            tickTarget = null;
            canAttack = false;
            return;
        }
        List<EntityLivingBase> targets = getValidTargets();
        if (targets.isEmpty()) {
            boolean idleConverged = false;
            if (silentAimOwned) {
                idleConverged = SilentAimUtil.tickTowardQuant(SilentAimUtil.getRealYaw(), SilentAimUtil.getRealPitch(), 25f, 55f, false, false);
                SilentAimUtil.restoreMovementKeys();
            }
            if (idleConverged) {
                releaseIdleClaim();
            }
            tickTarget = null;
            canAttack = false;
            currentLockedTarget = null;
            renderTarget = null;
            return;
        }
        EntityLivingBase entity = sortByPriority(targets);
        if (!EntityUtils.isAlive(entity)) {
            SilentAimUtil.tickTowardQuant(SilentAimUtil.getRealYaw(), SilentAimUtil.getRealPitch(), 25f, 55f, false, false);
            SilentAimUtil.restoreMovementKeys();
            tickTarget = null;
            canAttack = false;
            return;
        }
        EntityLivingBase resolved = handleTargetSwitch(entity);
        boolean inSwitchDelay = (resolved == null);
        if (inSwitchDelay) {
            resolved = entity;
        }
        tickTarget = resolved;
        renderTarget = resolved;
        Backtrack.setTarget(resolved);
        boolean hitSelectBlocks = false;
        if ((hitSelectModule != null && hitSelectModule.isToggled()) && CombatContext.getTarget() != null && !CombatContext.shouldEngage()) {
            hitSelectBlocks = true;
        }
        double effectiveReach = range.getValue();
        if (reachModule != null && reachModule.isToggled()) {
            effectiveReach = client.utils.combat.ReachBalancer.getEffectiveReach(resolved);
        }
        lastEffectiveReach = effectiveReach;
        Vec3d predictedAimVec = AimUtils.predictAimPoint(resolved, resolveAimPoint(), getAimLeadTicks());
        GrimBypass.Config config = new GrimBypass.Config().withRotationSpeed(rotationSpeed.getValue().floatValue()).withAimPoint(resolveAimPoint()).withJitter(jitter.getValue().floatValue()).withVariance(rotVariance.getValue().floatValue() / 100.0f).withGCD(gcdFix.getValue()).withNoFailswing(true).withMaxReach(effectiveReach).withFailswingThreshold(5.0f);
        GrimBypass.RotationResult result = GrimBypass.applyRotation(predictedAimVec, lastServerYaw, lastServerPitch, config);
        boolean grimBypassCanAttack = result.canAttack && !inSwitchDelay && !hitSelectBlocks;
        if (grimBypassCanAttack) {
            boolean rotationOnTarget = RotationUtils.isRotationOnEntity(result.yaw, result.pitch, resolved, effectiveReach);
            double dirX = -Math.sin(Math.toRadians(result.yaw)) * Math.cos(Math.toRadians(result.pitch));
            double dirY = -Math.sin(Math.toRadians(result.pitch));
            double dirZ = Math.cos(Math.toRadians(result.yaw)) * Math.cos(Math.toRadians(result.pitch));
            Vec3d eyePos = mc.player.getPositionEyes(1.0f);
            double deviation = EntityMotionDeviationUtil.calculateDeviation(eyePos.xCoord, eyePos.yCoord, eyePos.zCoord, dirX, dirY, dirZ, predictedAimVec.xCoord, predictedAimVec.yCoord, predictedAimVec.zCoord, resolved.width, resolved.height, 0.0);
            if (!rotationOnTarget && deviation < 0.1) {
                rotationOnTarget = true;
            }
            canAttack = rotationOnTarget;
        } else {
            canAttack = false;
        }
        boolean converged = SilentAimUtil.tickTowardQuant(result.yaw, result.pitch, 40f, 55f, true, false);
        if (!converged) {
            canAttack = false;
        }
        lastServerYaw = SilentAimUtil.getServerYaw();
        lastServerPitch = SilentAimUtil.getServerPitch();
        if (canAttack && tickTarget != null) {
            renderTarget = tickTarget;
            if (autoUnblock.getValue() && mc.gameSettings.keyBindUseItem.isKeyDown()) {
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
                canAttack = false;
            } else if (client.utils.combat.AttackControlClaim.shouldAttack("KillAura", 100)) {
                boolean attacked = CombatAttackExecutor.executePreFlyingAttack(tickTarget, lastEffectiveReach);
                if (attacked) {
                    Backtrack.onAttack();
                    boolean crit = AimUtils.isCritPossible();
                    client.utils.combat.OpponentHealthTracker.recordAttack(tickTarget, crit);
                }
                canAttack = false;
            } else {
                canAttack = false;
            }
        }
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) {
            SilentAimUtil.restoreMovementKeys();
            return;
        }
        if (guiCheck.getValue() && mc.currentScreen != null) {
            pauseTicks = 1;
        }
        if (pauseTicks > 0) {
            pauseTicks--;
            SilentAimUtil.restoreMovementKeys();
            return;
        }
        if (disableOnDeath.getValue() && (mc.player.isDead || mc.player.getHealth() <= 0.0f)) {
            SilentAimUtil.restoreMovementKeys();
            toggle();
            return;
        }
        if (silentAim.getValue() && silentAimOwned) {
            SilentAimUtil.restoreMovementKeys();
            if (tickTarget == null || !tickTarget.isEntityAlive() || tickTarget.getHealth() <= 0) {
                tickTarget = null;
                canAttack = false;
                return;
            }
            renderTarget = tickTarget;
            SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindForward);
            SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindLeft);
            SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindRight);
            SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindBack);
            tickTarget = null;
            canAttack = false;
            return;
        }
        manualTarget = null;
        manualCanAttack = false;
    }

    private void releaseIdleClaim() {
        if (!silentAimOwned)
            return;
        if (SilentAimUtil.isOwnedBy("KillAura")) {
            SilentAimUtil.endStreak();
            SilentAimUtil.onDisable("KillAura");
            Client.INSTANCE.physicsConsistentAim = false;
        }
        silentAimOwned = false;
    }

    private void runManualRotationTick() {
        manualTarget = null;
        manualCanAttack = false;
        if (guiCheck.getValue() && mc.currentScreen != null) {
            pauseTicks = 1;
        }
        if (pauseTicks > 0) {
            pauseTicks--;
            SilentAimUtil.restoreMovementKeys();
            return;
        }
        if (disableOnDeath.getValue() && (mc.player.isDead || mc.player.getHealth() <= 0.0f)) {
            SilentAimUtil.restoreMovementKeys();
            toggle();
            return;
        }
        if (perfectSwing.getValue() && !isSwingReady()) {
            return;
        }
        if (!perfectSwing.getValue() && !attackTimer.canAttack(minAPS.getValue().intValue(), maxAPS.getValue().intValue())) {
            return;
        }
        List<EntityLivingBase> targets = getValidTargets();
        if (targets.isEmpty()) {
            renderTarget = null;
            currentLockedTarget = null;
            return;
        }
        EntityLivingBase entity = sortByPriority(targets);
        if (!EntityUtils.isAlive(entity)) {
            renderTarget = null;
            return;
        }
        EntityLivingBase resolved = handleTargetSwitch(entity);
        if (resolved == null) {
            renderTarget = entity;
            return;
        }
        renderTarget = resolved;
        RotationUtils.AimPoint aim = resolveAimPoint();
        Vec3d aimVec = AimUtils.compensateOwnMotion(RotationUtils.getAimPoint(resolved, aim));
        float[] needed = RotationUtils.getNeededRotations(aimVec);
        float speed = rotationSpeed.getValue().floatValue();
        float variancePct = rotVariance.getValue().floatValue() / 100.0f;
        if (variancePct > 0.0f) {
            float v = speed * variancePct;
            speed = speed - v + (float) (Math.random() * v * 2.0);
        }
        float[] smoothRots = RotationUtils.smoothRotate(mc.player.rotationYaw, mc.player.rotationPitch, needed[0], needed[1], speed);
        if (inertialSmooth.getValue()) {
            float responseFactor = speed / 180.0f;
            if (responseFactor > 0.95f)
                responseFactor = 0.95f;
            if (responseFactor < 0.05f)
                responseFactor = 0.05f;
            float yawDelta = needed[0] - mc.player.rotationYaw;
            float pitchDelta = needed[1] - mc.player.rotationPitch;
            while (yawDelta > 180) yawDelta -= 360;
            while (yawDelta < -180) yawDelta += 360;
            float smoothedYawDelta = yawSmoother.update(yawDelta, responseFactor);
            float smoothedPitchDelta = pitchSmoother.update(pitchDelta, responseFactor);
            smoothRots[0] = mc.player.rotationYaw + smoothedYawDelta;
            smoothRots[1] = mc.player.rotationPitch + smoothedPitchDelta;
        }
        if (jitter.getValue() > 0) {
            smoothRots = RotationUtils.addJitter(smoothRots[0], smoothRots[1], jitter.getValue().floatValue());
        }
        if (gcdFix.getValue()) {
            smoothRots = RotationUtils.fixRotations(smoothRots[0], smoothRots[1]);
        }
        double effectiveReach = range.getValue();
        if (reachModule != null && reachModule.isToggled()) {
            effectiveReach = client.utils.combat.ReachBalancer.getEffectiveReach(resolved);
        }
        if (!CombatUtils.isReachValid(resolved, effectiveReach)) {
            return;
        }
        manualReach = effectiveReach;
        mc.player.rotationYaw = smoothRots[0];
        mc.player.rotationPitch = smoothRots[1];
        if (!RotationUtils.isRotationOnEntity(smoothRots[0], smoothRots[1], resolved, effectiveReach)) {
            return;
        }
        if ((hitSelectModule != null && hitSelectModule.isToggled()) && CombatContext.getTarget() != null && !CombatContext.shouldEngage()) {
            return;
        }
        if (autoUnblock.getValue() && mc.gameSettings.keyBindUseItem.isKeyDown()) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
            return;
        }
        manualTarget = resolved;
        manualCanAttack = true;
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (!showTarget.getValue() || renderTarget == null)
            return;
        EntityLivingBase target = renderTarget;
        if (!target.isEntityAlive()) {
            renderTarget = null;
            return;
        }
        float partialTicks = event.getPartialTicks();
        lastPartialTicks = partialTicks;
        RenderUtils.updateCameraPos(partialTicks);
        RenderUtils.prepareGL();
        float maxHp = target.getMaxHealth();
        float hp = target.getHealth();
        float p = maxHp > 0 ? (maxHp - hp) / maxHp : 0;
        float red = Math.min(p * 2F, 1F);
        float green = Math.min(2F - red, 1F);
        AxisAlignedBB box = getTargetBox(target, p);
        RenderUtils.drawSolidBox(box, red, green, 0, 0.25f);
        RenderUtils.drawOutlinedBox(box, red, green, 0, 0.5f);
        RenderUtils.restoreGL();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (silentAim.getValue()) {
            silentAimOwned = SilentAimUtil.onEnable("KillAura");
            if (silentAimOwned) {
                SilentAimUtil.startStreak();
                Client.INSTANCE.physicsConsistentAim = true;
            }
        } else {
            silentAimOwned = false;
        }
        renderTarget = null;
        tickTarget = null;
        manualTarget = null;
        manualCanAttack = false;
        manualReach = 3.03;
        hitSelectModule = ModuleManager.getModuleByName("HitSelect");
        reachModule = ModuleManager.getModuleByName("Reach");
        currentLockedTarget = null;
        currentSwitchDelay = 0;
        canAttack = false;
        pauseTicks = 0;
        if (mc.player != null) {
            lastServerYaw = mc.player.rotationYaw;
            lastServerPitch = mc.player.rotationPitch;
        }
        yawSmoother.reset();
        pitchSmoother.reset();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        SilentAimUtil.restoreMovementKeys();
        renderTarget = null;
        tickTarget = null;
        manualTarget = null;
        manualCanAttack = false;
        currentLockedTarget = null;
        currentSwitchDelay = 0;
        canAttack = false;
        pauseTicks = 0;
        attackTimer.reset();
        targetsCache = null;
        targetsCacheTick = -1;
        OpponentTracker.reset();
        CombatTracker.reset();
        boolean ownedSilentClaim = SilentAimUtil.isOwnedBy("KillAura");
        if (ownedSilentClaim) {
            SilentAimUtil.endStreak();
        }
        SilentAimUtil.onDisable("KillAura");
        if (ownedSilentClaim) {
            Client.INSTANCE.physicsConsistentAim = false;
        }
        silentAimOwned = false;
        RotationUtils.resetRotation();
        yawSmoother.reset();
        pitchSmoother.reset();
    }

    @Override
    public void onWorldChange(client.event.events.WorldChangeEvent event) {
        OpponentTracker.onWorldChange();
        targetsCache = null;
        targetsCacheTick = -1;
    }

    private List<EntityLivingBase> targetsCache;

    private int targetsCacheTick = -1;

    private List<EntityLivingBase> getValidTargets() {
        int tick = mc.player != null ? mc.player.ticksExisted : -1;
        if (targetsCache == null || targetsCacheTick != tick) {
            targetsCache = TargetSelector.getValidTargets(buildCriteria());
            targetsCacheTick = tick;
        }
        return targetsCache;
    }

    private TargetSelector.Criteria buildCriteria() {
        TargetSelector.Criteria c = new TargetSelector.Criteria();
        c.targetPlayers = targetPlayers.getValue();
        TargetSelector.Criteria.applyMobMode(c, mobMode.getValue());
        c.targetInvisible = targetInvisible.getValue();
        c.hitThroughWalls = hitThroughWalls.getValue();
        c.range = swingRange.getValue();
        c.fov = fov.getValue();
        c.aimLeadTicks = getAimLeadTicks();
        return c;
    }

    private EntityLivingBase sortByPriority(List<EntityLivingBase> targets) {
        TargetSelector.sortByPriority(targets, priority.getValue(), getAimLeadTicks());
        return targets.get(0);
    }

    private boolean isSwingReady() {
        if (CombatUtils.isWeaponFullyCharged())
            return true;
        if (!raceMode.getValue())
            return false;
        if (CombatUtils.getCooldownProgress() < 0.9F)
            return false;
        if (CombatContext.getTicksSinceOpponentSwing() > 20)
            return false;
        long tradeWindow = CombatContext.getTradeWindowTicks();
        return tradeWindow <= 2;
    }

    private float getAngleToEntity(EntityLivingBase entity) {
        return TargetSelector.getPredictedAngleToEntity(entity, getAimLeadTicks());
    }

    private EntityLivingBase handleTargetSwitch(EntityLivingBase desired) {
        if (desired != currentLockedTarget) {
            currentLockedTarget = desired;
            int delay = (int) (double) switchDelay.getValue();
            currentSwitchDelay = delay > 0 ? 2 + (int) (Math.random() * delay) : 0;
        }
        if (currentSwitchDelay > 0) {
            currentSwitchDelay--;
            return null;
        }
        return desired;
    }

    private RotationUtils.AimPoint resolveAimPoint() {
        String str = aimPoint.getValue();
        if (str.equals("Head"))
            return RotationUtils.AimPoint.HEAD;
        if (str.equals("Center"))
            return RotationUtils.AimPoint.CENTER;
        if (str.equals("Nearest"))
            return RotationUtils.AimPoint.NEAREST;
        return RotationUtils.AimPoint.BODY;
    }

    private AxisAlignedBB getTargetBox(EntityLivingBase target, float damageRatio) {
        double hw = target.width / 2.0;
        double x = target.prevPosX + (target.posX - target.prevPosX) * lastPartialTicks - RenderUtils.camX;
        double y = target.prevPosY + (target.posY - target.prevPosY) * lastPartialTicks - RenderUtils.camY;
        double z = target.prevPosZ + (target.posZ - target.prevPosZ) * lastPartialTicks - RenderUtils.camZ;
        if (damageRatio > 0.0f && damageRatio < 1.0f) {
            double s = 1.0 - damageRatio;
            double cy = y + target.height / 2.0 + 0.05;
            double shw = hw * s;
            double shh = (target.height / 2.0) * s;
            return new AxisAlignedBB(x - shw, cy - shh, z - shw, x + shw, cy + shh, z + shw);
        }
        return new AxisAlignedBB(x - hw, y + 0.05, z - hw, x + hw, y + target.height, z + hw);
    }
}
