package client.module.impl.player;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;

public class Multitask extends Module {

    private final BooleanSetting attackingEntities = new BooleanSetting("AttackingEntities", true);

    public Multitask() {
        super("Multitask", Category.OTHER);
        setDescription("Lets you use items and attack at the same time");
        addSetting(attackingEntities);
        handles(HandlerType.UPDATE);
    }

    public boolean attackingEntities() {
        return isToggled() && attackingEntities.getValue();
    }

    @Override
    public void onUpdate() {
    }
}
