package client.module.impl.player;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.ModeSetting;

public class Rotation extends Module {

    private final ModeSetting yawMode = new ModeSetting("YawMode", "Off", "Off", "Simple", "Smart");

    private final NumberSetting yawAngle = new NumberSetting("YawAngle", 0.0, 0.0, 360.0);

    private final ModeSetting pitchMode = new ModeSetting("PitchMode", "Off", "Off", "Simple", "Smart");

    private final NumberSetting pitchAngle = new NumberSetting("PitchAngle", 0.0, -90.0, 90.0);

    public Rotation() {
        super("Rotation", Category.OTHER);
        setDescription("Locks your yaw and pitch to specific angles");
        addSetting(yawMode);
        addSetting(yawAngle);
        addSetting(pitchMode);
        addSetting(pitchAngle);
        handles(HandlerType.TICK);
    }

    @Override
    public void onTick() {
        if (mc.player == null)
            return;
        String ym = yawMode.getValue();
        if (ym.equals("Simple")) {
            mc.player.rotationYaw = (float) yawAngle.getValue().doubleValue();
        } else if (ym.equals("Smart")) {
            mc.player.rotationYaw = getSmartYaw(mc.player.rotationYaw);
        }
        String pm = pitchMode.getValue();
        if (pm.equals("Simple")) {
            mc.player.rotationPitch = (float) pitchAngle.getValue().doubleValue();
        } else if (pm.equals("Smart")) {
            mc.player.rotationPitch = getSmartPitch(mc.player.rotationPitch);
        }
    }

    private float getSmartYaw(float current) {
        float[] angles = { 0, 45, 90, 135, 180, -135, -90, -45 };
        float best = 0;
        float bestDiff = Float.MAX_VALUE;
        for (float angle : angles) {
            float diff = Math.abs(net.minecraft.util.math.MathHelper.wrapDegrees(current - angle));
            if (diff < bestDiff) {
                bestDiff = diff;
                best = angle;
            }
        }
        return best;
    }

    private float getSmartPitch(float current) {
        float[] angles = { -90, -60, -30, 0, 30, 60, 90 };
        float best = 0;
        float bestDiff = Float.MAX_VALUE;
        for (float angle : angles) {
            float diff = Math.abs(current - angle);
            if (diff < bestDiff) {
                bestDiff = diff;
                best = angle;
            }
        }
        return best;
    }
}
