package client.module.impl.player;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.utils.misc.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.network.Packet;

public class PacketCanceller extends Module {

    private final client.module.StringSetting packetNames = new client.module.StringSetting("Packets", "");

    private final BooleanSetting cancelIncoming = new BooleanSetting("CancelIncoming", true);

    private final BooleanSetting cancelOutgoing = new BooleanSetting("CancelOutgoing", true);

    private String[] cachedNames = new String[0];

    private long lastParse = 0;

    public PacketCanceller() {
        super("PacketCanceller", Category.OTHER);
        setDescription("Cancels specific packets by class name");
        addSetting(packetNames);
        addSetting(cancelIncoming);
        addSetting(cancelOutgoing);
        handles(HandlerType.PACKET_INPUT, HandlerType.PACKET_OUTPUT);
    }

    private String[] getNames() {
        long now = System.currentTimeMillis();
        if (now - lastParse > 2000) {
            String raw = packetNames.getValue();
            if (raw == null || raw.isEmpty()) {
                cachedNames = new String[0];
            } else {
                cachedNames = raw.split("[,\\n]");
                for (int i = 0; i < cachedNames.length; i++) {
                    cachedNames[i] = cachedNames[i].trim();
                }
            }
            lastParse = now;
        }
        return cachedNames;
    }

    private boolean shouldCancel(Packet<?> packet) {
        String[] names = getNames();
        if (names.length == 0)
            return false;
        String className = packet.getClass().getSimpleName();
        for (String name : names) {
            if (name.isEmpty())
                continue;
            if (className.contains(name))
                return true;
        }
        return false;
    }

    @Override
    public void onPacketInput(client.event.events.PacketInputEvent event) {
        if (!cancelIncoming.getValue())
            return;
        if (shouldCancel(event.getPacket())) {
            event.setCancelled(true);
        }
    }

    @Override
    public void onPacketOutput(client.event.events.PacketOutputEvent event) {
        if (!cancelOutgoing.getValue())
            return;
        if (shouldCancel(event.getPacket())) {
            event.setCancelled(true);
        }
    }
}
