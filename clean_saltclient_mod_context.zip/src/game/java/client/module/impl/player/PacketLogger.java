package client.module.impl.player;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.utils.misc.ChatUtils;
import net.minecraft.network.Packet;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PacketLogger extends Module {

    private final BooleanSetting logIncoming = new BooleanSetting("LogIncoming", true);

    private final BooleanSetting logOutgoing = new BooleanSetting("LogOutgoing", true);

    private final BooleanSetting showTimestamp = new BooleanSetting("ShowTimestamp", true);

    public PacketLogger() {
        super("PacketLogger", Category.OTHER);
        setDescription("Logs packets to chat");
        addSetting(logIncoming);
        addSetting(logOutgoing);
        addSetting(showTimestamp);
        handles(HandlerType.PACKET_INPUT, HandlerType.PACKET_OUTPUT);
    }

    private static final SimpleDateFormat TIMESTAMP_FORMAT = new SimpleDateFormat("HH:mm:ss.SSS");

    private final Date scratchDate = new Date();

    @Override
    public void onPacketInput(client.event.events.PacketInputEvent event) {
        if (!logIncoming.getValue())
            return;
        Packet<?> packet = event.getPacket();
        String name = packet.getClass().getSimpleName();
        if (showTimestamp.getValue()) {
            scratchDate.setTime(System.currentTimeMillis());
            String time = TIMESTAMP_FORMAT.format(scratchDate);
            ChatUtils.message("[S2C] " + time + " " + name);
        } else {
            ChatUtils.message("[S2C] " + name);
        }
    }

    @Override
    public void onPacketOutput(client.event.events.PacketOutputEvent event) {
        if (!logOutgoing.getValue())
            return;
        Packet<?> packet = event.getPacket();
        String name = packet.getClass().getSimpleName();
        if (showTimestamp.getValue()) {
            scratchDate.setTime(System.currentTimeMillis());
            String time = TIMESTAMP_FORMAT.format(scratchDate);
            ChatUtils.message("[C2S] " + time + " " + name);
        } else {
            ChatUtils.message("[C2S] " + name);
        }
    }
}
