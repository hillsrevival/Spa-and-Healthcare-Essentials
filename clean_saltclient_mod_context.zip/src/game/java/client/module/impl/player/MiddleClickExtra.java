package client.module.impl.player;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import client.module.ModeSetting;
import client.utils.misc.ChatUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.EnumHand;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayer;

public class MiddleClickExtra extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Pearl", "Pearl", "Firework", "AddFriend");

    private final BooleanSetting swapBack = new BooleanSetting("SwapBack", true);

    private final BooleanSetting notify = new BooleanSetting("Notify", true);

    private boolean wasMiddleDown = false;

    private int savedSlot = -1;

    public MiddleClickExtra() {
        super("MiddleClickExtra", Category.OTHER);
        setDescription("Perform actions when you middle click");
        addSetting(mode);
        addSetting(swapBack);
        addSetting(notify);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        boolean middleDown = net.lax1dude.eaglercraft.Mouse.isButtonDown(2);
        if (middleDown && !wasMiddleDown) {
            String modeVal = mode.getValue();
            if (modeVal.equals("AddFriend")) {
                handleAddFriend();
            } else if (modeVal.equals("Pearl")) {
                handleItemUse(Items.ENDER_PEARL);
            } else if (modeVal.equals("Firework")) {
                handleItemUse(Items.FIREWORKS);
            }
        }
        if (!middleDown && wasMiddleDown && savedSlot != -1 && swapBack.getValue()) {
            mc.player.inventory.currentItem = savedSlot;
            savedSlot = -1;
        }
        wasMiddleDown = middleDown;
    }

    private void handleItemUse(net.minecraft.item.Item item) {
        int slot = findItemInHotbar(item);
        if (slot == -1) {
            if (notify.getValue()) {
                ChatUtils.warning("Item not found in hotbar");
            }
            return;
        }
        if (savedSlot == -1) {
            savedSlot = mc.player.inventory.currentItem;
        }
        mc.player.inventory.currentItem = slot;
        mc.player.connection.sendPacket(new net.minecraft.network.play.client.CPacketHeldItemChange(slot));
        mc.playerController.processRightClick(mc.player, mc.world, EnumHand.MAIN_HAND);
    }

    private void handleAddFriend() {
        if (mc.objectMouseOver == null || mc.objectMouseOver.typeOfHit != RayTraceResult.Type.ENTITY)
            return;
        Entity entity = mc.objectMouseOver.entityHit;
        if (!(entity instanceof EntityPlayer))
            return;
        EntityPlayer player = (EntityPlayer) entity;
        String name = player.getName();
        if (client.utils.misc.FriendManager.isFriend(name)) {
            client.utils.misc.FriendManager.removeFriend(name);
            ChatUtils.info("Removed " + name + " from friends");
        } else {
            client.utils.misc.FriendManager.addFriend(name);
            ChatUtils.info("Added " + name + " as a friend");
        }
    }

    private int findItemInHotbar(net.minecraft.item.Item item) {
        client.utils.player.FindItemResult r = client.utils.player.InvUtils.findInHotbar(item);
        return r.found() ? r.slot() - client.utils.player.SlotUtils.HOTBAR_START : -1;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        wasMiddleDown = false;
        savedSlot = -1;
    }
}
