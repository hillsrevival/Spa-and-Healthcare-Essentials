package client.module.impl;

import client.module.BooleanSetting;
import client.module.Module;
import client.module.ModeSetting;
import client.module.NumberSetting;

public class TargetingConfig {

    private final NumberSetting range;

    private final NumberSetting fov;

    private final BooleanSetting targetPlayers;

    private final ModeSetting mobMode;

    private final BooleanSetting targetInvisible;

    private final BooleanSetting hitThroughWalls;

    private final NumberSetting filterFlying;

    public TargetingConfig(Module module) {
        this(module, 3.03, 1.0, 6.0);
    }

    public TargetingConfig(Module module, double defaultRange, double minRange, double maxRange) {
        range = new NumberSetting("Range", defaultRange, minRange, maxRange);
        fov = new NumberSetting("FOV", 360.0, 30.0, 360.0);
        targetPlayers = new BooleanSetting("Target Players", true);
        mobMode = new ModeSetting("Mobs", "Hostile", "Hostile", "Passive", "Both", "None");
        targetInvisible = new BooleanSetting("Target Invisible", true);
        hitThroughWalls = new BooleanSetting("Hit Through Walls", false);
        filterFlying = new NumberSetting("Filter Flying", 0.0, 0.0, 2.0);
        module.addSetting(range);
        module.addSetting(fov);
        module.addSetting(targetPlayers);
        module.addSetting(mobMode);
        module.addSetting(targetInvisible);
        module.addSetting(hitThroughWalls);
        module.addSetting(filterFlying);
    }

    public NumberSetting getRange() {
        return range;
    }

    public NumberSetting getFOV() {
        return fov;
    }

    public BooleanSetting getTargetPlayers() {
        return targetPlayers;
    }

    public ModeSetting getMobMode() {
        return mobMode;
    }

    public BooleanSetting getTargetInvisible() {
        return targetInvisible;
    }

    public BooleanSetting getHitThroughWalls() {
        return hitThroughWalls;
    }

    public NumberSetting getFilterFlying() {
        return filterFlying;
    }

    public boolean isEntityTypeValid(net.minecraft.entity.EntityLivingBase living) {
        if (living == null)
            return false;
        if (living.isDead || living.getHealth() <= 0)
            return false;
        if (living.isInvisible() && !targetInvisible.getValue())
            return false;
        if (client.utils.misc.FriendManager.isFriend(living))
            return false;
        String mode = mobMode.getValue();
        if (living instanceof net.minecraft.entity.player.EntityPlayer) {
            return targetPlayers.getValue();
        } else if (mode.equals("None")) {
            return false;
        } else if (living instanceof net.minecraft.entity.monster.IMob) {
            return mode.equals("Hostile") || mode.equals("Both");
        } else if (living instanceof net.minecraft.entity.passive.EntityAnimal) {
            return mode.equals("Passive") || mode.equals("Both");
        } else {
            return mode.equals("Passive") || mode.equals("Both");
        }
    }

    public boolean isInRange(net.minecraft.entity.EntityLivingBase living) {
        return living != null && mc != null && mc.player != null && client.utils.combat.CombatUtils.isReachValid(living, range.getValue());
    }

    public boolean isInFOV(net.minecraft.entity.EntityLivingBase living) {
        if (fov.getValue() >= 360.0)
            return true;
        if (living == null || mc == null || mc.player == null)
            return false;
        float angle = client.utils.combat.TargetSelector.getPredictedAngleToEntity(living, -1.0);
        return angle <= fov.getValue() / 2.0;
    }

    public boolean hasLineOfSight(net.minecraft.entity.EntityLivingBase living) {
        if (hitThroughWalls.getValue())
            return true;
        if (living == null || mc == null || mc.player == null)
            return false;
        return mc.player.canEntityBeSeen(living);
    }

    public client.utils.combat.TargetSelector.Criteria buildCriteria() {
        client.utils.combat.TargetSelector.Criteria c = new client.utils.combat.TargetSelector.Criteria();
        c.targetPlayers = targetPlayers.getValue();
        client.utils.combat.TargetSelector.Criteria.applyMobMode(c, mobMode.getValue());
        c.targetInvisible = targetInvisible.getValue();
        c.hitThroughWalls = hitThroughWalls.getValue();
        c.range = range.getValue();
        c.fov = fov.getValue();
        c.aimLeadTicks = -1.0;
        return c;
    }

    public java.util.List<net.minecraft.entity.EntityLivingBase> getValidTargets() {
        return client.utils.combat.TargetSelector.getValidTargets(buildCriteria());
    }

    public void sortByPriority(java.util.List<net.minecraft.entity.EntityLivingBase> targets, String mode) {
        client.utils.combat.TargetSelector.sortByPriority(targets, mode, -1.0);
    }

    public net.minecraft.entity.EntityLivingBase selectBestTarget(String mode) {
        return client.utils.combat.TargetSelector.selectTarget(buildCriteria(), mode);
    }

    private final net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getMinecraft();
}
