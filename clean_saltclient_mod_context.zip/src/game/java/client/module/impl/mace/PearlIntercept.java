package client.module.impl.mace;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import client.module.Category;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.Module;
import client.module.NumberSetting;
import client.utils.misc.NotificationSystem;
import client.utils.world.InteractionUtils;
import client.utils.world.MaceUtils;
import client.utils.world.PacketUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.init.Items;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;

/** Predicts where an enemy's ender pearl lands and throws a counter-projectile to meet it mid-flight. */
public class PearlIntercept extends Module {

    private final ModeSetting action = new ModeSetting("Action", "Throw", "Throw", "AlertOnly");
    private final ModeSetting counter = new ModeSetting("Counter", "Snowball", "Snowball", "Egg", "EnderPearl", "WindCharge");
    private final NumberSetting maxRange = new NumberSetting("MaxRange", 40.0, 8.0, 80.0);
    private final NumberSetting accuracy = new NumberSetting("HitRadius", 1.5, 0.5, 3.0);
    private final NumberSetting throwCooldown = new NumberSetting("ThrowCooldown", 12.0, 3.0, 40.0);

    private final Set<Integer> handled = new HashSet<Integer>();
    private int cooldownTicks = 0;

    public PearlIntercept() {
        super("PearlIntercept", Category.MACE);
        setDescription("Calculates enemy pearl trajectories and throws a counter-projectile to interrupt them");
        addSetting(action);
        addSetting(counter);
        addSetting(maxRange);
        addSetting(accuracy);
        throwCooldown.setStep(1.0);
        addSetting(throwCooldown);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        handled.clear();
        cooldownTicks = 0;
    }

    private static Vec3d dirOf(float yaw, float pitch) {
        double yr = Math.toRadians(yaw);
        double pr = Math.toRadians(pitch);
        return new Vec3d(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
    }

    private List<Vec3d> simulatePearl(EntityEnderPearl p) {
        List<Vec3d> path = new ArrayList<Vec3d>();
        Vec3d pos = new Vec3d(p.posX, p.posY, p.posZ);
        double mx = p.motionX, my = p.motionY, mz = p.motionZ;
        for (int t = 0; t < 120; t++) {
            Vec3d next = new Vec3d(pos.xCoord + mx, pos.yCoord + my, pos.zCoord + mz);
            RayTraceResult hit = mc.world.rayTraceBlocks(pos, next);
            if (hit != null) {
                path.add(hit.hitVec);
                return path;
            }
            pos = next;
            path.add(pos);
            mx *= 0.99;
            my *= 0.99;
            mz *= 0.99;
            my -= 0.03;
            if (pos.yCoord < -10)
                break;
        }
        return path;
    }

    private int counterSlot() {
        String c = counter.getValue();
        if (c.equals("WindCharge"))
            return MaceUtils.findWindChargeSlot();
        for (int i = 0; i < 9; i++) {
            net.minecraft.item.ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == null || stack.func_190926_b())
                continue;
            net.minecraft.item.Item it = stack.getItem();
            if (c.equals("Snowball") && it == Items.SNOWBALL)
                return i;
            if (c.equals("Egg") && it == Items.EGG)
                return i;
            if (c.equals("EnderPearl") && it == Items.ENDER_PEARL)
                return i;
        }
        return -1;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.currentScreen != null || mc.player.openContainer != mc.player.inventoryContainer)
            return;
        if (cooldownTicks > 0)
            cooldownTicks--;
        if (handled.size() > 64)
            handled.clear();
        List<Entity> ents = new ArrayList<Entity>(mc.world.loadedEntityList);
        for (Entity e : ents) {
            if (!(e instanceof EntityEnderPearl) || e.isDead)
                continue;
            EntityEnderPearl pearl = (EntityEnderPearl) e;
            if (!(pearl.getThrower() instanceof net.minecraft.entity.player.EntityPlayer)
                    || pearl.getThrower() == mc.player || handled.contains(pearl.getEntityId()))
                continue;
            double dx = pearl.posX - mc.player.posX;
            double dz = pearl.posZ - mc.player.posZ;
            if (Math.sqrt(dx * dx + dz * dz) > maxRange.getValue())
                continue;
            if (action.getValue().equals("Throw") && cooldownTicks > 0)
                continue;
            handled.add(pearl.getEntityId());
            List<Vec3d> path = simulatePearl(pearl);
            if (path.isEmpty())
                continue;
            Vec3d land = path.get(path.size() - 1);
            NotificationSystem.info("Enemy pearl lands at " + (int) land.xCoord + ", " + (int) land.yCoord + ", " + (int) land.zCoord + " in " + path.size() + " ticks");
            if (action.getValue().equals("Throw"))
                tryIntercept(path);
        }
    }

    private void tryIntercept(List<Vec3d> path) {
        int slot = counterSlot();
        if (slot == -1)
            return;
        double ex = mc.player.posX;
        double ey = mc.player.posY + mc.player.getEyeHeight() - 0.1;
        double ez = mc.player.posZ;
        double bestErr = 1.0e9;
        float bestYaw = 0;
        float bestPitch = 0;
        int limit = Math.min(path.size(), 70);
        for (int t = 4; t <= limit; t++) {
            Vec3d target = path.get(t - 1);
            double dx = target.xCoord - ex;
            double dz = target.zCoord - ez;
            float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            for (float pitch = -85.0f; pitch <= 85.0f; pitch += 1.5f) {
                Vec3d d = dirOf(yaw, pitch);
                double px = ex, py = ey, pz = ez;
                double vx = d.xCoord * 1.5 + mc.player.motionX;
                double vy = d.yCoord * 1.5 + (mc.player.onGround ? 0.0 : mc.player.motionY);
                double vz = d.zCoord * 1.5 + mc.player.motionZ;
                for (int s = 0; s < t; s++) {
                    px += vx;
                    py += vy;
                    pz += vz;
                    vx *= 0.99;
                    vy *= 0.99;
                    vz *= 0.99;
                    vy -= 0.03;
                }
                double err = Math.sqrt((px - target.xCoord) * (px - target.xCoord) + (py - target.yCoord) * (py - target.yCoord) + (pz - target.zCoord) * (pz - target.zCoord));
                if (err < bestErr) {
                    bestErr = err;
                    bestYaw = yaw;
                    bestPitch = pitch;
                }
            }
            if (bestErr <= accuracy.getValue())
                break;
        }
        if (bestErr > accuracy.getValue())
            return;
        int prev = mc.player.inventory.currentItem;
        try {
            PacketUtils.sendRotation(bestYaw, bestPitch, mc.player.onGround);
            mc.player.inventory.currentItem = slot;
            InteractionUtils.useItem(EnumHand.MAIN_HAND);
            mc.player.swingArm(EnumHand.MAIN_HAND);
            cooldownTicks = throwCooldown.getValue().intValue();
        } finally {
            mc.player.inventory.currentItem = prev;
        }
    }
}
