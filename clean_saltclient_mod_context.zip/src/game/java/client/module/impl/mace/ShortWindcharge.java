package client.module.impl.mace;

import client.module.BooleanSetting;
import client.module.Category;
import client.module.Module;
import client.utils.misc.NotificationSystem;
import client.utils.world.WindFire;

public class ShortWindcharge extends Module {

    private final BooleanSetting jump = new BooleanSetting("Jump", true);

    public ShortWindcharge() {
        super("ShortWindcharge", Category.MACE);
        setDescription("One keybind: jumps and fires a wind charge at your feet in the same tick (Auto Jump Wind Charge)");
        addSetting(jump);
        handles();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (!WindFire.fireNow(jump.getValue(), -1))
            NotificationSystem.error("ShortWindcharge: no wind charge in hotbar");
        setToggled(false);
    }
}
