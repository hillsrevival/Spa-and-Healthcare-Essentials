package client.module.impl.mace;

import client.module.BooleanSetting;
import client.module.Category;
import client.module.ModeSetting;
import client.module.Module;
import client.module.ModuleManager;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;

/**
 * Smart Select: AutoMace only strikes targets that are in the exact reach window for a fatal smash.
 * Turn this on next to AutoMace.
 */
public class MaceTargetFilter extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "LethalOnly", "LethalOnly", "InWindowOnly");
    private final NumberSetting horizontal = new NumberSetting("HorizontalRange", 2.9, 1.0, 4.5);
    private final NumberSetting maxBelow = new NumberSetting("MaxBelow", 6.0, 1.0, 20.0);
    private final NumberSetting density = new NumberSetting("DensityLevel", 0.0, 0.0, 5.0);
    private final NumberSetting breach = new NumberSetting("BreachLevel", 0.0, 0.0, 4.0);
    private final NumberSetting margin = new NumberSetting("SafetyMargin", 1.0, 0.8, 1.5);
    private final BooleanSetting armorAware = new BooleanSetting("ArmorAware", true);

    public MaceTargetFilter() {
        super("MaceTargetFilter", Category.MACE);
        setDescription("Only lets AutoMace swing at targets inside the exact range for a fatal falling strike");
        density.setStep(1.0);
        breach.setStep(1.0);
        addSetting(mode);
        addSetting(horizontal);
        addSetting(maxBelow);
        addSetting(density);
        addSetting(breach);
        addSetting(margin);
        addSetting(armorAware);
    }

    public static boolean isActive() {
        Module m = ModuleManager.getModuleByName("MaceTargetFilter");
        return m != null && m.isToggled();
    }

    public static boolean allows(EntityLivingBase target) {
        Module m = ModuleManager.getModuleByName("MaceTargetFilter");
        if (!(m instanceof MaceTargetFilter) || !m.isToggled() || target == null)
            return true;
        return ((MaceTargetFilter) m).check(target);
    }

    private boolean check(EntityLivingBase t) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null)
            return true;
        double dx = t.posX - mc.player.posX;
        double dz = t.posZ - mc.player.posZ;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        double below = mc.player.posY - t.posY;
        if (horiz > horizontal.getValue() || below < -0.5 || below > maxBelow.getValue())
            return false;
        if (mode.getValue().equals("InWindowOnly"))
            return true;
        double dmg = MaceDamageHud.maceDamage(mc.player.fallDistance, density.getValue().intValue());
        if (armorAware.getValue()) {
            double armor = t.getTotalArmorValue() * (1.0 - 0.15 * breach.getValue());
            double tough = t.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue();
            double eff = Math.min(20.0, Math.max(armor / 5.0, armor - dmg / (2.0 + tough / 4.0)));
            dmg = dmg * (1.0 - eff / 25.0);
        }
        // A larger safety margin must make the filter more conservative, not
        // easier to pass. The old multiplication did the exact opposite.
        return dmg >= (t.getHealth() + t.getAbsorptionAmount()) * margin.getValue();
    }
}
