package client.module.impl.mace;

import client.module.BooleanSetting;
import client.module.Category;
import client.module.HandlerType;
import client.event.events.WorldChangeEvent;
import client.module.Module;
import client.module.NumberSetting;
import client.utils.world.InteractionUtils;
import client.utils.world.MaceUtils;
import client.utils.world.SpearUtils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemAxe;

/** Breaks shields: when a nearby player is blocking, hits them with an axe (or a smash if falling). */
public class AutoStunSlam extends Module {

    private final NumberSetting range = new NumberSetting("Range", 3.0, 2.0, 4.5);
    private final BooleanSetting preferMace = new BooleanSetting("PreferMace", true);
    private final NumberSetting minFall = new NumberSetting("MinFall", 2.0, 1.5, 12.0);
    private final NumberSetting charge = new NumberSetting("MinCharge", 0.95, 0.5, 1.0);
    private final NumberSetting restore = new NumberSetting("RestoreDelay", 3.0, 1.0, 10.0);

    private int prevSlot = -1;
    private int restoreTimer = 0;
    private int attackCooldown = 0;
    private int activeSlot = -1;

    public AutoStunSlam() {
        super("AutoStunSlam", Category.MACE);
        setDescription("Tracks shields and auto-hits blockers with an axe or a smash attack to disable them");
        restore.setStep(1.0);
        addSetting(range);
        addSetting(preferMace);
        addSetting(minFall);
        addSetting(charge);
        addSetting(restore);
        handles(HandlerType.UPDATE, HandlerType.WORLD_CHANGE);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        back();
        restoreTimer = 0;
        attackCooldown = 0;
    }

    @Override
    public void onWorldChange(WorldChangeEvent event) {
        back();
        restoreTimer = 0;
        attackCooldown = 0;
    }

    private void back() {
        if (mc.player != null && prevSlot >= 0 && prevSlot < 9
                && (activeSlot < 0 || mc.player.inventory.currentItem == activeSlot))
            mc.player.inventory.currentItem = prevSlot;
        prevSlot = -1;
        activeSlot = -1;
    }

    private int findAxe() {
        for (int i = 0; i < 9; i++) {
            net.minecraft.item.ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack != null && !stack.func_190926_b() && stack.getItem() instanceof ItemAxe)
                return i;
        }
        return -1;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (attackCooldown > 0)
            attackCooldown--;
        if (prevSlot != -1) {
            if (restoreTimer > 0)
                restoreTimer--;
            else
                back();
        }
        if (attackCooldown > 0)
            return;
        EntityPlayer target = null;
        double best = range.getValue();
        for (EntityPlayer p : mc.world.playerEntities) {
            if (p == null || p == mc.player || p.isDead || !p.isActiveItemStackBlocking())
                continue;
            double d = SpearUtils.distanceTo(p);
            if (d <= best) {
                best = d;
                target = p;
            }
        }
        if (target == null)
            return;
        int slot = -1;
        if (preferMace.getValue() && mc.player.fallDistance >= minFall.getValue() && !mc.player.onGround)
            slot = MaceUtils.findMaceSlot();
        if (slot == -1)
            slot = findAxe();
        if (slot == -1)
            return;
        if (mc.player.getCooledAttackStrength(0.0f) < charge.getValue())
            return;
        int cur = mc.player.inventory.currentItem;
        if (slot != cur) {
            if (prevSlot == -1)
                prevSlot = cur;
            mc.player.inventory.currentItem = slot;
            activeSlot = slot;
        }
        InteractionUtils.attackAndSwing(target);
        restoreTimer = restore.getValue().intValue();
        attackCooldown = 4;
    }
}
