package client.module.impl.mace;

import client.module.BooleanSetting;
import client.module.Category;
import client.module.HandlerType;
import client.module.Module;
import client.module.NumberSetting;
import client.utils.render.ClientFontRenderer;
import client.utils.render.CrystalTheme;
import client.utils.world.SpearUtils;
import net.minecraft.entity.player.EntityPlayer;

public class SpearAssist extends Module {

    private final NumberSetting minRange = new NumberSetting("MinRange", 2.0, 0.5, 6.0);
    private final NumberSetting maxRange = new NumberSetting("MaxRange", 4.5, 2.0, 8.0);
    private final NumberSetting scanRange = new NumberSetting("ScanRange", 8.0, 3.0, 16.0);
    private final BooleanSetting autoSwap = new BooleanSetting("AutoSwap", false);
    private final NumberSetting swapBackDelay = new NumberSetting("SwapBackDelay", 10.0, 2.0, 60.0);
    private final BooleanSetting showHud = new BooleanSetting("ShowHud", true);

    private int prevSlot = -1;
    private int swapBackTimer = 0;
    private int activeSpearSlot = -1;
    private double lastDist = -1.0;
    private String lastName = "";

    public SpearAssist() {
        super("SpearAssist", Category.MACE);
        setDescription("Spear spacing: range window readout under the crosshair, optional auto swap to your spear");
        addSetting(minRange);
        addSetting(maxRange);
        addSetting(scanRange);
        addSetting(autoSwap);
        addSetting(swapBackDelay);
        addSetting(showHud);
        handles(HandlerType.UPDATE, HandlerType.GUI_RENDER);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        prevSlot = -1;
        swapBackTimer = 0;
        lastDist = -1.0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        restore();
        lastDist = -1.0;
    }

    private void restore() {
        if (mc.player != null && prevSlot >= 0 && prevSlot < 9
                && (activeSpearSlot < 0 || mc.player.inventory.currentItem == activeSpearSlot))
            mc.player.inventory.currentItem = prevSlot;
        prevSlot = -1;
        activeSpearSlot = -1;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        EntityPlayer t = SpearUtils.nearestPlayer(scanRange.getValue());
        if (t == null) {
            lastDist = -1.0;
        } else {
            lastDist = SpearUtils.distanceTo(t);
            lastName = t.getName();
            boolean inWindow = lastDist >= minRange.getValue() && lastDist <= maxRange.getValue();
            if (autoSwap.getValue() && inWindow) {
                int spear = SpearUtils.findSpearSlot();
                int cur = mc.player.inventory.currentItem;
                if (spear != -1 && spear != cur) {
                    if (prevSlot == -1)
                        prevSlot = cur;
                    mc.player.inventory.currentItem = spear;
                    activeSpearSlot = spear;
                }
                swapBackTimer = swapBackDelay.getValue().intValue();
            }
        }
        if (prevSlot != -1) {
            if (swapBackTimer > 0)
                swapBackTimer--;
            else
                restore();
        }
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck() || !showHud.getValue() || mc.scaledResolution == null || lastDist < 0.0)
            return;
        String state;
        int color;
        if (lastDist < minRange.getValue()) {
            state = "TOO CLOSE";
            color = CrystalTheme.WARN;
        } else if (lastDist > maxRange.getValue()) {
            state = "TOO FAR";
            color = CrystalTheme.BAD;
        } else {
            state = "IN RANGE";
            color = CrystalTheme.GOOD;
        }
        float x = mc.scaledResolution.getScaledWidth() / 2.0f;
        float y = mc.scaledResolution.getScaledHeight() / 2.0f + 16.0f;
        ClientFontRenderer.drawCenteredStringWithShadow(lastName + "  " + (Math.round(lastDist * 10.0) / 10.0) + "m  " + state, x, y, color);
    }
}
