package client.module.impl.mace;

import client.module.BooleanSetting;
import client.module.Category;
import client.module.HandlerType;
import client.module.Module;
import client.module.NumberSetting;
import client.utils.player.FallPrediction;
import client.utils.world.MaceUtils;
import client.utils.world.WindFire;

public class ElytraDiveAssist extends Module {

    private final NumberSetting triggerHeight = new NumberSetting("TriggerHeight", 14.0, 4.0, 40.0);
    private final NumberSetting minSpeed = new NumberSetting("MinSpeed", 1.0, 0.3, 3.0);
    private final NumberSetting minDivePitch = new NumberSetting("MinDivePitch", 40.0, 10.0, 90.0);
    private final BooleanSetting swapToMace = new BooleanSetting("SwapToMace", true);
    private final NumberSetting cooldown = new NumberSetting("Cooldown", 40.0, 10.0, 120.0);
    private final NumberSetting triggerTicks = new NumberSetting("TriggerTicks", 5.0, 1.0, 10.0);

    private int cd = 0;

    public ElytraDiveAssist() {
        super("ElytraDiveAssist", Category.MACE);
        setDescription("While diving on elytra, fires a wind charge before impact and readies your mace");
        addSetting(triggerHeight);
        addSetting(minSpeed);
        addSetting(minDivePitch);
        addSetting(swapToMace);
        addSetting(cooldown);
        triggerTicks.setStep(1.0);
        addSetting(triggerTicks);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        cd = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        WindFire.abort(this);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        WindFire.tick(this);
        if (cd > 0)
            cd--;
        if (cd > 0 || WindFire.isBusy() || !mc.player.isElytraFlying())
            return;
        if (mc.player.rotationPitch < minDivePitch.getValue())
            return;
        double speed = Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionY * mc.player.motionY + mc.player.motionZ * mc.player.motionZ);
        if (speed < minSpeed.getValue())
            return;
        double groundDistance = FallPrediction.getGroundDistance();
        double impactTicks = FallPrediction.getTicksToImpact(groundDistance, mc.player.motionY);
        if (mc.player.motionY >= -0.15 || groundDistance > triggerHeight.getValue() || impactTicks > triggerTicks.getValue())
            return;
        int maceSlot = swapToMace.getValue() ? MaceUtils.findMaceSlot() : -1;
        if (WindFire.begin(false, maceSlot, this))
            cd = cooldown.getValue().intValue();
    }
}
