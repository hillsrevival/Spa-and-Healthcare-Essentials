package client.module.impl.mace;

import client.module.BooleanSetting;
import client.module.Category;
import client.module.HandlerType;
import client.module.Module;
import client.module.NumberSetting;
import client.event.events.PacketOutputEvent;
import client.utils.world.MaceUtils;
import client.utils.world.PacketUtils;
import client.utils.combat.CombatUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.CPacketUseEntity;

/**
 * GroundMacing: right before an attack packet goes out with a mace in hand, sends up/down position
 * packets so the server counts a fall, letting you smash from flat ground.
 */
public class MaceKill extends Module {

    private final NumberSetting fakeHeight = new NumberSetting("FakeHeight", 8.0, 2.0, 9.0);
    private final NumberSetting pairs = new NumberSetting("Pairs", 1.0, 1.0, 5.0);
    private final BooleanSetting onlyMace = new BooleanSetting("OnlyMace", true);
    private final BooleanSetting checkCeiling = new BooleanSetting("CheckCeiling", true);

    private boolean sending = false;
    private int lastSequenceTick = -1;

    public MaceKill() {
        super("MaceKill", Category.MACE);
        setDescription("Ground macing: fakes a fall on flat ground so every mace hit is a full smash attack");
        pairs.setStep(1.0);
        addSetting(fakeHeight);
        addSetting(pairs);
        addSetting(onlyMace);
        addSetting(checkCeiling);
        handles(HandlerType.PACKET_OUTPUT);
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        if (sending || !nullCheck())
            return;
        if (!(event.getPacket() instanceof CPacketUseEntity))
            return;
        CPacketUseEntity attack = (CPacketUseEntity) event.getPacket();
        if (attack.getAction() != CPacketUseEntity.Action.ATTACK)
            return;
        Entity target = attack.getEntityFromWorld(mc.world);
        if (!(target instanceof EntityLivingBase) || target == mc.player || target.isDead)
            return;
        if (CombatUtils.getReachDistance(target) > MaceUtils.MAX_GRIM_REACH)
            return;
        if (lastSequenceTick == mc.player.ticksExisted)
            return;
        if (onlyMace.getValue() && !MaceUtils.isMaceSlot(mc.player.inventory.currentItem))
            return;
        if (mc.player.fallDistance > 1.6f || mc.player.isElytraFlying())
            return;
        double h = fakeHeight.getValue();
        if (checkCeiling.getValue() && !clearAbove(h))
            return;
        sending = true;
        lastSequenceTick = mc.player.ticksExisted;
        try {
            double x = mc.player.posX;
            double y = mc.player.posY;
            double z = mc.player.posZ;
            int n = pairs.getValue().intValue();
            for (int i = 0; i < n; i++) {
                PacketUtils.sendPosition(x, y + h, z, false);
                PacketUtils.sendPosition(x, y, z, false);
            }
        } finally {
            sending = false;
        }
    }

    private boolean clearAbove(double h) {
        net.minecraft.util.math.AxisAlignedBB raised = mc.player.getEntityBoundingBox().offset(0.0, h, 0.0);
        return mc.world.getCollisionBoxes(mc.player, raised).isEmpty();
    }
}
