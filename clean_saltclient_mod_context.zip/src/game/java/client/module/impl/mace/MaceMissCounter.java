package client.module.impl.mace;

import client.event.events.PacketOutputEvent;
import client.event.events.WorldChangeEvent;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.HandlerType;
import client.module.Module;
import client.module.NumberSetting;
import client.utils.combat.CombatUtils;
import client.utils.render.ClientFontRenderer;
import client.utils.render.CrystalTheme;
import client.utils.world.MaceUtils;
import net.minecraft.client.gui.Gui;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;

/** Tracks high mace falls that ended without a mace swing, and swings outside the configured reach. */
public class MaceMissCounter extends Module {

    private final NumberSetting minFall = new NumberSetting("MinFall", 8.0, 3.0, 40.0);
    private final NumberSetting opportunityRange = new NumberSetting("OpportunityRange", 6.0, 3.0, 12.0);
    private final NumberSetting maxReach = new NumberSetting("MaxReach", 3.03, 2.0, 3.03);
    private final BooleanSetting showHud = new BooleanSetting("ShowHud", true);
    private final NumberSetting posX = new NumberSetting("PosX", 6.0, 0.0, 1000.0);
    private final NumberSetting posY = new NumberSetting("PosY", 145.0, 0.0, 1000.0);

    private boolean fallActive;
    private boolean sawTarget;
    private boolean attempted;
    private boolean outOfRangeCounted;
    private double maxFall;
    private int noSwingCount;
    private int outOfRangeCount;
    private String lastResult = "No tracked fall";
    private int resultTicks;

    public MaceMissCounter() {
        super("MaceMissCounter", Category.MACE);
        setDescription("Counts high falls with no mace swing and mace attacks outside effective reach");
        addSetting(minFall);
        addSetting(opportunityRange);
        addSetting(maxReach);
        addSetting(showHud);
        addSetting(posX);
        addSetting(posY);
        handles(HandlerType.UPDATE, HandlerType.PACKET_OUTPUT, HandlerType.GUI_RENDER, HandlerType.WORLD_CHANGE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        resetSession();
    }

    @Override
    public void onWorldChange(WorldChangeEvent event) {
        resetFall();
        lastResult = "World changed";
        resultTicks = 60;
    }

    private void resetSession() {
        noSwingCount = 0;
        outOfRangeCount = 0;
        lastResult = "Tracking falls";
        resultTicks = 0;
        resetFall();
    }

    private void resetFall() {
        fallActive = false;
        sawTarget = false;
        attempted = false;
        outOfRangeCounted = false;
        maxFall = 0.0;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (resultTicks > 0)
            resultTicks--;
        boolean falling = !mc.player.onGround && !mc.player.isElytraFlying()
                && !mc.player.isInWater() && mc.player.motionY < -0.12;
        if (falling) {
            fallActive = true;
            maxFall = Math.max(maxFall, mc.player.fallDistance);
            if (maxFall >= minFall.getValue()) {
                for (EntityPlayer target : mc.world.playerEntities) {
                    if (target == null || target == mc.player || target.isDead || !target.isEntityAlive())
                        continue;
                    if (mc.player.getDistanceToEntity(target) <= opportunityRange.getValue()) {
                        sawTarget = true;
                        break;
                    }
                }
            }
            return;
        }
        if (fallActive)
            finishFall();
    }

    private void finishFall() {
        if (maxFall >= minFall.getValue() && sawTarget && !attempted) {
            noSwingCount++;
            lastResult = "No mace swing during " + format(maxFall) + "m fall";
            resultTicks = 100;
        } else if (maxFall >= minFall.getValue() && attempted && !outOfRangeCounted) {
            lastResult = "Mace swing attempted in range";
            resultTicks = 70;
        }
        resetFall();
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        if (!nullCheck() || event == null || !(event.getPacket() instanceof CPacketUseEntity))
            return;
        if (!MaceUtils.isMaceSlot(mc.player.inventory.currentItem))
            return;
        CPacketUseEntity packet = (CPacketUseEntity) event.getPacket();
        if (packet.getAction() != CPacketUseEntity.Action.ATTACK)
            return;
        Entity target = packet.getEntityFromWorld(mc.world);
        if (!(target instanceof EntityPlayer) || target == mc.player || target.isDead)
            return;

        if (!fallActive && !mc.player.onGround && !mc.player.isElytraFlying() && mc.player.motionY < -0.12) {
            fallActive = true;
            maxFall = Math.max(maxFall, mc.player.fallDistance);
        }
        if (!fallActive || maxFall < minFall.getValue())
            return;

        attempted = true;
        double distance = CombatUtils.getReachDistance(target);
        if (distance > maxReach.getValue() + 0.001 && !outOfRangeCounted) {
            outOfRangeCounted = true;
            outOfRangeCount++;
            lastResult = "Out of reach: " + format(distance) + "m / " + format(maxReach.getValue()) + "m";
            resultTicks = 100;
        } else if (distance <= maxReach.getValue() + 0.001) {
            lastResult = "In-range swing: " + format(distance) + "m";
            resultTicks = 70;
        }
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck() || !showHud.getValue() || mc.scaledResolution == null)
            return;
        String l1 = "MACE FALL WATCH";
        String l2 = "No swing: " + noSwingCount;
        String l3 = "Out of reach: " + outOfRangeCount;
        String l4 = resultTicks > 0 ? lastResult : (fallActive ? "Fall " + format(maxFall) + "m" : "Waiting for high fall");
        int w = Math.max(Math.max(ClientFontRenderer.getStringWidth(l1), ClientFontRenderer.getStringWidth(l2)),
                Math.max(ClientFontRenderer.getStringWidth(l3), ClientFontRenderer.getStringWidth(l4))) + 12;
        int x = posX.getValue().intValue();
        int y = posY.getValue().intValue();
        int h = 4 * 11 + 8;
        Gui.drawRect(x, y, x + w, y + h, CrystalTheme.BG_PANEL);
        Gui.drawRect(x, y, x + 2, y + h, outOfRangeCount > 0 || noSwingCount > 0 ? CrystalTheme.WARN : CrystalTheme.ACCENT);
        ClientFontRenderer.drawStringWithShadow(l1, x + 7, y + 4, CrystalTheme.ACCENT_BRIGHT);
        ClientFontRenderer.drawStringWithShadow(l2, x + 7, y + 15, CrystalTheme.TEXT);
        ClientFontRenderer.drawStringWithShadow(l3, x + 7, y + 26, CrystalTheme.TEXT);
        ClientFontRenderer.drawStringWithShadow(l4, x + 7, y + 37, CrystalTheme.TEXT_DIM);
    }

    private static String format(double value) {
        return String.valueOf(Math.round(value * 10.0) / 10.0);
    }
}
