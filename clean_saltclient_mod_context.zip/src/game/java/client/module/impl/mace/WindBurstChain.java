package client.module.impl.mace;

import client.module.BooleanSetting;
import client.module.Category;
import client.module.HandlerType;
import client.module.Module;
import client.module.NumberSetting;
import client.utils.player.FallPrediction;
import client.utils.render.ClientFontRenderer;
import client.utils.render.CrystalTheme;
import client.utils.world.MaceUtils;
import client.utils.world.WindFire;
import net.minecraft.client.gui.Gui;

public class WindBurstChain extends Module {

    private final BooleanSetting autoBounce = new BooleanSetting("AutoBounce", false);
    private final NumberSetting fireHeight = new NumberSetting("FireHeight", 5.0, 2.0, 14.0);
    private final NumberSetting minFall = new NumberSetting("MinFall", 8.0, 3.0, 40.0);
    private final BooleanSetting swapToMace = new BooleanSetting("SwapToMace", true);
    private final NumberSetting cooldown = new NumberSetting("Cooldown", 20.0, 5.0, 60.0);
    private final NumberSetting triggerTicks = new NumberSetting("TriggerTicks", 4.0, 1.0, 8.0);
    private final BooleanSetting showHud = new BooleanSetting("ShowHud", true);
    private final NumberSetting posX = new NumberSetting("PosX", 6, 0, 1000);
    private final NumberSetting posY = new NumberSetting("PosY", 105, 0, 1000);

    private int cd = 0;
    private int chain = 0;
    private int idleTicks = 0;
    private double groundDist = 999.0;
    private double ticksToImpact = 999.0;

    public WindBurstChain() {
        super("WindBurstChain", Category.MACE);
        setDescription("Bounce timing overlay for chaining mace hits with wind charges, with optional auto bounce");
        addSetting(autoBounce);
        addSetting(fireHeight);
        addSetting(minFall);
        addSetting(swapToMace);
        addSetting(cooldown);
        triggerTicks.setStep(1.0);
        addSetting(triggerTicks);
        addSetting(showHud);
        addSetting(posX);
        addSetting(posY);
        handles(HandlerType.UPDATE, HandlerType.GUI_RENDER);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        cd = 0;
        chain = 0;
        idleTicks = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        WindFire.abort(this);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        WindFire.tick(this);
        if (cd > 0)
            cd--;
        if (++idleTicks > 100)
            chain = 0;
        boolean falling = !mc.player.onGround && !mc.player.isElytraFlying() && mc.player.motionY < -0.2;
        if (falling) {
            groundDist = FallPrediction.getGroundDistance();
            ticksToImpact = FallPrediction.getTicksToImpact(groundDist, mc.player.motionY);
        } else {
            groundDist = 999.0;
            ticksToImpact = 999.0;
        }
        if (!autoBounce.getValue() || WindFire.isBusy() || cd > 0 || !falling)
            return;
        if (mc.player.motionY > -0.4 || mc.player.fallDistance < minFall.getValue())
            return;
        if (groundDist <= fireHeight.getValue() && ticksToImpact <= triggerTicks.getValue()) {
            int maceSlot = swapToMace.getValue() ? MaceUtils.findMaceSlot() : -1;
            if (WindFire.begin(false, maceSlot, this)) {
                cd = cooldown.getValue().intValue();
                chain++;
                idleTicks = 0;
            }
        }
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck() || !showHud.getValue() || mc.scaledResolution == null)
            return;
        boolean ready = groundDist <= fireHeight.getValue() && groundDist < 900.0;
        String l1 = "Chain x" + chain + (autoBounce.getValue() ? "  AUTO" : "");
        String l2 = groundDist < 900.0 ? ("Ground " + (Math.round(groundDist * 10.0) / 10.0) + "m  T-" + (Math.round(ticksToImpact * 10.0) / 10.0)) : "Ground --";
        String l3 = ready ? "FIRE" : "Wait";
        int color = ready ? CrystalTheme.GOOD : CrystalTheme.ACCENT;
        int x = posX.getValue().intValue();
        int y = posY.getValue().intValue();
        int w = Math.max(ClientFontRenderer.getStringWidth(l1), Math.max(ClientFontRenderer.getStringWidth(l2), ClientFontRenderer.getStringWidth(l3))) + 10;
        int h = 3 * 11 + 6;
        Gui.drawRect(x, y, x + w, y + h, CrystalTheme.BG_PANEL);
        Gui.drawRect(x, y, x + 2, y + h, color);
        ClientFontRenderer.drawStringWithShadow(l1, x + 6, y + 4, CrystalTheme.TEXT);
        ClientFontRenderer.drawStringWithShadow(l2, x + 6, y + 15, CrystalTheme.TEXT_DIM);
        ClientFontRenderer.drawStringWithShadow(l3, x + 6, y + 26, color);
    }
}
