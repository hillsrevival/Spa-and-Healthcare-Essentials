package client.module.impl.mace;

import client.module.Category;
import client.module.HandlerType;
import client.module.Module;
import client.module.NumberSetting;
import client.event.events.PacketInputEvent;
import client.utils.world.SpearUtils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketEntityVelocity;

/** Wind Glide / Lunge Swap: after a wind charge launches you, steers your motion toward the nearest player. */
public class WindLunge extends Module {

    private final NumberSetting strength = new NumberSetting("Strength", 0.12, 0.02, 0.5);
    private final NumberSetting duration = new NumberSetting("Ticks", 12.0, 2.0, 30.0);
    private final NumberSetting range = new NumberSetting("Range", 24.0, 6.0, 48.0);
    private final NumberSetting minLaunch = new NumberSetting("MinLaunch", 0.5, 0.2, 2.0);

    private int ticksLeft = 0;
    private int launchPacketCooldown = 0;

    public WindLunge() {
        super("WindLunge", Category.MACE);
        setDescription("After a wind charge launch, glides you horizontally toward the nearest target");
        duration.setStep(1.0);
        addSetting(strength);
        addSetting(duration);
        addSetting(range);
        addSetting(minLaunch);
        handles(HandlerType.PACKET_INPUT, HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        ticksLeft = 0;
        launchPacketCooldown = 0;
    }

    @Override
    public void onPacketInput(PacketInputEvent event) {
        if (!nullCheck() || !(event.getPacket() instanceof SPacketEntityVelocity))
            return;
        SPacketEntityVelocity v = (SPacketEntityVelocity) event.getPacket();
        if (v.getEntityID() != mc.player.getEntityId() || launchPacketCooldown > 0)
            return;
        double my = v.getMotionY() / 8000.0;
        double horizontal = Math.sqrt(v.getMotionX() * (double) v.getMotionX() + v.getMotionZ() * (double) v.getMotionZ()) / 8000.0;
        if (my >= minLaunch.getValue() && my <= 2.8 && horizontal <= 1.8) {
            ticksLeft = duration.getValue().intValue();
            launchPacketCooldown = 8;
        }
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (launchPacketCooldown > 0)
            launchPacketCooldown--;
        if (ticksLeft <= 0)
            return;
        ticksLeft--;
        if (mc.player.onGround && ticksLeft < duration.getValue() - 3) {
            ticksLeft = 0;
            return;
        }
        EntityPlayer t = SpearUtils.nearestPlayer(range.getValue());
        if (t == null)
            return;
        double dx = t.posX - mc.player.posX;
        double dz = t.posZ - mc.player.posZ;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.8)
            return;
        double s = strength.getValue();
        mc.player.motionX = Math.max(-1.8, Math.min(1.8, mc.player.motionX + dx / len * s));
        mc.player.motionZ = Math.max(-1.8, Math.min(1.8, mc.player.motionZ + dz / len * s));
    }
}
