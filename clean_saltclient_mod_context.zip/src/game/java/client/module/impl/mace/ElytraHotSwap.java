package client.module.impl.mace;

import client.module.Category;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.Module;
import client.module.NumberSetting;
import client.module.impl.items.ChestSwap;
import client.utils.player.FallPrediction;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

/** Auto elytra to chestplate hot-swapper built on ChestSwap: elytra while airborne, chestplate before impact. */
public class ElytraHotSwap extends Module {

    private final ModeSetting trigger = new ModeSetting("Trigger", "Launch", "Launch", "Fall");
    private final NumberSetting startFall = new NumberSetting("StartFall", 4.0, 1.0, 30.0);
    private final NumberSetting swapBackHeight = new NumberSetting("SwapBackHeight", 4.0, 1.5, 15.0);
    private final NumberSetting cooldown = new NumberSetting("Cooldown", 12.0, 5.0, 40.0);

    private int cd = 0;

    public ElytraHotSwap() {
        super("ElytraHotSwap", Category.MACE);
        setDescription("Equips elytra for height or a dive bomb, swaps your chestplate back just before landing");
        cooldown.setStep(1.0);
        addSetting(trigger);
        addSetting(startFall);
        addSetting(swapBackHeight);
        addSetting(cooldown);
        handles(HandlerType.UPDATE);
    }

    private boolean has(boolean elytra) {
        for (int i = 9; i < 45; i++) {
            ItemStack s = mc.player.inventoryContainer.getSlot(i).getStack();
            if (s == null || s.func_190926_b())
                continue;
            if (elytra && s.getItem() == Items.ELYTRA)
                return true;
            if (!elytra && s.getItem() instanceof ItemArmor && ((ItemArmor) s.getItem()).armorType == EntityEquipmentSlot.CHEST)
                return true;
        }
        return false;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.player.openContainer != mc.player.inventoryContainer || mc.currentScreen != null)
            return;
        if (cd > 0) {
            cd--;
            return;
        }
        ItemStack chest = mc.player.getItemStackFromSlot(EntityEquipmentSlot.CHEST);
        boolean elytraOn = chest != null && !chest.func_190926_b() && chest.getItem() == Items.ELYTRA;
        if (!elytraOn) {
            boolean airborne = !mc.player.onGround && !mc.player.isInWater();
            boolean go = trigger.getValue().equals("Launch") ? (airborne && mc.player.motionY > 0.5) : (airborne && mc.player.fallDistance >= startFall.getValue());
            if (go && has(true)) {
                if (ChestSwap.swapNow())
                    cd = cooldown.getValue().intValue();
            }
        } else {
            boolean low = mc.player.onGround || FallPrediction.getGroundDistance() <= swapBackHeight.getValue();
            if (low && mc.player.motionY <= 0.0 && has(false)) {
                if (ChestSwap.swapNow())
                    cd = cooldown.getValue().intValue();
            }
        }
    }
}
