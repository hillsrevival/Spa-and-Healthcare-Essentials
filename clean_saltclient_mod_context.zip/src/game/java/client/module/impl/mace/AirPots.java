package client.module.impl.mace;

import client.module.Category;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.Module;
import client.module.NumberSetting;
import client.utils.world.InteractionUtils;
import client.utils.world.PacketUtils;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemLingeringPotion;
import net.minecraft.item.ItemSplashPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionUtils;
import net.minecraft.util.EnumHand;

/** Anti-float: splashes a potion straight down while you're airborne so you don't waste time in the air. */
public class AirPots extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Heal", "Heal", "AnyBuff");
    private final NumberSetting healthBelow = new NumberSetting("HealthBelow", 14.0, 2.0, 20.0);
    private final NumberSetting minAirTicks = new NumberSetting("MinAirTicks", 3.0, 1.0, 20.0);
    private final NumberSetting cooldown = new NumberSetting("Cooldown", 20.0, 5.0, 60.0);

    private int air = 0;
    private int cd = 0;

    public AirPots() {
        super("AirPots", Category.MACE);
        setDescription("Splashes a potion straight down mid-air (heal when low, or any buff)");
        minAirTicks.setStep(1.0);
        cooldown.setStep(1.0);
        addSetting(mode);
        addSetting(healthBelow);
        addSetting(minAirTicks);
        addSetting(cooldown);
        handles(HandlerType.UPDATE);
    }

    private boolean fits(ItemStack s) {
        if (s == null || s.func_190926_b())
            return false;
        if (!(s.getItem() instanceof ItemSplashPotion) && !(s.getItem() instanceof ItemLingeringPotion))
            return false;
        boolean heal = false;
        boolean bad = false;
        java.util.List<PotionEffect> effects = PotionUtils.getEffectsFromStack(s);
        if (effects == null || effects.isEmpty())
            return false;
        for (PotionEffect e : effects) {
            if (e.getPotion() == MobEffects.INSTANT_HEALTH)
                heal = true;
            if (e.getPotion().isBadEffect())
                bad = true;
        }
        if (bad)
            return false;
        return mode.getValue().equals("Heal") ? heal : true;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.currentScreen != null || mc.player.openContainer != mc.player.inventoryContainer) {
            air = 0;
            return;
        }
        air = mc.player.onGround ? 0 : air + 1;
        if (cd > 0)
            cd--;
        if (cd > 0 || air < minAirTicks.getValue())
            return;
        if (mode.getValue().equals("Heal") && mc.player.getHealth() + mc.player.getAbsorptionAmount() > healthBelow.getValue())
            return;
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            if (fits(mc.player.inventory.getStackInSlot(i))) {
                slot = i;
                break;
            }
        }
        if (slot == -1)
            return;
        int prev = mc.player.inventory.currentItem;
        PacketUtils.sendRotation(mc.player.rotationYaw, 90.0f, mc.player.onGround);
        try {
            mc.player.inventory.currentItem = slot;
            InteractionUtils.useItem(EnumHand.MAIN_HAND);
            mc.player.swingArm(EnumHand.MAIN_HAND);
        } finally {
            mc.player.inventory.currentItem = prev;
        }
        cd = cooldown.getValue().intValue();
    }
}
