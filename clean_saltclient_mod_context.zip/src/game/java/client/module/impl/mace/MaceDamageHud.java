package client.module.impl.mace;

import client.module.BooleanSetting;
import client.module.Category;
import client.module.HandlerType;
import client.module.Module;
import client.module.NumberSetting;
import client.utils.render.ClientFontRenderer;
import client.utils.render.CrystalTheme;
import net.minecraft.client.gui.Gui;
import net.minecraft.entity.player.EntityPlayer;

public class MaceDamageHud extends Module {

    private final NumberSetting density = new NumberSetting("DensityLevel", 0, 0, 5);
    private final NumberSetting targetRange = new NumberSetting("TargetRange", 12.0, 3.0, 40.0);
    private final NumberSetting defaultHealth = new NumberSetting("DefaultHealth", 20.0, 1.0, 40.0);
    private final BooleanSetting hideOnGround = new BooleanSetting("HideOnGround", false);
    private final NumberSetting posX = new NumberSetting("PosX", 6, 0, 1000);
    private final NumberSetting posY = new NumberSetting("PosY", 60, 0, 1000);

    public MaceDamageHud() {
        super("MaceDamageHud", Category.MACE);
        setDescription("Shows fall height and raw mace damage. Green = lethal, red = not enough height");
        density.setStep(1.0);
        addSetting(density);
        addSetting(targetRange);
        addSetting(defaultHealth);
        addSetting(hideOnGround);
        addSetting(posX);
        addSetting(posY);
        handles(HandlerType.GUI_RENDER);
    }

    /** Raw (pre-armor) mace damage: 6 base + smash bonus + Density. */
    public static double maceDamage(double fall, int densityLevel) {
        if (fall <= 1.5)
            return 6.0;
        double bonus = 4.0 * Math.min(fall, 3.0);
        if (fall > 3.0)
            bonus += 2.0 * Math.min(fall - 3.0, 5.0);
        if (fall > 8.0)
            bonus += (fall - 8.0);
        bonus += 0.5 * densityLevel * fall;
        return 6.0 + bonus;
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck() || mc.scaledResolution == null)
            return;
        double fall = mc.player.fallDistance;
        if (hideOnGround.getValue() && mc.player.onGround)
            return;
        double dmg = maceDamage(fall, density.getValue().intValue());
        double targetHp = defaultHealth.getValue();
        String targetName = "dummy";
        EntityPlayer best = null;
        double bestDist = targetRange.getValue();
        for (EntityPlayer p : mc.world.playerEntities) {
            if (p == null || p == mc.player || p.isDead)
                continue;
            double dx = p.posX - mc.player.posX;
            double dy = p.posY - mc.player.posY;
            double dz = p.posZ - mc.player.posZ;
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (d <= bestDist) {
                bestDist = d;
                best = p;
            }
        }
        if (best != null) {
            targetHp = best.getHealth() + best.getAbsorptionAmount();
            targetName = best.getName();
        }
        int color;
        String state;
        if (dmg >= targetHp) {
            color = CrystalTheme.GOOD;
            state = "LETHAL";
        } else if (dmg >= targetHp * 0.6) {
            color = CrystalTheme.WARN;
            state = "HEAVY";
        } else {
            color = CrystalTheme.BAD;
            state = "LOW";
        }
        String l1 = "Fall " + (Math.round(fall * 10.0) / 10.0) + "m";
        String l2 = "Dmg " + (Math.round(dmg * 10.0) / 10.0) + "  " + state;
        String l3 = targetName + " " + (Math.round(targetHp * 10.0) / 10.0) + " hp";
        int x = posX.getValue().intValue();
        int y = posY.getValue().intValue();
        int w = Math.max(ClientFontRenderer.getStringWidth(l1), Math.max(ClientFontRenderer.getStringWidth(l2), ClientFontRenderer.getStringWidth(l3))) + 10;
        int h = 3 * 11 + 6;
        Gui.drawRect(x, y, x + w, y + h, CrystalTheme.BG_PANEL);
        Gui.drawRect(x, y, x + 2, y + h, color);
        ClientFontRenderer.drawStringWithShadow(l1, x + 6, y + 4, CrystalTheme.TEXT);
        ClientFontRenderer.drawStringWithShadow(l2, x + 6, y + 15, color);
        ClientFontRenderer.drawStringWithShadow(l3, x + 6, y + 26, CrystalTheme.TEXT_DIM);
    }
}
