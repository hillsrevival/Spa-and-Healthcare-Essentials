package client.module.impl.mace;

import client.module.Category;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.Module;
import client.module.NumberSetting;
import client.event.events.PacketOutputEvent;
import client.event.events.WorldChangeEvent;
import client.utils.world.MaceUtils;
import client.utils.world.PacketUtils;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.CPacketUseEntity;

/**
 * Smart Switch: when you hit with a sword/axe (or anything), the mace is swapped in at packet level
 * in the same tick so the hit uses the first weapon's cooldown but the mace's enchantments.
 */
public class AttributeSwapper extends Module {

    private final ModeSetting trigger = new ModeSetting("Trigger", "Sword/Axe", "Sword/Axe", "Sword", "Axe", "Anything");
    private final ModeSetting maceSlot = new ModeSetting("MaceSlot", "Default", "Default", "1", "2", "3", "4", "5", "6", "7", "8", "9");
    private final NumberSetting restoreDelay = new NumberSetting("RestoreDelay", 1.0, 1.0, 5.0);

    private boolean swapped = false;
    private int restoreSlot = -1;
    private int restoreTicks = 0;
    private int lastSwapTick = -1;

    public AttributeSwapper() {
        super("AttributeSwapper", Category.MACE);
        setDescription("Hit with a sword or axe, mace enchants and damage apply: swaps to the mace in the same tick");
        restoreDelay.setStep(1.0);
        addSetting(trigger);
        addSetting(maceSlot);
        addSetting(restoreDelay);
        handles(HandlerType.PACKET_OUTPUT, HandlerType.UPDATE, HandlerType.WORLD_CHANGE);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        restore();
    }

    @Override
    public void onWorldChange(WorldChangeEvent event) {
        restore();
        lastSwapTick = -1;
    }

    private int resolveMace() {
        String m = maceSlot.getValue();
        if (m.equals("Default"))
            return MaceUtils.findMaceSlot();
        try {
            int s = Integer.parseInt(m) - 1;
            return MaceUtils.isMaceSlot(s) ? s : -1;
        } catch (NumberFormatException ignored) {
            return -1;
        }
    }

    private boolean triggers(ItemStack held) {
        if (held == null || held.func_190926_b())
            return trigger.getValue().equals("Anything");
        String t = trigger.getValue();
        boolean sword = held.getItem() instanceof ItemSword;
        boolean axe = held.getItem() instanceof ItemAxe;
        if (t.equals("Sword"))
            return sword;
        if (t.equals("Axe"))
            return axe;
        if (t.equals("Anything"))
            return true;
        return sword || axe;
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        if (!nullCheck() || swapped || mc.player.ticksExisted == lastSwapTick)
            return;
        if (!(event.getPacket() instanceof CPacketUseEntity))
            return;
        if (((CPacketUseEntity) event.getPacket()).getAction() != CPacketUseEntity.Action.ATTACK)
            return;
        int cur = mc.player.inventory.currentItem;
        if (MaceUtils.isMaceSlot(cur))
            return;
        if (!triggers(mc.player.inventory.getStackInSlot(cur)))
            return;
        int mace = resolveMace();
        if (mace == -1)
            return;
        PacketUtils.sendHeldItemChange(mace);
        swapped = true;
        restoreSlot = cur;
        lastSwapTick = mc.player.ticksExisted;
        restoreTicks = restoreDelay.getValue().intValue();
    }

    @Override
    public void onUpdate() {
        if (!swapped)
            return;
        if (restoreTicks > 0) {
            restoreTicks--;
            return;
        }
        restore();
    }

    private void restore() {
        if (swapped && mc.player != null && restoreSlot >= 0 && restoreSlot < 9)
            PacketUtils.sendHeldItemChange(restoreSlot);
        swapped = false;
        restoreSlot = -1;
        restoreTicks = 0;
    }
}
