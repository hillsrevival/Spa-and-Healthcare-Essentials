package client.module.impl.retro;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;

public class FastBow extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting speed = new NumberSetting("Speed", 5.0, 1.0, 20.0);

    private final BooleanSetting randomize = new BooleanSetting("Randomize", false);

    public FastBow() {
        super("FastBow", Category.RETRO);
        setDescription("Shoots arrows at maximum speed without the delay");
        addSetting(speed);
        addSetting(randomize);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!mc.player.isHandActive())
            return;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held == null || held.getItem() != Items.BOW)
            return;
        int extra;
        if (randomize.getValue()) {
            extra = (int) (speed.getValue() - 1.0 + Math.random() * 0.5);
        } else {
            extra = speed.getValue().intValue() - 1;
        }
        if (extra > 0) {
            mc.player.activeItemStackUseCount -= extra;
        }
    }
}
