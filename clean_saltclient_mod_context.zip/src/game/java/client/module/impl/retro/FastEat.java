package client.module.impl.retro;

import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class FastEat extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting speed = new NumberSetting("Speed", 5.0, 1.0, 20.0);

    public FastEat() {
        super("FastEat", Category.RETRO);
        setDescription("Eats food faster");
        addSetting(speed);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!mc.player.isHandActive())
            return;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held == null)
            return;
        if (!(held.getItem() instanceof ItemFood))
            return;
        int extra = speed.getValue().intValue() - 1;
        if (extra > 0) {
            mc.player.activeItemStackUseCount -= extra;
        }
    }
}
