package client.module.impl.retro;

import net.minecraft.client.Minecraft;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.world.PacketUtils;

public class AntiFire extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting packets = new NumberSetting("Packets", 5.0, 1.0, 20.0);

    public AntiFire() {
        super("AntiFire", Category.RETRO);
        setDescription("Prevents fire damage");
        addSetting(packets);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.player.isBurning()) {
            int count = packets.getValue().intValue();
            for (int i = 0; i < count; i++) {
                PacketUtils.sendGround(mc.player.onGround);
            }
        }
    }
}
