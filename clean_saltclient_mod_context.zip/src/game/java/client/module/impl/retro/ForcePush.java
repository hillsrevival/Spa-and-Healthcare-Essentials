package client.module.impl.retro;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.EntityUtils;

public class ForcePush extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 5.0, 1.0, 10.0);

    private final NumberSetting strength = new NumberSetting("Strength", 1.0, 0.1, 5.0);

    private final NumberSetting vertical = new NumberSetting("Vertical", 0.4, 0.0, 2.0);

    public ForcePush() {
        super("ForcePush", Category.RETRO);
        setDescription("Pushes entities away from you");
        addSetting(range);
        addSetting(strength);
        addSetting(vertical);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        double rangeVal = range.getValue();
        double strengthVal = strength.getValue();
        double verticalVal = vertical.getValue();
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (entity == mc.player)
                continue;
            if (!(entity instanceof EntityLivingBase))
                continue;
            EntityLivingBase living = (EntityLivingBase) entity;
            if (living.isDead || living.getHealth() <= 0)
                continue;
            double dist = mc.player.getDistanceToEntity(living);
            if (dist > rangeVal || dist < 0.1)
                continue;
            double diffX = living.posX - mc.player.posX;
            double diffZ = living.posZ - mc.player.posZ;
            double distSq = diffX * diffX + diffZ * diffZ;
            if (distSq < 0.01)
                continue;
            double factor = strengthVal / dist;
            living.addVelocity(diffX / Math.sqrt(distSq) * factor, verticalVal, diffZ / Math.sqrt(distSq) * factor);
        }
    }
}
