package client.module.impl.retro;

import net.minecraft.client.Minecraft;
import net.minecraft.init.MobEffects;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;

public class AntiPotion extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting removeHunger = new BooleanSetting("Remove Hunger", true);

    private final BooleanSetting removeWeakness = new BooleanSetting("Remove Weakness", true);

    private final BooleanSetting removeLevitation = new BooleanSetting("Remove Levitation", true);

    public AntiPotion() {
        super("AntiPotion", Category.RETRO);
        setDescription("Removes negative potion effects from your screen");
        addSetting(removeHunger);
        addSetting(removeWeakness);
        addSetting(removeLevitation);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        mc.player.removePotionEffect(MobEffects.SLOWNESS);
        mc.player.removePotionEffect(MobEffects.POISON);
        mc.player.removePotionEffect(MobEffects.WITHER);
        mc.player.removePotionEffect(MobEffects.BLINDNESS);
        mc.player.removePotionEffect(MobEffects.NAUSEA);
        mc.player.removePotionEffect(MobEffects.MINING_FATIGUE);
        mc.player.removePotionEffect(MobEffects.UNLUCK);
        if (removeHunger.getValue()) {
            mc.player.removePotionEffect(MobEffects.HUNGER);
        }
        if (removeWeakness.getValue()) {
            mc.player.removePotionEffect(MobEffects.WEAKNESS);
        }
        if (removeLevitation.getValue()) {
            mc.player.removePotionEffect(MobEffects.LEVITATION);
        }
    }
}
