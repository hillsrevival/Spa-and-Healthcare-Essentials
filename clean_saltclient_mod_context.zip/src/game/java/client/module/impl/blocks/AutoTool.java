package client.module.impl.blocks;

import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Enchantments;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import client.utils.player.PendingSlotSwitch;
import client.utils.world.WorldUtils;

public class AutoTool extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting useSwords = new BooleanSetting("Use Swords", false);

    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 2.0, 0.0, 10.0);

    private int oldSlot = -1;

    private BlockPos pos;

    private int timer;

    private final PendingSlotSwitch switcher = new PendingSlotSwitch();

    private BlockPos pendingSwitchPos = null;

    public AutoTool() {
        super("AutoTool", Category.BLOCKS);
        setDescription("Switches to the best tool for the block you are mining");
        addSetting(useSwords);
        addSetting(switchDelay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (switcher.hasPending() && pendingSwitchPos != null) {
            if (switcher.tick()) {
                switcher.applySwitch();
                this.pos = pendingSwitchPos;
                timer = 4;
                pendingSwitchPos = null;
            }
            return;
        }
        if (mc.gameSettings.keyBindAttack.isKeyDown() && mc.objectMouseOver != null && mc.objectMouseOver.getBlockPos() != null) {
            findBestTool(mc.objectMouseOver.getBlockPos());
        }
        if (oldSlot == -1)
            return;
        if (timer <= 0) {
            mc.player.inventory.currentItem = oldSlot;
            oldSlot = -1;
            return;
        }
        if (!mc.gameSettings.keyBindAttack.isKeyDown() || mc.player.capabilities.isCreativeMode || WorldUtils.isAir(pos)) {
            timer--;
        }
    }

    private void findBestTool(BlockPos blockPos) {
        if (mc.player.capabilities.isCreativeMode)
            return;
        IBlockState state = WorldUtils.getState(blockPos);
        ItemStack heldItem = mc.player.getHeldItemMainhand();
        float bestSpeed = getDestroySpeed(heldItem, state);
        int bestSlot = -1;
        for (int slot = 0; slot < 9; slot++) {
            if (slot == mc.player.inventory.currentItem)
                continue;
            ItemStack stack = mc.player.inventory.getStackInSlot(slot);
            if (stack == null || stack.func_190926_b())
                continue;
            float speed = getDestroySpeed(stack, state);
            if (speed <= bestSpeed)
                continue;
            if (!useSwords.getValue() && stack.getItem() instanceof ItemSword)
                continue;
            bestSpeed = speed;
            bestSlot = slot;
        }
        if (bestSlot == -1)
            return;
        switcher.queue(bestSlot, switchDelay.getValue().intValue());
        pendingSwitchPos = blockPos;
    }

    private float getDestroySpeed(ItemStack stack, IBlockState state) {
        if (stack == null || stack.func_190926_b())
            return 1.0f;
        float speed = stack.getStrVsBlock(state);
        if (speed > 1.0f) {
            int efficiency = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, stack);
            if (efficiency > 0)
                speed += efficiency * efficiency + 1;
        }
        return speed;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (oldSlot != -1 && mc.player != null) {
            mc.player.inventory.currentItem = oldSlot;
            oldSlot = -1;
        }
        pendingSwitchPos = null;
        switcher.restore();
    }
}
