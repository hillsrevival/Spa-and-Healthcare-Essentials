package client.module.impl.blocks;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BedBreaker extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 5.0, 1.0, 10.0);

    private final NumberSetting delay = new NumberSetting("Delay", 5.0, 1.0, 20.0);

    private final BooleanSetting onlyOtherDim = new BooleanSetting("Only Other Dims", true);

    private int tickCounter = 0;

    private BlockPos currentTarget = null;

    private int breakProgress = 0;

    public BedBreaker() {
        super("BedBreaker", Category.BLOCKS);
        setDescription("Automatically finds and breaks nearby beds");
        addSetting(range);
        addSetting(delay);
        addSetting(onlyOtherDim);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (onlyOtherDim.getValue()) {
            int dimension = mc.player.dimension;
            if (dimension == 0)
                return;
        }
        tickCounter++;
        int delayTicks = delay.getValue().intValue();
        if (tickCounter < delayTicks)
            return;
        tickCounter = 0;
        if (currentTarget == null || !isBedAt(currentTarget)) {
            stopMiningIfOurs();
            currentTarget = findNearestBed();
            breakProgress = 0;
        }
        if (currentTarget == null)
            return;
        breakBed(currentTarget);
    }

    private BlockPos findNearestBed() {
        double range_ = range.getValue();
        int px = (int) Math.floor(mc.player.posX);
        int py = (int) Math.floor(mc.player.posY);
        int pz = (int) Math.floor(mc.player.posZ);
        int r = (int) Math.ceil(range_);
        BlockPos nearest = null;
        double nearestDist = range_ * range_;
        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    BlockPos pos = new BlockPos(px + x, py + y, pz + z);
                    if (!isBedAt(pos))
                        continue;
                    double dist = mc.player.getDistanceSq(pos);
                    if (dist < nearestDist) {
                        nearestDist = dist;
                        nearest = pos;
                    }
                }
            }
        }
        return nearest;
    }

    private boolean isBedAt(BlockPos pos) {
        if (mc.world == null || pos == null)
            return false;
        return mc.world.getBlockState(pos).getBlock() == Blocks.BED;
    }

    private void breakBed(BlockPos pos) {
        if (!nullCheck())
            return;
        double diffX = pos.x + 0.5 - mc.player.posX;
        double diffY = pos.y + 0.5 - (mc.player.posY + mc.player.getEyeHeight());
        double diffZ = pos.z + 0.5 - mc.player.posZ;
        double horizontalDist = Math.sqrt(diffX * diffX + diffZ * diffZ);
        mc.player.rotationYaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        mc.player.rotationPitch = (float) -Math.toDegrees(Math.atan2(diffY, horizontalDist));
        mc.playerController.onPlayerDamageBlock(pos, EnumFacing.UP);
        mc.player.swingArm(EnumHand.MAIN_HAND);
        breakProgress++;
        if (breakProgress > 40) {
            stopMiningIfOurs();
            currentTarget = null;
            breakProgress = 0;
        }
    }

    private void stopMiningIfOurs() {
        if (mc.playerController != null) {
            mc.playerController.resetBlockRemoving();
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        stopMiningIfOurs();
        currentTarget = null;
        breakProgress = 0;
    }
}
