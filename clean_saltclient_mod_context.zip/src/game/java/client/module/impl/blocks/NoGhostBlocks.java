package client.module.impl.blocks;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;

public class NoGhostBlocks extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public NoGhostBlocks() {
        super("NoGhostBlocks", Category.BLOCKS);
        setDescription("Removes ghost blocks from server block updates");
        handles(HandlerType.PACKET_OUTPUT);
    }

    @Override
    public void onPacketOutput(client.event.events.PacketOutputEvent event) {
        if (!nullCheck())
            return;
        Object packet = event.getPacket();
        if (!(packet instanceof CPacketPlayerDigging))
            return;
        CPacketPlayerDigging digPacket = (CPacketPlayerDigging) packet;
        CPacketPlayerDigging.Action action = digPacket.getAction();
        if (action == CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK) {
            BlockPos pos = digPacket.getPosition();
            if (pos != null) {
                mc.world.setBlockState(pos, Blocks.AIR.getDefaultState());
            }
        }
    }
}
