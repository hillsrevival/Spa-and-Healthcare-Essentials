package client.module.impl.blocks;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.lax1dude.eaglercraft.Mouse;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Queue;
import java.util.Set;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class VeinMiner extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 3.0, 1.0, 6.0);

    private BlockPos lastTarget = null;

    private Block lastBlockType = null;

    private boolean wasAirLastTick = false;

    private int cooldown = 0;

    public VeinMiner() {
        super("VeinMiner", Category.BLOCKS);
        setDescription("Whenever you mine a ore it mines all ores around it.");
        addSetting(range);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        RayTraceResult result = mc.objectMouseOver;
        if (result != null && result.typeOfHit == RayTraceResult.Type.BLOCK) {
            BlockPos pos = result.getBlockPos();
            Block block = WorldUtils.getBlock(pos);
            if (lastTarget != null && WorldUtils.isAir(lastTarget) && !wasAirLastTick) {
                if (lastBlockType != null && isValuable(lastBlockType)) {
                    BlockPos next = findNearestConnected(lastTarget, lastBlockType);
                    if (next != null) {
                        InteractionUtils.breakBlock(next, EnumFacing.UP);
                        cooldown = 3;
                    }
                }
            }
            wasAirLastTick = WorldUtils.isAir(pos);
            if (Mouse.isButtonDown(0) && isValuable(block) && !WorldUtils.isAir(pos)) {
                lastTarget = new BlockPos(pos);
                lastBlockType = block;
            } else if (!Mouse.isButtonDown(0)) {
                lastTarget = null;
                lastBlockType = null;
            }
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        lastTarget = null;
        lastBlockType = null;
        wasAirLastTick = false;
        cooldown = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        lastTarget = null;
        lastBlockType = null;
        wasAirLastTick = false;
        cooldown = 0;
    }

    private boolean isValuable(Block block) {
        return block == Blocks.COAL_ORE || block == Blocks.IRON_ORE || block == Blocks.GOLD_ORE || block == Blocks.DIAMOND_ORE || block == Blocks.EMERALD_ORE || block == Blocks.LAPIS_ORE || block == Blocks.REDSTONE_ORE || block == Blocks.QUARTZ_ORE;
    }

    private BlockPos findNearestConnected(BlockPos origin, Block blockType) {
        int rangeInt = range.getValue().intValue();
        BlockPos nearest = null;
        double closest = Double.MAX_VALUE;
        Set<BlockPos> visited = new HashSet<>();
        Queue<BlockPos> queue = new ArrayDeque<>();
        queue.add(origin);
        visited.add(origin);
        while (!queue.isEmpty()) {
            BlockPos current = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0)
                            continue;
                        BlockPos next = current.add(dx, dy, dz);
                        if (visited.contains(next))
                            continue;
                        if (Math.abs(next.getX() - origin.getX()) > rangeInt)
                            continue;
                        if (Math.abs(next.getY() - origin.getY()) > rangeInt)
                            continue;
                        if (Math.abs(next.getZ() - origin.getZ()) > rangeInt)
                            continue;
                        visited.add(next);
                        if (!WorldUtils.isAir(next) && WorldUtils.getBlock(next) == blockType) {
                            double dist = next.distanceSq(origin);
                            if (dist < closest && dist > 0) {
                                closest = dist;
                                nearest = next;
                            }
                            queue.add(next);
                        }
                    }
                }
            }
        }
        return nearest;
    }
}
