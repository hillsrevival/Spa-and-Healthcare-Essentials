package client.module.impl.blocks;

import java.util.ArrayList;
import java.util.List;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.utils.misc.ChatUtils;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class InstantBunker extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Mode", "Instant", "Instant", "Legit");

    private static final int[][] BUNKER_TEMPLATE = { { 1, 0, 1 }, { 1, 0, 0 }, { 1, 0, -1 }, { 1, 0, -2 }, { 0, 0, -2 }, { -1, 0, -2 }, { -1, 0, -1 }, { -1, 0, 0 }, { -1, 0, 1 }, { -1, 0, 2 }, { 0, 0, 2 }, { 1, 0, 2 }, { 0, 0, -1 }, { 0, 0, 0 }, { 0, 0, 1 }, { 1, 1, 1 }, { 1, 1, 0 }, { 1, 1, -1 }, { 1, 1, -2 }, { 0, 1, -2 }, { -1, 1, -2 }, { -1, 1, -1 }, { -1, 1, 0 }, { -1, 1, 1 }, { -1, 1, 2 }, { 0, 1, 2 }, { 1, 1, 2 }, { 0, 1, 1 }, { 0, 1, 0 }, { 0, 1, -1 }, { 1, 2, 1 }, { 1, 2, 0 }, { 1, 2, -1 }, { 1, 2, -2 }, { 0, 2, -2 }, { -1, 2, -2 }, { -1, 2, -1 }, { -1, 2, 0 }, { -1, 2, 1 }, { -1, 2, 2 }, { 0, 2, 2 }, { 1, 2, 2 }, { 0, 2, 1 }, { 0, 2, 0 }, { 0, 2, -1 }, { 1, 3, -2 }, { 0, 3, -2 }, { -1, 3, -2 }, { -1, 3, -1 }, { -1, 3, 0 }, { -1, 3, 1 }, { -1, 3, 2 }, { 0, 3, 2 }, { 1, 3, 2 }, { 1, 3, 1 } };

    private int placeIndex = 0;

    public InstantBunker() {
        super("InstantBunker", Category.BLOCKS);
        setDescription("Instantly builds a bunker around you");
        addSetting(mode);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (!nullCheck()) {
            toggle();
            return;
        }
        if (!mc.player.capabilities.isCreativeMode) {
            ChatUtils.error("InstantBunker requires Creative mode!");
            toggle();
            return;
        }
        int blockSlot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack != null && !stack.func_190926_b() && stack.getItem() instanceof ItemBlock) {
                blockSlot = i;
                break;
            }
        }
        if (blockSlot == -1) {
            ChatUtils.error("No blocks found in hotbar!");
            toggle();
            return;
        }
        int oldSlot = mc.player.inventory.currentItem;
        mc.player.inventory.currentItem = blockSlot;
        boolean isInstant = mode.getValue().equals("Instant");
        EnumFacing forward = mc.player.getHorizontalFacing();
        EnumFacing left = forward.rotateYCCW();
        BlockPos base = new BlockPos(mc.player);
        List<BlockPos> positions = new ArrayList<BlockPos>();
        for (int[] offset : BUNKER_TEMPLATE) {
            BlockPos pos = base.up(offset[1]).offset(forward, offset[2]).offset(left, offset[0]);
            positions.add(pos);
        }
        if (isInstant) {
            int placed = 0;
            for (BlockPos pos : positions) {
                if (WorldUtils.isAir(pos) || WorldUtils.getState(pos).getMaterial().isReplaceable()) {
                    placeBlock(pos);
                    placed++;
                }
            }
            ChatUtils.success("Bunker built! " + placed + " blocks placed.");
            mc.player.inventory.currentItem = oldSlot;
            toggle();
        } else {
            placeIndex = 0;
            ChatUtils.info("Building bunker in legit mode...");
        }
    }

    @Override
    public void onUpdate() {
        if (!mode.getValue().equals("Legit"))
            return;
        if (!nullCheck()) {
            toggle();
            return;
        }
        EnumFacing forward = mc.player.getHorizontalFacing();
        EnumFacing left = forward.rotateYCCW();
        BlockPos base = new BlockPos(mc.player);
        for (int i = 0; i < 4 && placeIndex < BUNKER_TEMPLATE.length; i++, placeIndex++) {
            int[] offset = BUNKER_TEMPLATE[placeIndex];
            BlockPos pos = base.up(offset[1]).offset(forward, offset[2]).offset(left, offset[0]);
            if (WorldUtils.isAir(pos) || WorldUtils.getState(pos).getMaterial().isReplaceable()) {
                placeBlock(pos);
            }
        }
        if (placeIndex >= BUNKER_TEMPLATE.length) {
            ChatUtils.success("Bunker built!");
            toggle();
        }
    }

    private void placeBlock(BlockPos pos) {
        for (EnumFacing facing : EnumFacing.values()) {
            BlockPos neighbor = pos.offset(facing);
            if (WorldUtils.getState(neighbor).getMaterial().isReplaceable())
                continue;
            Vec3d hitVec = new Vec3d(neighbor.getX() + 0.5, neighbor.getY() + 0.5, neighbor.getZ() + 0.5).add(new Vec3d(facing.getDirectionVec()).scale(-0.5));
            InteractionUtils.placeBlock(neighbor, facing.getOpposite(), hitVec, EnumHand.MAIN_HAND);
            mc.player.swingArm(EnumHand.MAIN_HAND);
            return;
        }
    }

    @Override
    public void onDisable() {
        placeIndex = 0;
        super.onDisable();
    }
}
