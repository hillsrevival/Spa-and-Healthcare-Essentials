package client.module.impl.blocks;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import client.utils.EntityUtils;

public class AutoBreed extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 4.0, 2.0, 6.0);

    public AutoBreed() {
        super("AutoBreed", Category.BLOCKS);
        setDescription("Automatically breeds nearby animals with food");
        addSetting(range);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held == null || held.func_190926_b())
            return;
        boolean isFood = held.getItem() instanceof net.minecraft.item.ItemFood;
        boolean isCarrot = held.getItem() == Items.CARROT;
        boolean isGoldenCarrot = held.getItem() == Items.GOLDEN_CARROT;
        boolean isWheat = held.getItem() == Items.WHEAT;
        boolean isSeeds = held.getItem() == Items.MELON_SEEDS || held.getItem() == Items.PUMPKIN_SEEDS || held.getItem() == Items.BEETROOT_SEEDS;
        if (!isFood && !isCarrot && !isGoldenCarrot && !isWheat && !isSeeds)
            return;
        double rangeD = range.getValue().doubleValue();
        for (Object obj : EntityUtils.getLoadedEntities()) {
            if (!(obj instanceof net.minecraft.entity.passive.EntityAnimal))
                continue;
            net.minecraft.entity.passive.EntityAnimal animal = (net.minecraft.entity.passive.EntityAnimal) obj;
            if (mc.player.getDistanceToEntity(animal) > rangeD)
                continue;
            if (!animal.isBreedingItem(held))
                continue;
            mc.playerController.interactWithEntity(mc.player, animal, net.minecraft.util.EnumHand.MAIN_HAND);
            break;
        }
    }
}
