package client.module.impl.blocks;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import client.utils.EntityUtils;

public class AutoShear extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 4.0, 2.0, 6.0);

    public AutoShear() {
        super("AutoShear", Category.BLOCKS);
        setDescription("Automatically shears nearby sheep");
        addSetting(range);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        int shearSlot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (stack != null && stack.getItem() == Items.SHEARS) {
                shearSlot = i;
                break;
            }
        }
        if (shearSlot == -1)
            return;
        int savedSlot = mc.player.inventory.currentItem;
        double rangeD = range.getValue();
        for (Object obj : EntityUtils.getLoadedEntities()) {
            if (!(obj instanceof net.minecraft.entity.passive.EntitySheep))
                continue;
            net.minecraft.entity.passive.EntitySheep sheep = (net.minecraft.entity.passive.EntitySheep) obj;
            if (mc.player.getDistanceToEntity(sheep) > rangeD)
                continue;
            if (sheep.getSheared())
                continue;
            mc.player.inventory.currentItem = shearSlot;
            mc.playerController.interactWithEntity(mc.player, sheep, EnumHand.MAIN_HAND);
            break;
        }
        mc.player.inventory.currentItem = savedSlot;
    }
}
