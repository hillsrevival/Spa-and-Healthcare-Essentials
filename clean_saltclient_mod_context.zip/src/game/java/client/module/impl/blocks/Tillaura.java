package client.module.impl.blocks;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import client.utils.world.WorldUtils;
import client.utils.player.InventoryManager;
import client.utils.player.InvUtils;
import client.utils.player.FindItemResult;

public class Tillaura extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 4.0, 1.0, 6.0);

    public Tillaura() {
        super("Tillaura", Category.BLOCKS);
        setDescription("Hoe’s soil around you for farming");
        addSetting(range);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        FindItemResult hoe = InvUtils.findInHotbar(item -> {
            ItemStack s = item;
            return s != null && !s.func_190926_b() && (s.getItem() instanceof net.minecraft.item.ItemHoe);
        });
        if (!hoe.found())
            return;
        BlockPos playerPos = new BlockPos(mc.player);
        int r = range.getValue().intValue();
        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                for (int y = -1; y <= 1; y++) {
                    BlockPos pos = playerPos.add(x, y, z);
                    if (WorldUtils.getBlock(pos) == Blocks.DIRT) {
                        if (hoe.slot() != InventoryManager.getCurrentSlot()) {
                            InventoryManager.switchToSlot(hoe.slot());
                        }
                        client.utils.world.InteractionUtils.placeBlock(pos, EnumFacing.UP);
                        return;
                    }
                }
            }
        }
    }
}
