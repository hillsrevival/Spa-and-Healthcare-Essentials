package client.module.impl.blocks;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import client.module.BlockListSetting;
import client.module.Category;
import client.module.Condition;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.Module;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.combat.SilentAimUtil;
import client.utils.world.BlockPlacementUtil;
import client.utils.world.BlockUtils;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFalling;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import client.utils.render.ClientFontRenderer;

public class Scaffold extends Module {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Mode", "GodBridge", "Legit", "GodBridge", "TellyBridge");

    private final NumberSetting delay = new NumberSetting("Delay", 0.0, 0.0, 10.0);

    private final BooleanSetting autoBlock = new BooleanSetting("AutoBlock", true);

    private final NumberSetting expand = new NumberSetting("Expand", 0.3, 0.0, 0.5);

    private final ModeSetting tower = new ModeSetting("Tower", "Off", "Off", "Jump", "Motion", "Step", "Smooth");

    private final ModeSetting blockFilter = new ModeSetting("Blocks", "All", "All", "Blacklist", "Whitelist");

    private final BlockListSetting filterBlocks = new BlockListSetting("Filter Blocks", new String[0]);

    private final BooleanSetting pitchCheck = new BooleanSetting("Pitch Check", false);

    private final NumberSetting pitchAngle = new NumberSetting("Pitch Angle", 60.0, 0.0, 90.0);

    private final BooleanSetting blockCount = new BooleanSetting("Block Count", false);

    private final NumberSetting sneakDelay = new NumberSetting("Sneak Delay", 150.0, 0.0, 1000.0);

    private final BooleanSetting requireSneak = new BooleanSetting("Require Sneak", false);

    private final NumberSetting activationBlocks = new NumberSetting("Activation Blocks", 0.0, 0.0, 10.0);

    private final BooleanSetting requireRightClick = new BooleanSetting("Require Right Click", false);

    private final NumberSetting yIncrease = new NumberSetting("Y Increase", 3.0, 0.0, 10.0);

    private int delayTimer = 0;

    private int placeGap = 0;

    private float bridgeStartY = 0;

    private float towerStartY = 0;

    private int towerTicks = 0;

    private boolean towerJumped = false;

    private boolean towerLanded = false;

    private int originalSlot = -1;

    private String[] lastFilterSnapshot = null;

    private final Set<Block> selectedBlocks = new HashSet<Block>();

    private int autoBlockCooldown = 0;

    private int swapSettleTicks = 0;

    private int preStageCooldown = 0;

    private boolean physicalSneak = false;

    private int edgeDwellTicks = 0;

    private int godStuckTicks = 0;

    private double godStuckRefX = 0;

    private double godStuckRefZ = 0;

    private int godSteerTicks = 0;

    private float lastGroundedY = 0;

    private static final int GOD_STEER_ENTER_TICKS = 6;

    private static final int GOD_STALL_STEER_TICKS = 10;

    private static final int GOD_STEER_MAX_TICKS = 16;

    private boolean legitSneaking = false;

    private long legitEdgeTimer = 0;

    private long legitSneakDelayMs = 150;

    private final Set<BlockPos> lastGroundAir = new HashSet<BlockPos>();

    private final Set<BlockPos> scanCurrentAir = new HashSet<BlockPos>();

    private int manualBlocksPlaced = 0;

    private boolean activated = false;

    private double yThreshold = 3.0;

    public Scaffold() {
        super("Scaffold", Category.BLOCKS);
        setDescription("Places blocks so you can’t fall off");
        addSetting(mode);
        addSetting(delay);
        addSetting(autoBlock);
        addSetting(expand);
        addSetting(tower);
        addSetting(blockFilter);
        addSetting(filterBlocks);
        addSetting(pitchCheck);
        addSetting(pitchAngle);
        addSetting(blockCount);
        addSetting(sneakDelay);
        addSetting(requireSneak);
        addSetting(activationBlocks);
        addSetting(requireRightClick);
        addSetting(yIncrease);
        sneakDelay.setVisibilityCondition(Condition.whenEqualTo(mode, "Legit"));
        requireSneak.setVisibilityCondition(Condition.whenEqualTo(mode, "Legit"));
        activationBlocks.setVisibilityCondition(Condition.or(Condition.whenEqualTo(mode, "GodBridge"), Condition.whenEqualTo(mode, "TellyBridge")));
        requireRightClick.setVisibilityCondition(Condition.whenEqualTo(mode, "TellyBridge"));
        yIncrease.setVisibilityCondition(Condition.whenEqualTo(mode, "TellyBridge"));
        pitchAngle.setVisibilityCondition(Condition.whenTrue(pitchCheck));
        filterBlocks.setVisibilityCondition(Condition.or(Condition.whenEqualTo(blockFilter, "Blacklist"), Condition.whenEqualTo(blockFilter, "Whitelist")));
        handles(HandlerType.TICK, HandlerType.UPDATE, HandlerType.GUI_RENDER);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        resetAllState();
        if (mc.player != null) {
            bridgeStartY = (float) mc.player.posY;
            towerStartY = bridgeStartY;
            originalSlot = mc.player.inventory.currentItem;
            if (autoBlock.getValue())
                ensureHoldingBlock();
        }
        BlockPlacementUtil.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.player != null) {
            releaseSneak();
            if (originalSlot != -1 && originalSlot >= 0 && originalSlot < 9 && mc.player.inventory.currentItem != originalSlot) {
                mc.playerController.windowClick(0, originalSlot + 36, mc.player.inventory.currentItem, ClickType.SWAP, mc.player);
                mc.player.inventory.currentItem = originalSlot;
                mc.player.connection.sendPacket(new CPacketHeldItemChange(originalSlot));
            }
        }
        BlockPlacementUtil.onDisable();
        if (mc.gameSettings != null) {
            SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindForward);
            SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindLeft);
            SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindRight);
            SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindBack);
        }
        resetAllState();
    }

    @Override
    public void onTick() {
        if (!nullCheck())
            return;
        BlockUtils.tickPlacements();
        if (mc.currentScreen != null) {
            BlockPlacementUtil.idle();
            releaseSneak();
            legitSneaking = false;
            return;
        }
        if (!SilentAimUtil.isActive()) {
            BlockPlacementUtil.onEnable();
        }
        if (autoBlock.getValue())
            ensureHoldingBlock();
        handleTower();
        if (swapSettleTicks > 0 && !mode.getValue().equals("Legit")) {
            swapSettleTicks--;
            if (mc.player.onGround) {
                applySneak();
            } else {
                releaseSneak();
            }
            BlockPlacementUtil.keepWarm();
            return;
        }
        if (!isHoldingBlock()) {
            boolean supplyComing = autoBlock.getValue() && (swapSettleTicks > 0 || findBestHotbarSlot(-1) != -1 || findDeepInventorySlot() != -1);
            if (supplyComing) {
                if (mc.player.onGround) {
                    applySneak();
                } else {
                    releaseSneak();
                }
                BlockPlacementUtil.keepWarm();
            } else {
                BlockPlacementUtil.idle();
                releaseSneak();
                legitSneaking = false;
                resetActivation();
            }
            return;
        }
        if (pitchCheck.getValue() && mc.player.rotationPitch < pitchAngle.getValue().floatValue()) {
            BlockPlacementUtil.idle();
            releaseSneak();
            legitSneaking = false;
            return;
        }
        delayTimer++;
        if (delayTimer <= delay.getValue().intValue()) {
            BlockPlacementUtil.idle();
            return;
        }
        if (towerModeIndex() > 0 && mc.gameSettings.keyBindJump.isKeyDown() && (mc.player.onGround || Math.abs(mc.player.motionX) + Math.abs(mc.player.motionZ) < 0.2)) {
            BlockPos towerTarget = BlockUtils.getPlacePosition(false, towerStartY, expand.getValue().doubleValue());
            if (towerTarget != null && mc.world.getBlockState(towerTarget).getMaterial().isReplaceable()) {
                boolean ready = BlockPlacementUtil.prepare(towerTarget, false, towerStartY, 40.0f, 180.0f, true, true, true);
                if (ready) {
                    placeNow();
                }
            } else {
                BlockPlacementUtil.idle();
            }
            releaseSneak();
            return;
        }
        String m = mode.getValue();
        if (m.equals("Legit")) {
            resetActivation();
            handleLegitEagle();
            return;
        }
        if (m.equals("TellyBridge")) {
            updateManualActivation();
            if (activated && !tellyInputGates()) {
                resetActivation();
            }
            handleTellyBridge();
            return;
        }
        updateManualActivation();
        handleGodBridge();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) {
            BlockPlacementUtil.idle();
            return;
        }
        SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindForward);
        SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindLeft);
        SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindRight);
        SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindBack);
        BlockPlacementUtil.restore();
    }

    private void placeNow() {
        try {
            if (BlockPlacementUtil.executePreMovement()) {
                BlockPlacementUtil.swing(EnumHand.MAIN_HAND);
                delayTimer = 0;
                godStuckTicks = 0;
                godStuckRefX = mc.player.posX;
                godStuckRefZ = mc.player.posZ;
                godSteerTicks = 0;
                edgeDwellTicks = 0;
                placeGap = 0;
            }
        } catch (Exception e) {
        }
    }

    private void handleLegitEagle() {
        BlockPlacementUtil.idle();
        if (!mc.player.onGround) {
            releaseSneak();
            legitSneaking = false;
            return;
        }
        if (requireSneak.getValue() && !mc.gameSettings.keyBindSneak.isKeyDown()) {
            releaseSneak();
            legitSneaking = false;
            return;
        }
        boolean wouldFall = predictFallNextTick();
        boolean shouldSneak = wouldFall;
        boolean skipTimerReset = false;
        long elapsed = System.currentTimeMillis() - legitEdgeTimer;
        if (!shouldSneak && legitSneaking && elapsed < legitSneakDelayMs && legitSneakDelayMs > 30) {
            shouldSneak = true;
            skipTimerReset = true;
        }
        if (!wouldFall && legitSneaking && elapsed > 500) {
            shouldSneak = false;
        }
        if (shouldSneak) {
            if (!legitSneaking) {
                legitSneakDelayMs = rollRandomMs(sneakDelay.getValue().doubleValue());
                legitEdgeTimer = System.currentTimeMillis();
                legitSneaking = true;
            }
            applySneak();
            if (!skipTimerReset) {
                legitEdgeTimer = System.currentTimeMillis();
            }
        } else {
            releaseSneak();
            legitSneaking = false;
        }
    }

    private boolean predictFallNextTick() {
        AxisAlignedBB box = mc.player.getEntityBoundingBox().expand(-0.2, 0.0, -0.2).offset(mc.player.motionX, -1.0, mc.player.motionZ);
        return mc.world.getCollisionBoxes(mc.player, box).isEmpty();
    }

    private boolean wouldLoseSupportNextTick() {
        AxisAlignedBB box = mc.player.getEntityBoundingBox().offset(mc.player.motionX, -1.0, mc.player.motionZ);
        return mc.world.getCollisionBoxes(mc.player, box).isEmpty();
    }

    private long rollRandomMs(double baseMs) {
        if (baseMs <= 0)
            return 0;
        double variation = baseMs * 0.4;
        long ms = Math.round(baseMs + (Math.random() - 0.5) * 2.0 * variation);
        return Math.max(1L, ms);
    }

    private boolean isSteerableTarget(BlockPos target) {
        int dx = target.x - (int) Math.floor(mc.player.posX);
        int dz = target.z - (int) Math.floor(mc.player.posZ);
        if (Math.abs(dx) > 1 || Math.abs(dz) > 1)
            return false;
        return BlockUtils.isSolid(target.north()) || BlockUtils.isSolid(target.south()) || BlockUtils.isSolid(target.east()) || BlockUtils.isSolid(target.west());
    }

    private double[] anchorFor(BlockPos target) {
        double ax = target.x + 0.5;
        double az = target.z + 0.5;
        EnumFacing bestDir = null;
        double bestDistSq = -1.0;
        EnumFacing[] horizontals = { EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.EAST, EnumFacing.WEST };
        for (EnumFacing f : horizontals) {
            BlockPos neighbor = target.offset(f);
            if (BlockUtils.isSolid(neighbor)) {
                double dx = neighbor.x + 0.5 - mc.player.posX;
                double dz = neighbor.z + 0.5 - mc.player.posZ;
                double distSq = dx * dx + dz * dz;
                if (distSq > bestDistSq) {
                    bestDistSq = distSq;
                    bestDir = f;
                }
            }
        }
        if (bestDir != null) {
            switch(bestDir) {
                case NORTH:
                    az = target.z + 0.15;
                    break;
                case SOUTH:
                    az = target.z + 0.85;
                    break;
                case EAST:
                    ax = target.x + 0.85;
                    break;
                case WEST:
                    ax = target.x + 0.15;
                    break;
                default:
                    break;
            }
        }
        return new double[] { ax, az };
    }

    private boolean glideWouldOvershootAnchor(double ax, double az) {
        double dirX = ax - mc.player.posX;
        double dirZ = az - mc.player.posZ;
        double len = Math.sqrt(dirX * dirX + dirZ * dirZ);
        if (len < 1.0E-4)
            return true;
        double sx = mc.player.posX + mc.player.motionX * 2.2;
        double sz = mc.player.posZ + mc.player.motionZ * 2.2;
        return (sx - ax) * (dirX / len) + (sz - az) * (dirZ / len) > 0.05;
    }

    private boolean pastAnchor(double ax, double az) {
        double dirX = ax - mc.player.posX;
        double dirZ = az - mc.player.posZ;
        double len = Math.sqrt(dirX * dirX + dirZ * dirZ);
        if (len < 1.0E-4)
            return true;
        double dot = (mc.player.posX - ax) * (dirX / len) + (mc.player.posZ - az) * (dirZ / len);
        return dot > 0.13;
    }

    private void setSteerKeys(double dirX, double dirZ) {
        float yaw = BlockPlacementUtil.isActive() ? BlockPlacementUtil.getRealYaw() : mc.player.rotationYaw;
        float yawRad = yaw * 0.017453292f;
        int f = (int) Math.round(dirZ * Math.cos(yawRad) - dirX * Math.sin(yawRad));
        int s = (int) Math.round(dirX * Math.cos(yawRad) + dirZ * Math.sin(yawRad));
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), f > 0);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), f < 0);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), s > 0);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), s < 0);
    }

    private void stopMovementKeys() {
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), false);
    }

    private void handleGodBridge() {
        if (!activated) {
            releaseSneak();
            BlockPlacementUtil.idle();
            return;
        }
        if (mc.player.onGround) {
            lastGroundedY = (float) mc.player.posY;
        }
        boolean airborne = !mc.player.onGround;
        BlockPos target = BlockUtils.getPlacePosition(airborne, lastGroundedY, expand.getValue().doubleValue());
        boolean targetValid = target != null && mc.world.getBlockState(target).getMaterial().isReplaceable();
        boolean holdingMove = mc.gameSettings.keyBindForward.isKeyDown() || mc.gameSettings.keyBindBack.isKeyDown() || mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown();
        if (mc.player.onGround && holdingMove && targetValid) {
            double ndx = mc.player.posX - godStuckRefX;
            double ndz = mc.player.posZ - godStuckRefZ;
            if (ndx * ndx + ndz * ndz > 0.2) {
                godStuckTicks = 0;
                godStuckRefX = mc.player.posX;
                godStuckRefZ = mc.player.posZ;
            } else {
                godStuckTicks++;
            }
        } else {
            godStuckTicks = 0;
            godStuckRefX = mc.player.posX;
            godStuckRefZ = mc.player.posZ;
            if (!targetValid) {
                godSteerTicks = 0;
            }
        }
        if (mc.player.onGround && targetValid && isSteerableTarget(target) && (edgeDwellTicks >= GOD_STEER_ENTER_TICKS || godStuckTicks >= GOD_STALL_STEER_TICKS)) {
            godSteerTicks = GOD_STEER_MAX_TICKS;
        }
        boolean steering = godSteerTicks > 0 && mc.player.onGround && targetValid && isSteerableTarget(target);
        if (steering) {
            godSteerTicks--;
            double[] anchor = anchorFor(target);
            double ax = anchor[0] - mc.player.posX;
            double az = anchor[1] - mc.player.posZ;
            double dSq = ax * ax + az * az;
            if (dSq < 0.01 || pastAnchor(anchor[0], anchor[1])) {
                godSteerTicks = 0;
                stopMovementKeys();
            } else if (!physicalSneak && glideWouldOvershootAnchor(anchor[0], anchor[1])) {
                stopMovementKeys();
            } else {
                double inv = 1.0 / Math.sqrt(dSq);
                setSteerKeys(ax * inv, az * inv);
            }
        }
        boolean atEdge = mc.player.onGround && predictFallNextTick();
        boolean hardFall = mc.player.onGround && wouldLoseSupportNextTick();
        if (hardFall) {
            applySneak();
        } else {
            releaseSneak();
        }
        if (atEdge) {
            if (!steering) {
                stopMovementKeys();
            }
            edgeDwellTicks++;
        } else {
            edgeDwellTicks = 0;
        }
        if (placeGap > 0) {
            placeGap--;
            if (targetValid) {
                BlockPlacementUtil.prepare(target, airborne, lastGroundedY, 30.0f, 55.0f, true, true, true);
            } else {
                BlockPlacementUtil.keepWarm();
            }
            return;
        }
        if (targetValid) {
            boolean ready = BlockPlacementUtil.prepare(target, airborne, lastGroundedY, 30.0f, 55.0f, true, true, true);
            if (ready) {
                placeNow();
            }
        } else {
            BlockPlacementUtil.keepWarm();
        }
    }

    private boolean tellyInputGates() {
        boolean moving = mc.gameSettings.keyBindForward.isKeyDown() || mc.gameSettings.keyBindBack.isKeyDown() || mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown() || Math.abs(mc.player.motionX) > 0.05 || Math.abs(mc.player.motionZ) > 0.05;
        if (!moving)
            return false;
        if (requireRightClick.getValue() && !mc.gameSettings.keyBindUseItem.isKeyDown()) {
            return false;
        }
        return true;
    }

    private void handleTellyBridge() {
        releaseSneak();
        if (!activated) {
            BlockPlacementUtil.idle();
            return;
        }
        if (!tellyInputGates()) {
            BlockPlacementUtil.idle();
            return;
        }
        if (mc.player.onGround) {
            yThreshold = rollYThreshold();
            BlockPos next = BlockUtils.getPlacePosition(true, bridgeStartY, expand.getValue().doubleValue());
            if (next != null && mc.world.getBlockState(next).getMaterial().isReplaceable()) {
                boolean gapTick = placeGap > 0;
                if (gapTick) {
                    placeGap--;
                }
                if (BlockPlacementUtil.prepare(next, false, bridgeStartY, 35.0f, 55.0f, true, true, true) && !gapTick) {
                    placeNow();
                }
                mc.player.jump();
            } else {
                BlockPlacementUtil.keepWarm();
            }
            return;
        }
        if (mc.player.posY > bridgeStartY + Math.max(yThreshold, 1.5)) {
            BlockPlacementUtil.idle();
            return;
        }
        if (placeGap > 0) {
            placeGap--;
            BlockPos gapTarget = BlockUtils.getPlacePosition(true, bridgeStartY, expand.getValue().doubleValue());
            if (gapTarget != null && mc.world.getBlockState(gapTarget).getMaterial().isReplaceable()) {
                BlockPlacementUtil.prepare(gapTarget, false, bridgeStartY, 35.0f, 55.0f, true, true, true);
            } else {
                BlockPlacementUtil.keepWarm();
            }
            return;
        }
        BlockPos target = BlockUtils.getPlacePosition(true, bridgeStartY, expand.getValue().doubleValue());
        if (target != null && mc.world.getBlockState(target).getMaterial().isReplaceable()) {
            boolean ready = BlockPlacementUtil.prepare(target, false, bridgeStartY, 35.0f, 55.0f, true, true, true);
            if (ready) {
                placeNow();
            }
        } else {
            BlockPlacementUtil.keepWarm();
        }
    }

    private double rollYThreshold() {
        double base = yIncrease.getValue().doubleValue();
        if (base <= 0)
            return 0;
        double r = Math.random();
        if (r < 0.15)
            return base + 1.0;
        if (r < 0.25)
            return Math.max(1.0, base - 1.0);
        return base;
    }

    private void updateManualActivation() {
        if (!mc.player.onGround) {
            lastGroundAir.clear();
            return;
        }
        int px = (int) Math.floor(mc.player.posX);
        int py = (int) Math.floor(mc.player.posY) - 1;
        int pz = (int) Math.floor(mc.player.posZ);
        Set<BlockPos> currentAir = scanCurrentAir;
        currentAir.clear();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                BlockPos pos = new BlockPos(px + dx, py, pz + dz);
                if (mc.world.isAirBlock(pos)) {
                    currentAir.add(pos);
                }
            }
        }
        if (!activated) {
            for (BlockPos pos : lastGroundAir) {
                if (!currentAir.contains(pos) && !BlockUtils.wasRecentlyPlaced(pos)) {
                    manualBlocksPlaced++;
                }
            }
            if (manualBlocksPlaced >= activationBlocks.getValue().intValue()) {
                activated = true;
                manualBlocksPlaced = 0;
                bridgeStartY = (float) mc.player.posY;
            }
        }
        lastGroundAir.clear();
        lastGroundAir.addAll(currentAir);
    }

    private void resetActivation() {
        activated = false;
        manualBlocksPlaced = 0;
        lastGroundAir.clear();
    }

    private void applySneak() {
        if (physicalSneak)
            return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), true);
        mc.player.setSneaking(true);
        physicalSneak = true;
    }

    private void releaseSneak() {
        if (!physicalSneak)
            return;
        SilentAimUtil.setKeyFromHardware(mc.gameSettings.keyBindSneak);
        mc.player.setSneaking(false);
        physicalSneak = false;
    }

    private int towerModeIndex() {
        String t = tower.getValue();
        if (t.equals("Jump"))
            return 1;
        if (t.equals("Motion"))
            return 2;
        if (t.equals("Step"))
            return 3;
        if (t.equals("Smooth"))
            return 4;
        return 0;
    }

    private void handleTower() {
        int tMode = towerModeIndex();
        if (tMode == 0)
            return;
        if (!mc.gameSettings.keyBindJump.isKeyDown()) {
            towerTicks = 0;
            towerJumped = false;
            towerLanded = false;
            return;
        }
        if (!mc.player.onGround)
            return;
        BlockPos below = new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY) - 1, Math.floor(mc.player.posZ));
        if (!mc.world.getBlockState(below).getMaterial().isReplaceable()) {
            towerTicks = 0;
            return;
        }
        switch(tMode) {
            case 1:
                mc.player.jump();
                break;
            case 2:
                if (towerTicks == 0) {
                    towerStartY = (float) mc.player.posY;
                    mc.player.motionY = 0.42;
                    towerTicks++;
                } else if (mc.player.posY > towerStartY + 1.0) {
                    mc.player.motionY = -0.15;
                    towerTicks = 0;
                }
                break;
            case 3:
                if (towerTicks == 0) {
                    mc.player.jump();
                    towerJumped = true;
                    towerLanded = false;
                }
                if (mc.player.onGround && towerJumped && !towerLanded) {
                    towerLanded = true;
                    towerTicks = -1;
                }
                towerTicks++;
                break;
            case 4:
                if (towerTicks == 0) {
                    mc.player.motionY = -0.07;
                    towerTicks++;
                } else if (towerTicks == 2) {
                    mc.player.jump();
                    towerTicks = 0;
                } else {
                    towerTicks++;
                }
                break;
            default:
                break;
        }
    }

    private boolean isHoldingBlock() {
        return isUsableBlockStack(mc.player.getHeldItemMainhand());
    }

    private boolean isUsableBlockStack(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return false;
        if (!(stack.getItem() instanceof ItemBlock))
            return false;
        Block block = Block.getBlockFromItem(stack.getItem());
        if (block == null || block == Blocks.AIR)
            return false;
        if (!block.getDefaultState().isFullBlock())
            return false;
        if (block instanceof BlockFalling)
            return false;
        if (block == Blocks.TNT || block == Blocks.WEB || block == Blocks.PORTAL || block == Blocks.END_PORTAL || block == Blocks.FLOWING_LAVA || block == Blocks.LAVA)
            return false;
        syncFilterCache();
        String f = blockFilter.getValue();
        if (f.equals("Blacklist") && selectedBlocks.contains(block))
            return false;
        if (f.equals("Whitelist") && !selectedBlocks.contains(block))
            return false;
        return true;
    }

    private void syncFilterCache() {
        String[] current = filterBlocks.getValue();
        if (Arrays.equals(current, lastFilterSnapshot))
            return;
        selectedBlocks.clear();
        if (current != null) {
            for (String id : current) {
                Block block = BlockListSetting.lookupBlock(id);
                if (block != null) {
                    selectedBlocks.add(block);
                }
            }
        }
        lastFilterSnapshot = current;
    }

    @Override
    public void onGUIRender() {
        if (!nullCheck())
            return;
        if (!blockCount.getValue())
            return;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held == null || held.func_190926_b() || !(held.getItem() instanceof ItemBlock))
            return;
        int count = 0;
        for (int i = 0; i < mc.player.inventory.mainInventory.size(); i++) {
            ItemStack s = mc.player.inventory.mainInventory.get(i);
            if (s != null && !s.func_190926_b() && s.getItem() == held.getItem()) {
                count += s.func_190916_E();
            }
        }
        if (count <= 0)
            return;
        String text = String.valueOf(count);
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        GlStateManager.pushMatrix();
        GlStateManager.translate(sr.getScaledWidth() / 2.0F, sr.getScaledHeight() / 2.0F + 14.0F, 0.0F);
        GlStateManager.scale(2.0F, 2.0F, 2.0F);
        ClientFontRenderer.drawCenteredStringWithShadow(text, 0, 0, 0xFFFFFFD0);
        GlStateManager.popMatrix();
    }

    public static boolean shouldSuppressVanillaUseClick() {
        Minecraft mcin = Minecraft.getMinecraft();
        if (mcin.player == null)
            return false;
        try {
            Module self = client.module.ModuleManager.getModuleByName("Scaffold");
            if (!(self instanceof Scaffold) || !self.isToggled()) {
                return false;
            }
            Scaffold s = (Scaffold) self;
            String m = s.mode.getValue();
            if (m == null || m.equals("Legit"))
                return false;
            if (!SilentAimUtil.isOwnedBy("Scaffold"))
                return false;
            if (!s.isUsableBlockStack(mcin.player.getHeldItemMainhand())) {
                return false;
            }
            return BlockPlacementUtil.isAimSpoofedRecently();
        } catch (Throwable t) {
            return false;
        }
    }

    private void ensureHoldingBlock() {
        if (!autoBlock.getValue())
            return;
        if (isHoldingBlock()) {
            autoBlockCooldown = 0;
            maybePreStageDeepSwap();
            return;
        }
        if (autoBlockCooldown > 0) {
            autoBlockCooldown--;
            return;
        }
        int cur = mc.player.inventory.currentItem;
        int hotbar = findBestHotbarSlot(cur);
        if (hotbar != -1) {
            mc.player.inventory.currentItem = hotbar;
            return;
        }
        int deep = findDeepInventorySlot();
        if (deep == -1) {
            autoBlockCooldown = 3;
            return;
        }
        mc.playerController.windowClick(0, deep, cur, ClickType.SWAP, mc.player);
        swapSettleTicks = 4;
        autoBlockCooldown = 3;
    }

    private int findBestHotbarSlot(int excludeSlot) {
        int bestSlot = -1;
        int bestCount = 0;
        for (int i = 0; i < 9; i++) {
            if (i == excludeSlot)
                continue;
            ItemStack s = mc.player.inventory.getStackInSlot(i);
            if (!isUsableBlockStack(s))
                continue;
            int count = s.func_190916_E();
            if (count > bestCount) {
                bestCount = count;
                bestSlot = i;
            }
        }
        return bestSlot;
    }

    private int findDeepInventorySlot() {
        int bestSlot = -1;
        int bestCount = 0;
        for (int i = 9; i < 36; i++) {
            ItemStack s = mc.player.inventory.getStackInSlot(i);
            if (!isUsableBlockStack(s))
                continue;
            int count = s.func_190916_E();
            if (count > bestCount) {
                bestCount = count;
                bestSlot = i;
            }
        }
        return bestSlot;
    }

    private void maybePreStageDeepSwap() {
        if (preStageCooldown > 0) {
            preStageCooldown--;
            return;
        }
        if (!mc.player.onGround)
            return;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held == null || held.func_190926_b())
            return;
        if (held.func_190916_E() > 8)
            return;
        int cur = mc.player.inventory.currentItem;
        if (findBestHotbarSlot(cur) != -1)
            return;
        int deep = findDeepInventorySlot();
        if (deep == -1)
            return;
        int target = -1;
        for (int i = 0; i < 9; i++) {
            if (i == cur)
                continue;
            ItemStack s = mc.player.inventory.getStackInSlot(i);
            if (s == null || s.func_190926_b()) {
                target = i;
                break;
            }
        }
        if (target == -1)
            return;
        mc.playerController.windowClick(0, deep, target, ClickType.SWAP, mc.player);
        preStageCooldown = 6;
    }

    private void resetAllState() {
        delayTimer = 0;
        placeGap = 0;
        towerTicks = 0;
        towerJumped = false;
        towerLanded = false;
        swapSettleTicks = 0;
        preStageCooldown = 0;
        bridgeStartY = 0;
        towerStartY = 0;
        originalSlot = -1;
        physicalSneak = false;
        autoBlockCooldown = 0;
        legitSneaking = false;
        legitEdgeTimer = 0;
        legitSneakDelayMs = 150;
        edgeDwellTicks = 0;
        godStuckTicks = 0;
        godStuckRefX = 0;
        godStuckRefZ = 0;
        godSteerTicks = 0;
        lastGroundedY = 0;
        resetActivation();
        yThreshold = 3.0;
    }
}
