package client.module.impl.blocks;

import java.util.ArrayList;
import java.util.List;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.misc.ChatUtils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.BlockNetherWart;
import net.minecraft.block.BlockPumpkin;
import net.minecraft.block.BlockMelon;
import net.minecraft.block.BlockReed;
import net.minecraft.block.BlockCactus;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class AutoFarm extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 4.0, 1.0, 6.0);

    private final BooleanSetting autoSwitch = new BooleanSetting("AutoSwitch", true);

    private final NumberSetting delay = new NumberSetting("Delay", 1.0, 1.0, 10.0);

    private int tickCounter = 0;

    public AutoFarm() {
        super("AutoFarm", Category.BLOCKS);
        setDescription("Automatically harvests and replants crops");
        addSetting(range);
        addSetting(autoSwitch);
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.currentScreen != null)
            return;
        tickCounter++;
        int actualDelay = delay.getValue().intValue();
        if (tickCounter < actualDelay)
            return;
        tickCounter = 0;
        double rangeVal = range.getValue();
        BlockPos playerPos = new BlockPos(mc.player);
        int blockRange = (int) Math.ceil(rangeVal);
        BlockPos cropPos = findNearestMatureCrop(playerPos, blockRange, rangeVal);
        if (cropPos != null) {
            breakCrop(cropPos);
            return;
        }
        BlockPos plantPos = findNearestEmptyFarmland(playerPos, blockRange, rangeVal);
        if (plantPos != null) {
            plantSeed(plantPos);
        }
    }

    private BlockPos findNearestMatureCrop(BlockPos center, int blockRange, double rangeVal) {
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos pos : BlockPos.getAllInBox(center.add(blockRange, blockRange, blockRange), center.add(-blockRange, -blockRange, -blockRange))) {
            if (WorldUtils.isAir(pos))
                continue;
            double dist = mc.player.getDistanceSq(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
            if (dist > rangeVal * rangeVal)
                continue;
            Block block = WorldUtils.getBlock(pos);
            if (isMatureCrop(block, pos) && dist < bestDist) {
                bestDist = dist;
                best = pos;
            }
        }
        return best;
    }

    private BlockPos findNearestEmptyFarmland(BlockPos center, int blockRange, double rangeVal) {
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos pos : BlockPos.getAllInBox(center.add(blockRange, blockRange, blockRange), center.add(-blockRange, -blockRange, -blockRange))) {
            Block below = WorldUtils.getBlock(pos);
            if (below != Blocks.FARMLAND && below != Blocks.SOUL_SAND)
                continue;
            if (!WorldUtils.isAir(pos.up()))
                continue;
            double dist = mc.player.getDistanceSq(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
            if (dist > rangeVal * rangeVal)
                continue;
            if (getSeedForSoil(below) != -1) {
                if (dist < bestDist) {
                    bestDist = dist;
                    best = pos;
                }
            }
        }
        return best;
    }

    private int getSeedForSoil(Block soil) {
        if (soil == Blocks.FARMLAND) {
            int slot;
            slot = findSeedInHotbar(Items.WHEAT_SEEDS);
            if (slot != -1)
                return slot;
            slot = findSeedInHotbar(Items.CARROT);
            if (slot != -1)
                return slot;
            slot = findSeedInHotbar(Items.POTATO);
            if (slot != -1)
                return slot;
            slot = findSeedInHotbar(Items.BEETROOT_SEEDS);
            if (slot != -1)
                return slot;
            slot = findSeedInHotbar(Item.getItemFromBlock(Blocks.REEDS));
            if (slot != -1)
                return slot;
            slot = findSeedInHotbar(Item.getItemFromBlock(Blocks.CACTUS));
            if (slot != -1)
                return slot;
        } else if (soil == Blocks.SOUL_SAND) {
            return findSeedInHotbar(Items.NETHER_WART);
        }
        return -1;
    }

    private int findSeedInHotbar(Item seedItem) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.func_190926_b())
                continue;
            if (stack.getItem() == seedItem)
                return i;
        }
        return -1;
    }

    private void breakCrop(BlockPos pos) {
        if (mc.player.capabilities.isCreativeMode) {
            InteractionUtils.breakBlock(pos);
        } else {
            InteractionUtils.breakBlock(pos, EnumFacing.UP);
            mc.player.swingArm(EnumHand.MAIN_HAND);
        }
    }

    private void plantSeed(BlockPos soilPos) {
        Block soil = WorldUtils.getBlock(soilPos);
        int seedSlot = getSeedForSoil(soil);
        if (seedSlot == -1)
            return;
        int prevSlot = mc.player.inventory.currentItem;
        if (autoSwitch.getValue()) {
            mc.player.inventory.currentItem = seedSlot;
        }
        Vec3d hitVec = new Vec3d(soilPos.getX() + 0.5, soilPos.getY() + 1.0, soilPos.getZ() + 0.5);
        InteractionUtils.placeBlock(soilPos, EnumFacing.UP, hitVec, EnumHand.MAIN_HAND);
        mc.player.swingArm(EnumHand.MAIN_HAND);
        if (autoSwitch.getValue() && prevSlot != seedSlot) {
            mc.player.inventory.currentItem = prevSlot;
        }
    }

    private boolean isMatureCrop(Block block, BlockPos pos) {
        IBlockState state = WorldUtils.getState(pos);
        if (block instanceof BlockCrops) {
            return ((BlockCrops) block).isMaxAge(state);
        }
        if (block == Blocks.NETHER_WART) {
            return state.getValue(BlockNetherWart.AGE) >= 3;
        }
        if (block == Blocks.PUMPKIN) {
            return true;
        }
        if (block == Blocks.MELON_BLOCK) {
            return true;
        }
        if (block == Blocks.REEDS) {
            return WorldUtils.getState(pos.up()).getBlock() == Blocks.REEDS;
        }
        if (block == Blocks.CACTUS) {
            return WorldUtils.getState(pos.up()).getBlock() == Blocks.CACTUS;
        }
        return false;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        ChatUtils.info("AutoFarm enabled - harvesting & replanting crops");
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.playerController != null) {
            InteractionUtils.stopMining();
        }
        tickCounter = 0;
    }
}
