package client.module.impl.blocks;

import java.util.Random;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.utils.misc.ChatUtils;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class BuildRandom extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Mode", "Legit", "Fast", "Legit");

    private final Random random = new Random();

    public BuildRandom() {
        super("BuildRandom", Category.BLOCKS);
        setDescription("Automatically builds random structures around you");
        addSetting(mode);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held == null || held.func_190926_b() || !(held.getItem() instanceof ItemBlock))
            return;
        boolean isLegit = mode.getValue().equals("Legit");
        int range = isLegit ? 5 : 6;
        for (int attempts = 0; attempts < 128; attempts++) {
            int rx = random.nextInt(range * 2 + 1) - range;
            int ry = random.nextInt(range * 2 + 1) - range;
            int rz = random.nextInt(range * 2 + 1) - range;
            BlockPos pos = new BlockPos(mc.player).add(rx, ry, rz);
            if (!WorldUtils.isReplaceable(pos))
                continue;
            if (placeBlock(pos)) {
                if (isLegit) {
                    return;
                }
            }
        }
    }

    private boolean placeBlock(BlockPos pos) {
        for (EnumFacing facing : EnumFacing.values()) {
            BlockPos neighbor = pos.offset(facing);
            Block neighborBlock = WorldUtils.getBlock(neighbor);
            if (WorldUtils.isReplaceable(neighbor) || !neighborBlock.isCollidable())
                continue;
            Vec3d hitVec = new Vec3d(neighbor.x + 0.5, neighbor.y + 0.5, neighbor.z + 0.5).add(new Vec3d(facing.getDirectionVec()).scale(-0.5));
            InteractionUtils.placeBlock(neighbor, facing.getOpposite(), hitVec, EnumHand.MAIN_HAND);
            mc.player.swingArm(EnumHand.MAIN_HAND);
            return true;
        }
        return false;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        ChatUtils.info("BuildRandom enabled - hold a block in your hand");
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }
}
