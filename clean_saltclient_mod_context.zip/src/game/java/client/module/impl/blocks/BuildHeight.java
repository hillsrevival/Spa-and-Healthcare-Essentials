package client.module.impl.blocks;

import client.event.events.PacketOutputEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;

public class BuildHeight extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public BuildHeight() {
        super("BuildHeight", Category.BLOCKS);
        setDescription("Allows placing and breaking blocks at the height limit");
        handles(HandlerType.PACKET_OUTPUT);
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        if (!nullCheck())
            return;
        if (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
            CPacketPlayerTryUseItemOnBlock packet = (CPacketPlayerTryUseItemOnBlock) event.getPacket();
            int y = packet.getPos().y;
            if (y < 0 || y > 255) {
                event.setCancelled(true);
            }
        }
    }
}
