package client.module.impl.blocks;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import client.utils.world.PacketUtils;
import client.utils.world.InteractionUtils;
import client.utils.player.InventoryManager;
import client.utils.world.WorldUtils;

public class EChestFarmer extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting autoToggle = new BooleanSetting("AutoToggle", false);

    private final NumberSetting targetAmount = new NumberSetting("Target", 64.0, 1.0, 512.0);

    private BlockPos target = null;

    private int startObsidian = 0;

    private int savedSlot = -1;

    private int miningSlotSynced = -1;

    public EChestFarmer() {
        super("EChestFarmer", Category.BLOCKS);
        setDescription("Automatically farms ender chests");
        addSetting(autoToggle);
        addSetting(targetAmount);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        target = null;
        startObsidian = countObsidian();
        if (mc.player != null) {
            savedSlot = mc.player.inventory.currentItem;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.playerController != null) {
            InteractionUtils.stopMining();
        }
        if (mc.player != null) {
            if (savedSlot >= 0 && savedSlot < 9 && mc.player.inventory.currentItem != savedSlot) {
                InventoryManager.switchToSlot(savedSlot);
            }
        }
        savedSlot = -1;
        target = null;
        miningSlotSynced = -1;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.currentScreen != null)
            return;
        if (target == null) {
            if (mc.objectMouseOver == null || mc.objectMouseOver.typeOfHit != RayTraceResult.Type.BLOCK)
                return;
            BlockPos lookingAt = mc.objectMouseOver.getBlockPos();
            BlockPos above = lookingAt.up();
            IBlockState state = WorldUtils.getState(above);
            if (state.getBlock() == Blocks.AIR || state.getBlock() == Blocks.ENDER_CHEST || state.getMaterial().isReplaceable()) {
                target = above;
            } else {
                return;
            }
        }
        double dist = mc.player.getDistanceSq(target.getX() + 0.5, target.getY() + 0.5, target.getZ() + 0.5);
        if (dist > 25.0) {
            target = null;
            return;
        }
        if (autoToggle.getValue()) {
            int farmed = countObsidian() - startObsidian;
            if (farmed >= targetAmount.getValue().intValue()) {
                toggle();
                return;
            }
        }
        IBlockState targetState = WorldUtils.getState(target);
        if (targetState.getBlock() == Blocks.ENDER_CHEST) {
            int bestSlot = findBestPickaxe();
            if (bestSlot == -1)
                return;
            if (miningSlotSynced != bestSlot) {
                InventoryManager.switchToSlot(bestSlot);
                miningSlotSynced = bestSlot;
            }
            InteractionUtils.damageBlock(target, EnumFacing.UP);
            mc.player.swingArm(EnumHand.MAIN_HAND);
            return;
        }
        if (targetState.getBlock() == Blocks.AIR || targetState.getMaterial().isReplaceable()) {
            int echestSlot = findEchestInHotbar();
            if (echestSlot == -1) {
                toggle();
                return;
            }
            miningSlotSynced = -1;
            int oldSlot = mc.player.inventory.currentItem;
            InventoryManager.switchToSlot(echestSlot);
            placeBlock(target);
            mc.player.swingArm(EnumHand.MAIN_HAND);
            InventoryManager.switchToSlot(oldSlot);
        }
    }

    private int findBestPickaxe() {
        int bestSlot = -1;
        float bestSpeed = -1.0f;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.func_190926_b())
                continue;
            if (!(stack.getItem() instanceof ItemPickaxe))
                continue;
            int silkTouch = EnchantmentHelper.getEnchantmentLevel(Enchantments.SILK_TOUCH, stack);
            if (silkTouch > 0)
                continue;
            float speed = stack.getStrVsBlock(Blocks.ENDER_CHEST.getDefaultState());
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = i;
            }
        }
        return bestSlot;
    }

    private int findEchestInHotbar() {
        Item echestItem = Item.getItemFromBlock(Blocks.ENDER_CHEST);
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.func_190926_b())
                continue;
            if (stack.getItem() == echestItem)
                return i;
        }
        return -1;
    }

    private void placeBlock(BlockPos pos) {
        BlockPos below = pos.down();
        if (WorldUtils.getBlock(below).isCollidable()) {
            doPlace(pos, below, EnumFacing.UP);
            return;
        }
        for (EnumFacing facing : EnumFacing.values()) {
            BlockPos neighbor = pos.offset(facing);
            if (WorldUtils.getBlock(neighbor).isCollidable()) {
                doPlace(pos, neighbor, facing);
                return;
            }
        }
    }

    private void doPlace(BlockPos pos, BlockPos neighbor, EnumFacing dir) {
        Vec3d hitVec = new Vec3d(neighbor.getX() + 0.5, neighbor.getY() + 0.5, neighbor.getZ() + 0.5).add(new Vec3d(dir.getDirectionVec()).scale(-0.5));
        InteractionUtils.placeBlock(neighbor, dir.getOpposite(), hitVec, EnumHand.MAIN_HAND);
    }

    private int countObsidian() {
        int count = 0;
        Item obsidianItem = Item.getItemFromBlock(Blocks.OBSIDIAN);
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (!stack.func_190926_b() && stack.getItem() == obsidianItem) {
                count += stack.func_190916_E();
            }
        }
        return count;
    }
}
