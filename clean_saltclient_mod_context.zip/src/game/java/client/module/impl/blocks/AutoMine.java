package client.module.impl.blocks;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.misc.ChatUtils;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import java.util.Random;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class AutoMine extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Random rand = new Random();

    private final NumberSetting startDelay = new NumberSetting("Start Delay", 1.0, 0.0, 5.0);

    private int delayCounter = 0;

    private BlockPos lastTarget = null;

    public AutoMine() {
        super("AutoMine", Category.BLOCKS);
        setDescription("Automatically mines the block you are looking at");
        addSetting(startDelay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        RayTraceResult result = mc.objectMouseOver;
        if (result == null || result.typeOfHit != RayTraceResult.Type.BLOCK) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
            lastTarget = null;
            return;
        }
        BlockPos pos = result.getBlockPos();
        if (lastTarget == null || !lastTarget.equals(pos)) {
            lastTarget = pos;
            delayCounter = 0;
            int delay = startDelay.getValue().intValue() + (rand.nextDouble() < 0.3 ? 1 : 0);
            if (delayCounter < delay) {
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
                delayCounter++;
                return;
            }
        }
        if (mc.gameSettings.keyBindAttack.isKeyDown() && !InteractionUtils.isMining()) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
            return;
        }
        boolean shouldMine = WorldUtils.getState(pos).getMaterial() != Material.AIR;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), shouldMine);
    }

    @Override
    public void onDisable() {
        if (mc.gameSettings != null) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
        }
        super.onDisable();
        lastTarget = null;
        delayCounter = 0;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        ChatUtils.info("AutoMine enabled - look at a block to mine it");
    }
}
