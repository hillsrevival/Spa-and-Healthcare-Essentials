package client.module.impl.blocks;

import java.util.ArrayList;
import java.util.List;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.ModeSetting;
import client.utils.misc.ChatUtils;
import client.utils.player.InvUtils;
import client.utils.player.SlotUtils;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class Tunneller extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting delay = new NumberSetting("Delay", 3.0, 1.0, 10.0);

    private java.util.Random rand = new java.util.Random();

    private BlockPos currentTarget;

    private int tickCounter = 0;

    public Tunneller() {
        super("Tunneller", Category.BLOCKS);
        setDescription("Digs tunnels in a straight line");
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        tickCounter++;
        int actualDelay = delay.getValue().intValue() + (rand.nextInt(2) == 0 ? 1 : 0);
        if (tickCounter < actualDelay)
            return;
        tickCounter = 0;
        BlockPos playerPos = new BlockPos(mc.player);
        BlockPos target = null;
        for (int x = 1; x >= -1; x--) {
            for (int y = 1; y >= -1; y--) {
                for (int z = 1; z >= -1; z--) {
                    if (x == 0 && y == 0 && z == 0)
                        continue;
                    BlockPos pos = playerPos.add(x, y, z);
                    if (WorldUtils.isAir(pos))
                        continue;
                    if (WorldUtils.isLiquid(pos.x, pos.y, pos.z))
                        continue;
                    if (target == null)
                        target = pos;
                }
            }
        }
        if (target == null)
            return;
        currentTarget = target;
        if (mc.player.capabilities.isCreativeMode) {
            InteractionUtils.breakBlock(target);
        } else {
            InteractionUtils.breakBlock(target, EnumFacing.UP);
        }
        if (mc.player.ticksExisted % 100 == 0) {
            placeTorch();
        }
    }

    private void placeTorch() {
        client.utils.player.FindItemResult torch = InvUtils.findInHotbar(stack -> stack != null && !stack.func_190926_b() && stack.getItem() == net.minecraft.item.Item.getItemFromBlock(net.minecraft.init.Blocks.TORCH));
        if (torch.found()) {
            int i = torch.slot() - SlotUtils.HOTBAR_START;
            int oldSlot = mc.player.inventory.currentItem;
            mc.player.inventory.currentItem = i;
            BlockPos torchPos = new BlockPos(mc.player);
            if (WorldUtils.isAir(torchPos)) {
                BlockPos floorPos = torchPos.down();
                if (!WorldUtils.isAir(floorPos)) {
                    InteractionUtils.placeBlock(floorPos, EnumFacing.UP, new net.minecraft.util.math.Vec3d(floorPos.x + 0.5, floorPos.y + 1.0, floorPos.z + 0.5), net.minecraft.util.EnumHand.MAIN_HAND);
                }
            }
            mc.player.inventory.currentItem = oldSlot;
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        currentTarget = null;
        tickCounter = 0;
    }

    @Override
    public void onDisable() {
        currentTarget = null;
        if (mc.gameSettings != null) {
            net.minecraft.client.settings.KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
        }
        if (mc.playerController != null) {
            InteractionUtils.stopMining();
        }
        super.onDisable();
        tickCounter = 0;
    }
}
