package client.module.impl.blocks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.state.IBlockState;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.ModeSetting;
import client.event.listeners.RenderListener;
import client.utils.misc.ChatUtils;
import client.utils.render.RenderUtils;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class Nuker extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 4.5, 1.0, 6.0);

    private final ModeSetting mode = new ModeSetting("Mode", "Normal", "Normal", "Flat", "Smash", "Crosshair", "ID");

    private final NumberSetting blocksPerTick = new NumberSetting("BlocksPerTick", 0.0, 0.0, 20.0);

    private BlockPos currentBlock;

    private final java.util.List<BlockPos> scanBuffer = new ArrayList<>();

    private final java.util.Comparator<BlockPos> scanComparator = new java.util.Comparator<BlockPos>() {

        @Override
        public int compare(BlockPos a, BlockPos b) {
            double da = mc.player.getDistanceSq(a.x + 0.5, a.y + 0.5, a.z + 0.5);
            double db = mc.player.getDistanceSq(b.x + 0.5, b.y + 0.5, b.z + 0.5);
            return Double.compare(da, db);
        }
    };

    private Block idBlock = null;

    public Nuker() {
        super("Nuker", Category.BLOCKS);
        setDescription("Breaks all blocks in range around you");
        addSetting(range);
        addSetting(mode);
        addSetting(blocksPerTick);
        handles(HandlerType.UPDATE, HandlerType.RENDER, HandlerType.LEFT_CLICK);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mode.getValue().equals("Crosshair")) {
            if (mc.objectMouseOver == null || mc.objectMouseOver.getBlockPos() == null)
                return;
            BlockPos targetPos = mc.objectMouseOver.getBlockPos();
            double dist = mc.player.getDistance(targetPos.x + 0.5, targetPos.y + 0.5, targetPos.z + 0.5);
            if (dist > range.getValue())
                return;
            if (WorldUtils.isAir(targetPos))
                return;
            if (WorldUtils.getBlockHardness(targetPos) < 0.0f)
                return;
            InteractionUtils.breakBlock(targetPos, mc.player.getHorizontalFacing());
            currentBlock = targetPos;
            return;
        }
        currentBlock = null;
        double rangeVal = range.getValue();
        BlockPos playerPos = new BlockPos(mc.player);
        int blockRange = (int) Math.ceil(rangeVal);
        List<BlockPos> blocks = scanBuffer;
        blocks.clear();
        String modeVal = mode.getValue();
        double rangeSq = rangeVal * rangeVal;
        for (BlockPos pos : BlockPos.getAllInBox(playerPos.add(blockRange, blockRange, blockRange), playerPos.add(-blockRange, -blockRange, -blockRange))) {
            double px = pos.x + 0.5;
            double py = pos.y + 0.5;
            double pz = pos.z + 0.5;
            double dist = mc.player.getDistanceSq(px, py, pz);
            if (dist > rangeSq)
                continue;
            if (WorldUtils.isAir(pos))
                continue;
            if (modeVal.equals("Flat") && pos.y < mc.player.posY)
                continue;
            if (modeVal.equals("Smash") && WorldUtils.getBlockHardness(pos) >= 1.0f)
                continue;
            if (modeVal.equals("ID") && idBlock != null && WorldUtils.getBlock(pos) != idBlock)
                continue;
            blocks.add(pos);
        }
        blocks.sort(scanComparator);
        if (mc.player.capabilities.isCreativeMode) {
            int limit = blocksPerTick.getValue().intValue();
            int broken = 0;
            for (BlockPos pos : blocks) {
                InteractionUtils.breakBlock(pos);
                currentBlock = pos;
                broken++;
                if (limit > 0 && broken >= limit)
                    break;
            }
            return;
        }
        if (blocks.isEmpty()) {
            if (currentBlock != null) {
                InteractionUtils.stopMining();
                currentBlock = null;
            }
            return;
        }
        BlockPos target = blocks.get(0);
        if (currentBlock != null && !currentBlock.equals(target)) {
            InteractionUtils.stopMining();
            currentBlock = null;
        }
        if (WorldUtils.getBlockHardness(target) < 0.0f) {
            return;
        }
        InteractionUtils.breakBlock(target, mc.player.getHorizontalFacing());
        currentBlock = target;
    }

    @Override
    public void onRender(RenderListener.RenderEvent event) {
        if (currentBlock == null || mc.player == null)
            return;
        float partialTicks = event.getPartialTicks();
        RenderUtils.updateCameraPos(partialTicks);
        RenderUtils.prepareGL();
        double x = currentBlock.getX() - RenderUtils.camX;
        double y = currentBlock.getY() - RenderUtils.camY;
        double z = currentBlock.getZ() - RenderUtils.camZ;
        net.minecraft.util.math.AxisAlignedBB box = new net.minecraft.util.math.AxisAlignedBB(x, y, z, x + 1, y + 1, z + 1);
        RenderUtils.drawSolidBox(box, 1.0f, 1.0f, 0.0f, 0.25f);
        RenderUtils.drawOutlinedBox(box, 1.0f, 1.0f, 0.0f, 0.5f);
        RenderUtils.restoreGL();
    }

    public void onLeftClick(BlockPos pos) {
        if (!isToggled())
            return;
        if (mode.getValue().equals("ID") && pos != null) {
            idBlock = WorldUtils.getBlock(pos);
            ChatUtils.message("Nuker ID set to: " + idBlock.getLocalizedName());
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        currentBlock = null;
        if (mc.playerController != null) {
            InteractionUtils.stopMining();
        }
    }
}
