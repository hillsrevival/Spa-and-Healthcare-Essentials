package client.module.impl.blocks;

import java.util.Random;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.utils.misc.ChatUtils;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class TemplateTool extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting template = new ModeSetting("Template", "Floor", "Floor", "Wall", "Roof", "Tower");

    private final Random random = new Random();

    public TemplateTool() {
        super("TemplateTool", Category.BLOCKS);
        setDescription("Places pre built block templates from a structure");
        addSetting(template);
        handles(HandlerType.RIGHT_CLICK);
    }

    @Override
    public void onRightClick(client.event.listeners.RightClickListener.RightClickEvent event) {
        if (!nullCheck())
            return;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held == null || held.func_190926_b() || !(held.getItem() instanceof ItemBlock))
            return;
        String tmpl = template.getValue();
        BlockPos base = new BlockPos(mc.player);
        int[][] offsets = getTemplateOffsets(tmpl);
        int placed = 0;
        for (int[] offset : offsets) {
            BlockPos pos = base.add(offset[0], offset[1], offset[2]);
            if (WorldUtils.getState(pos).getMaterial().isReplaceable()) {
                placeBlock(pos);
                placed++;
            }
        }
        if (placed > 0) {
            ChatUtils.message("Placed " + placed + " blocks (" + tmpl + ")");
        }
    }

    private int[][] getTemplateOffsets(String tmpl) {
        if (tmpl.equals("Floor")) {
            int[][] offsets = new int[25][];
            int idx = 0;
            for (int x = -2; x <= 2; x++) {
                for (int z = -2; z <= 2; z++) {
                    offsets[idx++] = new int[] { x, -1, z };
                }
            }
            return offsets;
        } else if (tmpl.equals("Wall")) {
            int[][] offsets = new int[15][];
            int idx = 0;
            EnumFacing facing = mc.player.getHorizontalFacing();
            for (int y = 0; y < 3; y++) {
                for (int side = -2; side <= 2; side++) {
                    BlockPos pos = new BlockPos(mc.player).add(0, y, 0).offset(facing, 2);
                    EnumFacing left = facing.rotateYCCW();
                    pos = pos.offset(left, side);
                    offsets[idx++] = new int[] { pos.x - (int) mc.player.posX, pos.y - (int) mc.player.posY, pos.z - (int) mc.player.posZ };
                }
            }
            return offsets;
        } else if (tmpl.equals("Roof")) {
            int[][] offsets = new int[25][];
            int idx = 0;
            for (int x = -2; x <= 2; x++) {
                for (int z = -2; z <= 2; z++) {
                    offsets[idx++] = new int[] { x, 3, z };
                }
            }
            return offsets;
        } else {
            int[][] offsets = new int[9][];
            int idx = 0;
            for (int x = -1; x <= 1; x++) {
                for (int z = -1; z <= 1; z++) {
                    offsets[idx++] = new int[] { x, 3, z };
                }
            }
            return offsets;
        }
    }

    private void placeBlock(BlockPos pos) {
        for (EnumFacing facing : EnumFacing.values()) {
            BlockPos neighbor = pos.offset(facing);
            if (WorldUtils.getState(neighbor).getMaterial().isReplaceable())
                continue;
            Vec3d hitVec = new Vec3d(neighbor.x + 0.5, neighbor.y + 0.5, neighbor.z + 0.5).add(new Vec3d(facing.getDirectionVec()).scale(-0.5));
            InteractionUtils.placeBlock(neighbor, facing.getOpposite(), hitVec, net.minecraft.util.EnumHand.MAIN_HAND);
            mc.player.swingArm(net.minecraft.util.EnumHand.MAIN_HAND);
            return;
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        ChatUtils.info("TemplateTool enabled - hold a block and right-click");
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }
}
