package client.module.impl.blocks;

import client.event.listeners.ShouldSideBeRenderedListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.ChatUtils;
import net.minecraft.client.Minecraft;

public class Liquids extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    public Liquids() {
        super("Liquids", Category.BLOCKS);
        setDescription("Place blocks inside water and lava");
        handles(HandlerType.SHOULD_SIDE_BE_RENDERED);
    }

    @Override
    public void onShouldSideBeRendered(ShouldSideBeRenderedListener.ShouldSideBeRenderedEvent event) {
        if (!nullCheck())
            return;
        if (event.getState().getMaterial().isLiquid()) {
            event.setRendered(true);
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        ChatUtils.message("Liquids enabled - you can now interact with liquid blocks");
    }

    @Override
    public void onDisable() {
        ChatUtils.message("Liquids disabled");
        super.onDisable();
    }
}
