package client.module.impl.blocks;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.misc.ChatUtils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockGrass;
import net.minecraft.block.IGrowable;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class BonemealAura extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 4.25, 1.0, 6.0);

    private final NumberSetting delay = new NumberSetting("Delay", 2.0, 0.0, 10.0);

    private int tickCounter = 0;

    public BonemealAura() {
        super("BonemealAura", Category.BLOCKS);
        setDescription("Automatically bonemeals crops and saplings in range");
        addSetting(range);
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.rightClickDelayTimer > 0)
            return;
        if (delay.getValue() > 0) {
            tickCounter++;
            if (tickCounter < delay.getValue().intValue())
                return;
            tickCounter = 0;
        }
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held == null || held.func_190926_b())
            return;
        if (held.getItem() != Items.DYE || held.getMetadata() != 15)
            return;
        double rangeVal = range.getValue();
        BlockPos playerPos = new BlockPos(mc.player);
        int blockRange = (int) Math.ceil(rangeVal);
        for (BlockPos pos : BlockPos.getAllInBox(playerPos.add(blockRange, blockRange, blockRange), playerPos.add(-blockRange, -blockRange, -blockRange))) {
            if (WorldUtils.isAir(pos))
                continue;
            double dist = mc.player.getDistanceSq(pos.x + 0.5, pos.y + 0.5, pos.z + 0.5);
            if (dist > rangeVal * rangeVal)
                continue;
            Block block = WorldUtils.getBlock(pos);
            if (!(block instanceof IGrowable))
                continue;
            if (block instanceof BlockGrass)
                continue;
            IGrowable growable = (IGrowable) block;
            if (!growable.canGrow(mc.world, pos, WorldUtils.getState(pos), false))
                continue;
            EnumFacing facing = EnumFacing.UP;
            Vec3d hitVec = new Vec3d(pos.x + 0.5, pos.y + 0.5, pos.z + 0.5);
            InteractionUtils.placeBlock(pos, facing, hitVec, EnumHand.MAIN_HAND);
            mc.player.swingArm(EnumHand.MAIN_HAND);
            break;
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        ChatUtils.info("BonemealAura enabled - hold bonemeal to auto-use it");
        tickCounter = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        tickCounter = 0;
    }
}
