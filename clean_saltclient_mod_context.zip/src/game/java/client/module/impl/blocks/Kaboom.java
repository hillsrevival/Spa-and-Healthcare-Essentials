package client.module.impl.blocks;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.misc.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class Kaboom extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting power = new NumberSetting("Power", 128.0, 32.0, 512.0);

    private final BooleanSetting persistent = new BooleanSetting("Persistent", false);

    private final NumberSetting range = new NumberSetting("Range", 4.0, 1.0, 6.0);

    private int tickCounter = 0;

    public Kaboom() {
        super("Kaboom", Category.BLOCKS);
        setDescription("Places and lights tnt to damage entities nearby");
        addSetting(power);
        addSetting(persistent);
        addSetting(range);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null || mc.world == null) {
            toggle();
            return;
        }
        if (!mc.player.capabilities.isCreativeMode && !mc.player.onGround) {
            ChatUtils.error("Stand on the ground first!");
            toggle();
            return;
        }
        if (persistent.getValue()) {
            ChatUtils.info("Kaboom persistent mode - breaking blocks one at a time");
            return;
        }
        ChatUtils.info("KABOOM!");
        int range = 6;
        BlockPos playerPos = new BlockPos(mc.player);
        for (int x = range; x >= -range; x--) {
            for (int y = range; y >= -range; y--) {
                for (int z = range; z >= -range; z--) {
                    BlockPos pos = playerPos.add(x, y, z);
                    if (WorldUtils.isAir(pos))
                        continue;
                    double dist = mc.player.getDistanceSq(pos.x + 0.5, pos.y + 0.5, pos.z + 0.5);
                    if (dist > range * range)
                        continue;
                    if (mc.player.capabilities.isCreativeMode) {
                        InteractionUtils.breakBlock(pos);
                    } else {
                        InteractionUtils.breakBlock(pos, EnumFacing.UP);
                    }
                }
            }
        }
        InteractionUtils.stopMining();
        toggle();
    }

    @Override
    public void onUpdate() {
        if (!persistent.getValue())
            return;
        if (!nullCheck())
            return;
        tickCounter++;
        if (!mc.player.capabilities.isCreativeMode && tickCounter % 2 != 0)
            return;
        double rangeVal = range.getValue();
        BlockPos playerPos = new BlockPos(mc.player);
        int blockRange = (int) Math.ceil(rangeVal);
        BlockPos bestPos = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos pos : BlockPos.getAllInBox(playerPos.add(blockRange, blockRange, blockRange), playerPos.add(-blockRange, -blockRange, -blockRange))) {
            if (WorldUtils.isAir(pos))
                continue;
            if (pos.equals(new BlockPos(mc.player)))
                continue;
            double dist = Math.sqrt(mc.player.getDistanceSq(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5));
            if (dist > rangeVal)
                continue;
            if (dist > bestDist)
                continue;
            bestDist = dist;
            bestPos = pos;
        }
        if (bestPos == null) {
            ChatUtils.info("Kaboom done - no more blocks in range");
            toggle();
            return;
        }
        if (mc.player.capabilities.isCreativeMode) {
            InteractionUtils.breakBlock(bestPos);
        } else {
            InteractionUtils.breakBlock(bestPos, EnumFacing.UP);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.playerController != null) {
            InteractionUtils.stopMining();
        }
        tickCounter = 0;
    }
}
