package client.module.impl.blocks;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.misc.NotificationSystem;
import client.utils.misc.TickTimer;
import client.utils.player.InvUtils;
import client.utils.player.SlotUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class SpawnProofer extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 5.0, 1.0, 10.0);

    private final NumberSetting delay = new NumberSetting("Delay", 5.0, 1.0, 20.0);

    private final TickTimer tickTimer = new TickTimer();

    public SpawnProofer() {
        super("SpawnProofer", Category.BLOCKS);
        setDescription("Places torches to prevent mob spawns");
        addSetting(range);
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!tickTimer.passedAndReset(delay.getValue().intValue()))
            return;
        int torchSlot = InvUtils.findInHotbar(stack -> stack != null && !stack.func_190926_b() && stack.getItem() == net.minecraft.item.Item.getItemFromBlock(net.minecraft.init.Blocks.TORCH)).slot() - SlotUtils.HOTBAR_START;
        if (torchSlot == -1)
            return;
        int r = range.getValue().intValue();
        int px = (int) Math.floor(mc.player.posX);
        int py = (int) Math.floor(mc.player.posY);
        int pz = (int) Math.floor(mc.player.posZ);
        for (int x = -r; x <= r; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -r; z <= r; z++) {
                    BlockPos pos = new BlockPos(px + x, py + y, pz + z);
                    if (!isValidTorchSpot(pos))
                        continue;
                    if (mc.world.getLight(pos, false) > 7)
                        continue;
                    int savedSlot = mc.player.inventory.currentItem;
                    mc.player.inventory.currentItem = torchSlot;
                    BlockPos below = pos.down();
                    if (!mc.world.isAirBlock(below)) {
                        mc.playerController.processRightClickBlock(mc.player, mc.world, below, EnumFacing.UP, new net.minecraft.util.math.Vec3d(below.x + 0.5, below.y + 1.0, below.z + 0.5), EnumHand.MAIN_HAND);
                        mc.player.swingArm(EnumHand.MAIN_HAND);
                    }
                    mc.player.inventory.currentItem = savedSlot;
                    return;
                }
            }
        }
    }

    private boolean isValidTorchSpot(BlockPos pos) {
        if (mc.world == null)
            return false;
        if (!mc.world.isAirBlock(pos))
            return false;
        BlockPos below = pos.down();
        if (mc.world.isAirBlock(below))
            return false;
        return mc.world.getBlockState(below).isFullBlock();
    }
}
