package client.module.impl.blocks;

import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.ModeSetting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Enchantments;
import net.minecraft.block.state.IBlockState;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class FastBreak extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting speed = new NumberSetting("Speed", 1.5, 1.0, 5.0);

    private final ModeSetting mode = new ModeSetting("Mode", "EnchantCap", "Vanilla", "EnchantCap");

    public FastBreak() {
        super("FastBreak", Category.BLOCKS);
        setDescription("Breaks blocks faster");
        addSetting(speed);
        addSetting(mode);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!mc.gameSettings.keyBindAttack.isKeyDown())
            return;
        if (mc.objectMouseOver == null || mc.objectMouseOver.getBlockPos() == null)
            return;
        BlockPos pos = mc.objectMouseOver.getBlockPos();
        if (WorldUtils.isAir(pos))
            return;
        float speedMult;
        if (mode.getValue().equals("EnchantCap")) {
            ItemStack held = mc.player.getHeldItemMainhand();
            int currentEff = 0;
            if (held != null && !held.func_190926_b()) {
                currentEff = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, held);
            }
            int simEff = currentEff + 2;
            float maxSpeed = 1.0f + (simEff * simEff + 1) * 0.1f;
            speedMult = Math.min(speed.getValue().floatValue(), maxSpeed);
        } else {
            speedMult = speed.getValue().floatValue();
        }
        mc.playerController.curBlockDamageMP += speedMult * 0.1f;
        if (mc.playerController.curBlockDamageMP >= 1.0f) {
            InteractionUtils.breakBlock(pos);
            mc.player.swingArm(net.minecraft.util.EnumHand.MAIN_HAND);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.playerController != null) {
            InteractionUtils.stopMining();
        }
    }
}
