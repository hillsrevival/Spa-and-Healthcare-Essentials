package client.module.impl.blocks;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import client.utils.player.InvUtils;
import client.utils.player.SlotUtils;
import client.utils.world.BlockUtils;
import client.utils.world.InteractionUtils;
import client.utils.world.WorldUtils;

public class LiquidFill extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting range = new NumberSetting("Range", 4.0, 2.0, 6.0);

    public LiquidFill() {
        super("LiquidFill", Category.BLOCKS);
        setDescription("Automatically fills in liquids like water or lava with blocks");
        addSetting(range);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        int blockSlot = InvUtils.findInHotbar(stack -> stack != null && !stack.func_190926_b() && stack.getItem() instanceof ItemBlock).slot() - SlotUtils.HOTBAR_START;
        if (blockSlot == -1)
            return;
        int savedSlot = mc.player.inventory.currentItem;
        double rangeD = range.getValue();
        for (int x = -4; x <= 4; x++) {
            for (int y = -2; y <= 0; y++) {
                for (int z = -4; z <= 4; z++) {
                    BlockPos pos = new BlockPos((int) Math.floor(mc.player.posX) + x, (int) Math.floor(mc.player.posY) + y, (int) Math.floor(mc.player.posZ) + z);
                    if (mc.player.getDistance(pos.x + 0.5, pos.y + 0.5, pos.z + 0.5) > rangeD)
                        continue;
                    if (!isLiquid(pos))
                        continue;
                    BlockPos placePos = pos.up();
                    if (WorldUtils.isAir(placePos)) {
                        mc.player.inventory.currentItem = blockSlot;
                        EnumFacing dir = BlockUtils.findPlaceableSide(placePos);
                        if (dir != null) {
                            BlockPos neighbor = placePos.offset(dir);
                            InteractionUtils.placeBlock(neighbor, dir.getOpposite(), BlockUtils.faceCenter(neighbor, dir.getOpposite()), EnumHand.MAIN_HAND);
                        }
                    }
                }
            }
        }
        mc.player.inventory.currentItem = savedSlot;
    }

    private boolean isLiquid(BlockPos pos) {
        return WorldUtils.getBlock(pos) == Blocks.WATER || WorldUtils.getBlock(pos) == Blocks.FLOWING_WATER || WorldUtils.getBlock(pos) == Blocks.LAVA || WorldUtils.getBlock(pos) == Blocks.FLOWING_LAVA;
    }
}
