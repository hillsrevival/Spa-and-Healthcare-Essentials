package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.utils.world.WorldUtils;

public class AutoJump extends Module {

    private final BooleanSetting edges = new BooleanSetting("Edges", true);

    private final BooleanSetting blocks = new BooleanSetting("Blocks", true);

    public AutoJump() {
        super("AutoJump", Category.MOVEMENT);
        setDescription("Automatically jumps for you");
        addSetting(edges);
        addSetting(blocks);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (mc.player.isSneaking() || mc.player.isElytraFlying())
            return;
        if (!mc.player.onGround || mc.player.isInWater() || mc.player.isInLava())
            return;
        if (blocks.getValue()) {
            double px = mc.player.posX;
            double py = mc.player.posY;
            double pz = mc.player.posZ;
            float yaw = mc.player.rotationYaw;
            double moveX = -Math.sin(Math.toRadians(yaw)) * 0.6;
            double moveZ = Math.cos(Math.toRadians(yaw)) * 0.6;
            int checkX = (int) Math.floor(px + moveX);
            int checkZ = (int) Math.floor(pz + moveZ);
            for (int dy = 0; dy <= 1; dy++) {
                if (!WorldUtils.isAir(new net.minecraft.util.math.BlockPos(checkX, (int) Math.floor(py) + dy, checkZ))) {
                    mc.player.jump();
                    return;
                }
            }
        }
        if (edges.getValue()) {
            double px = mc.player.posX;
            double pz = mc.player.posZ;
            float yaw = mc.player.rotationYaw;
            double moveX = -Math.sin(Math.toRadians(yaw)) * 0.3;
            double moveZ = Math.cos(Math.toRadians(yaw)) * 0.3;
            int checkX = (int) Math.floor(px + moveX);
            int checkZ = (int) Math.floor(pz + moveZ);
            int checkY = (int) Math.floor(mc.player.posY) - 1;
            if (WorldUtils.isAir(new net.minecraft.util.math.BlockPos(checkX, checkY, checkZ))) {
                mc.player.jump();
            }
        }
    }
}
