package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;

public class Strafe extends Module {

    public Strafe() {
        super("Strafe", Category.MOVEMENT);
        setDescription("Strafes");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (mc.player.onGround)
            return;
        float speed = 0.02f;
        float yaw = mc.player.rotationYaw * 0.017453292f;
        float forward = mc.player.movementInput.field_192832_b;
        float strafe = mc.player.movementInput.moveStrafe;
        if (forward != 0.0f || strafe != 0.0f) {
            mc.player.motionX += (-Math.sin(yaw) * forward + Math.cos(yaw) * strafe) * speed;
            mc.player.motionZ += (Math.cos(yaw) * forward + Math.sin(yaw) * strafe) * speed;
        }
    }
}
