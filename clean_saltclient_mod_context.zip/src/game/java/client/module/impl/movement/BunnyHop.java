package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;
import client.module.NumberSetting;
import java.util.Random;

public class BunnyHop extends Module {

    private final Random rand = new Random();

    private final ModeSetting jumpIf = new ModeSetting("JumpIf", "Moving", "Sprinting", "Always");

    private final NumberSetting delay = new NumberSetting("Delay", 0.0, 0.0, 5.0);

    private int tickCounter = 0;

    public BunnyHop() {
        super("BunnyHop", Category.MOVEMENT);
        setDescription("Automatically jumps while moving to bunnyhop");
        addSetting(jumpIf);
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!mc.player.onGround || mc.player.isSneaking())
            return;
        if (mc.player.isInWater() || mc.player.isInLava())
            return;
        String mode = jumpIf.getValue();
        boolean isMoving = mc.player.moveForward != 0 || mc.player.moveStrafing != 0;
        boolean shouldJump = false;
        switch(mode) {
            case "Moving":
                shouldJump = isMoving;
                break;
            case "Sprinting":
                shouldJump = isMoving && mc.player.isSprinting();
                break;
            case "Always":
                shouldJump = true;
                break;
        }
        if (!shouldJump)
            return;
        double delayVal = delay.getValue();
        if (delayVal > 0) {
            tickCounter++;
            int threshold = rand.nextInt((int) delayVal + 1);
            if (tickCounter <= threshold)
                return;
            tickCounter = 0;
        }
        mc.player.jump();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        tickCounter = 0;
    }
}
