package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;

public class Snap extends Module {

    public Snap() {
        super("Snap", Category.MOVEMENT);
        setDescription("Snap");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        float forward = mc.player.movementInput.field_192832_b;
        float strafe = mc.player.movementInput.moveStrafe;
        if (forward == 0.0f && strafe == 0.0f)
            return;
        float yaw = mc.player.rotationYaw;
        float moveYaw = yaw;
        if (forward > 0.0f) {
            if (strafe > 0.0f)
                moveYaw -= 45;
            else if (strafe < 0.0f)
                moveYaw += 45;
        } else if (forward < 0.0f) {
            moveYaw += 180;
            if (strafe > 0.0f)
                moveYaw += 45;
            else if (strafe < 0.0f)
                moveYaw -= 45;
        } else {
            if (strafe > 0.0f)
                moveYaw -= 90;
            else if (strafe < 0.0f)
                moveYaw += 90;
        }
        mc.player.rotationYaw = net.minecraft.util.math.MathHelper.wrapDegrees(moveYaw);
    }
}
