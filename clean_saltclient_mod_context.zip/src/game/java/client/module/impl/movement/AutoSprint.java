package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.combat.SprintPolicy;

public class AutoSprint extends Module {

    public AutoSprint() {
        super("AutoSprint", Category.MOVEMENT);
        setDescription("Automatically sprints when moving forward");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (SprintPolicy.shouldMaintainSprint()) {
            client.utils.movement.MovementUtils.setSprinting(true);
        }
    }
}
