package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class Jetpack extends Module {

    private final NumberSetting speed = new NumberSetting("Speed", 1.0, 0.1, 5.0);

    public Jetpack() {
        super("Jetpack", Category.MOVEMENT);
        setDescription("Launches you upward when you jump");
        addSetting(speed);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.player.rotationPitch < -30.0f || mc.gameSettings.keyBindJump.isKeyDown()) {
            mc.player.motionY = speed.getValue() * 0.5;
            mc.player.fallDistance = 0;
        }
    }
}
