package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntityDonkey;
import net.minecraft.util.EnumHand;
import client.utils.EntityUtils;

public class AutoMount extends Module {

    private final NumberSetting range = new NumberSetting("Range", 4.0, 2.0, 6.0);

    public AutoMount() {
        super("AutoMount", Category.MOVEMENT);
        setDescription("Automatically mounts the nearest rideable entity");
        addSetting(range);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.player.isRiding())
            return;
        double rangeD = range.getValue().doubleValue();
        for (Object obj : EntityUtils.getLoadedEntities()) {
            if (obj == mc.player)
                continue;
            boolean isMountable = false;
            if (obj instanceof EntityHorse)
                isMountable = true;
            if (obj instanceof EntityPig)
                isMountable = true;
            if (obj instanceof EntityDonkey)
                isMountable = true;
            if (!isMountable)
                continue;
            Entity entity = (Entity) obj;
            if (mc.player.getDistanceToEntity(entity) > rangeD)
                continue;
            mc.playerController.interactWithEntity(mc.player, entity, EnumHand.MAIN_HAND);
            return;
        }
    }
}
