package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;

public class AutoSwim extends Module {

    public AutoSwim() {
        super("AutoSwim", Category.MOVEMENT);
        setDescription("Automatically swims to the surface when in water");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.player.isInWater()) {
            if (mc.player.rotationPitch < -10.0f) {
                mc.player.jump();
            } else if (mc.player.posY % 1.0 > 0.6 && mc.player.getRidingEntity() == null) {
                mc.player.jump();
            }
        }
    }
}
