package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class LongJump extends Module {

    private final NumberSetting boost = new NumberSetting("Boost", 2.5, 1.0, 5.0);

    private boolean wasOnGround = false;

    public LongJump() {
        super("LongJump", Category.MOVEMENT);
        setDescription("Jump farther");
        addSetting(boost);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        boolean onGround = mc.player.onGround;
        if (wasOnGround && !onGround && mc.player.motionY > 0) {
            float yaw = mc.player.rotationYaw;
            double yawRad = Math.toRadians(yaw);
            double dirX = -Math.sin(yawRad);
            double dirZ = Math.cos(yawRad);
            double boostVal = boost.getValue();
            mc.player.motionX += dirX * boostVal * 0.2;
            mc.player.motionZ += dirZ * boostVal * 0.2;
        }
        wasOnGround = onGround;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        wasOnGround = false;
    }
}
