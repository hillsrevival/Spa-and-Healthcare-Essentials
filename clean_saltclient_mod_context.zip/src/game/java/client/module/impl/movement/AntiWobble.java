package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;

public class AntiWobble extends Module {

    public AntiWobble() {
        super("AntiWobble", Category.MOVEMENT);
        setDescription("Smooths out the screen wobble effect when walking on soulsand");
        handles(HandlerType.RENDER);
    }

    @Override
    public void onRender(client.event.listeners.RenderListener.RenderEvent event) {
        if (mc.player == null)
            return;
        mc.player.hurtTime = 0;
    }
}
