package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.utils.world.PacketUtils;

public class FlyLegit extends Module {

    private final NumberSetting speed = new NumberSetting("Speed", 0.5, 0.1, 2.0);

    private final BooleanSetting antiKick = new BooleanSetting("AntiKick", true);

    private final NumberSetting verticalSpeed = new NumberSetting("Vertical", 0.3, 0.0, 1.0);

    private int tickCounter = 0;

    public FlyLegit() {
        super("FlyLegit", Category.MOVEMENT);
        setDescription("Tries to fly more legitly");
        addSetting(speed);
        addSetting(antiKick);
        addSetting(verticalSpeed);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        tickCounter++;
        float forward = mc.player.movementInput.field_192832_b;
        float strafe = mc.player.movementInput.moveStrafe;
        float flySpeed = (float) (double) speed.getValue() * 0.1f;
        float vSpeed = (float) (double) verticalSpeed.getValue() * 0.1f;
        if (forward != 0 || strafe != 0) {
            float yaw = mc.player.rotationYaw;
            float rad = (float) Math.toRadians(yaw);
            mc.player.motionX += (-Math.sin(rad) * forward + Math.cos(rad) * strafe) * flySpeed;
            mc.player.motionZ += (Math.cos(rad) * forward + Math.sin(rad) * strafe) * flySpeed;
        }
        if (mc.gameSettings.keyBindJump.isKeyDown()) {
            mc.player.motionY = vSpeed;
        } else if (mc.gameSettings.keyBindSneak.isKeyDown()) {
            mc.player.motionY = -vSpeed;
        } else {
            mc.player.motionY = 0;
        }
        if (antiKick.getValue() && tickCounter % 20 == 0) {
            if (mc.player.connection != null) {
                PacketUtils.sendGround(true);
            }
        }
        double hSpeed = Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ);
        double maxHSpeed = 0.5;
        if (hSpeed > maxHSpeed) {
            mc.player.motionX = mc.player.motionX / hSpeed * maxHSpeed;
            mc.player.motionZ = mc.player.motionZ / hSpeed * maxHSpeed;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        tickCounter = 0;
    }
}
