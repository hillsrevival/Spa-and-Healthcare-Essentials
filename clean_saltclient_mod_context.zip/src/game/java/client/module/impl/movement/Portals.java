package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;

public class Portals extends Module {

    private final BooleanSetting noNausea = new BooleanSetting("NoNausea", true);

    public Portals() {
        super("Portals", Category.MOVEMENT);
        setDescription("Portals");
        addSetting(noNausea);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (noNausea.getValue()) {
            mc.player.timeInPortal = 0.0f;
            mc.player.prevTimeInPortal = 0.0f;
        }
    }
}
