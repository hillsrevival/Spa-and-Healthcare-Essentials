package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.EnumHand;
import client.utils.world.PacketUtils;
import client.utils.world.InteractionUtils;

public class AutoElytraFly extends Module {

    private final NumberSetting minSpeed = new NumberSetting("Min Speed", 0.4, 0.1, 1.5);

    private final BooleanSetting autoDeploy = new BooleanSetting("Auto Deploy", true);

    private final BooleanSetting switchBack = new BooleanSetting("Switch Back", true);

    private final NumberSetting delay = new NumberSetting("Delay (ticks)", 10, 2, 40);

    private int useTimer = 0;

    public AutoElytraFly() {
        super("AutoElytraFly", Category.MOVEMENT);
        setDescription("Automatically uses fireworks to stay in flight when using elytra");
        addSetting(minSpeed);
        addSetting(autoDeploy);
        addSetting(switchBack);
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        useTimer = 0;
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (ElytraFollow.shouldHoldAutoDeploy()) {
            useTimer = Math.max(useTimer, 1);
            return;
        }
        ItemStack chest = mc.player.getItemStackFromSlot(EntityEquipmentSlot.CHEST);
        if (autoDeploy.getValue() && !mc.player.onGround && !mc.player.isElytraFlying() && !mc.player.capabilities.isFlying && mc.player.motionY < 0.0D) {
            if (chest.getItem() == Items.ELYTRA && ItemElytra.isBroken(chest)) {
                PacketUtils.sendEntityAction(mc.player, CPacketEntityAction.Action.START_FALL_FLYING);
                return;
            }
        }
        if (!mc.player.isElytraFlying()) {
            useTimer = 0;
            return;
        }
        if (useTimer > 0) {
            useTimer--;
            return;
        }
        double currentSpeed = Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ);
        if (currentSpeed < minSpeed.getValue()) {
            int fireworkSlot = findFirework();
            if (fireworkSlot < 0)
                return;
            int prevSlot = mc.player.inventory.currentItem;
            mc.player.inventory.currentItem = fireworkSlot;
            InteractionUtils.useItem(EnumHand.MAIN_HAND);
            if (switchBack.getValue()) {
                mc.player.inventory.currentItem = prevSlot;
            }
            useTimer = delay.getValue().intValue();
        }
    }

    private int findFirework() {
        client.utils.player.FindItemResult r = client.utils.player.InvUtils.findInHotbar(Items.FIREWORKS);
        return r.found() ? r.slot() - client.utils.player.SlotUtils.HOTBAR_START : -1;
    }
}
