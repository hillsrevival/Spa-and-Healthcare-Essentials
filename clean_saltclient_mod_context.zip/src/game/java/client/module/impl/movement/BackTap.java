package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.combat.CombatContext;
import client.utils.movement.MovementInputHelper;
import client.utils.movement.MovementUtils;
import net.minecraft.entity.EntityLivingBase;

public class BackTap extends Module {

    private final client.utils.movement.MovementKeySnapshot keySnapshot = new client.utils.movement.MovementKeySnapshot();

    private final NumberSetting tapDuration = new NumberSetting("Tap Duration", 3.0, 1.0, 5.0);

    private final BooleanSetting landingRetap = new BooleanSetting("Landing Re-Tap", true);

    private final NumberSetting landingTapDuration = new NumberSetting("Landing Tap Duration", 6.0, 1.0, 6.0);

    private final BooleanSetting onlyWhenMoving = new BooleanSetting("Only When Moving", false);

    private final BooleanSetting preserveUserInput = new BooleanSetting("Preserve User Input", true);

    private final NumberSetting minKnockbackMagnitude = new NumberSetting("Min KB Magnitude", 0.2, 0.0, 1.0);

    private int tapTicksRemaining = 0;

    private boolean inTapPhase = false;

    private boolean wasOnGround = true;

    private int landingWindowTicks = 0;

    public BackTap() {
        super("BackTap", Category.MOVEMENT);
        setDescription("Cancels knockback with attacker-directed taps on hit and landing");
        addSetting(tapDuration);
        addSetting(landingRetap);
        addSetting(landingTapDuration);
        addSetting(onlyWhenMoving);
        addSetting(preserveUserInput);
        addSetting(minKnockbackMagnitude);
        handles(HandlerType.TICK);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            wasOnGround = true;
            landingWindowTicks = 0;
            return;
        }
        if (mc.player.hurtTime > 0 && mc.player.hurtTime == mc.player.maxHurtTime && shouldBackTap(false)) {
            if (!inTapPhase) {
                startTapPhase((int) (double) tapDuration.getValue());
            } else {
                tapTicksRemaining = (int) (double) tapDuration.getValue();
            }
            landingWindowTicks = 25;
        }
        boolean justLanded = mc.player.onGround && !wasOnGround;
        if (landingWindowTicks > 0) {
            landingWindowTicks--;
            if (justLanded) {
                if (landingRetap.getValue() && !inTapPhase && shouldBackTap(true)) {
                    startTapPhase((int) (double) landingTapDuration.getValue());
                }
                landingWindowTicks = 0;
            }
        }
        wasOnGround = mc.player.onGround;
        if (inTapPhase) {
            tapTicksRemaining--;
            if (tapTicksRemaining <= 0) {
                endTapPhase();
            }
        }
    }

    private boolean shouldBackTap(boolean landingPhase) {
        if (mc.player == null)
            return false;
        long ticksSinceAttack = CombatContext.getTicksSinceMyAttack();
        long ticksSinceOpponentSwing = CombatContext.getTicksSinceOpponentSwing();
        if (ticksSinceAttack > 60 && ticksSinceOpponentSwing > 60) {
            return false;
        }
        if (landingPhase)
            return true;
        if (onlyWhenMoving.getValue() && !MovementUtils.isMoving()) {
            return false;
        }
        double horizontalSpeed = MovementUtils.getHorizontalSpeed();
        double minMag = minKnockbackMagnitude.getValue();
        if (horizontalSpeed < minMag && ticksSinceAttack > 5) {
            return false;
        }
        return true;
    }

    private EntityLivingBase resolveAttacker() {
        if (mc.player == null)
            return null;
        EntityLivingBase attacker = mc.player.getAttackingEntity();
        if (attacker == null) {
            attacker = mc.player.getLastAttacker();
        }
        if (attacker != null && attacker.isEntityAlive()) {
            return attacker;
        }
        return null;
    }

    private void startTapPhase(int duration) {
        if (mc.player == null)
            return;
        inTapPhase = true;
        tapTicksRemaining = duration;
        saveUserKeys();
        EntityLivingBase attacker = resolveAttacker();
        if (attacker != null) {
            MovementInputHelper.applyDirectionalMovement(attacker.posX - mc.player.posX, attacker.posZ - mc.player.posZ);
        } else {
            MovementUtils.holdForward(true);
        }
    }

    private void endTapPhase() {
        if (mc.player == null)
            return;
        if (preserveUserInput.getValue()) {
            keySnapshot.restore();
        } else {
            MovementUtils.holdForward(false);
            MovementUtils.holdBack(false);
            MovementUtils.holdLeft(false);
            MovementUtils.holdRight(false);
        }
        inTapPhase = false;
        tapTicksRemaining = 0;
    }

    private void saveUserKeys() {
        keySnapshot.save();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        inTapPhase = false;
        tapTicksRemaining = 0;
        wasOnGround = true;
        landingWindowTicks = 0;
        keySnapshot.clearForward();
        keySnapshot.clearBack();
        keySnapshot.clearLeft();
        keySnapshot.clearRight();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (inTapPhase && mc.player != null) {
            if (preserveUserInput.getValue()) {
                keySnapshot.restore();
            } else {
                MovementUtils.holdForward(false);
                MovementUtils.holdBack(false);
                MovementUtils.holdLeft(false);
                MovementUtils.holdRight(false);
            }
        }
        inTapPhase = false;
        tapTicksRemaining = 0;
        landingWindowTicks = 0;
    }
}
