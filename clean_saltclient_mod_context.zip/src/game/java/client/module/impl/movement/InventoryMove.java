package client.module.impl.movement;

import net.lax1dude.eaglercraft.Keyboard;
import net.minecraft.util.MovementInput;
import net.minecraft.client.gui.inventory.GuiContainer;
import client.module.Category;
import client.module.Module;

public class InventoryMove extends Module {

    private MovementInput originalInput;

    public InventoryMove() {
        super("InventoryMove", Category.MOVEMENT);
        setDescription("Move around while your inventory is open");
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null)
            return;
        originalInput = mc.player.movementInput;
        mc.player.movementInput = new MovementInput() {

            @Override
            public void updatePlayerMoveState() {
                if (mc.currentScreen != null && !(mc.currentScreen instanceof GuiContainer)) {
                    this.moveStrafe = 0.0F;
                    this.field_192832_b = 0.0F;
                    this.forwardKeyDown = false;
                    this.backKeyDown = false;
                    this.leftKeyDown = false;
                    this.rightKeyDown = false;
                    this.jump = false;
                    this.sneak = false;
                    return;
                }
                this.moveStrafe = 0.0F;
                this.field_192832_b = 0.0F;
                if (Keyboard.isKeyDown(mc.gameSettings.keyBindForward.getKeyCode())) {
                    ++this.field_192832_b;
                    this.forwardKeyDown = true;
                } else {
                    this.forwardKeyDown = false;
                }
                if (Keyboard.isKeyDown(mc.gameSettings.keyBindBack.getKeyCode())) {
                    --this.field_192832_b;
                    this.backKeyDown = true;
                } else {
                    this.backKeyDown = false;
                }
                if (Keyboard.isKeyDown(mc.gameSettings.keyBindLeft.getKeyCode())) {
                    ++this.moveStrafe;
                    this.leftKeyDown = true;
                } else {
                    this.leftKeyDown = false;
                }
                if (Keyboard.isKeyDown(mc.gameSettings.keyBindRight.getKeyCode())) {
                    --this.moveStrafe;
                    this.rightKeyDown = true;
                } else {
                    this.rightKeyDown = false;
                }
                this.jump = Keyboard.isKeyDown(mc.gameSettings.keyBindJump.getKeyCode());
                this.sneak = Keyboard.isKeyDown(mc.gameSettings.keyBindSneak.getKeyCode());
                if (this.sneak) {
                    this.moveStrafe = (float) ((double) this.moveStrafe * 0.3D);
                    this.field_192832_b = (float) ((double) this.field_192832_b * 0.3D);
                }
            }
        };
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.player != null && originalInput != null) {
            mc.player.movementInput = originalInput;
            originalInput = null;
        }
    }
}
