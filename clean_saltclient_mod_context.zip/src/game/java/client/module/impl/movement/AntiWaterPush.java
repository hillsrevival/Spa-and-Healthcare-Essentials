package client.module.impl.movement;

import client.event.CancellableEvent;
import client.event.events.PacketInputEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.network.play.server.SPacketEntityVelocity;

public class AntiWaterPush extends Module {

    public AntiWaterPush() {
        super("AntiWaterPush", Category.MOVEMENT);
        setDescription("Prevents water flow from pushing you around");
        handles(HandlerType.PACKET_INPUT);
    }

    @Override
    public void onPacketInput(PacketInputEvent event) {
        if (mc.player == null)
            return;
        if (event.getPacket() instanceof SPacketEntityVelocity) {
            SPacketEntityVelocity packet = (SPacketEntityVelocity) event.getPacket();
            if (packet.getEntityID() == mc.player.getEntityId()) {
                if (mc.player.isInWater()) {
                    event.setCancelled(true);
                }
            }
        }
    }
}
