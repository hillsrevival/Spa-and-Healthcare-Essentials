package client.module.impl.movement;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.movement.RotationUtils;
import client.utils.EntityUtils;

public class Follow extends Module {

    private final NumberSetting range = new NumberSetting("Range", 10.0, 1.0, 50.0);

    private final NumberSetting distance = new NumberSetting("Distance", 2.0, 1.0, 6.0);

    public Follow() {
        super("Follow", Category.MOVEMENT);
        setDescription("Automatically follows the closest player");
        addSetting(range);
        addSetting(distance);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        EntityPlayer target = null;
        double closest = range.getValue();
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (!(entity instanceof EntityPlayer))
                continue;
            if (entity == mc.player)
                continue;
            double dist = mc.player.getDistanceToEntity(entity);
            if (dist < closest) {
                closest = dist;
                target = (EntityPlayer) entity;
            }
        }
        if (target == null)
            return;
        RotationUtils.faceVectorForWalking(new Vec3d(target.posX, target.posY, target.posZ));
        if (closest > distance.getValue()) {
            mc.player.movementInput.forwardKeyDown = true;
            mc.player.movementInput.field_192832_b = 1.0F;
        } else {
            mc.player.movementInput.forwardKeyDown = false;
            mc.player.movementInput.field_192832_b = 0.0F;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.player == null)
            return;
        mc.player.movementInput.forwardKeyDown = false;
        mc.player.movementInput.field_192832_b = 0.0F;
    }
}
