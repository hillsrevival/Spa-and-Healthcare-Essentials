package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import client.utils.misc.ChatUtils;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.MathHelper;

public class ElytraBoost extends Module {

    private final BooleanSetting antiConsume = new BooleanSetting("AntiConsume", true);

    private final NumberSetting boostStrength = new NumberSetting("BoostStrength", 1.0, 0.1, 3.0);

    private final BooleanSetting playSound = new BooleanSetting("PlaySound", true);

    private final BooleanSetting requireFirework = new BooleanSetting("RequireFirework", false);

    private boolean wasJumpDown = false;

    public ElytraBoost() {
        super("ElytraBoost", Category.MOVEMENT);
        setDescription("Boosts your elytra without consuming fireworks");
        addSetting(antiConsume);
        addSetting(boostStrength);
        addSetting(playSound);
        addSetting(requireFirework);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!mc.player.isElytraFlying()) {
            wasJumpDown = false;
            return;
        }
        boolean jumpDown = mc.gameSettings.keyBindJump.isKeyDown();
        if (jumpDown && !wasJumpDown) {
            if (requireFirework.getValue()) {
                if (!hasFirework()) {
                    wasJumpDown = jumpDown;
                    return;
                }
            }
            if (antiConsume.getValue()) {
                applyBoost();
            } else {
                int slot = findFireworkSlot();
                if (slot != -1) {
                    int saved = mc.player.inventory.currentItem;
                    mc.player.inventory.currentItem = slot;
                    mc.player.connection.sendPacket(new net.minecraft.network.play.client.CPacketHeldItemChange(slot));
                    mc.playerController.processRightClick(mc.player, mc.world, EnumHand.MAIN_HAND);
                    mc.player.inventory.currentItem = saved;
                    mc.player.connection.sendPacket(new net.minecraft.network.play.client.CPacketHeldItemChange(saved));
                }
            }
        }
        wasJumpDown = jumpDown;
    }

    private void applyBoost() {
        float strength = boostStrength.getValue().floatValue();
        float yaw = mc.player.rotationYaw;
        float pitch = mc.player.rotationPitch;
        float f = net.minecraft.util.math.MathHelper.cos(-yaw * 0.017453292F - (float) Math.PI);
        float f1 = net.minecraft.util.math.MathHelper.sin(-yaw * 0.017453292F - (float) Math.PI);
        float f2 = -net.minecraft.util.math.MathHelper.cos(-pitch * 0.017453292F);
        float f3 = net.minecraft.util.math.MathHelper.sin(-pitch * 0.017453292F);
        double boostX = (f1 * f2 * 0.1 + f * 0.1) * strength;
        double boostY = (f3 * 0.1) * strength + 0.1 * strength;
        double boostZ = (f * f2 * 0.1 - f1 * 0.1) * strength;
        mc.player.motionX += boostX;
        mc.player.motionY += boostY;
        mc.player.motionZ += boostZ;
        if (playSound.getValue()) {
            mc.world.playSound(mc.player, mc.player.posX, mc.player.posY, mc.player.posZ, net.minecraft.init.SoundEvents.ENTITY_FIREWORK_SHOOT, net.minecraft.util.SoundCategory.PLAYERS, 1.0F, 1.0F);
        }
    }

    private boolean hasFirework() {
        return findFireworkSlot() != -1;
    }

    private int findFireworkSlot() {
        client.utils.player.FindItemResult r = client.utils.player.InvUtils.findInHotbar(net.minecraft.init.Items.FIREWORKS);
        return r.found() ? r.slot() - client.utils.player.SlotUtils.HOTBAR_START : -1;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        wasJumpDown = false;
    }
}
