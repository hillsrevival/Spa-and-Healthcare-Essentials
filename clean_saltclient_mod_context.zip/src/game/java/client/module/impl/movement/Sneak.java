package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.network.play.client.CPacketEntityAction;
import client.utils.world.PacketUtils;

public class Sneak extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Packet", "Packet", "Legit");

    private boolean sneakPacketSent = false;

    public Sneak() {
        super("Sneak", Category.MOVEMENT);
        setDescription("Automatically sneaks for you");
        addSetting(mode);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        String currentMode = mode.getValue();
        if (currentMode.equals("Packet")) {
            if (!sneakPacketSent) {
                PacketUtils.sendEntityAction(mc.player, CPacketEntityAction.Action.START_SNEAKING);
                sneakPacketSent = true;
            }
        } else {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), true);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.player == null)
            return;
        String currentMode = mode.getValue();
        if (currentMode.equals("Packet")) {
            PacketUtils.sendEntityAction(mc.player, CPacketEntityAction.Action.STOP_SNEAKING);
            sneakPacketSent = false;
        } else {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), GameSettings.isKeyDown(mc.gameSettings.keyBindSneak));
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        sneakPacketSent = false;
    }
}
