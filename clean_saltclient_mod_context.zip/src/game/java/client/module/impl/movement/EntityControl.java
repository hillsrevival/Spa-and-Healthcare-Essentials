package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.entity.passive.EntityAnimal;

public class EntityControl extends Module {

    public EntityControl() {
        super("EntityControl", Category.MOVEMENT);
        setDescription("Control ridden entities");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!mc.player.isRiding())
            return;
        if (mc.player.getRidingEntity() instanceof EntityAnimal) {
            net.minecraft.entity.Entity mount = mc.player.getRidingEntity();
            float moveForward = mc.player.movementInput.field_192832_b;
            float moveStrafe = mc.player.movementInput.moveStrafe;
            if (moveForward != 0) {
                mount.motionX += -Math.sin(Math.toRadians(mc.player.rotationYaw)) * moveForward * 0.1;
                mount.motionZ += Math.cos(Math.toRadians(mc.player.rotationYaw)) * moveForward * 0.1;
            }
            if (moveStrafe != 0) {
                mount.motionX += -Math.sin(Math.toRadians(mc.player.rotationYaw + 90)) * moveStrafe * 0.1;
                mount.motionZ += Math.cos(Math.toRadians(mc.player.rotationYaw + 90)) * moveStrafe * 0.1;
            }
        }
    }
}
