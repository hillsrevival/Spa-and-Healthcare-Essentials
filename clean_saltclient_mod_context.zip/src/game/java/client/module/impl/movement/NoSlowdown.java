package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class NoSlowdown extends Module {

    private final NumberSetting multiplier = new NumberSetting("Multiplier", 2.5, 1.0, 5.0);

    public NoSlowdown() {
        super("NoSlowdown", Category.MOVEMENT);
        setDescription("Prevents speed reduction from using items or soul sand");
        addSetting(multiplier);
        handles(HandlerType.TICK);
    }

    @Override
    public void onTick() {
        if (mc.player == null)
            return;
        if (mc.player.isHandActive()) {
            float mult = (float) (double) multiplier.getValue();
            mc.player.movementInput.field_192832_b *= mult;
            mc.player.movementInput.moveStrafe *= mult;
        }
    }
}
