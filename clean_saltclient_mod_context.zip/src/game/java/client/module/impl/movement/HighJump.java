package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class HighJump extends Module {

    private final NumberSetting height = new NumberSetting("Height", 1.0, 0.5, 5.0);

    public HighJump() {
        super("HighJump", Category.MOVEMENT);
        setDescription("Increases your jump height");
        addSetting(height);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (mc.player.onGround && mc.gameSettings.keyBindJump.isKeyDown()) {
            mc.player.motionY = 0.42f * height.getValue().floatValue();
        }
    }
}
