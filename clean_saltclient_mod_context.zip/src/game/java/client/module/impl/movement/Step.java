package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.event.events.StepEvent;

public class Step extends Module {

    private final NumberSetting height = new NumberSetting("Height", 1.0, 0.5, 1.5);

    public Step() {
        super("Step", Category.MOVEMENT);
        setDescription("Step up full blocks without jumping");
        addSetting(height);
        handles(HandlerType.UPDATE, HandlerType.STEP);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        mc.player.stepHeight = (float) (double) height.getValue();
    }

    @Override
    public void onStep(StepEvent event) {
        if (mc.player == null)
            return;
        if (event.getEntity() != mc.player)
            return;
        event.setStepHeight((float) (double) height.getValue());
        if (mc.player.isSneaking()) {
            event.setCancelled(true);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.player == null)
            return;
        mc.player.stepHeight = 0.6F;
    }
}
