package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import net.minecraft.util.math.MathHelper;

public class NoClip extends Module {

    private final NumberSetting speed = new NumberSetting("Speed", 0.5, 0.1, 5.0);

    private final BooleanSetting sneakToPhase = new BooleanSetting("SneakToPhase", false);

    public NoClip() {
        super("NoClip", Category.MOVEMENT);
        addSetting(speed);
        addSetting(sneakToPhase);
        handles(HandlerType.UPDATE);
        setDescription("Go through blocks");
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (sneakToPhase.getValue()) {
            if (!mc.gameSettings.keyBindSneak.isKeyDown()) {
                mc.player.noClip = false;
                return;
            }
        }
        mc.player.noClip = true;
        mc.player.fallDistance = 0.0f;
        mc.player.onGround = false;
        double sp = speed.getValue();
        float yaw = mc.player.rotationYaw;
        float forward = mc.player.movementInput.field_192832_b;
        float strafe = mc.player.movementInput.moveStrafe;
        if (forward != 0.0f || strafe != 0.0f) {
            float yawRad = (float) Math.toRadians(yaw);
            float moveAngle = MathHelper.wrapDegrees(yaw);
            float yawCos = (float) Math.cos(Math.toRadians(moveAngle + 90.0));
            float yawSin = (float) Math.sin(Math.toRadians(moveAngle + 90.0));
            mc.player.motionX = (double) (forward * yawCos + strafe * (-yawSin)) * sp;
            mc.player.motionZ = (double) (forward * yawSin + strafe * yawCos) * sp;
        } else {
            mc.player.motionX = 0.0;
            mc.player.motionZ = 0.0;
        }
        mc.player.motionY = 0.0;
        if (mc.gameSettings.keyBindJump.isKeyDown()) {
            mc.player.motionY = sp;
        }
        if (mc.gameSettings.keyBindSneak.isKeyDown()) {
            mc.player.motionY = -sp;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.player != null) {
            mc.player.noClip = false;
        }
    }
}
