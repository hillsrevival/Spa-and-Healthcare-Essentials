package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class FastLadder extends Module {

    private final NumberSetting speed = new NumberSetting("Speed", 0.4, 0.2, 1.0);

    public FastLadder() {
        super("FastLadder", Category.MOVEMENT);
        setDescription("Climbs ladders and vines much faster");
        addSetting(speed);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (!mc.player.isOnLadder())
            return;
        if (mc.player.movementInput.field_192832_b == 0 && mc.player.movementInput.moveStrafe == 0)
            return;
        mc.player.motionY = speed.getValue().floatValue();
    }
}
