package client.module.impl.movement;

import net.minecraft.util.math.BlockPos;
import net.minecraft.block.Block;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class AntiVoid extends Module {

    private final NumberSetting fallDist = new NumberSetting("FallDist", 5.0, 1.0, 20.0);

    public AntiVoid() {
        super("AntiVoid", Category.MOVEMENT);
        setDescription("Prevents falling into the void");
        addSetting(fallDist);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!mc.player.onGround && mc.player.motionY < 0.0) {
            double maxDist = fallDist.getValue().doubleValue();
            boolean noBlocks = true;
            int py = (int) Math.floor(mc.player.posY);
            for (int y = py - 1; y >= py - (int) maxDist && y >= 0; y--) {
                BlockPos bp = new BlockPos((int) Math.floor(mc.player.posX), y, (int) Math.floor(mc.player.posZ));
                if (mc.world.isBlockFullCube(bp)) {
                    noBlocks = false;
                    break;
                }
            }
            if (noBlocks && mc.player.fallDistance > 2.0f) {
                mc.player.motionY = 0.0;
                mc.player.setPosition(mc.player.posX, mc.player.posY + 0.5, mc.player.posZ);
            }
        }
    }
}
