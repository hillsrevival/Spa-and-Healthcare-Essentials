package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class Glide extends Module {

    private final NumberSetting fallSpeed = new NumberSetting("Fall Speed", 0.125, 0.005, 0.25);

    private final NumberSetting moveSpeed = new NumberSetting("Move Speed", 1.2, 1.0, 5.0);

    private final NumberSetting minHeight = new NumberSetting("Min Height", 0.0, 0.0, 2.0);

    public Glide() {
        super("Glide", Category.MOVEMENT);
        setDescription("Slowly falls down when in the air");
        addSetting(fallSpeed);
        addSetting(moveSpeed);
        addSetting(minHeight);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (!mc.player.isAirBorne || mc.player.isInWater() || mc.player.isInLava() || mc.player.isOnLadder() || mc.player.motionY >= 0)
            return;
        double minH = minHeight.getValue();
        if (minH > 0) {
            net.minecraft.util.math.AxisAlignedBB bb = mc.player.getEntityBoundingBox();
            net.minecraft.util.math.AxisAlignedBB checkBB = bb.union(bb.offset(0, -minH, 0));
            if (!mc.world.checkNoEntityCollision(bb) || mc.world.collidesWithAnyBlock(checkBB))
                return;
        }
        if (mc.player.motionY < -fallSpeed.getValue().floatValue()) {
            mc.player.motionY = -fallSpeed.getValue().floatValue();
        }
        mc.player.jumpMovementFactor *= moveSpeed.getValue().floatValue();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }
}
