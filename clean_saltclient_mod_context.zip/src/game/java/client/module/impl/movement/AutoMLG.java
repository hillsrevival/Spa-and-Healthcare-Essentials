package client.module.impl.movement;

import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.utils.player.FallPrediction;
import client.utils.world.InteractionUtils;

public class AutoMLG extends Module {

    private enum State {

        IDLE, PLACED, PICKING
    }

    private State state = State.IDLE;

    private int prevSlot = -1;

    private int bucketSlot = -1;

    private int landTimer = 0;

    private int pickupAttempts = 0;

    private BlockPos waterPos = null;

    private boolean pendingPlace = false;

    private boolean pendingPickup = false;

    private float savedPitch = 0.0f;

    private static final int MAX_PICKUP_ATTEMPTS = 15;

    private static final int TIMEOUT = 120;

    private final NumberSetting triggerDist = new NumberSetting("TriggerDist", 3.0, 1.5, 10.0);

    private final BooleanSetting debug = new BooleanSetting("Debug", false);

    public AutoMLG() {
        super("AutoMLG", Category.MOVEMENT);
        setDescription("Attempts to place a water bucket below you before hitting the ground");
        addSetting(triggerDist);
        addSetting(debug);
        handles(HandlerType.TICK, HandlerType.UPDATE);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        reset();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if ((pendingPlace || pendingPickup) && mc.player != null) {
            mc.player.rotationPitch = savedPitch;
        }
        pendingPlace = false;
        pendingPickup = false;
        restoreSlot();
        reset();
    }

    @Override
    public void onTick() {
        if (!nullCheck())
            return;
        switch(state) {
            case IDLE:
                handleIdle();
                break;
            case PLACED:
                handlePlaced();
                break;
            case PICKING:
                handlePicking();
                break;
        }
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (pendingPlace) {
            pendingPlace = false;
            InteractionUtils.useItem(EnumHand.MAIN_HAND);
            mc.player.rotationPitch = savedPitch;
        }
        if (pendingPickup) {
            pendingPickup = false;
            InteractionUtils.useItem(EnumHand.MAIN_HAND);
            mc.player.rotationPitch = savedPitch;
            ItemStack stack = mc.player.inventory.mainInventory.get(bucketSlot);
            if (stack.getItem() == Items.WATER_BUCKET) {
                restoreSlot();
                reset();
                return;
            }
            if (pickupAttempts >= MAX_PICKUP_ATTEMPTS) {
                restoreSlot();
                reset();
            }
        }
    }

    private void handleIdle() {
        if (mc.player.onGround || mc.player.isInWater() || mc.player.isInLava()) {
            return;
        }
        float fallDist = mc.player.fallDistance;
        float needed = triggerDist.getValue().floatValue();
        double motionY = mc.player.motionY;
        boolean byFallDist = (fallDist >= needed);
        boolean byPrediction = false;
        if (motionY < -0.2) {
            double groundDist = FallPrediction.getGroundDistance();
            double ticksToImpact = FallPrediction.getTicksToImpact(groundDist, motionY);
            byPrediction = (ticksToImpact <= 4.0 && fallDist >= 0.5f);
        }
        if (!byFallDist && !byPrediction)
            return;
        if (debug.getValue()) {
            double gd = FallPrediction.getGroundDistance();
            double tti = FallPrediction.getTicksToImpact(gd, motionY);
            client.utils.misc.ChatUtils.message("[AutoMLG] TRIGGER | fallDist:" + String.format("%.1f", fallDist) + " groundDist:" + String.format("%.1f", gd) + " tti:" + String.format("%.1f", tti) + " motionY:" + String.format("%.2f", motionY));
        }
        int slot = findWaterBucket();
        if (slot == -1)
            return;
        prevSlot = mc.player.inventory.currentItem;
        bucketSlot = slot;
        waterPos = FallPrediction.getLandingBlock();
        savedPitch = mc.player.rotationPitch;
        mc.player.rotationPitch = 90.0f;
        mc.player.inventory.currentItem = bucketSlot;
        pendingPlace = true;
        state = State.PLACED;
        landTimer = 0;
    }

    private void handlePlaced() {
        landTimer++;
        if (mc.player.onGround || mc.player.isInWater()) {
            state = State.PICKING;
            pickupAttempts = 0;
        } else if (landTimer > TIMEOUT) {
            restoreSlot();
            reset();
        }
    }

    private void handlePicking() {
        pickupAttempts++;
        if (bucketSlot < 0 || bucketSlot > 8) {
            restoreSlot();
            reset();
            return;
        }
        mc.player.inventory.currentItem = bucketSlot;
        savedPitch = mc.player.rotationPitch;
        mc.player.rotationPitch = 90.0f;
        pendingPickup = true;
    }

    private int findWaterBucket() {
        client.utils.player.FindItemResult r = client.utils.player.InvUtils.findInHotbar(net.minecraft.init.Items.WATER_BUCKET);
        return r.found() ? r.slot() - client.utils.player.SlotUtils.HOTBAR_START : -1;
    }

    private void restoreSlot() {
        if (mc.player != null && prevSlot >= 0 && prevSlot <= 8) {
            mc.player.inventory.currentItem = prevSlot;
            if (mc.player.connection != null) {
                mc.player.connection.sendPacket(new CPacketHeldItemChange(prevSlot));
            }
        }
    }

    private void reset() {
        state = State.IDLE;
        prevSlot = -1;
        bucketSlot = -1;
        landTimer = 0;
        pickupAttempts = 0;
        waterPos = null;
        pendingPlace = false;
        pendingPickup = false;
    }
}
