package client.module.impl.movement;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.lax1dude.eaglercraft.Keyboard;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Blocks;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.server.SPacketBlockChange;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import client.event.events.PacketInputEvent;
import client.module.BlockListSetting;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.HandlerType;
import client.module.Module;
import client.module.NumberSetting;
import client.module.RandomSetting;
import client.utils.combat.SilentAimUtil;
import client.utils.misc.NotificationSystem;
import client.utils.movement.MovementInputHelper;
import client.utils.movement.MovementUtils;
import client.utils.movement.RotationUtils;
import client.utils.render.ClientFontRenderer;
import client.utils.world.BlockUtils;

public class Clutch extends Module {

    private final BooleanSetting onVoid = new BooleanSetting("On Void", true);

    private final BooleanSetting onLethalFall = new BooleanSetting("On Lethal Fall", true);

    private final BooleanSetting onMoreThanBlocks = new BooleanSetting("On More Than X Blocks", false);

    private final NumberSetting blocksThreshold = new NumberSetting("Blocks", 6.0, 3.0, 10.0);

    private final NumberSetting speed = new NumberSetting("Speed", 3.5, 1.0, 10.0);

    private final BooleanSetting silentAim = new BooleanSetting("Silent Aim", false);

    private final BooleanSetting resetAngle = new BooleanSetting("Reset Angle", true);

    private final RandomSetting resetAngleDelay = new RandomSetting("Reset Angle Delay", 3.0, 3.0, 0.0, 10.0);

    private final BooleanSetting returnToLastSlot = new BooleanSetting("Return To Last Slot", true);

    private final RandomSetting returnDelay = new RandomSetting("Return Delay", 3.0, 3.0, 0.0, 10.0);

    private final BooleanSetting allowStaircaseUp = new BooleanSetting("Allow Staircase Up", true);

    private final RandomSetting clutchMoveDelay = new RandomSetting("Clutch Move Delay", 3.0, 3.0, 0.0, 10.0);

    private final NumberSetting failDelay = new NumberSetting("Fail Delay", 100.0, 0.0, 500.0);

    private final BooleanSetting showBlockCount = new BooleanSetting("Show Block Count", false);

    private final BooleanSetting limitBlocks = new BooleanSetting("Limit Blocks", false);

    private final NumberSetting maxBlocks = new NumberSetting("Max Blocks", 5.0, 1.0, 10.0);

    private final BooleanSetting useBlacklist = new BooleanSetting("Blacklist", true);

    private final BlockListSetting blacklistBlocks = new BlockListSetting("Block Blacklist", new String[] { "minecraft:gravel", "minecraft:sand", "minecraft:web", "minecraft:tnt", "minecraft:dispenser", "minecraft:noteblock", "minecraft:mob_spawner", "minecraft:enchanting_table", "minecraft:fence", "minecraft:jukebox", "minecraft:melon_block", "minecraft:command_block", "minecraft:anvil", "minecraft:glass_pane", "minecraft:stained_glass_pane", "minecraft:iron_bars", "minecraft:ice", "minecraft:packed_ice", "minecraft:redstone_block", "minecraft:gold_ore", "minecraft:iron_ore", "minecraft:coal_ore", "minecraft:lapis_ore", "minecraft:redstone_ore", "minecraft:acacia_stairs", "minecraft:wooden_pressure_plate", "minecraft:stone_pressure_plate", "minecraft:beacon", "minecraft:sapling", "minecraft:golden_rail", "minecraft:detector_rail", "minecraft:tallgrass", "minecraft:deadbush", "minecraft:yellow_flower", "minecraft:red_flower", "minecraft:red_mushroom", "minecraft:brown_mushroom", "minecraft:ladder", "minecraft:rail", "minecraft:trapdoor", "minecraft:waterlily", "minecraft:tripwire_hook", "minecraft:carpet", "minecraft:snow_layer", "minecraft:trapped_chest", "minecraft:daylight_detector", "minecraft:hopper", "minecraft:chest", "minecraft:torch", "minecraft:lever", "minecraft:redstone_torch", "minecraft:stone_button", "minecraft:wooden_button", "minecraft:cactus" });

    private final BooleanSetting heldWhitelist = new BooleanSetting("Held Whitelist", false);

    private final BlockListSetting whitelistBlocks = new BlockListSetting("Held Block Whitelist", new String[0]);

    private static final String[] PREFERRED_NAMES = { "Wool", "Stone", "Wood Planks", "Red Sandstone", "Stained Clay", "End Stone", "Obsidian" };

    private enum Phase {

        IDLE, FALLING, COOLDOWN
    }

    private Phase phase = Phase.IDLE;

    private boolean silentAimOwned = false;

    private int previousSlot = -1;

    private float lastServerYaw = 0.0f;

    private float lastServerPitch = 0.0f;

    private float savedYaw = 0.0f;

    private float savedPitch = 0.0f;

    private boolean resettingAngle = false;

    private boolean angleSaved = false;

    private final Set<BlockPos> placedBlocks = new HashSet<>();

    private int blocksPlacedThisFall = 0;

    private BlockPos lastPlacedBlock = null;

    private double episodeStartY = 0.0;

    private int groundedTicks = 0;

    private int placeCooldownTicks = 0;

    private boolean episodeSatisfied = false;

    private boolean gaveUpThisFall = false;

    private boolean notifiedThisFall = false;

    private long lastEpisodeEndMs = 0L;

    private long failTimerMs = 0L;

    private boolean staircaseQueued = false;

    private int moveDelayTicks = -1;

    private boolean inputFrozen = false;

    private int returnDelayTicks = -1;

    private int resetAngleDelayTicks = -1;

    private boolean counterMotionActive = false;

    private BlockPos counterMotionTarget = null;

    private int counterMotionRescanTicks = 0;

    private int supportCellX = Integer.MIN_VALUE;

    private int supportCellY = Integer.MIN_VALUE;

    private int supportCellZ = Integer.MIN_VALUE;

    private final int[] validSlots = new int[9];

    private final Set<BlockPos> candidateCells = new HashSet<>();

    public Clutch() {
        super("Clutch", Category.MOVEMENT);
        setDescription("Automatically places blocks to prevent falls");
        addSetting(onVoid);
        addSetting(onLethalFall);
        addSetting(onMoreThanBlocks);
        addSetting(blocksThreshold);
        addSetting(speed);
        addSetting(silentAim);
        addSetting(resetAngle);
        addSetting(resetAngleDelay);
        addSetting(returnToLastSlot);
        addSetting(returnDelay);
        addSetting(allowStaircaseUp);
        addSetting(clutchMoveDelay);
        addSetting(failDelay);
        addSetting(showBlockCount);
        addSetting(limitBlocks);
        addSetting(maxBlocks);
        addSetting(useBlacklist);
        addSetting(blacklistBlocks);
        addSetting(heldWhitelist);
        addSetting(whitelistBlocks);
        handles(HandlerType.TICK, HandlerType.UPDATE, HandlerType.GUI_RENDER, HandlerType.PACKET_INPUT);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        hardReset();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        restoreSlot();
        releaseClaim();
        if (counterMotionActive || inputFrozen) {
            restoreHardwareInput();
        }
        hardReset();
    }

    private void hardReset() {
        phase = Phase.IDLE;
        placedBlocks.clear();
        blocksPlacedThisFall = 0;
        lastPlacedBlock = null;
        episodeSatisfied = false;
        gaveUpThisFall = false;
        notifiedThisFall = false;
        groundedTicks = 0;
        placeCooldownTicks = 0;
        candidateCells.clear();
        counterMotionActive = false;
        counterMotionTarget = null;
        resettingAngle = false;
        angleSaved = false;
        moveDelayTicks = -1;
        returnDelayTicks = -1;
        resetAngleDelayTicks = -1;
        inputFrozen = false;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            hardReset();
            return;
        }
        if (mc.currentScreen != null) {
            if (phase == Phase.FALLING) {
                endEpisode();
            }
            return;
        }
        if (silentAimOwned && !SilentAimUtil.isOwnedBy("Clutch")) {
            silentAimOwned = false;
        }
        if (phase == Phase.FALLING) {
            tickFalling();
            return;
        }
        tickCooldown();
        boolean frozen = moveDelayTicks > 0 || inputFrozen;
        if (!frozen && shouldActivate()) {
            beginEpisode();
            tickFalling();
        }
    }

    @Override
    public void onUpdate() {
        if (silentAimOwned && SilentAimUtil.isOwnedBy("Clutch")) {
            SilentAimUtil.restore();
        }
        if (mc.player != null && showBlockCount.getValue()) {
            hudBlockCount = countUsableBlocks();
        }
    }

    private boolean shouldActivate() {
        if (mc.player.capabilities.isCreativeMode || mc.player.capabilities.isFlying) {
            return false;
        }
        if (mc.player.isElytraFlying() || mc.player.isRiding()) {
            return false;
        }
        if (mc.player.isInWater() || mc.player.isOnLadder() || mc.player.isInWeb) {
            return false;
        }
        if (!(onVoid.getValue() || onLethalFall.getValue() || onMoreThanBlocks.getValue())) {
            return false;
        }
        if (mc.player.motionX == 0.0 && mc.player.motionY == 0.0 && mc.player.motionZ == 0.0) {
            return false;
        }
        boolean fallingOrRising = !mc.player.onGround || mc.player.motionY >= 0.0;
        if (!fallingOrRising) {
            return false;
        }
        if (findBestBlockSlot() == -1) {
            return false;
        }
        if (System.currentTimeMillis() < failTimerMs) {
            return false;
        }
        BlockPos landing = predictLandingBlock();
        if (landing == null) {
            if (landingIsSafe) {
                return false;
            }
            return onVoid.getValue();
        }
        for (int h = 0; h <= 3; h++) {
            if (isSafeBlock(landing.up(h))) {
                return false;
            }
        }
        float fallDistance = (float) (mc.player.posY - (landing.getY() + 1));
        if (fallDistance < 0.0f)
            fallDistance = 0.0f;
        if (onMoreThanBlocks.getValue() && fallDistance >= blocksThreshold.getValue().floatValue()) {
            return true;
        }
        if (onLethalFall.getValue()) {
            float damage = estimateFallDamage(fallDistance);
            return mc.player.getHealth() - damage <= 0.0f;
        }
        return false;
    }

    private float estimateFallDamage(float fallDistance) {
        return client.utils.player.PlayerUtils.predictFallDamage(fallDistance);
    }

    private void beginEpisode() {
        previousSlot = mc.player.inventory.currentItem;
        placedBlocks.clear();
        blocksPlacedThisFall = 0;
        episodeSatisfied = false;
        gaveUpThisFall = false;
        notifiedThisFall = false;
        groundedTicks = 0;
        placeCooldownTicks = 0;
        episodeStartY = mc.player.posY;
        staircaseQueued = allowStaircaseUp.getValue() && System.currentTimeMillis() - lastEpisodeEndMs <= 500L;
        lastServerYaw = mc.player.rotationYaw;
        lastServerPitch = mc.player.rotationPitch;
        if (silentAim.getValue() && !silentAimOwned && !SilentAimUtil.isActive()) {
            silentAimOwned = SilentAimUtil.onEnable("Clutch");
            if (silentAimOwned) {
                SilentAimUtil.startStreak();
            }
        }
        if (silentAimOwned) {
            SilentAimUtil.setRotationCritical("Clutch", true);
        }
        if (!silentAimOwned && !angleSaved) {
            savedYaw = mc.player.rotationYaw;
            savedPitch = mc.player.rotationPitch;
            angleSaved = true;
        }
        phase = Phase.FALLING;
    }

    private void endEpisode() {
        if (counterMotionActive) {
            counterMotionActive = false;
            moveDelayTicks = (int) Math.round(clutchMoveDelay.getRandomValue());
        }
        if (returnToLastSlot.getValue() && previousSlot != -1) {
            returnDelayTicks = (int) Math.round(returnDelay.getRandomValue());
        }
        if (resetAngle.getValue() && !silentAimOwned && angleSaved) {
            resetAngleDelayTicks = (int) Math.round(resetAngleDelay.getRandomValue());
        }
        lastEpisodeEndMs = System.currentTimeMillis();
        releaseClaim();
        phase = Phase.COOLDOWN;
        episodeSatisfied = false;
        candidateCells.clear();
    }

    private void giveUp(String message) {
        if (!notifiedThisFall) {
            NotificationSystem.warning("Clutch: " + message);
            notifiedThisFall = true;
        }
        gaveUpThisFall = true;
        failTimerMs = System.currentTimeMillis() + (long) failDelay.getValue().doubleValue();
    }

    private void tickFalling() {
        if (mc.player.capabilities.isFlying || mc.player.isElytraFlying() || mc.player.isRiding() || mc.player.isInWater() || mc.player.isOnLadder() || mc.player.isInWeb) {
            endEpisode();
            return;
        }
        if (mc.player.onGround) {
            groundedTicks++;
            if (groundedTicks >= 3) {
                endEpisode();
                return;
            }
        } else {
            groundedTicks = 0;
        }
        if (mc.player.posY < episodeStartY - 90.0 || mc.player.posY < -16.0) {
            giveUp("Could not find a clutch path!");
            endEpisode();
            return;
        }
        if (placeCooldownTicks > 0) {
            placeCooldownTicks--;
        }
        if (gaveUpThisFall) {
            updateCounterMotion(true);
            holdSilentRotation();
            return;
        }
        if (episodeSatisfied) {
            if (stillSatisfied()) {
                holdSilentRotation();
                return;
            }
            episodeSatisfied = false;
        }
        CatchPlan plan = findCatchPlan();
        updateCounterMotion(plan != null);
        if (plan == null) {
            holdSilentRotation();
            return;
        }
        int slot = findBestBlockSlot();
        if (slot == -1) {
            giveUp("No blocks in hotbar!");
            endEpisode();
            return;
        }
        if (mc.player.inventory.currentItem != slot) {
            mc.player.inventory.currentItem = slot;
        }
        float[] needed = RotationUtils.getNeededRotations(plan.hitPoint);
        stepRotation(needed[0], needed[1]);
        tryFirePlacement(plan);
    }

    private void holdSilentRotation() {
        if (silentAimOwned) {
            SilentAimUtil.setupSilentRotation(lastServerYaw, lastServerPitch);
        }
    }

    private boolean stillSatisfied() {
        BlockPos landing = predictLandingBlock();
        if (landing == null) {
            return !onVoidDanger();
        }
        if (placedBlocks.contains(landing)) {
            return true;
        }
        float fallDistance = (float) (mc.player.posY - (landing.getY() + 1));
        if (fallDistance < 0.0f)
            fallDistance = 0.0f;
        return estimateFallDamage(fallDistance) < mc.player.getHealth() && !(onMoreThanBlocks.getValue() && fallDistance >= blocksThreshold.getValue().floatValue());
    }

    private boolean onVoidDanger() {
        return !landingIsSafe && onVoid.getValue();
    }

    private static final class CatchPlan {

        final BlockPos cell;

        final BlockPos support;

        final EnumFacing face;

        final Vec3d hitPoint;

        final int trajectoryIndex;

        CatchPlan(BlockPos cell, BlockPos support, EnumFacing face, Vec3d hitPoint, int trajectoryIndex) {
            this.cell = cell;
            this.support = support;
            this.face = face;
            this.hitPoint = hitPoint;
            this.trajectoryIndex = trajectoryIndex;
        }
    }

    private CatchPlan findCatchPlan() {
        candidateCells.clear();
        simulateTrajectory(60);
        Vec3d eyes = RotationUtils.getEyesPos();
        List<CatchPlan> plans = new ArrayList<CatchPlan>();
        for (int i = 0; i < trajLen - 1; i++) {
            double[] prev = trajPos[i];
            double[] cur = trajPos[i + 1];
            if (cur[1] < eyes.yCoord && Math.sqrt((cur[0] - eyes.xCoord) * (cur[0] - eyes.xCoord) + (cur[1] - eyes.yCoord) * (cur[1] - eyes.yCoord) + (cur[2] - eyes.zCoord) * (cur[2] - eyes.zCoord)) > 7.0) {
                break;
            }
            int topLevel = (int) Math.floor(prev[1]) - 1;
            int bottomLevel = (int) Math.floor(cur[1]);
            if (bottomLevel > topLevel) {
                continue;
            }
            int[] xs = { (int) Math.floor(cur[0]), (int) Math.floor(cur[0] - 0.3), (int) Math.floor(cur[0] + 0.3) };
            int[] zs = { (int) Math.floor(cur[2]), (int) Math.floor(cur[2] - 0.3), (int) Math.floor(cur[2] + 0.3) };
            for (int level = topLevel; level >= bottomLevel; level--) {
                for (int xi = 0; xi < 3; xi++) {
                    for (int zi = 0; zi < 3; zi++) {
                        BlockPos cell = new BlockPos(xs[xi], level, zs[zi]);
                        collectCatchCell(cell, eyes, i, plans);
                    }
                }
            }
            if (!plans.isEmpty() && i >= 3) {
                break;
            }
            if (i >= 12) {
                break;
            }
        }
        if (plans.isEmpty()) {
            return null;
        }
        return pickBestPlan(plans);
    }

    private void collectCatchCell(BlockPos cell, Vec3d eyes, int trajectoryIndex, List<CatchPlan> plans) {
        if (candidateCells.contains(cell)) {
            return;
        }
        IBlockState state = mc.world.getBlockState(cell);
        if (!state.getMaterial().isReplaceable()) {
            return;
        }
        if (mc.world.getBlockState(cell.up()).getMaterial().blocksMovement()) {
            return;
        }
        boolean atOrBelowFeet = cell.getY() <= (int) Math.floor(mc.player.posY);
        if (!atOrBelowFeet) {
            AxisAlignedBB blockBB = new AxisAlignedBB(cell);
            if (blockBB.intersectsWith(mc.player.getEntityBoundingBox().expand(-0.05, -0.05, -0.05))) {
                return;
            }
        }
        for (EnumFacing f : EnumFacing.values()) {
            BlockPos support = cell.offset(f);
            if (!BlockUtils.isSolid(support)) {
                continue;
            }
            EnumFacing face = f.getOpposite();
            Vec3d hit = new Vec3d(support.getX() + 0.5 + face.getFrontOffsetX() * 0.5, support.getY() + 0.5 + face.getFrontOffsetY() * 0.5, support.getZ() + 0.5 + face.getFrontOffsetZ() * 0.5);
            if (eyes.distanceTo(hit) > 4.4) {
                continue;
            }
            RayTraceResult r = mc.world.rayTraceBlocks(eyes, hit, false, false, false);
            if (r == null || r.typeOfHit != RayTraceResult.Type.BLOCK || !r.getBlockPos().equals(support)) {
                continue;
            }
            candidateCells.add(cell);
            plans.add(new CatchPlan(cell, support, face, hit, trajectoryIndex));
        }
    }

    private CatchPlan pickBestPlan(List<CatchPlan> plans) {
        CatchPlan best = null;
        double bestScore = Double.MAX_VALUE;
        for (CatchPlan plan : plans) {
            double fallDistance = mc.player.posY - (plan.cell.getY() + 1);
            double horiz = Math.hypot(plan.cell.getX() + 0.5 - mc.player.posX, plan.cell.getZ() + 0.5 - mc.player.posZ);
            float[] needed = RotationUtils.getNeededRotations(plan.hitPoint);
            float yawDist = Math.abs(RotationUtils.wrapDegrees(needed[0] - lastServerYaw));
            if (yawDist > 120.0f) {
                yawDist = Math.abs(RotationUtils.wrapDegrees(yawDist + 180.0f));
            }
            double score = Math.max(fallDistance, 0.0) * 1000.0 + horiz * 100.0 + yawDist * 2.0;
            if (staircaseQueued && lastPlacedBlock != null && plan.cell.getY() >= lastPlacedBlock.getY() && Math.abs(plan.cell.getX() - lastPlacedBlock.getX()) <= 3 && Math.abs(plan.cell.getZ() - lastPlacedBlock.getZ()) <= 3) {
                score -= 1500.0;
            }
            if (score < bestScore) {
                bestScore = score;
                best = plan;
            }
        }
        return best;
    }

    private final double[][] trajPos = new double[61][3];

    private int trajLen = 0;

    private void simulateTrajectory(int maxTicks) {
        double x = mc.player.posX;
        double y = mc.player.posY;
        double z = mc.player.posZ;
        double vx = mc.player.motionX;
        double vy = mc.player.motionY;
        double vz = mc.player.motionZ;
        trajPos[0][0] = x;
        trajPos[0][1] = y;
        trajPos[0][2] = z;
        trajLen = 1;
        for (int tick = 0; tick < maxTicks; tick++) {
            vy = (vy - 0.08) * 0.98;
            x += vx;
            y += vy;
            z += vz;
            vx *= 0.91;
            vz *= 0.91;
            trajPos[trajLen][0] = x;
            trajPos[trajLen][1] = y;
            trajPos[trajLen][2] = z;
            trajLen++;
            if (y < 0.0) {
                break;
            }
        }
    }

    private void tryFirePlacement(CatchPlan plan) {
        if (placeCooldownTicks > 0) {
            return;
        }
        float gateYaw = silentAimOwned ? lastServerYaw : mc.player.rotationYaw;
        float gatePitch = silentAimOwned ? lastServerPitch : mc.player.rotationPitch;
        Vec3d eyes = RotationUtils.getEyesPos();
        Vec3d look = RotationUtils.getLookVec(gateYaw, gatePitch);
        double reach = 4.4;
        Vec3d end = eyes.addVector(look.xCoord * reach, look.yCoord * reach, look.zCoord * reach);
        RayTraceResult r = mc.world.rayTraceBlocks(eyes, end, false, false, false);
        if (r == null || r.typeOfHit != RayTraceResult.Type.BLOCK || r.hitVec == null || eyes.distanceTo(r.hitVec) > reach) {
            return;
        }
        BlockPos clicked = r.getBlockPos();
        EnumFacing face = r.sideHit;
        BlockPos placed = clicked.offset(face);
        if (!isAcceptablePlacement(placed)) {
            return;
        }
        if (!BlockUtils.isSolid(clicked)) {
            return;
        }
        boolean airborneCatchCell = !mc.player.onGround && placed.getY() <= (int) Math.floor(mc.player.posY);
        if (!airborneCatchCell) {
            AxisAlignedBB blockBB = new AxisAlignedBB(placed);
            if (blockBB.intersectsWith(mc.player.getEntityBoundingBox().expand(-0.05, -0.05, -0.05))) {
                return;
            }
        }
        float repYaw = mc.player.getLastReportedYaw();
        float repPitch = mc.player.getLastReportedPitch();
        Vec3d repLook = RotationUtils.getLookVec(repYaw, repPitch);
        Vec3d repEnd = eyes.addVector(repLook.xCoord * reach, repLook.yCoord * reach, repLook.zCoord * reach);
        RayTraceResult repRay = mc.world.rayTraceBlocks(eyes, repEnd, false, false, false);
        boolean serverRotationSeesClick = repRay != null && repRay.typeOfHit == RayTraceResult.Type.BLOCK && repRay.getBlockPos().equals(clicked);
        if (!serverRotationSeesClick && !rotationSeesClickedBox(clicked, repYaw, repPitch)) {
            return;
        }
        float wireYaw = gateYaw;
        float wirePitch = gatePitch;
        if (client.Client.INSTANCE.renderRotationOverride) {
            wireYaw = client.Client.INSTANCE.scaffoldYaw;
            wirePitch = client.Client.INSTANCE.scaffoldPitch;
        }
        if (!rotationSeesClickedBox(clicked, wireYaw, wirePitch)) {
            return;
        }
        Vec3d cursor = clampToFaceInterior(r.hitVec, clicked, face);
        BlockUtils.markPlaced(placed);
        EnumActionResult result = mc.playerController.processRightClickBlock(mc.player, mc.world, clicked, face, cursor, EnumHand.MAIN_HAND);
        if (result != EnumActionResult.SUCCESS) {
            return;
        }
        placedBlocks.add(placed);
        lastPlacedBlock = placed;
        blocksPlacedThisFall++;
        placeCooldownTicks = 4;
        if (limitBlocks.getValue() && blocksPlacedThisFall > maxBlocks.getValue().intValue()) {
            giveUp("Requires more than the max blocks!");
            return;
        }
        if (blocksPlacedThisFall > 64) {
            giveUp("Clutch path too long!");
            return;
        }
        if (stillSatisfied()) {
            episodeSatisfied = true;
        }
    }

    private boolean rotationSeesClickedBox(BlockPos clicked, float yaw, float pitch) {
        AxisAlignedBB box = new AxisAlignedBB(clicked);
        double px = mc.player.posX;
        double py = mc.player.posY;
        double pz = mc.player.posZ;
        final double mt = 0.03;
        if (px + mt > box.minX && px - mt < box.maxX && py + 1.62 + mt > box.minY && py + 0.4 - mt < box.maxY && pz + mt > box.minZ && pz - mt < box.maxZ) {
            return true;
        }
        Vec3d look = RotationUtils.getLookVec(yaw, pitch);
        double[] eyeHeights = { 1.62, 1.54, 0.4 };
        for (double h : eyeHeights) {
            Vec3d origin = new Vec3d(px, py + h, pz);
            Vec3d end = origin.addVector(look.xCoord * 4.5, look.yCoord * 4.5, look.zCoord * 4.5);
            if (box.calculateIntercept(origin, end) != null) {
                return true;
            }
        }
        return false;
    }

    private boolean isAcceptablePlacement(BlockPos placed) {
        if (candidateCells.contains(placed)) {
            return true;
        }
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (candidateCells.contains(placed.add(dx, dy, dz))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private Vec3d clampToFaceInterior(Vec3d hit, BlockPos pos, EnumFacing face) {
        double x = hit.xCoord - pos.getX();
        double y = hit.yCoord - pos.getY();
        double z = hit.zCoord - pos.getZ();
        switch(face) {
            case UP:
            case DOWN:
                y = face == EnumFacing.UP ? 1.0 : 0.0;
                x = clamp01(x);
                z = clamp01(z);
                break;
            case NORTH:
            case SOUTH:
                z = face == EnumFacing.SOUTH ? 1.0 : 0.0;
                x = clamp01(x);
                y = clamp01(y);
                break;
            case EAST:
            case WEST:
            default:
                x = face == EnumFacing.EAST ? 1.0 : 0.0;
                y = clamp01(y);
                z = clamp01(z);
                break;
        }
        return new Vec3d(pos.getX() + x, pos.getY() + y, pos.getZ() + z);
    }

    private double clamp01(double v) {
        return Math.max(0.02, Math.min(0.98, v));
    }

    private void stepRotation(float targetYaw, float targetPitch) {
        float maxSpeed = 15.0f + 85.0f * (speed.getValue().floatValue() / 10.0f);
        maxSpeed += (int) (Math.abs(mc.player.posY) * 100.0) % 5;
        float dy = RotationUtils.wrapDegrees(targetYaw - lastServerYaw);
        float dp = targetPitch - lastServerPitch;
        float dist = Math.abs(dy) + Math.abs(dp);
        float stepSpeed = Math.min(maxSpeed, dist / 1.8f);
        if (stepSpeed < 0.5f) {
            stepSpeed = 0.5f;
        }
        if (dist > stepSpeed && dist > 0.0f) {
            dy *= stepSpeed / dist;
            dp *= stepSpeed / dist;
        }
        float newYaw = lastServerYaw + dy;
        float newPitch = lastServerPitch + dp;
        if (newPitch > 90.0f)
            newPitch = 90.0f;
        if (newPitch < -90.0f)
            newPitch = -90.0f;
        float[] fixed = RotationUtils.fixRotations(lastServerYaw, lastServerPitch, newYaw, newPitch);
        if (silentAimOwned) {
            SilentAimUtil.setupSilentRotation(fixed[0], fixed[1]);
        } else {
            mc.player.rotationYaw = fixed[0];
            mc.player.rotationPitch = fixed[1];
        }
        lastServerYaw = fixed[0];
        lastServerPitch = fixed[1];
    }

    private void stepResetAngle() {
        float dy = RotationUtils.wrapDegrees(savedYaw - mc.player.rotationYaw);
        float dp = savedPitch - mc.player.rotationPitch;
        float dist = Math.abs(dy) + Math.abs(dp);
        if (dist < 1.0f) {
            mc.player.rotationYaw = savedYaw;
            mc.player.rotationPitch = savedPitch;
            resettingAngle = false;
            angleSaved = false;
            return;
        }
        float stepSpeed = Math.max(Math.abs(dy) / 90.0f * 5.0f, 1.0f);
        if (dist > stepSpeed) {
            dy *= stepSpeed / dist;
            dp *= stepSpeed / dist;
        }
        float[] fixed = RotationUtils.fixRotations(mc.player.rotationYaw, mc.player.rotationPitch, mc.player.rotationYaw + dy, mc.player.rotationPitch + dp);
        mc.player.rotationYaw = fixed[0];
        mc.player.rotationPitch = fixed[1];
    }

    private void updateCounterMotion(boolean hasPlan) {
        if (hasPlan) {
            if (counterMotionActive) {
                counterMotionActive = false;
                counterMotionTarget = null;
                restoreHardwareInput();
            }
            return;
        }
        int cellX = (int) Math.floor(mc.player.posX);
        int cellY = (int) Math.floor(mc.player.posY);
        int cellZ = (int) Math.floor(mc.player.posZ);
        boolean cellChanged = cellX != supportCellX || cellY != supportCellY || cellZ != supportCellZ;
        if (counterMotionRescanTicks > 0 && counterMotionTarget != null && !cellChanged) {
            counterMotionRescanTicks--;
        } else {
            supportCellX = cellX;
            supportCellY = cellY;
            supportCellZ = cellZ;
            counterMotionTarget = findNearestSupport();
            counterMotionRescanTicks = 10;
        }
        BlockPos target = counterMotionTarget;
        if (target == null) {
            if (counterMotionActive) {
                counterMotionActive = false;
                restoreHardwareInput();
            }
            return;
        }
        double horiz = Math.hypot(target.getX() + 0.5 - mc.player.posX, target.getZ() + 0.5 - mc.player.posZ);
        if (horiz <= 3.0) {
            if (counterMotionActive) {
                counterMotionActive = false;
                restoreHardwareInput();
            }
            return;
        }
        counterMotionActive = true;
        MovementInputHelper.applyDirectionalMovement(target.getX() + 0.5 - mc.player.posX, target.getZ() + 0.5 - mc.player.posZ);
        MovementUtils.holdJump(false);
    }

    private BlockPos findNearestSupport() {
        int cx = (int) Math.floor(mc.player.posX);
        int cz = (int) Math.floor(mc.player.posZ);
        int topY = (int) Math.floor(mc.player.posY) + 2;
        int bottomY = (int) Math.floor(mc.player.posY) - 12;
        for (int radius = 1; radius <= 8; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) {
                        continue;
                    }
                    for (int y = topY; y >= bottomY; y--) {
                        BlockPos p = new BlockPos(cx + dx, y, cz + dz);
                        if (BlockUtils.isSolid(p)) {
                            return p;
                        }
                    }
                }
            }
        }
        return null;
    }

    private void restoreHardwareInput() {
        if (mc.currentScreen != null) {
            return;
        }
        restoreKey(mc.gameSettings.keyBindForward);
        restoreKey(mc.gameSettings.keyBindBack);
        restoreKey(mc.gameSettings.keyBindLeft);
        restoreKey(mc.gameSettings.keyBindRight);
        restoreKey(mc.gameSettings.keyBindJump);
    }

    private void restoreKey(KeyBinding key) {
        KeyBinding.setKeyBindState(key.getKeyCode(), Keyboard.isKeyDown(key.getKeyCode()));
    }

    private void tickCooldown() {
        if (moveDelayTicks > 0) {
            inputFrozen = true;
            MovementInputHelper.releaseAllInput();
            MovementUtils.holdJump(false);
            moveDelayTicks--;
        } else if (inputFrozen) {
            inputFrozen = false;
            restoreHardwareInput();
        }
        if (returnDelayTicks > 0) {
            returnDelayTicks--;
        } else if (returnDelayTicks == 0) {
            returnDelayTicks = -1;
            restoreSlot();
        }
        if (resetAngleDelayTicks > 0) {
            resetAngleDelayTicks--;
        } else if (resetAngleDelayTicks == 0) {
            resetAngleDelayTicks = -1;
            if (!silentAimOwned && angleSaved) {
                resettingAngle = true;
            }
        }
        if (resettingAngle) {
            stepResetAngle();
        }
        boolean busy = moveDelayTicks > 0 || inputFrozen || returnDelayTicks > 0 || resetAngleDelayTicks > 0 || resettingAngle;
        if (!busy) {
            phase = Phase.IDLE;
        }
    }

    private int findBestBlockSlot() {
        if (heldWhitelist.getValue()) {
            ItemStack held = mc.player.inventory.getStackInSlot(mc.player.inventory.currentItem);
            if (isUsableBlockStack(held) && isWhitelistedStack(held)) {
                return mc.player.inventory.currentItem;
            }
            return -1;
        }
        int validCount = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (isUsableBlockStack(stack)) {
                validSlots[validCount++] = i;
            }
        }
        if (validCount == 0) {
            return -1;
        }
        for (String preferred : PREFERRED_NAMES) {
            for (int vi = 0; vi < validCount; vi++) {
                int slot = validSlots[vi];
                String name = mc.player.inventory.getStackInSlot(slot).getDisplayName();
                if (name != null && name.contains(preferred)) {
                    return slot;
                }
            }
        }
        return validSlots[0];
    }

    private boolean isUsableBlockStack(ItemStack stack) {
        if (stack == null || stack.func_190926_b()) {
            return false;
        }
        if (!(stack.getItem() instanceof ItemBlock)) {
            return false;
        }
        if (useBlacklist.getValue() && blacklistBlocks.contains(blockRegistryId(stack))) {
            return false;
        }
        return true;
    }

    private boolean isWhitelistedStack(ItemStack stack) {
        return whitelistBlocks.contains(blockRegistryId(stack));
    }

    private String blockRegistryId(ItemStack stack) {
        Block block = ((ItemBlock) stack.getItem()).getBlock();
        Object loc = Block.REGISTRY.getNameForObject(block);
        return loc != null ? loc.toString() : "";
    }

    private int hudBlockCount = 0;

    private int countUsableBlocks() {
        if (heldWhitelist.getValue()) {
            ItemStack held = mc.player.inventory.getStackInSlot(mc.player.inventory.currentItem);
            if (isUsableBlockStack(held) && isWhitelistedStack(held)) {
                return held.func_190916_E();
            }
            return 0;
        }
        int count = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (isUsableBlockStack(stack)) {
                count += stack.func_190916_E();
            }
        }
        return count;
    }

    @Override
    public void onGUIRender() {
        if (!showBlockCount.getValue() || mc.player == null || mc.world == null) {
            return;
        }
        int count = hudBlockCount;
        ScaledResolution sr = mc.scaledResolution;
        if (sr == null)
            sr = new ScaledResolution(mc);
        String text = String.valueOf(count);
        int color = count >= 32 ? 0xFF02BE3A : count >= 16 ? 0xFFFFF912 : 0xFFFF1414;
        int x = sr.getScaledWidth() / 2 - ClientFontRenderer.getStringWidth(text) / 2;
        int y = sr.getScaledHeight() / 2 + 12;
        ClientFontRenderer.drawStringWithShadow(text, x, y, color);
    }

    @Override
    public void onPacketInput(PacketInputEvent event) {
        if (placedBlocks.isEmpty() || (phase != Phase.FALLING && phase != Phase.COOLDOWN)) {
            return;
        }
        if (!(event.getPacket() instanceof SPacketBlockChange)) {
            return;
        }
        SPacketBlockChange packet = (SPacketBlockChange) event.getPacket();
        BlockPos pos = packet.getBlockPosition();
        if (pos == null || !placedBlocks.contains(pos)) {
            return;
        }
        if (packet.getBlockState() != null && packet.getBlockState().getMaterial() == Material.AIR) {
            placedBlocks.remove(pos);
            episodeSatisfied = false;
            placeCooldownTicks = Math.max(placeCooldownTicks, 8);
            if (phase == Phase.FALLING && !notifiedThisFall) {
                NotificationSystem.warning("Clutch: server rejected the placement!");
                notifiedThisFall = true;
            }
        }
    }

    private boolean landingIsSafe = false;

    private BlockPos predictLandingBlock() {
        landingIsSafe = false;
        double x = mc.player.posX;
        double y = mc.player.posY;
        double z = mc.player.posZ;
        double vx = mc.player.motionX;
        double vy = mc.player.motionY;
        double vz = mc.player.motionZ;
        for (int tick = 0; tick < 60; tick++) {
            vy = (vy - 0.08) * 0.98;
            double nx = x + vx;
            double ny = y + vy;
            double nz = z + vz;
            BlockPos landing = landingInSegment(x, y, z, nx, ny, nz);
            if (landing != null) {
                return landing;
            }
            x = nx;
            y = ny;
            z = nz;
            vx *= 0.91;
            vz *= 0.91;
            if (y < 0.0) {
                return null;
            }
        }
        return null;
    }

    private BlockPos landingInSegment(double x0, double y0, double z0, double x1, double y1, double z1) {
        int topLevel = (int) Math.floor(y0) - 1;
        int bottomLevel = (int) Math.floor(y1);
        if (bottomLevel > topLevel)
            return null;
        int[] xs = { (int) Math.floor(x1), (int) Math.floor(x1 - 0.3), (int) Math.floor(x1 + 0.3) };
        int[] zs = { (int) Math.floor(z1), (int) Math.floor(z1 - 0.3), (int) Math.floor(z1 + 0.3) };
        for (int level = topLevel; level >= bottomLevel; level--) {
            BlockPos center = new BlockPos(xs[0], level, zs[0]);
            int ck = blockKind(mc.world.getBlockState(center));
            if (ck == 1) {
                landingIsSafe = true;
                return null;
            }
            if (ck == 2)
                return center;
            for (int xi = 0; xi < 3; xi++) {
                for (int zi = 0; zi < 3; zi++) {
                    if (xi == 0 && zi == 0)
                        continue;
                    BlockPos p = new BlockPos(xs[xi], level, zs[zi]);
                    if (blockKind(mc.world.getBlockState(p)) == 2) {
                        return p;
                    }
                }
            }
        }
        return null;
    }

    private int blockKind(IBlockState state) {
        if (state == null)
            return 0;
        if (state.getBlock() == Blocks.WEB || state.getBlock() == Blocks.LADDER) {
            return 1;
        }
        if (state.getMaterial().isLiquid())
            return 1;
        if (state.getMaterial().blocksMovement())
            return 2;
        return 0;
    }

    private boolean isSafeBlock(BlockPos pos) {
        return blockKind(mc.world.getBlockState(pos)) == 1;
    }

    private void releaseClaim() {
        SilentAimUtil.setRotationCritical("Clutch", false);
        if (silentAimOwned) {
            SilentAimUtil.onDisable("Clutch");
            silentAimOwned = false;
        } else if (SilentAimUtil.isOwnedBy("Clutch")) {
            SilentAimUtil.onDisable("Clutch");
        }
    }

    private void restoreSlot() {
        if (previousSlot != -1 && returnToLastSlot.getValue() && mc.player != null && mc.player.inventory.currentItem != previousSlot) {
            mc.player.inventory.currentItem = previousSlot;
            if (mc.player.connection != null) {
                mc.player.connection.sendPacket(new CPacketHeldItemChange(previousSlot));
            }
        }
        previousSlot = -1;
    }
}
