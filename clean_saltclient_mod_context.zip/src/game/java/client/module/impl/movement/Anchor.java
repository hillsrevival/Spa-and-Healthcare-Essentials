package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;

public class Anchor extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Stop", "Stop", "Slow", "Reverse");

    public Anchor() {
        super("Anchor", Category.MOVEMENT);
        setDescription("Prevents knockback");
        addSetting(mode);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        switch(mode.getValue()) {
            case "Stop":
                mc.player.motionX = 0;
                mc.player.motionZ = 0;
                break;
            case "Slow":
                mc.player.motionX *= 0.1;
                mc.player.motionZ *= 0.1;
                break;
            case "Reverse":
                mc.player.motionX = -mc.player.motionX * 0.5;
                mc.player.motionZ = -mc.player.motionZ * 0.5;
                break;
        }
    }
}
