package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;

public class Spider extends Module {

    private final NumberSetting speed = new NumberSetting("Speed", 0.2, 0.05, 0.3);

    private final BooleanSetting smooth = new BooleanSetting("Smooth", false);

    private int tickTimer = 0;

    public Spider() {
        super("Spider", Category.MOVEMENT);
        setDescription("Climb walls like a spider");
        addSetting(speed);
        addSetting(smooth);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (!mc.player.isCollidedHorizontally)
            return;
        if (smooth.getValue()) {
            if (mc.player.movementInput.field_192832_b == 0 && mc.player.movementInput.moveStrafe == 0)
                return;
            tickTimer++;
            if (tickTimer % 2 != 0)
                return;
        }
        mc.player.motionY = speed.getValue().floatValue();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        tickTimer = 0;
    }
}
