package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;

public class Jesus extends Module {

    private final NumberSetting buoyancy = new NumberSetting("Buoyancy", 0.11, 0.04, 0.15);

    private final BooleanSetting bob = new BooleanSetting("Bob", false);

    private int tickTimer = 0;

    public Jesus() {
        super("Jesus", Category.MOVEMENT);
        setDescription("Walk on water");
        addSetting(buoyancy);
        addSetting(bob);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.gameSettings.keyBindSneak.isKeyDown())
            return;
        if (mc.player.isInWater()) {
            if (bob.getValue()) {
                tickTimer++;
                if (tickTimer % 3 == 0) {
                    mc.player.motionY = buoyancy.getValue().floatValue();
                }
            } else {
                mc.player.motionY = buoyancy.getValue().floatValue();
                tickTimer = 0;
            }
        } else if (!bob.getValue() && tickTimer < 3) {
            if (tickTimer == 0) {
                mc.player.motionY = buoyancy.getValue().floatValue() * 2.5f;
            } else if (tickTimer == 1) {
                mc.player.motionY = 0.0;
            }
            tickTimer++;
        } else if (bob.getValue()) {
            tickTimer = 0;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        tickTimer = 0;
    }
}
