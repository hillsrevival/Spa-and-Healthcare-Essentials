package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class KeepSprint extends Module {

    private final NumberSetting retainFactor = new NumberSetting("Retain Factor", 0.95, 0.6, 1.0);

    private boolean wasSprinting = false;

    public KeepSprint() {
        super("KeepSprint", Category.MOVEMENT);
        setDescription("Prevents losing sprint when attacking");
        addSetting(retainFactor);
        handles(HandlerType.ATTACK, HandlerType.UPDATE);
    }

    @Override
    public void onAttack(client.event.events.AttackEvent event) {
        if (mc.player == null)
            return;
        wasSprinting = mc.player.isSprinting();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (wasSprinting) {
            wasSprinting = false;
            if (!client.utils.combat.SprintPolicy.shouldMaintainSprint()) {
                return;
            }
            float forwardInput = mc.player.movementInput.field_192832_b;
            float required = 1.2F - 0.5F * retainFactor.getValue().floatValue();
            if (forwardInput >= required) {
                mc.player.setSprinting(true);
            }
        }
    }
}
