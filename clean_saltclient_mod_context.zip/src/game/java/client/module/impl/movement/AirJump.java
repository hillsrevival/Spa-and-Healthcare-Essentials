package client.module.impl.movement;

import net.minecraft.client.Minecraft;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;

public class AirJump extends Module {

    private static final float JUMP_VELOCITY = 0.42f;

    private boolean wasJumpPressed = false;

    public AirJump() {
        super("AirJump", Category.MOVEMENT);
        setDescription("Jump again while in the air");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        boolean jumpPressed = mc.gameSettings.keyBindJump.isKeyDown();
        if (jumpPressed && !wasJumpPressed) {
            if (!mc.player.onGround) {
                mc.player.motionY = JUMP_VELOCITY;
            }
        }
        wasJumpPressed = jumpPressed;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        wasJumpPressed = false;
    }
}
