package client.module.impl.movement;

import client.module.BooleanSetting;
import client.module.Category;
import client.module.HandlerType;
import client.module.Module;
import client.module.NumberSetting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;

/**
 * Aerial target-follow controller. It gently steers toward the nearest player and
 * steers into a steep dive when a mace approach is ready. Vanilla 1.12 has no
 * client action that forcibly stops an active Elytra glide; the server ends the
 * glide on collision/landing. The module therefore avoids sending a misleading
 * START_FALL_FLYING packet and instead prepares the dive while suppressing
 * immediate auto-redeploy attempts.
 */
public class ElytraFollow extends Module {

    private final NumberSetting targetRange = new NumberSetting("TargetRange", 48.0, 8.0, 96.0);
    private final NumberSetting steering = new NumberSetting("Steering", 0.055, 0.01, 0.18);
    private final NumberSetting turnSpeed = new NumberSetting("TurnSpeed", 16.0, 3.0, 45.0);
    private final NumberSetting minReleaseSpeed = new NumberSetting("ReleaseSpeed", 1.45, 0.4, 3.5);
    private final NumberSetting interceptTicks = new NumberSetting("InterceptTicks", 5.0, 2.0, 10.0);
    private final NumberSetting aboveRadius = new NumberSetting("AboveRadius", 1.5, 0.5, 4.0);
    private final NumberSetting aboveHeight = new NumberSetting("AboveHeight", 0.8, 0.2, 4.0);
    private final NumberSetting releaseCooldown = new NumberSetting("ReleaseCooldown", 18.0, 5.0, 50.0);
    private final BooleanSetting steer = new BooleanSetting("Steer", true);
    private final BooleanSetting release = new BooleanSetting("AutoUndeploy", true);

    private static int deployHoldTicks = 0;
    private int cooldownTicks = 0;
    private int lastReleaseTick = -1;
    private int lastTargetId = -1;

    public ElytraFollow() {
        super("ElytraFollow", Category.MOVEMENT);
        setDescription("Follows a nearby player while gliding and releases the elytra on a timed approach or directly above their head");
        interceptTicks.setStep(1.0);
        releaseCooldown.setStep(1.0);
        addSetting(targetRange);
        addSetting(steering);
        addSetting(turnSpeed);
        addSetting(minReleaseSpeed);
        addSetting(interceptTicks);
        addSetting(aboveRadius);
        addSetting(aboveHeight);
        addSetting(releaseCooldown);
        addSetting(steer);
        addSetting(release);
        handles(HandlerType.UPDATE, HandlerType.WORLD_CHANGE);
    }

    public static boolean shouldHoldAutoDeploy() {
        return deployHoldTicks > 0;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        cooldownTicks = 0;
        lastReleaseTick = -1;
        lastTargetId = -1;
        deployHoldTicks = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        deployHoldTicks = 0;
        cooldownTicks = 0;
        lastReleaseTick = -1;
        lastTargetId = -1;
    }

    @Override
    public void onWorldChange(client.event.events.WorldChangeEvent event) {
        deployHoldTicks = 0;
        cooldownTicks = 0;
        lastReleaseTick = -1;
        lastTargetId = -1;
    }

    @Override
    public void onUpdate() {
        if (deployHoldTicks > 0)
            deployHoldTicks--;
        if (cooldownTicks > 0)
            cooldownTicks--;
        if (!nullCheck())
            return;
        if (!mc.player.isElytraFlying())
            return;
        if (mc.currentScreen != null)
            return;

        EntityPlayer target = findTarget();
        if (target == null) {
            lastTargetId = -1;
            return;
        }
        lastTargetId = target.getEntityId();

        double dx = target.posX - mc.player.posX;
        double dz = target.posZ - mc.player.posZ;
        double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
        if (horizontalDistance < 0.001)
            horizontalDistance = 0.001;

        double targetHead = target.posY + target.height;
        boolean directlyAbove = mc.player.posY >= targetHead + aboveHeight.getValue()
                && horizontalDistance <= aboveRadius.getValue();
        double horizontalSpeed = Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ);
        double dirX = dx / horizontalDistance;
        double dirZ = dz / horizontalDistance;
        double closingSpeed = mc.player.motionX * dirX + mc.player.motionZ * dirZ;
        boolean speedReady = horizontalSpeed >= minReleaseSpeed.getValue()
                && closingSpeed > 0.25
                && horizontalDistance <= closingSpeed * interceptTicks.getValue();

        // Release before rotating when directly over the target: this avoids the
        // oscillating yaw correction that otherwise circles around their head.
        if (release.getValue() && cooldownTicks == 0 && (directlyAbove || speedReady)) {
            beginDive(target, dirX, dirZ);
            return;
        }

        if (steer.getValue()) {
            Vec3d aim = new Vec3d(target.posX + target.motionX * 2.0,
                    target.posY + target.height * 0.62 + target.motionY,
                    target.posZ + target.motionZ * 2.0);
            float[] desired = client.utils.movement.RotationUtils.getNeededRotations(aim);
            mc.player.rotationYaw = client.utils.movement.RotationUtils.limitAngleChange(
                    mc.player.rotationYaw, desired[0], turnSpeed.getValue().floatValue());
            mc.player.rotationPitch = client.utils.movement.RotationUtils.limitAngleChange(
                    mc.player.rotationPitch, desired[1], Math.max(2.0f, turnSpeed.getValue().floatValue() * 0.45f));

            double ax = dirX * steering.getValue();
            double az = dirZ * steering.getValue();
            double vx = mc.player.motionX + ax;
            double vz = mc.player.motionZ + az;
            double nextSpeed = Math.sqrt(vx * vx + vz * vz);
            double maxSpeed = Math.max(0.8, minReleaseSpeed.getValue() + 1.2);
            if (nextSpeed > maxSpeed) {
                double scale = maxSpeed / nextSpeed;
                vx *= scale;
                vz *= scale;
            }
            mc.player.motionX = vx;
            mc.player.motionZ = vz;
        }
    }

    private EntityPlayer findTarget() {
        EntityPlayer best = null;
        double bestDistance = targetRange.getValue();
        for (EntityPlayer player : mc.world.playerEntities) {
            if (player == null || player == mc.player || player.isDead || !player.isEntityAlive())
                continue;
            double distance = mc.player.getDistanceToEntity(player);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = player;
            }
        }
        return best;
    }

    private void beginDive(EntityPlayer target, double dirX, double dirZ) {
        if (mc.player == null || !mc.player.isElytraFlying())
            return;
        if (lastReleaseTick == mc.player.ticksExisted)
            return;
        lastReleaseTick = mc.player.ticksExisted;
        cooldownTicks = releaseCooldown.getValue().intValue();
        deployHoldTicks = Math.max(deployHoldTicks, cooldownTicks);

        // Aim steeply down the target line. A 1.12 client cannot directly cancel
        // fall-flying; this converts the old ineffective packet into a real dive
        // setup and lets vanilla/server collision logic end the glide naturally.
        float[] desired = client.utils.movement.RotationUtils.getNeededRotations(
                new Vec3d(target.posX, target.posY + target.height * 0.35, target.posZ));
        mc.player.rotationYaw = desired[0];
        mc.player.rotationPitch = Math.max(48.0f, Math.min(78.0f, desired[1]));
        double diveX = dirX * 0.035;
        double diveZ = dirZ * 0.035;
        mc.player.motionX += diveX;
        mc.player.motionZ += diveZ;
    }
}
