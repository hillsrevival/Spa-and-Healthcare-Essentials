package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class NoRotateSet extends Module {

    private final NumberSetting threshold = new NumberSetting("Threshold", 30.0, 5.0, 180.0);

    private float prevYaw;

    private float prevPitch;

    public NoRotateSet() {
        super("NoRotateSet", Category.MOVEMENT);
        setDescription("NoRotateSet");
        handles(HandlerType.UPDATE);
        addSetting(threshold);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player != null) {
            prevYaw = mc.player.rotationYaw;
            prevPitch = mc.player.rotationPitch;
        }
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        float yawDiff = Math.abs(mc.player.rotationYaw - prevYaw);
        float pitchDiff = Math.abs(mc.player.rotationPitch - prevPitch);
        float thresh = threshold.getValue().floatValue();
        if (yawDiff > thresh || pitchDiff > thresh) {
            mc.player.rotationYaw = prevYaw;
            mc.player.rotationPitch = prevPitch;
            return;
        }
        prevYaw = mc.player.rotationYaw;
        prevPitch = mc.player.rotationPitch;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        prevYaw = 0;
        prevPitch = 0;
    }
}
