package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class FastPlace extends Module {

    private final NumberSetting delay = new NumberSetting("Delay", 1.0, 0.0, 4.0);

    public FastPlace() {
        super("FastPlace", Category.MOVEMENT);
        setDescription("Removes block placement cooldown");
        addSetting(delay);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        mc.rightClickDelayTimer = delay.getValue().intValue();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        mc.rightClickDelayTimer = 4;
    }
}
