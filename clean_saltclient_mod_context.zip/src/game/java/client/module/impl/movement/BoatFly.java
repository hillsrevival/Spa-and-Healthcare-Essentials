package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityBoat;

public class BoatFly extends Module {

    private final NumberSetting upSpeed = new NumberSetting("Up Speed", 1.0, 0.1, 5.0);

    private final NumberSetting hSpeed = new NumberSetting("H Speed", 1.0, 0.1, 3.0);

    public BoatFly() {
        super("BoatFly", Category.MOVEMENT);
        setDescription("Fly using boat(ride a boat first)");
        addSetting(upSpeed);
        addSetting(hSpeed);
        handles(HandlerType.TICK);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        EntityBoat.boatFlyActive = true;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        EntityBoat.boatFlyActive = false;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            EntityBoat.boatFlyActive = false;
            return;
        }
        Entity riding = mc.player.getRidingEntity();
        if (!(riding instanceof EntityBoat)) {
            EntityBoat.boatFlyActive = false;
            return;
        }
        EntityBoat.boatFlyActive = true;
        double up = upSpeed.getValue();
        double hz = hSpeed.getValue();
        if (mc.gameSettings.keyBindJump.isKeyDown()) {
            riding.motionY = up;
        } else if (mc.gameSettings.keyBindSneak.isKeyDown()) {
            riding.motionY = -up;
        } else {
            riding.motionY = 0;
        }
        if (mc.player.moveForward != 0 || mc.player.moveStrafing != 0) {
            float yaw = mc.player.rotationYaw;
            double rad = Math.toRadians(yaw);
            double forwardX = -Math.sin(rad);
            double forwardZ = Math.cos(rad);
            double fwd = mc.player.moveForward;
            double str = mc.player.moveStrafing;
            double len = Math.sqrt(fwd * fwd + str * str);
            if (len > 0) {
                fwd /= len;
                str /= len;
            }
            riding.motionX = ((forwardX * fwd) + (-Math.cos(rad) * str)) * hz;
            riding.motionZ = ((forwardZ * fwd) + (Math.sin(rad) * str)) * hz;
        } else {
            riding.motionX = 0;
            riding.motionZ = 0;
        }
        riding.fallDistance = 0.0f;
        mc.player.fallDistance = 0.0f;
    }
}
