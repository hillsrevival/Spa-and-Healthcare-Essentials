package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.event.events.PacketOutputEvent;
import client.utils.world.PacketUtils;

public class Blink extends Module {

    private final NumberSetting limit = new NumberSetting("Limit", 0.0, 0.0, 500.0);

    private final java.util.ArrayDeque<net.minecraft.network.play.client.CPacketPlayer> packets = new java.util.ArrayDeque<net.minecraft.network.play.client.CPacketPlayer>();

    public Blink() {
        super("Blink", Category.MOVEMENT);
        setDescription("Buffers position packets and sends them at once for a teleport effect");
        addSetting(limit);
        handles(HandlerType.UPDATE, HandlerType.PACKET_OUTPUT);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (limit.getValue() > 0 && packets.size() >= limit.getValue()) {
            toggle();
        }
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        Object packet = event.getPacket();
        if (!(packet instanceof net.minecraft.network.play.client.CPacketPlayer))
            return;
        event.setCancelled(true);
        net.minecraft.network.play.client.CPacketPlayer cp = (net.minecraft.network.play.client.CPacketPlayer) packet;
        net.minecraft.network.play.client.CPacketPlayer prev = packets.peekLast();
        if (prev != null && cp.isOnGround() == prev.isOnGround() && cp.getX(-1) == prev.getX(-1) && cp.getY(-1) == prev.getY(-1) && cp.getZ(-1) == prev.getZ(-1)) {
            return;
        }
        packets.addLast(cp);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        packets.clear();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.player == null || mc.player.connection == null) {
            packets.clear();
            return;
        }
        for (net.minecraft.network.play.client.CPacketPlayer packet : packets) {
            PacketUtils.send(packet);
        }
        packets.clear();
    }
}
