package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class Fly extends Module {

    private final NumberSetting speed = new NumberSetting("Speed", 2.0, 0.5, 10.0);

    private boolean wasFlying = false;

    private boolean wasAllowFlying = false;

    private float oldFlySpeed = 0.05f;

    public Fly() {
        super("Fly", Category.MOVEMENT);
        setDescription("Allows you to fly in survival mode");
        addSetting(speed);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        mc.player.capabilities.isFlying = true;
        mc.player.capabilities.allowFlying = true;
        mc.player.capabilities.setFlySpeed(speed.getValue().floatValue() * 0.05f);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.player != null && mc.player.capabilities != null) {
            mc.player.capabilities.isFlying = wasFlying;
            mc.player.capabilities.allowFlying = wasAllowFlying;
            mc.player.capabilities.setFlySpeed(oldFlySpeed);
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player != null && mc.player.capabilities != null) {
            wasFlying = mc.player.capabilities.isFlying;
            wasAllowFlying = mc.player.capabilities.allowFlying;
            oldFlySpeed = mc.player.capabilities.getFlySpeed();
        }
    }
}
