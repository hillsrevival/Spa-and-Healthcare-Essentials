package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class NoWeb extends Module {

    private final NumberSetting multiplier = new NumberSetting("Multiplier", 0.0, 0.0, 1.0);

    public NoWeb() {
        super("NoWeb", Category.MOVEMENT);
        setDescription("Prevents being slowed down by cobwebs");
        addSetting(multiplier);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (!mc.player.isInWeb)
            return;
        if (multiplier.getValue() <= 0.0) {
            mc.player.isInWeb = false;
        } else {
            mc.player.isInWeb = false;
            double mult = multiplier.getValue();
            mc.player.motionX *= mult;
            mc.player.motionZ *= mult;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.player == null)
            return;
    }
}
