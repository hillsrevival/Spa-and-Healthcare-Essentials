package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.utils.world.WorldUtils;

public class ReverseStep extends Module {

    private final NumberSetting height = new NumberSetting("Height", 1.0, 0.5, 2.5);

    public ReverseStep() {
        super("ReverseStep", Category.MOVEMENT);
        setDescription("Pulls you backward quickly to dodge attacks");
        addSetting(height);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        if (mc.player.isSneaking() || mc.player.isInWater() || mc.player.isInLava())
            return;
        if (!mc.player.onGround || mc.player.isElytraFlying())
            return;
        double maxH = height.getValue().doubleValue();
        float yaw = mc.player.rotationYaw;
        double moveX = -Math.sin(Math.toRadians(yaw)) * 0.6;
        double moveZ = Math.cos(Math.toRadians(yaw)) * 0.6;
        int frontX = (int) Math.floor(mc.player.posX + moveX);
        int frontZ = (int) Math.floor(mc.player.posZ + moveZ);
        int feetY = (int) Math.floor(mc.player.posY);
        if (WorldUtils.isAir(new net.minecraft.util.math.BlockPos(frontX, feetY, frontZ))) {
            int dropDist = 0;
            for (int dy = 1; dy <= (int) maxH + 1; dy++) {
                if (!WorldUtils.isAir(new net.minecraft.util.math.BlockPos(frontX, feetY - dy, frontZ))) {
                    dropDist = dy - 1;
                    break;
                }
            }
            if (dropDist > 0 && dropDist <= (int) maxH) {
                double destX = mc.player.posX + moveX * 0.5;
                double destY = feetY - dropDist + 0.001;
                double destZ = mc.player.posZ + moveZ * 0.5;
                if (WorldUtils.isAir(new net.minecraft.util.math.BlockPos((int) Math.floor(destX), (int) Math.floor(destY), (int) Math.floor(destZ)))) {
                    mc.player.setPosition(destX, destY, destZ);
                }
            }
        }
    }
}
