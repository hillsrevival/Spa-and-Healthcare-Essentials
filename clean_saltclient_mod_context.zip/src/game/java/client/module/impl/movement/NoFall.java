package client.module.impl.movement;

import net.minecraft.network.play.client.CPacketPlayer;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.event.events.PacketOutputEvent;

public class NoFall extends Module {

    private final NumberSetting minFall = new NumberSetting("MinFall", 3.0, 0.5, 10.0);

    public NoFall() {
        super("NoFall", Category.MOVEMENT);
        setDescription("Tries to removes fall damage");
        addSetting(minFall);
        handles(HandlerType.PACKET_OUTPUT);
    }

    @Override
    public void onPacketOutput(PacketOutputEvent event) {
        if (!nullCheck())
            return;
        if (!(event.getPacket() instanceof CPacketPlayer))
            return;
        if (!shouldClaimGround())
            return;
        ((CPacketPlayer) event.getPacket()).setOnGround(true);
    }

    private boolean shouldClaimGround() {
        if (mc.player.onGround)
            return false;
        if (mc.player.motionY >= 0.0)
            return false;
        if (mc.player.fallDistance <= minFall.getValue().floatValue())
            return false;
        if (mc.player.isInWater())
            return false;
        if (mc.player.isOnLadder())
            return false;
        if (mc.player.isElytraFlying())
            return false;
        if (mc.player.capabilities != null && mc.player.capabilities.isFlying)
            return false;
        if (mc.player.isRiding())
            return false;
        return true;
    }
}
