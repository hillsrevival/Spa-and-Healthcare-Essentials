package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.init.MobEffects;

public class AntiLevitation extends Module {

    public AntiLevitation() {
        super("AntiLevitation", Category.MOVEMENT);
        setDescription("Removes the levitation effect when shot by a shulker");
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (mc.player.isPotionActive(MobEffects.LEVITATION)) {
            mc.player.motionY = Math.min(mc.player.motionY, -0.05);
        }
    }
}
