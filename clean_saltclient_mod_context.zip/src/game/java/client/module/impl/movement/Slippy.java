package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;

public class Slippy extends Module {

    private final NumberSetting slipperiness = new NumberSetting("Slip", 0.98, 0.6, 0.999);

    public Slippy() {
        super("Slippy", Category.MOVEMENT);
        setDescription("Makes all blocks slippery like ice");
        addSetting(slipperiness);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (mc.player.onGround) {
            float slip = slipperiness.getValue().floatValue();
            double vanillaGroundFriction = 0.546;
            double targetFriction = slip;
            double restoreRatio = targetFriction / vanillaGroundFriction;
            double speed = Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ);
            if (speed > 0.001) {
                mc.player.motionX *= restoreRatio;
                mc.player.motionZ *= restoreRatio;
            }
        }
    }
}
