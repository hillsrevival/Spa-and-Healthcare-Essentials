package client.module.impl.movement;

import client.Client;
import client.event.events.MotionEvent;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import net.minecraft.util.math.AxisAlignedBB;

public class SafeWalk extends Module {

    private boolean sneakOverride = false;

    public SafeWalk() {
        super("SafeWalk", Category.MOVEMENT);
        setDescription("Sneaks at block edges");
        handles(HandlerType.MOTION);
    }

    @Override
    public void onMotion(MotionEvent event) {
        if (!nullCheck())
            return;
        if (event.getEntity() != mc.player)
            return;
        if (event.isPost()) {
            if (sneakOverride) {
                mc.player.movementInput.sneak = mc.gameSettings.keyBindSneak.isKeyDown();
                sneakOverride = false;
            }
            return;
        }
        if (sneakOverride)
            return;
        if (Client.INSTANCE.freecamActive)
            return;
        if (mc.player.isRiding())
            return;
        if (!mc.player.onGround)
            return;
        if (mc.player.movementInput.sneak)
            return;
        double mx = event.getX();
        double mz = event.getZ();
        if (mx == 0.0D && mz == 0.0D)
            return;
        if (wouldLeaveSupport(mx, mz)) {
            mc.player.movementInput.sneak = true;
            sneakOverride = true;
        }
    }

    private boolean wouldLeaveSupport(double mx, double mz) {
        if (mx != 0.0D && leavesSupport(mx, 0.0D))
            return true;
        if (mz != 0.0D && leavesSupport(0.0D, mz))
            return true;
        if (mx != 0.0D && mz != 0.0D && leavesSupport(mx, mz))
            return true;
        return false;
    }

    private boolean leavesSupport(double mx, double mz) {
        AxisAlignedBB test = mc.player.getEntityBoundingBox().offset(mx, -mc.player.stepHeight, mz);
        return mc.world.getCollisionBoxes(mc.player, test).isEmpty();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (sneakOverride && mc.player != null) {
            mc.player.movementInput.sneak = mc.gameSettings.keyBindSneak.isKeyDown();
            sneakOverride = false;
        }
    }
}
