package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;

public class SpeedHack extends Module {

    private final NumberSetting boost = new NumberSetting("Boost", 1.3, 1.0, 2.0);

    private final NumberSetting jumpBoost = new NumberSetting("Jump Boost", 0.08, 0.04, 0.15);

    private final BooleanSetting vanillaStrafe = new BooleanSetting("Vanilla Strafe", true);

    private final BooleanSetting noHop = new BooleanSetting("NoHop", false);

    public SpeedHack() {
        super("SpeedHack", Category.MOVEMENT);
        setDescription("Increases movement speed");
        addSetting(boost);
        addSetting(jumpBoost);
        addSetting(vanillaStrafe);
        addSetting(noHop);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (mc.player.isSneaking())
            return;
        if (mc.player.moveForward == 0 && mc.player.moveStrafing == 0)
            return;
        if (mc.player.isInWater() || mc.player.isInLava())
            return;
        if (noHop.getValue()) {
            if (mc.player.moveForward > 0 && mc.player.onGround) {
                float mult = (float) (double) boost.getValue();
                mc.player.motionX *= mult;
                mc.player.motionZ *= mult;
                double currentSpeed = Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ);
                double maxSpeed = 0.34;
                if (currentSpeed > maxSpeed) {
                    mc.player.motionX = mc.player.motionX / currentSpeed * maxSpeed;
                    mc.player.motionZ = mc.player.motionZ / currentSpeed * maxSpeed;
                }
            }
            return;
        }
        if (mc.player.onGround) {
            float jBoost = (float) (double) jumpBoost.getValue();
            mc.player.motionY += jBoost;
            float speedMult = (float) (double) boost.getValue();
            mc.player.motionX *= speedMult;
            mc.player.motionZ *= speedMult;
            double maxSpeed = 0.62;
            double maxSpeedSq = maxSpeed * maxSpeed;
            double currentSpeedSq = mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ;
            if (currentSpeedSq > maxSpeedSq) {
                double currentSpeed = Math.sqrt(currentSpeedSq);
                mc.player.motionX = mc.player.motionX / currentSpeed * maxSpeed;
                mc.player.motionZ = mc.player.motionZ / currentSpeed * maxSpeed;
            }
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }
}
