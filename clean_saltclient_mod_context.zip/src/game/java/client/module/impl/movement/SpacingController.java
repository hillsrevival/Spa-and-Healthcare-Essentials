package client.module.impl.movement;

import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.utils.combat.CombatContext;
import client.utils.movement.MovementInputHelper;
import client.utils.movement.MovementUtils;
import net.minecraft.entity.EntityLivingBase;

public class SpacingController extends Module {

    private final NumberSetting targetDistance = new NumberSetting("Target Distance", 2.7, 1.5, 3.2);

    private final NumberSetting tolerance = new NumberSetting("Tolerance", 0.4, 0.1, 1.0);

    private final ModeSetting strafeMode = new ModeSetting(// FIX: was "Circle", caused unwanted movement
    "Strafe Mode", "Off", "Off", "Circle", "Figure-8", "Adaptive");

    private final NumberSetting strafeSpeed = new NumberSetting("Strafe Speed", 1.0, 0.5, 2.0);

    private final BooleanSetting manageForward = new BooleanSetting("Manage Forward", false);

    private final BooleanSetting onlyWhenTargeted = new BooleanSetting("Only When Targeted", true);

    private final BooleanSetting pauseOnAttack = new BooleanSetting("Pause On Attack", true);

    private final NumberSetting pauseTicks = new NumberSetting("Pause Ticks", 1.0, 1.0, 5.0);

    private final BooleanSetting proportionalPulses = new BooleanSetting("Proportional Pulses", true);

    private final BooleanSetting cooldownSync = new BooleanSetting("Cooldown Sync", false);

    private int strafeTick = 0;

    private int strafeDir = 1;

    private int ticksSinceAttack = 999;

    private boolean weSetStrafe = false;

    private boolean weSetForward = false;

    private final client.utils.movement.MovementKeySnapshot keySnapshot = new client.utils.movement.MovementKeySnapshot();

    private int forwardPulseRemaining = 0;

    private int backPulseRemaining = 0;

    public SpacingController() {
        super("SpacingController", Category.MOVEMENT);
        setDescription("Maintains ideal spacing from the target");
        addSetting(targetDistance);
        addSetting(tolerance);
        addSetting(strafeMode);
        addSetting(strafeSpeed);
        addSetting(manageForward);
        addSetting(onlyWhenTargeted);
        addSetting(pauseOnAttack);
        addSetting(pauseTicks);
        addSetting(proportionalPulses);
        addSetting(cooldownSync);
        handles(HandlerType.ATTACK, HandlerType.UPDATE);
    }

    @Override
    public void onAttack(client.event.events.AttackEvent event) {
        ticksSinceAttack = 0;
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        ticksSinceAttack++;
        EntityLivingBase target = CombatContext.getTarget();
        if (target == null || !target.isEntityAlive()) {
            releaseOurKeys();
            client.utils.movement.MovementInputLock.forceUnlock();
            return;
        }
        if (onlyWhenTargeted.getValue() && CombatContext.getTarget() == null) {
            releaseOurKeys();
            return;
        }
        if (pauseOnAttack.getValue() && ticksSinceAttack <= (int) (double) pauseTicks.getValue()) {
            releaseOurKeys();
            return;
        }
        if (mc.currentScreen != null) {
            releaseOurKeys();
            return;
        }
        if (mc.player.isSneaking()) {
            releaseOurKeys();
            return;
        }
        if (!mc.player.onGround && mc.player.hurtTime <= 0) {
            releaseOurKeys();
            return;
        }
        client.utils.movement.MovementInputLock.lock("SpacingController");
        if (manageForward.getValue()) {
            manageForwardBackWithHelper(target);
        }
        String sm = strafeMode.getValue();
        if (!sm.equals("Off")) {
            boolean userMovingForward = mc.gameSettings.keyBindForward.isKeyDown();
            if (userMovingForward) {
                int dir = computeStrafeDirection(sm);
                if (dir != 0) {
                    MovementUtils.holdLeft(dir < 0);
                    MovementUtils.holdRight(dir > 0);
                    weSetStrafe = true;
                } else {
                    if (weSetStrafe) {
                        MovementUtils.holdLeft(false);
                        MovementUtils.holdRight(false);
                        weSetStrafe = false;
                    }
                }
            } else {
                if (weSetStrafe) {
                    MovementUtils.holdLeft(false);
                    MovementUtils.holdRight(false);
                    weSetStrafe = false;
                }
            }
        } else {
            if (weSetStrafe) {
                MovementUtils.holdLeft(false);
                MovementUtils.holdRight(false);
                weSetStrafe = false;
            }
        }
    }

    private void manageForwardBack(EntityLivingBase target) {
        if (forwardPulseRemaining > 0) {
            forwardPulseRemaining--;
            if (forwardPulseRemaining == 0) {
                MovementUtils.holdForward(keySnapshot.savedForward());
                weSetForward = false;
            }
        }
        if (backPulseRemaining > 0) {
            backPulseRemaining--;
            if (backPulseRemaining == 0) {
                MovementUtils.holdBack(keySnapshot.savedBack());
                weSetForward = false;
            }
        }
        if (forwardPulseRemaining > 0 || backPulseRemaining > 0)
            return;
        double distance = client.utils.combat.CombatUtils.getReachDistance(target);
        double target_ = targetDistance.getValue();
        double tol = tolerance.getValue();
        if (distance > target_ + tol) {
            if (!mc.gameSettings.keyBindForward.isKeyDown()) {
                keySnapshot.clearForward();
                MovementUtils.holdForward(true);
                weSetForward = true;
                forwardPulseRemaining = 2;
            }
        } else if (distance < target_ - tol) {
            if (!mc.gameSettings.keyBindBack.isKeyDown() && !mc.gameSettings.keyBindForward.isKeyDown()) {
                keySnapshot.clearBack();
                MovementUtils.holdBack(true);
                weSetForward = true;
                backPulseRemaining = 2;
            }
        }
    }

    private void manageForwardBackWithHelper(EntityLivingBase target) {
        if (forwardPulseRemaining > 0) {
            forwardPulseRemaining--;
            if (forwardPulseRemaining == 0) {
                restoreSavedKeys();
                weSetForward = false;
            }
        }
        if (backPulseRemaining > 0) {
            backPulseRemaining--;
            if (backPulseRemaining == 0) {
                restoreSavedKeys();
                weSetForward = false;
            }
        }
        if (forwardPulseRemaining > 0 || backPulseRemaining > 0)
            return;
        double distance = client.utils.combat.CombatUtils.getReachDistance(target);
        double target_ = targetDistance.getValue();
        double tol = tolerance.getValue();
        if (cooldownSync.getValue() && CombatContext.getTarget() != null) {
            double swingEdge = target_ + tol;
            double reachCap = client.utils.combat.ReachBalancer.getEffectiveReach(target) - 0.15;
            if (reachCap < 1.0)
                reachCap = 1.0;
            if (swingEdge > reachCap)
                swingEdge = reachCap;
            if (CombatContext.isMyCooldownReady() && distance <= swingEdge) {
            } else if (!CombatContext.isOpponentCooldownReady() && distance < swingEdge) {
                double shortfall = swingEdge - distance;
                int ticks = proportionalPulses.getValue() ? computePulseTicks(shortfall) : 2;
                if (shortfall > tol * 0.5 && ticks >= 1) {
                    pulseAwayFromTarget(target, ticks);
                    return;
                }
            }
        }
        if (distance > target_ + tol) {
            if (!mc.gameSettings.keyBindForward.isKeyDown()) {
                double error = distance - (target_ + tol);
                int ticks = proportionalPulses.getValue() ? computePulseTicks(error) : 2;
                pulseTowardTarget(target, ticks);
            }
        } else if (distance < target_ - tol) {
            if (!mc.gameSettings.keyBindBack.isKeyDown() && !mc.gameSettings.keyBindForward.isKeyDown()) {
                double error = (target_ - tol) - distance;
                int ticks = proportionalPulses.getValue() ? computePulseTicks(error) : 2;
                pulseAwayFromTarget(target, ticks);
            }
        }
    }

    private int computePulseTicks(double errorBlocks) {
        if (errorBlocks <= 0)
            return 0;
        double accel = 0.1;
        if (mc.player != null) {
            accel = Math.max(0.1, mc.player.getAIMoveSpeed());
        }
        double perTick = accel / (1.0 - 0.546);
        if (perTick < 0.22)
            perTick = 0.22;
        if (perTick > 0.30)
            perTick = 0.30;
        int ticks = (int) Math.ceil(errorBlocks / perTick);
        if (ticks < 1)
            ticks = 1;
        if (ticks > 4)
            ticks = 4;
        return ticks;
    }

    private void pulseTowardTarget(EntityLivingBase target, int ticks) {
        keySnapshot.clearBack();
        double offsetX = target.posX - mc.player.posX;
        double offsetZ = target.posZ - mc.player.posZ;
        saveUserKeys();
        MovementInputHelper.applyDirectionalMovement(offsetX, offsetZ);
        weSetForward = true;
        forwardPulseRemaining = ticks;
    }

    private void pulseAwayFromTarget(EntityLivingBase target, int ticks) {
        keySnapshot.clearBack();
        double offsetX = mc.player.posX - target.posX;
        double offsetZ = mc.player.posZ - target.posZ;
        saveUserKeys();
        MovementInputHelper.applyDirectionalMovement(offsetX, offsetZ);
        weSetForward = true;
        backPulseRemaining = ticks;
    }

    private void saveUserKeys() {
        keySnapshot.save();
    }

    private void restoreSavedKeys() {
        keySnapshot.restore();
    }

    private int computeStrafeDirection(String mode) {
        if (mode.equals("Circle")) {
            strafeTick++;
            if (strafeTick > 40 + (int) (Math.random() * 20)) {
                strafeDir = -strafeDir;
                strafeTick = 0;
            }
            return strafeDir;
        }
        if (mode.equals("Figure-8")) {
            strafeTick++;
            double t = strafeTick * 0.05 * strafeSpeed.getValue();
            double sin = Math.sin(t);
            if (sin > 0.1)
                return 1;
            if (sin < -0.1)
                return -1;
            return 0;
        }
        if (mode.equals("Adaptive")) {
            EntityLivingBase target = CombatContext.getTarget();
            if (target == null)
                return 0;
            double dx = target.posX - mc.player.posX;
            double dz = target.posZ - mc.player.posZ;
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 0.1)
                return strafeDir;
            double perpX = -dz / len;
            double perpZ = dx / len;
            double dot = target.motionX * perpX + target.motionZ * perpZ;
            if (dot > 0.02)
                return 1;
            if (dot < -0.02)
                return -1;
            return strafeDir;
        }
        return 0;
    }

    private void releaseOurKeys() {
        if (weSetStrafe) {
            MovementUtils.holdLeft(false);
            MovementUtils.holdRight(false);
            weSetStrafe = false;
        }
        if (weSetForward) {
            restoreSavedKeys();
            weSetForward = false;
            forwardPulseRemaining = 0;
            backPulseRemaining = 0;
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        strafeTick = 0;
        strafeDir = 1;
        ticksSinceAttack = 999;
        weSetStrafe = false;
        weSetForward = false;
        keySnapshot.clearForward();
        keySnapshot.clearBack();
        keySnapshot.clearLeft();
        keySnapshot.clearRight();
        forwardPulseRemaining = 0;
        backPulseRemaining = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        releaseOurKeys();
    }
}
