package client.module.impl.chat;

import client.event.listeners.ChatInputListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.ChatUtils;
import net.minecraft.client.Minecraft;

public class Home extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private int disableTimer;

    public Home() {
        super("/home", Category.CHAT);
        setDescription("Types/home in chat when you click the module");
        handles(HandlerType.UPDATE, HandlerType.CHAT_INPUT);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        disableTimer = 0;
    }

    @Override
    public void onDisable() {
        disableTimer = 0;
        super.onDisable();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (disableTimer >= 4) {
            toggle();
        } else if (disableTimer == 0) {
            mc.player.sendChatMessage("/home");
        }
        disableTimer++;
    }

    @Override
    public void onChatInput(ChatInputListener.ChatInputEvent event) {
        if (event.getComponent() == null)
            return;
        String message = event.getComponent().getUnformattedText();
        if (message.contains("[galactic]"))
            return;
        String lower = message.toLowerCase();
        if (lower.contains("/help") || lower.contains("permission")) {
            event.setCancelled(true);
            ChatUtils.error("This server doesn't have /home.");
        }
    }
}
