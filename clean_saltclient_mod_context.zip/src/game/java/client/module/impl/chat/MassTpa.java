package client.module.impl.chat;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.util.StringUtils;
import client.event.listeners.ChatInputListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.utils.misc.ChatUtils;

public class MassTpa extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final Random random = new Random();

    private final ArrayList<String> players = new ArrayList<String>();

    private int index;

    private int timer;

    public MassTpa() {
        super("MassTpa", Category.CHAT);
        setDescription("Sends teleport requests to all players via /tpa");
        handles(HandlerType.UPDATE, HandlerType.CHAT_INPUT);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        index = 0;
        timer = -1;
        players.clear();
        if (mc.player == null || mc.getConnection() == null) {
            ChatUtils.error("Not connected to a server.");
            toggle();
            return;
        }
        Collection<NetworkPlayerInfo> infoMap = mc.getConnection().getPlayerInfoMap();
        for (NetworkPlayerInfo info : infoMap) {
            String name = info.getGameProfile().getName();
            name = StringUtils.stripControlCodes(name);
            if (name.equals(mc.player.getName()))
                continue;
            players.add(name);
        }
        Collections.shuffle(players, random);
        if (players.isEmpty()) {
            ChatUtils.error("Couldn't find any players.");
            toggle();
            return;
        }
        ChatUtils.message("MassTpa: Sending TPA to " + players.size() + " players...");
    }

    @Override
    public void onDisable() {
        players.clear();
        index = 0;
        timer = -1;
        super.onDisable();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null)
            return;
        if (timer > -1) {
            timer--;
            return;
        }
        if (index >= players.size()) {
            ChatUtils.message("MassTpa: TPA sent to all " + players.size() + " players!");
            toggle();
            return;
        }
        mc.player.sendChatMessage("/tpa " + players.get(index));
        ChatUtils.message("Sent TPA to " + players.get(index) + " (" + (index + 1) + "/" + players.size() + ")");
        index++;
        timer = 20;
    }

    @Override
    public void onChatInput(ChatInputListener.ChatInputEvent event) {
        if (event.getComponent() == null)
            return;
        String message = event.getComponent().getUnformattedText().toLowerCase();
        if (message.contains("[galactic]"))
            return;
        if (message.contains("/help") || message.contains("permission")) {
            event.setCancelled(true);
            ChatUtils.error("This server doesn't have TPA.");
            toggle();
            return;
        }
        if ((message.contains("accepted") && message.contains("request")) || (message.contains("teleport") && message.contains("accepted"))) {
            event.setCancelled(true);
            ChatUtils.message("Someone accepted your TPA request. Stopping.");
            toggle();
            return;
        }
    }
}
