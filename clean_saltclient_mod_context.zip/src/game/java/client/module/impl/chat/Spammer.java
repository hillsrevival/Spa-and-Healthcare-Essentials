package client.module.impl.chat;

import net.minecraft.client.Minecraft;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.NumberSetting;
import client.module.ModeSetting;
import client.utils.misc.ChatUtils;

public class Spammer extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final NumberSetting delay = new NumberSetting("Delay", 3.0, 1.0, 10.0);

    private final ModeSetting message = new ModeSetting("Message", "SaltClient ON TOP", "SaltClient is the best 1.12.2 client!", "Join SaltClient - the ultimate 1.12.2 experience", "SaltClient ON TOP", "L + Ratio + SaltClient Wins", "ez gg no re - SaltClient");

    private int tickCounter = 0;

    public Spammer() {
        super("Spammer", Category.CHAT);
        setDescription("Repeats a chat message(configurable)");
        addSetting(delay);
        addSetting(message);
        handles(HandlerType.UPDATE);
    }

    @Override
    public void onUpdate() {
        if (!nullCheck())
            return;
        tickCounter++;
        int delayTicks = delay.getValue().intValue() * 20;
        if (tickCounter < delayTicks)
            return;
        tickCounter = 0;
        String msg = message.getValue();
        try {
            mc.player.sendChatMessage(msg);
        } catch (Exception e) {
            if (mc.ingameGUI != null && mc.ingameGUI.getChatGUI() != null) {
                mc.ingameGUI.getChatGUI().printChatMessage(new TextComponentString(msg));
            }
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        tickCounter = 0;
        ChatUtils.message("Spammer enabled (delay: " + delay.getValue().intValue() + "s)");
    }

    @Override
    public void onDisable() {
        ChatUtils.message("Spammer disabled");
        super.onDisable();
        tickCounter = 0;
    }
}
