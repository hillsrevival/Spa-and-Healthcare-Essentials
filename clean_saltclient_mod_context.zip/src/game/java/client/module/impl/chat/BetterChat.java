package client.module.impl.chat;

import client.event.listeners.ChatOutputListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import net.minecraft.client.Minecraft;

public class BetterChat extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final BooleanSetting antiSpam = new BooleanSetting("Anti Spam", true);

    private final NumberSetting stackDelay = new NumberSetting("Stack Delay", 5, 1, 30);

    private final java.util.LinkedHashMap<String, Long> messageTimes = new java.util.LinkedHashMap<>();

    private final java.util.LinkedHashMap<String, Integer> messageCounts = new java.util.LinkedHashMap<>();

    public BetterChat() {
        super("BetterChat", Category.CHAT);
        setDescription("Custom chat background, font size, and more");
        addSetting(antiSpam);
        addSetting(stackDelay);
        handles(HandlerType.CHAT_OUTPUT);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        messageTimes.clear();
        messageCounts.clear();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        messageTimes.clear();
        messageCounts.clear();
    }

    @Override
    public void onChatOutput(ChatOutputListener.ChatOutputEvent event) {
        if (!antiSpam.getValue())
            return;
        String message = event.getMessage();
        if (message == null)
            return;
        long now = System.currentTimeMillis();
        long delayMs = stackDelay.getValue().longValue() * 1000;
        messageTimes.entrySet().removeIf(e -> now - e.getValue() > delayMs);
        if (messageTimes.containsKey(message)) {
            long lastTime = messageTimes.get(message);
            if (now - lastTime < delayMs) {
                int count = messageCounts.getOrDefault(message, 1) + 1;
                messageCounts.put(message, count);
                event.setCancelled(true);
                return;
            }
        }
        messageTimes.put(message, now);
    }
}
