package client.module.impl.chat;

import client.event.listeners.ChatOutputListener;
import client.module.Category;
import client.module.Module;
import client.module.HandlerType;
import client.module.ModeSetting;
import net.minecraft.client.Minecraft;

public class FancyChat extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();

    private final ModeSetting mode = new ModeSetting("Mode", "Rainbow", "Rainbow", "Bold", "Italic", "Magic");

    public FancyChat() {
        super("FancyChat", Category.CHAT);
        setDescription("Adds formatting codes and Unicode to chat messages");
        addSetting(mode);
        handles(HandlerType.CHAT_OUTPUT);
    }

    @Override
    public void onChatOutput(ChatOutputListener.ChatOutputEvent event) {
        if (event.isAutomatic())
            return;
        String message = event.getMessage();
        if (message.startsWith("/"))
            return;
        String formatted;
        switch(mode.getValue()) {
            case "Rainbow":
                formatted = applyRainbow(message);
                break;
            case "Bold":
                formatted = "\u00a7l" + message;
                break;
            case "Italic":
                formatted = "\u00a7o" + message;
                break;
            case "Magic":
                formatted = applyMagic(message);
                break;
            default:
                formatted = applyRainbow(message);
                break;
        }
        event.setMessage(formatted);
    }

    private String applyRainbow(String message) {
        String[] colors = { "\u00a7c", "\u00a76", "\u00a7e", "\u00a7a", "\u00a79", "\u00a75", "\u00a7d", "\u00a7b" };
        StringBuilder fancy = new StringBuilder();
        for (int i = 0; i < message.length(); i++) {
            fancy.append(colors[i % colors.length]);
            fancy.append(message.charAt(i));
        }
        return fancy.toString();
    }

    private String applyMagic(String message) {
        String[] colors = { "\u00a7c", "\u00a76", "\u00a7e", "\u00a7a", "\u00a79", "\u00a75", "\u00a7d", "\u00a7b", "\u00a7f", "\u00a77", "\u00a78" };
        StringBuilder fancy = new StringBuilder();
        for (int i = 0; i < message.length(); i++) {
            fancy.append(colors[i % colors.length]);
            fancy.append("\u00a7k");
            fancy.append(message.charAt(i));
        }
        return fancy.toString();
    }
}
