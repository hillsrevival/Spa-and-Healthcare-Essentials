package client.module;

import java.util.EnumSet;
import java.util.Set;
import client.event.Event;
import client.event.Listener;
import client.event.events.TickEvent;
import client.event.events.MotionEvent;
import client.event.events.PacketInputEvent;
import client.event.events.PacketOutputEvent;
import client.event.events.PlayerMoveEvent;
import client.event.events.SetOpaqueCubeEvent;
import client.event.events.ShouldSideBeRenderedEvent;
import client.event.events.AttackEvent;
import client.event.events.RenderFirstPersonItemEvent;
import client.event.events.PotionEffectCheckEvent;
import client.event.events.SetSprintingEvent;
import client.event.events.FogDensityEvent;
import client.event.events.EntityJoinWorldEvent;
import client.event.events.PreRenderLivingEvent;
import client.event.events.PostRenderLivingEvent;
import client.event.events.PlaySoundAtEntityEvent;
import client.event.events.WorldChangeEvent;
import client.event.events.MoveEvent;
import client.event.events.StepEvent;
import client.event.events.NameFormatEvent;
import client.event.events.WindowClickEvent;
import client.event.listeners.CameraTransformViewBobbingListener;
import client.event.listeners.ChatInputListener;
import client.event.listeners.ChatOutputListener;
import client.event.listeners.DeathListener;
import client.event.listeners.GUIRenderListener;
import client.event.listeners.GetAmbientOcclusionLightValueListener;
import client.event.listeners.KeyPressListener;
import client.event.listeners.LeftClickListener;
import client.event.listeners.PlayerMoveListener;
import client.event.listeners.PostUpdateListener;
import client.event.listeners.RenderBlockModelListener;
import client.event.listeners.RenderListener;
import client.event.listeners.RenderTileEntityListener;
import client.event.listeners.RightClickListener;
import client.event.listeners.SetOpaqueCubeListener;
import client.event.listeners.ShouldSideBeRenderedListener;
import client.event.listeners.UpdateListener;

@SuppressWarnings("unchecked")
public enum HandlerType {

    TICK(TickEvent.class),
    MOTION(MotionEvent.class),
    PACKET_INPUT(PacketInputEvent.class),
    PACKET_OUTPUT(PacketOutputEvent.class),
    CHAT_OUTPUT(ChatOutputListener.ChatOutputEvent.class),
    CHAT_INPUT(ChatInputListener.ChatInputEvent.class),
    RENDER(RenderListener.RenderEvent.class),
    KEY_PRESS(KeyPressListener.KeyPressEvent.class),
    LEFT_CLICK(LeftClickListener.LeftClickEvent.class),
    RIGHT_CLICK(RightClickListener.RightClickEvent.class),
    PLAYER_MOVE(PlayerMoveListener.PlayerMoveEvent.class),
    DEATH(DeathListener.DeathEvent.class),
    SHOULD_SIDE_BE_RENDERED(ShouldSideBeRenderedListener.ShouldSideBeRenderedEvent.class),
    SET_OPAQUE_CUBE(SetOpaqueCubeListener.SetOpaqueCubeEvent.class),
    RENDER_BLOCK_MODEL(RenderBlockModelListener.RenderBlockModelEvent.class),
    RENDER_TILE_ENTITY(RenderTileEntityListener.RenderTileEntityEvent.class),
    CAMERA_VIEW_BOB(CameraTransformViewBobbingListener.CameraTransformViewBobbingEvent.class),
    GUI_RENDER(GUIRenderListener.GUIRenderEvent.class),
    POST_UPDATE(PostUpdateListener.PostUpdateEvent.class),
    UPDATE(UpdateListener.UpdateEvent.class),
    AO_LIGHT(GetAmbientOcclusionLightValueListener.GetAmbientOcclusionLightValueEvent.class),
    ATTACK(AttackEvent.class),
    RENDER_FIRST_PERSON_ITEM(RenderFirstPersonItemEvent.class),
    POTION_EFFECT_CHECK(PotionEffectCheckEvent.class),
    SET_SPRINTING(SetSprintingEvent.class),
    FOG_DENSITY(FogDensityEvent.class),
    ENTITY_JOIN_WORLD(EntityJoinWorldEvent.class),
    PRE_RENDER_LIVING(PreRenderLivingEvent.class),
    POST_RENDER_LIVING(PostRenderLivingEvent.class),
    PLAY_SOUND(PlaySoundAtEntityEvent.class),
    WORLD_CHANGE(WorldChangeEvent.class),
    MOVE(MoveEvent.class),
    STEP(StepEvent.class),
    NAME_FORMAT(NameFormatEvent.class),
    WINDOW_CLICK(WindowClickEvent.class);

    private final Class<? extends Event> eventType;

    public static final Set<HandlerType> ALL = EnumSet.allOf(HandlerType.class);

    HandlerType(Class<? extends Event> eventType) {
        this.eventType = eventType;
    }

    public Class<? extends Event> getEventType() {
        return eventType;
    }
}
