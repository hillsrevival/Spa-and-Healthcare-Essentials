package client.module;

public enum Category {

    BLOCKS,
    COMBAT,
    MACE,
    MOVEMENT,
    RENDER,
    CHAT,
    FUN,
    ITEMS,
    RETRO,
    OTHER,
    NON_HACK
}
