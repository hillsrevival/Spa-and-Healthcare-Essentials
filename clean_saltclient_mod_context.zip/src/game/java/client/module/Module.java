package client.module;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import client.Client;
import client.event.Event;
import client.event.Listener;
import client.utils.StrProt;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import client.event.events.TickEvent;
import client.event.events.MotionEvent;
import client.event.events.PacketInputEvent;
import client.event.events.PacketOutputEvent;
import client.event.events.PlayerMoveEvent;
import client.event.events.SetOpaqueCubeEvent;
import client.event.events.ShouldSideBeRenderedEvent;
import client.event.events.AttackEvent;
import client.event.events.RenderFirstPersonItemEvent;
import client.event.events.PotionEffectCheckEvent;
import client.event.events.SetSprintingEvent;
import client.event.events.FogDensityEvent;
import client.event.events.EntityJoinWorldEvent;
import client.event.events.PreRenderLivingEvent;
import client.event.events.PostRenderLivingEvent;
import client.event.events.PlaySoundAtEntityEvent;
import client.event.events.WorldChangeEvent;
import client.event.events.MoveEvent;
import client.event.events.StepEvent;
import client.event.events.NameFormatEvent;
import client.event.events.WindowClickEvent;
import client.event.listeners.CameraTransformViewBobbingListener;
import client.event.listeners.ChatInputListener;
import client.event.listeners.ChatOutputListener;
import client.event.listeners.DeathListener;
import client.event.listeners.GUIRenderListener;
import client.event.listeners.GetAmbientOcclusionLightValueListener;
import client.event.listeners.KeyPressListener;
import client.event.listeners.LeftClickListener;
import client.event.listeners.PacketInputListener;
import client.event.listeners.PacketOutputListener;
import client.event.listeners.PlayerMoveListener;
import client.event.listeners.PostUpdateListener;
import client.event.listeners.RenderBlockModelListener;
import client.event.listeners.RenderListener;
import client.event.listeners.RenderTileEntityListener;
import client.event.listeners.RightClickListener;
import client.event.listeners.SetOpaqueCubeListener;
import client.event.listeners.ShouldSideBeRenderedListener;
import client.event.listeners.UpdateListener;

public abstract class Module {

    protected final Minecraft mc = Minecraft.getMinecraft();

    private final String name;

    private final Category category;

    private String description = "";

    private boolean toggled;

    private int key = -1;

    private boolean hiddenInGUI = false;

    private boolean favorite = false;

    private final List<Setting<?>> settings = new ArrayList<>();

    private client.utils.render.HudElement hudElement = null;

    private ColorSetting moduleColor;

    private long lastUsedTime = 0;

    private static volatile long toggleCounter = 0;

    public static long getToggleCounter() {
        return toggleCounter;
    }

    private static boolean suppressToggleNotifications = false;

    private Set<HandlerType> declaredHandlers = null;

    protected void handles(HandlerType... types) {
        if (declaredHandlers == null) {
            declaredHandlers = EnumSet.noneOf(HandlerType.class);
        }
        for (HandlerType t : types) {
            declaredHandlers.add(t);
        }
    }

    private Set<HandlerType> getEffectiveHandlers() {
        return declaredHandlers != null ? declaredHandlers : HandlerType.ALL;
    }

    private static float defaultHueForCategory(Category cat) {
        switch(cat) {
            case COMBAT:
                return 0.0f;
            case MACE:
                return 195.0f;
            case MOVEMENT:
                return 120.0f;
            case RENDER:
                return 210.0f;
            case BLOCKS:
                return 45.0f;
            case CHAT:
                return 180.0f;
            case FUN:
                return 300.0f;
            case ITEMS:
                return 30.0f;
            case RETRO:
                return 270.0f;
            case OTHER:
                return 60.0f;
            case NON_HACK:
                return 160.0f;
            default:
                return 0.0f;
        }
    }

    public Module(String name, Category category) {
        this.name = StrProt.x(name);
        this.category = category;
        this.toggled = false;
        this.moduleColor = new ColorSetting(StrProt.x("Color"), defaultHueForCategory(category));
        addSetting(moduleColor);
    }

    public String getName() {
        return name;
    }

    public Category getCategory() {
        return category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String desc) {
        this.description = StrProt.x(desc);
    }

    public boolean isToggled() {
        return toggled;
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public boolean isHiddenInGUI() {
        return hiddenInGUI;
    }

    public void setHiddenInGUI(boolean hidden) {
        this.hiddenInGUI = hidden;
    }

    public boolean isFavorite() {
        return favorite;
    }

    public void setFavorite(boolean favorite) {
        this.favorite = favorite;
    }

    public void setToggled(boolean state) {
        if (this.toggled != state) {
            toggle();
        }
    }

    public void toggle() {
        toggled = !toggled;
        this.lastUsedTime = System.currentTimeMillis();
        toggleCounter++;
        if (toggled)
            onEnable();
        else
            onDisable();
        Client.INSTANCE.saveConfig();
        if (!suppressToggleNotifications && !Client.INSTANCE.isLoading()) {
            showToggleNotification();
            playToggleSound();
        }
    }

    private void playToggleSound() {
        if (mc.player == null || mc.world == null)
            return;
        try {
            float pitch = toggled ? 1.2f : 0.8f;
            mc.world.playSound(mc.player, mc.player.posX, mc.player.posY, mc.player.posZ, net.minecraft.init.SoundEvents.UI_BUTTON_CLICK, net.minecraft.util.SoundCategory.MASTER, 0.2f, pitch);
        } catch (Exception e) {
        }
    }

    private void showToggleNotification() {
        String message = name + (toggled ? " ON" : " OFF");
        client.utils.misc.NotificationSystem.NotificationType type;
        if (toggled) {
            switch(category) {
                case COMBAT:
                case MACE:
                    type = client.utils.misc.NotificationSystem.NotificationType.WARNING;
                    break;
                case MOVEMENT:
                case ITEMS:
                    type = client.utils.misc.NotificationSystem.NotificationType.INFO;
                    break;
                case RENDER:
                case FUN:
                    type = client.utils.misc.NotificationSystem.NotificationType.SUCCESS;
                    break;
                default:
                    type = client.utils.misc.NotificationSystem.NotificationType.INFO;
                    break;
            }
        } else {
            type = client.utils.misc.NotificationSystem.NotificationType.INFO;
        }
        client.utils.misc.NotificationSystem.show(message, type, 1500);
    }

    public static void setSuppressToggleNotifications(boolean suppress) {
        suppressToggleNotifications = suppress;
    }

    public long getLastUsedTime() {
        return lastUsedTime;
    }

    public void addSetting(Setting<?> s) {
        s.setParent(this);
        settings.add(s);
    }

    public List<Setting<?>> getSettings() {
        return settings;
    }

    public void setHudElement(client.utils.render.HudElement he) {
        this.hudElement = he;
    }

    public client.utils.render.HudElement getHudElement() {
        return hudElement;
    }

    public ColorSetting getModuleColor() {
        return moduleColor;
    }

    public int getAccentColor() {
        return moduleColor.getARGB();
    }

    public int getAccentBright() {
        float[] rgb = moduleColor.getRGBFloat();
        float r = Math.min(1.0f, rgb[0] + 0.25f);
        float g = Math.min(1.0f, rgb[1] + 0.25f);
        float b = Math.min(1.0f, rgb[2] + 0.25f);
        return 0xFF000000 | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    public int getAccentDim() {
        float[] rgb = moduleColor.getRGBFloat();
        return 0xFF000000 | ((int) (rgb[0] * 80) << 16) | ((int) (rgb[1] * 80) << 8) | (int) (rgb[2] * 80);
    }

    public int getAccentAlpha(int alpha) {
        float[] rgb = moduleColor.getRGBFloat();
        return (alpha << 24) | ((int) (rgb[0] * 255) << 16) | ((int) (rgb[1] * 255) << 8) | (int) (rgb[2] * 255);
    }

    public Setting<?> getSettingByName(String name) {
        name = StrProt.x(name);
        for (Setting<?> s : settings) {
            if (s.getName().equalsIgnoreCase(name))
                return s;
        }
        return null;
    }

    private final Listener tickListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof TickEvent)
            onTick();
    };

    private final Listener motionListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof MotionEvent)
            onMotion((MotionEvent) event);
    };

    private final Listener packetInputListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof PacketInputEvent)
            onPacketInput((PacketInputEvent) event);
    };

    private final Listener packetOutputListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof PacketOutputEvent)
            onPacketOutput((PacketOutputEvent) event);
    };

    private final Listener chatOutputListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof ChatOutputListener.ChatOutputEvent)
            onChatOutput((ChatOutputListener.ChatOutputEvent) event);
    };

    private final Listener chatInputListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof ChatInputListener.ChatInputEvent)
            onChatInput((ChatInputListener.ChatInputEvent) event);
    };

    private final Listener renderListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof RenderListener.RenderEvent)
            onRender((RenderListener.RenderEvent) event);
    };

    private final Listener keyPressListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof KeyPressListener.KeyPressEvent)
            onKeyPress((KeyPressListener.KeyPressEvent) event);
    };

    private final Listener leftClickListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof LeftClickListener.LeftClickEvent)
            onLeftClick((LeftClickListener.LeftClickEvent) event);
    };

    private final Listener rightClickListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof RightClickListener.RightClickEvent)
            onRightClick((RightClickListener.RightClickEvent) event);
    };

    private final Listener playerMoveListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof PlayerMoveListener.PlayerMoveEvent)
            onPlayerMove((PlayerMoveListener.PlayerMoveEvent) event);
    };

    private final Listener deathListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof DeathListener.DeathEvent)
            onDeath();
    };

    private final Listener shouldSideBeRenderedListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof ShouldSideBeRenderedListener.ShouldSideBeRenderedEvent)
            onShouldSideBeRendered((ShouldSideBeRenderedListener.ShouldSideBeRenderedEvent) event);
    };

    private final Listener setOpaqueCubeListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof SetOpaqueCubeListener.SetOpaqueCubeEvent)
            onSetOpaqueCube((SetOpaqueCubeListener.SetOpaqueCubeEvent) event);
    };

    private final Listener renderBlockModelListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof RenderBlockModelListener.RenderBlockModelEvent)
            onRenderBlockModel((RenderBlockModelListener.RenderBlockModelEvent) event);
    };

    private final Listener renderTileEntityListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof RenderTileEntityListener.RenderTileEntityEvent)
            onRenderTileEntity((RenderTileEntityListener.RenderTileEntityEvent) event);
    };

    private final Listener cameraTransformViewBobbingListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof CameraTransformViewBobbingListener.CameraTransformViewBobbingEvent)
            onCameraTransformViewBobbing((CameraTransformViewBobbingListener.CameraTransformViewBobbingEvent) event);
    };

    private final Listener guiRenderListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof GUIRenderListener.GUIRenderEvent)
            onGUIRender();
    };

    private final Listener postUpdateListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof PostUpdateListener.PostUpdateEvent)
            onPostUpdate();
    };

    private final Listener updateListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof UpdateListener.UpdateEvent)
            onUpdate();
    };

    private final Listener aoLightListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof GetAmbientOcclusionLightValueListener.GetAmbientOcclusionLightValueEvent)
            onGetAmbientOcclusionLightValue((GetAmbientOcclusionLightValueListener.GetAmbientOcclusionLightValueEvent) event);
    };

    private final Listener attackListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof AttackEvent)
            onAttack((AttackEvent) event);
    };

    private final Listener renderFirstPersonItemListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof RenderFirstPersonItemEvent)
            onRenderFirstPersonItem((RenderFirstPersonItemEvent) event);
    };

    private final Listener potionEffectCheckListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof PotionEffectCheckEvent)
            onPotionEffectCheck((PotionEffectCheckEvent) event);
    };

    private final Listener setSprintingListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof SetSprintingEvent)
            onSetSprinting((SetSprintingEvent) event);
    };

    private final Listener fogDensityListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof FogDensityEvent)
            onFogDensity((FogDensityEvent) event);
    };

    private final Listener entityJoinWorldListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof EntityJoinWorldEvent)
            onEntityJoinWorld((EntityJoinWorldEvent) event);
    };

    private final Listener preRenderLivingListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof PreRenderLivingEvent)
            onPreRenderLiving((PreRenderLivingEvent) event);
    };

    private final Listener postRenderLivingListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof PostRenderLivingEvent)
            onPostRenderLiving((PostRenderLivingEvent) event);
    };

    private final Listener playSoundListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof PlaySoundAtEntityEvent)
            onPlaySoundAtEntity((PlaySoundAtEntityEvent) event);
    };

    private final Listener worldChangeListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof WorldChangeEvent)
            onWorldChange((WorldChangeEvent) event);
    };

    private final Listener moveListener2 = event -> {
        if (!this.toggled)
            return;
        if (event instanceof MoveEvent)
            onMove2((MoveEvent) event);
    };

    private final Listener stepListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof StepEvent)
            onStep((StepEvent) event);
    };

    private final Listener nameFormatListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof NameFormatEvent)
            onNameFormat((NameFormatEvent) event);
    };

    private final Listener windowClickListener = event -> {
        if (!this.toggled)
            return;
        if (event instanceof WindowClickEvent)
            onWindowClick((WindowClickEvent) event);
    };

    private static final Class<? extends Event>[] EVENT_TYPES = new Class[] { TickEvent.class, MotionEvent.class, PacketInputEvent.class, PacketOutputEvent.class, ChatOutputListener.ChatOutputEvent.class, ChatInputListener.ChatInputEvent.class, RenderListener.RenderEvent.class, KeyPressListener.KeyPressEvent.class, LeftClickListener.LeftClickEvent.class, RightClickListener.RightClickEvent.class, PlayerMoveListener.PlayerMoveEvent.class, DeathListener.DeathEvent.class, ShouldSideBeRenderedListener.ShouldSideBeRenderedEvent.class, SetOpaqueCubeListener.SetOpaqueCubeEvent.class, RenderBlockModelListener.RenderBlockModelEvent.class, RenderTileEntityListener.RenderTileEntityEvent.class, CameraTransformViewBobbingListener.CameraTransformViewBobbingEvent.class, GUIRenderListener.GUIRenderEvent.class, PostUpdateListener.PostUpdateEvent.class, UpdateListener.UpdateEvent.class, GetAmbientOcclusionLightValueListener.GetAmbientOcclusionLightValueEvent.class, AttackEvent.class, RenderFirstPersonItemEvent.class, PotionEffectCheckEvent.class, SetSprintingEvent.class, FogDensityEvent.class, EntityJoinWorldEvent.class, PreRenderLivingEvent.class, PostRenderLivingEvent.class, PlaySoundAtEntityEvent.class, WorldChangeEvent.class, MoveEvent.class, StepEvent.class, NameFormatEvent.class, WindowClickEvent.class };

    private Listener listenerFor(HandlerType type) {
        switch(type) {
            case TICK:
                return tickListener;
            case MOTION:
                return motionListener;
            case PACKET_INPUT:
                return packetInputListener;
            case PACKET_OUTPUT:
                return packetOutputListener;
            case CHAT_OUTPUT:
                return chatOutputListener;
            case CHAT_INPUT:
                return chatInputListener;
            case RENDER:
                return renderListener;
            case KEY_PRESS:
                return keyPressListener;
            case LEFT_CLICK:
                return leftClickListener;
            case RIGHT_CLICK:
                return rightClickListener;
            case PLAYER_MOVE:
                return playerMoveListener;
            case DEATH:
                return deathListener;
            case SHOULD_SIDE_BE_RENDERED:
                return shouldSideBeRenderedListener;
            case SET_OPAQUE_CUBE:
                return setOpaqueCubeListener;
            case RENDER_BLOCK_MODEL:
                return renderBlockModelListener;
            case RENDER_TILE_ENTITY:
                return renderTileEntityListener;
            case CAMERA_VIEW_BOB:
                return cameraTransformViewBobbingListener;
            case GUI_RENDER:
                return guiRenderListener;
            case POST_UPDATE:
                return postUpdateListener;
            case UPDATE:
                return updateListener;
            case AO_LIGHT:
                return aoLightListener;
            case ATTACK:
                return attackListener;
            case RENDER_FIRST_PERSON_ITEM:
                return renderFirstPersonItemListener;
            case POTION_EFFECT_CHECK:
                return potionEffectCheckListener;
            case SET_SPRINTING:
                return setSprintingListener;
            case FOG_DENSITY:
                return fogDensityListener;
            case ENTITY_JOIN_WORLD:
                return entityJoinWorldListener;
            case PRE_RENDER_LIVING:
                return preRenderLivingListener;
            case POST_RENDER_LIVING:
                return postRenderLivingListener;
            case PLAY_SOUND:
                return playSoundListener;
            case WORLD_CHANGE:
                return worldChangeListener;
            case MOVE:
                return moveListener2;
            case STEP:
                return stepListener;
            case NAME_FORMAT:
                return nameFormatListener;
            case WINDOW_CLICK:
                return windowClickListener;
            default:
                return null;
        }
    }

    public void onEnable() {
        Set<HandlerType> handlers = getEffectiveHandlers();
        for (HandlerType type : handlers) {
            Client.bus().register(EVENT_TYPES[type.ordinal()], listenerFor(type));
        }
    }

    public void onDisable() {
        Set<HandlerType> handlers = getEffectiveHandlers();
        for (HandlerType type : handlers) {
            Client.bus().unregister(EVENT_TYPES[type.ordinal()], listenerFor(type));
        }
    }

    public void onTick() {
    }

    public void onMotion(MotionEvent event) {
    }

    public void onPacketInput(PacketInputEvent event) {
    }

    public void onPacketOutput(PacketOutputEvent event) {
    }

    public void onChatOutput(ChatOutputListener.ChatOutputEvent event) {
    }

    public void onChatInput(ChatInputListener.ChatInputEvent event) {
    }

    public void onRender(RenderListener.RenderEvent event) {
    }

    public void onKeyPress(KeyPressListener.KeyPressEvent event) {
    }

    public void onLeftClick(LeftClickListener.LeftClickEvent event) {
    }

    public void onRightClick(RightClickListener.RightClickEvent event) {
    }

    public void onPlayerMove(PlayerMoveListener.PlayerMoveEvent event) {
    }

    public void onDeath() {
    }

    public void onShouldSideBeRendered(ShouldSideBeRenderedListener.ShouldSideBeRenderedEvent event) {
    }

    public void onSetOpaqueCube(SetOpaqueCubeListener.SetOpaqueCubeEvent event) {
    }

    public void onRenderBlockModel(RenderBlockModelListener.RenderBlockModelEvent event) {
    }

    public void onRenderTileEntity(RenderTileEntityListener.RenderTileEntityEvent event) {
    }

    public void onCameraTransformViewBobbing(CameraTransformViewBobbingListener.CameraTransformViewBobbingEvent event) {
    }

    public void onGUIRender() {
    }

    public void onPostUpdate() {
    }

    public void onUpdate() {
    }

    public void onGetAmbientOcclusionLightValue(GetAmbientOcclusionLightValueListener.GetAmbientOcclusionLightValueEvent event) {
    }

    public void onAttack(AttackEvent event) {
    }

    public void onRenderFirstPersonItem(RenderFirstPersonItemEvent event) {
    }

    public void onPotionEffectCheck(PotionEffectCheckEvent event) {
    }

    public void onSetSprinting(SetSprintingEvent event) {
    }

    public void onFogDensity(FogDensityEvent event) {
    }

    public void onEntityJoinWorld(EntityJoinWorldEvent event) {
    }

    public void onPreRenderLiving(PreRenderLivingEvent event) {
    }

    public void onPostRenderLiving(PostRenderLivingEvent event) {
    }

    public void onPlaySoundAtEntity(PlaySoundAtEntityEvent event) {
    }

    public void onWorldChange(WorldChangeEvent event) {
    }

    public void onMove2(MoveEvent event) {
    }

    public void onStep(StepEvent event) {
    }

    public void onNameFormat(NameFormatEvent event) {
    }

    public void onWindowClick(WindowClickEvent event) {
    }

    protected boolean nullCheck() {
        return mc.player != null && mc.world != null;
    }

    protected boolean canAct() {
        return mc.player != null && mc.world != null && mc.player.isEntityAlive() && mc.getNetHandler() != null;
    }

    protected void releaseMovementKeys() {
        if (mc.gameSettings == null)
            return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), false);
    }
}
