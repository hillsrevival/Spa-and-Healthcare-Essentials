package client.module;

import client.Client;

public class BindSetting extends Setting<int[]> {

    public static final int MODE_HOLD = 0;

    public static final int MODE_TOGGLE = 1;

    private static final int[] DEFAULT = new int[] { -1, MODE_TOGGLE };

    public BindSetting(String name) {
        this(name, -1, MODE_TOGGLE);
    }

    public BindSetting(String name, int keyCode, int activationMode) {
        super(name, new int[] { keyCode, activationMode });
    }

    public int getKeyCode() {
        return value[0];
    }

    public int getActivationMode() {
        return value[1];
    }

    public boolean isHoldMode() {
        return value[1] == MODE_HOLD;
    }

    public boolean isToggleMode() {
        return value[1] == MODE_TOGGLE;
    }

    public boolean isBound() {
        return value[0] != -1;
    }

    public void setKey(int keyCode) {
        value[0] = keyCode;
        if (getParent() != null && !Client.INSTANCE.isLoading()) {
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }

    public void setActivationMode(int mode) {
        value[1] = mode;
        if (getParent() != null && !Client.INSTANCE.isLoading()) {
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }

    @Override
    public void setValue(int[] value) {
        if (value != null && value.length >= 2) {
            this.value = value;
        }
    }
}
