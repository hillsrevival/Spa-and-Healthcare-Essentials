package client.module;

import client.Client;
import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class ItemFilterSetting extends Setting<String[]> {

    private final boolean whitelist;

    private boolean includeOffhand;

    public ItemFilterSetting(String name, boolean whitelist, String[] defaultValue) {
        super(name, defaultValue);
        this.whitelist = whitelist;
    }

    public boolean isWhitelist() {
        return whitelist;
    }

    public void setIncludeOffhand(boolean includeOffhand) {
        this.includeOffhand = includeOffhand;
    }

    public boolean matches(ItemStack stack) {
        if (stack == null || stack.func_190926_b()) {
            return value == null || value.length == 0;
        }
        boolean inList = isInList(stack);
        if (value == null || value.length == 0) {
            return true;
        }
        return whitelist ? inList : !inList;
    }

    public boolean matchesHeldItem() {
        return matchesHeldItem(false);
    }

    public boolean matchesHeldItem(boolean checkOffhand) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null)
            return false;
        ItemStack mainHand = mc.player.getHeldItemMainhand();
        if (matches(mainHand)) {
            return true;
        }
        if (checkOffhand && includeOffhand) {
            ItemStack offHand = mc.player.getHeldItemOffhand();
            if (matches(offHand)) {
                return true;
            }
        }
        return false;
    }

    public boolean contains(String itemName) {
        if (value == null)
            return false;
        for (String s : value) {
            if (s.equalsIgnoreCase(itemName))
                return true;
        }
        return false;
    }

    public void toggle(String itemName) {
        if (value == null)
            return;
        for (int i = 0; i < value.length; i++) {
            if (value[i].equalsIgnoreCase(itemName)) {
                String[] newValue = new String[value.length - 1];
                System.arraycopy(value, 0, newValue, 0, i);
                System.arraycopy(value, i + 1, newValue, i, value.length - i - 1);
                setValue(newValue);
                return;
            }
        }
        String[] newValue = new String[value.length + 1];
        System.arraycopy(value, 0, newValue, 0, value.length);
        newValue[value.length] = itemName;
        setValue(newValue);
    }

    private boolean isInList(ItemStack stack) {
        if (value == null || stack == null)
            return false;
        String displayName = stack.getDisplayName().toLowerCase();
        for (String entry : value) {
            if (entry == null)
                continue;
            String lower = entry.toLowerCase();
            if (displayName.contains(lower)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void setValue(String[] value) {
        this.value = value;
        if (getParent() != null && !Client.INSTANCE.isLoading()) {
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }
}
