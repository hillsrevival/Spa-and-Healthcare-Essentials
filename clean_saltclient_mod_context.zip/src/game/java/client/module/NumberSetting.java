package client.module;

import client.Client;

public class NumberSetting extends Setting<Double> {

    private final double min;

    private final double max;

    private double step;

    public NumberSetting(String name, double defaultValue, double min, double max) {
        super(name, defaultValue);
        this.min = min;
        this.max = max;
        double range = max - min;
        if (range <= 0) {
            this.step = 0;
        } else {
            this.step = range / 100.0;
            if (this.step > 0.1)
                this.step = 0.1;
            if (this.step < range / 10000.0)
                this.step = range / 10000.0;
        }
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public double getStep() {
        return step;
    }

    public void setStep(double step) {
        this.step = step;
    }

    @Override
    public void setValue(Double value) {
        this.value = value;
        if (getParent() != null && !Client.INSTANCE.isLoading()) {
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }
}
