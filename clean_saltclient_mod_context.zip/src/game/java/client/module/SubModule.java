package client.module;

public abstract class SubModule {

    private final String name;

    private Module parent;

    public SubModule(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Module getParent() {
        return parent;
    }

    public void setParent(Module parent) {
        this.parent = parent;
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onUpdate() {
    }

    protected void addSetting(Setting<?> setting) {
        if (parent != null) {
            parent.addSetting(setting);
        }
    }
}
