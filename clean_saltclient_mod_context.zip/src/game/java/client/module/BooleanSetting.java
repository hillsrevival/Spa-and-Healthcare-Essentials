package client.module;

import client.Client;

public class BooleanSetting extends Setting<Boolean> {

    public BooleanSetting(String name, boolean defaultValue) {
        super(name, defaultValue);
    }

    @Override
    public void setValue(Boolean value) {
        this.value = value;
        if (getParent() != null && !Client.INSTANCE.isLoading()) {
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }
}
