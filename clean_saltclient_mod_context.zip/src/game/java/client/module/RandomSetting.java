package client.module;

import client.Client;
import java.util.Random;

public class RandomSetting extends Setting<double[]> {

    private final double allowedMin;

    private final double allowedMax;

    private final Random random = new Random();

    public RandomSetting(String name, double defaultMin, double defaultMax, double allowedMin, double allowedMax) {
        super(name, new double[] { defaultMin, defaultMax });
        this.allowedMin = allowedMin;
        this.allowedMax = allowedMax;
    }

    public double getMin() {
        return value[0];
    }

    public double getMax() {
        return value[1];
    }

    public int getMinInt() {
        return (int) Math.round(value[0]);
    }

    public int getMaxInt() {
        return (int) Math.round(value[1]);
    }

    public void setMin(double min) {
        min = Math.max(allowedMin, Math.min(allowedMax, min));
        value[0] = min;
        if (getParent() != null && !Client.INSTANCE.isLoading()) {
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }

    public void setMax(double max) {
        max = Math.max(allowedMin, Math.min(allowedMax, max));
        value[1] = max;
        if (getParent() != null && !Client.INSTANCE.isLoading()) {
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }

    public double getRandomValue() {
        double min = getMin();
        double max = getMax();
        if (max <= min)
            return min;
        return min + (max - min) * random.nextDouble();
    }

    public int getRandomInt() {
        int min = getMinInt();
        int max = getMaxInt();
        if (max <= min)
            return min;
        return min + random.nextInt(max - min + 1);
    }

    public long getRandomDelayMs() {
        double cps = getRandomValue();
        long delay = (long) (1000.0 / cps);
        delay = (long) (delay * (0.80 + random.nextDouble() * 0.40));
        if (delay < 50)
            delay = 50;
        return delay;
    }

    public double getAllowedMin() {
        return allowedMin;
    }

    public double getAllowedMax() {
        return allowedMax;
    }

    @Override
    public void setValue(double[] value) {
        if (value != null && value.length >= 2) {
            this.value = value;
            if (getParent() != null && !Client.INSTANCE.isLoading()) {
                Client.INSTANCE.getConfigManager().getSettingConfig().save();
            }
        }
    }
}
