package client.module;

import client.Client;

public class ColorSetting extends Setting<Double> {

    private final double min = 0;

    private final double max = 360;

    public ColorSetting(String name, double defaultHue) {
        super(name, defaultHue);
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public double getHue() {
        return value;
    }

    public float[] getRGBFloat() {
        return hsbToRgb((float) (value / 360.0f), 1.0f, 1.0f);
    }

    public int getARGB() {
        float[] rgb = getRGBFloat();
        int r = (int) (rgb[0] * 255);
        int g = (int) (rgb[1] * 255);
        int b = (int) (rgb[2] * 255);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    public int getARGB(int alpha) {
        float[] rgb = getRGBFloat();
        int r = (int) (rgb[0] * 255);
        int g = (int) (rgb[1] * 255);
        int b = (int) (rgb[2] * 255);
        return (alpha << 24) | (r << 16) | (g << 8) | b;
    }

    @Override
    public void setValue(Double value) {
        this.value = value;
        if (getParent() != null && !Client.INSTANCE.isLoading()) {
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }

    public static float[] hsbToRgb(float h, float s, float b) {
        int i = (int) (h * 6.0f);
        float f = h * 6.0f - i;
        float p = b * (1.0f - s);
        float q = b * (1.0f - f * s);
        float t = b * (1.0f - (1.0f - f) * s);
        switch(i % 6) {
            case 0:
                return new float[] { b, t, p };
            case 1:
                return new float[] { q, b, p };
            case 2:
                return new float[] { p, b, t };
            case 3:
                return new float[] { p, q, b };
            case 4:
                return new float[] { t, p, b };
            case 5:
                return new float[] { b, p, q };
            default:
                return new float[] { 1, 1, 1 };
        }
    }
}
