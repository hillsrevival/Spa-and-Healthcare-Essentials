package client.module;

import client.Client;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.Minecraft;

public class TargetFilterSetting extends Setting<Boolean[]> {

    private static final Minecraft mc = Minecraft.getMinecraft();

    public static final int IDX_PLAYERS = 0;

    public static final int IDX_HOSTILE = 1;

    public static final int IDX_PASSIVE = 2;

    public static final int IDX_INVISIBLE = 3;

    public static final int IDX_THROUGH_WALLS = 4;

    public static final int IDX_IGNORE_NAKED = 5;

    private final BooleanSetting playersSetting;

    private final BooleanSetting hostileSetting;

    private final BooleanSetting passiveSetting;

    private final BooleanSetting invisibleSetting;

    private final BooleanSetting throughWallsSetting;

    private final BooleanSetting ignoreNakedSetting;

    public TargetFilterSetting(Module parent) {
        super("Targets", new Boolean[] { true, true, false, true, false, false });
        setParent(parent);
        playersSetting = new BooleanSetting("Players", true);
        hostileSetting = new BooleanSetting("Hostile Mobs", true);
        passiveSetting = new BooleanSetting("Passive Mobs", false);
        invisibleSetting = new BooleanSetting("Target Invisible", true);
        throughWallsSetting = new BooleanSetting("Hit Through Walls", false);
        ignoreNakedSetting = new BooleanSetting("Ignore Naked", false);
        parent.addSetting(playersSetting);
        parent.addSetting(hostileSetting);
        parent.addSetting(passiveSetting);
        parent.addSetting(invisibleSetting);
        parent.addSetting(throughWallsSetting);
        parent.addSetting(ignoreNakedSetting);
    }

    public boolean targetPlayers() {
        return playersSetting.getValue();
    }

    public boolean targetHostile() {
        return hostileSetting.getValue();
    }

    public boolean targetPassive() {
        return passiveSetting.getValue();
    }

    public boolean targetInvisible() {
        return invisibleSetting.getValue();
    }

    public boolean hitThroughWalls() {
        return throughWallsSetting.getValue();
    }

    public boolean ignoreNaked() {
        return ignoreNakedSetting.getValue();
    }

    public boolean isValidTarget(EntityLivingBase entity) {
        if (entity == null)
            return false;
        if (mc.player == null)
            return false;
        if (entity instanceof EntityPlayer) {
            if (!targetPlayers())
                return false;
            if (ignoreNaked()) {
                EntityPlayer player = (EntityPlayer) entity;
                boolean hasArmor = false;
                for (net.minecraft.inventory.EntityEquipmentSlot slot : net.minecraft.inventory.EntityEquipmentSlot.values()) {
                    if (slot.getSlotType() == net.minecraft.inventory.EntityEquipmentSlot.Type.ARMOR) {
                        net.minecraft.item.ItemStack stack = player.getItemStackFromSlot(slot);
                        if (stack != null && !stack.func_190926_b()) {
                            hasArmor = true;
                            break;
                        }
                    }
                }
                if (!hasArmor && entity != mc.player)
                    return false;
            }
        } else if (entity instanceof EntityMob) {
            if (!targetHostile())
                return false;
        } else if (entity instanceof EntityAnimal) {
            if (!targetPassive())
                return false;
        } else {
            if (!targetPassive())
                return false;
        }
        if (entity.isInvisible() && !targetInvisible())
            return false;
        if (!hitThroughWalls() && !mc.player.canEntityBeSeen(entity))
            return false;
        return true;
    }

    @Override
    public void setValue(Boolean[] value) {
        if (value != null && value.length >= 6) {
            this.value = value;
        }
    }
}
