package client.shader;

import static net.lax1dude.eaglercraft.internal.PlatformOpenGL.*;
import static net.lax1dude.eaglercraft.opengl.RealOpenGLEnums.*;
import net.lax1dude.eaglercraft.EagRuntime;
import net.lax1dude.eaglercraft.internal.IFramebufferGL;
import net.lax1dude.eaglercraft.internal.IProgramGL;
import net.lax1dude.eaglercraft.internal.IShaderGL;
import net.lax1dude.eaglercraft.internal.IRenderbufferGL;
import net.lax1dude.eaglercraft.internal.IUniformGL;
import net.lax1dude.eaglercraft.internal.IBufferGL;
import net.lax1dude.eaglercraft.internal.IVertexArrayGL;
import net.lax1dude.eaglercraft.internal.buffer.FloatBuffer;
import net.lax1dude.eaglercraft.internal.buffer.ByteBuffer;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.GLSLHeader;

public class ShaderPipeline {

    private static final int _GL_FBO = 0x8D40;

    private static final int _GL_CA0 = 0x8CE0;

    private static final int _GL_DA = 0x8D00;

    private static final int _GL_DC16 = 0x81A5;

    private static final int _GL_AB = 0x8892;

    private IFramebufferGL sceneFBO, pingFBO, pongFBO, godRayFBO, prevFrameFBO, compFBO, fxaaFBO;

    private int sceneColorTex = -1, pingTex = -1, pongTex = -1, godRayColorTex = -1, prevFrameTex = -1, compTex = -1, fxaaTex = -1;

    private IProgramGL bloomExtractProg, blurProg, godRayProg, copyProg, compositeProg, fxaaProg;

    private IUniformGL be_u_tex, be_u_thresh;

    private IUniformGL bl_u_tex, bl_u_dir, bl_u_rad;

    private IUniformGL gr_u_scene, gr_u_sunPos, gr_u_decay, gr_u_dens;

    private IUniformGL cp_u_tex;

    private IUniformGL co_u_scene, co_u_bloom, co_u_godRays, co_u_prevFrame;

    private IUniformGL co_u_res;

    private IUniformGL co_u_bloomStr, co_u_grStr, co_u_chromStr;

    private IUniformGL co_u_vigStr, co_u_vigSmth;

    private IUniformGL co_u_sat, co_u_bri, co_u_con, co_u_tint;

    private IUniformGL co_u_mbStr;

    private IUniformGL co_u_grainStr, co_u_grainTime;

    private IUniformGL co_u_gamma;

    private IUniformGL co_u_sharpenStr;

    private IUniformGL co_u_flareStr, co_u_flareWidth;

    private IUniformGL fx_u_tex, fx_u_res, fx_u_sub, fx_u_th, fx_u_thMin;

    private int width = -1, height = -1;

    private boolean initialized = false, compileFailed = false;

    private IVertexArrayGL quadVAO;

    private IBufferGL quadVBO;

    private boolean firstFrame = true;

    private boolean mbWasEnabled = false;

    public static class Config {

        public boolean bloomEnabled, godRaysEnabled, chromaticAbEnabled;

        public boolean vignetteEnabled, colorGradeEnabled, fxaaEnabled, motionBlurEnabled;

        public float bloomStrength = 0.5f, bloomThreshold = 0.7f, bloomRadius = 3.0f;

        public int bloomPasses = 4;

        public float godRayStrength = 0.4f, godRayDecay = 0.97f;

        public float godRayDensity = 1.0f;

        public int godRaySamples = 16;

        public float chromaticStrength = 0.003f;

        public float vignetteStrength = 0.45f, vignetteSmoothness = 0.45f;

        public float saturation = 1.1f, brightness = 1.0f, contrast = 1.08f;

        public float colorTintR = 1.0f, colorTintG = 1.0f, colorTintB = 1.0f;

        public float fxaaSubpixelQuality = 0.75f;

        public float fxaaEdgeThreshold = 0.166f, fxaaEdgeThresholdMin = 0.0833f;

        public float motionBlurStrength = 0.08f;

        public float sunScreenX = 0.65f, sunScreenY = 0.15f;

        public float filmGrainStrength = 0.0f;

        public float gamma = 1.0f;

        public boolean sharpenEnabled = false;

        public float sharpenStrength = 0.3f;

        public boolean lensFlareEnabled = false;

        public float lensFlareStrength = 0.4f;

        public float lensFlareWidth = 8.0f;

        public boolean needsPostProcess() {
            return bloomEnabled || godRaysEnabled || chromaticAbEnabled || vignetteEnabled || colorGradeEnabled || fxaaEnabled || motionBlurEnabled || filmGrainStrength > 0.001f || Math.abs(gamma - 1.0f) > 0.01f || sharpenEnabled || lensFlareEnabled;
        }

        public boolean needsBloomExtract() {
            return bloomEnabled || godRaysEnabled || lensFlareEnabled;
        }
    }

    private final Config config = new Config();

    public Config getConfig() {
        return config;
    }

    private static final String PREC = "precision lowp int;\n" + "precision highp float;\n" + "precision highp sampler2D;\n" + "\n";

    private static final String VERT = "EAGLER_IN(0, vec2, a_pos)\n" + "EAGLER_OUT(vec2, v_uv)\n" + "void main() {\n" + "    EAGLER_VERT_POSITION = vec4(a_pos, 0.0, 1.0);\n" + "    v_uv = a_pos * 0.5 + 0.5;\n" + "}\n" + "\n";

    private static final String BE_FSH = "EAGLER_IN(vec2, v_uv)\n" + "uniform sampler2D u_texture;\n" + "uniform float u_threshold;\n" + "EAGLER_FRAG_OUT()\n" + "void main() {\n" + "    vec4 c = EAGLER_TEXTURE_2D(u_texture, v_uv);\n" + "    float l = dot(c.rgb, vec3(0.2126, 0.7152, 0.0722));\n" + "    float t = u_threshold;\n" + "    float knee = t * 0.25;\n" + "    float lo = t - knee;\n" + "    float hi = t + knee;\n" + "    float contrib = 0.0;\n" + "    if (l > hi) {\n" + "        contrib = 1.0;\n" + "    } else if (l > lo) {\n" + "        contrib = smoothstep(lo, hi, l);\n" + "    }\n" + "    EAGLER_FRAG_COLOR = vec4(c.rgb * contrib, 1.0);\n" + "}\n" + "\n";

    private static final String BLUR_FSH = "EAGLER_IN(vec2, v_uv)\n" + "uniform sampler2D u_texture;\n" + "uniform vec2 u_direction;\n" + "uniform float u_radius;\n" + "EAGLER_FRAG_OUT()\n" + "void main() {\n" + "    vec4 s = vec4(0.0);\n" + "    float tw = 0.0;\n" + "    float sigma = max(u_radius, 0.1);\n" + "    for (int i = -12; i <= 12; i++) {\n" + "        float x = float(i);\n" + "        float w = exp(-0.5 * x * x / (sigma * sigma));\n" + "        vec2 off = v_uv + x * u_direction;\n" + "        s += EAGLER_TEXTURE_2D(u_texture, off) * w;\n" + "        tw += w;\n" + "    }\n" + "    EAGLER_FRAG_COLOR = s / max(tw, 0.00001);\n" + "}\n" + "\n";

    private static final String GR_FSH = "EAGLER_IN(vec2, v_uv)\n" + "uniform sampler2D u_scene;\n" + "uniform vec2 u_sunPos;\n" + "uniform float u_decay, u_density;\n" + "EAGLER_FRAG_OUT()\n" + "void main() {\n" + "    if (u_sunPos.x < -0.5 || u_sunPos.x > 1.5 || u_sunPos.y < -0.5 || u_sunPos.y > 1.5) {\n" + "        EAGLER_FRAG_COLOR = vec4(0.0, 0.0, 0.0, 1.0);\n" + "        return;\n" + "    }\n" + "    vec2 delta = (v_uv - u_sunPos) * u_density / 24.0;\n" + "    float decay = 1.0;\n" + "    vec3 result = vec3(0.0);\n" + "    for (int i = 0; i < 24; i++) {\n" + "        vec2 sUV = v_uv - delta * float(i + 1);\n" + "        sUV = clamp(sUV, 0.0, 1.0);\n" + "        vec3 s = EAGLER_TEXTURE_2D(u_scene, sUV).rgb;\n" + "        result += s * decay;\n" + "        decay *= u_decay;\n" + "    }\n" + "    result /= 24.0;\n" + "    result *= vec3(1.0, 0.92, 0.75);\n" + "    result = min(result, vec3(0.6));\n" + "    EAGLER_FRAG_COLOR = vec4(result, 1.0);\n" + "}\n" + "\n";

    private static final String COPY_FSH = "EAGLER_IN(vec2, v_uv)\n" + "uniform sampler2D u_texture;\n" + "EAGLER_FRAG_OUT()\n" + "void main() {\n" + "    EAGLER_FRAG_COLOR = EAGLER_TEXTURE_2D(u_texture, v_uv);\n" + "}\n" + "\n";

    private static final String FXAA_FSH = "EAGLER_IN(vec2, v_uv)\n" + "uniform sampler2D u_texture;\n" + "uniform vec2 u_resolution;\n" + "uniform float u_subpix, u_thresh, u_threshMin;\n" + "EAGLER_FRAG_OUT()\n" + "void main() {\n" + "    vec2 uv = v_uv;\n" + "    vec2 px = 1.0 / u_resolution;\n" + "    vec3 color = EAGLER_TEXTURE_2D(u_texture, uv).rgb;\n" + "    float lM  = dot(color, vec3(0.299,0.587,0.114));\n" + "    float lNW = dot(EAGLER_TEXTURE_2D(u_texture,uv+vec2(-px.x, px.y)).rgb,vec3(0.299,0.587,0.114));\n" + "    float lNE = dot(EAGLER_TEXTURE_2D(u_texture,uv+vec2( px.x, px.y)).rgb,vec3(0.299,0.587,0.114));\n" + "    float lSW = dot(EAGLER_TEXTURE_2D(u_texture,uv+vec2(-px.x,-px.y)).rgb,vec3(0.299,0.587,0.114));\n" + "    float lSE = dot(EAGLER_TEXTURE_2D(u_texture,uv+vec2( px.x,-px.y)).rgb,vec3(0.299,0.587,0.114));\n" + "    float lN  = dot(EAGLER_TEXTURE_2D(u_texture,uv+vec2( 0.0, px.y)).rgb,vec3(0.299,0.587,0.114));\n" + "    float lS  = dot(EAGLER_TEXTURE_2D(u_texture,uv+vec2( 0.0,-px.y)).rgb,vec3(0.299,0.587,0.114));\n" + "    float lW  = dot(EAGLER_TEXTURE_2D(u_texture,uv+vec2(-px.x, 0.0)).rgb,vec3(0.299,0.587,0.114));\n" + "    float lE  = dot(EAGLER_TEXTURE_2D(u_texture,uv+vec2( px.x, 0.0)).rgb,vec3(0.299,0.587,0.114));\n" + "    float lMin = min(lM, min(min(lN,lS),min(lW,lE)));\n" + "    float lMax = max(lM, max(max(lN,lS),max(lW,lE)));\n" + "    float lRng = lMax - lMin;\n" + "    float subR = abs(lNW+lNE-lM-lM)+abs(lSW+lSE-lM-lM);\n" + "    float subG = abs(lN+lE-lM-lM)+abs(lS+lW-lM-lM);\n" + "    float subP = max(subR,subG) / max(lRng,0.0001);\n" + "    if (lRng > max(u_threshMin, lMax * u_thresh)) {\n" + "        float eH = abs(-2.0*lW+lNW+lSW)+abs(-2.0*lM+lN+lS)*2.0+abs(-2.0*lE+lNE+lSE);\n" + "        float eV = abs(-2.0*lN+lNW+lNE)+abs(-2.0*lM+lW+lE)*2.0+abs(-2.0*lS+lSW+lSE);\n" + "        bool hz = eH >= eV;\n" + "        vec2 d = hz ? vec2(0.0, px.y) : vec2(px.x, 0.0);\n" + "        float lNeg = dot(EAGLER_TEXTURE_2D(u_texture,uv-d).rgb,vec3(0.299,0.587,0.114));\n" + "        float lPos = dot(EAGLER_TEXTURE_2D(u_texture,uv+d).rgb,vec3(0.299,0.587,0.114));\n" + "        float gNeg = lM - lNeg;\n" + "        float gPos = lM - lPos;\n" + "        bool signNeg = gNeg >= 0.0;\n" + "        bool signPos = gPos >= 0.0;\n" + "        if (signNeg != signPos) {\n" + "            float gS = min(abs(gNeg),abs(gPos));\n" + "            float gL = max(abs(gNeg),abs(gPos));\n" + "            float tS = gS / max(gL+gS,0.0001);\n" + "            vec2 off = d * (-tS + 0.5);\n" + "            float step = hz ? px.x : px.y;\n" + "            vec2 nOff = d * 0.5;\n" + "            float lEndNeg = lM;\n" + "            float lEndPos = lM;\n" + "            for (int i = 0; i < 8; i++) {\n" + "                lEndNeg = dot(EAGLER_TEXTURE_2D(u_texture,uv+off-nOff).rgb,vec3(0.299,0.587,0.114));\n" + "                lEndPos = dot(EAGLER_TEXTURE_2D(u_texture,uv+off+nOff).rgb,vec3(0.299,0.587,0.114));\n" + "                bool sn = (lEndNeg-lM) * gNeg < 0.0;\n" + "                bool sp = (lEndPos-lM) * gPos < 0.0;\n" + "                if (sn && sp) break;\n" + "                if (!sn) off.x -= (hz ? 0.0 : step);\n" + "                if (!sn) off.y -= (hz ? step : 0.0);\n" + "                if (!sp) off.x += (hz ? 0.0 : step);\n" + "                if (!sp) off.y += (hz ? step : 0.0);\n" + "                nOff = d * 0.5;\n" + "            }\n" + "            float dNeg = abs(off.x)+abs(off.y);\n" + "            vec2 opp = -off;\n" + "            float dPos = abs(opp.x)+abs(opp.y);\n" + "            float spSel = min(dNeg,dPos) / max(dNeg+dPos,0.0001);\n" + "            float spSub = clamp(subP * u_subpix, 0.0, 1.0);\n" + "            float blendW = max(spSel, spSub);\n" + "            color = mix(color, EAGLER_TEXTURE_2D(u_texture, uv+off).rgb, blendW);\n" + "        }\n" + "    }\n" + "    EAGLER_FRAG_COLOR = vec4(color, 1.0);\n" + "}\n" + "\n";

    private static final String COMP_FSH = "EAGLER_IN(vec2, v_uv)\n" + "uniform sampler2D u_scene, u_bloom, u_godRays, u_prevFrame;\n" + "uniform vec2 u_resolution;\n" + "uniform float u_bloomStr, u_grStr, u_chromStr;\n" + "uniform float u_vigStr, u_vigSmth;\n" + "uniform float u_sat, u_bri, u_con;\n" + "uniform vec3 u_colorTint;\n" + "uniform float u_mbStr;\n" + "uniform float u_grainStr, u_grainTime;\n" + "uniform float u_gamma;\n" + "uniform float u_sharpenStr;\n" + "uniform float u_flareStr, u_flareWidth;\n" + "EAGLER_FRAG_OUT()\n" + "void main() {\n" + "    vec2 uv = v_uv;\n" + "    vec2 px = 1.0 / u_resolution;\n" + "    float aspect = u_resolution.x / u_resolution.y;\n" + "    vec3 color = EAGLER_TEXTURE_2D(u_scene, uv).rgb;\n" + "\n" + "    // 1. Sharpen — unsharp mask\n" + "    if (u_sharpenStr > 0.001) {\n" + "        vec3 blur = (EAGLER_TEXTURE_2D(u_scene, uv+vec2(px.x,0.0)).rgb +\n" + "                     EAGLER_TEXTURE_2D(u_scene, uv+vec2(-px.x,0.0)).rgb +\n" + "                     EAGLER_TEXTURE_2D(u_scene, uv+vec2(0.0,px.y)).rgb +\n" + "                     EAGLER_TEXTURE_2D(u_scene, uv+vec2(0.0,-px.y)).rgb) * 0.25;\n" + "        color += (color - blur) * u_sharpenStr;\n" + "    }\n" + "\n" + "    // 2. Chromatic aberration — radial with screen-edge falloff\n" + "    // Stronger at screen edges, invisible in center (matches real lenses)\n" + "    if (u_chromStr > 0.0001) {\n" + "        float edgeDist = length((uv - 0.5) * vec2(1.0, aspect));\n" + "        float caFalloff = smoothstep(0.2, 0.7, edgeDist);\n" + "        vec2 dir = (uv - 0.5) * u_chromStr * caFalloff;\n" + "        color.r = EAGLER_TEXTURE_2D(u_scene, uv + dir).r;\n" + "        color.b = EAGLER_TEXTURE_2D(u_scene, uv - dir).b;\n" + "    }\n" + "\n" + "    // 3. Add bloom (additive)\n" + "    if (u_bloomStr > 0.001) {\n" + "        color += EAGLER_TEXTURE_2D(u_bloom, uv).rgb * u_bloomStr;\n" + "    }\n" + "\n" + "    // 4. Add god rays\n" + "    if (u_grStr > 0.001) {\n" + "        color += EAGLER_TEXTURE_2D(u_godRays, uv).rgb * u_grStr;\n" + "    }\n" + "\n" + "    // 5. Anamorphic lens flare\n" + "    if (u_flareStr > 0.001) {\n" + "        vec3 flare = vec3(0.0);\n" + "        float fDecay = 1.0;\n" + "        for (int fi = 1; fi <= 8; fi++) {\n" + "            float off = float(fi) * px.x * u_flareWidth;\n" + "            flare += EAGLER_TEXTURE_2D(u_bloom, uv + vec2(off, 0.0)).rgb * fDecay;\n" + "            flare += EAGLER_TEXTURE_2D(u_bloom, uv - vec2(off, 0.0)).rgb * fDecay;\n" + "            fDecay *= 0.88;\n" + "        }\n" + "        flare /= 8.0;\n" + "        float cd = length(uv - 0.5) * 2.0;\n" + "        vec3 fTint = mix(vec3(1.0, 0.92, 0.7), vec3(0.5, 0.7, 1.0), cd);\n" + "        color += flare * u_flareStr * fTint;\n" + "    }\n" + "\n" + "    // 6. Vignette — aspect-corrected for true circular shape\n" + "    if (u_vigStr > 0.001) {\n" + "        float d = length((uv - 0.5) * vec2(1.0, aspect));\n" + "        float vig = 1.0 - d * d * u_vigStr * 4.0;\n" + "        vig = clamp(vig, 0.0, 1.0);\n" + "        vig = mix(1.0, vig, smoothstep(0.0, u_vigSmth, d * 1.414));\n" + "        color *= vig;\n" + "    }\n" + "\n" + "    // 7. Color grading\n" + "    color = (color - 0.5) * u_con + 0.5;\n" + "    float lum = dot(color, vec3(0.2126, 0.7152, 0.0722));\n" + "    color = mix(vec3(lum), color, u_sat);\n" + "    color *= u_bri;\n" + "    color *= u_colorTint;\n" + "\n" + "    // 8. Reinhard tone mapping (move BEFORE motion blur so both\n" + "    //    current and previous frame are in display [0,1] space —\n" + "    //    blending in linear HDR space caused a gray-wash artifact).\n" + "    color = color / (1.0 + max(color, vec3(0.0)));\n" + "\n" + "    // 9. Gamma correction\n" + "    if (u_gamma > 0.01) {\n" + "        color = pow(max(color, vec3(0.0)), vec3(1.0 / u_gamma));\n" + "    }\n" + "\n" + "    // 10. Motion blur — MotionBlurX-style temporal frame blend.\n" + "    //    Both color and prevColor are now tone-mapped display-space\n" + "    //    values, so mix() produces a clean cinematic trail instead of\n" + "    //    a muddy gray wash. Default strength 0.5 = 50% previous frame.\n" + "    //    The previous frame already contains accumulated history, so a\n" + "    //    single mix() gives an exponentially-decaying trail.\n" + "    if (u_mbStr > 0.001) {\n" + "        vec3 prevColor = EAGLER_TEXTURE_2D(u_prevFrame, uv).rgb;\n" + "        color = mix(color, prevColor, u_mbStr);\n" + "    }\n" + "\n" + "    // 11. Film grain (applied AFTER motion blur so grain noise is not\n" + "    //     blended into the history buffer — keeps the trail clean)\n" + "    if (u_grainStr > 0.001) {\n" + "        float grain = fract(sin(dot(uv, vec2(12.9898, 78.233)) + u_grainTime) * 43758.5453);\n" + "        grain = (grain - 0.5) * 2.0;\n" + "        color += grain * u_grainStr;\n" + "    }\n" + "\n" + "    EAGLER_FRAG_COLOR = vec4(color, 1.0);\n" + "}\n" + "\n";

    private IProgramGL compile(String vsh, String fsh) {
        IShaderGL vs = _wglCreateShader(GL_VERTEX_SHADER);
        _wglShaderSource(vs, GLSLHeader.getVertexHeaderCompat(vsh, PREC));
        _wglCompileShader(vs);
        if (_wglGetShaderi(vs, GL_COMPILE_STATUS) != GL_TRUE) {
            System.err.println("[ShaderPipeline] VS error: " + _wglGetShaderInfoLog(vs));
            _wglDeleteShader(vs);
            return null;
        }
        IShaderGL fs = _wglCreateShader(GL_FRAGMENT_SHADER);
        _wglShaderSource(fs, GLSLHeader.getFragmentHeaderCompat(fsh, PREC));
        _wglCompileShader(fs);
        if (_wglGetShaderi(fs, GL_COMPILE_STATUS) != GL_TRUE) {
            System.err.println("[ShaderPipeline] FS error: " + _wglGetShaderInfoLog(fs));
            _wglDeleteShader(vs);
            _wglDeleteShader(fs);
            return null;
        }
        IProgramGL prog = _wglCreateProgram();
        _wglAttachShader(prog, vs);
        _wglAttachShader(prog, fs);
        if (EaglercraftGPU.checkOpenGLESVersion() == 200) {
            _wglBindAttribLocation(prog, 0, "a_pos");
        }
        _wglLinkProgram(prog);
        _wglDetachShader(prog, vs);
        _wglDetachShader(prog, fs);
        _wglDeleteShader(vs);
        _wglDeleteShader(fs);
        if (_wglGetProgrami(prog, GL_LINK_STATUS) != GL_TRUE) {
            System.err.println("[ShaderPipeline] Link error: " + _wglGetProgramInfoLog(prog));
            _wglDeleteProgram(prog);
            return null;
        }
        return prog;
    }

    private IUniformGL uni(IProgramGL p, String name) {
        return _wglGetUniformLocation(p, name);
    }

    private boolean compileAll() {
        bloomExtractProg = compile(VERT, BE_FSH);
        if (bloomExtractProg == null)
            return false;
        blurProg = compile(VERT, BLUR_FSH);
        if (blurProg == null)
            return false;
        godRayProg = compile(VERT, GR_FSH);
        if (godRayProg == null)
            return false;
        copyProg = compile(VERT, COPY_FSH);
        if (copyProg == null)
            return false;
        fxaaProg = compile(VERT, FXAA_FSH);
        if (fxaaProg == null)
            return false;
        compositeProg = compile(VERT, COMP_FSH);
        if (compositeProg == null)
            return false;
        be_u_tex = uni(bloomExtractProg, "u_texture");
        be_u_thresh = uni(bloomExtractProg, "u_threshold");
        bl_u_tex = uni(blurProg, "u_texture");
        bl_u_dir = uni(blurProg, "u_direction");
        bl_u_rad = uni(blurProg, "u_radius");
        gr_u_scene = uni(godRayProg, "u_scene");
        gr_u_sunPos = uni(godRayProg, "u_sunPos");
        gr_u_decay = uni(godRayProg, "u_decay");
        gr_u_dens = uni(godRayProg, "u_density");
        cp_u_tex = uni(copyProg, "u_texture");
        fx_u_tex = uni(fxaaProg, "u_texture");
        fx_u_res = uni(fxaaProg, "u_resolution");
        fx_u_sub = uni(fxaaProg, "u_subpix");
        fx_u_th = uni(fxaaProg, "u_thresh");
        fx_u_thMin = uni(fxaaProg, "u_threshMin");
        co_u_scene = uni(compositeProg, "u_scene");
        co_u_bloom = uni(compositeProg, "u_bloom");
        co_u_godRays = uni(compositeProg, "u_godRays");
        co_u_prevFrame = uni(compositeProg, "u_prevFrame");
        co_u_res = uni(compositeProg, "u_resolution");
        co_u_bloomStr = uni(compositeProg, "u_bloomStr");
        co_u_grStr = uni(compositeProg, "u_grStr");
        co_u_chromStr = uni(compositeProg, "u_chromStr");
        co_u_vigStr = uni(compositeProg, "u_vigStr");
        co_u_vigSmth = uni(compositeProg, "u_vigSmth");
        co_u_sat = uni(compositeProg, "u_sat");
        co_u_bri = uni(compositeProg, "u_bri");
        co_u_con = uni(compositeProg, "u_con");
        co_u_tint = uni(compositeProg, "u_colorTint");
        co_u_mbStr = uni(compositeProg, "u_mbStr");
        co_u_grainStr = uni(compositeProg, "u_grainStr");
        co_u_grainTime = uni(compositeProg, "u_grainTime");
        co_u_gamma = uni(compositeProg, "u_gamma");
        co_u_sharpenStr = uni(compositeProg, "u_sharpenStr");
        co_u_flareStr = uni(compositeProg, "u_flareStr");
        co_u_flareWidth = uni(compositeProg, "u_flareWidth");
        return true;
    }

    private IFramebufferGL createFBO(boolean depth) {
        IFramebufferGL fbo = _wglCreateFramebuffer();
        _wglBindFramebuffer(_GL_FBO, fbo);
        if (depth) {
            IRenderbufferGL rb = _wglCreateRenderbuffer();
            _wglBindRenderbuffer(0x8D41, rb);
            _wglRenderbufferStorage(0x8D41, _GL_DC16, width, height);
            _wglFramebufferRenderbuffer(_GL_FBO, _GL_DA, 0x8D41, rb);
        }
        _wglBindFramebuffer(_GL_FBO, null);
        return fbo;
    }

    private int createFBOColorTex() {
        int tex = GlStateManager.generateTexture();
        GlStateManager.bindTexture(tex);
        _wglTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        _wglTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        _wglTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        _wglTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        EaglercraftGPU.glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, (ByteBuffer) null);
        return tex;
    }

    private void attachColorTex(IFramebufferGL fbo, int tex) {
        _wglBindFramebuffer(_GL_FBO, fbo);
        _wglFramebufferTexture2D(_GL_FBO, _GL_CA0, GL_TEXTURE_2D, EaglercraftGPU.getNativeTexture(tex), 0);
        _wglBindFramebuffer(_GL_FBO, null);
    }

    private void setupQuad() {
        quadVAO = EaglercraftGPU.createGLVertexArray();
        quadVBO = _wglGenBuffers();
        FloatBuffer verts = EagRuntime.allocateFloatBuffer(12);
        verts.put(new float[] { -1, -1, 1, -1, -1, 1, 1, -1, 1, 1, -1, 1 });
        verts.flip();
        EaglercraftGPU.bindVAOGLArrayBufferNow(quadVBO);
        _wglBufferData(_GL_AB, verts, GL_STATIC_DRAW);
        EagRuntime.freeFloatBuffer(verts);
        EaglercraftGPU.bindGLVertexArray(quadVAO);
        EaglercraftGPU.enableVertexAttribArray(0);
        EaglercraftGPU.vertexAttribPointer(0, 2, GL_FLOAT, false, 0, 0);
    }

    public boolean init(int w, int h) {
        if (compileFailed)
            return false;
        if (w == width && h == height && initialized)
            return true;
        if (!initialized) {
            if (!compileAll()) {
                compileFailed = true;
                return false;
            }
            setupQuad();
            initialized = true;
        }
        destroyFBOs();
        width = w;
        height = h;
        firstFrame = true;
        sceneFBO = createFBO(true);
        sceneColorTex = createFBOColorTex();
        attachColorTex(sceneFBO, sceneColorTex);
        int hw = Math.max(1, w / 2);
        int hh = Math.max(1, h / 2);
        pingFBO = _wglCreateFramebuffer();
        pingTex = createHalfResColorTex(hw, hh);
        attachColorTex(pingFBO, pingTex);
        pongFBO = _wglCreateFramebuffer();
        pongTex = createHalfResColorTex(hw, hh);
        attachColorTex(pongFBO, pongTex);
        godRayFBO = _wglCreateFramebuffer();
        godRayColorTex = createFBOColorTex();
        attachColorTex(godRayFBO, godRayColorTex);
        prevFrameFBO = _wglCreateFramebuffer();
        prevFrameTex = createHalfResColorTex(hw, hh);
        attachColorTex(prevFrameFBO, prevFrameTex);
        compFBO = _wglCreateFramebuffer();
        compTex = createFBOColorTex();
        attachColorTex(compFBO, compTex);
        fxaaFBO = _wglCreateFramebuffer();
        fxaaTex = createFBOColorTex();
        attachColorTex(fxaaFBO, fxaaTex);
        return true;
    }

    private int createHalfResColorTex(int hw, int hh) {
        int tex = GlStateManager.generateTexture();
        GlStateManager.bindTexture(tex);
        _wglTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        _wglTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        _wglTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        _wglTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        EaglercraftGPU.glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, hw, hh, 0, GL_RGBA, GL_UNSIGNED_BYTE, (ByteBuffer) null);
        return tex;
    }

    private void destroyFBOs() {
        if (sceneFBO != null) {
            _wglDeleteFramebuffer(sceneFBO);
            sceneFBO = null;
        }
        if (pingFBO != null) {
            _wglDeleteFramebuffer(pingFBO);
            pingFBO = null;
        }
        if (pongFBO != null) {
            _wglDeleteFramebuffer(pongFBO);
            pongFBO = null;
        }
        if (godRayFBO != null) {
            _wglDeleteFramebuffer(godRayFBO);
            godRayFBO = null;
        }
        if (prevFrameFBO != null) {
            _wglDeleteFramebuffer(prevFrameFBO);
            prevFrameFBO = null;
        }
        if (compFBO != null) {
            _wglDeleteFramebuffer(compFBO);
            compFBO = null;
        }
        if (fxaaFBO != null) {
            _wglDeleteFramebuffer(fxaaFBO);
            fxaaFBO = null;
        }
        if (sceneColorTex > 0) {
            GlStateManager.deleteTexture(sceneColorTex);
            sceneColorTex = -1;
        }
        if (pingTex > 0) {
            GlStateManager.deleteTexture(pingTex);
            pingTex = -1;
        }
        if (pongTex > 0) {
            GlStateManager.deleteTexture(pongTex);
            pongTex = -1;
        }
        if (godRayColorTex > 0) {
            GlStateManager.deleteTexture(godRayColorTex);
            godRayColorTex = -1;
        }
        if (prevFrameTex > 0) {
            GlStateManager.deleteTexture(prevFrameTex);
            prevFrameTex = -1;
        }
        if (compTex > 0) {
            GlStateManager.deleteTexture(compTex);
            compTex = -1;
        }
        if (fxaaTex > 0) {
            GlStateManager.deleteTexture(fxaaTex);
            fxaaTex = -1;
        }
    }

    public void destroy() {
        EaglercraftGPU.bindGLVertexArray(null);
        EaglercraftGPU.bindGLShaderProgram(null);
        GlStateManager.setActiveTexture(GL_TEXTURE0);
        EaglercraftGPU.clearCurrentBinding(EaglercraftGPU.CLEAR_BINDING_TEXTURE);
        destroyFBOs();
        if (bloomExtractProg != null) {
            _wglDeleteProgram(bloomExtractProg);
            bloomExtractProg = null;
        }
        if (blurProg != null) {
            _wglDeleteProgram(blurProg);
            blurProg = null;
        }
        if (godRayProg != null) {
            _wglDeleteProgram(godRayProg);
            godRayProg = null;
        }
        if (copyProg != null) {
            _wglDeleteProgram(copyProg);
            copyProg = null;
        }
        if (fxaaProg != null) {
            _wglDeleteProgram(fxaaProg);
            fxaaProg = null;
        }
        if (compositeProg != null) {
            _wglDeleteProgram(compositeProg);
            compositeProg = null;
        }
        if (quadVAO != null) {
            EaglercraftGPU.destroyGLVertexArray(quadVAO);
            quadVAO = null;
        }
        if (quadVBO != null) {
            _wglDeleteBuffers(quadVBO);
            quadVBO = null;
        }
        initialized = false;
        compileFailed = false;
        width = -1;
        height = -1;
        sceneCaptured = false;
        firstFrame = true;
        mbWasEnabled = false;
    }

    public void resetHistory() {
        firstFrame = true;
    }

    private void drawQuad() {
        EaglercraftGPU.bindGLVertexArray(quadVAO);
        EaglercraftGPU.drawArrays(GL_TRIANGLES, 0, 6);
    }

    private void bindTex(int unit, int tex) {
        GlStateManager.setActiveTexture(GL_TEXTURE0 + unit);
        GlStateManager.bindTexture(tex);
    }

    private boolean sceneCaptured = false;

    private long grainTimeCounter = 0;

    public void beginSceneCapture() {
        if (!initialized)
            return;
        sceneCaptured = true;
        _wglBindFramebuffer(_GL_FBO, sceneFBO);
        GlStateManager.viewport(0, 0, width, height);
        GlStateManager.clearDepth(1.0F);
        GlStateManager.clear(16640);
    }

    public void endSceneCapture() {
        if (!initialized)
            return;
        _wglBindFramebuffer(_GL_FBO, null);
    }

    private void restoreGLState() {
        GlStateManager.setActiveTexture(GL_TEXTURE0);
        EaglercraftGPU.clearCurrentBinding(EaglercraftGPU.CLEAR_BINDING_TEXTURE);
        EaglercraftGPU.bindGLVertexArray(null);
    }

    public void applyEffects() {
        if (!initialized) {
            sceneCaptured = false;
            return;
        }
        if (!config.needsPostProcess()) {
            if (sceneCaptured) {
                _wglBindFramebuffer(_GL_FBO, null);
                GlStateManager.viewport(0, 0, width, height);
                GlStateManager.clear(16384);
                EaglercraftGPU.bindGLShaderProgram(copyProg);
                GlStateManager.disableDepth();
                GlStateManager.depthMask(false);
                GlStateManager.setActiveTexture(GL_TEXTURE0);
                GlStateManager.bindTexture(sceneColorTex);
                _wglUniform1i(cp_u_tex, 0);
                EaglercraftGPU.bindGLVertexArray(quadVAO);
                EaglercraftGPU.drawArrays(GL_TRIANGLES, 0, 6);
                EaglercraftGPU.bindGLShaderProgram(null);
                GlStateManager.depthMask(true);
                GlStateManager.enableDepth();
                restoreGLState();
            }
            sceneCaptured = false;
            return;
        }
        sceneCaptured = false;
        Config c = config;
        int w = width, h = height;
        if (c.motionBlurEnabled && !mbWasEnabled) {
            firstFrame = true;
        }
        mbWasEnabled = c.motionBlurEnabled;
        EaglercraftGPU.bindGLShaderProgram(null);
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
        GlStateManager.disableDepth();
        GlStateManager.disableCull();
        GlStateManager.disableFog();
        GlStateManager.depthMask(false);
        int sceneTexForPipeline = sceneColorTex;
        if (c.fxaaEnabled) {
            _wglBindFramebuffer(_GL_FBO, fxaaFBO);
            GlStateManager.viewport(0, 0, w, h);
            EaglercraftGPU.bindGLShaderProgram(fxaaProg);
            bindTex(0, sceneColorTex);
            _wglUniform1i(fx_u_tex, 0);
            _wglUniform2f(fx_u_res, (float) w, (float) h);
            _wglUniform1f(fx_u_sub, c.fxaaSubpixelQuality);
            _wglUniform1f(fx_u_th, c.fxaaEdgeThreshold);
            _wglUniform1f(fx_u_thMin, c.fxaaEdgeThresholdMin);
            drawQuad();
            sceneTexForPipeline = fxaaTex;
        }
        int bloomExtractTex = sceneTexForPipeline;
        int bloomResultTex = sceneTexForPipeline;
        if (c.needsBloomExtract()) {
            int hw = Math.max(1, w / 2);
            int hh = Math.max(1, h / 2);
            _wglBindFramebuffer(_GL_FBO, pingFBO);
            GlStateManager.viewport(0, 0, hw, hh);
            EaglercraftGPU.bindGLShaderProgram(bloomExtractProg);
            bindTex(0, sceneTexForPipeline);
            _wglUniform1i(be_u_tex, 0);
            float thresh = c.bloomEnabled ? c.bloomThreshold : 0.8f;
            _wglUniform1f(be_u_thresh, thresh);
            drawQuad();
            bloomExtractTex = pingTex;
            if (c.bloomEnabled) {
                int numPasses = Math.max(2, Math.min(c.bloomPasses, 6));
                float[] radii = new float[numPasses / 2 + 1];
                for (int i = 0; i < radii.length; i++) {
                    radii[i] = c.bloomRadius * (float) Math.pow(2.0, i - 1);
                }
                if (radii[0] < 0.1f)
                    radii[0] = c.bloomRadius * 0.5f;
                int passIdx = 0;
                for (int ri = 0; ri < numPasses / 2 && passIdx < numPasses; ri++) {
                    float r = radii[Math.min(ri, radii.length - 1)];
                    _wglBindFramebuffer(_GL_FBO, pongFBO);
                    EaglercraftGPU.bindGLShaderProgram(blurProg);
                    bindTex(0, pingTex);
                    _wglUniform1i(bl_u_tex, 0);
                    _wglUniform2f(bl_u_dir, 2.0f / w, 0.0f);
                    _wglUniform1f(bl_u_rad, r);
                    drawQuad();
                    passIdx++;
                    if (passIdx >= numPasses)
                        break;
                    _wglBindFramebuffer(_GL_FBO, pingFBO);
                    EaglercraftGPU.bindGLShaderProgram(blurProg);
                    bindTex(0, pongTex);
                    _wglUniform1i(bl_u_tex, 0);
                    _wglUniform2f(bl_u_dir, 0.0f, 2.0f / h);
                    _wglUniform1f(bl_u_rad, r);
                    drawQuad();
                    passIdx++;
                }
                bloomResultTex = (passIdx % 2 == 0) ? pongTex : pingTex;
            }
        }
        int godRayResultTex = sceneTexForPipeline;
        if (c.godRaysEnabled) {
            _wglBindFramebuffer(_GL_FBO, godRayFBO);
            GlStateManager.viewport(0, 0, w, h);
            EaglercraftGPU.bindGLShaderProgram(godRayProg);
            bindTex(0, bloomExtractTex);
            _wglUniform1i(gr_u_scene, 0);
            _wglUniform2f(gr_u_sunPos, c.sunScreenX, c.sunScreenY);
            _wglUniform1f(gr_u_decay, c.godRayDecay);
            _wglUniform1f(gr_u_dens, c.godRayDensity);
            drawQuad();
            godRayResultTex = godRayColorTex;
        }
        int bloomTexForComposite = bloomResultTex;
        if (c.lensFlareEnabled && !c.bloomEnabled && c.needsBloomExtract()) {
            bloomTexForComposite = bloomExtractTex;
        }
        _wglBindFramebuffer(_GL_FBO, compFBO);
        GlStateManager.viewport(0, 0, w, h);
        EaglercraftGPU.bindGLShaderProgram(compositeProg);
        bindTex(0, sceneTexForPipeline);
        bindTex(1, bloomTexForComposite);
        bindTex(2, godRayResultTex);
        bindTex(3, prevFrameTex);
        _wglUniform1i(co_u_scene, 0);
        _wglUniform1i(co_u_bloom, 1);
        _wglUniform1i(co_u_godRays, 2);
        _wglUniform1i(co_u_prevFrame, 3);
        _wglUniform2f(co_u_res, (float) w, (float) h);
        _wglUniform1f(co_u_bloomStr, c.bloomEnabled ? c.bloomStrength : 0.0f);
        _wglUniform1f(co_u_grStr, c.godRaysEnabled ? c.godRayStrength : 0.0f);
        _wglUniform1f(co_u_chromStr, c.chromaticAbEnabled ? c.chromaticStrength : 0.0f);
        _wglUniform1f(co_u_vigStr, c.vignetteEnabled ? c.vignetteStrength : 0.0f);
        _wglUniform1f(co_u_vigSmth, c.vignetteSmoothness);
        _wglUniform1f(co_u_sat, c.colorGradeEnabled ? c.saturation : 1.0f);
        _wglUniform1f(co_u_bri, c.colorGradeEnabled ? c.brightness : 1.0f);
        _wglUniform1f(co_u_con, c.colorGradeEnabled ? c.contrast : 1.0f);
        _wglUniform3f(co_u_tint, c.colorGradeEnabled ? c.colorTintR : 1.0f, c.colorGradeEnabled ? c.colorTintG : 1.0f, c.colorGradeEnabled ? c.colorTintB : 1.0f);
        _wglUniform1f(co_u_mbStr, c.motionBlurEnabled && !firstFrame ? c.motionBlurStrength : 0.0f);
        grainTimeCounter++;
        _wglUniform1f(co_u_grainStr, c.filmGrainStrength);
        _wglUniform1f(co_u_grainTime, (float) (grainTimeCounter & 0xFFFF) * 0.01f);
        _wglUniform1f(co_u_gamma, c.gamma);
        _wglUniform1f(co_u_sharpenStr, c.sharpenEnabled ? c.sharpenStrength : 0.0f);
        _wglUniform1f(co_u_flareStr, c.lensFlareEnabled ? c.lensFlareStrength : 0.0f);
        _wglUniform1f(co_u_flareWidth, c.lensFlareWidth);
        drawQuad();
        _wglBindFramebuffer(_GL_FBO, null);
        GlStateManager.viewport(0, 0, w, h);
        GlStateManager.clear(16384);
        EaglercraftGPU.bindGLShaderProgram(copyProg);
        bindTex(0, compTex);
        _wglUniform1i(cp_u_tex, 0);
        drawQuad();
        if (c.motionBlurEnabled) {
            int mhw = Math.max(1, w / 2);
            int mhh = Math.max(1, h / 2);
            _wglBindFramebuffer(_GL_FBO, prevFrameFBO);
            GlStateManager.viewport(0, 0, mhw, mhh);
            bindTex(0, compTex);
            _wglUniform1i(cp_u_tex, 0);
            drawQuad();
        }
        firstFrame = false;
        GlStateManager.viewport(0, 0, w, h);
        _wglBindFramebuffer(_GL_FBO, null);
        EaglercraftGPU.bindGLShaderProgram(null);
        GlStateManager.depthMask(true);
        GlStateManager.enableDepth();
        GlStateManager.enableCull();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        restoreGLState();
    }
}
