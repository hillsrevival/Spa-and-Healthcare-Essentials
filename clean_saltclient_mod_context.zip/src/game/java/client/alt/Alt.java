package client.alt;

import net.lax1dude.eaglercraft.EaglercraftUUID;

public class Alt {

    private final String username;

    private final EaglercraftUUID uuid;

    public Alt(String username, EaglercraftUUID uuid) {
        this.username = username;
        this.uuid = uuid;
    }

    public String getUsername() {
        return username;
    }

    public EaglercraftUUID getUuid() {
        return uuid;
    }

    @Override
    public String toString() {
        return username;
    }
}
