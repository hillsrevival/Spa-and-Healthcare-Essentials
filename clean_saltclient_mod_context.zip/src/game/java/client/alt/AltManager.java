package client.alt;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.lax1dude.eaglercraft.EaglercraftUUID;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Session;

public class AltManager {

    private static final List<Alt> alts = new ArrayList<Alt>();

    private AltManager() {
    }

    public static void addAlt(String username, EaglercraftUUID uuid) {
        if (username == null) {
            return;
        }
        username = username.trim();
        if (username.length() == 0) {
            return;
        }
        for (Alt alt : alts) {
            if (alt.getUsername().equalsIgnoreCase(username)) {
                return;
            }
        }
        alts.add(new Alt(username, uuid));
    }

    public static void removeAlt(Alt alt) {
        if (alt == null) {
            return;
        }
        alts.remove(alt);
    }

    public static List<Alt> getAlts() {
        return Collections.unmodifiableList(alts);
    }

    public static void clear() {
        alts.clear();
    }

    public static Alt getCurrentAlt() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null) {
            return null;
        }
        Session session = mc.getSession();
        if (session == null) {
            return null;
        }
        String username = session.getUsername();
        if (username == null) {
            return null;
        }
        for (Alt alt : alts) {
            if (alt.getUsername().equalsIgnoreCase(username)) {
                return alt;
            }
        }
        return null;
    }

    public static void selectAlt(Alt alt) {
        if (alt == null) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null) {
            return;
        }
        Session session = mc.getSession();
        if (session == null) {
            return;
        }
        session.update(alt.getUsername(), alt.getUuid());
    }

    public static Alt getAlt(String username) {
        if (username == null) {
            return null;
        }
        for (Alt alt : alts) {
            if (alt.getUsername().equalsIgnoreCase(username)) {
                return alt;
            }
        }
        return null;
    }

    public static int size() {
        return alts.size();
    }
}
