package client.config;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class AutoLoginConfig {

    private static final String FILE_NAME = "autologin";

    private static final String KEY_FILE = "autologin_key";

    private final HashMap<String, String> passwords = new HashMap<>();

    private static byte[] installKey() {
        byte[] k = ConfigIO.read(KEY_FILE);
        if (k == null || k.length < 16) {
            k = new byte[16];
            java.util.Random r = new java.util.Random(System.nanoTime() ^ Runtime.getRuntime().freeMemory());
            r.nextBytes(k);
            ConfigIO.write(KEY_FILE, k);
        }
        return k;
    }

    private static byte[] xor(byte[] data, byte[] key) {
        byte[] out = new byte[data.length];
        for (int i = 0; i < data.length; i++) {
            out[i] = (byte) (data[i] ^ key[i % key.length]);
        }
        return out;
    }

    public void save() {
        try {
            byte[] key = installKey();
            ByteArrayOutputStream bos = ConfigIO.out();
            DataOutputStream dos = new DataOutputStream(bos);
            dos.write(2);
            dos.writeInt(passwords.size());
            for (Map.Entry<String, String> entry : passwords.entrySet()) {
                byte[] urlBytes = entry.getKey().getBytes("UTF-8");
                byte[] pwBytes = xor(entry.getValue().getBytes("UTF-8"), key);
                dos.writeShort(urlBytes.length);
                dos.write(urlBytes);
                dos.writeShort(pwBytes.length);
                dos.write(pwBytes);
            }
            ConfigIO.write(FILE_NAME, bos.toByteArray());
        } catch (IOException e) {
            client.utils.misc.ChatUtils.error("AutoLogin config save error: " + e.getMessage());
        }
    }

    public void load() {
        passwords.clear();
        byte[] data = ConfigIO.read(FILE_NAME);
        if (data == null || data.length == 0)
            return;
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(data);
            DataInputStream dis = new DataInputStream(bis);
            int first = dis.read();
            if (first == -1)
                return;
            boolean obfuscated = (first == 2);
            int count;
            if (obfuscated) {
                count = dis.readInt();
            } else {
                int b2 = dis.read(), b3 = dis.read(), b4 = dis.read();
                if (b2 < 0 || b3 < 0 || b4 < 0)
                    return;
                count = (first << 24) | (b2 << 16) | (b3 << 8) | b4;
            }
            byte[] key = obfuscated ? installKey() : null;
            for (int i = 0; i < count; i++) {
                int urlLen = dis.readShort() & 0xFFFF;
                byte[] urlBytes = new byte[urlLen];
                dis.readFully(urlBytes);
                int pwLen = dis.readShort() & 0xFFFF;
                byte[] pwBytes = new byte[pwLen];
                dis.readFully(pwBytes);
                if (key != null) {
                    pwBytes = xor(pwBytes, key);
                }
                passwords.put(new String(urlBytes, "UTF-8"), new String(pwBytes, "UTF-8"));
            }
        } catch (IOException e) {
            client.utils.misc.ChatUtils.error("AutoLogin config load error: " + e.getMessage());
        }
    }

    public String get(String serverUrl) {
        return passwords.get(serverUrl);
    }

    public void put(String serverUrl, String password) {
        passwords.put(serverUrl, password);
        save();
    }

    public void remove(String serverUrl) {
        passwords.remove(serverUrl);
        save();
    }

    public boolean has(String serverUrl) {
        return passwords.containsKey(serverUrl);
    }
}
