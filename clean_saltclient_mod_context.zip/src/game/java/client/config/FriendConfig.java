package client.config;

import client.utils.misc.FriendManager;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

public class FriendConfig {

    private static final String FILE = "friends.bin";

    private static final int FORMAT_VERSION = 1;

    public void save() {
        java.util.Set<String> friends = FriendManager.getFriends();
        ByteArrayOutputStream out = ConfigIO.out();
        out.write(FORMAT_VERSION);
        int count = friends.size();
        out.write((count >> 8) & 0xFF);
        out.write(count & 0xFF);
        for (String name : friends) {
            byte[] nameBytes = name.getBytes();
            out.write(nameBytes.length & 0xFF);
            out.write(nameBytes, 0, nameBytes.length);
        }
        ConfigIO.write(FILE, out.toByteArray());
    }

    public void load() {
        if (!ConfigIO.exists(FILE))
            return;
        byte[] data = ConfigIO.read(FILE);
        if (data.length == 0)
            return;
        ByteArrayInputStream in = ConfigIO.in(data);
        int version = in.read();
        if (version != FORMAT_VERSION)
            return;
        int hi = in.read();
        int lo = in.read();
        if (hi < 0 || lo < 0)
            return;
        int count = (hi << 8) | lo;
        for (int i = 0; i < count; i++) {
            int nameLen = in.read();
            if (nameLen <= 0)
                return;
            byte[] nameBytes = new byte[nameLen];
            in.read(nameBytes, 0, nameLen);
            String name = new String(nameBytes);
            FriendManager.addFriend(name);
        }
    }
}
