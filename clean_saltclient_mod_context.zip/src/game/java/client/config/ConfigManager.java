package client.config;

import client.utils.misc.FriendManager;

public class ConfigManager {

    private final JsonConfig jsonConfig = new JsonConfig();

    public void saveAll() {
        jsonConfig.saveNow();
    }

    public void tick() {
        jsonConfig.tick();
    }

    public void loadAll() {
        jsonConfig.load();
    }

    public JsonConfig getJsonConfig() {
        return jsonConfig;
    }

    private final SettingConfig _legacySettingConfig = new SettingConfig();

    private final ModuleConfig _legacyModuleConfig = new ModuleConfig();

    private final FriendConfig _legacyFriendConfig = new FriendConfig();

    public SettingConfig getSettingConfig() {
        return new SettingConfig() {

            @Override
            public void save() {
                jsonConfig.save();
            }

            @Override
            public void saveNow() {
                jsonConfig.saveNow();
            }
        };
    }

    public ModuleConfig getModuleConfig() {
        return new ModuleConfig() {

            @Override
            public void save() {
                jsonConfig.saveNow();
            }
        };
    }

    public FriendConfig getFriendConfig() {
        return new FriendConfig() {

            @Override
            public void save() {
                jsonConfig.saveNow();
            }
        };
    }
}
