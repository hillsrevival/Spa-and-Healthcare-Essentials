package client.config;

import client.module.BlockListSetting;
import client.module.BooleanSetting;
import client.module.ColorSetting;
import client.module.ModeSetting;
import client.module.Module;
import client.module.ModuleManager;
import client.module.NumberSetting;
import client.module.Setting;
import client.module.StringSetting;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

public class SettingConfig {

    private static final String FILE = "settings.bin";

    private boolean dirty = false;

    private long lastDirtyTime = 0;

    private static final long SAVE_DELAY_MS = 500;

    public void save() {
        dirty = true;
        lastDirtyTime = System.currentTimeMillis();
    }

    public void tick() {
        if (!dirty)
            return;
        if (System.currentTimeMillis() - lastDirtyTime < SAVE_DELAY_MS)
            return;
        dirty = false;
        writeNow();
    }

    public void saveNow() {
        dirty = false;
        writeNow();
    }

    private void writeNow() {
        ByteArrayOutputStream out = ConfigIO.out();
        int total = 0;
        for (Module m : ModuleManager.getModules()) {
            total += m.getSettings().size();
        }
        out.write(101);
        out.write((total >> 8) & 0xFF);
        out.write(total & 0xFF);
        for (Module m : ModuleManager.getModules()) {
            for (Setting<?> s : m.getSettings()) {
                byte[] mod = m.getName().getBytes();
                out.write(mod.length & 0xFF);
                out.write(mod, 0, mod.length);
                byte[] set = s.getName().getBytes();
                out.write(set.length & 0xFF);
                out.write(set, 0, set.length);
                if (s instanceof BooleanSetting) {
                    out.write(0);
                    out.write(((BooleanSetting) s).getValue() ? 1 : 0);
                } else if (s instanceof NumberSetting) {
                    out.write(1);
                    long bits = Double.doubleToLongBits(((NumberSetting) s).getValue());
                    for (int i = 7; i >= 0; i--) {
                        out.write((int) (bits >> (i * 8)) & 0xFF);
                    }
                } else if (s instanceof ModeSetting) {
                    out.write(2);
                    byte[] val = ((ModeSetting) s).getValue().getBytes();
                    writeLen(out, val.length);
                    out.write(val, 0, val.length);
                } else if (s instanceof ColorSetting) {
                    out.write(3);
                    long bits = Double.doubleToLongBits(((ColorSetting) s).getValue());
                    for (int i = 7; i >= 0; i--) {
                        out.write((int) (bits >> (i * 8)) & 0xFF);
                    }
                } else if (s instanceof StringSetting) {
                    out.write(4);
                    byte[] val = ((StringSetting) s).getValue().getBytes();
                    writeLen(out, val.length);
                    out.write(val, 0, val.length);
                } else if (s instanceof BlockListSetting) {
                    out.write(5);
                    String[] blocks = ((BlockListSetting) s).getValue();
                    int count = blocks != null ? blocks.length : 0;
                    out.write((count >> 8) & 0xFF);
                    out.write(count & 0xFF);
                    for (String block : blocks) {
                        byte[] val = block.getBytes();
                        writeLen(out, val.length);
                        out.write(val, 0, val.length);
                    }
                }
            }
        }
        ConfigIO.write(FILE, out.toByteArray());
    }

    private static void writeLen(ByteArrayOutputStream out, int len) {
        if (len > 65535)
            len = 65535;
        out.write((len >> 8) & 0xFF);
        out.write(len & 0xFF);
    }

    private static int readLen(ByteArrayInputStream in, int version) {
        if (version >= 101) {
            int hi = in.read();
            int lo = in.read();
            if (hi < 0 || lo < 0)
                return -1;
            return (hi << 8) | lo;
        }
        return in.read();
    }

    public void load() {
        if (!ConfigIO.exists(FILE))
            return;
        byte[] data = ConfigIO.read(FILE);
        if (data.length == 0)
            return;
        ByteArrayInputStream in = ConfigIO.in(data);
        int first = in.read();
        if (first < 0)
            return;
        int total;
        int version;
        if (first == 100 || first == 101) {
            version = first;
            int hi = in.read();
            int lo = in.read();
            if (hi < 0 || lo < 0)
                return;
            total = (hi << 8) | lo;
        } else {
            version = 1;
            total = first;
        }
        for (int i = 0; i < total; i++) {
            int modLen = in.read();
            if (modLen <= 0)
                return;
            byte[] modBytes = new byte[modLen];
            in.read(modBytes, 0, modLen);
            String modName = new String(modBytes);
            int setLen = in.read();
            if (setLen <= 0)
                return;
            byte[] setBytes = new byte[setLen];
            in.read(setBytes, 0, setLen);
            String setName = new String(setBytes);
            Module m = ModuleManager.getModuleByName(modName);
            if (m == null) {
                int t = in.read();
                if (t == -1)
                    return;
                skipValue(in, version, t);
                continue;
            }
            Setting<?> s = m.getSettingByName(setName);
            if (s == null) {
                int t = in.read();
                if (t == -1)
                    return;
                skipValue(in, version, t);
                continue;
            }
            int type = in.read();
            if (type == -1)
                return;
            if (type == 0 && s instanceof BooleanSetting) {
                ((BooleanSetting) s).setValue(in.read() == 1);
            } else if (type == 1 && s instanceof NumberSetting) {
                long bits = 0;
                for (int b = 7; b >= 0; b--) {
                    int v = in.read();
                    if (v == -1)
                        return;
                    bits |= ((long) v & 0xFF) << (b * 8);
                }
                ((NumberSetting) s).setValue(Double.longBitsToDouble(bits));
            } else if (type == 2 && s instanceof ModeSetting) {
                int valLen = readLen(in, version);
                if (valLen <= 0)
                    return;
                byte[] valBytes = new byte[valLen];
                in.read(valBytes, 0, valLen);
                ((ModeSetting) s).setMode(new String(valBytes));
            } else if (type == 3 && s instanceof ColorSetting) {
                long bits = 0;
                for (int b = 7; b >= 0; b--) {
                    int v = in.read();
                    if (v == -1)
                        return;
                    bits |= ((long) v & 0xFF) << (b * 8);
                }
                ((ColorSetting) s).setValue(Double.longBitsToDouble(bits));
            } else if (type == 4 && s instanceof StringSetting) {
                int valLen = readLen(in, version);
                if (valLen <= 0)
                    return;
                byte[] valBytes = new byte[valLen];
                in.read(valBytes, 0, valLen);
                ((StringSetting) s).setValue(new String(valBytes));
            } else if (type == 5 && s instanceof BlockListSetting) {
                int hi = in.read();
                int lo = in.read();
                if (hi < 0 || lo < 0)
                    return;
                int count = (hi << 8) | lo;
                String[] blocks = new String[count];
                for (int j = 0; j < count; j++) {
                    int blen = readLen(in, version);
                    if (blen <= 0)
                        return;
                    byte[] bbytes = new byte[blen];
                    in.read(bbytes, 0, blen);
                    blocks[j] = new String(bbytes);
                }
                ((BlockListSetting) s).setValue(blocks);
            } else {
                skipValue(in, version, type);
            }
        }
    }

    private void skipValue(ByteArrayInputStream in, int version, int type) {
        if (type == -1)
            return;
        if (type == 0) {
            in.read();
        } else if (type == 1) {
            for (int i = 0; i < 8; i++) in.read();
        } else if (type == 2) {
            int len = readLen(in, version);
            if (len <= 0)
                return;
            for (int i = 0; i < len; i++) in.read();
        } else if (type == 3) {
            for (int i = 0; i < 8; i++) in.read();
        } else if (type == 4) {
            int len = readLen(in, version);
            if (len <= 0)
                return;
            for (int i = 0; i < len; i++) in.read();
        } else if (type == 5) {
            int hi = in.read();
            int lo = in.read();
            if (hi < 0 || lo < 0)
                return;
            int count = (hi << 8) | lo;
            for (int j = 0; j < count; j++) {
                int len = readLen(in, version);
                if (len <= 0)
                    return;
                for (int i = 0; i < len; i++) in.read();
            }
        }
    }
}
