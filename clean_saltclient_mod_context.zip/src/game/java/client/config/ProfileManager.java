package client.config;

import client.Client;

/**
 * Stores named SaltClient profiles in Eaglercraft's persistent key/value storage.
 * Profile slots are intentionally bounded so the browser storage footprint stays
 * predictable and the existing slot-based UI/commands remain compatible.
 */
public class ProfileManager {

    public static final int MAX_PROFILES = 8;
    private static final int MAX_NAME_LENGTH = 24;

    private final String[] names = new String[MAX_PROFILES];
    private int activeSlot = 0;

    public ProfileManager() {
        for (int i = 0; i < MAX_PROFILES; i++) {
            names[i] = "Profile " + (i + 1);
        }
        loadMeta();
    }

    /** Save the live client state into a profile slot. */
    public boolean saveProfile(int slot) {
        if (!validSlot(slot))
            return false;
        Client.INSTANCE.getConfigManager().getJsonConfig().saveNow();
        byte[] data = ConfigIO.read("config");
        if (data == null || data.length == 0)
            return false;
        ConfigIO.write(profileKey(slot), data);
        activeSlot = slot;
        saveMeta();
        return true;
    }

    /** Load a profile without leaving the client stuck in loading mode on error. */
    public boolean loadProfile(int slot) {
        if (!validSlot(slot))
            return false;
        byte[] data = ConfigIO.read(profileKey(slot));
        if (data == null || data.length == 0)
            return false;

        Client client = Client.INSTANCE;
        client.setLoading(true);
        boolean loaded;
        try {
            loaded = client.getConfigManager().getJsonConfig().applyProfileData(data);
        } catch (Throwable t) {
            System.err.println("[SaltClient] Could not load profile '" + names[slot] + "': " + t);
            loaded = false;
        } finally {
            client.setLoading(false);
        }
        if (!loaded)
            return false;

        activeSlot = slot;
        saveMeta();
        client.saveConfig();
        return true;
    }

    /** Create a named profile from the current live configuration. */
    public int createProfile(String name) {
        String safeName = sanitizeName(name);
        if (safeName == null)
            return -1;
        int slot = findEmptySlot();
        if (slot < 0)
            return -1;
        names[slot] = safeName;
        if (!saveProfile(slot)) {
            names[slot] = defaultName(slot);
            saveMeta();
            return -1;
        }
        return slot;
    }

    /** Duplicate an existing saved profile into the first free slot. */
    public int duplicateProfile(int sourceSlot, String name) {
        if (!validSlot(sourceSlot) || !hasData(sourceSlot))
            return -1;
        String safeName = sanitizeName(name);
        if (safeName == null)
            return -1;
        int targetSlot = findEmptySlot();
        if (targetSlot < 0)
            return -1;
        byte[] source = ConfigIO.read(profileKey(sourceSlot));
        if (source == null || source.length == 0)
            return -1;
        ConfigIO.write(profileKey(targetSlot), source);
        names[targetSlot] = safeName;
        saveMeta();
        return targetSlot;
    }

    /** Clear a saved profile while preserving its slot for future reuse. */
    public boolean resetProfile(int slot) {
        if (!validSlot(slot))
            return false;
        ConfigIO.write(profileKey(slot), new byte[0]);
        names[slot] = defaultName(slot);
        if (activeSlot == slot)
            activeSlot = 0;
        saveMeta();
        return true;
    }

    public void deleteProfile(int slot) {
        resetProfile(slot);
    }

    public String exportProfile(int slot) {
        if (!validSlot(slot))
            return null;
        byte[] data = ConfigIO.read(profileKey(slot));
        if (data == null || data.length == 0)
            return null;
        return new String(data);
    }

    /**
     * Import JSON into the live client and the currently selected profile.
     * Validation happens before any settings are reset or applied.
     */
    public boolean importProfile(String json) {
        if (json == null || json.trim().isEmpty())
            return false;
        byte[] data = json.trim().getBytes();
        JsonConfig config = Client.INSTANCE.getConfigManager().getJsonConfig();
        if (!config.isValidProfileData(data))
            return false;

        Client client = Client.INSTANCE;
        client.setLoading(true);
        boolean imported;
        try {
            imported = config.applyProfileData(data);
        } catch (Throwable t) {
            System.err.println("[SaltClient] Could not import profile: " + t);
            imported = false;
        } finally {
            client.setLoading(false);
        }
        if (!imported)
            return false;

        ConfigIO.write(profileKey(activeSlot), data);
        saveMeta();
        client.saveConfig();
        return true;
    }

    /** Reset the live client settings to defaults, then save that state. */
    public void resetCurrentConfig() {
        Client client = Client.INSTANCE;
        client.setLoading(true);
        try {
            client.getConfigManager().getJsonConfig().resetToDefaults();
        } finally {
            client.setLoading(false);
        }
        client.saveConfig();
        saveProfile(activeSlot);
    }

    public int getActiveSlot() {
        return activeSlot;
    }

    public int getMaxProfiles() {
        return MAX_PROFILES;
    }

    public String getName(int slot) {
        if (!validSlot(slot))
            return "???";
        return names[slot];
    }

    public boolean renameProfile(int slot, String name) {
        if (!validSlot(slot))
            return false;
        String safeName = sanitizeName(name);
        if (safeName == null)
            return false;
        names[slot] = safeName;
        saveMeta();
        return true;
    }

    public boolean hasData(int slot) {
        if (!validSlot(slot))
            return false;
        byte[] data = ConfigIO.read(profileKey(slot));
        return data != null && data.length > 0;
    }

    public int findEmptySlot() {
        for (int i = 0; i < MAX_PROFILES; i++) {
            if (!hasData(i))
                return i;
        }
        return -1;
    }

    private static boolean validSlot(int slot) {
        return slot >= 0 && slot < MAX_PROFILES;
    }

    private static String profileKey(int slot) {
        return "prof_" + slot;
    }

    private static String defaultName(int slot) {
        return "Profile " + (slot + 1);
    }

    private static String sanitizeName(String name) {
        if (name == null)
            return null;
        String value = name.trim().replace('\n', ' ').replace('\r', ' ');
        if (value.length() == 0)
            return null;
        if (value.length() > MAX_NAME_LENGTH)
            value = value.substring(0, MAX_NAME_LENGTH).trim();
        return value.length() == 0 ? null : value;
    }

    private void saveMeta() {
        StringBuilder sb = new StringBuilder();
        sb.append(activeSlot).append('\n');
        for (int i = 0; i < MAX_PROFILES; i++) {
            sb.append(names[i]).append('\n');
        }
        ConfigIO.write("prof_meta", sb.toString().getBytes());
    }

    private void loadMeta() {
        byte[] data = ConfigIO.read("prof_meta");
        if (data == null || data.length == 0)
            return;
        String[] lines = new String(data).split("\\n", -1);
        if (lines.length > 0) {
            try {
                int storedSlot = Integer.parseInt(lines[0].trim());
                if (validSlot(storedSlot))
                    activeSlot = storedSlot;
            } catch (NumberFormatException ignored) {
            }
        }
        // Older builds stored five names. Missing newer slots retain defaults.
        for (int i = 0; i < MAX_PROFILES && i + 1 < lines.length; i++) {
            String storedName = sanitizeName(lines[i + 1]);
            if (storedName != null)
                names[i] = storedName;
        }
    }
}
