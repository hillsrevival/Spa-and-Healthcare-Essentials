package client.config;

import client.module.Module;
import client.module.ModuleManager;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

public class ModuleConfig {

    private static final String FILE = "modules.bin";

    private static final int FORMAT_VERSION = 5;

    public void save() {
        ByteArrayOutputStream out = ConfigIO.out();
        out.write(FORMAT_VERSION);
        int count = ModuleManager.getModules().size();
        out.write((count >> 8) & 0xFF);
        out.write(count & 0xFF);
        for (Module m : ModuleManager.getModules()) {
            byte[] nameBytes = m.getName().getBytes();
            out.write(nameBytes.length & 0xFF);
            out.write(nameBytes, 0, nameBytes.length);
            out.write(m.isToggled() ? 1 : 0);
            int key = m.getKey();
            out.write((key >> 24) & 0xFF);
            out.write((key >> 16) & 0xFF);
            out.write((key >> 8) & 0xFF);
            out.write(key & 0xFF);
            out.write(m.isHiddenInGUI() ? 1 : 0);
            out.write(m.isFavorite() ? 1 : 0);
        }
        ConfigIO.write(FILE, out.toByteArray());
    }

    public void load() {
        if (!ConfigIO.exists(FILE))
            return;
        byte[] data = ConfigIO.read(FILE);
        if (data.length == 0)
            return;
        ByteArrayInputStream in = ConfigIO.in(data);
        int version = in.read();
        if (version < 0)
            return;
        if (version == 1) {
            int count = in.read();
            if (count < 0)
                return;
            loadV1(in, count);
            return;
        }
        if (version == 2) {
            int count = in.read();
            if (count < 0)
                return;
            loadV2(in, count);
            return;
        }
        if (version == 3) {
            int hi = in.read();
            int lo = in.read();
            if (hi < 0 || lo < 0)
                return;
            int count = (hi << 8) | lo;
            loadV2(in, count);
            return;
        }
        if (version == 4) {
            int hi = in.read();
            int lo = in.read();
            if (hi < 0 || lo < 0)
                return;
            int count = (hi << 8) | lo;
            loadV4(in, count);
            return;
        }
        if (version == 5) {
            int hi = in.read();
            int lo = in.read();
            if (hi < 0 || lo < 0)
                return;
            int count = (hi << 8) | lo;
            loadV5(in, count);
            return;
        }
        loadV1(in, version);
    }

    private void loadV1(ByteArrayInputStream in, int count) {
        for (int i = 0; i < count; i++) {
            int nameLen = in.read();
            if (nameLen <= 0)
                return;
            byte[] nameBytes = new byte[nameLen];
            in.read(nameBytes, 0, nameLen);
            String name = new String(nameBytes);
            boolean toggled = in.read() == 1;
            Module m = ModuleManager.getModuleByName(name);
            if (m != null) {
                m.setToggled(toggled);
            }
        }
    }

    private void loadV2(ByteArrayInputStream in, int count) {
        for (int i = 0; i < count; i++) {
            int nameLen = in.read();
            if (nameLen <= 0)
                return;
            byte[] nameBytes = new byte[nameLen];
            in.read(nameBytes, 0, nameLen);
            String name = new String(nameBytes);
            boolean toggled = in.read() == 1;
            int key = -1;
            for (int b = 3; b >= 0; b--) {
                int v = in.read();
                if (v == -1) {
                    key = -1;
                    break;
                }
                if (b == 3)
                    key = 0;
                key |= (v & 0xFF) << (b * 8);
            }
            Module m = ModuleManager.getModuleByName(name);
            if (m != null) {
                m.setKey(key);
                m.setToggled(toggled);
            }
        }
    }

    private void loadV5(ByteArrayInputStream in, int count) {
        for (int i = 0; i < count; i++) {
            int nameLen = in.read();
            if (nameLen <= 0)
                return;
            byte[] nameBytes = new byte[nameLen];
            if (in.read(nameBytes, 0, nameLen) != nameLen)
                return;
            String name = new String(nameBytes);
            boolean toggled = in.read() == 1;
            int key = 0;
            for (int b = 3; b >= 0; b--) {
                int v = in.read();
                if (v < 0)
                    return;
                key |= (v & 0xFF) << (b * 8);
            }
            int hiddenByte = in.read();
            int favoriteByte = in.read();
            if (hiddenByte < 0 || favoriteByte < 0)
                return;
            Module m = ModuleManager.getModuleByName(name);
            if (m != null) {
                m.setKey(key);
                m.setToggled(toggled);
                m.setHiddenInGUI(hiddenByte == 1);
                m.setFavorite(favoriteByte == 1);
            }
        }
    }

    private void loadV4(ByteArrayInputStream in, int count) {
        for (int i = 0; i < count; i++) {
            int nameLen = in.read();
            if (nameLen <= 0)
                return;
            byte[] nameBytes = new byte[nameLen];
            in.read(nameBytes, 0, nameLen);
            String name = new String(nameBytes);
            boolean toggled = in.read() == 1;
            int key = -1;
            for (int b = 3; b >= 0; b--) {
                int v = in.read();
                if (v == -1) {
                    key = -1;
                    break;
                }
                if (b == 3)
                    key = 0;
                key |= (v & 0xFF) << (b * 8);
            }
            int hiddenByte = in.read();
            boolean hidden = hiddenByte == 1;
            Module m = ModuleManager.getModuleByName(name);
            if (m != null) {
                m.setKey(key);
                m.setToggled(toggled);
                m.setHiddenInGUI(hidden);
            }
        }
    }
}
