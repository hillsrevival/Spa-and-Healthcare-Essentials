package client.config;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import net.lax1dude.eaglercraft.EagRuntime;

public class ConfigIO {

    private static final String PREFIX = "gc_";

    public static void write(String name, byte[] data) {
        EagRuntime.setStorage(PREFIX + name, data);
    }

    public static byte[] read(String name) {
        byte[] data = EagRuntime.getStorage(PREFIX + name);
        if (data == null) {
            return new byte[0];
        }
        return data;
    }

    public static boolean exists(String name) {
        return EagRuntime.getStorage(PREFIX + name) != null;
    }

    public static ByteArrayOutputStream out() {
        return new ByteArrayOutputStream();
    }

    public static ByteArrayInputStream in(byte[] data) {
        return new ByteArrayInputStream(data);
    }
}
