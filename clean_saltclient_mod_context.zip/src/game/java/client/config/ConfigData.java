package client.config;

import java.util.ArrayList;
import java.util.List;
import client.module.Module;
import client.module.ModuleManager;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import client.module.ModeSetting;
import client.module.Setting;

public class ConfigData {

    public List<ModuleEntry> modules = new ArrayList<>();

    public ConfigData(ModuleManager moduleManager) {
        for (Module m : moduleManager.getModules()) {
            modules.add(new ModuleEntry(m));
        }
    }

    public void apply(ModuleManager moduleManager) {
        for (ModuleEntry entry : modules) {
            Module m = moduleManager.getModuleByName(entry.name);
            if (m == null)
                continue;
            m.setToggled(entry.toggled);
            entry.applySettings(m);
        }
    }

    public static class ModuleEntry {

        public String name;

        public boolean toggled;

        public List<SettingEntry> settings = new ArrayList<>();

        public ModuleEntry(Module m) {
            this.name = m.getName();
            this.toggled = m.isToggled();
            for (Setting<?> s : m.getSettings()) {
                settings.add(new SettingEntry(s));
            }
        }

        public void applySettings(Module m) {
            for (SettingEntry entry : settings) {
                Setting<?> s = m.getSettingByName(entry.name);
                if (s == null)
                    continue;
                if (s instanceof BooleanSetting) {
                    ((BooleanSetting) s).setValue((Boolean) entry.value);
                } else if (s instanceof NumberSetting) {
                    ((NumberSetting) s).setValue(((Number) entry.value).doubleValue());
                } else if (s instanceof ModeSetting) {
                    ((ModeSetting) s).setMode((String) entry.value);
                }
            }
        }
    }

    public static class SettingEntry {

        public String name;

        public Object value;

        public SettingEntry(Setting<?> s) {
            this.name = s.getName();
            this.value = s.getValue();
        }
    }
}
