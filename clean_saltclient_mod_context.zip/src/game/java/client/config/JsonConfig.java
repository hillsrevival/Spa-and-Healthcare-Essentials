package client.config;

import client.module.BlockListSetting;
import client.module.BindSetting;
import client.module.BooleanSetting;
import client.module.ColorSetting;
import client.module.ItemFilterSetting;
import client.module.ModeSetting;
import client.module.Module;
import client.module.ModuleManager;
import client.module.NumberSetting;
import client.module.RandomSetting;
import client.module.Setting;
import client.module.StringSetting;
import client.module.TargetFilterSetting;
import client.utils.misc.FriendManager;
import client.Client;
import net.lax1dude.eaglercraft.EagRuntime;
import net.lax1dude.eaglercraft.internal.FileChooserResult;

public class JsonConfig {

    private static final String KEY = "config";

    private static final int VERSION = 3;

    private boolean dirty = false;

    private long lastDirtyTime = 0;

    private static final long SAVE_DELAY_MS = 500;

    public void save() {
        dirty = true;
        lastDirtyTime = System.currentTimeMillis();
    }

    public void tick() {
        if (!dirty)
            return;
        if (System.currentTimeMillis() - lastDirtyTime < SAVE_DELAY_MS)
            return;
        dirty = false;
        writeNow();
    }

    public void saveNow() {
        dirty = false;
        writeNow();
    }

    private void writeNow() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"version\":").append(VERSION).append(",\n");
        sb.append("  \"modules\":{");
        boolean first = true;
        for (Module m : ModuleManager.getModules()) {
            if (moduleIsDefault(m))
                continue;
            sb.append(first ? "\n" : ",\n");
            first = false;
            sb.append("    ").append(jsonStr(m.getName())).append(":{");
            sb.append("\"enabled\":").append(m.isToggled());
            sb.append(", \"key\":").append(m.getKey());
            sb.append(", \"hidden\":").append(m.isHiddenInGUI());
            sb.append(", \"favorite\":").append(m.isFavorite());
            sb.append("}");
        }
        sb.append(first ? "},\n" : "\n  },\n");
        sb.append("  \"settings\":{");
        first = true;
        for (Module m : ModuleManager.getModules()) {
            if (m.getSettings().isEmpty())
                continue;
            StringBuilder modSb = new StringBuilder();
            boolean firstSetting = true;
            for (Setting<?> s : m.getSettings()) {
                if (settingIsDefault(s))
                    continue;
                modSb.append(firstSetting ? "\n" : ",\n");
                firstSetting = false;
                modSb.append("      ").append(jsonStr(s.getName())).append(":");
                if (s instanceof BooleanSetting) {
                    modSb.append(((BooleanSetting) s).getValue());
                } else if (s instanceof NumberSetting) {
                    modSb.append(((NumberSetting) s).getValue());
                } else if (s instanceof ColorSetting) {
                    modSb.append(((ColorSetting) s).getValue());
                } else if (s instanceof ModeSetting) {
                    modSb.append(jsonStr(((ModeSetting) s).getValue()));
                } else if (s instanceof StringSetting) {
                    modSb.append(jsonStr(((StringSetting) s).getValue()));
                } else if (s instanceof BlockListSetting) {
                    String[] blocks = ((BlockListSetting) s).getValue();
                    modSb.append("[");
                    if (blocks != null) {
                        for (int i = 0; i < blocks.length; i++) {
                            if (i > 0)
                                modSb.append(",");
                            modSb.append(jsonStr(blocks[i]));
                        }
                    }
                    modSb.append("]");
                } else if (s instanceof RandomSetting) {
                    RandomSetting rs = (RandomSetting) s;
                    modSb.append("[").append(rs.getMin()).append(",").append(rs.getMax()).append("]");
                } else if (s instanceof BindSetting) {
                    BindSetting bs = (BindSetting) s;
                    modSb.append("[").append(bs.getKeyCode()).append(",").append(bs.getActivationMode()).append("]");
                } else if (s instanceof ItemFilterSetting) {
                    String[] items = ((ItemFilterSetting) s).getValue();
                    modSb.append("[");
                    if (items != null) {
                        for (int i = 0; i < items.length; i++) {
                            if (i > 0)
                                modSb.append(",");
                            modSb.append(jsonStr(items[i]));
                        }
                    }
                    modSb.append("]");
                } else if (s instanceof TargetFilterSetting) {
                    Boolean[] tval = ((TargetFilterSetting) s).getValue();
                    modSb.append("[");
                    if (tval != null) {
                        for (int i = 0; i < tval.length; i++) {
                            if (i > 0)
                                modSb.append(",");
                            modSb.append(tval[i]);
                        }
                    }
                    modSb.append("]");
                } else {
                    modSb.append("null");
                }
            }
            if (modSb.length() == 0)
                continue;
            sb.append(first ? "\n" : ",\n");
            first = false;
            sb.append("    ").append(jsonStr(m.getName())).append(":{");
            sb.append(modSb);
            sb.append("\n    }");
        }
        sb.append(first ? "},\n" : "\n  },\n");
        sb.append("  \"friends\":[");
        java.util.Set<String> friends = FriendManager.getFriends();
        {
            int i = 0;
            for (String name : friends) {
                if (i > 0)
                    sb.append(", ");
                sb.append(jsonStr(name));
                i++;
            }
        }
        sb.append("],\n");
        sb.append("  \"gui_key\":").append(Client.INSTANCE.getGuiKey()).append(",\n");
        sb.append("  \"auto_wss\":").append(Client.INSTANCE.isAutoWss()).append(",\n");
        byte[] guiLayout = ConfigIO.read("gui_layout");
        int layout = guiLayout != null && guiLayout.length > 0 ? guiLayout[0] & 0xFF : 0;
        sb.append("  \"gui_layout\":").append(layout).append(",\n");
        sb.append("  \"panel_states\":{");
        client.module.Category[] categories = client.module.Category.values();
        for (int i = 0; i < categories.length; i++) {
            if (i > 0) sb.append(",");
            String categoryKey = "panel_ext_" + categories[i].name().toLowerCase();
            byte[] state = ConfigIO.read(categoryKey);
            boolean expanded = state == null || state.length == 0 || state[0] != 0;
            sb.append(jsonStr(categories[i].name())).append(":").append(expanded);
        }
        sb.append("}\n");
        sb.append("}");
        ConfigIO.write(KEY, sb.toString().getBytes());
    }

    public void load() {
        if (!ConfigIO.exists(KEY))
            return;
        byte[] data = ConfigIO.read(KEY);
        if (data.length == 0)
            return;
        if (!isValidProfileData(data)) {
            System.err.println("[SaltClient] Ignoring invalid saved config data");
            return;
        }
        String json = new String(data);
        applyConfig(json);
    }

    public boolean applyProfileData(byte[] data) {
        if (!isValidProfileData(data))
            return false;
        applyConfig(new String(data));
        return true;
    }

    /** Reject incomplete or unrelated files before they can reset live settings. */
    public boolean isValidProfileData(byte[] data) {
        if (data == null || data.length == 0)
            return false;
        String json = new String(data).trim();
        if (json.length() < 2 || json.charAt(0) != '{' || json.charAt(json.length() - 1) != '}')
            return false;
        if (findMatchingBrace(json, 0) != json.length() - 1)
            return false;
        Integer version = extractInt(json, "version");
        if (version == null || version.intValue() < 1)
            return false;
        return extractObject(json, "modules") != null && extractObject(json, "settings") != null;
    }

    /** Reset every client-owned config value while preserving unrelated Eaglercraft data. */
    public void resetToDefaults() {
        resetAllModulesToDefaults();
        FriendManager.clearFriends();
        Client.INSTANCE.setGuiKey(net.lax1dude.eaglercraft.Keyboard.KEY_RSHIFT);
        Client.INSTANCE.setAutoWss(true);
        ConfigIO.write("gui_layout", new byte[] { 0 });
        for (client.module.Category category : client.module.Category.values()) {
            ConfigIO.write("panel_ext_" + category.name().toLowerCase(), new byte[] { 1 });
        }
        saveNow();
    }

    private void applyConfig(String json) {
        resetAllModulesToDefaults();
        String modulesJson = extractObject(json, "modules");
        if (modulesJson != null) {
            parseModules(modulesJson);
        }
        String settingsJson = extractObject(json, "settings");
        if (settingsJson != null) {
            parseSettings(settingsJson);
        }
        FriendManager.clearFriends();
        String friendsJson = extractArray(json, "friends");
        if (friendsJson != null) {
            parseFriends(friendsJson);
        }
        Integer guiKey = extractInt(json, "gui_key");
        if (guiKey != null) {
            Client.INSTANCE.setGuiKey(guiKey);
        }
        Boolean autoWss = extractBool(json, "auto_wss");
        if (autoWss != null) {
            Client.INSTANCE.setAutoWss(autoWss);
        }
        Integer guiLayout = extractInt(json, "gui_layout");
        if (guiLayout != null && guiLayout >= 0 && guiLayout < 3) {
            ConfigIO.write("gui_layout", new byte[] { (byte) guiLayout.intValue() });
        }
        String panelStates = extractObject(json, "panel_states");
        if (panelStates != null) {
            for (client.module.Category category : client.module.Category.values()) {
                Boolean expanded = extractBool(panelStates, category.name());
                if (expanded != null) {
                    String key = "panel_ext_" + category.name().toLowerCase();
                    ConfigIO.write(key, new byte[] { (byte) (expanded.booleanValue() ? 1 : 0) });
                }
            }
        }
    }

    private static boolean settingIsDefault(Setting<?> s) {
        Object value = s.getValue();
        Object def = s.getDefault();
        if (s instanceof BlockListSetting) {
            return java.util.Arrays.equals((String[]) value, (String[]) def);
        }
        if (s instanceof RandomSetting || s instanceof BindSetting || s instanceof ItemFilterSetting || s instanceof TargetFilterSetting) {
            return false;
        }
        return value == null ? def == null : value.equals(def);
    }

    private static boolean moduleIsDefault(Module m) {
        if (m.isToggled())
            return false;
        if (m.getKey() != -1)
            return false;
        if (m.isHiddenInGUI())
            return false;
        if (m.isFavorite())
            return false;
        for (Setting<?> s : m.getSettings()) {
            if (!settingIsDefault(s))
                return false;
        }
        return true;
    }

    private static void resetAllModulesToDefaults() {
        Module.setSuppressToggleNotifications(true);
        try {
            for (Module m : ModuleManager.getModules()) {
                if (m.isToggled())
                    m.setToggled(false);
                if (m.getKey() != -1)
                    m.setKey(-1);
                if (m.isHiddenInGUI())
                    m.setHiddenInGUI(false);
                if (m.isFavorite())
                    m.setFavorite(false);
                for (Setting<?> s : m.getSettings()) {
                    if (!settingIsDefault(s)) {
                        resetSettingToDefault(s);
                    }
                }
            }
        } finally {
            Module.setSuppressToggleNotifications(false);
        }
    }

    private static <T> void resetSettingToDefault(Setting<T> s) {
        s.setValue(s.getDefault());
    }

    private void parseModules(String json) {
        int pos = 0;
        while (pos < json.length()) {
            int keyStart = json.indexOf('"', pos);
            if (keyStart < 0)
                break;
            int keyEnd = json.indexOf('"', keyStart + 1);
            if (keyEnd < 0)
                break;
            String modName = json.substring(keyStart + 1, keyEnd);
            int objStart = json.indexOf('{', keyEnd);
            if (objStart < 0)
                break;
            int objEnd = findMatchingBrace(json, objStart);
            if (objEnd < 0)
                break;
            String modObj = json.substring(objStart + 1, objEnd);
            Module m = ModuleManager.getModuleByName(modName);
            if (m != null) {
                Boolean enabled = extractBool(modObj, "enabled");
                if (enabled != null) {
                    Module.setSuppressToggleNotifications(true);
                    m.setToggled(enabled);
                    Module.setSuppressToggleNotifications(false);
                }
                Integer key = extractInt(modObj, "key");
                if (key != null)
                    m.setKey(key);
                Boolean hidden = extractBool(modObj, "hidden");
                if (hidden != null)
                    m.setHiddenInGUI(hidden);
                Boolean favorite = extractBool(modObj, "favorite");
                if (favorite != null)
                    m.setFavorite(favorite);
            }
            pos = objEnd + 1;
        }
    }

    private void parseSettings(String json) {
        int pos = 0;
        while (pos < json.length()) {
            int keyStart = json.indexOf('"', pos);
            if (keyStart < 0)
                break;
            int keyEnd = json.indexOf('"', keyStart + 1);
            if (keyEnd < 0)
                break;
            String modName = json.substring(keyStart + 1, keyEnd);
            int objStart = json.indexOf('{', keyEnd);
            if (objStart < 0)
                break;
            int objEnd = findMatchingBrace(json, objStart);
            if (objEnd < 0)
                break;
            String settingsObj = json.substring(objStart + 1, objEnd);
            Module m = ModuleManager.getModuleByName(modName);
            if (m != null) {
                parseModuleSettings(m, settingsObj);
            }
            pos = objEnd + 1;
        }
    }

    private void parseModuleSettings(Module m, String json) {
        int pos = 0;
        while (pos < json.length()) {
            int keyStart = json.indexOf('"', pos);
            if (keyStart < 0)
                break;
            int keyEnd = json.indexOf('"', keyStart + 1);
            if (keyEnd < 0)
                break;
            String settingName = json.substring(keyStart + 1, keyEnd);
            int colonIdx = json.indexOf(':', keyEnd);
            if (colonIdx < 0)
                break;
            int valStart = colonIdx + 1;
            while (valStart < json.length() && (json.charAt(valStart) == ' ' || json.charAt(valStart) == '\t')) valStart++;
            if (valStart >= json.length())
                break;
            char firstChar = json.charAt(valStart);
            String rawValue;
            int valEnd;
            if (firstChar == '"') {
                valEnd = valStart + 1;
                while (valEnd < json.length()) {
                    char ch = json.charAt(valEnd);
                    if (ch == '\\') {
                        valEnd += 2;
                        continue;
                    }
                    if (ch == '"')
                        break;
                    valEnd++;
                }
                if (valEnd >= json.length())
                    break;
                rawValue = json.substring(valStart + 1, valEnd);
                rawValue = rawValue.replace("\\\"", "\"").replace("\\\\", "\\").replace("\\/", "/");
                valEnd++;
            } else if (firstChar == '[') {
                valEnd = findMatchingBracket(json, valStart);
                if (valEnd < 0)
                    break;
                rawValue = json.substring(valStart, valEnd + 1);
            } else {
                valEnd = valStart;
                while (valEnd < json.length() && json.charAt(valEnd) != ',' && json.charAt(valEnd) != '}' && json.charAt(valEnd) != '\n') {
                    valEnd++;
                }
                rawValue = json.substring(valStart, valEnd).trim();
            }
            Setting<?> s = m.getSettingByName(settingName);
            if (s != null) {
                applySettingValue(s, rawValue);
            }
            pos = valEnd;
            while (pos < json.length() && (json.charAt(pos) == ',' || json.charAt(pos) == ' ' || json.charAt(pos) == '\n' || json.charAt(pos) == '\t')) pos++;
        }
    }

    @SuppressWarnings("unchecked")
    private void applySettingValue(Setting<?> s, String rawValue) {
        try {
            if (s instanceof BooleanSetting) {
                ((BooleanSetting) s).setValue(Boolean.parseBoolean(rawValue));
            } else if (s instanceof NumberSetting) {
                ((NumberSetting) s).setValue(Double.parseDouble(rawValue));
            } else if (s instanceof ColorSetting) {
                ((ColorSetting) s).setValue(Double.parseDouble(rawValue));
            } else if (s instanceof ModeSetting) {
                ((ModeSetting) s).setMode(rawValue);
            } else if (s instanceof StringSetting) {
                ((StringSetting) s).setValue(rawValue);
            } else if (s instanceof BlockListSetting) {
                String inner = rawValue;
                if (inner.startsWith("["))
                    inner = inner.substring(1);
                if (inner.endsWith("]"))
                    inner = inner.substring(0, inner.length() - 1);
                java.util.List<String> blocks = new java.util.ArrayList<>();
                int i = 0;
                while (i < inner.length()) {
                    int q1 = inner.indexOf('"', i);
                    if (q1 < 0)
                        break;
                    int q2 = inner.indexOf('"', q1 + 1);
                    if (q2 < 0)
                        break;
                    blocks.add(inner.substring(q1 + 1, q2));
                    i = q2 + 1;
                }
                ((BlockListSetting) s).setValue(blocks.toArray(new String[0]));
            } else if (s instanceof RandomSetting) {
                String inner = rawValue;
                if (inner.startsWith("["))
                    inner = inner.substring(1);
                if (inner.endsWith("]"))
                    inner = inner.substring(0, inner.length() - 1);
                String[] parts = inner.split(",");
                if (parts.length >= 2) {
                    double min = Double.parseDouble(parts[0].trim());
                    double max = Double.parseDouble(parts[1].trim());
                    ((RandomSetting) s).setValue(new double[] { min, max });
                }
            } else if (s instanceof BindSetting) {
                String inner = rawValue;
                if (inner.startsWith("["))
                    inner = inner.substring(1);
                if (inner.endsWith("]"))
                    inner = inner.substring(0, inner.length() - 1);
                String[] parts = inner.split(",");
                if (parts.length >= 2) {
                    int key = Integer.parseInt(parts[0].trim());
                    int mode = Integer.parseInt(parts[1].trim());
                    ((BindSetting) s).setValue(new int[] { key, mode });
                }
            } else if (s instanceof ItemFilterSetting) {
                String inner = rawValue;
                if (inner.startsWith("["))
                    inner = inner.substring(1);
                if (inner.endsWith("]"))
                    inner = inner.substring(0, inner.length() - 1);
                java.util.List<String> items = new java.util.ArrayList<>();
                int i = 0;
                while (i < inner.length()) {
                    int q1 = inner.indexOf('"', i);
                    if (q1 < 0)
                        break;
                    int q2 = inner.indexOf('"', q1 + 1);
                    if (q2 < 0)
                        break;
                    items.add(inner.substring(q1 + 1, q2));
                    i = q2 + 1;
                }
                ((ItemFilterSetting) s).setValue(items.toArray(new String[0]));
            } else if (s instanceof TargetFilterSetting) {
                String inner = rawValue;
                if (inner.startsWith("["))
                    inner = inner.substring(1);
                if (inner.endsWith("]"))
                    inner = inner.substring(0, inner.length() - 1);
                String[] parts = inner.split(",");
                Boolean[] tval = new Boolean[6];
                for (int i = 0; i < 6 && i < parts.length; i++) {
                    tval[i] = Boolean.parseBoolean(parts[i].trim());
                }
                ((TargetFilterSetting) s).setValue(tval);
            }
        } catch (Exception e) {
        }
    }

    private void parseFriends(String json) {
        int pos = 0;
        while (pos < json.length()) {
            int q1 = json.indexOf('"', pos);
            if (q1 < 0)
                break;
            int q2 = json.indexOf('"', q1 + 1);
            if (q2 < 0)
                break;
            String name = json.substring(q1 + 1, q2);
            FriendManager.addFriend(name);
            pos = q2 + 1;
        }
    }

    public void exportToFile() {
        writeNow();
        byte[] data = ConfigIO.read(KEY);
        if (data == null || data.length == 0) {
            data = "{\"version\":1,\"modules\":{},\"settings\":{},\"friends\":[]}".getBytes();
        }
        EagRuntime.downloadFileWithName("saltclient-config.json", data);
    }

    public void importFromFile() {
        EagRuntime.displayFileChooser("application/json", "json");
    }

    public boolean checkImportResult() {
        FileChooserResult result = EagRuntime.getFileChooserResult();
        if (result == null || result.fileData == null || result.fileData.length == 0) {
            return false;
        }
        EagRuntime.clearFileChooserResult();
        if (!isValidProfileData(result.fileData)) {
            return false;
        }
        String json = new String(result.fileData);
        applyConfig(json);
        saveNow();
        return true;
    }

    private static String jsonStr(String s) {
        if (s == null)
            return "null";
        StringBuilder sb = new StringBuilder();
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch(c) {
                case '"':
                    sb.append("\\\"");
                    break;
                case '\\':
                    sb.append("\\\\");
                    break;
                case '\n':
                    sb.append("\\n");
                    break;
                case '\r':
                    sb.append("\\r");
                    break;
                case '\t':
                    sb.append("\\t");
                    break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        sb.append('"');
        return sb.toString();
    }

    private static String extractObject(String json, String key) {
        String searchKey = "\"" + key + "\"";
        int keyIdx = json.indexOf(searchKey);
        if (keyIdx < 0)
            return null;
        int colonIdx = json.indexOf(':', keyIdx + searchKey.length());
        if (colonIdx < 0)
            return null;
        int braceStart = json.indexOf('{', colonIdx);
        if (braceStart < 0)
            return null;
        int braceEnd = findMatchingBrace(json, braceStart);
        if (braceEnd < 0)
            return null;
        return json.substring(braceStart + 1, braceEnd);
    }

    private static String extractArray(String json, String key) {
        String searchKey = "\"" + key + "\"";
        int keyIdx = json.indexOf(searchKey);
        if (keyIdx < 0)
            return null;
        int colonIdx = json.indexOf(':', keyIdx + searchKey.length());
        if (colonIdx < 0)
            return null;
        int bracketStart = json.indexOf('[', colonIdx);
        if (bracketStart < 0)
            return null;
        int bracketEnd = findMatchingBracket(json, bracketStart);
        if (bracketEnd < 0)
            return null;
        return json.substring(bracketStart + 1, bracketEnd);
    }

    private static Integer extractInt(String json, String key) {
        String searchKey = "\"" + key + "\"";
        int keyIdx = json.indexOf(searchKey);
        if (keyIdx < 0)
            return null;
        int colonIdx = json.indexOf(':', keyIdx + searchKey.length());
        if (colonIdx < 0)
            return null;
        int start = colonIdx + 1;
        while (start < json.length() && Character.isWhitespace(json.charAt(start))) start++;
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}' && json.charAt(end) != '\n' && json.charAt(end) != ' ') end++;
        try {
            return Integer.parseInt(json.substring(start, end).trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static Boolean extractBool(String json, String key) {
        String searchKey = "\"" + key + "\"";
        int keyIdx = json.indexOf(searchKey);
        if (keyIdx < 0)
            return null;
        int colonIdx = json.indexOf(':', keyIdx + searchKey.length());
        if (colonIdx < 0)
            return null;
        int start = colonIdx + 1;
        while (start < json.length() && Character.isWhitespace(json.charAt(start))) start++;
        if (json.startsWith("true", start))
            return true;
        if (json.startsWith("false", start))
            return false;
        return null;
    }

    private static int findMatchingBrace(String json, int openPos) {
        int depth = 0;
        boolean inString = false;
        for (int i = openPos; i < json.length(); i++) {
            char c = json.charAt(i);
            if (inString) {
                if (c == '\\') {
                    i++;
                    continue;
                }
                if (c == '"')
                    inString = false;
            } else {
                if (c == '"')
                    inString = true;
                else if (c == '{')
                    depth++;
                else if (c == '}') {
                    depth--;
                    if (depth == 0)
                        return i;
                }
            }
        }
        return -1;
    }

    private static int findMatchingBracket(String json, int openPos) {
        int depth = 0;
        boolean inString = false;
        for (int i = openPos; i < json.length(); i++) {
            char c = json.charAt(i);
            if (inString) {
                if (c == '\\') {
                    i++;
                    continue;
                }
                if (c == '"')
                    inString = false;
            } else {
                if (c == '"')
                    inString = true;
                else if (c == '[')
                    depth++;
                else if (c == ']') {
                    depth--;
                    if (depth == 0)
                        return i;
                }
            }
        }
        return -1;
    }
}
