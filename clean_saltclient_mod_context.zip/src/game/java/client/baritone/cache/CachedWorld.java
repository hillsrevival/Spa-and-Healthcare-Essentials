package client.baritone.cache;

import client.baritone.cache.LongIntMap;
import client.baritone.cache.LongObjMap;
import net.minecraft.client.Minecraft;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;

public class CachedWorld {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final LongObjMap chunks = new LongObjMap(512);

    private static final int MAX_CHUNKS = 256;

    private static long accessClock = 0;

    private static final long[] chunkAccessTime = new long[MAX_CHUNKS];

    private static final long[] chunkKeys = new long[MAX_CHUNKS];

    private static int chunkCount = 0;

    private static final LongIntMap chunkIndexMap = new LongIntMap(512);

    public static final int SOLID = CachedChunk.SOLID;

    public static final int WATER = CachedChunk.WATER;

    public static final int DANGER = CachedChunk.DANGER;

    public static final int CLIMB = CachedChunk.CLIMB;

    public static final int SOUL_SND = CachedChunk.SOUL_SND;

    public static final int LIQUID = CachedChunk.LIQUID;

    public static final int OPAQUE = CachedChunk.OPAQUE;

    public static final int WALK_SP = CachedChunk.WALK_SP;

    private static final long KEY_XOR = 0x9E3779B97E3779B7L;

    private static long chunkKey(int cx, int cz) {
        return (((long) cx << 32) | ((long) cz & 0xFFFFFFFFL)) ^ KEY_XOR;
    }

    public static int getFlags(int x, int y, int z) {
        int cx = x >> 4;
        int cz = z >> 4;
        int lx = x & 15;
        int lz = z & 15;
        long key = chunkKey(cx, cz);
        CachedChunk chunk = (CachedChunk) chunks.get(key);
        if (chunk == null)
            return 0;
        return chunk.getFlags(lx, y, lz) & 0xFF;
    }

    public static CachedChunk ensureLoaded(int x, int y, int z) {
        int cx = x >> 4;
        int cz = z >> 4;
        long key = chunkKey(cx, cz);
        CachedChunk chunk = (CachedChunk) chunks.get(key);
        if (chunk != null) {
            touchChunk(key);
            return chunk;
        }
        World world = mc.world;
        if (world == null)
            return null;
        try {
            Chunk worldChunk = world.getChunkFromChunkCoords(cx, cz);
            if (worldChunk == null || worldChunk.isEmpty()) {
                return null;
            }
            if (chunkCount >= MAX_CHUNKS) {
                evictLRU();
            }
            chunk = new CachedChunk(cx, cz);
            chunk.populate();
            chunks.put(key, chunk);
            touchChunk(key);
            return chunk;
        } catch (Exception e) {
            return null;
        }
    }

    public static void invalidateChunk(int cx, int cz) {
        long key = chunkKey(cx, cz);
        chunks.remove(key);
        int idx = chunkIndexMap.remove(key);
        if (idx != Integer.MIN_VALUE && idx < chunkCount) {
            int last = chunkCount - 1;
            if (idx != last) {
                long lastKey = chunkKeys[last];
                chunkKeys[idx] = lastKey;
                chunkAccessTime[idx] = chunkAccessTime[last];
                chunkIndexMap.put(lastKey, idx);
            }
            chunkCount--;
        }
    }

    public static void invalidateAt(int x, int y, int z) {
        invalidateChunk(x >> 4, z >> 4);
    }

    public static void clearAll() {
        chunks.clear();
        chunkIndexMap.clear();
        chunkCount = 0;
        accessClock = 0;
    }

    private static void touchChunk(long key) {
        long now = ++accessClock;
        int idx = chunkIndexMap.get(key);
        if (idx != Integer.MIN_VALUE) {
            chunkAccessTime[idx] = now;
            return;
        }
        if (chunkCount < MAX_CHUNKS) {
            chunkKeys[chunkCount] = key;
            chunkAccessTime[chunkCount] = now;
            chunkIndexMap.put(key, chunkCount);
            chunkCount++;
        }
    }

    private static void evictLRU() {
        if (chunkCount == 0)
            return;
        int oldestIdx = 0;
        long oldestTime = chunkAccessTime[0];
        for (int i = 1; i < chunkCount; i++) {
            if (chunkAccessTime[i] < oldestTime) {
                oldestTime = chunkAccessTime[i];
                oldestIdx = i;
            }
        }
        long evictKey = chunkKeys[oldestIdx];
        chunks.remove(evictKey);
        chunkIndexMap.remove(evictKey);
        int last = chunkCount - 1;
        if (oldestIdx != last) {
            long lastKey = chunkKeys[last];
            chunkKeys[oldestIdx] = lastKey;
            chunkAccessTime[oldestIdx] = chunkAccessTime[last];
            chunkIndexMap.put(lastKey, oldestIdx);
        }
        chunkCount--;
    }

    public static int getCacheSize() {
        return chunks.size();
    }

    private static int preCacheCX = 0;

    private static int preCacheCZ = 0;

    private static int preCacheRadius = 0;

    private static int preCachePCX = 0;

    private static int preCachePCZ = 0;

    private static boolean preCacheActive = false;

    private static final int PRECACHE_CHUNKS_PER_TICK = 8;

    public static boolean preCacheAroundPlayer(int radius) {
        if (mc.player == null || mc.world == null)
            return true;
        int pcx = (int) Math.floor(mc.player.posX) >> 4;
        int pcz = (int) Math.floor(mc.player.posZ) >> 4;
        if (!preCacheActive || preCachePCX != pcx || preCachePCZ != pcz || preCacheRadius != radius) {
            preCacheCX = -radius;
            preCacheCZ = -radius;
            preCacheRadius = radius;
            preCachePCX = pcx;
            preCachePCZ = pcz;
            preCacheActive = true;
        }
        int cached = 0;
        while (preCacheCX <= radius) {
            while (preCacheCZ <= radius) {
                ensureLoaded((pcx + preCacheCX) << 4, 64, (pcz + preCacheCZ) << 4);
                cached++;
                preCacheCZ++;
                if (cached >= PRECACHE_CHUNKS_PER_TICK) {
                    if (preCacheCX > radius) {
                        preCacheActive = false;
                        return true;
                    }
                    return false;
                }
            }
            preCacheCZ = -radius;
            preCacheCX++;
        }
        preCacheActive = false;
        return true;
    }

    public static void resetPreCache() {
        preCacheActive = false;
    }

    public static boolean isSolid(int x, int y, int z) {
        int flags = getFlags(x, y, z);
        if (flags == 0) {
            return false;
        }
        return (flags & SOLID) != 0;
    }

    public static boolean isWater(int x, int y, int z) {
        return (getFlags(x, y, z) & WATER) != 0;
    }

    public static boolean isDangerous(int x, int y, int z) {
        return (getFlags(x, y, z) & DANGER) != 0;
    }

    public static boolean isClimbable(int x, int y, int z) {
        return (getFlags(x, y, z) & CLIMB) != 0;
    }

    public static boolean isSoulSand(int x, int y, int z) {
        return (getFlags(x, y, z) & SOUL_SND) != 0;
    }

    public static boolean canWalkThrough(int x, int y, int z) {
        int flags = getFlags(x, y, z);
        if (flags == 0)
            return true;
        if ((flags & WATER) != 0)
            return true;
        if ((flags & LIQUID) != 0)
            return true;
        if ((flags & SOLID) != 0)
            return false;
        if ((flags & OPAQUE) != 0)
            return false;
        return true;
    }

    public static boolean canWalkOn(int x, int y, int z) {
        int flags = getFlags(x, y, z);
        if ((flags & WATER) != 0)
            return true;
        if ((flags & SOLID) != 0)
            return true;
        if ((flags & WALK_SP) != 0)
            return true;
        return false;
    }
}
