package client.baritone.cache;

public final class LongIntMap {

    private long[] keys;

    private int[] values;

    private int size;

    private int mask;

    private static final long FREE_KEY = 0L;

    private static final int NO_VALUE = Integer.MIN_VALUE;

    private static final double LOAD_FACTOR = 0.75;

    public LongIntMap(int expectedSize) {
        int capacity = nextPowerOf2((int) (expectedSize / LOAD_FACTOR) + 1);
        keys = new long[capacity];
        values = new int[capacity];
        java.util.Arrays.fill(values, NO_VALUE);
        mask = capacity - 1;
        size = 0;
    }

    public int get(long key) {
        int idx = (int) (mix(key) & mask);
        long[] k = keys;
        for (; ; ) {
            long kIdx = k[idx];
            if (kIdx == key)
                return values[idx];
            if (kIdx == FREE_KEY)
                return NO_VALUE;
            idx = (idx + 1) & mask;
        }
    }

    public void put(long key, int value) {
        int idx = (int) (mix(key) & mask);
        long[] k = keys;
        int firstTombstone = -1;
        for (; ; ) {
            long kIdx = k[idx];
            if (kIdx == FREE_KEY) {
                int target = firstTombstone >= 0 ? firstTombstone : idx;
                k[target] = key;
                values[target] = value;
                size++;
                if (size > mask * LOAD_FACTOR)
                    resize();
                return;
            }
            if (kIdx == Long.MIN_VALUE) {
                if (firstTombstone < 0)
                    firstTombstone = idx;
            } else if (kIdx == key) {
                values[idx] = value;
                return;
            }
            idx = (idx + 1) & mask;
        }
    }

    public int remove(long key) {
        int idx = (int) (mix(key) & mask);
        long[] k = keys;
        for (; ; ) {
            long kIdx = k[idx];
            if (kIdx == key) {
                int old = values[idx];
                k[idx] = Long.MIN_VALUE;
                values[idx] = NO_VALUE;
                size--;
                return old;
            }
            if (kIdx == FREE_KEY)
                return NO_VALUE;
            idx = (idx + 1) & mask;
        }
    }

    public void clear() {
        java.util.Arrays.fill(keys, FREE_KEY);
        java.util.Arrays.fill(values, NO_VALUE);
        size = 0;
    }

    public int size() {
        return size;
    }

    private static long mix(long key) {
        long h = key ^ (key >>> 32);
        h ^= h >>> 16;
        h *= 0x85ebca6bL;
        h ^= h >>> 13;
        h *= 0xc2b2ae35L;
        h ^= h >>> 16;
        return h;
    }

    private static int nextPowerOf2(int n) {
        int p = 1;
        while (p < n) p <<= 1;
        return p;
    }

    private void resize() {
        int newCap = keys.length << 1;
        long[] oldKeys = keys;
        int[] oldVals = values;
        keys = new long[newCap];
        values = new int[newCap];
        java.util.Arrays.fill(values, NO_VALUE);
        mask = newCap - 1;
        size = 0;
        for (int i = 0; i < oldKeys.length; i++) {
            if (oldKeys[i] != FREE_KEY && oldKeys[i] != Long.MIN_VALUE && oldVals[i] != NO_VALUE) {
                put(oldKeys[i], oldVals[i]);
            }
        }
    }
}
