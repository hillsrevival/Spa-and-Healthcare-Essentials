package client.baritone.cache;

public class LongObjMap {

    private long[] keys;

    private Object[] values;

    private int size;

    private int mask;

    public LongObjMap(int capacity) {
        int cap = 1;
        while (cap < capacity * 2) cap <<= 1;
        keys = new long[cap];
        values = new Object[cap];
        mask = cap - 1;
        java.util.Arrays.fill(keys, Long.MIN_VALUE);
    }

    private int index(long key) {
        int h = (int) (key ^ (key >>> 32));
        return (h & 0x7FFFFFFF) & mask;
    }

    public Object get(long key) {
        int idx = index(key);
        long[] k = keys;
        Object[] v = values;
        while (true) {
            if (k[idx] == key)
                return v[idx];
            if (k[idx] == Long.MIN_VALUE)
                return null;
            idx = (idx + 1) & mask;
        }
    }

    public Object put(long key, Object value) {
        int idx = index(key);
        long[] k = keys;
        Object[] v = values;
        while (true) {
            if (k[idx] == Long.MIN_VALUE) {
                k[idx] = key;
                v[idx] = value;
                size++;
                if (size > keys.length / 2)
                    resize();
                return null;
            }
            if (k[idx] == key) {
                Object old = v[idx];
                v[idx] = value;
                return old;
            }
            idx = (idx + 1) & mask;
        }
    }

    public Object remove(long key) {
        int idx = index(key);
        long[] k = keys;
        Object[] v = values;
        while (true) {
            if (k[idx] == Long.MIN_VALUE)
                return null;
            if (k[idx] == key) {
                Object old = v[idx];
                k[idx] = Long.MIN_VALUE;
                v[idx] = null;
                size--;
                int next = (idx + 1) & mask;
                while (k[next] != Long.MIN_VALUE) {
                    long nk = k[next];
                    Object nv = v[next];
                    k[next] = Long.MIN_VALUE;
                    v[next] = null;
                    size--;
                    long[] oldK = keys;
                    put(nk, nv);
                    if (keys != oldK)
                        break;
                    next = (next + 1) & mask;
                }
                return old;
            }
            idx = (idx + 1) & mask;
        }
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void clear() {
        java.util.Arrays.fill(keys, Long.MIN_VALUE);
        java.util.Arrays.fill(values, null);
        size = 0;
    }

    private void resize() {
        long[] oldKeys = keys;
        Object[] oldVals = values;
        int newCap = oldKeys.length * 2;
        keys = new long[newCap];
        values = new Object[newCap];
        mask = newCap - 1;
        java.util.Arrays.fill(keys, Long.MIN_VALUE);
        size = 0;
        for (int i = 0; i < oldKeys.length; i++) {
            if (oldKeys[i] != Long.MIN_VALUE && oldVals[i] != null) {
                put(oldKeys[i], oldVals[i]);
            }
        }
    }
}
