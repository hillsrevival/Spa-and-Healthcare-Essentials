package client.baritone.cache;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;

public class CachedChunk {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final BlockPos POS = new BlockPos(0, 0, 0);

    private final byte[] data;

    public final int chunkX, chunkZ;

    private boolean populated;

    public static final int SOLID = 0x01;

    public static final int WATER = 0x02;

    public static final int DANGER = 0x04;

    public static final int CLIMB = 0x08;

    public static final int SOUL_SND = 0x10;

    public static final int LIQUID = 0x20;

    public static final int OPAQUE = 0x40;

    public static final int WALK_SP = 0x80;

    public CachedChunk(int chunkX, int chunkZ) {
        this.chunkX = chunkX;
        this.chunkZ = chunkZ;
        this.data = new byte[16 * 256 * 16];
        this.populated = false;
    }

    public void populate() {
        World world = mc.world;
        if (world == null)
            return;
        for (int i = 0; i < data.length; i++) {
            data[i] = 0;
        }
        Chunk chunk = world.getChunkFromChunkCoords(chunkX, chunkZ);
        if (chunk == null || chunk.isEmpty())
            return;
        for (int y = 0; y < 256; y++) {
            for (int lz = 0; lz < 16; lz++) {
                for (int lx = 0; lx < 16; lx++) {
                    try {
                        IBlockState state = chunk.getBlockState(lx, y, lz);
                        Block block = state.getBlock();
                        if (block == Blocks.AIR)
                            continue;
                        byte flags = encodeBlock(block, state);
                        if (flags != 0) {
                            int idx = (y * 16 + lz) * 16 + lx;
                            data[idx] = flags;
                        }
                    } catch (Exception e) {
                    }
                }
            }
        }
        populated = true;
    }

    private static byte encodeBlock(Block block, IBlockState state) {
        byte flags = 0;
        if (block == Blocks.WATER || block == Blocks.FLOWING_WATER) {
            flags |= WATER | LIQUID;
            return flags;
        }
        if (block == Blocks.LAVA || block == Blocks.FLOWING_LAVA) {
            flags |= DANGER | LIQUID;
            return flags;
        }
        if (block == Blocks.CACTUS || block == Blocks.FIRE || block == Blocks.MAGMA || block == Blocks.WEB || block == Blocks.END_PORTAL || block == Blocks.TRIPWIRE) {
            flags |= DANGER;
        }
        if (block == Blocks.LADDER || block == Blocks.VINE) {
            flags |= CLIMB;
        }
        if (block == Blocks.SOUL_SAND) {
            flags |= SOUL_SND;
        }
        if (block == Blocks.WATERLILY || block == Blocks.SNOW_LAYER) {
            flags |= WALK_SP;
        }
        Material mat = block.getMaterial(state);
        if (mat.isSolid()) {
            flags |= SOLID;
        }
        if (mat.isLiquid()) {
            flags |= LIQUID;
        }
        try {
            if (block.isOpaqueCube(state)) {
                flags |= OPAQUE;
            }
        } catch (Exception e) {
        }
        return flags;
    }

    public byte getFlags(int lx, int ly, int lz) {
        if (lx < 0 || lx > 15 || ly < 0 || ly > 255 || lz < 0 || lz > 15)
            return 0;
        int idx = (ly * 16 + lz) * 16 + lx;
        return data[idx];
    }

    public boolean isPopulated() {
        return populated;
    }

    public void updateBlock(int lx, int ly, int lz, IBlockState state) {
        if (lx < 0 || lx > 15 || ly < 0 || ly > 255 || lz < 0 || lz > 15)
            return;
        int idx = (ly * 16 + lz) * 16 + lx;
        Block block = state.getBlock();
        if (block == Blocks.AIR) {
            data[idx] = 0;
        } else {
            data[idx] = encodeBlock(block, state);
        }
    }
}
