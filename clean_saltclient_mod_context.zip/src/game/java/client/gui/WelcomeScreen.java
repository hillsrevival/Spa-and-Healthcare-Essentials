package client.gui;

import net.lax1dude.eaglercraft.Keyboard;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import client.Client;
import client.utils.misc.NotificationSystem;
import client.utils.render.ClientFontRenderer;

public class WelcomeScreen extends GuiScreen {

    private final Minecraft mc = Minecraft.getMinecraft();

    private static boolean checked = false;

    @Override
    public void initGui() {
        super.initGui();
        int centerY = this.height / 2;
        this.buttonList.add(new GuiButton(0, this.width / 2 - 75, centerY + 40, 150, 20, "Got it!"));
        this.buttonList.add(new GuiButton(1, this.width / 2 - 75, centerY + 62, 150, 20, "Open ClickGUI"));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        int cx = this.width / 2;
        String title = "Welcome to SaltClient!";
        ClientFontRenderer.drawCenteredStringWithShadow(title, cx, 40, 0xFFFFAA00);
        String[] lines = { "Here's how to get started:", "", "1. Press RSHIFT to open the ClickGUI", "2. Search for modules by name (e.g. 'KillAura')", "3. Click a module to toggle it ON/OFF", "4. Right-click settings to reset them to default", "5. Hover settings for tooltips (where available)", "", "Chat Commands:", "  .help - List all commands", "  .binds - Show your keybinds", "  .profile list - Manage config profiles", "  .toggle <module> - Toggle a module", "  .bind <module> <key> - Set a keybind", "", "Type .help in chat for the full command list.", "This screen won't show again. Enjoy!" };
        int y = 70;
        for (String line : lines) {
            int color = line.isEmpty() ? 0xFFFFFF : (line.startsWith("  ") ? 0xFFAAAAFF : (line.contains(":") && !line.startsWith(" ") ? 0xFFFFFFAA : 0xFFCCCCCC));
            ClientFontRenderer.drawCenteredStringWithShadow(line, cx, y, color);
            y += 12;
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void actionPerformed(GuiButton button) throws java.io.IOException {
        markSeen();
        enableDefaultModules();
        if (button.id == 0) {
            mc.displayGuiScreen(new net.minecraft.client.gui.GuiMainMenu());
        } else if (button.id == 1) {
            mc.displayGuiScreen(new client.gui.salt.SaltGui());
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws java.io.IOException {
        if (keyCode == Keyboard.KEY_RETURN || keyCode == Keyboard.KEY_ESCAPE) {
            markSeen();
            enableDefaultModules();
            mc.displayGuiScreen(new net.minecraft.client.gui.GuiMainMenu());
        }
    }

    private void enableDefaultModules() {
        if (!client.utils.misc.DefaultModules.hasEnabled()) {
            client.utils.misc.DefaultModules.enableDefaults();
        }
    }

    private void markSeen() {
        client.config.ConfigIO.write("welcome_seen", new byte[] { 1 });
        NotificationSystem.success("Welcome to SaltClient!");
    }

    public static boolean isFirstLaunch() {
        byte[] data = client.config.ConfigIO.read("welcome_seen");
        return data == null || data.length == 0 || data[0] == 0;
    }

    public static boolean hasChecked() {
        return checked;
    }

    public static void setChecked(boolean value) {
        checked = value;
    }
}
