package client.gui.clickgui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import client.module.Category;
import client.module.Module;
import client.module.ModuleManager;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;
import client.utils.render.StencilClipUtil;
import client.module.impl.fun.ColorUi;
import net.minecraft.client.gui.Gui;

public class Panel {

    private int x, y, width;

    private int headerHeight = 16;

    private int maxVisible = 350;

    private double scrollOffset = 0;

    private double smoothScrollOffset = 0;

    private boolean extended = true;

    private Category category;

    private List<ModuleButton> modules;

    private String searchFilter = "";

    private float expandProgress = 1.0f;

    private float glowPhase = 0.0f;

    private static final int PANEL_RADIUS = 6;

    private static final int SHADOW_OFFSET = 3;

    private static final int SHADOW_SPREAD = 6;

    private static final int SHADOW_ALPHA = 60;

    public static float scrollSpeed = 5.0f;

    public Panel(Category category, int x, int y, int width) {
        this.category = category;
        this.x = x;
        this.y = y;
        this.width = width;
        this.modules = new ArrayList<>();
        for (Module mod : ModuleManager.getModules()) {
            if (mod.getCategory() == category) {
                this.modules.add(new ModuleButton(mod));
            }
        }
        resortModules();
        loadExtendedState();
    }

    public void saveExtendedState() {
        client.config.ConfigIO.write("panel_ext_" + category.name().toLowerCase(), new byte[] { (byte) (extended ? 1 : 0) });
    }

    private void loadExtendedState() {
        byte[] data = client.config.ConfigIO.read("panel_ext_" + category.name().toLowerCase());
        if (data != null && data.length > 0) {
            extended = data[0] != 0;
            expandProgress = extended ? 1.0f : 0.0f;
        }
    }

    public void setSearchFilter(String filter) {
        this.searchFilter = filter;
        int maxScroll = Math.max(0, getFullContentHeight() - maxVisible);
        if (scrollOffset > maxScroll) {
            scrollOffset = maxScroll;
        }
    }

    public void resortModules() {
        Collections.sort(this.modules, new Comparator<ModuleButton>() {

            @Override
            public int compare(ModuleButton a, ModuleButton b) {
                long ta = a.getMod().getLastUsedTime();
                long tb = b.getMod().getLastUsedTime();
                if (ta != tb)
                    return Long.compare(tb, ta);
                return a.getMod().getName().compareToIgnoreCase(b.getMod().getName());
            }
        });
    }

    private boolean isModuleVisible(ModuleButton btn) {
        if (btn.getMod().isHiddenInGUI())
            return false;
        if (searchFilter.isEmpty())
            return true;
        String name = btn.getMod().getName().toLowerCase();
        if (name.contains(searchFilter))
            return true;
        String desc = btn.getMod().getDescription();
        if (desc != null && desc.toLowerCase().contains(searchFilter))
            return true;
        return false;
    }

    public int getContentHeight() {
        int h = 0;
        for (ModuleButton btn : modules) {
            if (!isModuleVisible(btn))
                continue;
            h += 14;
            if (btn.isExtended()) {
                h += btn.getSettingsHeight();
            }
        }
        return h;
    }

    public int getFullContentHeight() {
        int h = 0;
        for (ModuleButton btn : modules) {
            if (!isModuleVisible(btn))
                continue;
            h += 14;
            if (btn.isExtended()) {
                h += btn.getFullSettingsHeight();
            }
        }
        return h;
    }

    public void handleScroll(int dWheel, int mx, int my) {
        if (mx >= x && mx <= x + width && my >= y + headerHeight && my <= y + headerHeight + maxVisible) {
            scrollOffset -= dWheel * scrollSpeed;
            int maxScroll = Math.max(0, getFullContentHeight() - maxVisible);
            if (scrollOffset < 0)
                scrollOffset = 0;
            if (scrollOffset > maxScroll)
                scrollOffset = maxScroll;
        }
    }

    public void drawScreen(int mouseX, int mouseY) {
        float target = extended ? 1.0f : 0.0f;
        expandProgress = AnimationUtil.lerp(expandProgress, target, 0.18f);
        if (Math.abs(expandProgress - target) < 0.01f)
            expandProgress = target;
        glowPhase += 0.04f;
        if (glowPhase > 1.0f)
            glowPhase -= 1.0f;
        smoothScrollOffset = AnimationUtil.lerp((float) smoothScrollOffset, (float) scrollOffset, 0.25f);
        boolean hasVisibleModules = false;
        for (ModuleButton btn : modules) {
            if (isModuleVisible(btn)) {
                hasVisibleModules = true;
                break;
            }
        }
        int animMaxVisible = (int) (maxVisible * expandProgress);
        int totalH = headerHeight + animMaxVisible;
        if (expandProgress > 0.01f) {
            float easeExpand = AnimationUtil.easeOutCubic(Math.min(1.0f, expandProgress));
            int baseShadowA = (int) (SHADOW_ALPHA * Math.min(1.0f, easeExpand * 1.5f));
            int s1 = (int) (baseShadowA * 0.7f) << 24;
            RenderUtils.drawRoundedRect2D(x - 2 + SHADOW_OFFSET, y - 2 + SHADOW_OFFSET, x + width + 2 + SHADOW_OFFSET, y + totalH + 2 + SHADOW_OFFSET, PANEL_RADIUS + 2, s1);
            int s2 = (int) (baseShadowA * 0.4f) << 24;
            RenderUtils.drawRoundedRect2D(x - SHADOW_SPREAD + SHADOW_OFFSET, y - SHADOW_SPREAD + SHADOW_OFFSET, x + width + SHADOW_SPREAD + SHADOW_OFFSET, y + totalH + SHADOW_SPREAD + SHADOW_OFFSET, PANEL_RADIUS + SHADOW_SPREAD, s2);
            int s3 = (int) (baseShadowA * 0.15f) << 24;
            RenderUtils.drawRoundedRect2D(x - SHADOW_SPREAD * 2 + SHADOW_OFFSET, y - SHADOW_SPREAD * 2 + SHADOW_OFFSET, x + width + SHADOW_SPREAD * 2 + SHADOW_OFFSET, y + totalH + SHADOW_SPREAD * 2 + SHADOW_OFFSET, PANEL_RADIUS + SHADOW_SPREAD * 2, s3);
            int bgAlpha = (int) (255 * Math.min(1.0f, easeExpand * 1.5f));
            int bgColor = (bgAlpha << 24) | (ClickGUI.BG_PANEL & 0x00FFFFFF);
            RenderUtils.drawRoundedRect2D(x, y, x + width, y + totalH, PANEL_RADIUS, bgColor);
            int borderAlpha = (int) (120 * Math.min(1.0f, easeExpand * 1.5f));
            int borderColor = (borderAlpha << 24) | (ClickGUI.BORDER_DARK & 0x00FFFFFF);
            RenderUtils.drawRoundedStroke2D(x, y, x + width, y + totalH, PANEL_RADIUS, 1.0f, borderColor);
            boolean isRainbow = client.module.ModuleManager.getModuleByName("ColorUi") != null && ((client.module.impl.fun.ColorUi) client.module.ModuleManager.getModuleByName("ColorUi")).isToggled() && !ColorUi.isCustomMode() && !ColorUi.isPresetMode();
            if (isRainbow) {
                int hdrSegments = width - 2;
                for (int gi = 0; gi < hdrSegments; gi++) {
                    float hueOff = (float) gi / (float) hdrSegments * 0.3f;
                    int rgb = ColorUi.getRainbowColor(hueOff);
                    int segAlpha = (int) (220 * easeExpand);
                    GuiRenderUtil.drawRect(x + 1 + gi, y + 1, x + 2 + gi, y + headerHeight, (segAlpha << 24) | rgb);
                }
            } else {
                int hdrColor = ClickGUI.getAccentDim();
                RenderUtils.drawRoundedRect2D(x + 1, y + 1, x + width - 1, y + headerHeight, PANEL_RADIUS - 1, hdrColor);
            }
            int accentRgb = ClickGUI.getAccent() & 0x00FFFFFF;
            float accentPulse = 0.8f + 0.2f * (float) Math.sin(glowPhase * Math.PI * 2.0);
            if (isRainbow) {
                for (int gi = 0; gi < 3; gi++) {
                    float fade = 1.0f - gi * 0.3f;
                    int barAlpha = (int) ((200 * accentPulse * fade) * easeExpand + 30);
                    for (int px = PANEL_RADIUS; px < width - PANEL_RADIUS; px++) {
                        float hueOff = (float) px / (float) width * 0.3f;
                        int pxRgb = ColorUi.getRainbowColor(hueOff);
                        GuiRenderUtil.drawRect(x + px, y + headerHeight - 3 + gi, x + px + 1, y + headerHeight - 2 + gi, (barAlpha << 24) | pxRgb);
                    }
                }
            } else {
                for (int gi = 0; gi < 3; gi++) {
                    float fade = 1.0f - gi * 0.3f;
                    int barAlpha = (int) ((200 * accentPulse * fade) * easeExpand + 30);
                    int barColor = (barAlpha << 24) | accentRgb;
                    GuiRenderUtil.drawRect(x + PANEL_RADIUS, y + headerHeight - 3 + gi, x + width - PANEL_RADIUS, y + headerHeight - 2 + gi, barColor);
                }
            }
            String catName = category.name();
            int catW = ClientFontRenderer.getStringWidth(catName);
            int catX = x + (width - catW) / 2;
            ClientFontRenderer.drawStringWithShadow(catName, catX, y + (headerHeight - 8) / 2, ClickGUI.TEXT_NORMAL);
        }
        int bodyTop = y + headerHeight;
        int bodyBottom = bodyTop + animMaxVisible;
        if (extended && hasVisibleModules && animMaxVisible > 2) {
            StencilClipUtil.pushClip(x + 1, bodyTop, x + width - 1, bodyBottom);
            int moduleY = bodyTop - (int) smoothScrollOffset;
            boolean sidebarMode = ClickGUI.getGuiLayout() == 1;
            for (ModuleButton button : modules) {
                if (!isModuleVisible(button))
                    continue;
                int btnHeight = 14;
                int totalHeight = btnHeight;
                if (button.isExtended()) {
                    totalHeight += button.getSettingsHeight();
                }
                int totalBottom = moduleY + totalHeight;
                if (totalBottom > bodyTop && moduleY < bodyBottom) {
                    button.drawScreen(mouseX, mouseY, x, moduleY, width, bodyTop, bodyBottom);
                }
                moduleY += btnHeight;
                if (button.isExtended()) {
                    moduleY += button.getSettingsHeight();
                }
                if (sidebarMode && moduleY < bodyBottom) {
                    int sepY = moduleY - 1;
                    if (sepY >= bodyTop) {
                        GuiRenderUtil.drawRect(x + 2, sepY, x + width - 2, sepY + 1, ClickGUI.BORDER_DARK);
                    }
                }
            }
            StencilClipUtil.popClip();
            int contentHeight = getFullContentHeight();
            if (contentHeight > maxVisible && maxVisible > 0) {
                int maxScroll = contentHeight - maxVisible;
                int scrollBarHeight = Math.max(14, (int) (maxVisible * maxVisible / contentHeight));
                int scrollBarY = bodyTop + (int) ((maxVisible - scrollBarHeight) * (smoothScrollOffset / maxScroll));
                int scrollAlpha = (int) (100 * expandProgress);
                int scrollColor = (scrollAlpha << 24) | 0xAAAAAA;
                RenderUtils.drawRoundedRect2D(x + width - 4, scrollBarY, x + width - 1, scrollBarY + scrollBarHeight, 2, scrollColor);
            }
        }
    }

    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + headerHeight) {
            if (mouseButton == 1) {
                extended = !extended;
                scrollOffset = 0;
                smoothScrollOffset = 0;
                saveExtendedState();
            }
            return;
        }
        if (extended) {
            int bodyTop = y + headerHeight;
            int bodyBottom = bodyTop + maxVisible;
            int moduleY = bodyTop - (int) scrollOffset;
            for (ModuleButton button : modules) {
                if (!isModuleVisible(button))
                    continue;
                int btnHeight = 14;
                int totalHeight = btnHeight;
                if (button.isExtended()) {
                    totalHeight += button.getSettingsHeight();
                }
                int totalBottom = moduleY + totalHeight;
                if (totalBottom > bodyTop && moduleY < bodyBottom) {
                    button.mouseClicked(mouseX, mouseY, mouseButton, x, moduleY, width, bodyTop, bodyBottom);
                }
                moduleY += btnHeight;
                if (button.isExtended()) {
                    moduleY += button.getFullSettingsHeight();
                }
            }
            resortModules();
        }
    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
        for (ModuleButton btn : modules) {
            btn.mouseReleased(mouseX, mouseY, state);
        }
    }

    public boolean handleKeyTyped(char typedChar, int keyCode) {
        for (ModuleButton btn : modules) {
            if (btn.handleKeyTyped(typedChar, keyCode)) {
                return true;
            }
        }
        return false;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int w) {
        this.width = w;
    }

    public int getHeaderHeight() {
        return headerHeight;
    }

    public Category getCategory() {
        return category;
    }

    public boolean isExtended() {
        return extended;
    }

    public void setExtended(boolean ext) {
        if (extended != ext) {
            extended = ext;
            if (!ext) {
                scrollOffset = 0;
                smoothScrollOffset = 0;
            }
            saveExtendedState();
        }
    }
}
