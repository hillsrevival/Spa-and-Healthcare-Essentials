package client.gui.clickgui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import client.Client;
import client.module.Module;
import client.module.BlockListSetting;
import client.module.BooleanSetting;
import client.module.ModeSetting;
import client.module.NumberSetting;
import client.module.ColorSetting;
import client.module.Setting;
import client.module.StringSetting;
import client.gui.clickgui.ColorComponent;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;
import net.lax1dude.eaglercraft.Keyboard;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;

public class ModuleButton {

    private Module mod;

    private Minecraft mc = Minecraft.getMinecraft();

    private boolean extended;

    private List<SettingComponent> settings;

    private Map<SettingComponent, Setting<?>> compSettings = new HashMap<>();

    private boolean hasHudElement;

    private static final int BTN_HEIGHT = 14;

    private static final int BTN_RADIUS = 3;

    private boolean listeningForKey = false;

    private ColorComponent moduleColorComp = null;

    private float expandProgress = 0.0f;

    private float hoverProgress = 0.0f;

    private float toggleFlashProgress = 0.0f;

    private float accentBarWidth = 0.0f;

    private float rippleX = 0.0f, rippleY = 0.0f;

    private float rippleProgress = 0.0f;

    public static String tooltipText = null;

    public static int tooltipX = 0;

    public static int tooltipY = 0;

    public static int tooltipMouseX = 0;

    public static int tooltipMouseY = 0;

    public ModuleButton(Module mod) {
        this.mod = mod;
        this.settings = new ArrayList<>();
        HudElement he = mod.getHudElement();
        for (Setting<?> setting : mod.getSettings()) {
            if (he != null && he.isHiddenSetting(setting))
                continue;
            if (setting == mod.getModuleColor())
                continue;
            SettingComponent comp = null;
            if (setting instanceof BooleanSetting) {
                comp = new BooleanComponent((BooleanSetting) setting);
            } else if (setting instanceof NumberSetting) {
                comp = new SliderComponent((NumberSetting) setting);
            } else if (setting instanceof ModeSetting) {
                comp = new ModeComponent((ModeSetting) setting);
            } else if (setting instanceof ColorSetting) {
                comp = new ColorComponent((ColorSetting) setting);
            } else if (setting instanceof StringSetting) {
                comp = new StringComponent((StringSetting) setting);
            } else if (setting instanceof BlockListSetting) {
                comp = new BlockListComponent((BlockListSetting) setting);
            }
            if (comp != null) {
                settings.add(comp);
                compSettings.put(comp, setting);
            }
        }
        boolean hasOtherColor = false;
        for (Setting<?> setting : mod.getSettings()) {
            if (setting instanceof ColorSetting && setting != mod.getModuleColor()) {
                hasOtherColor = true;
                break;
            }
        }
        if (!hasOtherColor) {
            moduleColorComp = new ColorComponent(mod.getModuleColor());
        }
        this.hasHudElement = (he != null);
        this.accentBarWidth = mod.isToggled() ? 1.0f : 0.0f;
    }

    public void tick(boolean hovering) {
        float target = extended ? 1.0f : 0.0f;
        expandProgress = AnimationUtil.lerp(expandProgress, target, 0.15f);
        if (Math.abs(expandProgress - target) < 0.01f)
            expandProgress = target;
        float hoverTarget = hovering ? 1.0f : 0.0f;
        hoverProgress = AnimationUtil.lerp(hoverProgress, hoverTarget, 0.2f);
        toggleFlashProgress = AnimationUtil.lerp(toggleFlashProgress, 0.0f, 0.15f);
        if (toggleFlashProgress < 0.01f)
            toggleFlashProgress = 0.0f;
        float barTarget = mod.isToggled() ? 1.0f : 0.0f;
        accentBarWidth = AnimationUtil.lerp(accentBarWidth, barTarget, 0.12f);
        rippleProgress = AnimationUtil.lerp(rippleProgress, 0.0f, 0.08f);
        if (rippleProgress < 0.01f)
            rippleProgress = 0.0f;
    }

    public int getSettingsHeight() {
        int rows = countVisibleSettings() + 1;
        if (moduleColorComp != null)
            rows++;
        if (hasHudElement)
            rows++;
        return (int) (rows * 10 * expandProgress);
    }

    public int getFullSettingsHeight() {
        int rows = countVisibleSettings() + 1;
        if (moduleColorComp != null)
            rows++;
        if (hasHudElement)
            rows++;
        return rows * 10;
    }

    private int countVisibleSettings() {
        int rows = 0;
        for (SettingComponent comp : settings) {
            if (isCompVisible(comp))
                rows++;
        }
        return rows;
    }

    private boolean isCompVisible(SettingComponent comp) {
        Setting<?> s = compSettings.get(comp);
        return s == null || s.isVisible();
    }

    public boolean isExtended() {
        return extended;
    }

    public Module getMod() {
        return mod;
    }

    public boolean isListeningForKey() {
        return listeningForKey;
    }

    public void drawScreen(int mouseX, int mouseY, int panelX, int buttonY, int panelWidth, int visibleTop, int visibleBottom) {
        boolean hovering = mouseX >= panelX && mouseX <= panelX + panelWidth && mouseY >= buttonY && mouseY <= buttonY + BTN_HEIGHT;
        tick(hovering);
        SettingComponent.currentAccent = ClickGUI.getAccent();
        SettingComponent.currentAccentBright = ClickGUI.getAccentBright();
        SettingComponent.currentAccentDim = ClickGUI.getAccentDim();
        int bgColor;
        if (mod.isToggled()) {
            int accentRgb = ClickGUI.getAccent() & 0x00FFFFFF;
            int tintAlpha = (int) (46 * (1.0f + hoverProgress * 0.4f));
            int accentTint = (tintAlpha << 24) | accentRgb;
            bgColor = AnimationUtil.lerpColor(ClickGUI.BG_PANEL, accentTint, 0.65f);
        } else {
            int hoverColor = ClickGUI.BG_HOVER;
            int baseColor = ClickGUI.BG_PANEL;
            bgColor = AnimationUtil.lerpColor(baseColor, hoverColor, hoverProgress);
        }
        RenderUtils.drawRoundedRect2D(panelX + 1, buttonY, panelX + panelWidth - 1, buttonY + BTN_HEIGHT, BTN_RADIUS, bgColor);
        if (accentBarWidth > 0.01f) {
            int barH = (int) ((BTN_HEIGHT - 2) * accentBarWidth);
            if (barH >= 2) {
                int barY = buttonY + 1 + (BTN_HEIGHT - 2 - barH) / 2;
                RenderUtils.drawRoundedRect2D(panelX + 1, barY, panelX + 4, barY + barH, 1, ClickGUI.getAccent());
                RenderUtils.drawRoundedRect2D(panelX + 4, barY, panelX + 6, barY + barH, 1, ClickGUI.getAccentAlpha(50));
            }
        }
        int nameX = panelX + 12;
        if (mod.getKey() > 0 && !extended) {
            String keyName = Keyboard.getKeyName(mod.getKey());
            if (keyName != null && keyName.length() <= 4) {
                int keyW = ClientFontRenderer.getStringWidth(keyName) + 4;
                int keyX = nameX;
                int keyY = buttonY + 2;
                int keyBgAlpha = (int) (80 + 60 * hoverProgress);
                int keyBg = (keyBgAlpha << 24) | (ClickGUI.getAccent() & 0x00FFFFFF);
                RenderUtils.drawRoundedRect2D(keyX, keyY, keyX + keyW, keyY + 9, 2, keyBg);
                ClientFontRenderer.drawString(keyName, keyX + 2, keyY + 1, 0xFFFFFFFF);
                nameX = keyX + keyW + 3;
            }
        }
        int nameColor;
        if (mod.isToggled()) {
            nameColor = AnimationUtil.lerpColor(ClickGUI.getAccent(), ClickGUI.getAccentBright(), hoverProgress);
        } else {
            nameColor = AnimationUtil.lerpColor(ClickGUI.TEXT_MUTED, ClickGUI.getTextAccent(), hoverProgress * 0.5f);
        }
        int availableWidth = panelX + panelWidth - 4 - nameX;
        String displayName = mod.getName();
        int nameWidth = ClientFontRenderer.getStringWidth(displayName);
        if (nameWidth > availableWidth && availableWidth > 10) {
            while (displayName.length() > 1 && ClientFontRenderer.getStringWidth(displayName + "..") > availableWidth) {
                displayName = displayName.substring(0, displayName.length() - 1);
            }
            displayName = displayName + "..";
        }
        ClientFontRenderer.drawStringWithShadow(displayName, nameX, buttonY + 2, nameColor);
        if (hovering) {
            String desc = mod.getDescription();
            if (desc != null && !desc.isEmpty()) {
                if (desc.length() > 28)
                    desc = desc.substring(0, 26) + "..";
                int descW = ClientFontRenderer.getStringWidth(desc);
                int descX = panelX + panelWidth - descW - 14;
                int nameW = ClientFontRenderer.getStringWidth(mod.getName());
                if (descX > panelX + 5 + nameW + 4) {
                    ClientFontRenderer.drawString(desc, descX, buttonY + 3, 0x809BE7FF);
                }
            }
        }
        if (!settings.isEmpty() || moduleColorComp != null) {
            int ind = AnimationUtil.lerpColor(ClickGUI.TEXT_DIM, ClickGUI.getAccentBright(), Math.max(hoverProgress, expandProgress));
            ClientFontRenderer.drawString(extended ? "-" : "+", panelX + panelWidth - 9, buttonY + 3, ind);
        }
        if (hovering) {
            String desc = mod.getDescription();
            if (desc != null && !desc.isEmpty()) {
                tooltipText = desc;
                tooltipMouseX = mouseX;
                tooltipMouseY = buttonY;
            }
        }
        try {
        if (expandProgress > 0.01f) {
            int fullHeight = getFullSettingsHeight();
            int animHeight = (int) (fullHeight * expandProgress);
            int settingY = buttonY + BTN_HEIGHT;
            int pixelsDrawn = 0;
            for (SettingComponent comp : settings) {
                if (!isCompVisible(comp))
                    continue;
                int settingBottom = settingY + 10;
                if (settingBottom > visibleTop && settingY < visibleBottom) {
                    if (pixelsDrawn + 10 <= animHeight) {
                        comp.drawScreen(mouseX, mouseY, panelX + 2, settingY, panelWidth - 4);
                    }
                }
                settingY += 10;
                pixelsDrawn += 10;
            }
            int keybindY = settingY;
            if (pixelsDrawn + 10 <= animHeight) {
                if (keybindY + 10 > visibleTop && keybindY < visibleBottom) {
                    int kbBg = listeningForKey ? 0xFF1B4272 : ClickGUI.BG_SETTING_DEEP;
                    RenderUtils.drawRoundedRect2D(panelX + 2, keybindY, panelX + panelWidth - 2, keybindY + 10, 2, kbBg);
                    RenderUtils.drawRoundedRect2D(panelX + 2, keybindY, panelX + panelWidth - 2, keybindY + 1, 0, ClickGUI.getAccentDim());
                    String label;
                    int labelColor;
                    if (listeningForKey) {
                        label = "Press a key... [ESC to clear]";
                        labelColor = 0xFFCFEFFF;
                    } else {
                        label = "Keybind: " + (mod.getKey() >= 0 ? Keyboard.getKeyName(mod.getKey()) : "[None]");
                        labelColor = ClickGUI.TEXT_NORMAL;
                    }
                    ClientFontRenderer.drawStringWithShadow(label, panelX + 5, keybindY + 2, labelColor);
                }
                pixelsDrawn += 10;
            }
            if (moduleColorComp != null && pixelsDrawn + 10 <= animHeight) {
                int colorY = keybindY + 10;
                if (colorY + 10 > visibleTop && colorY < visibleBottom) {
                    moduleColorComp.drawScreen(mouseX, mouseY, panelX + 2, colorY, panelWidth - 4);
                }
                pixelsDrawn += 10;
            }
            if (hasHudElement && pixelsDrawn + 10 <= animHeight) {
                int hudBtnY = keybindY + 10 + (moduleColorComp != null ? 10 : 0);
                if (hudBtnY + 10 > visibleTop && hudBtnY < visibleBottom) {
                    boolean hudHover = mouseX >= panelX + 2 && mouseX <= panelX + panelWidth - 2 && mouseY >= hudBtnY && mouseY <= hudBtnY + 10;
                    int hudBg = AnimationUtil.lerpColor(ClickGUI.BG_SETTING_DEEP, 0xFF1A3A5A, hudHover ? 1.0f : 0.0f);
                    RenderUtils.drawRoundedRect2D(panelX + 2, hudBtnY, panelX + panelWidth - 2, hudBtnY + 10, 2, hudBg);
                    RenderUtils.drawRoundedRect2D(panelX + 2, hudBtnY, panelX + panelWidth - 2, hudBtnY + 1, 0, ClickGUI.getAccentDim());
                    int hudTextColor = AnimationUtil.lerpColor(ClickGUI.TEXT_NORMAL, ClickGUI.getAccentBright(), hudHover ? 1.0f : 0.0f);
                    ClientFontRenderer.drawStringWithShadow("Edit HUD Position", panelX + 5, hudBtnY + 2, hudTextColor);
                }
            }
        }
        } catch (Throwable t) {
            System.err.println("[ModuleButton] settings view failed for " + mod.getName() + ": " + t);
            extended = false;
            expandProgress = 0.0f;
        }
    }

    public void mouseClicked(int mouseX, int mouseY, int mouseButton, int panelX, int buttonY, int panelWidth, int visibleTop, int visibleBottom) {
        if (mouseX >= panelX && mouseX <= panelX + panelWidth && mouseY >= buttonY && mouseY <= buttonY + BTN_HEIGHT) {
            if (mouseButton == 0) {
                mod.toggle();
                toggleFlashProgress = 1.0f;
                rippleX = mouseX - panelX;
                rippleY = mouseY - buttonY;
                rippleProgress = 1.0f;
                Client.INSTANCE.getConfigManager().getSettingConfig().save();
            } else if (mouseButton == 1) {
                extended = !extended;
                listeningForKey = false;
            } else if (mouseButton == 2) {
                ContextMenu.show(mod, mouseX, mouseY);
            }
            return;
        }
        if (extended && expandProgress > 0.5f) {
            try {
                handleSettingClicks(mouseX, mouseY, mouseButton, panelX, buttonY, panelWidth, visibleTop, visibleBottom);
            } catch (Throwable t) {
                System.err.println("[ModuleButton] settings click failed for " + mod.getName() + ": " + t);
                extended = false;
                expandProgress = 0.0f;
            }
            return;
        }
    }

    private void handleSettingClicks(int mouseX, int mouseY, int mouseButton, int panelX, int buttonY, int panelWidth, int visibleTop, int visibleBottom) {
        {
            int settingY = buttonY + BTN_HEIGHT;
            for (SettingComponent comp : settings) {
                if (!isCompVisible(comp))
                    continue;
                int settingBottom = settingY + 10;
                if (settingBottom > visibleTop && settingY < visibleBottom) {
                    comp.mouseClicked(mouseX, mouseY, mouseButton, panelX + 2, settingY, panelWidth - 4);
                }
                settingY += 10;
            }
            int keybindY = settingY;
            if (mouseX >= panelX + 2 && mouseX <= panelX + panelWidth - 2 && mouseY >= keybindY && mouseY <= keybindY + 10) {
                if (mouseButton == 0) {
                    listeningForKey = true;
                }
            }
            int colorCompY = keybindY + 10;
            if (moduleColorComp != null && mouseX >= panelX + 2 && mouseX <= panelX + panelWidth - 2 && mouseY >= colorCompY && mouseY <= colorCompY + 10) {
                moduleColorComp.mouseClicked(mouseX, mouseY, mouseButton, panelX + 2, colorCompY, panelWidth - 4);
            }
            if (hasHudElement) {
                int hudBtnY = keybindY + 10 + (moduleColorComp != null ? 10 : 0);
                if (mouseX >= panelX + 2 && mouseX <= panelX + panelWidth - 2 && mouseY >= hudBtnY && mouseY <= hudBtnY + 10 && mouseButton == 0) {
                    HudElement.setHudEditorOpen(true);
                    mc.displayGuiScreen(new client.gui.HudEditorScreen());
                }
            }
        }
    }

    public boolean handleKeyTyped(char typedChar, int keyCode) {
        for (SettingComponent comp : settings) {
            if (!isCompVisible(comp))
                continue;
            if (comp instanceof StringComponent && ((StringComponent) comp).isEditing()) {
                return ((StringComponent) comp).handleKeyTyped(typedChar, keyCode);
            }
        }
        if (!listeningForKey)
            return false;
        if (keyCode == 1) {
            mod.setKey(-1);
            Client.INSTANCE.getConfigManager().getModuleConfig().save();
            listeningForKey = false;
            return true;
        }
        if (keyCode == 54) {
            return true;
        }
        if (keyCode > 0) {
            mod.setKey(keyCode);
            Client.INSTANCE.getConfigManager().getModuleConfig().save();
        }
        listeningForKey = false;
        return true;
    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
        for (SettingComponent comp : settings) {
            if (!isCompVisible(comp))
                continue;
            comp.mouseReleased(mouseX, mouseY, state);
        }
        if (moduleColorComp != null) {
            moduleColorComp.mouseReleased(mouseX, mouseY, state);
        }
    }

    public static void drawDeferredTooltip(Minecraft mc) {
        if (tooltipText == null || tooltipText.isEmpty())
            return;
        String[] lines = tooltipText.split("\n");
        int padding = 4;
        int boxWidth = 0;
        for (String line : lines) {
            int w = ClientFontRenderer.getStringWidth(line);
            if (w > boxWidth)
                boxWidth = w;
        }
        boxWidth += padding * 2;
        int lineHeight = 10;
        int boxHeight = lines.length * lineHeight + padding * 2;
        int screenW = ClientGuiScale.getGuiWidth(mc);
        int screenH = ClientGuiScale.getGuiHeight(mc);
        int boxX = tooltipMouseX + 8;
        int boxY = tooltipMouseY - boxHeight - 2;
        if (boxX + boxWidth > screenW) {
            boxX = tooltipMouseX - boxWidth - 8;
        }
        if (boxX < 0)
            boxX = 0;
        if (boxY + boxHeight > screenH) {
            boxY = Math.max(0, screenH - boxHeight - 2);
        }
        if (boxY < 0) {
            boxY = tooltipMouseY + BTN_HEIGHT + 2;
        }
        RenderUtils.drawRoundedRect2D(boxX, boxY, boxX + boxWidth, boxY + boxHeight, 4, ClickGUI.TOOLTIP_BG);
        RenderUtils.drawRoundedStroke2D(boxX, boxY, boxX + boxWidth, boxY + boxHeight, 4, 1.0f, ClickGUI.getAccent());
        for (int i = 0; i < lines.length; i++) {
            ClientFontRenderer.drawStringWithShadow(lines[i], boxX + padding, boxY + padding + i * lineHeight, ClickGUI.TEXT_NORMAL);
        }
        tooltipText = null;
    }
}
