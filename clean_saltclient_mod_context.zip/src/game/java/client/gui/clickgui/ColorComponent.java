package client.gui.clickgui;

import client.module.ColorSetting;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;
import client.gui.clickgui.AnimationUtil;
import net.minecraft.client.Minecraft;

public class ColorComponent extends SettingComponent {

    private ColorSetting setting;

    private Minecraft mc = Minecraft.getMinecraft();

    private static final int H = 10;

    private boolean dragging = false;

    public ColorComponent(ColorSetting setting) {
        this.setting = setting;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, int x, int y, int width) {
        if (dragging) {
            updateHue(mouseX, x, width);
        }
        boolean hovering = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + H;
        int bgBase = AnimationUtil.lerpColor(ClickGUI.BG_SETTING, 0xFF101018, hovering ? 0.3f : 0.0f);
        RenderUtils.drawRoundedRect2D(x, y, x + width, y + H, 2, bgBase);
        int stripX = x + width - 52;
        int stripW = 50;
        int stripH = 8;
        int stripY = y + (H - stripH) / 2;
        RenderUtils.drawRoundedRect2D(stripX - 1, stripY - 1, stripX + stripW + 1, stripY + stripH + 1, 2, 0xFF091526);
        int segments = stripW;
        for (int i = 0; i < segments; i++) {
            float hue = (float) i / (float) segments;
            float[] rgb = ColorSetting.hsbToRgb(hue, 1.0f, 1.0f);
            int color = 0xFF000000 | ((int) (rgb[0] * 255) << 16) | ((int) (rgb[1] * 255) << 8) | (int) (rgb[2] * 255);
            GuiRenderUtil.drawRect(stripX + i, stripY, stripX + i + 1, stripY + stripH, color);
        }
        double hueVal = setting.getHue();
        int selX = stripX + (int) ((hueVal / 360.0) * stripW);
        int selColor = setting.getARGB();
        int glowRgb = selColor & 0x00FFFFFF;
        RenderUtils.drawRoundedRect2D(selX - 2, stripY - 2, selX + 3, stripY + stripH + 2, 2, (0x40 << 24) | glowRgb);
        GuiRenderUtil.drawRect(selX - 1, stripY - 1, selX + 2, stripY + stripH + 1, 0xFFFFFFFF);
        GuiRenderUtil.drawRect(selX, stripY, selX + 1, stripY + stripH, selColor);
        int hueInt = (int) hueVal;
        String hueStr = String.valueOf(hueInt) + "°";
        int hueStrW = ClientFontRenderer.getStringWidth(hueStr);
        ClientFontRenderer.drawStringWithShadow(hueStr, stripX - hueStrW - 4, y + 1, selColor);
        setHoverTooltip(setting, mouseX, mouseY, x, y, width, H);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton, int x, int y, int width) {
        if (mouseButton == 1) {
            if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + H) {
                resetToDefault(setting);
            }
            return;
        }
        int stripX = x + width - 52;
        int stripW = 50;
        if (mouseX >= stripX && mouseX <= stripX + stripW && mouseY >= y && mouseY <= y + H) {
            dragging = true;
            updateHue(mouseX, x, width);
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        if (dragging) {
            dragging = false;
        }
    }

    private void updateHue(int mouseX, int x, int width) {
        int stripX = x + width - 52;
        int stripW = 50;
        double ratio = (mouseX - stripX) / (double) stripW;
        ratio = Math.max(0, Math.min(1, ratio));
        double hue = ratio * 360.0;
        setting.setValue(hue);
    }
}
