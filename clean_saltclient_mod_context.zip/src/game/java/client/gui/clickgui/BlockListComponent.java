package client.gui.clickgui;

import client.module.BlockListSetting;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;
import net.minecraft.client.Minecraft;

public class BlockListComponent extends SettingComponent {

    private final BlockListSetting setting;

    private final Minecraft mc = Minecraft.getMinecraft();

    public BlockListComponent(BlockListSetting setting) {
        this.setting = setting;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, int x, int y, int w) {
        int bgColor = ClickGUI.BG_SETTING_DEEP;
        RenderUtils.drawRoundedRect2D(x, y, x + w, y + 10, 2, bgColor);
        RenderUtils.drawRoundedRect2D(x, y, x + w, y + 1, 0, ClickGUI.getAccentDim());
        String[] selected = setting.getValue();
        int count = selected != null ? selected.length : 0;
        String display = setting.getName() + ": " + count + " blocks";
        ClientFontRenderer.drawStringWithShadow(display, x + 3, y + 2, ClickGUI.TEXT_NORMAL);
        String arrow = ">";
        ClientFontRenderer.drawRightAlignedString(arrow, x + w - 3, y + 2, ClickGUI.getAccent());
        setHoverTooltip(setting, mouseX, mouseY, x, y, w, 10);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton, int x, int y, int w) {
        if (mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + 10) {
            if (mouseButton == 0) {
                mc.displayGuiScreen(new BlockListScreen(setting));
            } else if (mouseButton == 1) {
                resetToDefault(setting);
            } else if (mouseButton == 2) {
                setting.clearAll();
            }
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
    }
}
