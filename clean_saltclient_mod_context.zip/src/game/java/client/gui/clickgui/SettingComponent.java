package client.gui.clickgui;

import client.module.Setting;

public abstract class SettingComponent {

    public static int currentAccent = 0xFFCFEFFF;

    public static int currentAccentBright = 0xFFFFFFFF;

    public static int currentAccentDim = 0xFF2A6C99;

    public static int currentAccentAlpha(int alpha) {
        return (alpha << 24) | (currentAccent & 0x00FFFFFF);
    }

    public abstract void drawScreen(int mouseX, int mouseY, int x, int y, int width);

    public abstract void mouseClicked(int mouseX, int mouseY, int mouseButton, int x, int y, int width);

    public void mouseReleased(int mouseX, int mouseY, int state) {
    }

    protected void resetToDefault(Setting<?> setting) {
        if (setting == null)
            return;
        resetToDefaultGeneric(setting);
        client.utils.misc.NotificationSystem.info(setting.getName() + " reset to default");
    }

    private <T> void resetToDefaultGeneric(Setting<T> setting) {
        setting.setValue(setting.getDefault());
    }

    protected void setHoverTooltip(Setting<?> setting, int mouseX, int mouseY, int x, int y, int width, int height) {
        if (setting == null || !setting.hasDescription())
            return;
        if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height) {
            ModuleButton.tooltipText = setting.getDescription();
            ModuleButton.tooltipMouseX = mouseX;
            ModuleButton.tooltipMouseY = y;
        }
    }
}
