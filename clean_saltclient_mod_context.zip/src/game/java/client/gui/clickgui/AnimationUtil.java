package client.gui.clickgui;

public class AnimationUtil {

    public static float lerp(float current, float target, float speed) {
        float diff = target - current;
        if (Math.abs(diff) < 0.5f)
            return target;
        return current + diff * speed;
    }

    public static int lerpColor(int from, int to, float progress) {
        float p = Math.min(1.0f, Math.max(0.0f, progress));
        int aFrom = (from >> 24) & 0xFF;
        int rFrom = (from >> 16) & 0xFF;
        int gFrom = (from >> 8) & 0xFF;
        int bFrom = from & 0xFF;
        int aTo = (to >> 24) & 0xFF;
        int rTo = (to >> 16) & 0xFF;
        int gTo = (to >> 8) & 0xFF;
        int bTo = to & 0xFF;
        int a = aFrom + (int) ((aTo - aFrom) * p);
        int r = rFrom + (int) ((rTo - rFrom) * p);
        int g = gFrom + (int) ((gTo - gFrom) * p);
        int b = bFrom + (int) ((bTo - bFrom) * p);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static float easeOutCubic(float t) {
        float f = Math.min(1.0f, Math.max(0.0f, t));
        return 1.0f - (1.0f - f) * (1.0f - f) * (1.0f - f);
    }

    public static float easeOutBack(float t) {
        float f = Math.min(1.0f, Math.max(0.0f, t));
        float c1 = 1.70158f;
        float c3 = c1 + 1.0f;
        return 1.0f + c3 * (f - 1.0f) * (f - 1.0f) * (f - 1.0f) + c1 * (f - 1.0f) * (f - 1.0f);
    }

    public static float easeInOutSine(float t) {
        float f = Math.min(1.0f, Math.max(0.0f, t));
        return -(float) (Math.cos(Math.PI * f) - 1.0f) / 2.0f;
    }

    public static float easeOutSpring(float t, float bounce) {
        float f = Math.max(0.0f, Math.min(1.0f, t));
        if (bounce <= 0.0f)
            return f;
        float decay = (float) Math.pow(1.0f - f, 3.0);
        float osc = (float) Math.sin(f * Math.PI * (1.0f + bounce * 2.0f));
        return f + decay * osc * bounce;
    }

    public static float easeOutElastic(float t) {
        float f = Math.max(0.0f, Math.min(1.0f, t));
        if (f == 0.0f || f == 1.0f)
            return f;
        float p = 0.3f;
        return (float) (Math.pow(2.0, -10.0 * f) * Math.sin((f - p / 4.0) * (2.0 * Math.PI) / p) + 1.0);
    }

    public static float pulse(float speed) {
        return (float) (Math.sin(System.currentTimeMillis() / 1000.0 * speed * Math.PI * 2.0) * 0.5 + 0.5);
    }

    public static float smoothStep(float edge0, float edge1, float x) {
        float t = Math.max(0.0f, Math.min(1.0f, (x - edge0) / (edge1 - edge0)));
        return t * t * (3.0f - 2.0f * t);
    }

    public static float easeInOutQuad(float t) {
        float f = Math.max(0.0f, Math.min(1.0f, t));
        return f < 0.5f ? 2.0f * f * f : 1.0f - (float) Math.pow(-2.0f * f + 2.0f, 2.0f) / 2.0f;
    }
}
