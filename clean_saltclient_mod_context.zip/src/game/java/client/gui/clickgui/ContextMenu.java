package client.gui.clickgui;

import net.minecraft.client.Minecraft;
import client.Client;
import client.utils.render.RenderUtils;
import client.gui.clickgui.AnimationUtil;
import client.utils.render.ClientFontRenderer;
import client.utils.misc.NotificationSystem;
import client.module.Module;
import client.module.ModuleManager;

public class ContextMenu {

    private static final int MENU_WIDTH = 140;

    private static final int ITEM_HEIGHT = 14;

    private static final int PADDING = 4;

    private static Module targetModule = null;

    private static int menuX = 0;

    private static int menuY = 0;

    private static boolean visible = false;

    private static float openProgress = 0.0f;

    private static final String[] MENU_ITEMS = { "Toggle", "Bind Key...", "Reset Settings", "Copy Name", "Add to QuickBar" };

    private ContextMenu() {
    }

    public static void show(Module mod, int x, int y) {
        targetModule = mod;
        ScaledResolutionWrapper sr = new ScaledResolutionWrapper();
        if (x + MENU_WIDTH > sr.width)
            x = sr.width - MENU_WIDTH - 4;
        if (y + MENU_ITEMS.length * ITEM_HEIGHT + PADDING * 2 > sr.height) {
            y = sr.height - (MENU_ITEMS.length * ITEM_HEIGHT + PADDING * 2) - 4;
        }
        menuX = x;
        menuY = y;
        visible = true;
        openProgress = 0.0f;
    }

    public static void hide() {
        visible = false;
        targetModule = null;
    }

    public static boolean isVisible() {
        return visible && targetModule != null;
    }

    public static void render(Minecraft mc) {
        if (!isVisible())
            return;
        openProgress = AnimationUtil.lerp(openProgress, 1.0f, 0.2f);
        float ease = AnimationUtil.easeOutCubic(openProgress);
        int menuHeight = MENU_ITEMS.length * ITEM_HEIGHT + PADDING * 2;
        int animHeight = (int) (menuHeight * ease);
        int shadow1 = 0x30000000;
        RenderUtils.drawRoundedRect2D(menuX - 1, menuY - 1, menuX + MENU_WIDTH + 1, menuY + animHeight + 1, 5, shadow1);
        int shadow2 = 0x18000000;
        RenderUtils.drawRoundedRect2D(menuX - 4, menuY - 4, menuX + MENU_WIDTH + 4, menuY + animHeight + 4, 6, shadow2);
        int bgAlpha = (int) (224 * ease);
        int bgColor = (bgAlpha << 24) | 0x181820;
        RenderUtils.drawRoundedRect2D(menuX, menuY, menuX + MENU_WIDTH, menuY + animHeight, 4, bgColor);
        RenderUtils.drawRoundedStroke2D(menuX, menuY, menuX + MENU_WIDTH, menuY + animHeight, 4, 1.0f, ClickGUI.getAccent());
        int hdrAlpha = (int) (255 * Math.min(1.0f, ease * 2.0f));
        int hdrColor = (hdrAlpha << 24) | (ClickGUI.getTextAccent() & 0x00FFFFFF);
        ClientFontRenderer.drawStringWithShadow(targetModule.getName(), menuX + PADDING, menuY + PADDING - 1, hdrColor);
        int sepAlpha = (int) (255 * Math.min(1.0f, ease * 2.0f));
        int sepColor = (sepAlpha << 24) | (ClickGUI.getAccentDim() & 0x00FFFFFF);
        RenderUtils.drawRect2D(menuX + PADDING, menuY + PADDING + 9, menuX + MENU_WIDTH - PADDING, menuY + PADDING + 10, sepColor);
        int itemY = menuY + PADDING + 12;
        for (int i = 0; i < MENU_ITEMS.length; i++) {
            float itemEase = Math.max(0.0f, Math.min(1.0f, ease * (MENU_ITEMS.length + 1) - i));
            int mx = net.lax1dude.eaglercraft.Mouse.getX();
            int my = net.lax1dude.eaglercraft.Mouse.getY();
            ScaledResolutionWrapper sr = new ScaledResolutionWrapper();
            int mouseX = mx * sr.width / mc.displayWidth;
            int mouseY = sr.height - my * sr.height / mc.displayHeight - 1;
            boolean hovering = mouseX >= menuX && mouseX <= menuX + MENU_WIDTH && mouseY >= itemY && mouseY <= itemY + ITEM_HEIGHT;
            if (hovering && itemEase > 0.5f) {
                RenderUtils.drawRoundedRect2D(menuX + 2, itemY, menuX + MENU_WIDTH - 2, itemY + ITEM_HEIGHT, 2, ClickGUI.getAccentAlpha(40));
                RenderUtils.drawRoundedRect2D(menuX + 2, itemY, menuX + 4, itemY + ITEM_HEIGHT, 1, ClickGUI.getAccent());
            }
            int itemAlpha = (int) (255 * itemEase);
            int color = hovering ? (itemAlpha << 24) | 0xFFFFFF : (itemAlpha << 24) | 0xCCCCCC;
            ClientFontRenderer.drawStringWithShadow(MENU_ITEMS[i], menuX + PADDING + 2, itemY + 3, color);
            itemY += ITEM_HEIGHT;
        }
    }

    public static boolean handleClick(int mouseX, int mouseY, int mouseButton) {
        if (!isVisible())
            return false;
        if (mouseButton != 0) {
            hide();
            return true;
        }
        int menuHeight = MENU_ITEMS.length * ITEM_HEIGHT + PADDING * 2;
        if (mouseX >= menuX && mouseX <= menuX + MENU_WIDTH && mouseY >= menuY && mouseY <= menuY + menuHeight) {
            int itemY = menuY + PADDING + 12;
            for (int i = 0; i < MENU_ITEMS.length; i++) {
                if (mouseY >= itemY && mouseY <= itemY + ITEM_HEIGHT) {
                    executeItem(i);
                    hide();
                    return true;
                }
                itemY += ITEM_HEIGHT;
            }
            return true;
        }
        hide();
        return true;
    }

    private static void executeItem(int index) {
        if (targetModule == null)
            return;
        switch(index) {
            case 0:
                targetModule.toggle();
                break;
            case 1:
                NotificationSystem.info("Press a key to bind to " + targetModule.getName() + "...");
                NotificationSystem.info("Use .bind " + targetModule.getName() + " <key>");
                break;
            case 2:
                for (client.module.Setting<?> s : targetModule.getSettings()) {
                    if (s.getName().equals("Module Color"))
                        continue;
                    resetSettingToDefault(s);
                }
                Client.INSTANCE.getConfigManager().getSettingConfig().save();
                NotificationSystem.success(targetModule.getName() + " settings reset to default");
                break;
            case 3:
                try {
                    net.lax1dude.eaglercraft.EagRuntime.setClipboard(targetModule.getName());
                    NotificationSystem.success("Copied: " + targetModule.getName());
                } catch (Exception e) {
                    NotificationSystem.error("Failed to copy");
                }
                break;
            case 4:
                for (int i = 0; i < client.module.impl.non_hack.QuickToggleBar.getNumSlots(); i++) {
                    if (client.module.impl.non_hack.QuickToggleBar.getAssignedModule(i) == null) {
                        client.module.impl.non_hack.QuickToggleBar.assignSlot(i, targetModule.getName());
                        NotificationSystem.success("Added " + targetModule.getName() + " to QuickBar slot " + (i + 1));
                        return;
                    }
                }
                NotificationSystem.warning("QuickBar is full (all 5 slots assigned)");
                break;
        }
    }

    private static <T> void resetSettingToDefault(client.module.Setting<T> s) {
        s.setValue(s.getDefault());
    }

    private static class ScaledResolutionWrapper {

        final int width;

        final int height;

        ScaledResolutionWrapper() {
            this.width = ClientGuiScale.getGuiWidth(Minecraft.getMinecraft());
            this.height = ClientGuiScale.getGuiHeight(Minecraft.getMinecraft());
        }
    }
}
