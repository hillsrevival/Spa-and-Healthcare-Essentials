package client.gui.clickgui;

import client.Client;
import client.module.ModeSetting;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;
import net.minecraft.client.Minecraft;

public class ModeComponent extends SettingComponent {

    private ModeSetting setting;

    private Minecraft mc = Minecraft.getMinecraft();

    private static final int H = 10;

    private float hoverLeftProgress = 0.0f;

    private float hoverRightProgress = 0.0f;

    private float modeChangeFlash = 0.0f;

    private float hoverBgProgress = 0.0f;

    public ModeComponent(ModeSetting setting) {
        this.setting = setting;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, int x, int y, int width) {
        boolean hovering = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + H;
        float hoverTarget = hovering ? 1.0f : 0.0f;
        hoverBgProgress = AnimationUtil.lerp(hoverBgProgress, hoverTarget, 0.15f);
        modeChangeFlash = AnimationUtil.lerp(modeChangeFlash, 0.0f, 0.12f);
        int bgBase = AnimationUtil.lerpColor(ClickGUI.BG_SETTING, 0xFF101018, hoverBgProgress * 0.4f);
        RenderUtils.drawRoundedRect2D(x, y, x + width, y + H, 2, bgBase);
        if (modeChangeFlash > 0.01f) {
            int flashA = (int) (35 * modeChangeFlash);
            int flashColor = (flashA << 24) | (currentAccent & 0x00FFFFFF);
            RenderUtils.drawRoundedRect2D(x, y, x + width, y + H, 2, flashColor);
        }
        String modeName = setting.getValue();
        boolean leftHover = mouseX >= x && mouseX < x + 12 && mouseY >= y && mouseY <= y + H;
        float leftTarget = leftHover ? 1.0f : 0.0f;
        hoverLeftProgress = AnimationUtil.lerp(hoverLeftProgress, leftTarget, 0.25f);
        boolean rightHover = mouseX > x + width - 12 && mouseX <= x + width && mouseY >= y && mouseY <= y + H;
        float rightTarget = rightHover ? 1.0f : 0.0f;
        hoverRightProgress = AnimationUtil.lerp(hoverRightProgress, rightTarget, 0.25f);
        if (hoverLeftProgress > 0.01f) {
            int arrBgA = (int) (30 * hoverLeftProgress);
            int arrBg = (arrBgA << 24) | (currentAccent & 0x00FFFFFF);
            RenderUtils.drawRoundedRect2D(x, y, x + 12, y + H, 2, arrBg);
        }
        int leftColor = AnimationUtil.lerpColor(ClickGUI.TEXT_DARK, currentAccent, hoverLeftProgress);
        ClientFontRenderer.drawStringWithShadow("\u25C0", x + 1, y + 1, leftColor);
        if (hoverRightProgress > 0.01f) {
            int arrBgA = (int) (30 * hoverRightProgress);
            int arrBg = (arrBgA << 24) | (currentAccent & 0x00FFFFFF);
            RenderUtils.drawRoundedRect2D(x + width - 12, y, x + width, y + H, 2, arrBg);
        }
        int rightColor = AnimationUtil.lerpColor(ClickGUI.TEXT_DARK, currentAccent, hoverRightProgress);
        ClientFontRenderer.drawStringWithShadow("\u25B6", x + width - 9, y + 1, rightColor);
        int centerStart = x + 14;
        int centerEnd = x + width - 14;
        int centerWidth = centerEnd - centerStart;
        int modeWidth = ClientFontRenderer.getStringWidth(modeName);
        int nameX = centerStart + (centerWidth - modeWidth) / 2;
        int nameColor = AnimationUtil.lerpColor(ClickGUI.TEXT_NORMAL, currentAccentBright, modeChangeFlash * 0.8f);
        ClientFontRenderer.drawStringWithShadow(modeName, nameX, y + 1, nameColor);
        setHoverTooltip(setting, mouseX, mouseY, x, y, width, H);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton, int x, int y, int width) {
        if (mouseButton == 1 && mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + H) {
            resetToDefault(setting);
            return;
        }
        if (mouseY >= y && mouseY <= y + H) {
            String[] modes = setting.getModes();
            if (modes == null || modes.length == 0)
                return;
            int index = -1;
            for (int i = 0; i < modes.length; i++) {
                if (modes[i].equals(setting.getValue())) {
                    index = i;
                    break;
                }
            }
            if (index < 0)
                index = 0;
            if (mouseX >= x && mouseX < x + 10) {
                index--;
                if (index < 0)
                    index = modes.length - 1;
            } else if (mouseX > x + width - 10 && mouseX <= x + width) {
                index++;
                if (index >= modes.length)
                    index = 0;
            } else {
                return;
            }
            setting.setValue(modes[index]);
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }
}
