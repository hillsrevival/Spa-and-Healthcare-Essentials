package client.gui.clickgui;

import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.minecraft.client.Minecraft;

public final class ClientGuiScale {

    private static final int CLIENT_SCALE = 2;

    private ClientGuiScale() {
    }

    public static int getScaleFactor(Minecraft mc) {
        int factor = CLIENT_SCALE;
        while (factor > 1 && (mc.displayWidth / factor < 320 || mc.displayHeight / factor < 240)) {
            factor--;
        }
        return factor;
    }

    public static int getGuiWidth(Minecraft mc) {
        return (int) Math.ceil((double) mc.displayWidth / getScaleFactor(mc));
    }

    public static int getGuiHeight(Minecraft mc) {
        return (int) Math.ceil((double) mc.displayHeight / getScaleFactor(mc));
    }

    public static void applyDims(net.minecraft.client.gui.GuiScreen screen, Minecraft mc) {
        screen.width = getGuiWidth(mc);
        screen.height = getGuiHeight(mc);
    }

    public static void setupOrtho(Minecraft mc) {
        GlStateManager.clear(256);
        GlStateManager.matrixMode(RealOpenGLEnums.GL_PROJECTION);
        GlStateManager.loadIdentity();
        GlStateManager.ortho(0.0D, getGuiWidth(mc), getGuiHeight(mc), 0.0D, 1000.0D, 3000.0D);
        GlStateManager.matrixMode(RealOpenGLEnums.GL_MODELVIEW);
        GlStateManager.loadIdentity();
        GlStateManager.translate(0.0F, 0.0F, -2000.0F);
    }

    public static void restoreVanillaOrtho(Minecraft mc) {
        mc.entityRenderer.setupOverlayRendering();
    }
}
