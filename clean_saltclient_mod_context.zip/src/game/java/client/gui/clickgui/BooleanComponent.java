package client.gui.clickgui;

import client.Client;
import client.module.BooleanSetting;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;
import net.minecraft.client.Minecraft;

public class BooleanComponent extends SettingComponent {

    private BooleanSetting setting;

    private Minecraft mc = Minecraft.getMinecraft();

    private static final int H = 10;

    private float toggleProgress = 0.0f;

    private float hoverProgress = 0.0f;

    private float toggleSpring = 0.0f;

    private float flashProgress = 0.0f;

    public BooleanComponent(BooleanSetting setting) {
        this.setting = setting;
        this.toggleProgress = setting.getValue() ? 1.0f : 0.0f;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, int x, int y, int width) {
        boolean hovering = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + H;
        float hoverTarget = hovering ? 1.0f : 0.0f;
        hoverProgress = AnimationUtil.lerp(hoverProgress, hoverTarget, 0.2f);
        float toggleTarget = setting.getValue() ? 1.0f : 0.0f;
        toggleProgress = AnimationUtil.lerp(toggleProgress, toggleTarget, 0.18f);
        toggleSpring = AnimationUtil.lerp(toggleSpring, 0.0f, 0.12f);
        if (Math.abs(toggleSpring) < 0.01f)
            toggleSpring = 0.0f;
        flashProgress = AnimationUtil.lerp(flashProgress, 0.0f, 0.15f);
        int bgColor = AnimationUtil.lerpColor(ClickGUI.BG_SETTING, 0xFF101018, hoverProgress * 0.5f);
        RenderUtils.drawRoundedRect2D(x, y, x + width, y + H, 2, bgColor);
        if (flashProgress > 0.01f) {
            int flashA = (int) (40 * flashProgress);
            int flashColor = (flashA << 24) | (currentAccent & 0x00FFFFFF);
            RenderUtils.drawRoundedRect2D(x, y, x + width, y + H, 2, flashColor);
        }
        int pillW = 20;
        int pillH = 10;
        int pillX = x + width - pillW - 2;
        int pillY = y + (H - pillH) / 2;
        int pillOff = 0xFF2A6C99;
        int pillOn = currentAccent;
        int pillBg = AnimationUtil.lerpColor(pillOff, pillOn, toggleProgress);
        RenderUtils.drawRoundedRect2D(pillX, pillY, pillX + pillW, pillY + pillH, pillH / 2, pillBg);
        if (toggleProgress > 0.1f) {
            int glowA = (int) (25 * toggleProgress);
            int glowColor = (glowA << 24) | (currentAccent & 0x00FFFFFF);
            RenderUtils.drawRoundedRect2D(pillX - 1, pillY - 1, pillX + pillW + 1, pillY + pillH + 1, pillH / 2 + 1, glowColor);
        }
        float springToggled = toggleProgress + toggleSpring;
        springToggled = Math.max(0.0f, Math.min(1.0f, springToggled));
        int thumbOffset = (int) ((pillW - 8) * springToggled);
        int thumbX = pillX + 1 + thumbOffset;
        int thumbColor = 0xFFFFFFFF;
        RenderUtils.drawRoundedRect2D(thumbX, pillY + 1, thumbX + 7, pillY + pillH - 1, 3, thumbColor);
        int labelColor = AnimationUtil.lerpColor(ClickGUI.TEXT_NORMAL, 0xFFDCEFFA, hoverProgress * 0.3f);
        ClientFontRenderer.drawStringWithShadow(setting.getName(), x + 2, y + 1, labelColor);
        setHoverTooltip(setting, mouseX, mouseY, x, y, width, H);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton, int x, int y, int width) {
        if (mouseButton == 1 && mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + H) {
            resetToDefault(setting);
            return;
        }
        if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + H) {
            setting.setValue(!setting.getValue());
            toggleSpring = setting.getValue() ? 0.25f : -0.25f;
            flashProgress = 1.0f;
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }
}
