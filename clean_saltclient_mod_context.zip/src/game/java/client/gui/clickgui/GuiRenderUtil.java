package client.gui.clickgui;

import net.minecraft.client.gui.Gui;

public class GuiRenderUtil {

    public static void drawRect(int left, int top, int right, int bottom, int color) {
        Gui.drawRect(left, top, right, bottom, color);
    }
}
