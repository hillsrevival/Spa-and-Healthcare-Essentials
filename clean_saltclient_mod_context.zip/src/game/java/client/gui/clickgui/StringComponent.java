package client.gui.clickgui;

import client.Client;
import client.module.StringSetting;
import client.utils.render.RenderUtils;
import client.gui.clickgui.AnimationUtil;
import client.utils.render.ClientFontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiTextField;

public class StringComponent extends SettingComponent {

    private final StringSetting setting;

    private final Minecraft mc = Minecraft.getMinecraft();

    private GuiTextField textField;

    private boolean editing;

    public StringComponent(StringSetting setting) {
        this.setting = setting;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, int x, int y, int w) {
        boolean hovering = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + 10;
        int bgColor = editing ? 0xFF0A0A14 : ClickGUI.BG_SETTING_DEEP;
        RenderUtils.drawRoundedRect2D(x, y, x + w, y + 10, 2, bgColor);
        RenderUtils.drawRoundedRect2D(x, y, x + w, y + 1, 0, ClickGUI.getAccentDim());
        if (editing) {
            float glowPulse = 0.7f + 0.3f * (float) Math.sin(System.currentTimeMillis() / 200.0);
            int borderA = (int) (180 * glowPulse);
            int borderColor = (borderA << 24) | (ClickGUI.getAccent() & 0x00FFFFFF);
            RenderUtils.drawRoundedStroke2D(x, y, x + w, y + 10, 2, 1.5f, borderColor);
        } else if (hovering) {
            RenderUtils.drawRoundedStroke2D(x, y, x + w, y + 10, 2, 0.5f, ClickGUI.getAccentDim());
        }
        String label = setting.getName() + ": ";
        if (editing) {
            String cursor = (System.currentTimeMillis() / 500) % 2 == 0 ? "|" : "";
            label += textField.getText() + cursor;
        } else {
            String val = setting.getValue();
            if (val.length() > 16)
                val = val.substring(0, 14) + "..";
            label += val;
        }
        int labelColor = editing ? ClickGUI.getAccentBright() : ClickGUI.TEXT_NORMAL;
        ClientFontRenderer.drawStringWithShadow(label, x + 3, y + 2, labelColor);
        setHoverTooltip(setting, mouseX, mouseY, x, y, w, 10);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton, int x, int y, int w) {
        if (mouseButton == 1 && mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + 10) {
            resetToDefault(setting);
            editing = false;
            return;
        }
        if (mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + 10) {
            if (mouseButton == 0) {
                editing = !editing;
                if (editing) {
                    textField = new GuiTextField(0, ClientFontRenderer.getFontRenderer(), x + 3, y + 1, w - 6, 8);
                    textField.setFocused(true);
                    textField.setText(setting.getValue());
                    textField.setCanLoseFocus(false);
                }
            }
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
    }

    public boolean handleKeyTyped(char typedChar, int keyCode) {
        if (!editing || textField == null)
            return false;
        if (keyCode == 1) {
            editing = false;
            textField.setFocused(false);
            return true;
        }
        if (keyCode == 28) {
            String text = textField.getText();
            setting.setValue(text);
            editing = false;
            textField.setFocused(false);
            return true;
        }
        textField.textboxKeyTyped(typedChar, keyCode);
        return true;
    }

    public boolean isEditing() {
        return editing;
    }
}
