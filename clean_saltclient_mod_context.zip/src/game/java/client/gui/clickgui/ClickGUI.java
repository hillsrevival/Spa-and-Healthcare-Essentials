package client.gui.clickgui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import client.Client;
import client.config.ConfigIO;
import client.config.ProfileManager;
import client.module.Category;
import client.module.Module;
import client.module.ModuleManager;
import client.module.impl.fun.ColorUi;
import client.module.BooleanSetting;
import client.module.NumberSetting;
import client.module.ModeSetting;
import client.module.ColorSetting;
import client.module.StringSetting;
import client.module.BlockListSetting;
import client.module.Setting;
import net.lax1dude.eaglercraft.Mouse;
import net.lax1dude.eaglercraft.Keyboard;
import net.lax1dude.eaglercraft.EagRuntime;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import client.utils.render.ClientFontRenderer;
import client.utils.render.RenderUtils;
import client.utils.render.GuiBlurUtil;

public class ClickGUI extends GuiScreen {

    private Minecraft mc = Minecraft.getMinecraft();

    private static Module cachedRainbowModule = null;

    private static long lastRainbowCheck = 0;

    private Panel[] panels;

    private int dragPanelIndex = -1;

    private int dragOffsetX, dragOffsetY;

    private long openTime = 0;

    private static int guiLayout = 0;

    private int selectedCategory = 0;

    private float sidebarTransition = 0.0f;

    private static final int LAYOUT_BTN_WIDTH = 58;

    private static final int LAYOUT_BTN_HEIGHT = 12;

    private static final int HIDE_BTN_WIDTH = 42;

    private static final int HIDE_BTN_HEIGHT = 12;

    private static final int CONFIG_BTN_WIDTH = 42;

    private static final int CONFIG_BTN_HEIGHT = 12;

    private static final int SIDEBAR_WIDTH = 90;

    private String searchText = "";

    private boolean searchFocused = true;

    private static final int SEARCH_HEIGHT = 12;

    private static final int SEARCH_BAR_Y = 10;

    private boolean configOpen = false;

    private long configOpenTime = 0L;

    private java.util.List<String> searchHistory = new java.util.ArrayList<>();

    private static final int MAX_HISTORY = 5;

    private static final int PROF_ROW_Y = SEARCH_BAR_Y + SEARCH_HEIGHT + 2;

    private static final int PROF_ROW_H = 14;

    private int selectedSlot = 0;

    private boolean renamingProfile = false;

    private String renameBuffer = "";

    private String statusMsg = "";

    private int statusTimer = 0;

    private static final int PROF_BTN_H = 12;

    private static final int PROF_BTN_W = 38;

    private static final int PROF_SM_W = 30;

    private static final int PROF_EXPORT_W = 52;

    private static final int PROF_IMPORT_W = 48;

    private static final int PROF_ARROW_W = 14;

    private static final int PROF_GAP = 3;

    private static final int RESET_BTN_WIDTH = 64;

    private static final int RESET_BTN_HEIGHT = 12;

    private boolean resetConfirm = false;

    private int resetTimer = 0;

    private static final int GUI_KEY_BTN_WIDTH = 110;

    private static final int GUI_KEY_BTN_HEIGHT = 12;

    private boolean listeningGuiKey = false;

    public static final int BG_DARK = 0xDD07101E;

    public static final int BG_HEADER = 0xDD0D1E36;

    public static final int BG_PANEL = 0xEE0B1A2E;

    public static final int BG_PANEL_HEADER = 0xDD12294A;

    public static final int ACCENT_RED = 0xFF4FC3F7;

    public static final int ACCENT_RED_BRIGHT = 0xFF9BE7FF;

    public static final int ACCENT_RED_DIM = 0xFF1E6F9F;

    public static final int TEXT_RED = 0xFF9BE7FF;

    public static final int TEXT_DIM = 0xFF5F8CA8;

    public static final int TEXT_MUTED = 0xFF7FA6BF;

    public static final int TEXT_NORMAL = 0xFFDCEFFA;

    public static final int BORDER_DARK = 0xFF173A5C;

    public static final int BORDER_RED = 0xFF2A6C99;

    public static final int BG_HOVER = 0xEE163459;

    public static final int BG_ACTIVE = 0xEE1B4272;

    public static final int BG_SETTING = 0xEE091526;

    public static final int BG_SETTING_DEEP = 0xEE07111F;

    public static final int TEXT_DARK = 0xFF4B7391;

    public static final int TOOLTIP_BG = 0xE00B1A2E;

    public static final int TOOLTIP_BORDER = 0xFF4FC3F7;

    private static final int KEY_BACKSPACE = 14;

    @Override
    public void initGui() {
        ClientGuiScale.applyDims(this, mc);
        searchText = "";
        searchFocused = true;
        resetConfirm = false;
        resetTimer = 0;
        listeningGuiKey = false;
        renamingProfile = false;
        configOpen = false;
        statusMsg = "";
        openTime = System.currentTimeMillis();
        loadGuiLayout();
        GuiBlurUtil.captureScreen();
        cachedRainbowModule = null;
        statusTimer = 0;
        selectedSlot = Client.INSTANCE.getProfileManager().getActiveSlot();
        Category[] cats = Category.values();
        panels = new Panel[cats.length];
        int startY = PROF_ROW_Y + PROF_ROW_H + 4;
        if (guiLayout == 1) {
            int panelX = sidebarPanelX();
            int panelWidth = sidebarPanelW();
            if (panelWidth < 100)
                panelWidth = 100;
            for (int i = 0; i < cats.length; i++) {
                panels[i] = new Panel(cats[i], panelX, startY, panelWidth);
            }
        } else {
            if (guiLayout == 2) {
                int cols = 5;
                int fw = Math.max(110, Math.min(150, (this.width - 40) / cols - 10));
                for (int i = 0; i < cats.length; i++) {
                    int col = i % cols;
                    int row = i / cols;
                    panels[i] = new Panel(cats[i], 14 + col * (fw + 10) + row * 16, startY + row * 140, fw);
                }
                return;
            }
            int totalPanels = cats.length;
            int panelGap = 2;
            int margin = 4;
            int panelWidth = (this.width - margin * 2 - (totalPanels - 1) * panelGap) / totalPanels;
            int startX = margin;
            for (int i = 0; i < cats.length; i++) {
                panels[i] = new Panel(cats[i], startX + i * (panelWidth + panelGap), startY, panelWidth);
            }
        }
    }

    private int centralWinW() {
        return Math.min(this.width - 20, 560);
    }

    private int centralOriginX() {
        return guiLayout == 1 ? Math.max(4, (this.width - centralWinW()) / 2) : 4;
    }

    private int sidebarPanelX() {
        return centralOriginX() + SIDEBAR_WIDTH + 6;
    }

    private int sidebarPanelW() {
        return Math.max(100, centralWinW() - SIDEBAR_WIDTH - 6 - (guiLayout == 1 ? 0 : 0));
    }

    private int getSearchWidth() {
        int btnsWidth = RESET_BTN_WIDTH + 6 + GUI_KEY_BTN_WIDTH + 6 + LAYOUT_BTN_WIDTH + 6 + HIDE_BTN_WIDTH + 6 + CONFIG_BTN_WIDTH + 10;
        int maxSearchWidth = this.width - 20 - btnsWidth;
        int searchWidth = panels.length > 0 ? this.width - 400 : 200;
        if (searchWidth > maxSearchWidth)
            searchWidth = maxSearchWidth;
        if (searchWidth < 80)
            searchWidth = 80;
        return searchWidth;
    }

    private boolean drawBtn(int x, int y, int w, int h, int mouseX, int mouseY, String label) {
        boolean hover = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
        GuiRenderUtil.drawRect(x, y, x + w, y + h, hover ? 0xFF1B4272 : 0xFF12294A);
        GuiRenderUtil.drawRect(x, y, x + w, y + 1, BORDER_RED);
        int labelW = ClientFontRenderer.getStringWidth(label);
        ClientFontRenderer.drawStringWithShadow(label, x + (w - labelW) / 2, y + 2, hover ? 0xFFFFFFFF : 0xFFBFE3F7);
        return hover;
    }

    private void showStatus(String msg) {
        statusMsg = msg;
        statusTimer = 80;
    }

    private void drawConfigPopup() {
        float fade = Math.min(1.0f, Math.max(0.0f, (System.currentTimeMillis() - configOpenTime) / 160.0f));
        float ease = AnimationUtil.easeOutCubic(fade);
        GuiRenderUtil.drawRect(0, 0, this.width, this.height, ((int) (170 * ease) << 24));
        int w = 240;
        int h = 140;
        int x = (this.width - w) / 2;
        int y = (this.height - h) / 2;
        float slide = (1.0f - ease) * 10.0f;
        net.lax1dude.eaglercraft.opengl.GlStateManager.pushMatrix();
        net.lax1dude.eaglercraft.opengl.GlStateManager.translate(0, slide, 0);
        int panelA = (int) (255 * ease);
        RenderUtils.drawRoundedRect2D(x, y, x + w, y + h, 6, (panelA << 24) | (BG_PANEL & 0x00FFFFFF));
        RenderUtils.drawRoundedStroke2D(x, y, x + w, y + h, 6, 1.0f, ((int) (200 * ease) << 24) | (BORDER_DARK & 0x00FFFFFF));
        int titleA = (panelA << 24) | (getAccent() & 0x00FFFFFF);
        ClientFontRenderer.drawStringWithShadow("Config", x + (w - ClientFontRenderer.getStringWidth("Config")) / 2, y + 10, titleA);
        int hintA = ((int) (150 * ease) << 24) | (TEXT_MUTED & 0x00FFFFFF);
        String hint = "Preset configs will appear here";
        ClientFontRenderer.drawStringWithShadow(hint, x + (w - ClientFontRenderer.getStringWidth(hint)) / 2, y + h / 2 - 4, hintA);
        String closeHint = "Click outside or press Esc to close";
        ClientFontRenderer.drawStringWithShadow(closeHint, x + (w - ClientFontRenderer.getStringWidth(closeHint)) / 2, y + h - 16, hintA);
        net.lax1dude.eaglercraft.opengl.GlStateManager.popMatrix();
    }

    private void handleConfigClick(int mouseX, int mouseY) {
        int w = 240;
        int h = 140;
        int x = (this.width - w) / 2;
        int y = (this.height - h) / 2;
        if (mouseX < x || mouseX > x + w || mouseY < y || mouseY > y + h) {
            configOpen = false;
        }
    }

    private void drawProfileRow(int mouseX, int mouseY) {
        ProfileManager pm = Client.INSTANCE.getProfileManager();
        int y = PROF_ROW_Y;
        int h = PROF_ROW_H;
        int x = 10;
        boolean hoverLeft = mouseX >= x && mouseX <= x + PROF_ARROW_W && mouseY >= y && mouseY <= y + h;
        GuiRenderUtil.drawRect(x, y, x + PROF_ARROW_W, y + h, hoverLeft ? 0xFF1B4272 : 0xFF12294A);
        ClientFontRenderer.drawStringWithShadow("<", x + 3, y + 3, hoverLeft ? getAccentBright() : getTextAccent());
        x += PROF_ARROW_W;
        int btnsTotal = PROF_BTN_W * 2 + PROF_SM_W + PROF_EXPORT_W + PROF_IMPORT_W + PROF_GAP * 4 + 6;
        int nameW = this.width - 20 - PROF_ARROW_W * 2 - btnsTotal;
        if (nameW < 50)
            nameW = 50;
        int nameX = x;
        boolean hoverName = mouseX >= nameX && mouseX <= nameX + nameW && mouseY >= y && mouseY <= y + h;
        GuiRenderUtil.drawRect(nameX, y, nameX + nameW, y + h, BG_HEADER);
        if (renamingProfile) {
            GuiRenderUtil.drawRect(nameX, y, nameX + 1, y + h, getAccent());
        }
        String nameDisplay;
        int nameColor;
        if (renamingProfile) {
            nameDisplay = renameBuffer.isEmpty() ? "" : renameBuffer;
            if ((System.currentTimeMillis() / 500) % 2 == 0) {
                nameDisplay += "_";
            }
            nameColor = TEXT_NORMAL;
        } else {
            nameDisplay = pm.getName(selectedSlot);
            nameColor = (selectedSlot == pm.getActiveSlot()) ? getTextAccent() : TEXT_NORMAL;
        }
        ClientFontRenderer.drawStringWithShadow(nameDisplay, nameX + 4, y + 3, nameColor);
        if (selectedSlot == pm.getActiveSlot() && !renamingProfile) {
            int dotX = nameX + nameW - 8;
            GuiRenderUtil.drawRect(dotX, y + 5, dotX + 3, y + 9, getAccent());
        }
        x += nameW;
        boolean hoverRight = mouseX >= x && mouseX <= x + PROF_ARROW_W && mouseY >= y && mouseY <= y + h;
        GuiRenderUtil.drawRect(x, y, x + PROF_ARROW_W, y + h, hoverRight ? 0xFF1B4272 : 0xFF12294A);
        ClientFontRenderer.drawStringWithShadow(">", x + 4, y + 3, hoverRight ? getAccentBright() : getTextAccent());
        x += PROF_ARROW_W + 6;
        drawBtn(x, y, PROF_BTN_W, h, mouseX, mouseY, "LOAD");
        x += PROF_BTN_W + PROF_GAP;
        drawBtn(x, y, PROF_BTN_W, h, mouseX, mouseY, "SAVE");
        x += PROF_BTN_W + PROF_GAP;
        drawBtn(x, y, PROF_SM_W, h, mouseX, mouseY, "DEL");
        x += PROF_SM_W + PROF_GAP;
        drawBtn(x, y, PROF_EXPORT_W, h, mouseX, mouseY, "EXPORT");
        x += PROF_EXPORT_W + PROF_GAP;
        drawBtn(x, y, PROF_IMPORT_W, h, mouseX, mouseY, "IMPORT");
    }

    private boolean handleProfileClick(int mouseX, int mouseY, int mouseButton) {
        ProfileManager pm = Client.INSTANCE.getProfileManager();
        int y = PROF_ROW_Y;
        int h = PROF_ROW_H;
        int x = 10;
        if (mouseX >= x && mouseX <= x + PROF_ARROW_W && mouseY >= y && mouseY <= y + h && mouseButton == 0) {
            selectedSlot = (selectedSlot - 1 + pm.getMaxProfiles()) % pm.getMaxProfiles();
            renamingProfile = false;
            return true;
        }
        x += PROF_ARROW_W;
        int btnsTotal = PROF_BTN_W * 2 + PROF_SM_W + PROF_EXPORT_W + PROF_IMPORT_W + PROF_GAP * 4 + 6;
        int nameW = this.width - 20 - PROF_ARROW_W * 2 - btnsTotal;
        if (nameW < 50)
            nameW = 50;
        if (mouseX >= x && mouseX <= x + nameW && mouseY >= y && mouseY <= y + h) {
            if (mouseButton == 0 && !renamingProfile) {
                renamingProfile = true;
                renameBuffer = pm.getName(selectedSlot);
            } else if (mouseButton == 0 && renamingProfile) {
                if (!renameBuffer.trim().isEmpty()) {
                    pm.renameProfile(selectedSlot, renameBuffer.trim());
                }
                renamingProfile = false;
            }
            return true;
        }
        x += nameW;
        if (mouseX >= x && mouseX <= x + PROF_ARROW_W && mouseY >= y && mouseY <= y + h && mouseButton == 0) {
            selectedSlot = (selectedSlot + 1) % pm.getMaxProfiles();
            renamingProfile = false;
            return true;
        }
        x += PROF_ARROW_W + 6;
        if (mouseX >= x && mouseX <= x + PROF_BTN_W && mouseY >= y && mouseY <= y + h && mouseButton == 0) {
            renamingProfile = false;
            if (pm.hasData(selectedSlot)) {
                if (pm.loadProfile(selectedSlot)) {
                    showStatus("Loaded " + pm.getName(selectedSlot));
                } else {
                    showStatus("Failed to load profile");
                }
            } else {
                showStatus("Slot is empty");
            }
            return true;
        }
        x += PROF_BTN_W + PROF_GAP;
        if (mouseX >= x && mouseX <= x + PROF_BTN_W && mouseY >= y && mouseY <= y + h && mouseButton == 0) {
            renamingProfile = false;
            pm.saveProfile(selectedSlot);
            showStatus("Saved to " + pm.getName(selectedSlot));
            return true;
        }
        x += PROF_BTN_W + PROF_GAP;
        if (mouseX >= x && mouseX <= x + PROF_SM_W && mouseY >= y && mouseY <= y + h && mouseButton == 0) {
            renamingProfile = false;
            pm.deleteProfile(selectedSlot);
            showStatus("Deleted " + pm.getName(selectedSlot));
            return true;
        }
        x += PROF_SM_W + PROF_GAP;
        if (mouseX >= x && mouseX <= x + PROF_EXPORT_W && mouseY >= y && mouseY <= y + h && mouseButton == 0) {
            renamingProfile = false;
            String json = pm.exportProfile(selectedSlot);
            if (json != null) {
                net.lax1dude.eaglercraft.EagRuntime.downloadFileWithName("galactic-profile-" + (selectedSlot + 1) + ".json", json.getBytes());
                showStatus("Exported as file");
            } else {
                showStatus("Nothing to export");
            }
            return true;
        }
        x += PROF_EXPORT_W + PROF_GAP;
        if (mouseX >= x && mouseX <= x + PROF_IMPORT_W && mouseY >= y && mouseY <= y + h && mouseButton == 0) {
            renamingProfile = false;
            String clip = getClipboardString();
            if (clip == null || clip.trim().isEmpty()) {
                showStatus("Clipboard is empty — paste JSON config");
            } else if (pm.importProfile(clip.trim())) {
                showStatus("Config imported");
            } else {
                showStatus("Invalid config data");
            }
            return true;
        }
        return false;
    }

    private boolean handleProfileKey(char typedChar, int keyCode) {
        if (!renamingProfile)
            return false;
        if (keyCode == 1) {
            renamingProfile = false;
            return true;
        }
        if (keyCode == 28) {
            ProfileManager pm = Client.INSTANCE.getProfileManager();
            if (!renameBuffer.trim().isEmpty()) {
                pm.renameProfile(selectedSlot, renameBuffer.trim());
            }
            renamingProfile = false;
            return true;
        }
        if (keyCode == KEY_BACKSPACE) {
            if (renameBuffer.length() > 0) {
                renameBuffer = renameBuffer.substring(0, renameBuffer.length() - 1);
            }
            return true;
        }
        if (typedChar >= ' ' && renameBuffer.length() < 24) {
            renameBuffer += typedChar;
            return true;
        }
        return false;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        ClientGuiScale.setupOrtho(mc);
        mouseX = Mouse.getX() * this.width / this.mc.displayWidth;
        mouseY = this.height - Mouse.getY() * this.height / this.mc.displayHeight - 1;
        long openMs = System.currentTimeMillis() - openTime;
        float guiAlpha = Math.min(1.0f, openMs / 200.0f);
        float guiScale = 0.95f + 0.05f * Math.min(1.0f, openMs / 200.0f);
        int bgAlpha = (int) (240 * guiAlpha);
        if (GuiBlurUtil.isEnabled()) {
            GuiBlurUtil.renderBlur(guiAlpha);
        } else {
            GuiRenderUtil.drawRect(0, 0, this.width, this.height, (bgAlpha << 24) | 0x050B16);
            int vigA = (int) (30 * guiAlpha);
            int vigColor = (vigA << 24);
            GuiRenderUtil.drawRect(0, 0, this.width, 30, vigColor);
            GuiRenderUtil.drawRect(0, this.height - 30, this.width, this.height, vigColor);
        }
        if (guiScale < 1.0f) {
            float cx = this.width / 2.0f;
            float cy = this.height / 2.0f;
            net.lax1dude.eaglercraft.opengl.GlStateManager.translate(cx, cy, 0);
            net.lax1dude.eaglercraft.opengl.GlStateManager.scale(guiScale, guiScale, 1.0f);
            net.lax1dude.eaglercraft.opengl.GlStateManager.translate(-cx, -cy, 0);
        }
        if (resetConfirm && resetTimer > 0) {
            resetTimer--;
            if (resetTimer <= 0) {
                resetConfirm = false;
            }
        }
        if (statusTimer > 0) {
            statusTimer--;
        }
        int searchWidth = getSearchWidth();
        RenderUtils.drawRoundedRect2D(10, SEARCH_BAR_Y, 10 + searchWidth, SEARCH_BAR_Y + SEARCH_HEIGHT, 3, BG_HEADER);
        if (searchFocused && !renamingProfile) {
            RenderUtils.drawRoundedRect2D(10, SEARCH_BAR_Y, 12, SEARCH_BAR_Y + SEARCH_HEIGHT, 2, getAccent());
            int glowA = (int) (120 + 40 * AnimationUtil.pulse(1.5f));
            int glowColor = (glowA << 24) | (getAccent() & 0x00FFFFFF);
            GuiRenderUtil.drawRect(10, SEARCH_BAR_Y + SEARCH_HEIGHT - 1, 10 + searchWidth, SEARCH_BAR_Y + SEARCH_HEIGHT, glowColor);
        } else {
            RenderUtils.drawRoundedStroke2D(10, SEARCH_BAR_Y, 10 + searchWidth, SEARCH_BAR_Y + SEARCH_HEIGHT, 3, 0.5f, BORDER_DARK);
        }
        String displayText = searchText.isEmpty() ? "Search..." : searchText;
        int textColor = searchText.isEmpty() ? getTextAccentDim() : TEXT_NORMAL;
        if (searchFocused && !renamingProfile && !searchText.isEmpty()) {
            if ((System.currentTimeMillis() / 500) % 2 == 0) {
                displayText += "_";
            }
        }
        ClientFontRenderer.drawStringWithShadow(displayText, 14, SEARCH_BAR_Y + 2, textColor);
        if (!searchText.isEmpty()) {
            int clearX = 10 + searchWidth - 14;
            int clearY = SEARCH_BAR_Y + 2;
            boolean hClear = mouseX >= clearX && mouseX <= clearX + 10 && mouseY >= clearY && mouseY <= clearY + 10;
            GuiRenderUtil.drawRect(clearX, clearY, clearX + 10, clearY + 10, hClear ? 0xFF444466 : 0xFF12294A);
            ClientFontRenderer.drawStringWithShadow("X", clearX + 2, clearY + 1, hClear ? 0xFFBFE3F7 : getTextAccentDim());
        }
        int resetX = 10 + searchWidth + 6;
        boolean hReset = mouseX >= resetX && mouseX <= resetX + RESET_BTN_WIDTH && mouseY >= SEARCH_BAR_Y && mouseY <= SEARCH_BAR_Y + RESET_BTN_HEIGHT;
        if (resetConfirm) {
            GuiRenderUtil.drawRect(resetX, SEARCH_BAR_Y, resetX + RESET_BTN_WIDTH, SEARCH_BAR_Y + RESET_BTN_HEIGHT, 0xFF1B4272);
            String rLabel = "CONFIRM?";
            int rW = ClientFontRenderer.getStringWidth(rLabel);
            ClientFontRenderer.drawStringWithShadow(rLabel, resetX + (RESET_BTN_WIDTH - rW) / 2, SEARCH_BAR_Y + 2, hReset ? 0xFFFFFFFF : 0xFFBFE3F7);
        } else {
            drawBtn(resetX, SEARCH_BAR_Y, RESET_BTN_WIDTH, RESET_BTN_HEIGHT, mouseX, mouseY, "RESET ALL");
        }
        int guiKeyX = resetX + RESET_BTN_WIDTH + 6;
        boolean hGuiKey = mouseX >= guiKeyX && mouseX <= guiKeyX + GUI_KEY_BTN_WIDTH && mouseY >= SEARCH_BAR_Y && mouseY <= SEARCH_BAR_Y + GUI_KEY_BTN_HEIGHT;
        GuiRenderUtil.drawRect(guiKeyX, SEARCH_BAR_Y, guiKeyX + GUI_KEY_BTN_WIDTH, SEARCH_BAR_Y + GUI_KEY_BTN_HEIGHT, hGuiKey ? 0xFF1B4272 : 0xFF12294A);
        GuiRenderUtil.drawRect(guiKeyX, SEARCH_BAR_Y, guiKeyX + GUI_KEY_BTN_WIDTH, SEARCH_BAR_Y + 1, BORDER_RED);
        String guiKeyLabel;
        int guiKeyColor;
        if (listeningGuiKey) {
            guiKeyLabel = "Press a key...";
            guiKeyColor = 0xFF00FFAA;
        } else {
            guiKeyLabel = "GUI Key [" + Keyboard.getKeyName(Client.INSTANCE.getGuiKey()) + "]";
            guiKeyColor = hGuiKey ? getAccentBright() : getTextAccent();
        }
        int gkW = ClientFontRenderer.getStringWidth(guiKeyLabel);
        ClientFontRenderer.drawStringWithShadow(guiKeyLabel, guiKeyX + (GUI_KEY_BTN_WIDTH - gkW) / 2, SEARCH_BAR_Y + 2, guiKeyColor);
        int layoutX = guiKeyX + GUI_KEY_BTN_WIDTH + 6;
        boolean hLayout = mouseX >= layoutX && mouseX <= layoutX + LAYOUT_BTN_WIDTH && mouseY >= SEARCH_BAR_Y && mouseY <= SEARCH_BAR_Y + LAYOUT_BTN_HEIGHT;
        String layoutLabel = guiLayout == 1 ? "CENTRAL" : (guiLayout == 2 ? "FLOATING" : "DOCKED");
        GuiRenderUtil.drawRect(layoutX, SEARCH_BAR_Y, layoutX + LAYOUT_BTN_WIDTH, SEARCH_BAR_Y + LAYOUT_BTN_HEIGHT, hLayout ? 0xFF1B4272 : 0xFF12294A);
        GuiRenderUtil.drawRect(layoutX, SEARCH_BAR_Y, layoutX + LAYOUT_BTN_WIDTH, SEARCH_BAR_Y + 1, BORDER_RED);
        int layoutLabelW = ClientFontRenderer.getStringWidth(layoutLabel);
        ClientFontRenderer.drawStringWithShadow(layoutLabel, layoutX + (LAYOUT_BTN_WIDTH - layoutLabelW) / 2, SEARCH_BAR_Y + 2, hLayout ? 0xFFFFFFFF : 0xFFBFE3F7);
        int hideX = layoutX + LAYOUT_BTN_WIDTH + 6;
        boolean hHide = mouseX >= hideX && mouseX <= hideX + HIDE_BTN_WIDTH && mouseY >= SEARCH_BAR_Y && mouseY <= SEARCH_BAR_Y + HIDE_BTN_HEIGHT;
        String hideLabel = "Hide";
        GuiRenderUtil.drawRect(hideX, SEARCH_BAR_Y, hideX + HIDE_BTN_WIDTH, SEARCH_BAR_Y + HIDE_BTN_HEIGHT, hHide ? 0xFF1B4272 : 0xFF12294A);
        GuiRenderUtil.drawRect(hideX, SEARCH_BAR_Y, hideX + HIDE_BTN_WIDTH, SEARCH_BAR_Y + 1, BORDER_RED);
        int hideLabelW = ClientFontRenderer.getStringWidth(hideLabel);
        ClientFontRenderer.drawStringWithShadow(hideLabel, hideX + (HIDE_BTN_WIDTH - hideLabelW) / 2, SEARCH_BAR_Y + 2, hHide ? 0xFFFFFFFF : 0xFFBFE3F7);
        int configX = hideX + HIDE_BTN_WIDTH + 6;
        boolean hConfig = mouseX >= configX && mouseX <= configX + CONFIG_BTN_WIDTH && mouseY >= SEARCH_BAR_Y && mouseY <= SEARCH_BAR_Y + CONFIG_BTN_HEIGHT;
        String configLabel = "Config";
        GuiRenderUtil.drawRect(configX, SEARCH_BAR_Y, configX + CONFIG_BTN_WIDTH, SEARCH_BAR_Y + CONFIG_BTN_HEIGHT, hConfig ? 0xFF1B4272 : 0xFF12294A);
        GuiRenderUtil.drawRect(configX, SEARCH_BAR_Y, configX + CONFIG_BTN_WIDTH, SEARCH_BAR_Y + 1, BORDER_RED);
        int configLabelW = ClientFontRenderer.getStringWidth(configLabel);
        ClientFontRenderer.drawStringWithShadow(configLabel, configX + (CONFIG_BTN_WIDTH - configLabelW) / 2, SEARCH_BAR_Y + 2, hConfig ? 0xFFFFFFFF : 0xFFBFE3F7);
        drawProfileRow(mouseX, mouseY);
        String filter = searchText.toLowerCase();
        sidebarTransition = AnimationUtil.lerp(sidebarTransition, 1.0f, 0.15f);
        if (guiLayout == 1) {
            Category[] cats = Category.values();
            int sidebarX = centralOriginX();
            int sidebarY = PROF_ROW_Y + PROF_ROW_H + 4;
            int sidebarH = this.height - sidebarY - 10;
            int catH = 14;
            int catGap = 1;
            if (guiLayout == 1) {
                int winX = sidebarX - 6;
                int winR = sidebarX + centralWinW() + 6;
                RenderUtils.drawRoundedRect2D(winX, sidebarY - 6, winR, sidebarY + sidebarH + 6, 6, BG_DARK);
                RenderUtils.drawRoundedStroke2D(winX, sidebarY - 6, winR, sidebarY + sidebarH + 6, 6, 1.0f, BORDER_RED);
                GuiRenderUtil.drawRect(winX + 8, sidebarY - 6, winR - 8, sidebarY - 5, getAccent());
            }
            RenderUtils.drawRoundedRect2D(sidebarX, sidebarY, sidebarX + SIDEBAR_WIDTH, sidebarY + sidebarH, 4, BG_PANEL);
            RenderUtils.drawRoundedStroke2D(sidebarX, sidebarY, sidebarX + SIDEBAR_WIDTH, sidebarY + sidebarH, 4, 1.0f, BORDER_DARK);
            for (int i = 0; i < cats.length; i++) {
                int itemY = sidebarY + 2 + i * (catH + catGap);
                if (itemY + catH > sidebarY + sidebarH)
                    break;
                boolean isSelected = (i == selectedCategory);
                boolean isHover = mouseX >= sidebarX + 2 && mouseX <= sidebarX + SIDEBAR_WIDTH - 2 && mouseY >= itemY && mouseY <= itemY + catH;
                int catBg;
                if (isSelected) {
                    int accentRgb = getAccent() & 0x00FFFFFF;
                    int accentA = 30;
                    catBg = (accentA << 24) | accentRgb;
                } else if (isHover) {
                    catBg = 0xFF12294A;
                } else {
                    catBg = 0x001A1A1A;
                }
                if (catBg != 0x001A1A1A) {
                    RenderUtils.drawRoundedRect2D(sidebarX + 2, itemY, sidebarX + SIDEBAR_WIDTH - 2, itemY + catH, 2, catBg);
                }
                if (isSelected) {
                    GuiRenderUtil.drawRect(sidebarX + 2, itemY + 2, sidebarX + 4, itemY + catH - 2, getAccent());
                }
                int catColor;
                if (isSelected) {
                    catColor = getAccentBright();
                } else if (isHover) {
                    catColor = TEXT_NORMAL;
                } else {
                    catColor = TEXT_MUTED;
                }
                String catName = cats[i].name();
                if (catName.length() > 1) {
                    catName = catName.charAt(0) + catName.substring(1).toLowerCase();
                }
                ClientFontRenderer.drawStringWithShadow(catName, sidebarX + 8, itemY + 3, catColor);
            }
            if (selectedCategory >= 0 && selectedCategory < panels.length && panels[selectedCategory].isExtended()) {
                int panelX = sidebarPanelX();
                int panelWidth = sidebarPanelW();
                if (panelWidth < 100)
                    panelWidth = 100;
                panels[selectedCategory].setX(panelX);
                panels[selectedCategory].setWidth(panelWidth);
                panels[selectedCategory].setSearchFilter(filter);
                panels[selectedCategory].drawScreen(mouseX, mouseY);
            }
        } else {
            for (int i = 0; i < panels.length; i++) {
                long panelDelay = i * 60L;
                float panelAlpha = Math.min(1.0f, Math.max(0.0f, (openMs - panelDelay) / 200.0f));
                panels[i].setSearchFilter(filter);
                panels[i].drawScreen(mouseX, mouseY);
            }
        }
        if (statusTimer > 0 && !statusMsg.isEmpty()) {
            int alpha = statusTimer < 20 ? (statusTimer * 12) : 240;
            int sW = ClientFontRenderer.getStringWidth(statusMsg) + 16;
            int sX = (this.width - sW) / 2;
            int sY = this.height / 2 - 10;
            GuiRenderUtil.drawRect(sX, sY, sX + sW, sY + 18, (alpha << 24) | 0x0B1A2E);
            GuiRenderUtil.drawRect(sX, sY, sX + sW, sY + 1, (alpha << 24) | 0x2A6C99);
            ClientFontRenderer.drawStringWithShadow(statusMsg, sX + 8, sY + 5, (alpha << 24) | 0xCFEFFF);
        }
        ModuleButton.drawDeferredTooltip(mc);
        ContextMenu.render(mc);
        if (configOpen) {
            drawConfigPopup();
        }
        if (guiScale < 1.0f) {
            float cx = this.width / 2.0f;
            float cy = this.height / 2.0f;
            net.lax1dude.eaglercraft.opengl.GlStateManager.translate(cx, cy, 0);
            float invScale = 1.0f / guiScale;
            net.lax1dude.eaglercraft.opengl.GlStateManager.scale(invScale, invScale, 1.0f);
            net.lax1dude.eaglercraft.opengl.GlStateManager.translate(-cx, -cy, 0);
        }
        ClientGuiScale.restoreVanillaOrtho(mc);
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0) {
            int mx = Mouse.getEventX() * this.width / this.mc.displayWidth;
            int my = this.height - Mouse.getEventY() * this.height / this.mc.displayHeight - 1;
            if (guiLayout == 1) {
                if (selectedCategory >= 0 && selectedCategory < panels.length) {
                    panels[selectedCategory].handleScroll(d, mx, my);
                }
            } else {
                for (Panel p : panels) {
                    p.handleScroll(d, mx, my);
                }
            }
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (configOpen) {
            handleConfigClick(mouseX, mouseY);
            return;
        }
        if (ContextMenu.handleClick(mouseX, mouseY, mouseButton)) {
            return;
        }
        int searchWidth = getSearchWidth();
        if (handleProfileClick(mouseX, mouseY, mouseButton)) {
            return;
        }
        int guiKeyX = 10 + searchWidth + 6 + RESET_BTN_WIDTH + 6;
        if (mouseX >= guiKeyX && mouseX <= guiKeyX + GUI_KEY_BTN_WIDTH && mouseY >= SEARCH_BAR_Y && mouseY <= SEARCH_BAR_Y + GUI_KEY_BTN_HEIGHT) {
            if (mouseButton == 0) {
                listeningGuiKey = true;
            }
            return;
        }
        int layoutBtnX = 10 + searchWidth + 6 + RESET_BTN_WIDTH + 6 + GUI_KEY_BTN_WIDTH + 6;
        if (mouseX >= layoutBtnX && mouseX <= layoutBtnX + LAYOUT_BTN_WIDTH && mouseY >= SEARCH_BAR_Y && mouseY <= SEARCH_BAR_Y + LAYOUT_BTN_HEIGHT) {
            if (mouseButton == 0) {
                setGuiLayout((guiLayout + 1) % 3);
                initGui();
            }
            return;
        }
        int hideBtnX = layoutBtnX + LAYOUT_BTN_WIDTH + 6;
        if (mouseX >= hideBtnX && mouseX <= hideBtnX + HIDE_BTN_WIDTH && mouseY >= SEARCH_BAR_Y && mouseY <= SEARCH_BAR_Y + HIDE_BTN_HEIGHT) {
            if (mouseButton == 0) {
                mc.displayGuiScreen(new ModuleHideScreen());
            }
            return;
        }
        int configBtnX = hideBtnX + HIDE_BTN_WIDTH + 6;
        if (mouseX >= configBtnX && mouseX <= configBtnX + CONFIG_BTN_WIDTH && mouseY >= SEARCH_BAR_Y && mouseY <= SEARCH_BAR_Y + CONFIG_BTN_HEIGHT) {
            if (mouseButton == 0) {
                configOpen = true;
                configOpenTime = System.currentTimeMillis();
            }
            return;
        }
        int resetX = 10 + searchWidth + 6;
        if (mouseX >= resetX && mouseX <= resetX + RESET_BTN_WIDTH && mouseY >= SEARCH_BAR_Y && mouseY <= SEARCH_BAR_Y + RESET_BTN_HEIGHT) {
            if (resetConfirm) {
                resetAll();
                resetConfirm = false;
                resetTimer = 0;
            } else {
                resetConfirm = true;
                resetTimer = 60;
            }
            return;
        }
        if (mouseX >= 10 && mouseX <= 10 + searchWidth && mouseY >= SEARCH_BAR_Y && mouseY <= SEARCH_BAR_Y + SEARCH_HEIGHT) {
            if (!searchText.isEmpty()) {
                int clearX = 10 + searchWidth - 14;
                int clearY = SEARCH_BAR_Y + 2;
                if (mouseX >= clearX && mouseX <= clearX + 10 && mouseY >= clearY && mouseY <= clearY + 10) {
                    searchText = "";
                    searchFocused = true;
                    return;
                }
            }
            searchFocused = true;
            return;
        } else {
            searchFocused = false;
        }
        if (guiLayout == 1) {
            Category[] cats = Category.values();
            int sidebarX = centralOriginX();
            int sidebarY = PROF_ROW_Y + PROF_ROW_H + 4;
            int sidebarH = this.height - sidebarY - 10;
            int catH = 14;
            int catGap = 1;
            if (mouseX >= sidebarX && mouseX <= sidebarX + SIDEBAR_WIDTH && mouseY >= sidebarY && mouseY <= sidebarY + sidebarH) {
                for (int i = 0; i < cats.length; i++) {
                    int itemY = sidebarY + 2 + i * (catH + catGap);
                    if (itemY + catH > sidebarY + sidebarH)
                        break;
                    if (mouseY >= itemY && mouseY <= itemY + catH) {
                        if (mouseButton == 0) {
                            setSelectedCategory(i);
                            if (!panels[i].isExtended()) {
                                panels[i].setExtended(true);
                            }
                        } else if (mouseButton == 1) {
                            setSelectedCategory(i);
                            panels[i].setExtended(!panels[i].isExtended());
                        }
                        return;
                    }
                }
                return;
            }
        }
        for (int i = panels.length - 1; i >= 0; i--) {
            Panel panel = panels[i];
            int px = panel.getX();
            int py = panel.getY();
            int pw = panel.getWidth();
            if (mouseX >= px && mouseX <= px + pw && mouseY >= py && mouseY <= py + panel.getHeaderHeight()) {
                if (mouseButton == 0) {
                    dragPanelIndex = i;
                    dragOffsetX = mouseX - px;
                    dragOffsetY = mouseY - py;
                }
                panel.mouseClicked(mouseX, mouseY, mouseButton);
                return;
            }
        }
        if (guiLayout == 1) {
            if (selectedCategory >= 0 && selectedCategory < panels.length) {
                panels[selectedCategory].mouseClicked(mouseX, mouseY, mouseButton);
            }
        } else {
            for (Panel panel : panels) {
                panel.mouseClicked(mouseX, mouseY, mouseButton);
            }
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        dragPanelIndex = -1;
        for (Panel panel : panels) {
            panel.mouseReleased(mouseX, mouseY, state);
        }
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        if (dragPanelIndex >= 0 && dragPanelIndex < panels.length) {
            Panel panel = panels[dragPanelIndex];
            panel.setX(mouseX - dragOffsetX);
            panel.setY(mouseY - dragOffsetY);
        }
    }

    private void resetAll() {
        for (Module m : ModuleManager.getModules()) {
            if (m.isToggled()) {
                m.setToggled(false);
            }
            m.setKey(-1);
            for (Setting<?> s : m.getSettings()) {
                if (s instanceof BooleanSetting) {
                    ((BooleanSetting) s).setValue(((BooleanSetting) s).getDefault());
                } else if (s instanceof NumberSetting) {
                    ((NumberSetting) s).setValue(((NumberSetting) s).getDefault());
                } else if (s instanceof ModeSetting) {
                    ((ModeSetting) s).setMode(((ModeSetting) s).getDefault());
                } else if (s instanceof ColorSetting) {
                    ((ColorSetting) s).setValue(((ColorSetting) s).getDefault());
                } else if (s instanceof StringSetting) {
                    ((StringSetting) s).setValue(((StringSetting) s).getDefault());
                } else if (s instanceof BlockListSetting) {
                    BlockListSetting bl = (BlockListSetting) s;
                    String[] def = bl.getDefault();
                    bl.setValue(def != null ? def.clone() : new String[0]);
                }
            }
        }
        Client.INSTANCE.setGuiKey(Keyboard.KEY_RSHIFT);
        ConfigIO.write("config", new byte[0]);
        Client.INSTANCE.saveConfig();
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (configOpen && keyCode == 1) {
            configOpen = false;
            return;
        }
        if (handleProfileKey(typedChar, keyCode))
            return;
        if (listeningGuiKey) {
            if (keyCode == 1) {
                Client.INSTANCE.setGuiKey(Keyboard.KEY_RSHIFT);
                listeningGuiKey = false;
                return;
            }
            if (keyCode > 0) {
                Client.INSTANCE.setGuiKey(keyCode);
            }
            listeningGuiKey = false;
            return;
        }
        if (keyCode == 1) {
            if (searchFocused && !searchText.isEmpty()) {
                searchText = "";
                return;
            }
            boolean consumed = false;
            for (Panel panel : panels) {
                if (panel.handleKeyTyped(typedChar, keyCode)) {
                    consumed = true;
                }
            }
            if (!consumed) {
                mc.displayGuiScreen(null);
            }
            return;
        }
        for (Panel panel : panels) {
            if (panel.handleKeyTyped(typedChar, keyCode)) {
                return;
            }
        }
        if (!searchFocused)
            return;
        if (keyCode == 28 && !searchText.isEmpty()) {
            addToSearchHistory(searchText);
            return;
        }
        if (keyCode == KEY_BACKSPACE) {
            if (searchText.length() > 0) {
                searchText = searchText.substring(0, searchText.length() - 1);
            }
            return;
        }
        if (typedChar >= ' ') {
            searchText += typedChar;
        }
    }

    private void addToSearchHistory(String term) {
        searchHistory.remove(term);
        searchHistory.add(0, term);
        while (searchHistory.size() > MAX_HISTORY) {
            searchHistory.remove(searchHistory.size() - 1);
        }
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    public static int getGuiLayout() {
        return guiLayout;
    }

    public static void setGuiLayout(int layout) {
        guiLayout = layout;
        client.config.ConfigIO.write("gui_layout", new byte[] { (byte) layout });
    }

    public static void loadGuiLayout() {
        byte[] data = client.config.ConfigIO.read("gui_layout");
        if (data != null && data.length > 0) {
            guiLayout = data[0];
            if (guiLayout < 0 || guiLayout > 2)
                guiLayout = 0;
        }
    }

    public int getSelectedCategory() {
        return selectedCategory;
    }

    public void setSelectedCategory(int index) {
        if (index != selectedCategory) {
            selectedCategory = index;
            sidebarTransition = 0.0f;
        }
    }

    public static int getAccent() {
        refreshRainbowCache();
        if (cachedRainbowModule != null && cachedRainbowModule.isToggled()) {
            return ColorUi.getRainbowColor(255);
        }
        return ACCENT_RED;
    }

    public static int getAccentBright() {
        refreshRainbowCache();
        if (cachedRainbowModule != null && cachedRainbowModule.isToggled()) {
            return ColorUi.getRainbowColor(255);
        }
        return ACCENT_RED_BRIGHT;
    }

    public static int getAccentDim() {
        refreshRainbowCache();
        if (cachedRainbowModule != null && cachedRainbowModule.isToggled()) {
            return ColorUi.getRainbowColor(80);
        }
        return ACCENT_RED_DIM;
    }

    public static int getAccentAlpha(int alpha) {
        refreshRainbowCache();
        if (cachedRainbowModule != null && cachedRainbowModule.isToggled()) {
            return ColorUi.getRainbowColor(alpha);
        }
        return (alpha << 24) | 0x4FC3F7;
    }

    public static int getTextAccent() {
        refreshRainbowCache();
        if (cachedRainbowModule != null && cachedRainbowModule.isToggled()) {
            return ColorUi.getRainbowColor(255);
        }
        return TEXT_RED;
    }

    public static int getTextAccentDim() {
        refreshRainbowCache();
        if (cachedRainbowModule != null && cachedRainbowModule.isToggled()) {
            return ColorUi.getRainbowColor(150);
        }
        return TEXT_DIM;
    }

    private static void refreshRainbowCache() {
        long now = System.currentTimeMillis();
        if (now - lastRainbowCheck > 1000) {
            cachedRainbowModule = ModuleManager.getModuleByName("ColorUi");
            lastRainbowCheck = now;
        }
    }
}
