package client.gui.clickgui;

import client.Client;
import client.module.NumberSetting;
import client.utils.render.RenderUtils;
import client.utils.render.ClientFontRenderer;
import net.minecraft.client.Minecraft;

public class SliderComponent extends SettingComponent {

    private NumberSetting setting;

    private Minecraft mc = Minecraft.getMinecraft();

    private boolean dragging;

    private static final int H = 10;

    private float displayRatio = 0.0f;

    public SliderComponent(NumberSetting setting) {
        this.setting = setting;
        this.displayRatio = getCurrentRatio();
    }

    private float getCurrentRatio() {
        double min = setting.getMin();
        double max = setting.getMax();
        double range = max - min;
        return range > 0 ? (float) ((setting.getValue().doubleValue() - min) / range) : 0.0f;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, int x, int y, int width) {
        if (dragging) {
            updateSlider(mouseX, x, width);
        }
        float target = getCurrentRatio();
        displayRatio = AnimationUtil.lerp(displayRatio, target, 0.3f);
        boolean hovering = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + H;
        RenderUtils.drawRoundedRect2D(x, y, x + width, y + H, 2, ClickGUI.BG_SETTING);
        double val = setting.getValue().doubleValue();
        String label = setting.getName() + ": " + formatValue(val);
        ClientFontRenderer.drawStringWithShadow(label, x + 2, y + 1, ClickGUI.TEXT_NORMAL);
        int trackX = x + 2;
        int trackY = y + 7;
        int trackW = width - 4;
        RenderUtils.drawRoundedRect2D(trackX, trackY, trackX + trackW, trackY + 3, 1, ClickGUI.BORDER_DARK);
        int fillW = (int) (trackW * Math.max(0, Math.min(1, displayRatio)));
        if (fillW > 0) {
            int glowA = dragging ? 30 : 15;
            int glowColor = (glowA << 24) | (currentAccent & 0x00FFFFFF);
            RenderUtils.drawRoundedRect2D(trackX, trackY - 1, trackX + fillW, trackY + 4, 2, glowColor);
            RenderUtils.drawRoundedRect2D(trackX, trackY, trackX + fillW, trackY + 3, 1, currentAccent);
        }
        int thumbX = trackX + fillW;
        if (dragging || hovering) {
            int thumbGlowA = dragging ? 50 : 25;
            int thumbGlow = (thumbGlowA << 24) | (currentAccentBright & 0x00FFFFFF);
            RenderUtils.drawRoundedRect2D(thumbX - 2, trackY - 2, thumbX + 4, trackY + 5, 3, thumbGlow);
        }
        RenderUtils.drawRoundedRect2D(thumbX - 1, trackY - 1, thumbX + 3, trackY + 4, 2, currentAccentBright);
        if (dragging || hovering) {
            String valStr = formatValue(val);
            int valW = ClientFontRenderer.getStringWidth(valStr) + 6;
            int valX = thumbX - valW / 2 + 1;
            int valY = trackY - 14;
            if (valX < x)
                valX = x;
            if (valX + valW > x + width)
                valX = x + width - valW;
            RenderUtils.drawRoundedRect2D(valX, valY, valX + valW, valY + 11, 3, 0xE0000000);
            RenderUtils.drawRoundedStroke2D(valX, valY, valX + valW, valY + 11, 3, 0.5f, currentAccent);
            ClientFontRenderer.drawStringWithShadow(valStr, valX + 3, valY + 2, 0xFFFFFFFF);
        }
        setHoverTooltip(setting, mouseX, mouseY, x, y, width, H);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton, int x, int y, int width) {
        if (mouseButton == 1 && mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + H) {
            resetToDefault(setting);
            return;
        }
        if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + H) {
            dragging = true;
            updateSlider(mouseX, x, width);
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        if (dragging) {
            dragging = false;
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        }
    }

    private void updateSlider(int mouseX, int x, int width) {
        double min = setting.getMin();
        double max = setting.getMax();
        double range = max - min;
        double ratio = (mouseX - x - 2) / (double) (width - 4);
        ratio = Math.max(0, Math.min(1, ratio));
        double value = min + ratio * range;
        double step = setting.getStep();
        if (step > 0) {
            value = Math.round((value - min) / step) * step + min;
        }
        value = Math.max(min, Math.min(max, value));
        setting.setValue(value);
    }

    private String formatValue(double val) {
        if (setting.getMin() >= 1.0 && val == Math.floor(val)) {
            return String.valueOf((int) val);
        }
        double step = setting.getStep();
        int decimals = 1;
        if (step > 0) {
            decimals = Math.max(0, (int) Math.ceil(-Math.log10(step)));
            if (decimals > 6)
                decimals = 6;
        }
        return formatFixed(val, decimals);
    }

    /** Plain fixed-decimal formatting (String.format is unreliable in the browser build). */
    private static String formatFixed(double val, int decimals) {
        if (Double.isNaN(val) || Double.isInfinite(val))
            return "0";
        if (decimals <= 0)
            return String.valueOf((long) Math.round(val));
        double pow = 1.0;
        for (int i = 0; i < decimals; i++)
            pow *= 10.0;
        long scaled = Math.round(Math.abs(val) * pow);
        long whole = (long) (scaled / (long) pow);
        long frac = scaled % (long) pow;
        StringBuilder f = new StringBuilder(String.valueOf(frac));
        while (f.length() < decimals)
            f.insert(0, '0');
        return (val < 0 && scaled != 0 ? "-" : "") + whole + "." + f;
    }
}
