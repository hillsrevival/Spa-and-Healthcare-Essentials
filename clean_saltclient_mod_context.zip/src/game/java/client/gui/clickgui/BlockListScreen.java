package client.gui.clickgui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import client.module.BlockListSetting;
import net.lax1dude.eaglercraft.Mouse;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import client.utils.render.ClientFontRenderer;

public class BlockListScreen extends GuiScreen {

    private final BlockListSetting setting;

    private final Minecraft mc = Minecraft.getMinecraft();

    private String searchText = "";

    private boolean searchFocused = true;

    private final List<Entry> allEntries = new ArrayList<Entry>();

    private final Map<String, Entry> entryById = new HashMap<String, Entry>();

    private List<Entry> availableView = new ArrayList<Entry>();

    private List<Entry> selectedView = new ArrayList<Entry>();

    private boolean viewDirty = true;

    private int leftScroll = 0;

    private int rightScroll = 0;

    private static final int MARGIN = 6;

    private static final int HEADER_H = 16;

    private static final int SEARCH_H = 14;

    private static final int COL_HEADER_H = 12;

    private static final int ROW_H = 16;

    private static final int FOOTER_H = 14;

    private static final int COL_GAP = 4;

    private static final int DONE_W = 42;

    private static final int DONE_H = 12;

    private static final int BTN_W = 34;

    private static final int BTN_H = 11;

    private static final int KEY_BACKSPACE = 14;

    private static final int KEY_ESC = 1;

    private int colW;

    private int leftX, rightX;

    private int listTop, listBottom;

    private int visibleRows;

    private String hoverId = null;

    private static class Entry {

        final String id;

        final Block block;

        final String label;

        Entry(String id, Block block, String label) {
            this.id = id;
            this.block = block;
            this.label = label;
        }
    }

    public BlockListScreen(BlockListSetting setting) {
        this.setting = setting;
    }

    @Override
    public void initGui() {
        ClientGuiScale.applyDims(this, mc);
        buildCatalog();
        searchText = "";
        searchFocused = true;
        leftScroll = 0;
        rightScroll = 0;
        viewDirty = true;
        colW = (width - MARGIN * 2 - COL_GAP) / 2;
        leftX = MARGIN;
        rightX = MARGIN + colW + COL_GAP;
        int top = MARGIN + HEADER_H + 2 + SEARCH_H + 2 + COL_HEADER_H;
        listTop = top;
        listBottom = height - FOOTER_H - MARGIN;
        visibleRows = Math.max(1, (listBottom - listTop) / ROW_H);
    }

    private void buildCatalog() {
        allEntries.clear();
        entryById.clear();
        for (String id : setting.getAllowedBlocks()) {
            Entry e = entryFor(id);
            if (e != null) {
                allEntries.add(e);
            }
        }
        allEntries.sort((a, b) -> {
            int c = a.label.toLowerCase(Locale.ROOT).compareTo(b.label.toLowerCase(Locale.ROOT));
            return c != 0 ? c : a.id.compareTo(b.id);
        });
    }

    private Entry entryFor(String id) {
        Entry cached = entryById.get(id);
        if (cached != null) {
            return cached;
        }
        Block block = BlockListSetting.lookupBlock(id);
        String label = block != null ? block.getLocalizedName() : null;
        if (label == null || label.isEmpty() || label.endsWith(".name")) {
            label = prettify(id);
        }
        Entry e = new Entry(id, block, label);
        entryById.put(id, e);
        return e;
    }

    private static String prettify(String id) {
        String path = id.contains(":") ? id.substring(id.indexOf(':') + 1) : id;
        String[] words = path.replace('-', '_').split("_");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            if (w.isEmpty()) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(Character.toUpperCase(w.charAt(0)));
            if (w.length() > 1) {
                sb.append(w.substring(1));
            }
        }
        return sb.length() > 0 ? sb.toString() : path;
    }

    private void markDirty() {
        viewDirty = true;
    }

    private void rebuildViews() {
        String q = searchText.toLowerCase(Locale.ROOT).trim();
        String[] sel = setting.getValue();
        if (sel == null) {
            sel = new String[0];
        }
        Set<String> selectedLower = new HashSet<String>();
        for (String s : sel) {
            selectedLower.add(s.toLowerCase(Locale.ROOT));
        }
        selectedView = new ArrayList<Entry>();
        for (String id : sel) {
            Entry e = entryFor(id);
            if (matches(e, q)) {
                selectedView.add(e);
            }
        }
        availableView = new ArrayList<Entry>();
        for (Entry e : allEntries) {
            if (!selectedLower.contains(e.id.toLowerCase(Locale.ROOT)) && matches(e, q)) {
                availableView.add(e);
            }
        }
        clampScrolls();
        viewDirty = false;
    }

    private void clampScrolls() {
        leftScroll = clampScroll(leftScroll, availableView.size());
        rightScroll = clampScroll(rightScroll, selectedView.size());
    }

    private int clampScroll(int scroll, int size) {
        int max = Math.max(0, size - visibleRows);
        return Math.max(0, Math.min(scroll, max));
    }

    private boolean matches(Entry e, String q) {
        if (q.isEmpty()) {
            return true;
        }
        return e.label.toLowerCase(Locale.ROOT).contains(q) || e.id.toLowerCase(Locale.ROOT).contains(q);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        ClientGuiScale.setupOrtho(mc);
        mouseX = Mouse.getX() * this.width / this.mc.displayWidth;
        mouseY = this.height - Mouse.getY() * this.height / this.mc.displayHeight - 1;
        if (viewDirty) {
            rebuildViews();
        }
        GuiRenderUtil.drawRect(0, 0, width, height, 0xF00A0A0F);
        client.module.Module parentModule = setting.getParent();
        String title = parentModule != null ? "Select Blocks - " + parentModule.getName() : "Select Blocks";
        ClientFontRenderer.drawStringWithShadow(title, MARGIN, 8, ClickGUI.TEXT_NORMAL);
        drawDoneButton(mouseX, mouseY);
        drawSearchBar(mouseX, mouseY);
        String leftLabel = "Available - " + availableView.size();
        String rightLabel = "Selected - " + selectedView.size();
        ClientFontRenderer.drawStringWithShadow(leftLabel, leftX, MARGIN + HEADER_H + 2 + SEARCH_H + 4, ClickGUI.TEXT_MUTED);
        ClientFontRenderer.drawStringWithShadow(rightLabel, rightX, MARGIN + HEADER_H + 2 + SEARCH_H + 4, ClickGUI.getAccent());
        hoverId = null;
        drawColumn(mouseX, mouseY, leftX, leftScroll, availableView, true);
        drawColumn(mouseX, mouseY, rightX, rightScroll, selectedView, false);
        drawFooter(mouseX, mouseY);
        ClientGuiScale.restoreVanillaOrtho(mc);
    }

    private void drawDoneButton(int mouseX, int mouseY) {
        int x = width - MARGIN - DONE_W;
        int y = MARGIN + 1;
        boolean hover = mouseX >= x && mouseX <= x + DONE_W && mouseY >= y && mouseY <= y + DONE_H;
        GuiRenderUtil.drawRect(x, y, x + DONE_W, y + DONE_H, hover ? ClickGUI.BG_HOVER : ClickGUI.BG_PANEL);
        GuiRenderUtil.drawRect(x, y + DONE_H, x + DONE_W, y + DONE_H + 1, ClickGUI.ACCENT_RED_DIM);
        String text = "Done";
        ClientFontRenderer.drawCenteredStringWithShadow(text, x + DONE_W / 2, y + 2, hover ? ClickGUI.ACCENT_RED_BRIGHT : ClickGUI.TEXT_NORMAL);
    }

    private void drawSearchBar(int mouseX, int mouseY) {
        int x = MARGIN;
        int y = MARGIN + HEADER_H + 2;
        GuiRenderUtil.drawRect(x, y, x + width - MARGIN * 2, y + SEARCH_H, ClickGUI.BG_PANEL);
        if (searchFocused) {
            GuiRenderUtil.drawRect(x, y, x + 1, y + SEARCH_H, ClickGUI.getAccent());
        }
        String display = searchText.isEmpty() ? "Search blocks..." : searchText;
        int color = searchText.isEmpty() ? ClickGUI.TEXT_MUTED : ClickGUI.TEXT_NORMAL;
        String caret = (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0) ? "_" : "";
        ClientFontRenderer.drawStringWithShadow(display + caret, x + 4, y + 3, color);
    }

    private void drawColumn(int mouseX, int mouseY, int x, int scroll, List<Entry> entries, boolean left) {
        GuiRenderUtil.drawRect(x, listTop, x + colW, listBottom, ClickGUI.BG_SETTING);
        int n = entries.size();
        int rows = Math.min(visibleRows, n);
        for (int i = 0; i < rows; i++) {
            Entry e = entries.get(scroll + i);
            int ry = listTop + i * ROW_H;
            boolean zebra = (scroll + i) % 2 == 0;
            boolean hover = mouseX >= x && mouseX < x + colW && mouseY >= ry && mouseY < ry + ROW_H;
            if (hover) {
                hoverId = e.id;
            }
            int bg = hover ? ClickGUI.BG_HOVER : (zebra ? ClickGUI.BG_SETTING_DEEP : ClickGUI.BG_SETTING);
            GuiRenderUtil.drawRect(x, ry, x + colW, ry + ROW_H, bg);
            drawItemIcon(e, x + 2, ry + 1);
            String label = e.label;
            int maxW = colW - 24;
            while (label.length() > 1 && ClientFontRenderer.getStringWidth(label) > maxW) {
                label = label.substring(0, label.length() - 1);
            }
            ClientFontRenderer.drawStringWithShadow(label, x + 21, ry + 4, e.block == null ? ClickGUI.TEXT_MUTED : ClickGUI.TEXT_NORMAL);
            String glyph = left ? "+" : "-";
            ClientFontRenderer.drawRightAlignedString(glyph, x + colW - 3, ry + 4, hover ? ClickGUI.ACCENT_RED_BRIGHT : ClickGUI.TEXT_DIM);
        }
        if (n > visibleRows) {
            int barX = x + colW - 1;
            int trackH = listBottom - listTop;
            int thumbH = Math.max(6, trackH * visibleRows / n);
            int maxScroll = n - visibleRows;
            int thumbY = listTop + (maxScroll > 0 ? (trackH - thumbH) * scroll / maxScroll : 0);
            GuiRenderUtil.drawRect(barX, thumbY, barX + 1, thumbY + thumbH, ClickGUI.ACCENT_RED_DIM);
        }
    }

    private void drawItemIcon(Entry e, int x, int y) {
        if (e.block == null) {
            return;
        }
        Item item = Item.getItemFromBlock(e.block);
        if (item == null || item == Items.AIR) {
            return;
        }
        ItemStack stack = new ItemStack(item);
        if (stack.func_190926_b()) {
            return;
        }
        RenderHelper.enableGUIStandardItemLighting();
        try {
            mc.getRenderItem().renderItemAndEffectIntoGUI(stack, x, y);
        } catch (Exception ignored) {
        } finally {
            RenderHelper.disableStandardItemLighting();
        }
    }

    private void drawFooter(int mouseX, int mouseY) {
        int y = height - FOOTER_H - MARGIN + 2;
        if (hoverId != null) {
            String id = hoverId;
            int w = ClientFontRenderer.getStringWidth(id);
            ClientFontRenderer.drawStringWithShadow(id, (width - w) / 2, y, ClickGUI.TEXT_DIM);
        }
        drawSmallButton(mouseX, mouseY, leftX, y, "All", true);
        drawSmallButton(mouseX, mouseY, rightX, y, "None", false);
    }

    private void drawSmallButton(int mouseX, int mouseY, int x, int y, String text, boolean left) {
        boolean hover = mouseX >= x && mouseX <= x + BTN_W && mouseY >= y && mouseY <= y + BTN_H;
        GuiRenderUtil.drawRect(x, y, x + BTN_W, y + BTN_H, hover ? ClickGUI.BG_HOVER : ClickGUI.BG_PANEL);
        ClientFontRenderer.drawCenteredStringWithShadow(text, x + BTN_W / 2, y + 2, hover ? ClickGUI.ACCENT_RED_BRIGHT : ClickGUI.TEXT_MUTED);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (mouseButton != 0) {
            searchFocused = false;
            return;
        }
        int dx = width - MARGIN - DONE_W;
        int dy = MARGIN + 1;
        if (mouseX >= dx && mouseX <= dx + DONE_W && mouseY >= dy && mouseY <= dy + DONE_H) {
            close();
            return;
        }
        int sy = MARGIN + HEADER_H + 2;
        if (mouseY >= sy && mouseY <= sy + SEARCH_H) {
            searchFocused = true;
            return;
        }
        searchFocused = false;
        int fy = height - FOOTER_H - MARGIN + 2;
        if (mouseY >= fy && mouseY <= fy + BTN_H) {
            if (mouseX >= leftX && mouseX <= leftX + BTN_W) {
                addAllFiltered();
                return;
            }
            if (mouseX >= rightX && mouseX <= rightX + BTN_W) {
                removeAllFiltered();
                return;
            }
        }
        if (mouseX >= leftX && mouseX < leftX + colW && mouseY >= listTop && mouseY < listBottom) {
            int idx = leftScroll + (mouseY - listTop) / ROW_H;
            if (idx >= 0 && idx < availableView.size()) {
                setting.toggle(availableView.get(idx).id);
                markDirty();
            }
            return;
        }
        if (mouseX >= rightX && mouseX < rightX + colW && mouseY >= listTop && mouseY < listBottom) {
            int idx = rightScroll + (mouseY - listTop) / ROW_H;
            if (idx >= 0 && idx < selectedView.size()) {
                setting.toggle(selectedView.get(idx).id);
                markDirty();
            }
            return;
        }
    }

    private void addAllFiltered() {
        LinkedHashSet<String> set = new LinkedHashSet<String>();
        String[] sel = setting.getValue();
        if (sel != null) {
            set.addAll(Arrays.asList(sel));
        }
        for (Entry e : availableView) {
            set.add(e.id);
        }
        setting.setValue(set.toArray(new String[0]));
        markDirty();
    }

    private void removeAllFiltered() {
        String[] sel = setting.getValue();
        if (sel == null || sel.length == 0) {
            return;
        }
        Set<String> remove = new HashSet<String>();
        for (Entry e : selectedView) {
            remove.add(e.id);
        }
        List<String> out = new ArrayList<String>();
        for (String id : sel) {
            if (!remove.contains(id)) {
                out.add(id);
            }
        }
        setting.setValue(out.toArray(new String[0]));
        markDirty();
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d == 0) {
            return;
        }
        int mx = Mouse.getEventX() * this.width / this.mc.displayWidth;
        int my = this.height - Mouse.getEventY() * this.height / this.mc.displayHeight - 1;
        int dir = d > 0 ? -1 : 1;
        if (mx >= leftX && mx < leftX + colW && my >= listTop && my < listBottom) {
            leftScroll = clampScroll(leftScroll + dir, availableView.size());
        } else if (mx >= rightX && mx < rightX + colW && my >= listTop && my < listBottom) {
            rightScroll = clampScroll(rightScroll + dir, selectedView.size());
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == KEY_ESC) {
            if (searchFocused && !searchText.isEmpty()) {
                searchText = "";
                markDirty();
                return;
            }
            close();
            return;
        }
        if (!searchFocused) {
            return;
        }
        if (keyCode == KEY_BACKSPACE) {
            if (searchText.length() > 0) {
                searchText = searchText.substring(0, searchText.length() - 1);
                markDirty();
            }
            return;
        }
        if (typedChar >= ' ') {
            searchText += typedChar;
            markDirty();
        }
    }

    private void close() {
        mc.displayGuiScreen(new client.gui.salt.SaltGui());
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
