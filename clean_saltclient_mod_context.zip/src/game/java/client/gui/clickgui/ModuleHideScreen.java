package client.gui.clickgui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import client.module.Category;
import client.module.Module;
import client.module.ModuleManager;
import client.utils.render.ClientFontRenderer;
import net.lax1dude.eaglercraft.Mouse;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;

public class ModuleHideScreen extends GuiScreen {

    private final Minecraft mc = Minecraft.getMinecraft();

    private static final int MARGIN = 6;

    private static final int HEADER_H = 16;

    private static final int SEARCH_H = 14;

    private static final int ROW_H = 16;

    private static final int FOOTER_H = 14;

    private static final int DONE_W = 42;

    private static final int DONE_H = 12;

    private static final int BTN_W = 34;

    private static final int BTN_H = 11;

    private static final int KEY_BACKSPACE = 14;

    private static final int KEY_ESC = 1;

    private String searchText = "";

    private boolean searchFocused = true;

    private int scrollOffset = 0;

    private List<Module> filteredModules = new ArrayList<Module>();

    private boolean viewDirty = true;

    private Integer hoverIndex = null;

    private int listTop;

    private int listBottom;

    private int visibleRows;

    private int listX;

    private int listWidth;

    public ModuleHideScreen() {
    }

    @Override
    public void initGui() {
        ClientGuiScale.applyDims(this, mc);
        searchText = "";
        searchFocused = true;
        scrollOffset = 0;
        viewDirty = true;
        listX = MARGIN;
        listWidth = this.width - MARGIN * 2;
        int top = MARGIN + HEADER_H + 2 + SEARCH_H + 2;
        listTop = top;
        listBottom = this.height - FOOTER_H - MARGIN;
        visibleRows = Math.max(1, (listBottom - listTop) / ROW_H);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        ClientGuiScale.setupOrtho(mc);
        mouseX = Mouse.getX() * this.width / this.mc.displayWidth;
        mouseY = this.height - Mouse.getY() * this.height / this.mc.displayHeight - 1;
        if (viewDirty)
            rebuildViews();
        GuiRenderUtil.drawRect(0, 0, this.width, this.height, 0xF00A0A0F);
        String title = "Module Visibility - Click to toggle";
        ClientFontRenderer.drawStringWithShadow(title, MARGIN, 8, ClickGUI.TEXT_NORMAL);
        drawDoneButton(mouseX, mouseY);
        drawSearchBar(mouseX, mouseY);
        hoverIndex = null;
        drawList(mouseX, mouseY);
        drawFooter(mouseX, mouseY);
        ClientGuiScale.restoreVanillaOrtho(mc);
    }

    private void drawDoneButton(int mouseX, int mouseY) {
        int dx = this.width - MARGIN - DONE_W;
        int dy = MARGIN + 1;
        boolean hover = mouseX >= dx && mouseX <= dx + DONE_W && mouseY >= dy && mouseY <= dy + DONE_H;
        GuiRenderUtil.drawRect(dx, dy, dx + DONE_W, dy + DONE_H, hover ? 0xFF1B4272 : 0xFF12294A);
        GuiRenderUtil.drawRect(dx, dy, dx + DONE_W, dy + 1, ClickGUI.BORDER_RED);
        String label = "Done";
        int labelW = ClientFontRenderer.getStringWidth(label);
        ClientFontRenderer.drawStringWithShadow(label, dx + (DONE_W - labelW) / 2, dy + 2, hover ? 0xFFFFFFFF : 0xFFBFE3F7);
    }

    private void drawSearchBar(int mouseX, int mouseY) {
        int sx = MARGIN;
        int sy = MARGIN + HEADER_H + 2;
        int sw = this.width - MARGIN * 2 - DONE_W - 6;
        boolean hover = mouseX >= sx && mouseX <= sx + sw && mouseY >= sy && mouseY <= sy + SEARCH_H;
        GuiRenderUtil.drawRect(sx, sy, sx + sw, sy + SEARCH_H, searchFocused ? 0xFF1B4272 : (hover ? 0xFF173A5C : 0xFF0B1A2E));
        GuiRenderUtil.drawRect(sx, sy, sx + sw, sy + 1, ClickGUI.BORDER_RED);
        String display = searchFocused ? searchText + "_" : searchText;
        if (display.isEmpty() && !searchFocused) {
            ClientFontRenderer.drawStringWithShadow("Search modules...", sx + 4, sy + 3, ClickGUI.TEXT_MUTED);
        } else {
            ClientFontRenderer.drawStringWithShadow(display, sx + 4, sy + 3, ClickGUI.TEXT_NORMAL);
        }
    }

    private void drawList(int mouseX, int mouseY) {
        int total = filteredModules.size();
        int maxScroll = Math.max(0, total - visibleRows);
        if (scrollOffset > maxScroll)
            scrollOffset = maxScroll;
        if (scrollOffset < 0)
            scrollOffset = 0;
        client.utils.render.StencilClipUtil.pushClip(listX, listTop, listX + listWidth, listBottom);
        for (int i = 0; i < visibleRows; i++) {
            int idx = scrollOffset + i;
            if (idx >= total)
                break;
            Module mod = filteredModules.get(idx);
            int rowY = listTop + i * ROW_H;
            boolean hover = mouseX >= listX && mouseX <= listX + listWidth && mouseY >= rowY && mouseY <= rowY + ROW_H;
            if (hover)
                hoverIndex = idx;
            int bg = (i % 2 == 0) ? 0xFF091526 : 0xFF0B1A2E;
            if (hover)
                bg = 0xFF12294A;
            GuiRenderUtil.drawRect(listX, rowY, listX + listWidth, rowY + ROW_H, bg);
            int cbX = listX + 4;
            int cbY = rowY + (ROW_H - 10) / 2;
            int cbSize = 10;
            boolean hidden = mod.isHiddenInGUI();
            GuiRenderUtil.drawRect(cbX, cbY, cbX + cbSize, cbY + cbSize, hidden ? 0xFF091526 : ClickGUI.getAccent());
            GuiRenderUtil.drawRect(cbX, cbY, cbX + cbSize, cbY + 1, ClickGUI.BORDER_DARK);
            GuiRenderUtil.drawRect(cbX, cbY + cbSize - 1, cbX + cbSize, cbY + cbSize, ClickGUI.BORDER_DARK);
            GuiRenderUtil.drawRect(cbX, cbY, cbX + 1, cbY + cbSize, ClickGUI.BORDER_DARK);
            GuiRenderUtil.drawRect(cbX + cbSize - 1, cbY, cbX + cbSize, cbY + cbSize, ClickGUI.BORDER_DARK);
            if (!hidden) {
                ClientFontRenderer.drawStringWithShadow("x", cbX + 2, cbY + 1, 0xFFFFFFFF);
            }
            String catName = mod.getCategory().name();
            if (catName.length() > 1) {
                catName = catName.charAt(0) + catName.substring(1).toLowerCase();
            }
            int catColor = ClickGUI.TEXT_MUTED;
            int catW = ClientFontRenderer.getStringWidth(catName);
            ClientFontRenderer.drawStringWithShadow(catName, listX + listWidth - catW - 6, rowY + 4, catColor);
            int nameColor = hidden ? ClickGUI.TEXT_MUTED : ClickGUI.TEXT_NORMAL;
            String name = mod.getName();
            int maxNameW = listWidth - 20 - catW - 12;
            if (ClientFontRenderer.getStringWidth(name) > maxNameW) {
                while (name.length() > 1 && ClientFontRenderer.getStringWidth(name + "..") > maxNameW) {
                    name = name.substring(0, name.length() - 1);
                }
                name = name + "..";
            }
            ClientFontRenderer.drawStringWithShadow(name, cbX + cbSize + 6, rowY + 4, nameColor);
        }
        client.utils.render.StencilClipUtil.popClip();
        if (total > visibleRows) {
            int scrollBarH = Math.max(14, visibleRows * visibleRows / total);
            int maxScroll2 = total - visibleRows;
            int scrollBarY = listTop + (visibleRows - scrollBarH) * scrollOffset / maxScroll2;
            GuiRenderUtil.drawRect(listX + listWidth - 3, scrollBarY, listX + listWidth - 1, scrollBarY + scrollBarH, 0x649BE7FF);
        }
    }

    private void drawFooter(int mouseX, int mouseY) {
        int fy = this.height - FOOTER_H - MARGIN + 2;
        int visibleCount = 0;
        int hiddenCount = 0;
        for (Module m : ModuleManager.getModules()) {
            if (m.isHiddenInGUI())
                hiddenCount++;
            else
                visibleCount++;
        }
        String info = "Visible: " + visibleCount + "  Hidden: " + hiddenCount;
        ClientFontRenderer.drawStringWithShadow(info, MARGIN, fy + 1, ClickGUI.TEXT_MUTED);
        int btnX = this.width - MARGIN - BTN_W * 2 - 4;
        boolean hoverShow = mouseX >= btnX && mouseX <= btnX + BTN_W && mouseY >= fy && mouseY <= fy + BTN_H;
        GuiRenderUtil.drawRect(btnX, fy, btnX + BTN_W, fy + BTN_H, hoverShow ? 0xFF1B4272 : 0xFF12294A);
        GuiRenderUtil.drawRect(btnX, fy, btnX + BTN_W, fy + 1, ClickGUI.BORDER_RED);
        String showLabel = "Show All";
        int showLabelW = ClientFontRenderer.getStringWidth(showLabel);
        ClientFontRenderer.drawStringWithShadow(showLabel, btnX + (BTN_W - showLabelW) / 2, fy + 2, hoverShow ? 0xFFFFFFFF : 0xFFBFE3F7);
        int btnX2 = btnX + BTN_W + 4;
        boolean hoverHide = mouseX >= btnX2 && mouseX <= btnX2 + BTN_W && mouseY >= fy && mouseY <= fy + BTN_H;
        GuiRenderUtil.drawRect(btnX2, fy, btnX2 + BTN_W, fy + BTN_H, hoverHide ? 0xFF1B4272 : 0xFF12294A);
        GuiRenderUtil.drawRect(btnX2, fy, btnX2 + BTN_W, fy + 1, ClickGUI.BORDER_RED);
        String hideLabel = "Hide All";
        int hideLabelW = ClientFontRenderer.getStringWidth(hideLabel);
        ClientFontRenderer.drawStringWithShadow(hideLabel, btnX2 + (BTN_W - hideLabelW) / 2, fy + 2, hoverHide ? 0xFFFFFFFF : 0xFFBFE3F7);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (mouseButton != 0) {
            searchFocused = false;
            return;
        }
        int dx = this.width - MARGIN - DONE_W;
        int dy = MARGIN + 1;
        if (mouseX >= dx && mouseX <= dx + DONE_W && mouseY >= dy && mouseY <= dy + DONE_H) {
            close();
            return;
        }
        int sy = MARGIN + HEADER_H + 2;
        int sw = this.width - MARGIN * 2 - DONE_W - 6;
        if (mouseX >= MARGIN && mouseX <= MARGIN + sw && mouseY >= sy && mouseY <= sy + SEARCH_H) {
            searchFocused = true;
            return;
        }
        searchFocused = false;
        int fy = this.height - FOOTER_H - MARGIN + 2;
        if (mouseY >= fy && mouseY <= fy + BTN_H) {
            int btnX = this.width - MARGIN - BTN_W * 2 - 4;
            if (mouseX >= btnX && mouseX <= btnX + BTN_W) {
                for (Module m : ModuleManager.getModules()) {
                    m.setHiddenInGUI(false);
                }
                viewDirty = true;
                client.Client.INSTANCE.saveConfig();
                return;
            }
            int btnX2 = btnX + BTN_W + 4;
            if (mouseX >= btnX2 && mouseX <= btnX2 + BTN_W) {
                for (Module m : filteredModules) {
                    m.setHiddenInGUI(true);
                }
                viewDirty = true;
                client.Client.INSTANCE.saveConfig();
                return;
            }
        }
        if (mouseX >= listX && mouseX <= listX + listWidth && mouseY >= listTop && mouseY <= listBottom) {
            int idx = scrollOffset + (mouseY - listTop) / ROW_H;
            if (idx >= 0 && idx < filteredModules.size()) {
                Module mod = filteredModules.get(idx);
                mod.setHiddenInGUI(!mod.isHiddenInGUI());
                viewDirty = true;
                client.Client.INSTANCE.saveConfig();
            }
            return;
        }
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int wheel = Mouse.getEventDWheel();
        if (wheel != 0) {
            int dir = wheel > 0 ? -1 : 1;
            scrollOffset += dir * 3;
            int total = filteredModules.size();
            int maxScroll = Math.max(0, total - visibleRows);
            if (scrollOffset > maxScroll)
                scrollOffset = maxScroll;
            if (scrollOffset < 0)
                scrollOffset = 0;
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == KEY_ESC) {
            close();
            return;
        }
        if (searchFocused) {
            if (keyCode == KEY_BACKSPACE) {
                if (searchText.length() > 0) {
                    searchText = searchText.substring(0, searchText.length() - 1);
                    viewDirty = true;
                }
                return;
            }
            if (typedChar >= 32 && typedChar < 127) {
                searchText += typedChar;
                viewDirty = true;
            }
        }
    }

    private void rebuildViews() {
        filteredModules.clear();
        String filter = searchText.toLowerCase();
        for (Category cat : Category.values()) {
            for (Module mod : ModuleManager.getModules()) {
                if (mod.getCategory() != cat)
                    continue;
                if (!filter.isEmpty()) {
                    String name = mod.getName().toLowerCase();
                    String desc = mod.getDescription() != null ? mod.getDescription().toLowerCase() : "";
                    if (!name.contains(filter) && !desc.contains(filter))
                        continue;
                }
                filteredModules.add(mod);
            }
        }
        viewDirty = false;
    }

    private void close() {
        mc.displayGuiScreen(new client.gui.salt.SaltGui());
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
