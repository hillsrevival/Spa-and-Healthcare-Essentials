package client.gui;

import java.util.List;
import client.utils.render.ClientFontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.Minecraft;
import net.lax1dude.eaglercraft.EagRuntime;
import net.lax1dude.eaglercraft.internal.FileChooserResult;
import net.minecraft.schematic.SchematicManager;
import net.minecraft.schematic.SchematicData;
import net.minecraft.schematic.SchematicRenderer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class GuiSchematicManager extends GuiScreen {

    private static final Logger LOGGER = LogManager.getLogger();

    private static final int SCHEMATIC_BUTTON_ID_BASE = 100;

    private GuiScreen parentScreen;

    private GuiButton uploadButton;

    private GuiButton confirmButton;

    private GuiButton cancelButton;

    private String uploadedFileName = null;

    private byte[] uploadedFileData = null;

    private String statusMessage = "";

    private List<SchematicData> loadedSchematicsSnapshot;

    private int listTop;

    private static final int LIST_ENTRY_HEIGHT = 20;

    private static final int LIST_ENTRY_SPACING = 2;

    public GuiSchematicManager(GuiScreen parentScreen) {
        this.parentScreen = parentScreen;
    }

    @Override
    public void initGui() {
        ScaledResolution sr = new ScaledResolution(this.mc);
        int width = sr.getScaledWidth();
        int height = sr.getScaledHeight();
        this.buttonList.clear();
        this.loadedSchematicsSnapshot = SchematicManager.getLoadedSchematics();
        this.listTop = height / 2 - 100 + 24;
        for (int i = 0; i < this.loadedSchematicsSnapshot.size(); i++) {
            SchematicData schematic = this.loadedSchematicsSnapshot.get(i);
            String label = schematic.getName() + " (" + schematic.getWidth() + "x" + schematic.getHeight() + "x" + schematic.getLength() + ")";
            if (schematic == SchematicManager.getActiveSchematic()) {
                label = "> " + label + " <";
            }
            int entryY = this.listTop + i * (LIST_ENTRY_HEIGHT + LIST_ENTRY_SPACING);
            GuiButton entryButton = new GuiButton(SCHEMATIC_BUTTON_ID_BASE + i, width / 2 - 100, entryY, 200, LIST_ENTRY_HEIGHT, label);
            this.buttonList.add(entryButton);
        }
        int belowListY = this.listTop + this.loadedSchematicsSnapshot.size() * (LIST_ENTRY_HEIGHT + LIST_ENTRY_SPACING) + 10;
        this.uploadButton = new GuiButton(0, width / 2 - 100, belowListY, 200, 20, "Upload Schematic File");
        this.buttonList.add(this.uploadButton);
        this.confirmButton = new GuiButton(1, width / 2 - 100, belowListY + 24, 200, 20, "Load Schematic");
        this.confirmButton.enabled = (this.uploadedFileData != null);
        this.buttonList.add(this.confirmButton);
        this.cancelButton = new GuiButton(2, width / 2 - 100, belowListY + 54, 200, 20, "Close");
        this.buttonList.add(this.cancelButton);
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        if (button.id == 0) {
            EagRuntime.displayFileChooser("application/octet-stream", "schematic");
            this.statusMessage = "Choose a file...";
        } else if (button.id == 1) {
            if (this.uploadedFileData != null) {
                loadSchematic(this.uploadedFileName, this.uploadedFileData);
                this.uploadedFileData = null;
                this.uploadedFileName = null;
                this.initGui();
            }
        } else if (button.id == 2) {
            this.mc.displayGuiScreen(this.parentScreen);
        } else if (button.id >= SCHEMATIC_BUTTON_ID_BASE) {
            int index = button.id - SCHEMATIC_BUTTON_ID_BASE;
            selectSchematic(index);
        }
    }

    private void selectSchematic(int index) {
        if (index < 0 || index >= this.loadedSchematicsSnapshot.size()) {
            return;
        }
        SchematicData schematic = this.loadedSchematicsSnapshot.get(index);
        SchematicManager.setActiveSchematic(schematic);
        if (this.mc.player != null) {
            SchematicRenderer.setRenderPosition((int) Math.floor(this.mc.player.posX), (int) Math.floor(this.mc.player.posY), (int) Math.floor(this.mc.player.posZ));
            this.statusMessage = "Active: " + schematic.getName() + " — placed at your position";
        } else {
            this.statusMessage = "Active: " + schematic.getName() + " — will position once in-world";
        }
        LOGGER.info("Selected active schematic: {}", schematic.getName());
        this.initGui();
    }

    @Override
    public void updateScreen() {
        if (EagRuntime.fileChooserHasResult()) {
            FileChooserResult result = EagRuntime.getFileChooserResult();
            if (result != null) {
                this.uploadedFileName = result.fileName;
                this.uploadedFileData = result.fileData;
                this.statusMessage = "Loaded: " + this.uploadedFileName + " (" + result.fileData.length + " bytes)";
                this.confirmButton.enabled = true;
            } else {
                this.statusMessage = "File upload cancelled.";
            }
            EagRuntime.clearFileChooserResult();
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        ScaledResolution sr = new ScaledResolution(this.mc);
        int width = sr.getScaledWidth();
        int height = sr.getScaledHeight();
        ClientFontRenderer.drawCenteredStringWithShadow("Schematic Manager", width / 2, height / 2 - 100, 0xFFFFFF);
        if (this.loadedSchematicsSnapshot != null && this.loadedSchematicsSnapshot.isEmpty()) {
            ClientFontRenderer.drawCenteredStringWithShadow("No schematics loaded yet — upload one below.", width / 2, this.listTop, 0x888888);
        }
        if (this.uploadedFileName != null) {
            int belowListY = this.listTop + this.loadedSchematicsSnapshot.size() * (LIST_ENTRY_HEIGHT + LIST_ENTRY_SPACING) - 12;
            ClientFontRenderer.drawCenteredStringWithShadow("File: " + this.uploadedFileName, width / 2, belowListY, 0x00FF00);
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
        if (!this.statusMessage.isEmpty()) {
            ClientFontRenderer.drawCenteredStringWithShadow(this.statusMessage, width / 2, height - 20, 0xAAAAAA);
        }
    }

    private void loadSchematic(String fileName, byte[] fileData) {
        try {
            String schematicName = extractNameFromPath(fileName);
            SchematicData schematic = SchematicManager.loadSchematic(fileData, schematicName);
            if (schematic != null) {
                if (this.mc.player != null) {
                    SchematicRenderer.setRenderPosition((int) Math.floor(this.mc.player.posX), (int) Math.floor(this.mc.player.posY), (int) Math.floor(this.mc.player.posZ));
                }
                statusMessage = "Schematic loaded: " + schematicName + " (" + schematic.getWidth() + "x" + schematic.getHeight() + "x" + schematic.getLength() + ")";
                LOGGER.info("Successfully loaded schematic: {} with dimensions {}x{}x{}", schematicName, schematic.getWidth(), schematic.getHeight(), schematic.getLength());
            } else {
                statusMessage = "Failed to parse schematic file";
                LOGGER.warn("Schematic parsing returned null for: {}", fileName);
            }
        } catch (Exception e) {
            statusMessage = "Error loading schematic: " + e.getMessage();
            LOGGER.error("Exception while loading schematic: {}", fileName, e);
        }
    }

    private String extractNameFromPath(String path) {
        if (path == null)
            return "Unnamed";
        int lastSlash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
        String name = lastSlash >= 0 ? path.substring(lastSlash + 1) : path;
        int lastDot = name.lastIndexOf('.');
        return lastDot >= 0 ? name.substring(0, lastDot) : name;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
