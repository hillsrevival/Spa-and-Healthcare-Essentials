package client.gui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import client.Client;
import client.gui.clickgui.ClickGUI;
import client.module.Module;
import client.module.ModuleManager;
import client.utils.render.HudElement;
import client.utils.render.ClientFontRenderer;
import client.utils.render.GuiBlurUtil;
import net.lax1dude.eaglercraft.Mouse;
import net.lax1dude.eaglercraft.Keyboard;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;

public class HudEditorScreen extends GuiScreen {

    private final Minecraft mc = Minecraft.getMinecraft();

    private static final int BG_PANEL = 0xCC0E0E12;

    private static final int BORDER = 0xFF1E1E2A;

    private static final int TEXT = 0xFFCCCCCC;

    private static final int TEXT_DIM = 0xFF666666;

    private static final int BTN_DONE = 0xFF2A2A35;

    private static final int BTN_RESET = 0xFF1A3A5A;

    private static final int BTN_HOVER_DONE = 0xFF3A3A48;

    private static final int BTN_HOVER_RESET = 0xFF2A4A6A;

    private static final int INSTRUCTION_HEIGHT = 22;

    private static final int BUTTON_HEIGHT = 16;

    private static final int BUTTON_GAP = 6;

    private static final int BUTTON_WIDTH = 90;

    private HudElement dragging = null;

    private int dragOffX = 0;

    private int dragOffY = 0;

    private boolean wasMouseDown = false;

    private static final List<HudElement> elements = new ArrayList<>();

    @Override
    public void initGui() {
        if (GuiBlurUtil.isEnabled()) {
            GuiBlurUtil.captureScreen();
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (GuiBlurUtil.isEnabled()) {
            GuiBlurUtil.renderBlur(1.0f);
        } else {
            drawDefaultBackground();
        }
        ScaledResolution sr = new ScaledResolution(mc);
        int sw = sr.getScaledWidth();
        int sh = sr.getScaledHeight();
        elements.clear();
        for (Module m : ModuleManager.getModules()) {
            if (m.isToggled() && m.getHudElement() != null) {
                elements.add(m.getHudElement());
            }
        }
        String line1 = "Click and drag modules to reposition them";
        String line2 = "You may have to retoggle the module after changing the position";
        int boxW = Math.max(ClientFontRenderer.getStringWidth(line1), ClientFontRenderer.getStringWidth(line2)) + 20;
        int boxX = (sw - boxW) / 2;
        int boxY = 8;
        Gui.drawRect(boxX, boxY, boxX + boxW, boxY + INSTRUCTION_HEIGHT, 0xCC0A2A2A);
        int accent = ClickGUI.getAccent();
        Gui.drawRect(boxX, boxY, boxX + boxW, boxY + 1, accent);
        Gui.drawRect(boxX, boxY, boxX + 1, boxY + INSTRUCTION_HEIGHT, accent);
        Gui.drawRect(boxX + boxW - 1, boxY, boxX + boxW, boxY + INSTRUCTION_HEIGHT, accent);
        ClientFontRenderer.drawStringWithShadow(line1, boxX + 10, boxY + 3, 0xFFFFFFFF);
        ClientFontRenderer.drawStringWithShadow(line2, boxX + 10, boxY + 12, TEXT_DIM);
        int gridSpacing = 20;
        for (int gx = gridSpacing; gx < sw; gx += gridSpacing) {
            for (int gy = gridSpacing; gy < sh; gy += gridSpacing) {
                Gui.drawRect(gx, gy, gx + 1, gy + 1, 0x15151515);
            }
        }
        for (HudElement he : elements) {
            int x = he.getX();
            int y = he.getY();
            boolean isDragging = (he == dragging);
            int ew = Math.max(20, getModuleWidth(he));
            int eh = Math.max(20, getModuleHeight(he));
            if (isDragging) {
                Gui.drawRect(x - 2, y - 2, x + ew + 2, y + eh + 2, 0x20FF2222);
                Gui.drawRect(x - 2, y - 2, x + ew + 2, y - 1, accent);
                Gui.drawRect(x - 2, y + eh + 1, x + ew + 2, y + eh + 2, accent);
                Gui.drawRect(x - 2, y - 2, x - 1, y + eh + 2, accent);
                Gui.drawRect(x + ew + 1, y - 2, x + ew + 2, y + eh + 2, accent);
                Gui.drawRect(x - 3, y - 3, x + 1, y + 1, 0xFFFFFFFF);
                Gui.drawRect(x + ew - 1, y - 3, x + ew + 3, y + 1, 0xFFFFFFFF);
                Gui.drawRect(x - 3, y + eh - 1, x + 1, y + eh + 3, 0xFFFFFFFF);
                Gui.drawRect(x + ew - 1, y + eh - 1, x + ew + 3, y + eh + 3, 0xFFFFFFFF);
            } else {
                Gui.drawRect(x - 1, y - 1, x + ew + 1, y, 0x40FFFFFF);
                Gui.drawRect(x - 1, y + eh, x + ew + 1, y + eh + 1, 0x40FFFFFF);
                Gui.drawRect(x - 1, y, x, y + eh, 0x40FFFFFF);
                Gui.drawRect(x + ew, y, x + ew + 1, y + eh, 0x40FFFFFF);
            }
        }
        int btnY = sh - BUTTON_HEIGHT - 10;
        int totalBtnW = BUTTON_WIDTH * 2 + BUTTON_GAP;
        int btnStartX = (sw - totalBtnW) / 2;
        int doneX = btnStartX;
        boolean doneHover = mouseX >= doneX && mouseX <= doneX + BUTTON_WIDTH && mouseY >= btnY && mouseY <= btnY + BUTTON_HEIGHT;
        Gui.drawRect(doneX, btnY, doneX + BUTTON_WIDTH, btnY + BUTTON_HEIGHT, doneHover ? BTN_HOVER_DONE : BTN_DONE);
        Gui.drawRect(doneX, btnY, doneX + BUTTON_WIDTH, btnY + 1, BORDER);
        String doneText = "Done";
        int doneTextW = ClientFontRenderer.getStringWidth(doneText);
        ClientFontRenderer.drawStringWithShadow(doneText, doneX + (BUTTON_WIDTH - doneTextW) / 2, btnY + 4, TEXT);
        int resetX = btnStartX + BUTTON_WIDTH + BUTTON_GAP;
        boolean resetHover = mouseX >= resetX && mouseX <= resetX + BUTTON_WIDTH && mouseY >= btnY && mouseY <= btnY + BUTTON_HEIGHT;
        Gui.drawRect(resetX, btnY, resetX + BUTTON_WIDTH, btnY + BUTTON_HEIGHT, resetHover ? BTN_HOVER_RESET : BTN_RESET);
        Gui.drawRect(resetX, btnY, resetX + BUTTON_WIDTH, btnY + 1, accent);
        String resetText = "Reset Positions";
        int resetTextW = ClientFontRenderer.getStringWidth(resetText);
        ClientFontRenderer.drawStringWithShadow(resetText, resetX + (BUTTON_WIDTH - resetTextW) / 2, btnY + 4, accent);
        if (dragging != null && wasMouseDown && Mouse.isButtonDown(0)) {
            int newX = Math.max(0, Math.min(mouseX - dragOffX, sw - 10));
            int newY = Math.max(0, Math.min(mouseY - dragOffY, sh - 10));
            dragging.setPosition(newX, newY);
        }
        if (wasMouseDown && !Mouse.isButtonDown(0)) {
            wasMouseDown = false;
            if (dragging != null) {
                dragging = null;
                Client.INSTANCE.saveConfig();
            }
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        ScaledResolution sr = new ScaledResolution(mc);
        int sw = sr.getScaledWidth();
        int sh = sr.getScaledHeight();
        int btnY = sh - BUTTON_HEIGHT - 10;
        int totalBtnW = BUTTON_WIDTH * 2 + BUTTON_GAP;
        int btnStartX = (sw - totalBtnW) / 2;
        int doneX = btnStartX;
        if (mouseX >= doneX && mouseX <= doneX + BUTTON_WIDTH && mouseY >= btnY && mouseY <= btnY + BUTTON_HEIGHT && mouseButton == 0) {
            closeEditor();
            return;
        }
        int resetX = btnStartX + BUTTON_WIDTH + BUTTON_GAP;
        if (mouseX >= resetX && mouseX <= resetX + BUTTON_WIDTH && mouseY >= btnY && mouseY <= btnY + BUTTON_HEIGHT && mouseButton == 0) {
            for (HudElement he : elements) {
                he.resetToDefault();
            }
            Client.INSTANCE.saveConfig();
            return;
        }
        if (mouseButton == 0) {
            for (int i = elements.size() - 1; i >= 0; i--) {
                HudElement he = elements.get(i);
                int ex = he.getX();
                int ey = he.getY();
                int ew = Math.max(20, getModuleWidth(he));
                int eh = Math.max(20, getModuleHeight(he));
                if (mouseX >= ex && mouseX <= ex + ew && mouseY >= ey && mouseY <= ey + eh) {
                    dragging = he;
                    dragOffX = mouseX - ex;
                    dragOffY = mouseY - ey;
                    wasMouseDown = true;
                    return;
                }
            }
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == 1) {
            closeEditor();
        }
    }

    @Override
    public void onGuiClosed() {
        HudElement.setHudEditorOpen(false);
    }

    private void closeEditor() {
        HudElement.setHudEditorOpen(false);
        mc.displayGuiScreen(null);
    }

    private int getModuleWidth(HudElement he) {
        if (he == null || he.getModule() == null)
            return 60;
        Module m = he.getModule();
        String name = m.getName();
        if (name.equals("Keystrokes"))
            return 120;
        if (name.equals("CpsDisplay"))
            return 80;
        if (name.equals("InventoryHud"))
            return 176;
        if (name.equals("Durability"))
            return 100;
        if (name.equals("DeathCords"))
            return 80;
        if (name.equals("ActiveModuleHud"))
            return 80;
        return ClientFontRenderer.getStringWidth(name) + 20;
    }

    private int getModuleHeight(HudElement he) {
        if (he == null || he.getModule() == null)
            return 20;
        String name = he.getModule().getName();
        if (name.equals("Keystrokes"))
            return 98;
        if (name.equals("CpsDisplay"))
            return 24;
        if (name.equals("InventoryHud"))
            return 66;
        if (name.equals("Durability"))
            return 20;
        if (name.equals("DeathCords"))
            return 20;
        if (name.equals("ActiveModuleHud"))
            return 40;
        return 20;
    }
}
