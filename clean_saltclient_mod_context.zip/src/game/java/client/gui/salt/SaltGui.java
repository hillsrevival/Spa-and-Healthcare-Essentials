package client.gui.salt;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import client.Client;
import client.gui.clickgui.BlockListScreen;
import client.gui.clickgui.ClickGUI;
import client.module.BindSetting;
import client.module.BlockListSetting;
import client.module.BooleanSetting;
import client.module.Category;
import client.module.ColorSetting;
import client.module.ModeSetting;
import client.module.Module;
import client.module.ModuleManager;
import client.module.NumberSetting;
import client.module.Setting;
import client.module.StringSetting;
import client.utils.render.ClientFontRenderer;
import client.utils.render.CrystalTheme;
import client.utils.render.HudElement;
import client.utils.render.RenderUtils;
import client.utils.render.StencilClipUtil;
import net.lax1dude.eaglercraft.Keyboard;
import net.lax1dude.eaglercraft.Mouse;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;

/**
 * SaltClient module GUI. Two layouts: HUB (one central window: categories, modules, settings)
 * and PANELS (floating draggable category windows plus a floating settings window).
 */
public class SaltGui extends GuiScreen {

    // row types for the settings view
    private static final int T_TOGGLE = 0, T_BIND = 1, T_BOOL = 2, T_NUM = 3, T_MODE = 4, T_COLOR = 5, T_STR = 6, T_BINDSET = 7, T_BLOCK = 8, T_MODCOLOR = 9, T_HUD = 10;

    private static boolean layoutLoaded = false;
    private static int hubX = -1, hubY = -1;
    private static int selCat = 0;
    private static Module selected = null;
    private static int setWinX = -1, setWinY = 12;
    private static final Map<Integer, int[]> panelPos = new HashMap<Integer, int[]>();

    private final Category[] cats = Category.values();
    private final Map<Module, Float> switchAnim = new HashMap<Module, Float>();
    private final Map<Integer, Float> listScroll = new HashMap<Integer, Float>();
    private final Map<Integer, Float> hoverAnim = new HashMap<Integer, Float>();

    private String search = "";
    private boolean searchFocus = false;
    private float settingsScroll = 0.0f;
    private long openTime = 0L;

    private int dragWin = -2;
    private int dragOffX = 0, dragOffY = 0;

    private Setting<?> activeSetting = null;
    private int activeX = 0, activeW = 0;
    private Setting<?> editing = null;
    private String editBuf = "";
    private boolean listeningModuleKey = false;
    private BindSetting listeningBind = null;

    // hub geometry (recomputed each frame)
    private int hx, hy, hw, hh;

    public SaltGui() {
        if (!layoutLoaded) {
            layoutLoaded = true;
            try {
                ClickGUI.loadGuiLayout();
            } catch (Throwable ignored) {
            }
        }
    }

    public boolean doesGuiPauseGame() {
        return false;
    }

    private static boolean panelsMode() {
        return ClickGUI.getGuiLayout() == 2;
    }

    private void toggleLayout() {
        ClickGUI.setGuiLayout(panelsMode() ? 0 : 2);
    }

    public void initGui() {
        openTime = System.currentTimeMillis();
        if (selected == null) {
            for (Module m : ModuleManager.getModules()) {
                boolean inSelection = selCat == -1 ? m.isFavorite() : m.getCategory() == cats[Math.max(0, Math.min(selCat, cats.length - 1))];
                if (inSelection && !m.isHiddenInGUI()) {
                    selected = m;
                    break;
                }
            }
        }
    }

    // ---------------------------------------------------------------- helpers

    private static float lerpF(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static int fadeC(int c, float f) {
        int a = (int) (((c >>> 24) & 0xFF) * Math.max(0.0f, Math.min(1.0f, f)));
        return (a << 24) | (c & 0x00FFFFFF);
    }

    private static String trim(String s, int maxW) {
        if (s == null)
            return "";
        if (ClientFontRenderer.getStringWidth(s) <= maxW)
            return s;
        while (s.length() > 1 && ClientFontRenderer.getStringWidth(s + "..") > maxW)
            s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    private static String fmt(double v, double step) {
        int decimals = 1;
        if (step > 0) {
            decimals = Math.max(0, (int) Math.ceil(-Math.log10(step)));
            if (decimals > 4)
                decimals = 4;
        }
        if (decimals == 0)
            return String.valueOf(Math.round(v));
        double pow = 1.0;
        for (int i = 0; i < decimals; i++)
            pow *= 10.0;
        long scaled = Math.round(Math.abs(v) * pow);
        long whole = scaled / (long) pow;
        long frac = scaled % (long) pow;
        StringBuilder f = new StringBuilder(String.valueOf(frac));
        while (f.length() < decimals)
            f.insert(0, '0');
        return (v < 0 && scaled != 0 ? "-" : "") + whole + "." + f;
    }

    private static boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void saveSettings() {
        try {
            Client.INSTANCE.getConfigManager().getSettingConfig().save();
        } catch (Throwable ignored) {
        }
    }

    private static <T> void resetSetting(Setting<T> s) {
        s.setValue(s.getDefault());
    }

    private List<Module> modulesFor(int catIndex) {
        List<Module> out = new ArrayList<Module>();
        String q = search.trim().toLowerCase();
        for (Module m : ModuleManager.getModules()) {
            if (m.isHiddenInGUI())
                continue;
            if (!q.isEmpty()) {
                if (m.getName().toLowerCase().contains(q))
                    out.add(m);
            } else if (catIndex == -1 && m.isFavorite()) {
                out.add(m);
            } else if (catIndex >= 0 && catIndex < cats.length && m.getCategory() == cats[catIndex]) {
                out.add(m);
            }
        }
        Collections.sort(out, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        return out;
    }

    private int countFavoriteOn() {
        int n = 0;
        for (Module m : ModuleManager.getModules()) {
            if (m.isFavorite() && m.isToggled() && !m.isHiddenInGUI())
                n++;
        }
        return n;
    }

    private int countFavorites() {
        int n = 0;
        for (Module m : ModuleManager.getModules()) {
            if (m.isFavorite() && !m.isHiddenInGUI())
                n++;
        }
        return n;
    }

    private int countOn(int catIndex) {
        int n = 0;
        for (Module m : ModuleManager.getModules()) {
            if (m.getCategory() == cats[catIndex] && m.isToggled() && !m.isHiddenInGUI())
                n++;
        }
        return n;
    }

    // ---------------------------------------------------------------- primitives

    private void window(int x, int y, int w, int h, String title, float f) {
        RenderUtils.drawRoundedRect2D(x - 2, y - 2, x + w + 2, y + h + 2, 8, fadeC(0x40000000, f));
        RenderUtils.drawRoundedRect2D(x, y, x + w, y + h, 7, fadeC(CrystalTheme.BG_DEEP, f));
        RenderUtils.drawRoundedStroke2D(x, y, x + w, y + h, 7, 1.0f, fadeC(CrystalTheme.BORDER, f));
        RenderUtils.drawRoundedRect2D(x + 1, y + 1, x + w - 1, y + 20, 6, fadeC(CrystalTheme.BG_PANEL_ALT, f));
        long now = System.currentTimeMillis();
        for (int i = 0; i < w - 16; i += 8) {
            int c = CrystalTheme.shimmer(now, i / 12);
            Gui.drawRect(x + 8 + i, y + 20, x + 8 + i + Math.min(8, w - 16 - i), y + 21, fadeC(c, f * 0.9f));
        }
        if (title != null)
            ClientFontRenderer.drawStringWithShadow(title, x + 8, y + 6, fadeC(CrystalTheme.TEXT, f));
    }

    private void pill(int x, int y, float on, float f) {
        int bg = CrystalTheme.lerp(0xFF1A2A40, CrystalTheme.ACCENT_DIM, on);
        RenderUtils.drawRoundedRect2D(x, y, x + 16, y + 8, 4, fadeC(bg, f));
        int kx = x + 1 + (int) (8 * on);
        RenderUtils.drawRoundedRect2D(kx, y + 1, kx + 6, y + 7, 3, fadeC(CrystalTheme.lerp(CrystalTheme.TEXT_DIM, CrystalTheme.ACCENT_BRIGHT, on), f));
    }

    private float hover(int key, boolean on) {
        float v = hoverAnim.containsKey(key) ? hoverAnim.get(key) : 0.0f;
        v = lerpF(v, on ? 1.0f : 0.0f, 0.22f);
        hoverAnim.put(key, v);
        return v;
    }

    // ---------------------------------------------------------------- module list view

    private int listRows(int w) {
        return w;
    }

    private void drawList(int id, int x, int y, int w, int h, List<Module> mods, int mx, int my, float f, int rowH) {
        StencilClipUtil.pushClip(x, y, x + w, y + h);
        float sc = listScroll.containsKey(id) ? listScroll.get(id) : 0.0f;
        int content = mods.size() * rowH;
        float maxScroll = Math.max(0, content - h);
        sc = Math.max(0, Math.min(maxScroll, sc));
        listScroll.put(id, sc);
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            int ry = y + i * rowH - (int) sc;
            if (ry + rowH < y || ry > y + h)
                continue;
            boolean hov = in(mx, my, x, ry, w, rowH) && in(mx, my, x, y, w, h);
            float hv = hover(id * 1000 + i, hov);
            float on = switchAnim.containsKey(m) ? switchAnim.get(m) : (m.isToggled() ? 1.0f : 0.0f);
            on = lerpF(on, m.isToggled() ? 1.0f : 0.0f, 0.25f);
            switchAnim.put(m, on);
            boolean sel = m == selected;
            int bg = sel ? CrystalTheme.BG_HOVER : CrystalTheme.lerp(0x00000000, CrystalTheme.BG_PANEL_ALT, hv);
            if (((bg >>> 24) & 0xFF) > 4)
                RenderUtils.drawRoundedRect2D(x + 2, ry + 1, x + w - 2, ry + rowH - 1, 3, fadeC(bg, f));
            if (on > 0.02f)
                RenderUtils.drawRoundedRect2D(x + 2, ry + 3, x + 4, ry + rowH - 3, 1, fadeC(CrystalTheme.ACCENT, f * on));
            int nameCol = CrystalTheme.lerp(CrystalTheme.TEXT_DIM, CrystalTheme.TEXT, Math.max(on, hv * 0.7f));
            int keyW = 0;
            if (m.getKey() > 0) {
                String kn = Keyboard.getKeyName(m.getKey());
                if (kn != null && kn.length() <= 5) {
                    keyW = ClientFontRenderer.getStringWidth(kn) + 6;
                    int kx = x + w - 24 - keyW;
                    RenderUtils.drawRoundedRect2D(kx, ry + 3, kx + keyW, ry + rowH - 3, 2, fadeC(CrystalTheme.ACCENT_DEEP, f));
                    ClientFontRenderer.drawString(kn, kx + 3, ry + (rowH - 8) / 2, fadeC(CrystalTheme.ACCENT_BRIGHT, f));
                }
            }
            ClientFontRenderer.drawStringWithShadow(trim(m.getName(), w - 58 - keyW), x + 8, ry + (rowH - 8) / 2, fadeC(nameCol, f));
            ClientFontRenderer.drawString(m.isFavorite() ? "★" : "☆", x + w - 43, ry + (rowH - 8) / 2, fadeC(m.isFavorite() ? CrystalTheme.ACCENT_BRIGHT : CrystalTheme.TEXT_DIM, f));
            pill(x + w - 22, ry + (rowH - 8) / 2, on, f);
        }
        StencilClipUtil.popClip();
        if (maxScroll > 0) {
            int trackH = h - 4;
            int thumbH = Math.max(12, (int) (trackH * (h / (float) content)));
            int thumbY = y + 2 + (int) ((trackH - thumbH) * (sc / maxScroll));
            RenderUtils.drawRoundedRect2D(x + w - 3, thumbY, x + w - 1, thumbY + thumbH, 1, fadeC(CrystalTheme.ACCENT_DIM, f));
        }
    }

    private int listHit(int id, int x, int y, int w, int h, List<Module> mods, int mx, int my, int rowH, boolean[] onSwitch) {
        if (!in(mx, my, x, y, w, h))
            return -1;
        float sc = listScroll.containsKey(id) ? listScroll.get(id) : 0.0f;
        int idx = (int) ((my - y + sc) / rowH);
        if (idx < 0 || idx >= mods.size())
            return -1;
        onSwitch[0] = mx >= x + w - 26;
        if (onSwitch.length > 1)
            onSwitch[1] = mx >= x + w - 48 && mx < x + w - 27;
        return idx;
    }

    private void scrollList(int id, int h, int count, int rowH, int wheel) {
        float sc = listScroll.containsKey(id) ? listScroll.get(id) : 0.0f;
        sc -= Math.signum(wheel) * 18.0f;
        float max = Math.max(0, count * rowH - h);
        listScroll.put(id, Math.max(0, Math.min(max, sc)));
    }

    // ---------------------------------------------------------------- settings view

    private static class Row {
        int type;
        Setting<?> s;
        int y;
        int h;
    }

    private List<Row> buildRows(Module m) {
        List<Row> rows = new ArrayList<Row>();
        int y = 0;
        y = addRow(rows, T_TOGGLE, null, y, 18);
        y = addRow(rows, T_BIND, null, y, 18);
        HudElement he = m.getHudElement();
        for (Setting<?> s : m.getSettings()) {
            if (he != null && he.isHiddenSetting(s))
                continue;
            if (s == m.getModuleColor() || !s.isVisible())
                continue;
            if (s instanceof BooleanSetting)
                y = addRow(rows, T_BOOL, s, y, 16);
            else if (s instanceof NumberSetting)
                y = addRow(rows, T_NUM, s, y, 22);
            else if (s instanceof ModeSetting)
                y = addRow(rows, T_MODE, s, y, 16);
            else if (s instanceof ColorSetting)
                y = addRow(rows, T_COLOR, s, y, 18);
            else if (s instanceof StringSetting)
                y = addRow(rows, T_STR, s, y, 16);
            else if (s instanceof BindSetting)
                y = addRow(rows, T_BINDSET, s, y, 16);
            else if (s instanceof BlockListSetting)
                y = addRow(rows, T_BLOCK, s, y, 16);
        }
        y = addRow(rows, T_MODCOLOR, null, y, 18);
        if (he != null)
            y = addRow(rows, T_HUD, null, y, 18);
        return rows;
    }

    private int addRow(List<Row> rows, int type, Setting<?> s, int y, int h) {
        Row r = new Row();
        r.type = type;
        r.s = s;
        r.y = y;
        r.h = h;
        rows.add(r);
        return y + h + 3;
    }

    private int settingsContentH(Module m) {
        List<Row> rows = buildRows(m);
        if (rows.isEmpty())
            return 0;
        Row last = rows.get(rows.size() - 1);
        return last.y + last.h + 4;
    }

    private void drawSettings(Module m, int x, int y, int w, int h, int mx, int my, float f) {
        // header: name, description, category
        ClientFontRenderer.drawStringWithShadow(m.getName(), x + 6, y + 4, fadeC(CrystalTheme.ACCENT_BRIGHT, f));
        String cat = m.getCategory().name().toLowerCase();
        ClientFontRenderer.drawString(cat, x + w - 6 - ClientFontRenderer.getStringWidth(cat), y + 4, fadeC(CrystalTheme.TEXT_DIM, f));
        String desc = m.getDescription();
        if (desc != null && !desc.isEmpty())
            ClientFontRenderer.drawString(trim(desc, w - 12), x + 6, y + 15, fadeC(CrystalTheme.TEXT_DIM, f));
        int top = y + 28;
        int viewH = h - 28;
        StencilClipUtil.pushClip(x, top, x + w, top + viewH);
        try {
            int content = settingsContentH(m);
            float max = Math.max(0, content - viewH);
            settingsScroll = Math.max(0, Math.min(max, settingsScroll));
            if (activeSetting != null)
                dragSetting(mx);
            for (Row r : buildRows(m)) {
                int ry = top + r.y - (int) settingsScroll;
                if (ry + r.h < top || ry > top + viewH)
                    continue;
                drawRow(m, r, x + 4, ry, w - 8, mx, my, f, in(mx, my, x, top, w, viewH));
            }
        } catch (Throwable t) {
            System.err.println("[SaltGui] settings draw failed for " + m.getName() + ": " + t);
        }
        StencilClipUtil.popClip();
    }

    private void drawRow(Module m, Row r, int x, int y, int w, int mx, int my, float f, boolean viewHover) {
        boolean hov = viewHover && in(mx, my, x, y, w, r.h);
        int bg = hov ? CrystalTheme.BG_HOVER : CrystalTheme.BG_PANEL;
        RenderUtils.drawRoundedRect2D(x, y, x + w, y + r.h, 3, fadeC(bg, f));
        int tx = x + 6;
        int ty = y + (r.h >= 20 ? 3 : (r.h - 8) / 2);
        switch(r.type) {
            case T_TOGGLE: {
                float on = switchAnim.containsKey(m) ? switchAnim.get(m) : (m.isToggled() ? 1.0f : 0.0f);
                ClientFontRenderer.drawStringWithShadow("Enabled", tx, ty, fadeC(CrystalTheme.TEXT, f));
                pill(x + w - 22, y + (r.h - 8) / 2, on, f);
                break;
            }
            case T_BIND: {
                String label = listeningModuleKey ? "Press a key... (Esc clears)" : "Keybind: " + (m.getKey() > 0 ? Keyboard.getKeyName(m.getKey()) : "none");
                ClientFontRenderer.drawStringWithShadow(label, tx, ty, fadeC(listeningModuleKey ? CrystalTheme.WARN : CrystalTheme.TEXT, f));
                break;
            }
            case T_BOOL: {
                BooleanSetting b = (BooleanSetting) r.s;
                ClientFontRenderer.drawStringWithShadow(trim(b.getName(), w - 34), tx, ty, fadeC(CrystalTheme.TEXT, f));
                pill(x + w - 22, y + (r.h - 8) / 2, b.getValue() ? 1.0f : 0.0f, f);
                break;
            }
            case T_NUM: {
                NumberSetting n = (NumberSetting) r.s;
                double range = n.getMax() - n.getMin();
                float ratio = range > 0 ? (float) ((n.getValue() - n.getMin()) / range) : 0.0f;
                ratio = Math.max(0.0f, Math.min(1.0f, ratio));
                ClientFontRenderer.drawStringWithShadow(trim(n.getName(), w - 50), tx, ty, fadeC(CrystalTheme.TEXT, f));
                String v = fmt(n.getValue(), n.getStep());
                ClientFontRenderer.drawStringWithShadow(v, x + w - 6 - ClientFontRenderer.getStringWidth(v), ty, fadeC(CrystalTheme.ACCENT_BRIGHT, f));
                int tx1 = x + 6, tx2 = x + w - 6, tyy = y + r.h - 6;
                RenderUtils.drawRoundedRect2D(tx1, tyy, tx2, tyy + 3, 1, fadeC(CrystalTheme.ACCENT_DEEP, f));
                int fillX = tx1 + (int) ((tx2 - tx1) * ratio);
                if (fillX > tx1)
                    RenderUtils.drawRoundedRect2D(tx1, tyy, fillX, tyy + 3, 1, fadeC(CrystalTheme.ACCENT, f));
                RenderUtils.drawRoundedRect2D(fillX - 2, tyy - 1, fillX + 2, tyy + 4, 2, fadeC(CrystalTheme.ACCENT_BRIGHT, f));
                break;
            }
            case T_MODE: {
                ModeSetting ms = (ModeSetting) r.s;
                ClientFontRenderer.drawStringWithShadow(trim(ms.getName(), w / 2 - 8), tx, ty, fadeC(CrystalTheme.TEXT, f));
                String v = ms.getValue();
                int vw = ClientFontRenderer.getStringWidth(v) + 10;
                RenderUtils.drawRoundedRect2D(x + w - 4 - vw, y + 2, x + w - 4, y + r.h - 2, 3, fadeC(CrystalTheme.ACCENT_DEEP, f));
                ClientFontRenderer.drawStringWithShadow(v, x + w - 4 - vw + 5, ty, fadeC(CrystalTheme.ACCENT_BRIGHT, f));
                break;
            }
            case T_COLOR:
            case T_MODCOLOR: {
                ColorSetting cs = r.type == T_COLOR ? (ColorSetting) r.s : m.getModuleColor();
                String label = r.type == T_COLOR ? cs.getName() : "Module Color";
                ClientFontRenderer.drawStringWithShadow(trim(label, w - 90), tx, ty, fadeC(cs.getARGB(), f));
                int sx = x + w - 66, sw = 60, sy = y + 5;
                for (int i = 0; i < sw; i += 2) {
                    float[] rgb = ColorSetting.hsbToRgb(i / (float) sw, 1.0f, 1.0f);
                    int c = 0xFF000000 | ((int) (rgb[0] * 255) << 16) | ((int) (rgb[1] * 255) << 8) | (int) (rgb[2] * 255);
                    Gui.drawRect(sx + i, sy, sx + i + 2, sy + 8, fadeC(c, f));
                }
                int sel = sx + (int) ((cs.getHue() / 360.0) * sw);
                Gui.drawRect(sel - 1, sy - 2, sel + 1, sy + 10, fadeC(0xFFFFFFFF, f));
                break;
            }
            case T_STR: {
                StringSetting ss = (StringSetting) r.s;
                boolean ed = editing == ss;
                ClientFontRenderer.drawStringWithShadow(trim(ss.getName(), w / 3), tx, ty, fadeC(CrystalTheme.TEXT, f));
                String v = ed ? editBuf + ((System.currentTimeMillis() / 400) % 2 == 0 ? "|" : "") : ss.getValue();
                int fw = (w * 2) / 3 - 10;
                RenderUtils.drawRoundedRect2D(x + w - 4 - fw, y + 2, x + w - 4, y + r.h - 2, 3, fadeC(ed ? CrystalTheme.ACCENT_DEEP : CrystalTheme.BG_DEEP, f));
                ClientFontRenderer.drawString(trimTail(v, fw - 8), x + w - 4 - fw + 4, ty, fadeC(CrystalTheme.ACCENT_BRIGHT, f));
                break;
            }
            case T_BINDSET: {
                BindSetting bs = (BindSetting) r.s;
                String v = listeningBind == bs ? "press a key..." : (bs.isBound() ? Keyboard.getKeyName(bs.getKeyCode()) : "none") + (bs.isHoldMode() ? " (hold)" : " (toggle)");
                ClientFontRenderer.drawStringWithShadow(trim(bs.getName() + ": " + v, w - 12), tx, ty, fadeC(listeningBind == bs ? CrystalTheme.WARN : CrystalTheme.TEXT, f));
                break;
            }
            case T_BLOCK: {
                ClientFontRenderer.drawStringWithShadow(trim(r.s.getName() + "  (click to edit)", w - 12), tx, ty, fadeC(CrystalTheme.TEXT, f));
                break;
            }
            case T_HUD: {
                ClientFontRenderer.drawStringWithShadow("Edit HUD Position", tx, ty, fadeC(CrystalTheme.ACCENT_BRIGHT, f));
                break;
            }
            default:
                break;
        }
    }

    private static String trimTail(String s, int maxW) {
        if (s == null)
            return "";
        while (s.length() > 0 && ClientFontRenderer.getStringWidth(s) > maxW)
            s = s.substring(1);
        return s;
    }

    private void dragSetting(int mx) {
        if (activeSetting instanceof NumberSetting) {
            NumberSetting n = (NumberSetting) activeSetting;
            double ratio = (mx - (activeX + 6)) / (double) Math.max(1, activeW - 12);
            ratio = Math.max(0.0, Math.min(1.0, ratio));
            double value = n.getMin() + ratio * (n.getMax() - n.getMin());
            double step = n.getStep();
            if (step > 0)
                value = Math.round((value - n.getMin()) / step) * step + n.getMin();
            value = Math.max(n.getMin(), Math.min(n.getMax(), value));
            n.setValue(Double.valueOf(value));
        } else if (activeSetting instanceof ColorSetting) {
            ColorSetting c = (ColorSetting) activeSetting;
            double ratio = (mx - (activeX + activeW - 66)) / 60.0;
            ratio = Math.max(0.0, Math.min(1.0, ratio));
            c.setValue(Double.valueOf(ratio * 360.0));
        }
    }

    private boolean clickSettings(Module m, int x, int y, int w, int h, int mx, int my, int btn) {
        int top = y + 28;
        int viewH = h - 28;
        if (!in(mx, my, x, top, w, viewH))
            return false;
        for (Row r : buildRows(m)) {
            int ry = top + r.y - (int) settingsScroll;
            int rx = x + 4;
            int rw = w - 8;
            if (!in(mx, my, rx, ry, rw, r.h))
                continue;
            switch(r.type) {
                case T_TOGGLE:
                    m.toggle();
                    saveSettings();
                    break;
                case T_BIND:
                    listeningModuleKey = btn == 0;
                    if (btn == 1) {
                        m.setKey(-1);
                        Client.INSTANCE.getConfigManager().getModuleConfig().save();
                    }
                    break;
                case T_BOOL: {
                    BooleanSetting b = (BooleanSetting) r.s;
                    if (btn == 1)
                        resetSetting(b);
                    else
                        b.setValue(Boolean.valueOf(!b.getValue()));
                    saveSettings();
                    break;
                }
                case T_NUM: {
                    if (btn == 1) {
                        resetSetting(r.s);
                        saveSettings();
                    } else {
                        activeSetting = r.s;
                        activeX = rx;
                        activeW = rw;
                        dragSetting(mx);
                    }
                    break;
                }
                case T_MODE: {
                    ModeSetting ms = (ModeSetting) r.s;
                    String[] modes = ms.getModes();
                    if (btn == 1 && modes != null && modes.length > 0) {
                        int idx = 0;
                        for (int i = 0; i < modes.length; i++) {
                            if (modes[i].equals(ms.getValue()))
                                idx = i;
                        }
                        ms.setMode(modes[(idx - 1 + modes.length) % modes.length]);
                    } else {
                        ms.cycle();
                    }
                    saveSettings();
                    break;
                }
                case T_COLOR:
                case T_MODCOLOR: {
                    ColorSetting cs = r.type == T_COLOR ? (ColorSetting) r.s : m.getModuleColor();
                    if (btn == 1) {
                        resetSetting(cs);
                        saveSettings();
                    } else if (mx >= rx + rw - 66) {
                        activeSetting = cs;
                        activeX = rx;
                        activeW = rw;
                        dragSetting(mx);
                    }
                    break;
                }
                case T_STR:
                    editing = r.s;
                    editBuf = ((StringSetting) r.s).getValue();
                    break;
                case T_BINDSET: {
                    BindSetting bs = (BindSetting) r.s;
                    if (btn == 1)
                        bs.setActivationMode(bs.isHoldMode() ? BindSetting.MODE_TOGGLE : BindSetting.MODE_HOLD);
                    else
                        listeningBind = bs;
                    saveSettings();
                    break;
                }
                case T_BLOCK:
                    mc.displayGuiScreen(new BlockListScreen((BlockListSetting) r.s));
                    break;
                case T_HUD:
                    HudElement.setHudEditorOpen(true);
                    mc.displayGuiScreen(new client.gui.HudEditorScreen());
                    break;
                default:
                    break;
            }
            return true;
        }
        return true;
    }

    // ---------------------------------------------------------------- screen

    public void drawScreen(int mx, int my, float partialTicks) {
        float f = Math.min(1.0f, (System.currentTimeMillis() - openTime) / 220.0f);
        Gui.drawRect(0, 0, this.width, this.height, fadeC(0xA0030812, f));
        client.utils.render.FontManager.pump();
        if (panelsMode())
            drawPanels(mx, my, f);
        else
            drawHub(mx, my, f);
    }

    // ---- HUB layout

    private void hubGeometry() {
        hw = Math.min(this.width - 16, 580);
        hh = Math.min(this.height - 16, 350);
        if (hubX < 0 || hubY < 0) {
            hubX = (this.width - hw) / 2;
            hubY = (this.height - hh) / 2;
        }
        hubX = Math.max(0, Math.min(this.width - hw, hubX));
        hubY = Math.max(0, Math.min(this.height - hh, hubY));
        hx = hubX;
        hy = hubY;
    }

    private void drawHub(int mx, int my, float f) {
        hubGeometry();
        window(hx, hy, hw, hh, null, f);
        long now = System.currentTimeMillis();
        // title
        String title = "SALTCLIENT";
        int cx = hx + 10;
        for (int i = 0; i < title.length(); i++) {
            String ch = String.valueOf(title.charAt(i));
            ClientFontRenderer.drawStringWithShadow(ch, cx, hy + 6, fadeC(CrystalTheme.shimmer(now, i), f));
            cx += ClientFontRenderer.getStringWidth(ch) + 1;
        }
        ClientFontRenderer.drawStringWithShadow("MACE READY  •  " + ModuleManager.getModules().size() + " MODULES  •  " + countFavorites() + " SAVED", hx + 92, hy + 6, fadeC(CrystalTheme.TEXT_DIM, f));
        // layout switch + close
        String lay = "PANELS";
        int lw = ClientFontRenderer.getStringWidth(lay) + 12;
        int lx = hx + hw - lw - 24;
        boolean lh = in(mx, my, lx, hy + 3, lw, 14);
        RenderUtils.drawRoundedRect2D(lx, hy + 3, lx + lw, hy + 17, 4, fadeC(lh ? CrystalTheme.BG_HOVER : CrystalTheme.ACCENT_DEEP, f));
        ClientFontRenderer.drawStringWithShadow(lay, lx + 6, hy + 6, fadeC(CrystalTheme.ACCENT_BRIGHT, f));
        boolean xh = in(mx, my, hx + hw - 20, hy + 3, 14, 14);
        RenderUtils.drawRoundedRect2D(hx + hw - 20, hy + 3, hx + hw - 6, hy + 17, 4, fadeC(xh ? CrystalTheme.BAD : CrystalTheme.ACCENT_DEEP, f));
        ClientFontRenderer.drawStringWithShadow("x", hx + hw - 15, hy + 6, fadeC(CrystalTheme.TEXT, f));
        int bodyY = hy + 26;
        int bodyH = hh - 30;
        // rail
        int railW = 92;
        int sx = hx + 6, sy = bodyY;
        RenderUtils.drawRoundedRect2D(sx, sy, sx + railW - 6, sy + 16, 4, fadeC(searchFocus ? CrystalTheme.BG_HOVER : CrystalTheme.BG_PANEL, f));
        String stext = search.isEmpty() && !searchFocus ? "Search..." : search + (searchFocus && (now / 400) % 2 == 0 ? "|" : "");
        ClientFontRenderer.drawString(trimTail(stext, railW - 18), sx + 5, sy + 4, fadeC(search.isEmpty() ? CrystalTheme.TEXT_DIM : CrystalTheme.TEXT, f));
        int cy = sy + 22;
        boolean favSel = selCat == -1 && search.isEmpty();
        boolean favHov = in(mx, my, sx, cy, railW - 6, 17);
        float favHv = hover(899, favHov);
        if (favSel || favHv > 0.02f)
            RenderUtils.drawRoundedRect2D(sx, cy, sx + railW - 6, cy + 17, 4, fadeC(favSel ? CrystalTheme.BG_HOVER : CrystalTheme.BG_PANEL_ALT, f * (favSel ? 1.0f : favHv)));
        if (favSel)
            RenderUtils.drawRoundedRect2D(sx, cy + 3, sx + 2, cy + 14, 1, fadeC(CrystalTheme.ACCENT, f));
        ClientFontRenderer.drawStringWithShadow("★ Favorites", sx + 7, cy + 5, fadeC(favSel ? CrystalTheme.ACCENT_BRIGHT : CrystalTheme.TEXT, f));
        int favCount = countFavorites();
        if (favCount > 0) {
            String c = String.valueOf(favCount);
            ClientFontRenderer.drawString(c, sx + railW - 12 - ClientFontRenderer.getStringWidth(c), cy + 5, fadeC(CrystalTheme.ACCENT_BRIGHT, f));
        }
        cy += 19;
        for (int i = 0; i < cats.length; i++) {
            boolean sel = i == selCat && search.isEmpty();
            boolean hov = in(mx, my, sx, cy, railW - 6, 17);
            float hv = hover(900 + i, hov);
            if (sel)
                RenderUtils.drawRoundedRect2D(sx, cy, sx + railW - 6, cy + 17, 4, fadeC(CrystalTheme.BG_HOVER, f));
            else if (hv > 0.02f)
                RenderUtils.drawRoundedRect2D(sx, cy, sx + railW - 6, cy + 17, 4, fadeC(CrystalTheme.BG_PANEL_ALT, f * hv));
            if (sel)
                RenderUtils.drawRoundedRect2D(sx, cy + 3, sx + 2, cy + 14, 1, fadeC(CrystalTheme.ACCENT, f));
            String nm = cats[i].name().substring(0, 1) + cats[i].name().substring(1).toLowerCase();
            nm = nm.replace("_", " ");
            ClientFontRenderer.drawStringWithShadow(trim(nm, railW - 34), sx + 7, cy + 5, fadeC(sel ? CrystalTheme.ACCENT_BRIGHT : CrystalTheme.lerp(CrystalTheme.TEXT_DIM, CrystalTheme.TEXT, hv), f));
            int on = countOn(i);
            if (on > 0) {
                String c = String.valueOf(on);
                int cw = ClientFontRenderer.getStringWidth(c) + 6;
                RenderUtils.drawRoundedRect2D(sx + railW - 6 - cw - 3, cy + 3, sx + railW - 9, cy + 14, 3, fadeC(CrystalTheme.ACCENT_DEEP, f));
                ClientFontRenderer.drawString(c, sx + railW - 6 - cw, cy + 5, fadeC(CrystalTheme.ACCENT_BRIGHT, f));
            }
            cy += 19;
        }
        // module list
        int lx2 = hx + railW + 6;
        int lw2 = 178;
        RenderUtils.drawRoundedRect2D(lx2, bodyY, lx2 + lw2, bodyY + bodyH - 4, 5, fadeC(CrystalTheme.BG_PANEL, f));
        List<Module> mods = modulesFor(selCat);
        drawList(1, lx2, bodyY + 2, lw2, bodyH - 8, mods, mx, my, f, 18);
        // settings
        int px = lx2 + lw2 + 6;
        int pw = hx + hw - 6 - px;
        RenderUtils.drawRoundedRect2D(px, bodyY, px + pw, bodyY + bodyH - 4, 5, fadeC(CrystalTheme.BG_PANEL, f));
        if (selected != null)
            drawSettings(selected, px, bodyY + 2, pw, bodyH - 8, mx, my, f);
        else
            ClientFontRenderer.drawStringWithShadow("Select a module", px + 8, bodyY + 8, fadeC(CrystalTheme.TEXT_DIM, f));
    }

    // ---- PANELS layout

    private int[] panelPosFor(int i) {
        int[] p = panelPos.get(i);
        if (p == null) {
            int cols = Math.max(1, (this.width - 190) / 126);
            int col = i % cols;
            int row = i / cols;
            p = new int[] { 8 + col * 126, 10 + row * 120 };
            panelPos.put(i, p);
        }
        return p;
    }

    private int panelH(int count) {
        return 20 + Math.min(count, 12) * 14 + 6;
    }

    private void drawPanels(int mx, int my, float f) {
        long now = System.currentTimeMillis();
        for (int i = 0; i <= cats.length; i++) {
            int[] p = panelPosFor(i);
            List<Module> mods = modulesFor(i == cats.length ? -1 : i);
            int ph = panelH(mods.size());
            String nm = i == cats.length ? "FAVORITES" : cats[i].name().substring(0, 1) + cats[i].name().substring(1).toLowerCase();
            window(p[0], p[1], 120, ph, nm.replace("_", " "), f);
            int on = i == cats.length ? countFavoriteOn() : countOn(i);
            if (on > 0) {
                String c = String.valueOf(on);
                ClientFontRenderer.drawString(c, p[0] + 112 - ClientFontRenderer.getStringWidth(c), p[1] + 6, fadeC(CrystalTheme.ACCENT_BRIGHT, f));
            }
            drawList(10 + i, p[0], p[1] + 23, 120, ph - 26, mods, mx, my, f, 14);
        }
        if (setWinX < 0)
            setWinX = Math.max(8, this.width - 196);
        int sw = 188;
        int sh = Math.min(this.height - 20, 280);
        setWinY = Math.max(0, Math.min(this.height - sh, setWinY));
        setWinX = Math.max(0, Math.min(this.width - sw, setWinX));
        window(setWinX, setWinY, sw, sh, null, f);
        ClientFontRenderer.drawStringWithShadow("Settings", setWinX + 8, setWinY + 6, fadeC(CrystalTheme.TEXT, f));
        String lay = "HUB";
        int lw = ClientFontRenderer.getStringWidth(lay) + 12;
        int lx = setWinX + sw - lw - 24;
        boolean lh = in(mx, my, lx, setWinY + 3, lw, 14);
        RenderUtils.drawRoundedRect2D(lx, setWinY + 3, lx + lw, setWinY + 17, 4, fadeC(lh ? CrystalTheme.BG_HOVER : CrystalTheme.ACCENT_DEEP, f));
        ClientFontRenderer.drawStringWithShadow(lay, lx + 6, setWinY + 6, fadeC(CrystalTheme.ACCENT_BRIGHT, f));
        boolean xh = in(mx, my, setWinX + sw - 20, setWinY + 3, 14, 14);
        RenderUtils.drawRoundedRect2D(setWinX + sw - 20, setWinY + 3, setWinX + sw - 6, setWinY + 17, 4, fadeC(xh ? CrystalTheme.BAD : CrystalTheme.ACCENT_DEEP, f));
        ClientFontRenderer.drawStringWithShadow("x", setWinX + sw - 15, setWinY + 6, fadeC(CrystalTheme.TEXT, f));
        if (selected != null)
            drawSettings(selected, setWinX, setWinY + 22, sw, sh - 24, mx, my, f);
        else
            ClientFontRenderer.drawStringWithShadow("Right-click a module", setWinX + 8, setWinY + 32, fadeC(CrystalTheme.TEXT_DIM, f));
    }

    // ---------------------------------------------------------------- input

    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        if (editing != null) {
            commitEdit();
        }
        searchFocus = false;
        if (panelsMode())
            clickPanels(mx, my, btn);
        else
            clickHub(mx, my, btn);
    }

    private void clickList(int id, int x, int y, int w, int h, List<Module> mods, int mx, int my, int btn, int rowH) {
        boolean[] sw = new boolean[2];
        int idx = listHit(id, x, y, w, h, mods, mx, my, rowH, sw);
        if (idx < 0)
            return;
        Module m = mods.get(idx);
        if (btn == 0 && sw[1]) {
            m.setFavorite(!m.isFavorite());
            Client.INSTANCE.getConfigManager().getModuleConfig().save();
            return;
        }
        if (btn == 0) {
            if (sw[0] || panelsMode()) {
                m.toggle();
                saveSettings();
            } else {
                selected = m;
                settingsScroll = 0.0f;
            }
            if (!sw[0] && !panelsMode()) {
                // single click selects; double behaviour via switch
            }
        } else if (btn == 1) {
            selected = m;
            settingsScroll = 0.0f;
        } else if (btn == 2) {
            m.toggle();
            saveSettings();
        }
    }

    private void clickHub(int mx, int my, int btn) {
        if (!in(mx, my, hx, hy, hw, hh)) {
            mc.displayGuiScreen(null);
            return;
        }
        String lay = "PANELS";
        int lw = ClientFontRenderer.getStringWidth(lay) + 12;
        int lx = hx + hw - lw - 24;
        if (in(mx, my, lx, hy + 3, lw, 14)) {
            toggleLayout();
            return;
        }
        if (in(mx, my, hx + hw - 20, hy + 3, 14, 14)) {
            mc.displayGuiScreen(null);
            return;
        }
        if (in(mx, my, hx, hy, hw, 22)) {
            dragWin = -1;
            dragOffX = mx - hx;
            dragOffY = my - hy;
            return;
        }
        int bodyY = hy + 26;
        int bodyH = hh - 30;
        int railW = 92;
        int sx = hx + 6, sy = bodyY;
        if (in(mx, my, sx, sy, railW - 6, 16)) {
            searchFocus = true;
            return;
        }
        int cy = sy + 22;
        if (in(mx, my, sx, cy, railW - 6, 17)) {
            selCat = -1;
            search = "";
            listScroll.put(1, 0.0f);
            return;
        }
        cy += 19;
        for (int i = 0; i < cats.length; i++) {
            if (in(mx, my, sx, cy, railW - 6, 17)) {
                selCat = i;
                search = "";
                listScroll.put(1, 0.0f);
                return;
            }
            cy += 19;
        }
        int lx2 = hx + railW + 6;
        int lw2 = 178;
        List<Module> mods = modulesFor(selCat);
        clickList(1, lx2, bodyY + 2, lw2, bodyH - 8, mods, mx, my, btn, 18);
        int px = lx2 + lw2 + 6;
        int pw = hx + hw - 6 - px;
        if (selected != null)
            clickSettings(selected, px, bodyY + 2, pw, bodyH - 8, mx, my, btn);
    }

    private void clickPanels(int mx, int my, int btn) {
        int sw = 188;
        int sh = Math.min(this.height - 20, 280);
        String lay = "HUB";
        int lw = ClientFontRenderer.getStringWidth(lay) + 12;
        int lx = setWinX + sw - lw - 24;
        if (in(mx, my, setWinX, setWinY, sw, sh)) {
            if (in(mx, my, lx, setWinY + 3, lw, 14)) {
                toggleLayout();
                return;
            }
            if (in(mx, my, setWinX + sw - 20, setWinY + 3, 14, 14)) {
                mc.displayGuiScreen(null);
                return;
            }
            if (in(mx, my, setWinX, setWinY, sw, 22)) {
                dragWin = 100;
                dragOffX = mx - setWinX;
                dragOffY = my - setWinY;
                return;
            }
            if (selected != null)
                clickSettings(selected, setWinX, setWinY + 22, sw, sh - 24, mx, my, btn);
            return;
        }
        for (int i = cats.length; i >= 0; i--) {
            int[] p = panelPosFor(i);
            List<Module> mods = modulesFor(i == cats.length ? -1 : i);
            int ph = panelH(mods.size());
            if (!in(mx, my, p[0], p[1], 120, ph))
                continue;
            if (in(mx, my, p[0], p[1], 120, 22)) {
                dragWin = i;
                dragOffX = mx - p[0];
                dragOffY = my - p[1];
                return;
            }
            clickList(10 + i, p[0], p[1] + 23, 120, ph - 26, mods, mx, my, btn, 14);
            return;
        }
    }

    protected void mouseClickMove(int mx, int my, int btn, long time) {
        if (dragWin == -1) {
            hubX = mx - dragOffX;
            hubY = my - dragOffY;
        } else if (dragWin == 100) {
            setWinX = mx - dragOffX;
            setWinY = my - dragOffY;
        } else if (dragWin >= 0) {
            int[] p = panelPosFor(dragWin);
            p[0] = Math.max(0, Math.min(this.width - 120, mx - dragOffX));
            p[1] = Math.max(0, Math.min(this.height - 30, my - dragOffY));
        }
    }

    protected void mouseReleased(int mx, int my, int state) {
        if (activeSetting != null) {
            activeSetting = null;
            saveSettings();
        }
        dragWin = -2;
    }

    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d == 0)
            return;
        int mx = Mouse.getEventX() * this.width / this.mc.displayWidth;
        int my = this.height - Mouse.getEventY() * this.height / this.mc.displayHeight - 1;
        if (panelsMode()) {
            int sw = 188;
            int sh = Math.min(this.height - 20, 280);
            if (in(mx, my, setWinX, setWinY, sw, sh)) {
                settingsScroll -= Math.signum(d) * 18.0f;
                return;
            }
            for (int i = cats.length - 1; i >= 0; i--) {
                int[] p = panelPosFor(i);
                List<Module> mods = modulesFor(i);
                int ph = panelH(mods.size());
                if (in(mx, my, p[0], p[1], 120, ph)) {
                    scrollList(10 + i, ph - 26, mods.size(), 14, d);
                    return;
                }
            }
        } else {
            int bodyY = hy + 26;
            int bodyH = hh - 30;
            int lx2 = hx + 92 + 6;
            if (in(mx, my, lx2, bodyY, 178, bodyH)) {
                scrollList(1, bodyH - 8, modulesFor(selCat).size(), 18, d);
            } else if (in(mx, my, lx2 + 184, bodyY, hw, bodyH)) {
                settingsScroll -= Math.signum(d) * 18.0f;
            }
        }
    }

    private void commitEdit() {
        if (editing instanceof StringSetting) {
            ((StringSetting) editing).setValue(editBuf);
            saveSettings();
        }
        editing = null;
    }

    protected void keyTyped(char c, int code) throws IOException {
        if (listeningModuleKey && selected != null) {
            if (code == 1)
                selected.setKey(-1);
            else if (code > 0)
                selected.setKey(code);
            Client.INSTANCE.getConfigManager().getModuleConfig().save();
            listeningModuleKey = false;
            return;
        }
        if (listeningBind != null) {
            if (code == 1)
                listeningBind.setKey(-1);
            else if (code > 0)
                listeningBind.setKey(code);
            saveSettings();
            listeningBind = null;
            return;
        }
        if (editing != null) {
            if (code == 1) {
                editing = null;
            } else if (code == 28) {
                commitEdit();
            } else if (code == 14) {
                if (!editBuf.isEmpty())
                    editBuf = editBuf.substring(0, editBuf.length() - 1);
            } else if (c >= 32 && c != 127 && editBuf.length() < 64) {
                editBuf += c;
            }
            return;
        }
        if (searchFocus) {
            if (code == 1) {
                if (search.isEmpty())
                    searchFocus = false;
                else
                    search = "";
            } else if (code == 14) {
                if (!search.isEmpty())
                    search = search.substring(0, search.length() - 1);
            } else if (c >= 32 && c != 127 && search.length() < 24) {
                search += c;
            }
            listScroll.put(1, 0.0f);
            return;
        }
        if (code == 1) {
            this.mc.displayGuiScreen(null);
        }
    }
}
