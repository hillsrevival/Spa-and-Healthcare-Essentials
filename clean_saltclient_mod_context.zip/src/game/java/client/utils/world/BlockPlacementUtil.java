package client.utils.world;

import client.Client;
import client.utils.movement.RotationUtils;
import client.utils.combat.SilentAimUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;

public class BlockPlacementUtil {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static double aimPitchBias = 0.0;

    private static final float GRIM_MAX_ROT_SPEED = 55.0f;

    private static boolean rotationActive = false;

    private static BlockPos previousTarget = null;

    private static final int WARM_TICK_LIMIT = 6;

    private static int warmTicks = 0;

    private static boolean streakHeld = false;

    private static int lastSpoofedTick = -1000000;

    private static void markAimSpoofed() {
        if (mc.player != null) {
            lastSpoofedTick = mc.player.ticksExisted;
        }
    }

    private static int holdTicksRemaining = -1;

    private static boolean holdExpired = false;

    private static final int HOLD_TICKS = 0;

    private static BlockPos pendingClickedBlock = null;

    private static EnumFacing pendingFace = null;

    private static Vec3d pendingHitVec = null;

    private static BlockPos pendingPlacePos = null;

    private static BlockPos gateDeferredPending = null;

    private static BlockPos stickyAimNeighbor = null;

    private static BlockPos stickyAimCell = null;

    private static int stickyDisagreeTicks = 0;

    private static final int STICKY_DISAGREE_RELEASE = 3;

    private static final EnumFacing[] HORIZONTALS = { EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.EAST, EnumFacing.WEST };

    private static int pendingLayerY = 0;

    private BlockPlacementUtil() {
    }

    public static void onEnable() {
        SilentAimUtil.onEnable("Scaffold");
        clearPending();
        Client.INSTANCE.renderRotationOverride = false;
        Client.INSTANCE.physicsConsistentAim = true;
        rotationActive = false;
        streakHeld = false;
        lastSpoofedTick = -1000000;
        previousTarget = null;
        warmTicks = 0;
        holdTicksRemaining = -1;
        holdExpired = false;
    }

    public static void onDisable() {
        SilentAimUtil.onDisable("Scaffold");
        clearPending();
        BlockUtils.clearPlaced();
        Client.INSTANCE.renderRotationOverride = false;
        Client.INSTANCE.physicsConsistentAim = false;
        rotationActive = false;
        streakHeld = false;
        lastSpoofedTick = -1000000;
        previousTarget = null;
        stickyAimNeighbor = null;
        stickyAimCell = null;
        warmTicks = 0;
        holdTicksRemaining = -1;
        holdExpired = false;
    }

    public static boolean prepare(BlockPos target, boolean sameY, float startY, float minSpeed, float maxSpeed, boolean useGCD, boolean moveCorrect, boolean jitter) {
        if (mc.player == null || mc.world == null || target == null)
            return false;
        if (!SilentAimUtil.isOwnedBy("Scaffold")) {
            return false;
        }
        int hystLayerY = (int) Math.floor(startY) - 1;
        boolean hystSinking = !mc.player.onGround && !(mc.player.motionY > 0.05 || mc.player.posY > hystLayerY + 2.05);
        boolean diagonalMotion = Math.abs(mc.player.motionX) > 0.08 && Math.abs(mc.player.motionZ) > 0.08;
        if (!hystSinking && stickyAimCell != null && !stickyAimCell.equals(target)) {
            if (diagonalMotion) {
                stickyDisagreeTicks++;
            }
            BlockPos sc = stickyAimCell;
            boolean stillReplaceable = mc.world.getBlockState(sc).getMaterial().isReplaceable();
            boolean hasFace = BlockUtils.isSolid(sc.down()) || BlockUtils.isSolid(sc.up());
            if (!hasFace) {
                double hpx = mc.player.posX;
                double hpz = mc.player.posZ;
                for (EnumFacing f : HORIZONTALS) {
                    BlockPos nb = sc.offset(f);
                    if (BlockUtils.isSolid(nb) && BlockUtils.isNeighborFaceVisible(sc, nb, hpx, hpz)) {
                        hasFace = true;
                        break;
                    }
                }
            }
            double hdx = sc.getX() + 0.5 - mc.player.posX;
            double hdz = sc.getZ() + 0.5 - mc.player.posZ;
            boolean inReach = hdx * hdx + hdz * hdz < 12.0;
            if (stillReplaceable && hasFace && inReach && (!diagonalMotion || stickyDisagreeTicks < STICKY_DISAGREE_RELEASE)) {
                target = sc;
            } else {
                stickyAimCell = null;
                stickyDisagreeTicks = 0;
            }
        } else {
            stickyDisagreeTicks = 0;
        }
        stickyAimCell = target;
        float parkFwd = (mc.gameSettings.keyBindForward.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindBack.isKeyDown() ? 1 : 0);
        float parkStr = (mc.gameSettings.keyBindLeft.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindRight.isKeyDown() ? 1 : 0);
        boolean parkOnly = false;
        if (!mc.player.onGround && (parkFwd != 0.0f || parkStr != 0.0f)) {
            float parkYaw = SilentAimUtil.isContinuous() ? SilentAimUtil.getRealYaw() : mc.player.rotationYaw;
            float parkYawRad = parkYaw * 0.017453292f;
            double pdirX = parkStr * Math.cos(parkYawRad) - parkFwd * Math.sin(parkYawRad);
            double pdirZ = parkFwd * Math.cos(parkYawRad) + parkStr * Math.sin(parkYawRad);
            double pmag = Math.sqrt(pdirX * pdirX + pdirZ * pdirZ);
            if (pmag > 0.01) {
                double fillDot = (target.getX() + 0.5 - mc.player.posX) * (pdirX / pmag) + (target.getZ() + 0.5 - mc.player.posZ) * (pdirZ / pmag);
                parkOnly = fillDot < -0.9;
            }
        }
        Vec3d aimTarget = BlockUtils.getEdgeAimTarget(target, sameY, startY, stickyAimNeighbor, parkOnly);
        stickyAimNeighbor = BlockUtils.lastAimNeighbor;
        boolean isVoidBridge = !BlockUtils.isSolid(target.down());
        if (!isVoidBridge) {
            aimPitchBias += (Math.random() - 0.5) * 0.07;
            aimPitchBias = Math.max(-0.35, Math.min(0.35, aimPitchBias));
            aimTarget = new Vec3d(aimTarget.xCoord, aimTarget.yCoord + aimPitchBias, aimTarget.zCoord);
        }
        Vec3d realEyes = RotationUtils.getEyesPos();
        double estMotionY = mc.player.onGround ? mc.player.motionY * 0.5 : 0.0;
        float forward = (mc.gameSettings.keyBindForward.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindBack.isKeyDown() ? 1 : 0);
        float strafe = (mc.gameSettings.keyBindLeft.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindRight.isKeyDown() ? 1 : 0);
        float yaw = SilentAimUtil.isContinuous() ? SilentAimUtil.getRealYaw() : mc.player.rotationYaw;
        float yawRad = yaw * 0.017453292f;
        double moveDirX = strafe * Math.cos(yawRad) - forward * Math.sin(yawRad);
        double moveDirZ = forward * Math.cos(yawRad) + strafe * Math.sin(yawRad);
        double moveMag = Math.sqrt(moveDirX * moveDirX + moveDirZ * moveDirZ);
        double speed = 0.0;
        if (moveMag > 0.01) {
            moveDirX /= moveMag;
            moveDirZ /= moveMag;
            speed = Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ);
            speed = Math.min(speed, 0.6);
        }
        Vec3d estEyes;
        if (!mc.player.onGround) {
            estEyes = realEyes;
        } else {
            estEyes = new Vec3d(realEyes.xCoord + moveDirX * speed, realEyes.yCoord + estMotionY, realEyes.zCoord + moveDirZ * speed);
        }
        boolean isOffGround = !mc.player.onGround;
        float cappedMax = Math.min(maxSpeed, GRIM_MAX_ROT_SPEED);
        float cappedMin = Math.min(minSpeed, cappedMax);
        float effectiveMin = (isVoidBridge || isOffGround) ? Math.max(cappedMin, cappedMax * 0.9f) : cappedMin;
        holdTicksRemaining = -1;
        holdExpired = false;
        rotationActive = true;
        markAimSpoofed();
        float realYawNow = SilentAimUtil.isContinuous() ? SilentAimUtil.getRealYaw() : mc.player.rotationYaw;
        boolean moving = mc.gameSettings.keyBindForward.isKeyDown() || mc.gameSettings.keyBindBack.isKeyDown() || mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown();
        boolean gridLockMovement = moving && mc.player.onGround;
        float[] solved = solveGridRotation(aimTarget, estEyes, target, realYawNow, gridLockMovement);
        boolean rotationParked = false;
        if (mc.player.onGround && !mc.gameSettings.keyBindJump.isKeyDown() && SilentAimUtil.hasServerRotation()) {
            float parkYaw = SilentAimUtil.getServerYaw();
            float parkPitch = SilentAimUtil.getServerPitch();
            Vec3d parkLook = RotationUtils.getLookVec(parkYaw, parkPitch);
            int parkLayerY = target.getY();
            BlockPos realCell = parkArmCell(realEyes, parkLook, parkLayerY);
            BlockPos estCell = parkArmCell(estEyes, parkLook, parkLayerY);
            if (realCell != null && (estCell == null || estCell.equals(realCell))) {
                rotationParked = true;
            } else {
                for (int oi = 0; oi < 2 && !rotationParked; oi++) {
                    Vec3d org = oi == 0 ? estEyes : realEyes;
                    Vec3d end = org.addVector(parkLook.xCoord * 4.4, parkLook.yCoord * 4.4, parkLook.zCoord * 4.4);
                    RayTraceResult r = mc.world.rayTraceBlocks(org, end, false, false, false);
                    if (r == null || r.typeOfHit != RayTraceResult.Type.BLOCK) {
                        continue;
                    }
                    BlockPos hit = r.getBlockPos();
                    EnumFacing face = r.sideHit;
                    if (stickyAimNeighbor != null && hit.equals(stickyAimNeighbor) && hit.offset(face).equals(target)) {
                        rotationParked = true;
                    } else if (hit.equals(target.down()) && face == EnumFacing.UP && hit.offset(face).equals(target)) {
                        rotationParked = true;
                    }
                }
            }
        }
        if (rotationParked) {
            SilentAimUtil.clearQuantPending();
            if (SilentAimUtil.holdParkedTick()) {
                markAimSpoofed();
            }
        } else {
            SilentAimUtil.tickTowardQuant(solved[0], solved[1], effectiveMin, cappedMax, jitter, gridLockMovement);
        }
        boolean nearTarget = previousTarget == null || previousTarget.distanceSq(target) <= 9.0 || !mc.player.onGround;
        if (!nearTarget) {
            SilentAimUtil.revertToRealForPacket();
            previousTarget = target;
            warmTicks = 0;
            return false;
        }
        SilentAimUtil.applyMovementCorrection(SilentAimUtil.getRealYaw(), SilentAimUtil.getServerYaw());
        previousTarget = target;
        warmTicks = 0;
        float sYaw = SilentAimUtil.getServerYaw();
        float sPitch = SilentAimUtil.getServerPitch();
        int layerY = target.getY();
        Vec3d look = RotationUtils.getLookVec(sYaw, sPitch);
        double reach = 4.4;
        Vec3d end = estEyes.addVector(look.xCoord * reach, look.yCoord * reach, look.zCoord * reach);
        RayTraceResult result = mc.world.rayTraceBlocks(estEyes, end, false, false, false);
        if (result == null || result.typeOfHit != RayTraceResult.Type.BLOCK || !isAcceptablePlacement(result.getBlockPos().offset(result.sideHit), layerY) || estEyes.distanceTo(result.hitVec) > 4.4) {
            Vec3d end2 = realEyes.addVector(look.xCoord * reach, look.yCoord * reach, look.zCoord * reach);
            RayTraceResult result2 = mc.world.rayTraceBlocks(realEyes, end2, false, false, false);
            if (result2 != null && result2.typeOfHit == RayTraceResult.Type.BLOCK && isAcceptablePlacement(result2.getBlockPos().offset(result2.sideHit), layerY) && realEyes.distanceTo(result2.hitVec) <= 4.4) {
                result = result2;
            }
        }
        if (result == null || result.typeOfHit != RayTraceResult.Type.BLOCK || !isAcceptablePlacement(result.getBlockPos().offset(result.sideHit), layerY) || (result.hitVec != null && realEyes.distanceTo(result.hitVec) > 4.4)) {
            Vec3d midEyes = new Vec3d((realEyes.xCoord + estEyes.xCoord) * 0.5, (realEyes.yCoord + estEyes.yCoord) * 0.5, (realEyes.zCoord + estEyes.zCoord) * 0.5);
            Vec3d end3 = midEyes.addVector(look.xCoord * reach, look.yCoord * reach, look.zCoord * reach);
            RayTraceResult result3 = mc.world.rayTraceBlocks(midEyes, end3, false, false, false);
            if (result3 != null && result3.typeOfHit == RayTraceResult.Type.BLOCK && result3.getBlockPos().offset(result3.sideHit).equals(target) && midEyes.distanceTo(result3.hitVec) <= 4.4) {
                result = result3;
            }
        }
        if (result != null && result.typeOfHit == RayTraceResult.Type.BLOCK) {
            BlockPos clicked = result.getBlockPos();
            EnumFacing face = result.sideHit;
            BlockPos placed = clicked.offset(face);
            if (isAcceptablePlacement(placed, layerY) && BlockUtils.isSolid(clicked)) {
                pendingClickedBlock = clicked;
                pendingFace = face;
                pendingHitVec = result.hitVec;
                pendingPlacePos = placed;
                pendingLayerY = layerY;
                return true;
            }
        }
        return false;
    }

    public static boolean executePreMovement() {
        if (mc.player == null || mc.world == null) {
            clearPending();
            return false;
        }
        if (pendingClickedBlock == null || pendingFace == null || pendingPlacePos == null) {
            return false;
        }
        Vec3d eyes = RotationUtils.getEyesPos();
        double reach = 4.4;
        RayTraceResult r = rayFromRotation(eyes, mc.player.rotationYaw, mc.player.rotationPitch, reach);
        RayTraceResult chosen = null;
        BlockPos freshPlaced = (r != null) ? r.getBlockPos().offset(r.sideHit) : null;
        if (freshPlaced != null && isAcceptablePlacement(freshPlaced, pendingLayerY)) {
            chosen = r;
        } else {
            chosen = compliantAnchorClick(eyes);
        }
        if (chosen == null) {
            return false;
        }
        BlockPos clicked = chosen.getBlockPos();
        EnumFacing face = chosen.sideHit;
        BlockPos placed = clicked.offset(face);
        if (!BlockUtils.isSolid(clicked)) {
            clearPending();
            return false;
        }
        boolean airborneCatchCell = !mc.player.onGround && placed.getY() <= (int) Math.floor(mc.player.posY);
        AxisAlignedBB blockBB = new AxisAlignedBB(placed);
        if (!airborneCatchCell && blockBB.intersectsWith(mc.player.getEntityBoundingBox().expand(-0.05, -0.05, -0.05))) {
            clearPending();
            return false;
        }
        boolean sinkingCatchWindow = !mc.player.onGround && !(mc.player.motionY > 0.05 || mc.player.posY > pendingLayerY + 2.05);
        boolean gateAlreadyDeferred = gateDeferredPending != null && gateDeferredPending.equals(pendingPlacePos);
        if (!sinkingCatchWindow && !gateAlreadyDeferred) {
            float repYaw = mc.player.getLastReportedYaw();
            float repPitch = mc.player.getLastReportedPitch();
            Vec3d repLook = RotationUtils.getLookVec(repYaw, repPitch);
            Vec3d repEnd = eyes.addVector(repLook.xCoord * reach, repLook.yCoord * reach, repLook.zCoord * reach);
            RayTraceResult repRay = mc.world.rayTraceBlocks(eyes, repEnd, false, false, false);
            boolean serverRotationSeesClick = repRay != null && repRay.typeOfHit == RayTraceResult.Type.BLOCK && repRay.getBlockPos().equals(clicked);
            if (!serverRotationSeesClick) {
                gateDeferredPending = pendingPlacePos;
                return false;
            }
        }
        gateDeferredPending = null;
        Vec3d cursor = clampToFaceInterior(chosen.hitVec, clicked, face);
        BlockUtils.markPlaced(placed);
        mc.playerController.processRightClickBlock(mc.player, mc.world, clicked, face, cursor, EnumHand.MAIN_HAND);
        clearPending();
        return true;
    }

    private static RayTraceResult rayFromRotation(Vec3d eyes, float yaw, float pitch, double reach) {
        Vec3d look = RotationUtils.getLookVec(yaw, pitch);
        Vec3d end = eyes.addVector(look.xCoord * reach, look.yCoord * reach, look.zCoord * reach);
        RayTraceResult hit = mc.world.rayTraceBlocks(eyes, end, false, false, false);
        if (hit == null || hit.typeOfHit != RayTraceResult.Type.BLOCK || hit.hitVec == null || eyes.distanceTo(hit.hitVec) > reach) {
            return null;
        }
        return hit;
    }

    private static RayTraceResult compliantAnchorClick(Vec3d eyes) {
        if (pendingPlacePos == null || mc.player == null || mc.world == null) {
            return null;
        }
        EnumFacing[] order = new EnumFacing[EnumFacing.values().length];
        int n = 0;
        if (pendingFace != null) {
            order[n++] = pendingFace;
        }
        for (EnumFacing f : EnumFacing.values()) {
            if (f != pendingFace) {
                order[n++] = f;
            }
        }
        for (int i = 0; i < n; i++) {
            EnumFacing f = order[i];
            BlockPos anchor = pendingPlacePos.offset(f.getOpposite());
            if (!BlockUtils.isSolid(anchor)) {
                continue;
            }
            AxisAlignedBB box = new AxisAlignedBB(anchor);
            if (!positionPlaceSafe(box, f)) {
                continue;
            }
            if (!farPlaceSafe(eyes, box)) {
                continue;
            }
            if (!rotationSeesAnchor(eyes, mc.player.rotationYaw, mc.player.rotationPitch, box)) {
                continue;
            }
            return armedHit(anchor, f);
        }
        return null;
    }

    private static RayTraceResult armedHit(BlockPos anchor, EnumFacing f) {
        Vec3d basis = (f == pendingFace && pendingHitVec != null) ? pendingHitVec : new Vec3d(anchor.getX() + 0.5 + f.getFrontOffsetX() * 0.5, anchor.getY() + 0.5 + f.getFrontOffsetY() * 0.5, anchor.getZ() + 0.5 + f.getFrontOffsetZ() * 0.5);
        return new RayTraceResult(basis, f, anchor);
    }

    private static boolean positionPlaceSafe(AxisAlignedBB box, EnumFacing face) {
        final double mt = 0.03;
        double px = mc.player.posX;
        double py = mc.player.posY;
        double pz = mc.player.posZ;
        double eyeMinY = py + 0.4 - mt;
        double eyeMaxY = py + 1.62 + mt;
        double eyeMinX = px - mt;
        double eyeMaxX = px + mt;
        double eyeMinZ = pz - mt;
        double eyeMaxZ = pz + mt;
        if (eyeMaxX > box.minX && eyeMinX < box.maxX && eyeMaxY > box.minY && eyeMinY < box.maxY && eyeMaxZ > box.minZ && eyeMinZ < box.maxZ) {
            return true;
        }
        switch(face) {
            case UP:
                return !(eyeMaxY < box.maxY);
            case DOWN:
                return !(eyeMinY > box.minY);
            case NORTH:
                return !(eyeMinZ > box.minZ);
            case SOUTH:
                return !(eyeMaxZ < box.maxZ);
            case WEST:
                return !(eyeMinX > box.minX);
            case EAST:
                return !(eyeMaxX < box.maxX);
            default:
                return false;
        }
    }

    private static boolean farPlaceSafe(Vec3d eyes, AxisAlignedBB box) {
        double cx = Math.max(box.minX, Math.min(box.maxX, eyes.xCoord));
        double cy = Math.max(box.minY, Math.min(box.maxY, eyes.yCoord));
        double cz = Math.max(box.minZ, Math.min(box.maxZ, eyes.zCoord));
        double dx = eyes.xCoord - cx;
        double dy = eyes.yCoord - cy;
        double dz = eyes.zCoord - cz;
        return dx * dx + dy * dy + dz * dz <= 4.45 * 4.45;
    }

    public static boolean isVanillaBlockClickGrimSafe(BlockPos clicked, EnumFacing face) {
        if (mc.player == null || mc.world == null || clicked == null || face == null) {
            return true;
        }
        AxisAlignedBB box = new AxisAlignedBB(clicked);
        if (!positionPlaceSafe(box, face)) {
            return false;
        }
        if (!farPlaceSafe(RotationUtils.getEyesPos(), box)) {
            return false;
        }
        return true;
    }

    private static boolean rotationSeesAnchor(Vec3d eyes, float yaw, float pitch, AxisAlignedBB box) {
        if (eyes.xCoord > box.minX && eyes.xCoord < box.maxX && eyes.yCoord > box.minY && eyes.yCoord < box.maxY && eyes.zCoord > box.minZ && eyes.zCoord < box.maxZ) {
            return true;
        }
        Vec3d look = RotationUtils.getLookVec(yaw, pitch);
        Vec3d end = eyes.addVector(look.xCoord * 4.5, look.yCoord * 4.5, look.zCoord * 4.5);
        return box.calculateIntercept(eyes, end) != null;
    }

    private static Vec3d clampToFaceInterior(Vec3d hit, BlockPos pos, EnumFacing face) {
        double x = hit.xCoord - pos.getX();
        double y = hit.yCoord - pos.getY();
        double z = hit.zCoord - pos.getZ();
        switch(face) {
            case UP:
            case DOWN:
                y = face == EnumFacing.UP ? 1.0 : 0.0;
                x = clamp01(x);
                z = clamp01(z);
                break;
            case NORTH:
            case SOUTH:
                z = face == EnumFacing.SOUTH ? 1.0 : 0.0;
                x = clamp01(x);
                y = clamp01(y);
                break;
            case EAST:
            case WEST:
            default:
                x = face == EnumFacing.EAST ? 1.0 : 0.0;
                y = clamp01(y);
                z = clamp01(z);
                break;
        }
        return new Vec3d(pos.getX() + x, pos.getY() + y, pos.getZ() + z);
    }

    private static double clamp01(double v) {
        return Math.max(0.02, Math.min(0.98, v));
    }

    public static void execute() {
        if (mc.player == null || mc.world == null || pendingClickedBlock == null) {
            clearPending();
            return;
        }
        if (pendingPlacePos != null) {
            BlockUtils.markPlaced(pendingPlacePos);
        }
        mc.playerController.processRightClickBlock(mc.player, mc.world, pendingClickedBlock, pendingFace, pendingHitVec, EnumHand.MAIN_HAND);
        clearPending();
    }

    public static void restore() {
    }

    public static void restoreAndIdle() {
        rotationActive = false;
        streakHeld = false;
        previousTarget = null;
        if (!SilentAimUtil.isOwnedBy("Scaffold"))
            return;
        if (!SilentAimUtil.isContinuous())
            return;
        if (holdExpired)
            return;
        if (holdTicksRemaining == -1) {
            holdTicksRemaining = HOLD_TICKS;
        }
        holdTicksRemaining--;
        if (holdTicksRemaining > 0) {
            SilentAimUtil.accumulateDeltas();
            if (mc.player != null) {
                mc.player.rotationYaw = SilentAimUtil.getServerYaw();
                mc.player.rotationPitch = SilentAimUtil.getServerPitch();
            }
            Client.INSTANCE.renderRotationOverride = true;
            Client.INSTANCE.renderYaw = SilentAimUtil.getRealYaw();
            Client.INSTANCE.renderPitch = SilentAimUtil.getRealPitch();
        } else {
            holdTicksRemaining = -1;
            holdExpired = true;
            SilentAimUtil.endStreak();
        }
    }

    public static void idle() {
        holdTicksRemaining = -1;
        holdExpired = false;
        previousTarget = null;
        warmTicks = 0;
        if (SilentAimUtil.isOwnedBy("Scaffold")) {
            SilentAimUtil.resetStreak();
        }
        rotationActive = false;
        streakHeld = false;
    }

    public static void keepWarm() {
        rotationActive = false;
        streakHeld = false;
        warmTicks++;
        if (!SilentAimUtil.isOwnedBy("Scaffold") || warmTicks > WARM_TICK_LIMIT || !SilentAimUtil.isContinuous()) {
            idle();
            return;
        }
        streakHeld = SilentAimUtil.holdStreakTick();
        if (streakHeld) {
            markAimSpoofed();
        }
    }

    public static boolean isActive() {
        return rotationActive;
    }

    public static boolean isAimSpoofedRecently() {
        if (mc.player == null)
            return false;
        return rotationActive || streakHeld || mc.player.ticksExisted - lastSpoofedTick <= 2;
    }

    public static float getRealYaw() {
        return SilentAimUtil.getRealYaw();
    }

    public static boolean hasPending() {
        return pendingClickedBlock != null;
    }

    public static void swing(EnumHand hand) {
        if (mc.player != null) {
            mc.player.swingArm(hand);
        }
    }

    private static float[] solveGridRotation(Vec3d aimTarget, Vec3d estEyes, BlockPos target, float realYaw, boolean useGrid) {
        float[] ideal = RotationUtils.getNeededRotations(aimTarget, estEyes);
        if (!useGrid) {
            return new float[] { ideal[0], ideal[1] };
        }
        int bestK = Math.round(RotationUtils.wrapDegrees(ideal[0] - realYaw) / 45.0f);
        for (int step = 0; step <= 4; step++) {
            int[] signs = (step == 0) ? new int[] { 0 } : new int[] { 1, -1 };
            for (int sign : signs) {
                int k = bestK + sign * step;
                float yaw = RotationUtils.wrapDegrees(realYaw + 45.0f * k);
                for (int dp = 0; dp <= 12; dp += 4) {
                    int[] pitchSigns = (dp == 0) ? new int[] { 0 } : new int[] { 1, -1 };
                    for (int ps : pitchSigns) {
                        float pitch = RotationUtils.clamp(ideal[1] + ps * dp, -90.0f, 90.0f);
                        if (rayFillsTarget(estEyes, yaw, pitch, target)) {
                            return new float[] { yaw, pitch };
                        }
                    }
                }
            }
        }
        return new float[] { RotationUtils.wrapDegrees(realYaw + 45.0f * bestK), ideal[1] };
    }

    private static boolean rayFillsTarget(Vec3d eyes, float yaw, float pitch, BlockPos target) {
        if (mc.world == null)
            return false;
        Vec3d look = RotationUtils.getLookVec(yaw, pitch);
        double reach = 4.4;
        Vec3d end = eyes.addVector(look.xCoord * reach, look.yCoord * reach, look.zCoord * reach);
        RayTraceResult r = mc.world.rayTraceBlocks(eyes, end, false, false, false);
        return r != null && r.typeOfHit == RayTraceResult.Type.BLOCK && r.hitVec != null && eyes.distanceTo(r.hitVec) <= reach && r.getBlockPos().offset(r.sideHit).equals(target);
    }

    private static void clearPending() {
        pendingClickedBlock = null;
        pendingFace = null;
        pendingHitVec = null;
        pendingPlacePos = null;
        pendingLayerY = Integer.MIN_VALUE;
        gateDeferredPending = null;
    }

    private static BlockPos parkArmCell(Vec3d eyes, Vec3d look, int layerY) {
        if (mc.player == null || mc.world == null || eyes == null) {
            return null;
        }
        Vec3d end = eyes.addVector(look.xCoord * 4.4, look.yCoord * 4.4, look.zCoord * 4.4);
        RayTraceResult r = mc.world.rayTraceBlocks(eyes, end, false, false, false);
        if (r == null || r.typeOfHit != RayTraceResult.Type.BLOCK) {
            return null;
        }
        BlockPos placed = r.getBlockPos().offset(r.sideHit);
        if (!isAcceptablePlacement(placed, layerY)) {
            return null;
        }
        if (r.hitVec != null && eyes.distanceTo(r.hitVec) > 4.4) {
            return null;
        }
        return r.getBlockPos();
    }

    private static boolean isAcceptablePlacement(BlockPos placed, int layerY) {
        if (placed == null || layerY == Integer.MIN_VALUE)
            return false;
        if (mc.player == null || mc.world == null)
            return false;
        if (mc.player.onGround) {
            if (placed.getY() != layerY)
                return false;
        } else {
            BlockPos ownLayerCell = new BlockPos((int) Math.floor(mc.player.posX), layerY, (int) Math.floor(mc.player.posZ));
            boolean overHole = mc.world.getBlockState(ownLayerCell).getMaterial().isReplaceable();
            if (overHole) {
                int feetCell = (int) Math.floor(mc.player.posY);
                boolean soaring = mc.player.motionY > 0.05 || mc.player.posY > layerY + 2.05;
                if (soaring) {
                    if (placed.getY() != layerY)
                        return false;
                } else {
                    int bandLow = Math.min(layerY, feetCell);
                    if (placed.getY() < bandLow || placed.getY() > layerY) {
                        return false;
                    }
                }
            } else {
                if (placed.getY() != layerY)
                    return false;
            }
        }
        if (!mc.world.getBlockState(placed).getMaterial().isReplaceable()) {
            return false;
        }
        double dx = placed.getX() + 0.5 - mc.player.posX;
        double dz = placed.getZ() + 0.5 - mc.player.posZ;
        double radiusSq = mc.player.onGround ? 6.25 : 20.25;
        return dx * dx + dz * dz <= radiusSq;
    }
}
