package client.utils.world;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;
import java.util.HashMap;
import java.util.Map;

public final class EnchantmentUtil {

    private EnchantmentUtil() {
    }

    public static int getSharpness(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return 0;
        return EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, stack);
    }

    public static int getSmite(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return 0;
        return EnchantmentHelper.getEnchantmentLevel(Enchantments.SMITE, stack);
    }

    public static int getBaneOfArthropods(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return 0;
        return EnchantmentHelper.getEnchantmentLevel(Enchantments.BANE_OF_ARTHROPODS, stack);
    }

    public static int getFireAspect(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return 0;
        return EnchantmentHelper.getEnchantmentLevel(Enchantments.FIRE_ASPECT, stack);
    }

    public static int getKnockback(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return 0;
        return EnchantmentHelper.getEnchantmentLevel(Enchantments.KNOCKBACK, stack);
    }

    public static int getProtection(EntityLivingBase entity) {
        return EnchantmentHelper.getMaxEnchantmentLevel(Enchantments.PROTECTION, entity);
    }

    public static int getFeatherFalling(EntityLivingBase entity) {
        return EnchantmentHelper.getMaxEnchantmentLevel(Enchantments.FEATHER_FALLING, entity);
    }

    public static Map<Enchantment, Integer> getEnchantments(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return new HashMap<>();
        return EnchantmentHelper.getEnchantments(stack);
    }

    public static float getEnchantmentDamage(ItemStack stack, net.minecraft.entity.EnumCreatureAttribute creatureAttribute) {
        if (stack == null || stack.func_190926_b())
            return 0;
        return EnchantmentHelper.getModifierForCreature(stack, creatureAttribute);
    }
}
