package client.utils.world;

import net.minecraft.network.PacketBuffer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.client.CPacketCloseWindow;
import net.minecraft.network.play.client.CPacketCustomPayload;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketTabComplete;
import net.minecraft.client.Minecraft;

public final class PacketUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private PacketUtils() {
    }

    public static void send(Packet<?> packet) {
        if (mc.player != null && mc.player.connection != null) {
            mc.player.connection.sendPacket(packet);
        }
    }

    public static void sendPosition(double x, double y, double z, boolean onGround) {
        send(new CPacketPlayer.Position(x, y, z, onGround));
    }

    public static void sendRotation(float yaw, float pitch, boolean onGround) {
        send(new CPacketPlayer.Rotation(yaw, pitch, onGround));
    }

    public static void sendPositionRotation(double x, double y, double z, float yaw, float pitch, boolean onGround) {
        send(new CPacketPlayer.PositionRotation(x, y, z, yaw, pitch, onGround));
    }

    public static void sendGround(boolean onGround) {
        send(new CPacketPlayer(onGround));
    }

    public static void sendEntityAction(Entity entity, CPacketEntityAction.Action action) {
        send(new CPacketEntityAction(entity, action));
    }

    public static void sendHeldItemChange(int slot) {
        send(new CPacketHeldItemChange(slot));
    }

    public static void sendCloseWindow(int windowId) {
        send(new CPacketCloseWindow(windowId));
    }

    public static void sendChatMessage(String message) {
        send(new CPacketChatMessage(message));
    }

    public static void sendCustomPayload(String channel, PacketBuffer payload) {
        send(new CPacketCustomPayload(channel, payload));
    }

    public static void sendTabComplete(String text, BlockPos target, boolean assumeCommand) {
        send(new CPacketTabComplete(text, target, assumeCommand));
    }
}
