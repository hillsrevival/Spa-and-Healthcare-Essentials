package client.utils.world;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.Chunk;

public final class WorldUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private WorldUtils() {
    }

    public static Block getBlock(int x, int y, int z) {
        if (mc.world == null || y < 0 || y > 255)
            return Blocks.AIR;
        return mc.world.getBlockState(new BlockPos(x, y, z)).getBlock();
    }

    public static Block getBlock(BlockPos pos) {
        if (pos == null || mc.world == null)
            return Blocks.AIR;
        return getBlock(pos.x, pos.y, pos.z);
    }

    public static IBlockState getState(int x, int y, int z) {
        if (mc.world == null || y < 0 || y > 255)
            return null;
        return mc.world.getBlockState(new BlockPos(x, y, z));
    }

    public static IBlockState getState(BlockPos pos) {
        if (pos == null || mc.world == null)
            return null;
        return getState(pos.x, pos.y, pos.z);
    }

    public static boolean isAir(int x, int y, int z) {
        if (mc.world == null || y < 0 || y > 255)
            return true;
        return mc.world.isAirBlock(new BlockPos(x, y, z));
    }

    public static boolean isAir(BlockPos pos) {
        if (pos == null)
            return true;
        return isAir(pos.x, pos.y, pos.z);
    }

    public static boolean isSolid(int x, int y, int z) {
        if (y < 0 || y > 255)
            return true;
        if (mc.world == null)
            return true;
        if (mc.world.isAirBlock(new BlockPos(x, y, z)))
            return false;
        return mc.world.getBlockState(new BlockPos(x, y, z)).getMaterial().isSolid();
    }

    public static boolean isSolid(BlockPos pos) {
        if (pos == null)
            return true;
        return isSolid(pos.x, pos.y, pos.z);
    }

    public static boolean isReplaceable(int x, int y, int z) {
        if (mc.world == null || y < 0 || y > 255)
            return false;
        return mc.world.getBlockState(new BlockPos(x, y, z)).getMaterial().isReplaceable();
    }

    public static boolean isReplaceable(BlockPos pos) {
        if (pos == null)
            return false;
        return isReplaceable(pos.x, pos.y, pos.z);
    }

    public static boolean isWater(int x, int y, int z) {
        Block b = getBlock(x, y, z);
        return b == Blocks.WATER || b == Blocks.FLOWING_WATER;
    }

    public static boolean isLava(int x, int y, int z) {
        Block b = getBlock(x, y, z);
        return b == Blocks.LAVA || b == Blocks.FLOWING_LAVA;
    }

    public static boolean isLiquid(int x, int y, int z) {
        if (mc.world == null || y < 0 || y > 255)
            return false;
        Material mat = mc.world.getBlockState(new BlockPos(x, y, z)).getMaterial();
        return mat.isLiquid();
    }

    public static boolean isClearVertical(int x, int fromY, int toY, int z) {
        int minY = Math.min(fromY, toY);
        int maxY = Math.max(fromY, toY);
        for (int y = minY; y <= maxY; y++) {
            if (!isAir(x, y, z))
                return false;
        }
        return true;
    }

    public static float getBlockHardness(BlockPos pos) {
        if (mc.world == null || pos == null)
            return -1.0f;
        IBlockState state = mc.world.getBlockState(pos);
        return state.getBlockHardness(mc.world, pos);
    }

    public static Chunk getChunk(int cx, int cz) {
        if (mc.world == null)
            return null;
        Chunk chunk = mc.world.getChunkFromChunkCoords(cx, cz);
        if (chunk != null && !chunk.isEmpty() && chunk.isLoaded()) {
            return chunk;
        }
        return null;
    }
}
