package client.utils.world;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import java.util.Locale;

public class MaceUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    public static final double MAX_GRIM_REACH = 3.03;

    private static final String MACE_VB_TAG = "VB|Protocol1_20_5To1_20_3|id";

    private static final int MACE_VB_ID = 1093;

    private static final String WIND_CHARGE_VB_TAG = "VB|Protocol1_20_5To1_20_3|id";

    private static final int WIND_CHARGE_VB_ID = 1090;

    public static int findMaceSlot() {
        if (mc.player == null)
            return -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == null || stack.func_190926_b())
                continue;
            if (isMace(stack)) {
                return i;
            }
        }
        return -1;
    }

    public static boolean isMaceSlot(int slot) {
        if (mc.player == null || slot < 0 || slot > 8)
            return false;
        ItemStack stack = mc.player.inventory.getStackInSlot(slot);
        if (stack == null || stack.func_190926_b())
            return false;
        return isMace(stack);
    }

    public static boolean isMaceOffhand() {
        if (mc.player == null)
            return false;
        ItemStack stack = mc.player.getHeldItemOffhand();
        if (stack == null || stack.func_190926_b())
            return false;
        return isMace(stack);
    }

    private static boolean isMace(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return false;
        NBTTagCompound tag = stack.getTagCompound();
        if (tag != null && tag.hasKey(MACE_VB_TAG, 99)) {
            int id = tag.getInteger(MACE_VB_TAG);
            if (id == MACE_VB_ID)
                return true;
        }
        String displayName = stack.getDisplayName();
        if (displayName == null)
            return false;
        displayName = displayName.toLowerCase(Locale.ROOT);
        return displayName.contains("mace");
    }

    public static int findWindChargeSlot() {
        if (mc.player == null)
            return -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == null || stack.func_190926_b())
                continue;
            if (isWindCharge(stack)) {
                return i;
            }
        }
        return -1;
    }

    public static boolean isWindCharge(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return false;
        NBTTagCompound tag = stack.getTagCompound();
        if (tag != null && tag.hasKey(WIND_CHARGE_VB_TAG, 99)) {
            int id = tag.getInteger(WIND_CHARGE_VB_TAG);
            if (id == WIND_CHARGE_VB_ID)
                return true;
        }
        String displayName = stack.getDisplayName();
        if (displayName == null)
            return false;
        displayName = displayName.toLowerCase(Locale.ROOT);
        return displayName.contains("wind charge");
    }

    public static int findShieldSlot() {
        if (mc.player == null)
            return -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == null || stack.func_190926_b())
                continue;
            if (stack.getItem() == Items.SHIELD) {
                return i;
            }
        }
        return -1;
    }
}
