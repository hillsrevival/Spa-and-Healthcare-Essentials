package client.utils.world;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public final class SpearUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private SpearUtils() {
    }

    public static boolean isSpear(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return false;
        String name = stack.getDisplayName();
        return name != null && name.toLowerCase().contains("spear");
    }

    public static int findSpearSlot() {
        if (mc.player == null)
            return -1;
        for (int i = 0; i < 9; i++) {
            if (isSpear(mc.player.inventory.getStackInSlot(i)))
                return i;
        }
        return -1;
    }

    public static boolean holdingSpear() {
        return mc.player != null && isSpear(mc.player.inventory.getStackInSlot(mc.player.inventory.currentItem));
    }

    public static double distanceTo(EntityPlayer p) {
        double dx = p.posX - mc.player.posX;
        double dy = (p.posY + p.height * 0.5) - (mc.player.posY + mc.player.getEyeHeight());
        double dz = p.posZ - mc.player.posZ;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public static EntityPlayer nearestPlayer(double range) {
        if (mc.player == null || mc.world == null)
            return null;
        EntityPlayer best = null;
        double bestDist = range;
        for (EntityPlayer p : mc.world.playerEntities) {
            if (p == null || p == mc.player || p.isDead)
                continue;
            double d = distanceTo(p);
            if (d <= bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }
}
