package client.utils.world;

import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumHand;

/**
 * Shared "fire a wind charge straight down" sequence used by several modules.
 * Phase 1 aims down, phase 2 fires, phase 3 restores slot and pitch.
 * tick() is idempotent per game tick so more than one module may call it.
 */
public final class WindFire {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static int phase = 0;
    private static boolean jumpFirst = false;
    private static int slotAfter = -1;
    private static int savedSlot = -1;
    private static float savedPitch = 0.0f;
    private static int lastTick = -1;
    private static Object owner = null;

    private WindFire() {
    }

    public static boolean isBusy() {
        return phase != 0;
    }

    public static boolean begin(boolean jump, int selectAfterSlot) {
        return begin(jump, selectAfterSlot, null);
    }

    public static boolean begin(boolean jump, int selectAfterSlot, Object requester) {
        if (phase != 0 || mc.player == null || mc.world == null)
            return false;
        if (MaceUtils.findWindChargeSlot() == -1)
            return false;
        jumpFirst = jump;
        slotAfter = selectAfterSlot;
        savedSlot = mc.player.inventory.currentItem;
        savedPitch = mc.player.rotationPitch;
        owner = requester;
        lastTick = -1;
        phase = 1;
        return true;
    }

    /**
     * Instant version: sends a straight-down rotation packet, uses the wind charge in the same tick
     * (optionally jumping), then returns your hotbar slot. The camera never moves.
     */
    public static boolean fireNow(boolean jump, int selectAfterSlot) {
        if (mc.player == null || mc.world == null)
            return false;
        int slot = MaceUtils.findWindChargeSlot();
        if (slot == -1)
            return false;
        int prev = mc.player.inventory.currentItem;
        PacketUtils.sendRotation(mc.player.rotationYaw, 90.0f, mc.player.onGround);
        mc.player.inventory.currentItem = slot;
        InteractionUtils.useItem(EnumHand.MAIN_HAND);
        mc.player.swingArm(EnumHand.MAIN_HAND);
        if (jump && mc.player.onGround)
            mc.player.jump();
        int back = (selectAfterSlot >= 0 && selectAfterSlot < 9) ? selectAfterSlot : prev;
        mc.player.inventory.currentItem = back;
        return true;
    }

    public static void abort() {
        if (phase != 0)
            finish();
    }

    public static void abort(Object requester) {
        if (phase != 0 && owner == requester)
            finish();
    }

    public static void tick() {
        tick(null);
    }

    public static void tick(Object requester) {
        if (phase == 0 || owner != requester)
            return;
        if (mc.player == null || mc.world == null) {
            reset();
            return;
        }
        if (mc.player.ticksExisted == lastTick)
            return;
        lastTick = mc.player.ticksExisted;
        switch(phase) {
            case 1:
                mc.player.rotationPitch = 90.0f;
                phase = 2;
                break;
            case 2:
                int chargeSlot = MaceUtils.findWindChargeSlot();
                if (chargeSlot == -1) {
                    finish();
                    return;
                }
                mc.player.rotationPitch = 90.0f;
                if (jumpFirst && mc.player.onGround)
                    mc.player.jump();
                mc.player.inventory.currentItem = chargeSlot;
                InteractionUtils.useItem(EnumHand.MAIN_HAND);
                mc.player.swingArm(EnumHand.MAIN_HAND);
                phase = 3;
                break;
            default:
                finish();
                break;
        }
    }

    private static void finish() {
        if (mc.player != null) {
            int target = (slotAfter >= 0 && slotAfter < 9) ? slotAfter : savedSlot;
            if (target >= 0 && target < 9)
                mc.player.inventory.currentItem = target;
            mc.player.rotationPitch = savedPitch;
        }
        reset();
    }

    private static void reset() {
        phase = 0;
        jumpFirst = false;
        slotAfter = -1;
        savedSlot = -1;
        savedPitch = 0.0f;
        lastTick = -1;
        owner = null;
    }
}
