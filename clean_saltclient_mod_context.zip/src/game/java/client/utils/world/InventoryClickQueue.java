package client.utils.world;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.inventory.ClickType;
import java.util.ArrayDeque;
import java.util.Queue;

public final class InventoryClickQueue {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final Queue<PendingClick> queue = new ArrayDeque<>();

    private static long clickDelayMs = 100;

    private static long lastClickTime = 0;

    private static boolean processing = false;

    private InventoryClickQueue() {
    }

    public static void setClickDelay(long delayMs) {
        clickDelayMs = Math.max(50, delayMs);
    }

    public static long getClickDelay() {
        return clickDelayMs;
    }

    public static void click(int slot) {
        queue.add(new PendingClick(slot, 0, 0, ClickAction.CLICK));
    }

    public static void shiftClick(int slot) {
        queue.add(new PendingClick(slot, 0, 1, ClickAction.SHIFT_CLICK));
    }

    public static void swap(int sourceSlot, int targetSlot) {
        queue.add(new PendingClick(sourceSlot, 0, 0, ClickAction.CLICK));
        queue.add(new PendingClick(targetSlot, 0, 0, ClickAction.CLICK));
    }

    public static void dropSlot(int slot) {
        queue.add(new PendingClick(slot, 0, 4, ClickAction.DROP_SLOT));
    }

    public static void dropMouseStack() {
        queue.add(new PendingClick(-999, 0, 0, ClickAction.DROP_MOUSE_STACK));
    }

    public static void clear() {
        queue.clear();
        processing = false;
    }

    public static int pendingCount() {
        return queue.size();
    }

    public static boolean hasPending() {
        return !queue.isEmpty();
    }

    public static void tick() {
        if (mc.player == null || mc.playerController == null) {
            clear();
            return;
        }
        if (queue.isEmpty()) {
            processing = false;
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastClickTime < clickDelayMs) {
            return;
        }
        PendingClick click = queue.poll();
        if (click != null) {
            executeClick(click);
            lastClickTime = now;
            processing = true;
        }
    }

    private static void executeClick(PendingClick click) {
        if (mc.player == null || mc.playerController == null)
            return;
        int windowId = mc.player.inventoryContainer.windowId;
        if (windowId == -1)
            return;
        ClickType clickType;
        switch(click.clickMode) {
            case 0:
                clickType = ClickType.PICKUP;
                break;
            case 1:
                clickType = ClickType.QUICK_MOVE;
                break;
            case 4:
                clickType = ClickType.THROW;
                break;
            default:
                clickType = ClickType.PICKUP;
                break;
        }
        try {
            mc.playerController.windowClick(windowId, click.slotId, click.mouseButton, clickType, mc.player);
        } catch (Exception e) {
        }
    }

    private enum ClickAction {

        CLICK, SHIFT_CLICK, DROP_SLOT, DROP_MOUSE_STACK
    }

    private static class PendingClick {

        final int slotId;

        final int mouseButton;

        final int clickMode;

        final ClickAction type;

        PendingClick(int slotId, int mouseButton, int clickMode, ClickAction type) {
            this.slotId = slotId;
            this.mouseButton = mouseButton;
            this.clickMode = clickMode;
            this.type = type;
        }
    }
}
