package client.utils.world;

import net.minecraft.block.Block;
import net.minecraft.block.BlockFalling;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;

public class BlockUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final int PLACE_TRACK_TICKS = 3;

    private static final LinkedHashMap<BlockPos, Integer> placedPositions = new LinkedHashMap<BlockPos, Integer>() {

        @Override
        protected boolean removeEldestEntry(Map.Entry<BlockPos, Integer> eldest) {
            return size() > 20;
        }
    };

    private static int currentTick = 0;

    private BlockUtils() {
    }

    public static void tickPlacements() {
        currentTick++;
        placedPositions.entrySet().removeIf(e -> (currentTick - e.getValue()) >= PLACE_TRACK_TICKS);
    }

    public static void markPlaced(BlockPos pos) {
        placedPositions.put(pos, currentTick);
    }

    public static boolean wasRecentlyPlaced(BlockPos pos) {
        Integer tick = placedPositions.get(pos);
        return tick != null && (currentTick - tick) < PLACE_TRACK_TICKS;
    }

    @Deprecated
    public static BlockPos getLastPlacedPos() {
        if (placedPositions.isEmpty())
            return null;
        Map.Entry<BlockPos, Integer> last = null;
        for (Map.Entry<BlockPos, Integer> e : placedPositions.entrySet()) {
            last = e;
        }
        return last != null ? last.getKey() : null;
    }

    public static void clearPlaced() {
        placedPositions.clear();
    }

    public static boolean isSolid(BlockPos pos) {
        try {
            return mc.world.isBlockFullCube(pos);
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean hasSolidNeighbor(BlockPos pos) {
        for (EnumFacing f : EnumFacing.values()) {
            if (isSolid(pos.offset(f)))
                return true;
        }
        return false;
    }

    public static EnumFacing findPlaceableSide(BlockPos pos) {
        for (EnumFacing facing : EnumFacing.values()) {
            if (!WorldUtils.isAir(pos.offset(facing))) {
                return facing;
            }
        }
        return null;
    }

    public static Vec3d faceCenter(BlockPos neighbor, EnumFacing toward) {
        return new Vec3d(neighbor.x + 0.5 + toward.getFrontOffsetX() * 0.5, neighbor.y + 0.5 + toward.getFrontOffsetY() * 0.5, neighbor.z + 0.5 + toward.getFrontOffsetZ() * 0.5);
    }

    public static int findBlockSlot() {
        int bestSlot = -1;
        int bestCount = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == null || stack.func_190926_b())
                continue;
            if (!(stack.getItem() instanceof ItemBlock))
                continue;
            Block block = Block.getBlockFromItem(stack.getItem());
            if (block == null || block == Blocks.AIR)
                continue;
            if (!block.getDefaultState().isFullBlock())
                continue;
            if (block instanceof BlockFalling)
                continue;
            if (block == Blocks.TNT || block == Blocks.WEB || block == Blocks.PORTAL || block == Blocks.END_PORTAL || block == Blocks.FLOWING_LAVA || block == Blocks.LAVA)
                continue;
            int count = stack.func_190916_E();
            if (count > bestCount) {
                bestCount = count;
                bestSlot = i;
            }
        }
        return bestSlot;
    }

    public static BlockPos getPlacePosition(boolean sameY, float startY, double expand) {
        double px = mc.player.posX;
        double py = mc.player.posY;
        double pz = mc.player.posZ;
        int feetY = (int) Math.floor(py);
        int blockY = (sameY ? (int) Math.floor(startY) : feetY) - 1;
        double fx = px - Math.floor(px);
        double fz = pz - Math.floor(pz);
        BlockPos below = new BlockPos((int) Math.floor(px), blockY, (int) Math.floor(pz));
        if (!mc.player.onGround) {
            BlockPos edgeTarget = new BlockPos((int) Math.floor(px), blockY, (int) Math.floor(pz));
            if (mc.world.getBlockState(edgeTarget).getMaterial().isReplaceable() && hasSolidNeighbor(edgeTarget)) {
                return edgeTarget;
            }
            BlockPos feetTarget = new BlockPos((int) Math.floor(px), blockY + 1, (int) Math.floor(pz));
            if (mc.player.posY < blockY + 1.05 && mc.world.getBlockState(feetTarget).getMaterial().isReplaceable() && hasSolidNeighbor(feetTarget)) {
                return feetTarget;
            }
            BlockPos catchCell = findKnockbackCatchCell(px, pz, blockY);
            if (catchCell != null) {
                return catchCell;
            }
        }
        BlockPos ahead = getPlacePosInMoveDir(blockY);
        if (ahead != null && (mc.player.onGround || hasHorizontalSolidNeighbor(ahead))) {
            return ahead;
        }
        if (mc.player.onGround && mc.world.getBlockState(below).getMaterial().isReplaceable() && hasSolidNeighbor(below)) {
            return below;
        }
        if (mc.world.getBlockState(below).getMaterial().isReplaceable()) {
            return below;
        }
        double highThreshold = 1.0 - expand;
        double lowThreshold = expand;
        BlockPos[] edges = { fx < highThreshold ? below.west() : null, fx > lowThreshold ? below.east() : null, fz < highThreshold ? below.north() : null, fz > lowThreshold ? below.south() : null, (fx < highThreshold && fz < highThreshold) ? below.west().north() : null, (fx > lowThreshold && fz < highThreshold) ? below.east().north() : null, (fx < highThreshold && fz > lowThreshold) ? below.west().south() : null, (fx > lowThreshold && fz > lowThreshold) ? below.east().south() : null };
        for (BlockPos edge : edges) {
            if (edge != null && mc.world.getBlockState(edge).getMaterial().isReplaceable() && hasSolidNeighbor(edge) && isSolid(edge.down())) {
                return edge;
            }
        }
        {
            float fwd = (mc.gameSettings.keyBindForward.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindBack.isKeyDown() ? 1 : 0);
            float str = (mc.gameSettings.keyBindLeft.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindRight.isKeyDown() ? 1 : 0);
            if (fwd != 0.0f || str != 0.0f) {
                float yaw = BlockPlacementUtil.isActive() ? BlockPlacementUtil.getRealYaw() : mc.player.rotationYaw;
                float yawRad = yaw * 0.017453292f;
                double dirX = str * Math.cos(yawRad) - fwd * Math.sin(yawRad);
                double dirZ = fwd * Math.cos(yawRad) + str * Math.sin(yawRad);
                double mag = Math.sqrt(dirX * dirX + dirZ * dirZ);
                if (mag > 0.01) {
                    dirX /= mag;
                    dirZ /= mag;
                    for (double dist = 1.0; dist <= 2.0; dist += 1.0) {
                        BlockPos aheadPos = new BlockPos((int) Math.floor(px + dirX * dist), blockY, (int) Math.floor(pz + dirZ * dist));
                        if (mc.world.getBlockState(aheadPos).getMaterial().isReplaceable() && (mc.player.onGround || hasHorizontalSolidNeighbor(aheadPos))) {
                            return aheadPos;
                        }
                    }
                }
            }
        }
        return null;
    }

    private static BlockPos findKnockbackCatchCell(double px, double pz, int blockY) {
        int cx = (int) Math.floor(px);
        int cz = (int) Math.floor(pz);
        for (int pass = 1; pass <= 2; pass++) {
            BlockPos best = null;
            double bestDistSq = Double.MAX_VALUE;
            for (int dx = -6; dx <= 6; dx++) {
                for (int dz = -6; dz <= 6; dz++) {
                    if (dx == 0 && dz == 0)
                        continue;
                    BlockPos cell = new BlockPos(cx + dx, blockY, cz + dz);
                    if (!mc.world.getBlockState(cell).getMaterial().isReplaceable()) {
                        continue;
                    }
                    boolean clickableFromAbove = isSolid(cell.down()) || hasVisibleHorizontalSolidNeighbor(cell, px, pz);
                    boolean hasAnyFace = clickableFromAbove || isSolid(cell.up());
                    if ((pass == 1) != clickableFromAbove || !hasAnyFace) {
                        continue;
                    }
                    double ddx = cell.getX() + 0.5 - px;
                    double ddz = cell.getZ() + 0.5 - pz;
                    double distSq = ddx * ddx + ddz * ddz;
                    if (distSq < bestDistSq) {
                        bestDistSq = distSq;
                        best = cell;
                    }
                }
            }
            if (best != null) {
                return best;
            }
        }
        return null;
    }

    private static boolean hasHorizontalSolidNeighbor(BlockPos pos) {
        return isSolid(pos.north()) || isSolid(pos.south()) || isSolid(pos.east()) || isSolid(pos.west());
    }

    public static boolean isNeighborFaceVisible(BlockPos placePos, BlockPos neighbor, double px, double pz) {
        if (neighbor.getZ() == placePos.getZ() - 1) {
            return pz > neighbor.getZ() + 1.0;
        }
        if (neighbor.getZ() == placePos.getZ() + 1) {
            return pz < neighbor.getZ();
        }
        if (neighbor.getX() == placePos.getX() + 1) {
            return px < neighbor.getX();
        }
        if (neighbor.getX() == placePos.getX() - 1) {
            return px > neighbor.getX() + 1.0;
        }
        return true;
    }

    private static boolean hasVisibleHorizontalSolidNeighbor(BlockPos pos, double px, double pz) {
        EnumFacing[] horizontals = { EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.EAST, EnumFacing.WEST };
        for (EnumFacing f : horizontals) {
            BlockPos neighbor = pos.offset(f);
            if (isSolid(neighbor) && isNeighborFaceVisible(pos, neighbor, px, pz)) {
                return true;
            }
        }
        return false;
    }

    private static BlockPos getPlacePosInMoveDir(int blockY) {
        float forward = (mc.gameSettings.keyBindForward.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindBack.isKeyDown() ? 1 : 0);
        float strafe = (mc.gameSettings.keyBindLeft.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindRight.isKeyDown() ? 1 : 0);
        if (forward == 0.0f && strafe == 0.0f)
            return null;
        float yaw = BlockPlacementUtil.isActive() ? BlockPlacementUtil.getRealYaw() : mc.player.rotationYaw;
        float yawRad = yaw * 0.017453292f;
        double dirX = strafe * Math.cos(yawRad) - forward * Math.sin(yawRad);
        double dirZ = forward * Math.cos(yawRad) + strafe * Math.sin(yawRad);
        double mag = Math.sqrt(dirX * dirX + dirZ * dirZ);
        if (mag < 0.01)
            return null;
        dirX /= mag;
        dirZ /= mag;
        double px = mc.player.posX;
        double pz = mc.player.posZ;
        double aheadX = px + dirX * 1.0;
        double aheadZ = pz + dirZ * 1.0;
        BlockPos pos = new BlockPos((int) Math.floor(aheadX), blockY, (int) Math.floor(aheadZ));
        if (mc.world.getBlockState(pos).getMaterial().isReplaceable() && hasSolidNeighbor(pos)) {
            if (isSolid(pos.down())) {
                return pos;
            }
            return pos;
        }
        boolean isDiagonal = Math.abs(dirX) > 0.1 && Math.abs(dirZ) > 0.1;
        if (isDiagonal) {
            int bx = (int) Math.floor(px);
            int bz = (int) Math.floor(pz);
            int sX = dirX > 0 ? 1 : -1;
            int sZ = dirZ > 0 ? 1 : -1;
            BlockPos own = new BlockPos(bx, blockY, bz);
            if (mc.world.getBlockState(own).getMaterial().isReplaceable() && hasSolidNeighbor(own)) {
                return own;
            }
            BlockPos posZ = new BlockPos(bx, blockY, bz + sZ);
            BlockPos posX = new BlockPos(bx + sX, blockY, bz);
            double distX = dirX > 0 ? (bx + 1.0 - px) : (px - bx);
            double distZ = dirZ > 0 ? (bz + 1.0 - pz) : (pz - bz);
            BlockPos first = distX <= distZ ? posX : posZ;
            BlockPos second = distX <= distZ ? posZ : posX;
            if (mc.world.getBlockState(first).getMaterial().isReplaceable() && hasSolidNeighbor(first) && isSolid(first.down())) {
                return first;
            }
            if (mc.world.getBlockState(second).getMaterial().isReplaceable() && hasSolidNeighbor(second) && isSolid(second.down())) {
                return second;
            }
            BlockPos diagCell = new BlockPos(bx + sX, blockY, bz + sZ);
            if (mc.world.getBlockState(diagCell).getMaterial().isReplaceable() && hasSolidNeighbor(diagCell)) {
                return diagCell;
            }
            if (mc.world.getBlockState(first).getMaterial().isReplaceable() && hasSolidNeighbor(first)) {
                return first;
            }
            if (mc.world.getBlockState(second).getMaterial().isReplaceable() && hasSolidNeighbor(second)) {
                return second;
            }
            double fx = px - bx;
            double fz = pz - bz;
            BlockPos xSideRung = new BlockPos(bx, blockY, bz - sZ);
            BlockPos zSideRung = new BlockPos(bx - sX, blockY, bz);
            BlockPos firstBack = fx >= fz ? xSideRung : zSideRung;
            BlockPos secondBack = fx >= fz ? zSideRung : xSideRung;
            if (mc.world.getBlockState(firstBack).getMaterial().isReplaceable() && hasSolidNeighbor(firstBack)) {
                return firstBack;
            }
            if (mc.world.getBlockState(secondBack).getMaterial().isReplaceable() && hasSolidNeighbor(secondBack)) {
                return secondBack;
            }
        }
        return null;
    }

    private static boolean isNearEdgeInDir(double dirX, double dirZ, double maxDist) {
        double px = mc.player.posX;
        double pz = mc.player.posZ;
        double py = mc.player.posY;
        int groundY = (int) Math.floor(py) - 1;
        if (!isSolid(new BlockPos((int) Math.floor(px), groundY, (int) Math.floor(pz)))) {
            return false;
        }
        int blockX = (int) Math.floor(px);
        int blockZ = (int) Math.floor(pz);
        double edgeX, edgeZ;
        if (dirX > 0.01)
            edgeX = blockX + 1.0;
        else if (dirX < -0.01)
            edgeX = blockX;
        else
            edgeX = px;
        if (dirZ > 0.01)
            edgeZ = blockZ + 1.0;
        else if (dirZ < -0.01)
            edgeZ = blockZ;
        else
            edgeZ = pz;
        double dx = edgeX - px;
        double dz = edgeZ - pz;
        double dist = dx * dirX + dz * dirZ;
        return dist >= 0.0 && dist <= maxDist;
    }

    public static boolean isAtEdge() {
        double px = mc.player.posX;
        double py = mc.player.posY;
        double pz = mc.player.posZ;
        double[] offsets = { -0.3, 0.3 };
        for (double ox : offsets) {
            for (double oz : offsets) {
                double checkX = px + ox;
                double checkZ = pz + oz;
                if (!isSolid(new BlockPos(checkX, py, checkZ)) && !isSolid(new BlockPos(checkX, py - 1.0, checkZ))) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean isNearEdge() {
        double px = mc.player.posX;
        double py = mc.player.posY;
        double pz = mc.player.posZ;
        float yaw = BlockPlacementUtil.isActive() ? BlockPlacementUtil.getRealYaw() : mc.player.rotationYaw;
        float forward = (mc.gameSettings.keyBindForward.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindBack.isKeyDown() ? 1 : 0);
        float strafe = (mc.gameSettings.keyBindLeft.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindRight.isKeyDown() ? 1 : 0);
        if (forward == 0.0f && strafe == 0.0f)
            return false;
        float yawRad = yaw * 0.017453292f;
        double dirX = strafe * Math.cos(yawRad) - forward * Math.sin(yawRad);
        double dirZ = forward * Math.cos(yawRad) + strafe * Math.sin(yawRad);
        double mag = Math.sqrt(dirX * dirX + dirZ * dirZ);
        if (mag < 0.01)
            return false;
        dirX /= mag;
        dirZ /= mag;
        double checkX = px + dirX * 0.8;
        double checkZ = pz + dirZ * 0.8;
        return !isSolid(new BlockPos(checkX, py, checkZ)) && !isSolid(new BlockPos(checkX, py - 1.0, checkZ));
    }

    public static BlockPos lastAimNeighbor;

    public static Vec3d getEdgeAimTarget(BlockPos placePos, boolean sameY, float startY, BlockPos stickyNeighbor, boolean parkOnly) {
        lastAimNeighbor = null;
        double px = mc.player.posX;
        double pz = mc.player.posZ;
        int feetY = (int) Math.floor(mc.player.posY);
        int blockY = (sameY ? (int) Math.floor(startY) : feetY) - 1;
        BlockPos below = new BlockPos((int) Math.floor(px), blockY, (int) Math.floor(pz));
        if (!isSolid(placePos.down())) {
            EnumFacing[] horizontals = { EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.EAST, EnumFacing.WEST };
            EnumFacing bestDir = null;
            BlockPos bestNeighbor = null;
            double bestDistSq = -1.0;
            if (!parkOnly && stickyNeighbor != null) {
                for (EnumFacing f : horizontals) {
                    BlockPos neighbor = placePos.offset(f);
                    if (neighbor.equals(stickyNeighbor) && isSolid(neighbor) && isNeighborFaceVisible(placePos, neighbor, px, pz)) {
                        bestDir = f;
                        bestNeighbor = neighbor;
                        bestDistSq = Double.MAX_VALUE;
                        break;
                    }
                }
            }
            if (!parkOnly && bestNeighbor == null) {
                for (EnumFacing f : horizontals) {
                    BlockPos neighbor = placePos.offset(f);
                    if (isSolid(neighbor) && isNeighborFaceVisible(placePos, neighbor, px, pz)) {
                        double dx = neighbor.x + 0.5 - px;
                        double dz = neighbor.z + 0.5 - pz;
                        double distSq = dx * dx + dz * dz;
                        if (distSq > bestDistSq) {
                            bestDistSq = distSq;
                            bestDir = f;
                            bestNeighbor = neighbor;
                        }
                    }
                }
            }
            if (bestNeighbor != null) {
                lastAimNeighbor = bestNeighbor;
                double ax = bestNeighbor.x + 0.5;
                double ay = bestNeighbor.y + 0.7;
                double az = bestNeighbor.z + 0.5;
                EnumFacing aimFace = bestDir.getOpposite();
                switch(aimFace) {
                    case NORTH:
                        az = bestNeighbor.z;
                        break;
                    case SOUTH:
                        az = bestNeighbor.z + 1.0;
                        break;
                    case EAST:
                        ax = bestNeighbor.x + 1.0;
                        break;
                    case WEST:
                        ax = bestNeighbor.x;
                        break;
                    default:
                        break;
                }
                if (aimFace == EnumFacing.EAST || aimFace == EnumFacing.WEST) {
                    az = Math.max(bestNeighbor.z + 0.2, Math.min(bestNeighbor.z + 0.8, pz));
                } else {
                    ax = Math.max(bestNeighbor.x + 0.2, Math.min(bestNeighbor.x + 0.8, px));
                }
                return new Vec3d(ax, ay, az);
            }
            if (isSolid(placePos.up())) {
                return new Vec3d(placePos.x + 0.5, placePos.y + 1.0, placePos.z + 0.5);
            }
            if (stickyNeighbor != null && isSolid(stickyNeighbor)) {
                double ndx = px - (stickyNeighbor.x + 0.5);
                double ndz = pz - (stickyNeighbor.z + 0.5);
                double pay = placePos.y + 0.7;
                if (Math.abs(ndx) >= Math.abs(ndz)) {
                    if (ndx > 0 && px > stickyNeighbor.x + 1.0) {
                        lastAimNeighbor = stickyNeighbor;
                        return new Vec3d(stickyNeighbor.x + 1.0, pay, Math.max(stickyNeighbor.z + 0.2, Math.min(stickyNeighbor.z + 0.8, pz)));
                    }
                    if (ndx < 0 && px < stickyNeighbor.x) {
                        lastAimNeighbor = stickyNeighbor;
                        return new Vec3d(stickyNeighbor.x, pay, Math.max(stickyNeighbor.z + 0.2, Math.min(stickyNeighbor.z + 0.8, pz)));
                    }
                } else {
                    if (ndz > 0 && pz > stickyNeighbor.z + 1.0) {
                        lastAimNeighbor = stickyNeighbor;
                        return new Vec3d(Math.max(stickyNeighbor.x + 0.2, Math.min(stickyNeighbor.x + 0.8, px)), pay, stickyNeighbor.z + 1.0);
                    }
                    if (ndz < 0 && pz < stickyNeighbor.z) {
                        lastAimNeighbor = stickyNeighbor;
                        return new Vec3d(Math.max(stickyNeighbor.x + 0.2, Math.min(stickyNeighbor.x + 0.8, px)), pay, stickyNeighbor.z);
                    }
                }
            }
        }
        if (below.equals(placePos)) {
            return new Vec3d(placePos.x + 0.5, placePos.y + 0.5, placePos.z + 0.5);
        }
        if (placePos.y == blockY + 1 && isSolid(placePos.down())) {
            BlockPos clickedBlock = placePos.down();
            if (placePos.x == below.x && placePos.z == below.z) {
                return new Vec3d(placePos.x + 0.5, clickedBlock.y + 1.0, placePos.z + 0.5);
            }
            return new Vec3d(clickedBlock.x + 0.5, clickedBlock.y + 1.0, clickedBlock.z + 0.5);
        }
        EnumFacing face = getDirectionBetween(below, placePos);
        if (face == null) {
            return new Vec3d(placePos.x + 0.5, placePos.y + 0.5, placePos.z + 0.5);
        }
        BlockPos belowTarget = placePos.down();
        if (isSolid(belowTarget)) {
            double eyeY = mc.player.posY + mc.player.getEyeHeight();
            double groundTop = (double) below.y + 1.0;
            double aimY = (double) belowTarget.y + 1.0;
            double t = (eyeY - groundTop) / (eyeY - aimY);
            double aimX = belowTarget.x + 0.5;
            double aimZ = belowTarget.z + 0.5;
            double minTol = 0.2;
            double maxTol = 1.0 - minTol;
            switch(face) {
                case NORTH:
                    {
                        double maxAimZ = (below.z - 0.01 - (1.0 - t) * pz) / t;
                        aimZ = Math.min(aimZ, maxAimZ);
                        aimZ = Math.max(belowTarget.z + minTol, aimZ);
                        aimZ = Math.min(belowTarget.z + maxTol, aimZ);
                        break;
                    }
                case SOUTH:
                    {
                        double minAimZ = (below.z + 1.0 + 0.01 - (1.0 - t) * pz) / t;
                        aimZ = Math.max(aimZ, minAimZ);
                        aimZ = Math.max(belowTarget.z + minTol, aimZ);
                        aimZ = Math.min(belowTarget.z + maxTol, aimZ);
                        break;
                    }
                case EAST:
                    {
                        double minAimX = (below.x + 1.0 + 0.01 - (1.0 - t) * px) / t;
                        aimX = Math.max(aimX, minAimX);
                        aimX = Math.max(belowTarget.x + minTol, aimX);
                        aimX = Math.min(belowTarget.x + maxTol, aimX);
                        break;
                    }
                case WEST:
                    {
                        double maxAimX = (below.x - 0.01 - (1.0 - t) * px) / t;
                        aimX = Math.min(aimX, maxAimX);
                        aimX = Math.max(belowTarget.x + minTol, aimX);
                        aimX = Math.min(belowTarget.x + maxTol, aimX);
                        break;
                    }
                default:
                    break;
            }
            return new Vec3d(aimX, aimY, aimZ);
        }
        return new Vec3d(placePos.x + 0.5, placePos.y + 0.5, placePos.z + 0.5);
    }

    public static EnumFacing getDirectionBetween(BlockPos from, BlockPos to) {
        int dx = to.x - from.x;
        int dy = to.y - from.y;
        int dz = to.z - from.z;
        if (dx == 1 && dy == 0 && dz == 0)
            return EnumFacing.EAST;
        if (dx == -1 && dy == 0 && dz == 0)
            return EnumFacing.WEST;
        if (dx == 0 && dy == 1 && dz == 0)
            return EnumFacing.UP;
        if (dx == 0 && dy == -1 && dz == 0)
            return EnumFacing.DOWN;
        if (dx == 0 && dy == 0 && dz == 1)
            return EnumFacing.SOUTH;
        if (dx == 0 && dy == 0 && dz == -1)
            return EnumFacing.NORTH;
        return null;
    }

    private static double clampToBlock(double coord, int blockCoord) {
        return Math.max(blockCoord + 0.01, Math.min(blockCoord + 0.99, coord));
    }
}
