package client.utils.world;

import client.utils.combat.AttackControlClaim;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import client.Client;
import client.event.events.AttackEvent;

public final class InteractionUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private InteractionUtils() {
    }

    public static void placeBlock(BlockPos pos, EnumFacing face, Vec3d hitVec, EnumHand hand) {
        if (mc.player == null || mc.world == null)
            return;
        mc.playerController.processRightClickBlock(mc.player, mc.world, pos, face, hitVec, hand);
    }

    public static void placeBlock(BlockPos pos, EnumFacing face) {
        Vec3i dirVec = face.getDirectionVec();
        Vec3d hitVec = new Vec3d(pos.x + 0.5 + dirVec.x * 0.5, pos.y + 0.5 + dirVec.y * 0.5, pos.z + 0.5 + dirVec.z * 0.5);
        placeBlock(pos, face, hitVec, EnumHand.MAIN_HAND);
    }

    public static boolean breakBlock(BlockPos pos, EnumFacing face) {
        if (mc.player == null || mc.world == null)
            return false;
        if (mc.playerController.getCurrentGameType().isCreative()) {
            return mc.playerController.clickBlock(pos, face);
        }
        return mc.playerController.onPlayerDamageBlock(pos, face);
    }

    public static boolean breakBlock(BlockPos pos) {
        return breakBlock(pos, EnumFacing.UP);
    }

    public static void damageBlock(BlockPos pos, EnumFacing face) {
        if (mc.player == null || mc.world == null)
            return;
        mc.playerController.onPlayerDamageBlock(pos, face);
    }

    public static void stopMining() {
        if (mc.playerController != null) {
            mc.playerController.resetBlockRemoving();
        }
    }

    public static boolean isMining() {
        return mc.playerController != null && mc.playerController.getIsHittingBlock();
    }

    public static void attack(Entity target) {
        if (mc.player == null || target == null)
            return;
        AttackEvent event = new AttackEvent(target, EnumHand.MAIN_HAND);
        Client.bus().post(event);
        if (event.isCancelled())
            return;
        mc.playerController.attackEntity(mc.player, target);
        AttackControlClaim.recordAttack();
    }

    public static void attack(Entity target, boolean swing) {
        attack(target);
        if (swing && mc.player != null) {
            mc.player.swingArm(EnumHand.MAIN_HAND);
        }
    }

    public static void attackAndSwing(Entity target) {
        attack(target, true);
    }

    public static void useItem(EnumHand hand) {
        if (mc.player == null)
            return;
        mc.playerController.processRightClick(mc.player, mc.world, hand);
    }

    public static void useItem() {
        useItem(EnumHand.MAIN_HAND);
    }
}
