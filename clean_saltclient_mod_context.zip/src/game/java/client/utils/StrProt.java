package client.utils;

public final class StrProt {

    private StrProt() {
    }

    private static final int CJK_BASE = 0x4E00;

    private static final int CJK_MASK = 0x7F;

    static boolean isProtected(String s) {
        if (s == null || s.length() < 2)
            return false;
        for (int i = 0; i < s.length(); i++) {
            int c = s.charAt(i);
            if (c < CJK_BASE || c > CJK_BASE + CJK_MASK)
                return false;
        }
        return true;
    }

    public static String x(String s) {
        if (!isProtected(s))
            return s;
        int key = s.charAt(0) & CJK_MASK;
        StringBuilder out = new StringBuilder(s.length() - 1);
        for (int i = 1; i < s.length(); i++) {
            int k = (key + 31 * i) & CJK_MASK;
            out.append((char) ((s.charAt(i) & CJK_MASK) ^ k));
        }
        return out.toString();
    }
}
