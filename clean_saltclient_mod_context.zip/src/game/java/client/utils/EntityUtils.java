package client.utils;

import client.utils.misc.FriendManager;
import client.utils.movement.RotationUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.passive.EntityAmbientCreature;
import net.minecraft.entity.passive.EntityWaterMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;

public class EntityUtils {

    public static final TargetSettings DEFAULT_SETTINGS = new TargetSettings();

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final HashMap<Integer, long[]> closestCache = new HashMap<>();

    private static final HashMap<Integer, Object> closestResult = new HashMap<>();

    private static List<Entity> cachedEntityList = null;

    private static long cachedEntityListTick = -1;

    public static List<Entity> getLoadedEntities() {
        if (mc.world == null)
            return new ArrayList<>();
        long currentTick = mc.world.getTotalWorldTime();
        if (cachedEntityList == null || currentTick != cachedEntityListTick) {
            cachedEntityList = new ArrayList<>(mc.world.loadedEntityList);
            cachedEntityListTick = currentTick;
        }
        return cachedEntityList;
    }

    public static List<EntityPlayer> getLoadedPlayers() {
        if (mc.world == null)
            return new ArrayList<>();
        return new ArrayList<>(mc.world.playerEntities);
    }

    public static boolean isEntityLoaded(Entity entity) {
        if (mc.world == null || entity == null)
            return false;
        return mc.world.loadedEntityList.contains(entity);
    }

    public static boolean isAlive(EntityLivingBase e) {
        if (e == null)
            return false;
        if (e.isDead)
            return false;
        if (e.getHealth() <= 0.0f)
            return false;
        if (!e.isEntityAlive())
            return false;
        return true;
    }

    public static boolean isAlive(Entity e) {
        if (!(e instanceof EntityLivingBase))
            return false;
        return isAlive((EntityLivingBase) e);
    }

    private static long currentTick() {
        Minecraft mc = Minecraft.getMinecraft();
        return mc.world != null ? mc.world.getTotalWorldTime() : -1;
    }

    public static void invalidateCache() {
        closestCache.clear();
        closestResult.clear();
    }

    public static boolean isCorrectEntity(Entity en, TargetSettings settings) {
        Minecraft mc = Minecraft.getMinecraft();
        if (en == null)
            return false;
        if (en instanceof EntityLivingBase && (((EntityLivingBase) en).isDead || ((EntityLivingBase) en).getHealth() <= 0))
            return false;
        if (en instanceof EntityPlayer && !settings.targetFriends && FriendManager.isFriend((EntityPlayer) en))
            return false;
        if (mc.player.getDistanceToEntity(en) > settings.range)
            return false;
        if (settings.fov < 360F && RotationUtils.getAngleToClientRotation(getCenter(en)) > settings.fov / 2F)
            return false;
        if (!settings.targetBehindWalls && !mc.player.canEntityBeSeen(en))
            return false;
        if (en == mc.player)
            return false;
        if (en instanceof EntityPlayer) {
            if (!settings.targetPlayers)
                return false;
            if (!settings.targetSleepingPlayers && ((EntityPlayer) en).isPlayerSleeping())
                return false;
            if (!settings.targetInvisiblePlayers && ((EntityPlayer) en).isInvisible())
                return false;
            if (settings.filterFlying > 0) {
                AxisAlignedBB box = en.getEntityBoundingBox();
                box = box.union(box.offset(0, -settings.filterFlying, 0));
                if (mc.world.getCollisionBoxes(null, box).isEmpty())
                    return false;
            }
            if (((EntityPlayer) en).getName().equals(mc.player.getName()))
                return false;
        } else if (en instanceof EntityLiving) {
            if (((EntityLiving) en).isInvisible()) {
                if (!settings.targetInvisibleMobs)
                    return false;
            } else if (en instanceof EntityAgeable || en instanceof EntityAmbientCreature || en instanceof EntityWaterMob) {
                if (!settings.targetAnimals)
                    return false;
            } else if (en instanceof EntityMob || en instanceof EntitySlime) {
                if (!settings.targetMonsters)
                    return false;
            } else if (en instanceof EntityGolem) {
                if (!settings.targetGolems)
                    return false;
            } else
                return false;
        } else
            return false;
        return true;
    }

    public static Vec3d getCenter(Entity entity) {
        return new Vec3d(entity.posX, entity.posY + (entity.getEyeHeight() / 2.0), entity.posZ);
    }

    public static Vec3d getEyes(Entity entity) {
        return new Vec3d(entity.posX, entity.posY + entity.getEyeHeight(), entity.posZ);
    }

    public static Stream<Entity> getEntityStream(TargetSettings settings) {
        return Minecraft.getMinecraft().world.loadedEntityList.stream().filter(e -> isCorrectEntity(e, settings));
    }

    public static ArrayList<Entity> getValidEntities(TargetSettings settings) {
        ArrayList<Entity> validEntities = new ArrayList<>();
        Minecraft mc = Minecraft.getMinecraft();
        for (Entity entity : mc.world.loadedEntityList) {
            if (isCorrectEntity(entity, settings))
                validEntities.add(entity);
            if (validEntities.size() >= 64)
                break;
        }
        return validEntities;
    }

    public static Entity getClosestEntity(TargetSettings settings) {
        int key = settings.hashCode();
        long tick = currentTick();
        long[] cached = closestCache.get(key);
        if (cached != null && cached[0] == tick) {
            Object val = closestResult.get(key);
            if (val instanceof Entity)
                return (Entity) val;
        }
        Entity result = computeClosestEntity(settings);
        closestCache.put(key, new long[] { tick });
        closestResult.put(key, result);
        return result;
    }

    private static Entity computeClosestEntity(TargetSettings settings) {
        Entity closestEntity = null;
        Minecraft mc = Minecraft.getMinecraft();
        for (Entity entity : mc.world.loadedEntityList) if (isCorrectEntity(entity, settings) && (closestEntity == null || mc.player.getDistanceToEntity(entity) < mc.player.getDistanceToEntity(closestEntity)))
            closestEntity = entity;
        return closestEntity;
    }

    public static Entity getBestEntityToAttack(TargetSettings settings) {
        int key = settings.hashCode() ^ 0xAAAA_AAAA;
        long tick = currentTick();
        long[] cached = closestCache.get(key);
        if (cached != null && cached[0] == tick) {
            Object val = closestResult.get(key);
            if (val instanceof Entity)
                return (Entity) val;
        }
        Entity result = computeBestEntityToAttack(settings);
        closestCache.put(key, new long[] { tick });
        closestResult.put(key, result);
        return result;
    }

    private static Entity computeBestEntityToAttack(TargetSettings settings) {
        Entity bestEntity = null;
        float bestAngle = Float.POSITIVE_INFINITY;
        for (Entity entity : Minecraft.getMinecraft().world.loadedEntityList) {
            if (!isCorrectEntity(entity, settings))
                continue;
            float angle = RotationUtils.getAngleToServerRotation(getCenter(entity));
            if (angle < bestAngle) {
                bestEntity = entity;
                bestAngle = angle;
            }
        }
        return bestEntity;
    }

    public static Entity getClosestEntityOtherThan(Entity otherEntity, TargetSettings settings) {
        Entity closestEnemy = null;
        Minecraft mc = Minecraft.getMinecraft();
        for (Entity entity : mc.world.loadedEntityList) if (isCorrectEntity(entity, settings) && entity != otherEntity && (closestEnemy == null || mc.player.getDistanceToEntity(entity) < mc.player.getDistanceToEntity(closestEnemy)))
            closestEnemy = entity;
        return closestEnemy;
    }

    public static Entity getClosestEntityWithName(String name, TargetSettings settings) {
        Entity closestEntity = null;
        Minecraft mc = Minecraft.getMinecraft();
        for (Entity entity : mc.world.loadedEntityList) {
            if (!isCorrectEntity(entity, settings))
                continue;
            if (!entity.getName().equalsIgnoreCase(name))
                continue;
            if (closestEntity == null || mc.player.getDistanceSqToEntity(entity) < mc.player.getDistanceSqToEntity(closestEntity))
                closestEntity = entity;
        }
        return closestEntity;
    }

    public static class TargetSettings {

        public float range = 6.0F;

        public float fov = 360F;

        public boolean targetPlayers = true;

        public boolean targetFriends = false;

        public boolean targetAnimals = false;

        public boolean targetMonsters = true;

        public boolean targetGolems = true;

        public boolean targetSleepingPlayers = true;

        public boolean targetInvisiblePlayers = false;

        public boolean targetInvisibleMobs = false;

        public boolean targetBehindWalls = false;

        public double filterFlying = 0;

        public TargetSettings() {
        }

        @Override
        public int hashCode() {
            int hash = 1;
            hash = 31 * hash + Float.floatToIntBits(range);
            hash = 31 * hash + Float.floatToIntBits(fov);
            hash = 31 * hash + (targetPlayers ? 1 : 0);
            hash = 31 * hash + (targetFriends ? 1 : 0);
            hash = 31 * hash + (targetAnimals ? 1 : 0);
            hash = 31 * hash + (targetMonsters ? 1 : 0);
            hash = 31 * hash + (targetGolems ? 1 : 0);
            hash = 31 * hash + (targetSleepingPlayers ? 1 : 0);
            hash = 31 * hash + (targetInvisiblePlayers ? 1 : 0);
            hash = 31 * hash + (targetInvisibleMobs ? 1 : 0);
            hash = 31 * hash + (targetBehindWalls ? 1 : 0);
            long flyBits = Double.doubleToLongBits(filterFlying);
            hash = 31 * hash + (int) (flyBits ^ (flyBits >>> 32));
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (!(obj instanceof TargetSettings))
                return false;
            TargetSettings o = (TargetSettings) obj;
            return range == o.range && fov == o.fov && targetPlayers == o.targetPlayers && targetFriends == o.targetFriends && targetAnimals == o.targetAnimals && targetMonsters == o.targetMonsters && targetGolems == o.targetGolems && targetSleepingPlayers == o.targetSleepingPlayers && targetInvisiblePlayers == o.targetInvisiblePlayers && targetInvisibleMobs == o.targetInvisibleMobs && targetBehindWalls == o.targetBehindWalls && Double.doubleToLongBits(filterFlying) == Double.doubleToLongBits(o.filterFlying);
        }

        public TargetSettings setRange(float range) {
            this.range = range;
            return this;
        }

        public TargetSettings setFOV(float fov) {
            this.fov = fov;
            return this;
        }

        public TargetSettings setTargetPlayers(boolean targetPlayers) {
            this.targetPlayers = targetPlayers;
            return this;
        }

        public TargetSettings setTargetMonsters(boolean targetMonsters) {
            this.targetMonsters = targetMonsters;
            return this;
        }

        public TargetSettings setTargetAnimals(boolean targetAnimals) {
            this.targetAnimals = targetAnimals;
            return this;
        }

        public TargetSettings setTargetBehindWalls(boolean targetBehindWalls) {
            this.targetBehindWalls = targetBehindWalls;
            return this;
        }
    }
}
