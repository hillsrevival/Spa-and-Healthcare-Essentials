package client.utils.player;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class PlayerUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private PlayerUtils() {
    }

    public static float getTotalHealth() {
        if (mc.player == null)
            return 0;
        return mc.player.getHealth() + mc.player.getAbsorptionAmount();
    }

    public static float predictFallDamage() {
        if (mc.player == null)
            return 0;
        float fall = mc.player.fallDistance;
        if (mc.player.isElytraFlying()) {
            fall *= 0.2f;
        }
        return predictFallDamage(fall);
    }

    public static float predictFallDamage(float fallDistance) {
        net.minecraft.potion.PotionEffect jump = mc.player != null ? mc.player.getActivePotionEffect(net.minecraft.init.MobEffects.JUMP_BOOST) : null;
        float jumpReduction = jump != null ? jump.getAmplifier() + 1.0f : 0.0f;
        float d = fallDistance - 3.0f - jumpReduction;
        return d <= 0.0f ? 0.0f : (float) Math.ceil(d);
    }

    public static float predictExplosionDamage() {
        if (mc.player == null || mc.world == null)
            return 0;
        float maxDamage = 0;
        for (Entity e : mc.world.loadedEntityList) {
            double dist = mc.player.getDistanceToEntity(e);
            if (dist > 12.0)
                continue;
            if (e instanceof EntityEnderCrystal) {
                float dmg = crystalDamage(e, dist);
                if (dmg > maxDamage)
                    maxDamage = dmg;
            }
            if (e instanceof EntityCreeper) {
                float dmg = creeperDamage(dist);
                if (dmg > maxDamage)
                    maxDamage = dmg;
            }
            if (e.getName().toLowerCase().contains("tnt")) {
                float dmg = tntDamage(dist);
                if (dmg > maxDamage)
                    maxDamage = dmg;
            }
        }
        if (mc.world.getBlockState(new BlockPos(mc.player)).getBlock() == Blocks.BED) {
            float dmg = 10.0f;
            if (dmg > maxDamage)
                maxDamage = dmg;
        }
        return maxDamage;
    }

    private static float crystalDamage(Entity crystal, double dist) {
        double exposure = 1.0 - (dist / 12.0);
        if (exposure < 0)
            return 0;
        return (float) (exposure * 12.0);
    }

    private static float creeperDamage(double dist) {
        double exposure = 1.0 - (dist / 6.0);
        if (exposure < 0)
            return 0;
        return (float) (exposure * 6.0);
    }

    private static float tntDamage(double dist) {
        double exposure = 1.0 - (dist / 8.0);
        if (exposure < 0)
            return 0;
        return (float) (exposure * 8.0);
    }

    public static boolean isMoving() {
        if (mc.player == null)
            return false;
        return mc.player.moveForward != 0.0f || mc.player.moveStrafing != 0.0f;
    }

    public static float getMovementYaw() {
        if (mc.player == null)
            return 0;
        if (!isMoving())
            return mc.player.rotationYaw;
        float yaw = mc.player.rotationYaw;
        float forward = mc.player.moveForward;
        float strafe = mc.player.moveStrafing;
        float yawRad = yaw * 0.017453292f;
        double dirX = strafe * Math.sin(yawRad) - forward * Math.cos(yawRad);
        double dirZ = forward * Math.sin(yawRad) + strafe * Math.cos(yawRad);
        return (float) Math.toDegrees(Math.atan2(dirZ, dirX));
    }

    public static float possibleHealthReductions(boolean explosion, boolean fall) {
        float danger = 0;
        if (explosion) {
            float exp = predictExplosionDamage();
            if (exp > danger)
                danger = exp;
        }
        if (fall) {
            float fd = predictFallDamage();
            if (fd > danger)
                danger = fd;
        }
        return danger;
    }
}
