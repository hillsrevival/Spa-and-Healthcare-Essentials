package client.utils.player;

public class SlotUtils {

    public static final int HOTBAR_START = 36;

    public static final int HOTBAR_END = 44;

    public static final int MAIN_START = 9;

    public static final int MAIN_END = 35;

    public static final int ARMOR_START = 5;

    public static final int ARMOR_END = 8;

    public static final int OFFHAND = 45;

    private SlotUtils() {
    }

    public static int indexToId(int index) {
        return index;
    }

    public static int idToIndex(int id) {
        return id;
    }

    public static boolean isHotbar(int slotIndex) {
        return slotIndex >= HOTBAR_START && slotIndex <= HOTBAR_END;
    }

    public static boolean isMain(int slotIndex) {
        return slotIndex >= MAIN_START && slotIndex <= MAIN_END;
    }

    public static boolean isArmor(int slotIndex) {
        return slotIndex >= ARMOR_START && slotIndex <= ARMOR_END;
    }
}
