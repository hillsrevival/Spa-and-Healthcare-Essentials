package client.utils.player;

import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;

public final class FallPrediction {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final double GRAVITY = 0.08;

    private static final double TERMINAL_VELOCITY = 3.92;

    public static double getGroundDistance() {
        BlockPos landing = scanLandingBlock();
        if (landing == null)
            return 999.0;
        return Math.floor(mc.player.posY) - landing.getY();
    }

    public static BlockPos getLandingBlock() {
        return scanLandingBlock();
    }

    private static BlockPos scanLandingBlock() {
        if (mc.player == null || mc.world == null)
            return null;
        int px = (int) Math.floor(mc.player.posX);
        int py = (int) Math.floor(mc.player.posY);
        int pz = (int) Math.floor(mc.player.posZ);
        double motionY = mc.player.motionY;
        double absVelocity = Math.abs(motionY);
        double ticksRemaining = absVelocity > 0.1 ? Math.min(absVelocity / GRAVITY, 40.0) : 5.0;
        int landX = px + (int) Math.round(mc.player.motionX * ticksRemaining);
        int landZ = pz + (int) Math.round(mc.player.motionZ * ticksRemaining);
        landX = Math.max(px - 3, Math.min(px + 3, landX));
        landZ = Math.max(pz - 3, Math.min(pz + 3, landZ));
        BlockPos bestPos = null;
        double minDist = 999.0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                int checkX = landX + dx;
                int checkZ = landZ + dz;
                for (int y = py - 1; y >= py - 30 && y > 0; y--) {
                    BlockPos pos = new BlockPos(checkX, y, checkZ);
                    if (mc.world.getBlockState(pos).getMaterial().isSolid() || mc.world.getBlockState(pos).getMaterial().isLiquid()) {
                        double dist = py - y;
                        if (dist < minDist) {
                            minDist = dist;
                            bestPos = pos;
                        }
                        break;
                    }
                }
            }
        }
        return bestPos;
    }

    public static double getTicksToImpact(double groundDist, double motionY) {
        if (motionY >= 0 || groundDist <= 0)
            return 999.0;
        double velocity = Math.abs(motionY);
        velocity = Math.min(velocity, TERMINAL_VELOCITY);
        double discriminant = velocity * velocity + 2.0 * GRAVITY * groundDist;
        if (discriminant < 0)
            return 999.0;
        double t = (-velocity + Math.sqrt(discriminant)) / GRAVITY;
        return Math.max(t, 0);
    }
}
