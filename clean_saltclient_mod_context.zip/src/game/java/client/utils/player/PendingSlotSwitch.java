package client.utils.player;

import client.utils.misc.TickTimer;
import net.minecraft.client.Minecraft;
import java.util.Random;

public class PendingSlotSwitch {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private final TickTimer switchTimer = new TickTimer();

    private final Random rand = new Random();

    private int oldSlot = -1;

    private int pendingSlot = -1;

    private int actualSwitchDelay = -1;

    public boolean hasPending() {
        return pendingSlot != -1;
    }

    public int getPendingSlot() {
        return pendingSlot;
    }

    public int getOldSlot() {
        return oldSlot;
    }

    public void queue(int hotbarSlot, int baseDelayTicks) {
        if (mc.player == null)
            return;
        if (oldSlot == -1)
            oldSlot = mc.player.inventory.currentItem;
        pendingSlot = hotbarSlot;
        switchTimer.reset();
        actualSwitchDelay = baseDelayTicks + (rand.nextInt(2) == 0 ? 1 : 0);
    }

    public boolean tick() {
        if (pendingSlot == -1)
            return false;
        switchTimer.tick();
        return switchTimer.getTicks() >= actualSwitchDelay;
    }

    public void applySwitch() {
        if (pendingSlot == -1 || mc.player == null)
            return;
        mc.player.inventory.currentItem = pendingSlot;
        pendingSlot = -1;
        switchTimer.reset();
    }

    public void restore() {
        if (oldSlot != -1 && mc.player != null) {
            mc.player.inventory.currentItem = oldSlot;
        }
        oldSlot = -1;
        pendingSlot = -1;
        switchTimer.reset();
    }
}
