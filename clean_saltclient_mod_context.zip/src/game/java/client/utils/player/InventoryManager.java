package client.utils.player;

import net.minecraft.client.Minecraft;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import client.utils.world.PacketUtils;

public final class InventoryManager {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private InventoryManager() {
    }

    public static void swapIntoCurrent(int hotbarSlot) {
        if (mc.player == null)
            return;
        if (hotbarSlot < 0 || hotbarSlot > 8)
            return;
        int currentSlot = mc.player.inventory.currentItem;
        if (hotbarSlot == currentSlot)
            return;
        mc.playerController.windowClick(0, hotbarSlot + SlotUtils.HOTBAR_START, currentSlot, ClickType.SWAP, mc.player);
        mc.player.inventory.currentItem = currentSlot;
        PacketUtils.sendHeldItemChange(currentSlot);
    }

    public static void swapHotbarSlots(int fromSlot, int toSlot) {
        if (mc.player == null)
            return;
        if (fromSlot < 0 || fromSlot > 8 || toSlot < 0 || toSlot > 8)
            return;
        if (fromSlot == toSlot)
            return;
        mc.playerController.windowClick(0, fromSlot + SlotUtils.HOTBAR_START, toSlot, ClickType.SWAP, mc.player);
        mc.player.inventory.currentItem = toSlot;
        PacketUtils.sendHeldItemChange(toSlot);
    }

    public static void switchToSlot(int hotbarSlot) {
        if (mc.player == null)
            return;
        if (hotbarSlot < 0 || hotbarSlot > 8)
            return;
        mc.player.inventory.currentItem = hotbarSlot;
        PacketUtils.sendHeldItemChange(hotbarSlot);
    }

    public static void restoreSlot(int originalSlot) {
        if (mc.player == null)
            return;
        if (originalSlot < 0 || originalSlot > 8)
            return;
        if (mc.player.inventory.currentItem == originalSlot)
            return;
        mc.player.inventory.currentItem = originalSlot;
        PacketUtils.sendHeldItemChange(originalSlot);
    }

    public static boolean findAndSwap(Item item) {
        FindItemResult result = InvUtils.findInHotbar(item);
        if (!result.found() || !result.isHotbar())
            return false;
        int hotbarSlot = result.slot() - SlotUtils.HOTBAR_START;
        swapIntoCurrent(hotbarSlot);
        return true;
    }

    public static boolean findAndSwitch(Item item) {
        FindItemResult result = InvUtils.findInHotbar(item);
        if (!result.found() || !result.isHotbar())
            return false;
        int hotbarSlot = result.slot() - SlotUtils.HOTBAR_START;
        switchToSlot(hotbarSlot);
        return true;
    }

    public static int getCurrentSlot() {
        return mc.player != null ? mc.player.inventory.currentItem : -1;
    }

    public static ItemStack getHeldItem() {
        if (mc.player == null)
            return net.minecraft.item.ItemStack.field_190927_a;
        return mc.player.getHeldItemMainhand();
    }
}
