package client.utils.player;

import net.minecraft.client.Minecraft;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import java.util.function.Predicate;

public class InvUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private InvUtils() {
    }

    public static FindItemResult find(Item item) {
        return find(stack -> stack != null && !stack.func_190926_b() && stack.getItem() == item);
    }

    public static FindItemResult find(Predicate<ItemStack> predicate) {
        if (mc.player == null)
            return new FindItemResult(-1, 0);
        int slot = -1;
        int count = 0;
        for (int i = 0; i < 46; i++) {
            ItemStack stack = mc.player.inventoryContainer.getSlot(i).getStack();
            if (stack != null && predicate.test(stack)) {
                if (slot == -1)
                    slot = i;
                count += stack.func_190916_E();
            }
        }
        return new FindItemResult(slot, count);
    }

    public static FindItemResult findInHotbar(Item item) {
        return findInHotbar(stack -> stack != null && stack.getItem() == item);
    }

    public static FindItemResult findInHotbar(Predicate<ItemStack> predicate) {
        if (mc.player == null)
            return new FindItemResult(-1, 0);
        for (int i = SlotUtils.HOTBAR_START; i <= SlotUtils.HOTBAR_END; i++) {
            ItemStack stack = mc.player.inventoryContainer.getSlot(i).getStack();
            if (stack != null && predicate.test(stack)) {
                return new FindItemResult(i, stack.func_190916_E());
            }
        }
        return new FindItemResult(-1, 0);
    }

    public static void move(int from, int to) {
        if (mc.player == null)
            return;
        mc.playerController.windowClick(0, SlotUtils.indexToId(from), 0, ClickType.PICKUP, mc.player);
        mc.playerController.windowClick(0, SlotUtils.indexToId(to), 0, ClickType.PICKUP, mc.player);
    }

    public static void moveToOffhand(int from) {
        if (mc.player == null)
            return;
        mc.playerController.windowClick(0, SlotUtils.indexToId(from), 0, ClickType.PICKUP, mc.player);
        mc.playerController.windowClick(0, SlotUtils.indexToId(SlotUtils.OFFHAND), 0, ClickType.PICKUP, mc.player);
        mc.playerController.windowClick(0, SlotUtils.indexToId(from), 0, ClickType.PICKUP, mc.player);
    }

    public static void shiftClick(int slot) {
        if (mc.player == null)
            return;
        mc.playerController.windowClick(0, SlotUtils.indexToId(slot), 0, ClickType.QUICK_MOVE, mc.player);
    }

    public static void drop(int slot) {
        if (mc.player == null)
            return;
        mc.playerController.windowClick(0, SlotUtils.indexToId(slot), 1, ClickType.THROW, mc.player);
    }

    public static void swapToHotbar(int hotbarSlot) {
        if (mc.player == null)
            return;
        if (!SlotUtils.isHotbar(hotbarSlot))
            return;
        mc.player.inventory.currentItem = hotbarSlot - SlotUtils.HOTBAR_START;
    }
}
