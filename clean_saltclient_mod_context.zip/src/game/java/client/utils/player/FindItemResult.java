package client.utils.player;

public class FindItemResult {

    private final int slot;

    private final int count;

    public FindItemResult(int slot, int count) {
        this.slot = slot;
        this.count = count;
    }

    public boolean found() {
        return slot != -1;
    }

    public int slot() {
        return slot;
    }

    public int count() {
        return count;
    }

    public boolean isOffhand() {
        return slot == SlotUtils.OFFHAND;
    }

    public boolean isHotbar() {
        return slot >= SlotUtils.HOTBAR_START && slot <= SlotUtils.HOTBAR_END;
    }

    public boolean isMain() {
        return slot >= SlotUtils.MAIN_START && slot <= SlotUtils.MAIN_END;
    }

    public boolean isInventory() {
        return isMain() || isHotbar();
    }

    public boolean isValid() {
        return slot >= 0 && slot < 46;
    }
}
