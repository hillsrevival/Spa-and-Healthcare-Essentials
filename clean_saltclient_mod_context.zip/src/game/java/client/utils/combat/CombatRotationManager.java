package client.utils.combat;

import client.utils.movement.RotationUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;

public final class CombatRotationManager {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static RotationClaim activeClaim = null;

    private static float managedYaw;

    private static float managedPitch;

    private static float prevManagedYaw;

    private static float prevManagedPitch;

    private static float realYaw;

    private static float realPitch;

    private static boolean active;

    private static boolean silentAimClaimed;

    private static RayTraceResult extendedRayTrace;

    private static RayTraceResult normalRayTrace;

    private CombatRotationManager() {
    }

    public static final class RotationClaim {

        private final String owner;

        private final int priority;

        private boolean valid;

        RotationClaim(String owner, int priority) {
            this.owner = owner;
            this.priority = priority;
            this.valid = true;
        }

        public boolean isAcquired() {
            return valid && activeClaim == this;
        }

        public String getOwner() {
            return owner;
        }

        public int getPriority() {
            return priority;
        }

        public void release() {
            if (activeClaim == this) {
                activeClaim = null;
            }
            valid = false;
        }
    }

    public static RotationClaim acquire(String owner, int priority) {
        if (activeClaim != null && activeClaim.owner.equals(owner)) {
            return activeClaim;
        }
        if (activeClaim == null) {
            RotationClaim claim = new RotationClaim(owner, priority);
            activeClaim = claim;
            return claim;
        }
        if (priority > activeClaim.priority) {
            activeClaim.valid = false;
            RotationClaim claim = new RotationClaim(owner, priority);
            activeClaim = claim;
            return claim;
        }
        return new RotationClaim(owner, priority);
    }

    public static String getClaimOwner() {
        return activeClaim != null ? activeClaim.owner : null;
    }

    public static boolean isActive() {
        return active;
    }

    public static float getManagedYaw() {
        return managedYaw;
    }

    public static float getManagedPitch() {
        return managedPitch;
    }

    public static float getPrevManagedYaw() {
        return prevManagedYaw;
    }

    public static float getPrevManagedPitch() {
        return prevManagedPitch;
    }

    public static float getRealYaw() {
        return realYaw;
    }

    public static float getRealPitch() {
        return realPitch;
    }

    public static float getAngleTo(EntityLivingBase target) {
        if (mc.player == null || target == null)
            return 999f;
        float[] needed = RotationUtils.getNeededRotations(target.getPositionEyes(1.0f));
        float yawDiff = Math.abs(RotationUtils.wrapDegrees(needed[0] - managedYaw));
        float pitchDiff = Math.abs(needed[1] - managedPitch);
        return (float) Math.sqrt(yawDiff * yawDiff + pitchDiff * pitchDiff);
    }

    public static void beginTick() {
        if (mc.player == null || mc.world == null) {
            active = false;
            return;
        }
        if (activeClaim == null) {
            if (active) {
                SilentAimUtil.restore();
                SilentAimUtil.restoreMovementKeys();
                active = false;
            }
            return;
        }
        realYaw = mc.player.rotationYaw;
        realPitch = mc.player.rotationPitch;
        prevManagedYaw = managedYaw;
        prevManagedPitch = managedPitch;
        if (!silentAimClaimed) {
            silentAimClaimed = SilentAimUtil.onEnable("CombatRotationManager");
            SilentAimUtil.initPIController();
        }
        active = true;
    }

    public static void endTick() {
        if (!active)
            return;
        SilentAimUtil.restore();
        SilentAimUtil.restoreMovementKeys();
        active = false;
        silentAimClaimed = false;
    }

    public static void reset() {
        if (silentAimClaimed) {
            SilentAimUtil.onDisable("CombatRotationManager");
        }
        active = false;
        silentAimClaimed = false;
        activeClaim = null;
        managedYaw = 0;
        managedPitch = 0;
        prevManagedYaw = 0;
        prevManagedPitch = 0;
        extendedRayTrace = null;
        normalRayTrace = null;
    }

    public static boolean aimAt(Vec3d target, float speed, double distance, double targetHSpeed, boolean onTarget) {
        if (!active || mc.player == null)
            return false;
        float[] needed = RotationUtils.getNeededRotations(target);
        float[] adjusted = SilentAimUtil.piAimAdjustment(managedYaw, managedPitch, needed[0], needed[1], prevManagedYaw, prevManagedPitch, distance, targetHSpeed, onTarget);
        boolean reached = SilentAimUtil.faceTargetSmoothGCD(adjusted[0], adjusted[1], speed, true);
        managedYaw = mc.player.rotationYaw;
        managedPitch = mc.player.rotationPitch;
        SilentAimUtil.applyMovementCorrection(realYaw, managedYaw);
        refreshRayTraces();
        return reached;
    }

    public static boolean aimAtSimple(Vec3d target, float speed) {
        if (!active || mc.player == null)
            return false;
        boolean reached = SilentAimUtil.faceTargetSmoothGCD(target, speed, false);
        managedYaw = mc.player.rotationYaw;
        managedPitch = mc.player.rotationPitch;
        refreshRayTraces();
        return reached;
    }

    public static void snapTo(Vec3d target) {
        if (!active || mc.player == null)
            return;
        float[] needed = RotationUtils.getNeededRotations(target);
        float[] fixed = RotationUtils.fixRotations(realYaw, realPitch, needed[0], needed[1]);
        SilentAimUtil.setupSilentRotation(fixed[0], fixed[1]);
        managedYaw = fixed[0];
        managedPitch = fixed[1];
        SilentAimUtil.resetIntegerDelta();
        refreshRayTraces();
    }

    public static void refreshRayTraces() {
        if (mc.player == null || mc.world == null)
            return;
        float savedYaw = mc.player.rotationYaw;
        float savedPitch = mc.player.rotationPitch;
        mc.player.rotationYaw = managedYaw;
        mc.player.rotationPitch = managedPitch;
        normalRayTrace = mc.player.rayTrace(3.0, 0.0f);
        extendedRayTrace = mc.player.rayTrace(6.0, 0.0f);
        mc.player.rotationYaw = savedYaw;
        mc.player.rotationPitch = savedPitch;
    }

    public static RayTraceResult rayTrace(double reach) {
        if (mc.player == null || mc.world == null)
            return null;
        float savedYaw = mc.player.rotationYaw;
        float savedPitch = mc.player.rotationPitch;
        mc.player.rotationYaw = managedYaw;
        mc.player.rotationPitch = managedPitch;
        RayTraceResult result = mc.player.rayTrace(reach, 0.0f);
        mc.player.rotationYaw = savedYaw;
        mc.player.rotationPitch = savedPitch;
        return result;
    }

    public static boolean isOnTarget(EntityLivingBase entity, double reach) {
        if (entity == null)
            return false;
        return RotationUtils.isRotationOnEntity(managedYaw, managedPitch, entity, reach);
    }

    public static boolean isOnTarget(double reach) {
        RayTraceResult result = extendedRayTrace;
        if (result == null) {
            result = rayTrace(reach);
        }
        return result != null && result.typeOfHit == RayTraceResult.Type.ENTITY && result.entityHit != null && result.entityHit instanceof EntityLivingBase;
    }

    public static EntityLivingBase getTargetUnderCrosshair(double reach) {
        RayTraceResult result = extendedRayTrace;
        if (result == null) {
            result = rayTrace(reach);
        }
        if (result != null && result.typeOfHit == RayTraceResult.Type.ENTITY && result.entityHit instanceof EntityLivingBase) {
            return (EntityLivingBase) result.entityHit;
        }
        return null;
    }

    public static RayTraceResult getExtendedRayTrace() {
        return extendedRayTrace;
    }

    public static RayTraceResult getNormalRayTrace() {
        return normalRayTrace;
    }
}
