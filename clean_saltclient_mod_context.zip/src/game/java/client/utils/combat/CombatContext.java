package client.utils.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;

public final class CombatContext {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private CombatContext() {
    }

    private static EntityLivingBase currentTarget = null;

    private static EntityLivingBase lastTickTarget = null;

    private static long targetAcquiredTick = 0;

    private static long currentTick = 0;

    private static long lastGameTick = -1;

    private static Vec3d opponentPos = Vec3d.ZERO;

    private static Vec3d opponentPrevPos = Vec3d.ZERO;

    private static Vec3d opponentVelocity = Vec3d.ZERO;

    private static Vec3d opponentPrevVelocity = Vec3d.ZERO;

    private static Vec3d opponentAcceleration = Vec3d.ZERO;

    private static Vec3d predictedPos = Vec3d.ZERO;

    private static Vec3d predictedPos2 = Vec3d.ZERO;

    private static boolean opponentOnGround = false;

    private static boolean opponentSprinting = false;

    private static boolean opponentAirborne = false;

    private static int opponentHurtTime = 0;

    private static int opponentMaxHurtTime = 0;

    private static float opponentHealth = 0.0f;

    private static float opponentMaxHealth = 0.0f;

    private static long opponentLastSwingTick = -1000;

    private static long myLastAttackTick = -1000;

    private static long myLastHurtTick = -1000;

    private static boolean myCooldownReady = false;

    private static boolean myOnGround = false;

    private static boolean mySprinting = false;

    private static final double DEFAULT_SWING_PERIOD = 12.0;

    private static double opponentSwingPeriodEMA = DEFAULT_SWING_PERIOD;

    private static double myAttackPeriodEMA = DEFAULT_SWING_PERIOD;

    private static final double MIN_PLAUSIBLE_INTERVAL = 2.0;

    private static final double MAX_PLAUSIBLE_INTERVAL = 40.0;

    private static final double PERIOD_EMA_ALPHA = 0.3;

    private static double updatePeriodEMA(double current, double observedInterval) {
        if (observedInterval < MIN_PLAUSIBLE_INTERVAL || observedInterval > MAX_PLAUSIBLE_INTERVAL) {
            return current;
        }
        return current + PERIOD_EMA_ALPHA * (observedInterval - current);
    }

    private static int lastHitter = 0;

    private static int playerComboCount = 0;

    private static int opponentComboCount = 0;

    private static long expectedNextPlayerHitTick = 0;

    private static long expectedNextOpponentHitTick = 0;

    private static boolean shouldEngage = true;

    private static boolean canCritNow = false;

    private static String engageBlockReason = "";

    private static void checkTickAdvance() {
        long now = mc.player != null ? mc.player.ticksExisted : -1L;
        if (now != lastGameTick) {
            lastGameTick = now;
            currentTick++;
            lastTickTarget = currentTarget;
        }
    }

    public static void beginTick() {
        checkTickAdvance();
    }

    public static void clearTarget() {
        if (currentTarget != null) {
            lastTickTarget = currentTarget;
        }
        currentTarget = null;
        opponentPos = Vec3d.ZERO;
        opponentPrevPos = Vec3d.ZERO;
        opponentVelocity = Vec3d.ZERO;
        opponentPrevVelocity = Vec3d.ZERO;
        opponentAcceleration = Vec3d.ZERO;
        predictedPos = Vec3d.ZERO;
        predictedPos2 = Vec3d.ZERO;
        opponentOnGround = false;
        opponentSprinting = false;
        opponentAirborne = false;
        opponentHurtTime = 0;
        opponentMaxHurtTime = 0;
        opponentHealth = 0.0f;
        opponentMaxHealth = 0.0f;
        shouldEngage = true;
        canCritNow = false;
        engageBlockReason = "";
    }

    public static void setTarget(EntityLivingBase target) {
        checkTickAdvance();
        if (target != currentTarget) {
            targetAcquiredTick = currentTick;
            opponentSwingPeriodEMA = DEFAULT_SWING_PERIOD;
            opponentLastSwingTick = -1000;
            expectedNextOpponentHitTick = 0;
        }
        currentTarget = target;
    }

    public static void setOpponentState(Vec3d pos, Vec3d prevPos, Vec3d velocity, Vec3d prevVelocity, boolean onGround, boolean sprinting, boolean airborne, int hurtTime, int maxHurtTime, float health, float maxHealth) {
        opponentPrevPos = opponentPos;
        opponentPos = pos;
        opponentPrevVelocity = opponentVelocity;
        opponentVelocity = velocity;
        opponentAcceleration = velocity.subtract(prevVelocity);
        opponentOnGround = onGround;
        opponentSprinting = sprinting;
        opponentAirborne = airborne;
        opponentHurtTime = hurtTime;
        opponentMaxHurtTime = maxHurtTime;
        opponentHealth = health;
        opponentMaxHealth = maxHealth;
        predictedPos = pos.add(velocity);
        predictedPos2 = pos.add(velocity.scale(2.0));
    }

    public static void setOpponentLastSwingTick(long tick) {
        if (opponentLastSwingTick > 0 && tick > opponentLastSwingTick) {
            opponentSwingPeriodEMA = updatePeriodEMA(opponentSwingPeriodEMA, tick - opponentLastSwingTick);
        }
        opponentLastSwingTick = tick;
    }

    public static void setMyState(boolean cooldownReady, boolean onGround, boolean sprinting) {
        myCooldownReady = cooldownReady;
        myOnGround = onGround;
        mySprinting = sprinting;
    }

    public static void recordMyAttack() {
        checkTickAdvance();
        if (myLastAttackTick > 0 && currentTick > myLastAttackTick) {
            myAttackPeriodEMA = updatePeriodEMA(myAttackPeriodEMA, currentTick - myLastAttackTick);
        }
        myLastAttackTick = currentTick;
        expectedNextPlayerHitTick = currentTick + Math.round(myAttackPeriodEMA);
    }

    public static void recordMyHurt() {
        checkTickAdvance();
        myLastHurtTick = currentTick;
    }

    public static void onPlayerHitOpponent() {
        lastHitter = 1;
        playerComboCount++;
        opponentComboCount = 0;
    }

    public static void onOpponentHitPlayer() {
        checkTickAdvance();
        lastHitter = -1;
        opponentComboCount++;
        playerComboCount = 0;
        expectedNextOpponentHitTick = currentTick + Math.round(opponentSwingPeriodEMA);
    }

    public static void resetCombo() {
        lastHitter = 0;
        playerComboCount = 0;
        opponentComboCount = 0;
    }

    public static void setShouldEngage(boolean engage, String reason) {
        shouldEngage = engage;
        engageBlockReason = engage ? "" : reason;
    }

    public static void setCanCritNow(boolean canCrit) {
        canCritNow = canCrit;
    }

    public static EntityLivingBase getTarget() {
        return currentTarget;
    }

    public static EntityLivingBase getLastTickTarget() {
        return lastTickTarget;
    }

    public static long getTargetAcquiredTick() {
        checkTickAdvance();
        return targetAcquiredTick;
    }

    public static long getCurrentTick() {
        checkTickAdvance();
        return currentTick;
    }

    public static long getTicksSinceTargetAcquired() {
        checkTickAdvance();
        return currentTick - targetAcquiredTick;
    }

    public static Vec3d getOpponentPos() {
        return opponentPos;
    }

    public static Vec3d getOpponentPrevPos() {
        return opponentPrevPos;
    }

    public static Vec3d getOpponentVelocity() {
        return opponentVelocity;
    }

    public static Vec3d getOpponentAcceleration() {
        return opponentAcceleration;
    }

    public static Vec3d getPredictedPos() {
        return predictedPos;
    }

    public static Vec3d getPredictedPos(int ticksAhead) {
        if (currentTarget == null)
            return Vec3d.ZERO;
        if (ticksAhead <= 0)
            return opponentPos;
        if (ticksAhead == 1)
            return predictedPos;
        if (ticksAhead == 2)
            return predictedPos2;
        return opponentPos.add(opponentVelocity.scale(ticksAhead));
    }

    public static boolean isOpponentOnGround() {
        return opponentOnGround;
    }

    public static boolean isOpponentSprinting() {
        return opponentSprinting;
    }

    public static boolean isOpponentAirborne() {
        return opponentAirborne;
    }

    public static int getOpponentHurtTime() {
        return opponentHurtTime;
    }

    public static int getOpponentMaxHurtTime() {
        return opponentMaxHurtTime;
    }

    public static float getOpponentHealth() {
        return opponentHealth;
    }

    public static float getOpponentMaxHealth() {
        return opponentMaxHealth;
    }

    public static long getOpponentLastSwingTick() {
        return opponentLastSwingTick;
    }

    public static boolean isMyCooldownReady() {
        return myCooldownReady;
    }

    public static boolean isMyOnGround() {
        return myOnGround;
    }

    public static boolean isMySprinting() {
        return mySprinting;
    }

    public static long getMyLastAttackTick() {
        return myLastAttackTick;
    }

    public static long getMyLastHurtTick() {
        return myLastHurtTick;
    }

    public static int getLastHitter() {
        return lastHitter;
    }

    public static int getPlayerComboCount() {
        return playerComboCount;
    }

    public static int getOpponentComboCount() {
        return opponentComboCount;
    }

    public static long getExpectedNextPlayerHitTick() {
        return expectedNextPlayerHitTick;
    }

    public static long getExpectedNextOpponentHitTick() {
        return expectedNextOpponentHitTick;
    }

    public static boolean shouldEngage() {
        return shouldEngage;
    }

    public static boolean canCritNow() {
        return canCritNow;
    }

    public static String getEngageBlockReason() {
        return engageBlockReason;
    }

    public static boolean isOpponentHurt() {
        return opponentHurtTime > 0;
    }

    public static boolean isOpponentJustHit() {
        return opponentHurtTime > 0 && opponentHurtTime == opponentMaxHurtTime;
    }

    public static boolean isOpponentCooldownReady() {
        checkTickAdvance();
        return currentTick - opponentLastSwingTick >= Math.round(opponentSwingPeriodEMA);
    }

    public static long getTicksSinceOpponentSwing() {
        checkTickAdvance();
        return currentTick - opponentLastSwingTick;
    }

    public static long getTicksSinceMyAttack() {
        checkTickAdvance();
        return currentTick - myLastAttackTick;
    }

    private static long jumpResetTick = Long.MIN_VALUE;

    public static void recordJumpReset() {
        checkTickAdvance();
        jumpResetTick = currentTick;
    }

    public static boolean isJumpResetRecent(int ticks) {
        checkTickAdvance();
        return jumpResetTick != Long.MIN_VALUE && currentTick - jumpResetTick <= ticks;
    }

    public static long getTradeWindowTicks() {
        checkTickAdvance();
        return (long) (opponentLastSwingTick + Math.round(opponentSwingPeriodEMA)) - currentTick;
    }

    public static double getOpponentSwingPeriod() {
        return opponentSwingPeriodEMA;
    }

    public static double getMyAttackPeriod() {
        return myAttackPeriodEMA;
    }

    public static void reset() {
        currentTarget = null;
        lastTickTarget = null;
        targetAcquiredTick = 0;
        currentTick = 0;
        lastGameTick = -1;
        opponentPos = Vec3d.ZERO;
        opponentPrevPos = Vec3d.ZERO;
        opponentVelocity = Vec3d.ZERO;
        opponentPrevVelocity = Vec3d.ZERO;
        opponentAcceleration = Vec3d.ZERO;
        predictedPos = Vec3d.ZERO;
        predictedPos2 = Vec3d.ZERO;
        opponentOnGround = false;
        opponentSprinting = false;
        opponentAirborne = false;
        opponentHurtTime = 0;
        opponentMaxHurtTime = 0;
        opponentHealth = 0.0f;
        opponentMaxHealth = 0.0f;
        opponentLastSwingTick = -1000;
        myLastAttackTick = -1000;
        myLastHurtTick = -1000;
        myCooldownReady = false;
        myOnGround = false;
        mySprinting = false;
        opponentSwingPeriodEMA = DEFAULT_SWING_PERIOD;
        myAttackPeriodEMA = DEFAULT_SWING_PERIOD;
        lastHitter = 0;
        playerComboCount = 0;
        opponentComboCount = 0;
        expectedNextPlayerHitTick = 0;
        expectedNextOpponentHitTick = 0;
        shouldEngage = true;
        canCritNow = false;
        engageBlockReason = "";
    }
}
