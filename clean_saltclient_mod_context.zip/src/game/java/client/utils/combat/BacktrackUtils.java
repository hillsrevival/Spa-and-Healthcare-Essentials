package client.utils.combat;

import net.minecraft.entity.EntityLivingBase;

public final class BacktrackUtils {

    public static final double POSITION_SCALE = 4096.0;

    public static class PositionSnapshot {

        public final double x, y, z;

        public PositionSnapshot(double x, double y, double z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    public static class EncodedPositionState {

        private long encodedX;

        private long encodedY;

        private long encodedZ;

        public EncodedPositionState(long x, long y, long z) {
            this.encodedX = x;
            this.encodedY = y;
            this.encodedZ = z;
        }

        public static EncodedPositionState fromEntity(EntityLivingBase entity) {
            return new EncodedPositionState(floor(entity.posX * POSITION_SCALE), floor(entity.posY * POSITION_SCALE), floor(entity.posZ * POSITION_SCALE));
        }

        public void applyRelativeMove(int deltaX, int deltaY, int deltaZ) {
            this.encodedX += deltaX;
            this.encodedY += deltaY;
            this.encodedZ += deltaZ;
        }

        public void applyAbsolutePosition(long x, long y, long z) {
            this.encodedX = x;
            this.encodedY = y;
            this.encodedZ = z;
        }

        public PositionSnapshot toSnapshot() {
            return new PositionSnapshot(encodedX / POSITION_SCALE, encodedY / POSITION_SCALE, encodedZ / POSITION_SCALE);
        }

        private static long floor(double value) {
            long l = (long) value;
            return value < (double) l ? l - 1L : l;
        }
    }

    public static double rayIntersectionDistance(PositionSnapshot playerEye, PositionSnapshot targetPos) {
        final double halfWidth = 0.3;
        final double height = 1.8;
        double boxCenterX = targetPos.x;
        double boxCenterY = targetPos.y + height / 2.0;
        double boxCenterZ = targetPos.z;
        double dx = boxCenterX - playerEye.x;
        double dy = boxCenterY - playerEye.y;
        double dz = boxCenterZ - playerEye.z;
        double length = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (length < 0.001) {
            return 0.0;
        }
        double dirX = dx / length;
        double dirY = dy / length;
        double dirZ = dz / length;
        double minX = targetPos.x - halfWidth;
        double maxX = targetPos.x + halfWidth;
        double minY = targetPos.y;
        double maxY = targetPos.y + height;
        double minZ = targetPos.z - halfWidth;
        double maxZ = targetPos.z + halfWidth;
        double tMin = 0.0;
        double tMax = Double.MAX_VALUE;
        if (Math.abs(dirX) > 1.0E-8) {
            double t1 = (minX - playerEye.x) / dirX;
            double t2 = (maxX - playerEye.x) / dirX;
            if (t1 > t2) {
                double tmp = t1;
                t1 = t2;
                t2 = tmp;
            }
            tMin = Math.max(tMin, t1);
            tMax = Math.min(tMax, t2);
        } else {
            if (playerEye.x < minX || playerEye.x > maxX) {
                return length;
            }
        }
        if (Math.abs(dirY) > 1.0E-8) {
            double t1 = (minY - playerEye.y) / dirY;
            double t2 = (maxY - playerEye.y) / dirY;
            if (t1 > t2) {
                double tmp = t1;
                t1 = t2;
                t2 = tmp;
            }
            tMin = Math.max(tMin, t1);
            tMax = Math.min(tMax, t2);
        } else {
            if (playerEye.y < minY || playerEye.y > maxY) {
                return length;
            }
        }
        if (Math.abs(dirZ) > 1.0E-8) {
            double t1 = (minZ - playerEye.z) / dirZ;
            double t2 = (maxZ - playerEye.z) / dirZ;
            if (t1 > t2) {
                double tmp = t1;
                t1 = t2;
                t2 = tmp;
            }
            tMin = Math.max(tMin, t1);
            tMax = Math.min(tMax, t2);
        } else {
            if (playerEye.z < minZ || playerEye.z > maxZ) {
                return length;
            }
        }
        if (tMin > tMax || tMax < 0.0) {
            return length;
        }
        double hitT = tMin > 0.0 ? tMin : tMax;
        if (hitT < 0.0) {
            return length;
        }
        return hitT * Math.sqrt(dirX * dirX + dirY * dirY + dirZ * dirZ);
    }

    public static PositionSnapshot playerEyeSnapshot(net.minecraft.client.entity.EntityPlayerSP player) {
        return new PositionSnapshot(player.posX, player.posY + player.getEyeHeight(), player.posZ);
    }

    private BacktrackUtils() {
    }
}
