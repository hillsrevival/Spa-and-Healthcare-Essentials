package client.utils.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;

public final class AttackKeyController {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private AttackKeyController() {
    }

    public static void pressAttackKey() {
        KeyBinding attackKey = mc.gameSettings.keyBindAttack;
        KeyBinding.setKeyBindState(attackKey.getKeyCode(), true);
        KeyBinding.onTick(attackKey.getKeyCode());
    }

    public static void releaseAttackKey() {
        KeyBinding attackKey = mc.gameSettings.keyBindAttack;
        KeyBinding.setKeyBindState(attackKey.getKeyCode(), false);
    }

    public static boolean isAttackKeyDown() {
        return mc.gameSettings.keyBindAttack.isKeyDown();
    }
}
