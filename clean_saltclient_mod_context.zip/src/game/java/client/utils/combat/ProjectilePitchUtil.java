package client.utils.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.Vec3d;

public final class ProjectilePitchUtil {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final double ARROW_GRAVITY = 0.05;

    private static final double ARROW_SPEED = 3.0;

    private static final double LIGHT_GRAVITY = 0.03;

    private static final double LIGHT_SPEED = 1.5;

    private ProjectilePitchUtil() {
    }

    public static float calculateArrowPitch(EntityLivingBase target) {
        if (mc.player == null || target == null)
            return Float.NaN;
        return calculatePitch(target.posX, target.posY + target.height / 2.0, target.posZ, ARROW_SPEED, ARROW_GRAVITY);
    }

    public static float calculateLightProjectilePitch(EntityLivingBase target) {
        if (mc.player == null || target == null)
            return Float.NaN;
        return calculatePitch(target.posX, target.posY + target.height / 2.0, target.posZ, LIGHT_SPEED, LIGHT_GRAVITY);
    }

    public static float calculatePitch(double targetX, double targetY, double targetZ, double speed, double gravity) {
        if (mc.player == null)
            return Float.NaN;
        double deltaX = targetX - mc.player.posX;
        double deltaZ = targetZ - mc.player.posZ;
        double horizontalDistance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        double eyeY = mc.player.posY + mc.player.getEyeHeight();
        double verticalDistance = targetY - eyeY;
        double speedSquared = speed * speed;
        double speedFourth = speedSquared * speedSquared;
        double discriminant = speedFourth - gravity * (gravity * (horizontalDistance * horizontalDistance) + 2.0 * verticalDistance * speedSquared);
        if (discriminant < 0.0) {
            return Float.NaN;
        }
        double root = Math.sqrt(discriminant);
        double highAngle = Math.atan2(speedSquared + root, gravity * horizontalDistance);
        double lowAngle = Math.atan2(speedSquared - root, gravity * horizontalDistance);
        float pitch = (float) -Math.toDegrees(lowAngle);
        if (pitch < -90)
            pitch = -90;
        if (pitch > 90)
            pitch = 90;
        return pitch;
    }

    public static int calculateTimeToTarget(EntityLivingBase target) {
        return calculateTimeToTarget(target, ARROW_SPEED);
    }

    public static int calculateTimeToTarget(EntityLivingBase target, double arrowSpeed) {
        if (mc.player == null || target == null)
            return -1;
        if (arrowSpeed < 0.3)
            arrowSpeed = 0.3;
        double deltaX = target.posX - mc.player.posX;
        double deltaZ = target.posZ - mc.player.posZ;
        double horizontalDistance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        return (int) Math.ceil(horizontalDistance / arrowSpeed);
    }
}
