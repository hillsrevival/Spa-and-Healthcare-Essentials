package client.utils.combat;

import client.utils.misc.MathUtils;
import client.utils.movement.RotationUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.Vec3d;

public class CombatUtils {

    private static long lastAttackTime = 0;

    private static Object lastAttackTarget = null;

    private static int switchDelayTicks = 0;

    private static int cachedCPS = 10;

    private static long cachedCPSTick = -1;

    private static long cachedDelayMs = 100;

    public static class AttackTimer {

        private long nextAttackTime = 0L;

        private final java.util.Random random = new java.util.Random();

        private int lastMinCps = -1;

        private int lastMaxCps = -1;

        public boolean canAttack(int minCPS, int maxCPS) {
            long now = System.currentTimeMillis();
            if (minCPS != lastMinCps || maxCPS != lastMaxCps) {
                lastMinCps = minCPS;
                lastMaxCps = maxCPS;
                nextAttackTime = 0L;
            }
            if (now < nextAttackTime) {
                return false;
            }
            double medianCps = (minCPS + maxCPS) / 2.0;
            double cps = medianCps * Math.exp(random.nextGaussian() * 0.25);
            if (cps < minCPS)
                cps = minCPS + random.nextDouble() * 0.5;
            if (cps > maxCPS)
                cps = maxCPS - random.nextDouble() * 0.5;
            long delay = (long) (1000.0 / cps);
            delay = (long) (delay * (0.92 + random.nextDouble() * 0.16));
            if (delay < 40)
                delay = 40;
            nextAttackTime = now + delay;
            return true;
        }

        public void reset() {
            nextAttackTime = 0L;
        }
    }

    public static boolean canAttack(int minCPS, int maxCPS) {
        long now = System.currentTimeMillis();
        long currentTick = now / 50;
        if (currentTick != cachedCPSTick) {
            cachedCPSTick = currentTick;
            cachedCPS = minCPS + (int) (Math.random() * (maxCPS - minCPS + 1));
            long minDelay = 1000 / cachedCPS;
            cachedDelayMs = (long) (minDelay * (0.80 + Math.random() * 0.40));
            if (cachedDelayMs < 50)
                cachedDelayMs = 50;
        }
        if (now - lastAttackTime >= cachedDelayMs) {
            lastAttackTime = now;
            return true;
        }
        return false;
    }

    public static boolean canAttackMs(long minDelayMs) {
        long now = System.currentTimeMillis();
        if (now - lastAttackTime >= minDelayMs) {
            lastAttackTime = now;
            return true;
        }
        return false;
    }

    public static Object getTargetWithDelay(Object currentTarget, Object desiredTarget, int minDelay, int maxDelay) {
        int currentId = getEntityId(currentTarget);
        int desiredId = getEntityId(desiredTarget);
        if (desiredId != currentId) {
            lastAttackTarget = desiredTarget;
            switchDelayTicks = minDelay + (int) (Math.random() * (maxDelay - minDelay + 1));
            return null;
        }
        if (switchDelayTicks > 0) {
            switchDelayTicks--;
            return null;
        }
        return desiredTarget;
    }

    public static void resetSwitchDelay() {
        lastAttackTarget = null;
        switchDelayTicks = 0;
    }

    private static int getEntityId(Object obj) {
        if (obj instanceof net.minecraft.entity.Entity) {
            return ((net.minecraft.entity.Entity) obj).getEntityId();
        }
        return obj == null ? -1 : System.identityHashCode(obj);
    }

    public static boolean isWeaponReady(float minPercent) {
        if (Minecraft.getMinecraft().player == null)
            return false;
        return Minecraft.getMinecraft().player.getCooledAttackStrength(0.5F) >= minPercent;
    }

    public static boolean isWeaponFullyCharged() {
        if (Minecraft.getMinecraft().player == null)
            return false;
        return Minecraft.getMinecraft().player.getCooledAttackStrength(0.5F) >= 1.0F;
    }

    public static float getCooldownProgress() {
        if (Minecraft.getMinecraft().player == null)
            return 0.0F;
        return Minecraft.getMinecraft().player.getCooledAttackStrength(0.5F);
    }

    public static boolean isInRange(net.minecraft.entity.Entity entity, double maxReach) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null)
            return false;
        return mc.player.getDistanceToEntity(entity) <= maxReach;
    }

    public static double getReachDistance(net.minecraft.entity.Entity entity) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null)
            return Double.MAX_VALUE;
        Vec3d eyesPos = RotationUtils.getEyesPos();
        net.minecraft.util.math.AxisAlignedBB box = entity.getEntityBoundingBox();
        double nearestX = MathUtils.clamp(eyesPos.xCoord, box.minX, box.maxX);
        double nearestY = MathUtils.clamp(eyesPos.yCoord, box.minY, box.maxY);
        double nearestZ = MathUtils.clamp(eyesPos.zCoord, box.minZ, box.maxZ);
        double dx = eyesPos.xCoord - nearestX;
        double dy = eyesPos.yCoord - nearestY;
        double dz = eyesPos.zCoord - nearestZ;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public static boolean isReachValid(net.minecraft.entity.Entity entity, double maxReach) {
        return getReachDistance(entity) <= maxReach;
    }

    public static void reset() {
        lastAttackTime = 0;
        lastAttackTarget = null;
        switchDelayTicks = 0;
    }
}
