package client.utils.combat;

import client.utils.world.EnchantmentUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.init.Enchantments;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.CombatRules;
import java.util.HashMap;
import java.util.Map;

public final class OpponentHealthTracker {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final Map<Integer, TrackedState> trackedPlayers = new HashMap<>();

    private OpponentHealthTracker() {
    }

    public static void update() {
        if (mc.world == null)
            return;
        for (Map.Entry<Integer, TrackedState> entry : trackedPlayers.entrySet()) {
            Entity entity = mc.world.getEntityByID(entry.getKey());
            if (entity instanceof EntityLivingBase) {
                entry.getValue().update((EntityLivingBase) entity);
            }
        }
        trackedPlayers.entrySet().removeIf(entry -> {
            Entity entity = mc.world.getEntityByID(entry.getKey());
            return entity == null || entity.isDead;
        });
    }

    public static float getEstimatedHealth(EntityLivingBase entity) {
        if (entity == null)
            return 0.0f;
        TrackedState state = trackedPlayers.get(entity.getEntityId());
        if (state == null) {
            state = new TrackedState();
            state.estimatedHealth = entity.getHealth();
            trackedPlayers.put(entity.getEntityId(), state);
        }
        return state.estimatedHealth;
    }

    public static void recordAttack(EntityLivingBase target, boolean crit) {
        if (target == null || mc.player == null)
            return;
        TrackedState state = trackedPlayers.get(target.getEntityId());
        if (state == null) {
            state = new TrackedState();
            state.estimatedHealth = target.getHealth();
            trackedPlayers.put(target.getEntityId(), state);
        }
        ItemStack weapon = mc.player.getHeldItemMainhand();
        float damage = calculateAttackDamage(weapon, target, crit);
        state.estimatedHealth -= damage;
        if (state.estimatedHealth < 0)
            state.estimatedHealth = 0;
        state.ticksSinceAttack = 0;
        state.attackPending = true;
    }

    public static void resetTracking(int entityId) {
        trackedPlayers.remove(entityId);
    }

    public static void reset() {
        trackedPlayers.clear();
    }

    public static float calculateAttackDamage(ItemStack weapon, EntityLivingBase target, boolean crit) {
        float baseDamage = getWeaponBaseDamage(weapon);
        float enchantDamage = getEnchantmentDamage(weapon, target);
        float totalDamage = baseDamage + enchantDamage;
        if (crit && baseDamage > 0) {
            baseDamage *= 1.5f;
            totalDamage = baseDamage + enchantDamage;
        }
        if (totalDamage <= 0)
            return 0;
        return applyDamageReductions(target, totalDamage);
    }

    private static float getWeaponBaseDamage(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return 1.0f;
        if (stack.getItem() instanceof ItemSword) {
            ItemSword sword = (ItemSword) stack.getItem();
            return sword.getDamageVsEntity() + 1.0f;
        }
        if (stack.getItem() instanceof ItemTool) {
            ItemTool tool = (ItemTool) stack.getItem();
            return tool.damageVsEntity + 1.0f;
        }
        return 1.0f;
    }

    private static float getEnchantmentDamage(ItemStack stack, EntityLivingBase target) {
        if (stack == null || stack.func_190926_b())
            return 0;
        float total = 0;
        int sharpness = EnchantmentUtil.getSharpness(stack);
        if (sharpness > 0) {
            total += 0.5f + 0.5f * sharpness;
        }
        if (target != null) {
            EnumCreatureAttribute attr = target.getCreatureAttribute();
            int smite = EnchantmentUtil.getSmite(stack);
            if (smite > 0 && attr == EnumCreatureAttribute.UNDEAD) {
                total += 2.5f * smite;
            }
            int boa = EnchantmentUtil.getBaneOfArthropods(stack);
            if (boa > 0 && attr == EnumCreatureAttribute.ARTHROPOD) {
                total += 2.5f * boa;
            }
        }
        return total;
    }

    private static float applyDamageReductions(EntityLivingBase target, float damage) {
        if (target == null || damage <= 0)
            return 0;
        int armorValue = target.getTotalArmorValue();
        float armorToughness = 0.0f;
        damage = CombatRules.getDamageAfterAbsorb(damage, armorValue, armorToughness);
        if (target.isPotionActive(MobEffects.RESISTANCE)) {
            PotionEffect resistance = target.getActivePotionEffect(MobEffects.RESISTANCE);
            int level = resistance.getAmplifier() + 1;
            damage *= (float) Math.max(0, 25 - 5 * level) / 25.0f;
        }
        int protection = 0;
        for (ItemStack piece : target.getArmorInventoryList()) {
            if (piece != null && !piece.func_190926_b()) {
                protection += net.minecraft.enchantment.EnchantmentHelper.getEnchantmentLevel(Enchantments.PROTECTION, piece);
            }
        }
        protection = Math.min(protection, 20);
        if (protection > 0) {
            damage *= (1.0f - Math.min(protection * 0.04f, 0.80f));
        }
        return Math.max(damage, 0);
    }

    private static class TrackedState {

        float estimatedHealth = 20.0f;

        int ticksSinceAttack = 0;

        boolean attackPending = false;

        int foodTickTimer = 0;

        float lastFallDistance = 0;

        boolean wasOnGround = true;

        void update(EntityLivingBase entity) {
            ticksSinceAttack++;
            if (estimatedHealth > entity.getMaxHealth()) {
                estimatedHealth = entity.getMaxHealth();
            }
            if (estimatedHealth < 0)
                estimatedHealth = 0;
            float clientHealth = entity.getHealth();
            float diff = Math.abs(estimatedHealth - clientHealth);
            boolean attackGrace = attackPending && ticksSinceAttack <= 5;
            if (diff > 6.0f && !attackGrace) {
                estimatedHealth = clientHealth;
            }
            if (wasOnGround && !entity.onGround && entity.motionY > 0) {
                lastFallDistance = 0;
            }
            if (!entity.onGround) {
                lastFallDistance = Math.max(lastFallDistance, entity.fallDistance);
            }
            if (entity.onGround && !wasOnGround && lastFallDistance > 3.0f) {
                float fallDamage = lastFallDistance - 3.0f;
                if (entity.isPotionActive(MobEffects.JUMP_BOOST)) {
                    PotionEffect jump = entity.getActivePotionEffect(MobEffects.JUMP_BOOST);
                    fallDamage -= (jump.getAmplifier() + 1);
                }
                if (fallDamage > 0) {
                    estimatedHealth -= applyDamageReductions(entity, fallDamage);
                }
                lastFallDistance = 0;
            }
            wasOnGround = entity.onGround;
            if (estimatedHealth > 0 && estimatedHealth < entity.getMaxHealth()) {
                foodTickTimer++;
                if (foodTickTimer >= 80) {
                    estimatedHealth += 1.0f;
                    foodTickTimer = 0;
                }
            } else {
                foodTickTimer = 0;
            }
            if (attackPending && ticksSinceAttack > 5) {
                attackPending = false;
            }
        }
    }

    public static void onWorldChange() {
        trackedPlayers.clear();
    }
}
