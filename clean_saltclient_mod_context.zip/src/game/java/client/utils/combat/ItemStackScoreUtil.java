package client.utils.combat;

import client.utils.world.EnchantmentUtil;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;

public final class ItemStackScoreUtil {

    private ItemStackScoreUtil() {
    }

    public static float scoreWeapon(ItemStack stack, EntityLivingBase target) {
        if (stack == null || stack.func_190926_b())
            return 0;
        float damage = 0;
        boolean isWeapon = false;
        if (stack.getItem() instanceof ItemSword) {
            ItemSword sword = (ItemSword) stack.getItem();
            damage = sword.getDamageVsEntity() + 1.0f;
            isWeapon = true;
        } else if (stack.getItem() instanceof ItemTool) {
            ItemTool tool = (ItemTool) stack.getItem();
            damage = tool.damageVsEntity + 1.0f;
            isWeapon = true;
        }
        if (!isWeapon)
            return 0;
        damage += getEnchantmentDamage(stack, target);
        return damage;
    }

    public static float scoreWeaponGeneric(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return 0;
        float damage = 0;
        boolean isWeapon = false;
        if (stack.getItem() instanceof ItemSword) {
            ItemSword sword = (ItemSword) stack.getItem();
            damage = sword.getDamageVsEntity() + 1.0f;
            isWeapon = true;
        } else if (stack.getItem() instanceof ItemTool) {
            ItemTool tool = (ItemTool) stack.getItem();
            damage = tool.damageVsEntity + 1.0f;
            isWeapon = true;
        }
        if (!isWeapon)
            return 0;
        int sharpness = EnchantmentUtil.getSharpness(stack);
        if (sharpness > 0) {
            damage += 0.5f + 0.5f * sharpness;
        }
        return damage;
    }

    private static float getEnchantmentDamage(ItemStack stack, EntityLivingBase target) {
        if (target == null)
            return 0;
        float total = 0;
        int sharpness = EnchantmentUtil.getSharpness(stack);
        if (sharpness > 0) {
            total += 0.5f + 0.5f * sharpness;
        }
        EnumCreatureAttribute attr = target.getCreatureAttribute();
        int smite = EnchantmentUtil.getSmite(stack);
        if (smite > 0 && attr == EnumCreatureAttribute.UNDEAD) {
            total += 2.5f * smite;
        }
        int boa = EnchantmentUtil.getBaneOfArthropods(stack);
        if (boa > 0 && attr == EnumCreatureAttribute.ARTHROPOD) {
            total += 2.5f * boa;
        }
        return total;
    }

    public static int findBestWeaponSlot(EntityLivingBase target) {
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getMinecraft();
        if (mc.player == null)
            return -1;
        float bestDamage = 0;
        int bestSlot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == null || stack.func_190926_b())
                continue;
            float damage;
            if (target != null) {
                damage = scoreWeapon(stack, target);
            } else {
                damage = scoreWeaponGeneric(stack);
            }
            if (damage > bestDamage) {
                bestDamage = damage;
                bestSlot = i;
            }
        }
        return bestSlot;
    }

    public static int findBestWeaponSlot() {
        return findBestWeaponSlot(null);
    }
}
