package client.utils.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;
import client.utils.EntityUtils;
import client.utils.misc.FriendManager;
import client.utils.movement.RotationUtils;

public final class TargetSelector {

    private static final Minecraft mc = Minecraft.getMinecraft();

    public static class Criteria {

        public boolean targetPlayers = true;

        public boolean targetHostile = true;

        public boolean targetPassive = false;

        public boolean targetInvisible = true;

        public boolean hitThroughWalls = false;

        public double range = 3.03;

        public double fov = 360.0;

        public double aimLeadTicks = -1.0;

        public static void applyMobMode(Criteria c, String mobMode) {
            c.targetHostile = mobMode.equals("Hostile") || mobMode.equals("Both");
            c.targetPassive = mobMode.equals("Passive") || mobMode.equals("Both");
        }
    }

    private static final Map<Entity, Vec3d> predCache = new HashMap<>();

    private static final Map<Entity, Double> predTicks = new HashMap<>();

    private static long cacheTick = Long.MIN_VALUE;

    private static void ensureCacheFresh() {
        long now = mc.player != null ? mc.player.ticksExisted : 0L;
        if (now != cacheTick) {
            cacheTick = now;
            predCache.clear();
            predTicks.clear();
        }
    }

    public static float getPredictedAngleToEntity(EntityLivingBase entity, double ticks) {
        if (mc.player == null || entity == null)
            return 0.0f;
        if (ticks < 0)
            ticks = AimUtils.getLatencyLeadTicks();
        ensureCacheFresh();
        Vec3d predicted = predCache.get(entity);
        Double usedTicks = predTicks.get(entity);
        if (predicted == null || usedTicks == null || usedTicks.doubleValue() != ticks) {
            predicted = PlayerSimulationUtil.predictWithFallback(entity, (int) Math.max(1, ticks));
            predCache.put(entity, predicted);
            predTicks.put(entity, Double.valueOf(ticks));
        }
        double diffX = predicted.xCoord - mc.player.posX;
        double diffY = predicted.yCoord - (mc.player.posY + mc.player.getEyeHeight());
        double diffZ = predicted.zCoord - mc.player.posZ;
        double len = Math.sqrt(diffX * diffX + diffY * diffY + diffZ * diffZ);
        if (len < 1.0E-4)
            return 0.0f;
        Vec3d look = SilentAimUtil.isActive() ? RotationUtils.getLookVec(SilentAimUtil.getRealYaw(), SilentAimUtil.getRealPitch()) : mc.player.getLookVec();
        double dot = (look.xCoord * diffX + look.yCoord * diffY + look.zCoord * diffZ) / len;
        if (dot > 1.0)
            dot = 1.0;
        if (dot < -1.0)
            dot = -1.0;
        return (float) Math.toDegrees(Math.acos(dot));
    }

    public static boolean isValidTarget(EntityLivingBase living, Criteria c) {
        if (living == null || mc.player == null)
            return false;
        if (!EntityUtils.isAlive(living))
            return false;
        if (living.isInvisible() && !c.targetInvisible)
            return false;
        if (FriendManager.isFriend(living))
            return false;
        if (living instanceof EntityPlayer) {
            if (!c.targetPlayers)
                return false;
        } else if (living instanceof IMob) {
            if (!c.targetHostile)
                return false;
        } else if (living instanceof EntityAnimal) {
            if (!c.targetPassive)
                return false;
        } else {
            if (!c.targetPassive)
                return false;
        }
        if (!CombatUtils.isReachValid(living, c.range))
            return false;
        if (!c.hitThroughWalls && !mc.player.canEntityBeSeen(living)) {
            return false;
        }
        if (c.fov < 360.0) {
            if (getPredictedAngleToEntity(living, c.aimLeadTicks) > c.fov / 2.0) {
                return false;
            }
        }
        return true;
    }

    public static List<EntityLivingBase> getValidTargets(Criteria c) {
        List<EntityLivingBase> list = new ArrayList<>();
        if (mc.player == null || mc.world == null)
            return list;
        for (Entity entity : EntityUtils.getLoadedEntities()) {
            if (entity == mc.player)
                continue;
            if (!(entity instanceof EntityLivingBase))
                continue;
            EntityLivingBase living = (EntityLivingBase) entity;
            if (isValidTarget(living, c)) {
                list.add(living);
            }
        }
        return list;
    }

    public static void sortByPriority(List<EntityLivingBase> targets, String mode, double aimLeadTicks) {
        if (targets == null || targets.isEmpty())
            return;
        if (mode.equals("Health")) {
            targets.sort(Comparator.comparingDouble(EntityLivingBase::getHealth).thenComparingDouble(EntityLivingBase::getAbsorptionAmount));
        } else if (mode.equals("Angle")) {
            final double lead = aimLeadTicks;
            targets.sort(Comparator.comparingDouble(e -> getPredictedAngleToEntity(e, lead)));
        } else {
            targets.sort(Comparator.comparingDouble(CombatUtils::getReachDistance));
        }
    }

    public static EntityLivingBase selectTarget(Criteria c, String mode) {
        List<EntityLivingBase> targets = getValidTargets(c);
        if (targets.isEmpty())
            return null;
        sortByPriority(targets, mode, c.aimLeadTicks);
        return targets.get(0);
    }
}
