package client.utils.combat;

import client.Client;
import client.event.events.AttackEvent;
import client.utils.movement.RotationUtils;
import client.utils.world.InteractionUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;

public final class CombatAttackExecutor {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static boolean keyHeld = false;

    private static EntityLivingBase attackTarget = null;

    private static boolean shouldSwing = true;

    private static boolean attackSuccess = false;

    private CombatAttackExecutor() {
    }

    public static boolean tryAttack(EntityLivingBase target, double reach, boolean swingArm) {
        if (mc.player == null || mc.world == null)
            return false;
        if (target == null)
            return false;
        if (CombatRotationManager.isActive()) {
            if (!CombatRotationManager.isOnTarget(target, reach)) {
                return false;
            }
        } else {
            if (!RotationUtils.isRotationOnEntity(mc.player.rotationYaw, mc.player.rotationPitch, target, reach)) {
                return false;
            }
        }
        if (!target.isEntityAlive())
            return false;
        if (target.getHealth() <= 0)
            return false;
        pressAttackKey(target, swingArm);
        return true;
    }

    public static boolean tryAttack(EntityLivingBase target, double reach) {
        return tryAttack(target, reach, true);
    }

    private static void pressAttackKey(EntityLivingBase target, boolean swingArm) {
        attackTarget = target;
        shouldSwing = swingArm;
        attackSuccess = true;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), true);
        keyHeld = true;
    }

    public static void releaseAttackKey() {
        if (!keyHeld)
            return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
        keyHeld = false;
    }

    public static boolean isKeyHeld() {
        return keyHeld;
    }

    public static EntityLivingBase getAttackTarget() {
        return attackTarget;
    }

    public static boolean wasAttackSuccessful() {
        return attackSuccess;
    }

    public static boolean directAttack(EntityLivingBase target, double reach, boolean swingArm) {
        if (mc.player == null || target == null)
            return false;
        if (!RotationUtils.isRotationOnEntity(mc.player.rotationYaw, mc.player.rotationPitch, target, reach)) {
            return false;
        }
        if (!target.isEntityAlive())
            return false;
        if (target.getHealth() <= 0)
            return false;
        CombatContext.recordMyAttack();
        CombatTracker.onPlayerAttack(target);
        attackSuccess = true;
        InteractionUtils.attack(target);
        if (swingArm) {
            mc.player.swingArm(EnumHand.MAIN_HAND);
        }
        return true;
    }

    public static boolean directAttack(EntityLivingBase target, double reach) {
        return directAttack(target, reach, true);
    }

    public static boolean directAttack(Entity target, double reach, boolean swingArm) {
        if (mc.player == null || target == null)
            return false;
        if (!RotationUtils.isRotationOnEntity(mc.player.rotationYaw, mc.player.rotationPitch, target, reach)) {
            return false;
        }
        if (!target.isEntityAlive())
            return false;
        attackSuccess = true;
        InteractionUtils.attack(target);
        if (swingArm) {
            mc.player.swingArm(EnumHand.MAIN_HAND);
        }
        return true;
    }

    public static boolean directAttack(Entity target, double reach) {
        return directAttack(target, reach, true);
    }

    public static boolean executePreFlyingAttack(Entity target, double reach, boolean swingArm) {
        if (mc.player == null || mc.world == null)
            return false;
        if (target == null)
            return false;
        if (!RotationUtils.isRotationOnEntity(mc.player.rotationYaw, mc.player.rotationPitch, target, reach)) {
            return false;
        }
        if (!target.isEntityAlive())
            return false;
        if (target instanceof EntityLivingBase && ((EntityLivingBase) target).getHealth() <= 0)
            return false;
        alignSprintToServerView();
        AttackEvent event = new AttackEvent(target, EnumHand.MAIN_HAND);
        Client.bus().post(event);
        if (event.isCancelled())
            return false;
        if (target instanceof EntityLivingBase) {
            CombatContext.recordMyAttack();
            CombatTracker.onPlayerAttack((EntityLivingBase) target);
        } else {
            CombatContext.recordMyAttack();
        }
        AttackControlClaim.recordAttack();
        attackSuccess = true;
        mc.playerController.sendUseEntityPacket(target);
        if (!mc.player.isSpectator()) {
            boolean wasSprinting = mc.player.isSprinting();
            double preSlowX = mc.player.motionX;
            double preSlowZ = mc.player.motionZ;
            float cooldownProgress = mc.player.getCooledAttackStrength(0.5F);
            int kbLevel = net.minecraft.enchantment.EnchantmentHelper.getKnockbackModifier(mc.player);
            mc.player.attackTargetEntityWithCurrentItem(target);
            mc.player.resetCooldown();
            boolean vanillaSlowed = (wasSprinting && !mc.player.isSprinting()) || (Math.abs(mc.player.motionX - preSlowX * 0.6D) < 1.0E-9D && Math.abs(mc.player.motionZ - preSlowZ * 0.6D) < 1.0E-9D && (preSlowX != 0.0D || preSlowZ != 0.0D));
            boolean grimCertainSlow = (wasSprinting && kbLevel >= 0 && cooldownProgress > 0.7F) || kbLevel > 0;
            if (grimCertainSlow && !vanillaSlowed) {
                mc.player.motionX *= 0.6D;
                mc.player.motionZ *= 0.6D;
                mc.player.setSprinting(false);
            }
        }
        if (swingArm) {
            mc.player.swingArm(EnumHand.MAIN_HAND);
        }
        return true;
    }

    public static boolean executePreFlyingAttack(Entity target, double reach) {
        return executePreFlyingAttack(target, reach, true);
    }

    private static void alignSprintToServerView() {
        if (mc.player == null)
            return;
        boolean serverView = mc.player.isServerSprintState();
        if (mc.player.isSprinting() != serverView) {
            mc.player.setSprinting(serverView);
        }
    }

    public static void reset() {
        if (keyHeld) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
            keyHeld = false;
        }
        attackTarget = null;
        shouldSwing = true;
        attackSuccess = false;
        packetPreSent = false;
        swingPreSent = false;
    }

    private static boolean packetPreSent = false;

    public static boolean preSendAttackPacket(EntityLivingBase target, double reach) {
        if (mc.player == null || target == null)
            return false;
        if (!RotationUtils.isRotationOnEntity(mc.player.rotationYaw, mc.player.rotationPitch, target, reach)) {
            return false;
        }
        if (!target.isEntityAlive())
            return false;
        if (target.getHealth() <= 0)
            return false;
        mc.playerController.sendUseEntityPacket(target);
        packetPreSent = true;
        return true;
    }

    public static boolean preSendAttackPacket(EntityLivingBase target) {
        if (mc.player == null || target == null)
            return false;
        if (!target.isEntityAlive())
            return false;
        if (target.getHealth() <= 0)
            return false;
        mc.playerController.sendUseEntityPacket(target);
        packetPreSent = true;
        return true;
    }

    public static boolean wasPacketPreSent() {
        return packetPreSent;
    }

    public static void clearPacketPreSent() {
        packetPreSent = false;
    }

    private static boolean swingPreSent = false;

    public static void preSendSwingPacket() {
        if (mc.player == null)
            return;
        if (!packetPreSent)
            return;
        mc.player.connection.sendPacket(new CPacketAnimation(EnumHand.MAIN_HAND));
        swingPreSent = true;
    }

    public static boolean wasSwingPreSent() {
        return swingPreSent;
    }

    public static void clearSwingPreSent() {
        swingPreSent = false;
    }

    private static boolean jumpKeyHeld = false;

    public static void injectVanillaJump() {
        if (mc.player == null)
            return;
        if (!mc.player.onGround)
            return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), true);
        jumpKeyHeld = true;
    }

    public static void releaseJumpKey() {
        if (!jumpKeyHeld)
            return;
        boolean screenBlocking = mc.currentScreen != null && !mc.currentScreen.allowUserInput;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), !screenBlocking && net.lax1dude.eaglercraft.Keyboard.isKeyDown(mc.gameSettings.keyBindJump.getKeyCode()));
        jumpKeyHeld = false;
    }
}
