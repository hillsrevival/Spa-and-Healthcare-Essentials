package client.utils.combat;

import net.minecraft.client.Minecraft;

public final class AttackControlClaim {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static String claimHolder = null;

    private static int claimPriority = -1;

    private static boolean attackFiredThisTick = false;

    private static long lastClaimTick = -1;

    private AttackControlClaim() {
    }

    private static void checkTickAdvance() {
        long now = mc.player != null ? mc.player.ticksExisted : -1L;
        if (now != lastClaimTick) {
            if (now >= 0) {
                claimHolder = null;
                claimPriority = -1;
                attackFiredThisTick = false;
            }
            lastClaimTick = now;
        }
    }

    public static void resetTick() {
        claimHolder = null;
        claimPriority = -1;
        attackFiredThisTick = false;
    }

    public static boolean tryClaim(String moduleName, int priority) {
        checkTickAdvance();
        if (moduleName.equals(claimHolder)) {
            return true;
        }
        if (claimHolder == null) {
            claimHolder = moduleName;
            claimPriority = priority;
            return true;
        }
        if (priority > claimPriority) {
            claimHolder = moduleName;
            claimPriority = priority;
            return true;
        }
        return false;
    }

    public static boolean hasClaim(String moduleName) {
        checkTickAdvance();
        return moduleName.equals(claimHolder);
    }

    public static void recordAttack() {
        checkTickAdvance();
        attackFiredThisTick = true;
    }

    public static boolean wasAttackFiredThisTick() {
        checkTickAdvance();
        return attackFiredThisTick;
    }

    public static String getClaimHolder() {
        return claimHolder;
    }

    public static boolean shouldAttack(String moduleName, int priority) {
        checkTickAdvance();
        if (attackFiredThisTick)
            return false;
        return tryClaim(moduleName, priority);
    }

    public static void reset() {
        claimHolder = null;
        claimPriority = -1;
        attackFiredThisTick = false;
        lastClaimTick = -1;
    }
}
