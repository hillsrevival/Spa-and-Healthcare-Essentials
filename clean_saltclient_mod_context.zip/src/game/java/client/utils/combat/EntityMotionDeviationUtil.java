package client.utils.combat;

import net.minecraft.util.math.Vec3d;

public final class EntityMotionDeviationUtil {

    private EntityMotionDeviationUtil() {
    }

    public static double calculateDeviation(double sourceX, double sourceY, double sourceZ, double dirX, double dirY, double dirZ, double targetX, double targetY, double targetZ, double horizontalSize, double verticalSize, double padding) {
        double dirLength = Math.sqrt(dirX * dirX + dirY * dirY + dirZ * dirZ);
        if (dirLength == 0.0)
            dirLength = 1.0;
        double deltaX = targetX - sourceX;
        double deltaY = targetY - sourceY;
        double deltaZ = targetZ - sourceZ;
        double t = (deltaX * dirX + deltaY * dirY + deltaZ * dirZ) / (dirLength * dirLength);
        double projectedX = t * dirX;
        double projectedY = t * dirY;
        double projectedZ = t * dirZ;
        double deviation = 0.0;
        deviation += Math.max(Math.abs(deltaX - projectedX) - (horizontalSize / 2.0 + padding), 0.0);
        deviation += Math.max(Math.abs(deltaZ - projectedZ) - (horizontalSize / 2.0 + padding), 0.0);
        deviation += Math.max(Math.abs(deltaY - projectedY) - (verticalSize / 2.0 + padding), 0.0);
        return deviation;
    }
}
