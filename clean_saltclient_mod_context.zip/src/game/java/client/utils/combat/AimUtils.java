package client.utils.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.Vec3d;
import client.utils.movement.RotationUtils;

public final class AimUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static double cachedLatencyLeadTicks = 0.5;

    private static long lastLatencyRefreshTick = -100L;

    public static double getLatencyLeadTicks() {
        long now = mc.player != null ? mc.player.ticksExisted : 0L;
        if (now - lastLatencyRefreshTick >= 20L) {
            lastLatencyRefreshTick = now;
            cachedLatencyLeadTicks = 0.5;
            try {
                if (mc.player != null && mc.getConnection() != null) {
                    net.minecraft.client.network.NetworkPlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUniqueID());
                    if (info != null) {
                        int ping = info.getResponseTime();
                        if (ping >= 0 && ping <= 1000) {
                            cachedLatencyLeadTicks = Math.max(0.5, Math.min(3.0, ping / 50.0 + 0.5));
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }
        return cachedLatencyLeadTicks;
    }

    public static double getAimLeadTicks(boolean latencyDriven, double manualTicksSetting) {
        if (!latencyDriven) {
            return manualTicksSetting * 0.5;
        }
        return getLatencyLeadTicks();
    }

    public static Vec3d predictAimPoint(EntityLivingBase target, RotationUtils.AimPoint aim, double leadTicks) {
        Vec3d baseAimVec = RotationUtils.getAimPoint(target, aim);
        Vec3d predicted = PlayerSimulationUtil.predictWithFractionalTicks(target, Math.max(0.5, leadTicks));
        Vec3d aimVec = baseAimVec.add(new Vec3d(predicted.xCoord - target.posX, predicted.yCoord - target.posY, predicted.zCoord - target.posZ));
        return compensateOwnMotion(aimVec);
    }

    public static Vec3d compensateOwnMotion(Vec3d aimVec) {
        if (mc.player == null)
            return aimVec;
        return aimVec.subtract(new Vec3d(mc.player.motionX, mc.player.onGround ? 0.0 : mc.player.motionY, mc.player.motionZ));
    }

    public static boolean isCritPossible() {
        if (mc.player == null)
            return false;
        return !mc.player.onGround && mc.player.fallDistance > 0 && !mc.player.isSprinting() && !mc.player.isInWater();
    }

    public static boolean isCritPossibleExtended() {
        if (mc.player == null)
            return false;
        return isCritPossible() && !mc.player.isOnLadder() && !mc.player.isRiding();
    }
}
