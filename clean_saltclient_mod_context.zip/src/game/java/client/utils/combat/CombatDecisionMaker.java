package client.utils.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.enchantment.EnchantmentHelper;

public final class CombatDecisionMaker {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static boolean enabled = true;

    private static boolean skipRetreating = true;

    private static boolean skipAirborne = false;

    private static boolean skipHurtTarget = false;

    private static boolean skipFrameDisadvantage = false;

    private static boolean skipPostKnockbackOutOfRange = false;

    private static double minApproachVelocity = -0.12;

    private static double closeRangeThreshold = 2.5;

    private static int opponentComboDefensive = 5;

    private static String mode = "Aggressive";

    private static boolean strategicEnabled = false;

    private static double disengageHealthThreshold = 4.0;

    private static double disengageHealthGap = 10.0;

    private static int opponentComboDisengage = 5;

    private static double pressAdvantageGap = 8.0;

    private static boolean checkOpponentWeapon = false;

    private CombatDecisionMaker() {
    }

    public static void configureTactical(boolean enabled_) {
        enabled = enabled_;
    }

    public static void configureTactical(boolean enabled_, boolean skipRetreating_, boolean skipAirborne_, boolean skipFrameDisadvantage_, boolean skipPostKnockbackOutOfRange_, String mode_) {
        enabled = enabled_;
        skipRetreating = skipRetreating_;
        skipAirborne = skipAirborne_;
        skipFrameDisadvantage = skipFrameDisadvantage_;
        skipPostKnockbackOutOfRange = skipPostKnockbackOutOfRange_;
        mode = mode_;
    }

    public static void configureSkipHurtTarget(boolean skip) {
        skipHurtTarget = skip;
    }

    public static void configureStrategic(boolean enabled_, double disengageHP, double hpGap, int comboDisengage, double pressGap, boolean checkWeapon) {
        strategicEnabled = enabled_;
        disengageHealthThreshold = disengageHP;
        disengageHealthGap = hpGap;
        opponentComboDisengage = comboDisengage;
        pressAdvantageGap = pressGap;
        checkOpponentWeapon = checkWeapon;
    }

    public static void evaluate() {
        if (mc.player == null || mc.world == null) {
            CombatContext.setShouldEngage(true, "");
            return;
        }
        EntityLivingBase target = CombatContext.getTarget();
        if (target == null) {
            CombatContext.setShouldEngage(true, "");
            return;
        }
        if (!enabled) {
            CombatContext.setShouldEngage(true, "");
            if (strategicEnabled) {
                evaluateStrategic(target);
            }
            return;
        }
        evaluateTactical(target);
        if (strategicEnabled) {
            evaluateStrategic(target);
        }
    }

    private static void evaluateTactical(EntityLivingBase target) {
        double reach = CombatUtils.getReachDistance(target);
        if (reach <= closeRangeThreshold) {
            CombatContext.setShouldEngage(true, "");
            return;
        }
        if (mode.equals("Aggressive")) {
            evaluateAggressive(target);
        } else if (mode.equals("Defensive")) {
            evaluateDefensive(target);
        } else {
            evaluateSmart(target);
        }
    }

    private static void evaluateSmart(EntityLivingBase target) {
        if (skipRetreating) {
            double approach = TargetPrediction.getApproachVelocity(target);
            if (approach < minApproachVelocity) {
                CombatContext.setShouldEngage(false, "retreating");
                return;
            }
        }
        if (skipAirborne && CombatContext.isOpponentAirborne()) {
            boolean descendingTowardUs = target.motionY < 0 && TargetPrediction.getApproachVelocity(target) > 0;
            if (!descendingTowardUs) {
                CombatContext.setShouldEngage(false, "airborne");
                return;
            }
        }
        if (skipHurtTarget && CombatContext.isOpponentHurt()) {
            CombatContext.setShouldEngage(false, "target-hurt");
            return;
        }
        if (skipFrameDisadvantage && isAtFrameDisadvantage()) {
            CombatContext.setShouldEngage(false, "frame-disadvantage");
            return;
        }
        if (skipPostKnockbackOutOfRange && !willStayInRangeAfterHit(target)) {
            CombatContext.setShouldEngage(false, "kb-out-of-range");
            return;
        }
        if (CombatContext.getOpponentComboCount() >= opponentComboDefensive) {
            if (!CombatContext.isOpponentCooldownReady()) {
                CombatContext.setShouldEngage(true, "");
                return;
            }
            CombatContext.setShouldEngage(false, "opp-combo-streak");
            return;
        }
        CombatContext.setShouldEngage(true, "");
    }

    private static void evaluateAggressive(EntityLivingBase target) {
        if (skipAirborne && CombatContext.isOpponentAirborne()) {
            boolean descendingTowardUs = target.motionY < 0 && TargetPrediction.getApproachVelocity(target) > 0;
            if (!descendingTowardUs && TargetPrediction.getApproachVelocity(target) < -0.1) {
                CombatContext.setShouldEngage(false, "airborne-retreating");
                return;
            }
        }
        CombatContext.setShouldEngage(true, "");
    }

    private static void evaluateDefensive(EntityLivingBase target) {
        double approach = TargetPrediction.getApproachVelocity(target);
        if (approach < -0.12) {
            CombatContext.setShouldEngage(false, "retreating");
            return;
        }
        if (CombatContext.isOpponentAirborne() && target.motionY > 0) {
            CombatContext.setShouldEngage(false, "airborne");
            return;
        }
        if (skipHurtTarget && CombatContext.isOpponentHurt()) {
            CombatContext.setShouldEngage(false, "target-hurt");
            return;
        }
        if (isAtFrameDisadvantage()) {
            CombatContext.setShouldEngage(false, "frame-disadvantage");
            return;
        }
        if (!willStayInRangeAfterHit(target)) {
            CombatContext.setShouldEngage(false, "kb-out-of-range");
            return;
        }
        CombatContext.setShouldEngage(true, "");
    }

    private static void evaluateStrategic(EntityLivingBase target) {
        float myHealth = client.utils.player.PlayerUtils.getTotalHealth();
        float oppHealth = OpponentHealthTracker.getEstimatedHealth(target) + (target instanceof EntityPlayer ? ((EntityPlayer) target).getAbsorptionAmount() : 0);
        if (myHealth - oppHealth >= pressAdvantageGap) {
            CombatContext.setShouldEngage(true, "press-advantage");
            return;
        }
        if (myHealth <= disengageHealthThreshold) {
            CombatContext.setShouldEngage(false, "low-hp");
            return;
        }
        if (oppHealth - myHealth >= disengageHealthGap) {
            CombatContext.setShouldEngage(false, "hp-disadvantage");
            return;
        }
        if (CombatContext.getOpponentComboCount() >= opponentComboDisengage) {
            CombatContext.setShouldEngage(false, "losing-combo");
            return;
        }
        if (checkOpponentWeapon && target instanceof EntityPlayer) {
            EntityPlayer oppPlayer = (EntityPlayer) target;
            int myWeaponScore = scoreWeapon(mc.player.getHeldItemMainhand());
            int oppWeaponScore = scoreWeapon(oppPlayer.getHeldItemMainhand());
            if (oppWeaponScore - myWeaponScore >= 3) {
                CombatContext.setShouldEngage(false, "weapon-disadvantage");
                return;
            }
        }
    }

    private static boolean isAtFrameDisadvantage() {
        EntityLivingBase target = CombatContext.getTarget();
        if (target == null || mc.player == null)
            return false;
        long ticksSinceOppSwing = CombatContext.getTicksSinceOpponentSwing();
        if (ticksSinceOppSwing > 20)
            return false;
        long tradeWindow = CombatContext.getTradeWindowTicks();
        if (tradeWindow > 0) {
            return false;
        }
        long myPeriod = Math.round(CombatContext.getMyAttackPeriod());
        long theirNextSwingIn = Math.max(0, -tradeWindow);
        long ticksToEvaluate = Math.min(theirNextSwingIn, myPeriod);
        if (ticksToEvaluate < 1)
            ticksToEvaluate = 1;
        boolean sprintHit = mc.player.isSprinting();
        double separation = TargetPrediction.predictSeparationAfterKnockback(target, sprintHit, (int) ticksToEvaluate);
        return separation <= THEIR_REACH;
    }

    private static final double THEIR_REACH = 3.0;

    private static boolean willStayInRangeAfterHit(EntityLivingBase target) {
        if (mc.player == null || target == null)
            return true;
        boolean sprintHit = mc.player.isSprinting();
        double reach = CombatUtils.getReachDistance(target);
        return TargetPrediction.willBeInReachAfterKnockback(target, sprintHit, 0, reach + 0.6);
    }

    private static int scoreWeapon(ItemStack stack) {
        if (stack == null || stack.func_190926_b())
            return 0;
        int score = 0;
        if (stack.getItem() instanceof ItemSword) {
            score += 5;
            int sharp = EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, stack);
            score += sharp;
            int fire = EnchantmentHelper.getEnchantmentLevel(Enchantments.FIRE_ASPECT, stack);
            score += fire;
        } else if (stack.getItem() instanceof ItemTool) {
            score += 2;
        }
        return score;
    }
}
