package client.utils.combat;

import client.utils.EntityUtils;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.Vec3d;

public final class OpponentTracker {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static double range = 6.0;

    private static double fov = 360.0;

    private static boolean targetPlayers = true;

    private static boolean targetHostile = true;

    private static boolean targetPassive = false;

    private static boolean targetInvisible = true;

    private static boolean hitThroughWalls = false;

    private static String priority = "Distance";

    private static boolean prevOpponentSwinging = false;

    private OpponentTracker() {
    }

    public static void configure(double range_, double fov_, boolean targetPlayers_, boolean targetHostile_, boolean targetPassive_, boolean targetInvisible_, boolean hitThroughWalls_, String priority_) {
        range = range_;
        fov = fov_;
        targetPlayers = targetPlayers_;
        targetHostile = targetHostile_;
        targetPassive = targetPassive_;
        targetInvisible = targetInvisible_;
        hitThroughWalls = hitThroughWalls_;
        priority = priority_;
    }

    public static void update() {
        if (mc.player == null || mc.world == null) {
            CombatContext.clearTarget();
            return;
        }
        CombatContext.beginTick();
        List<EntityLivingBase> targets = getValidTargets();
        if (targets.isEmpty()) {
            CombatContext.clearTarget();
            return;
        }
        EntityLivingBase target = sortByPriority(targets);
        if (target == null || !EntityUtils.isAlive(target)) {
            CombatContext.clearTarget();
            return;
        }
        Vec3d pos = new Vec3d(target.posX, target.posY, target.posZ);
        Vec3d prevPos = new Vec3d(target.prevPosX, target.prevPosY, target.prevPosZ);
        Vec3d velocity = TargetPrediction.getObservedVelocity(target);
        Vec3d prevVelocity = TargetPrediction.getPreviousObservedVelocity(target);
        boolean onGround = target.onGround;
        boolean sprinting = target.isSprinting();
        boolean airborne = !onGround && !target.isInWater() && !target.isInLava();
        int hurtTime = target.hurtTime;
        int maxHurtTime = target.maxHurtTime;
        float health = target.getHealth();
        float maxHealth = target.getMaxHealth();
        boolean nowSwinging = target.isSwingInProgress;
        if (nowSwinging && !prevOpponentSwinging) {
            CombatContext.setOpponentLastSwingTick(CombatContext.getCurrentTick());
        }
        prevOpponentSwinging = nowSwinging;
        CombatContext.setTarget(target);
        CombatContext.setOpponentState(pos, prevPos, velocity, prevVelocity, onGround, sprinting, airborne, hurtTime, maxHurtTime, health, maxHealth);
        boolean myCooldownReady = CombatUtils.isWeaponFullyCharged();
        boolean myOnGround = mc.player.onGround;
        boolean mySprinting = mc.player.isSprinting();
        CombatContext.setMyState(myCooldownReady, myOnGround, mySprinting);
        CombatTracker.update();
        OpponentHealthTracker.update();
        CombatDecisionMaker.evaluate();
        AttackControlClaim.resetTick();
    }

    private static List<EntityLivingBase> getValidTargets() {
        TargetSelector.Criteria c = new TargetSelector.Criteria();
        c.targetPlayers = targetPlayers;
        c.targetHostile = targetHostile;
        c.targetPassive = targetPassive;
        c.targetInvisible = targetInvisible;
        c.hitThroughWalls = hitThroughWalls;
        c.range = range;
        c.fov = fov;
        c.aimLeadTicks = -1.0;
        return TargetSelector.getValidTargets(c);
    }

    private static EntityLivingBase sortByPriority(List<EntityLivingBase> targets) {
        if (targets.isEmpty())
            return null;
        TargetSelector.sortByPriority(targets, priority, -1.0);
        return targets.get(0);
    }

    public static void reset() {
        prevOpponentSwinging = false;
        CombatContext.reset();
        OpponentHealthTracker.reset();
        AttackControlClaim.reset();
    }

    public static void onWorldChange() {
        prevOpponentSwinging = false;
        CombatContext.reset();
        OpponentHealthTracker.onWorldChange();
        AttackControlClaim.reset();
    }
}
