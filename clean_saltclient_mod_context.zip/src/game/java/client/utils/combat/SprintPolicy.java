package client.utils.combat;

import client.module.Module;
import client.module.ModuleManager;
import client.module.impl.combat.SprintReset;
import net.minecraft.client.Minecraft;

public final class SprintPolicy {

    private SprintPolicy() {
    }

    public static boolean isSprintOwned() {
        return isSprintResetStopping() || isCritTimingDesprintGap();
    }

    public static boolean shouldMaintainSprint() {
        if (isSprintOwned())
            return false;
        return client.utils.movement.MovementUtils.canSprint();
    }

    public static void reSprintAfterAttack() {
        if (isSprintResetStopping())
            return;
        client.utils.movement.MovementUtils.reSprint();
    }

    private static boolean isSprintResetStopping() {
        try {
            SprintReset sr = (SprintReset) ModuleManager.getModuleByName("SprintReset");
            if (sr == null || !sr.isToggled())
                return false;
            return sr.isInStopPhase();
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean isCritTimingDesprintGap() {
        try {
            Module ct = ModuleManager.getModuleByName("CritTiming");
            if (ct == null || !ct.isToggled())
                return false;
            return ((client.module.impl.combat.CritTiming) ct).isSprintDropped();
        } catch (Throwable t) {
            return false;
        }
    }
}
