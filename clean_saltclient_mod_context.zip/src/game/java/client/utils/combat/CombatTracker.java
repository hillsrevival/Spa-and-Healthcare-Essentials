package client.utils.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public final class CombatTracker {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static long comboBreakTicks = 30;

    private static boolean resetOnTargetSwitch = false;

    private static long ticksSinceLastHit = 0;

    private static boolean prevHurtTime = false;

    private static Entity lastHitTarget = null;

    private CombatTracker() {
    }

    public static void configure(long comboBreakTicks_, boolean resetOnTargetSwitch_) {
        comboBreakTicks = comboBreakTicks_;
        resetOnTargetSwitch = resetOnTargetSwitch_;
    }

    public static void update() {
        if (mc.player == null)
            return;
        ticksSinceLastHit++;
        boolean nowHurt = mc.player.hurtTime > 0;
        if (nowHurt && !prevHurtTime) {
            EntityLivingBase target = CombatContext.getTarget();
            boolean inCombat = target != null && target.isEntityAlive() && mc.player.getDistanceToEntity(target) < 6.0;
            if (inCombat) {
                CombatContext.onOpponentHitPlayer();
                ticksSinceLastHit = 0;
            }
        }
        prevHurtTime = nowHurt;
        if (ticksSinceLastHit > comboBreakTicks) {
            if (CombatContext.getPlayerComboCount() > 0 || CombatContext.getOpponentComboCount() > 0) {
                CombatContext.resetCombo();
            }
        }
        EntityLivingBase currentTarget = CombatContext.getTarget();
        if (currentTarget == null || !currentTarget.isEntityAlive()) {
            if (CombatContext.getPlayerComboCount() > 0 && ticksSinceLastHit > comboBreakTicks) {
                CombatContext.resetCombo();
            }
        }
    }

    public static void onPlayerAttack(Entity target) {
        if (target == null)
            return;
        if (resetOnTargetSwitch && lastHitTarget != null && lastHitTarget != target) {
            CombatContext.resetCombo();
        }
        lastHitTarget = target;
        CombatContext.onPlayerHitOpponent();
        ticksSinceLastHit = 0;
    }

    public static void reset() {
        ticksSinceLastHit = 0;
        prevHurtTime = false;
        lastHitTarget = null;
        CombatContext.resetCombo();
    }
}
