package client.utils.combat;

import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.Minecraft;

public class EntityFakePlayer extends EntityOtherPlayerMP {

    public EntityFakePlayer() {
        super(Minecraft.getMinecraft().world, Minecraft.getMinecraft().player.getGameProfile());
        copyLocationAndAnglesFrom(Minecraft.getMinecraft().player);
        inventory.copyInventory(Minecraft.getMinecraft().player.inventory);
        rotationYawHead = Minecraft.getMinecraft().player.rotationYawHead;
        renderYawOffset = Minecraft.getMinecraft().player.renderYawOffset;
        chasingPosX = posX;
        chasingPosY = posY;
        chasingPosZ = posZ;
        Minecraft.getMinecraft().world.addEntityToWorld(getEntityId(), this);
    }

    public static EntityFakePlayer createSafe() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null || mc.player == null)
            return null;
        return new EntityFakePlayer();
    }

    public void resetPlayerPosition() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null)
            return;
        mc.player.setPositionAndRotation(posX, posY, posZ, rotationYaw, rotationPitch);
    }

    public void despawn() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null)
            return;
        mc.world.removeEntityFromWorld(getEntityId());
    }
}
