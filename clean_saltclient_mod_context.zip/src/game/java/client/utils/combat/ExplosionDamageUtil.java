package client.utils.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.init.MobEffects;
import net.minecraft.util.CombatRules;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Explosion;

public final class ExplosionDamageUtil {

    private ExplosionDamageUtil() {
    }

    public static final float CRYSTAL_SIZE = 6.0F;

    public static final float BED_SIZE = 5.0F;

    public static float predictDamage(EntityLivingBase entity, double explosionX, double explosionY, double explosionZ, float size) {
        Minecraft mc = Minecraft.getMinecraft();
        if (entity == null || mc.world == null)
            return 0.0F;
        float radius = size * 2.0F;
        double d12 = entity.getDistance(explosionX, explosionY, explosionZ) / (double) radius;
        if (d12 > 1.0D)
            return 0.0F;
        double density = mc.world.getBlockDensity(new Vec3d(explosionX, explosionY, explosionZ), entity.getEntityBoundingBox());
        double d10 = (1.0D - d12) * density;
        int rawDamage = (int) ((d10 * d10 + d10) / 2.0D * 7.0D * (double) radius + 1.0D);
        if (rawDamage <= 0)
            return 0.0F;
        float damage = CombatRules.getDamageAfterAbsorb((float) rawDamage, (float) entity.getTotalArmorValue(), (float) entity.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
        if (entity.isPotionActive(MobEffects.RESISTANCE)) {
            int amp = entity.getActivePotionEffect(MobEffects.RESISTANCE).getAmplifier() + 1;
            int j = 25 - amp * 5;
            damage = damage * (float) j / 25.0F;
        }
        if (damage <= 0.0F)
            return 0.0F;
        DamageSource explosion = DamageSource.causeExplosionDamage((Explosion) null);
        int epf = EnchantmentHelper.getEnchantmentModifierDamage(entity.getArmorInventoryList(), explosion);
        if (epf > 0) {
            damage = CombatRules.getDamageAfterMagicAbsorb(damage, (float) epf);
        }
        return Math.max(0.0F, damage);
    }

    public static float predictCrystalDamage(EntityLivingBase entity, double crystalX, double crystalY, double crystalZ) {
        return predictDamage(entity, crystalX, crystalY, crystalZ, CRYSTAL_SIZE);
    }

    public static float predictCrystalDamage(EntityLivingBase entity, BlockPos base) {
        return predictDamage(entity, base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5, CRYSTAL_SIZE);
    }

    public static float predictBedDamage(EntityLivingBase entity, double bedX, double bedY, double bedZ) {
        return predictDamage(entity, bedX, bedY, bedZ, BED_SIZE);
    }

    public static boolean isOccluded(Vec3d from, Vec3d to) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null || from == null || to == null)
            return false;
        net.minecraft.util.math.RayTraceResult hit = mc.world.rayTraceBlocks(from, to);
        return hit != null && hit.typeOfHit == net.minecraft.util.math.RayTraceResult.Type.BLOCK;
    }
}
