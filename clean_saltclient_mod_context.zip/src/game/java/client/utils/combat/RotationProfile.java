package client.utils.combat;

import net.minecraft.client.Minecraft;

public final class RotationProfile {

    private RotationProfile() {
    }

    public enum Profile {

        SNAP, TRACK, LAZY, LEGIT
    }

    public static class Params {

        public final float rotationSpeed;

        public final float jitter;

        public final float variance;

        public final float failswingThreshold;

        public Params(float rotationSpeed, float jitter, float variance, float failswingThreshold) {
            this.rotationSpeed = rotationSpeed;
            this.jitter = jitter;
            this.variance = variance;
            this.failswingThreshold = failswingThreshold;
        }
    }

    public static Params getParams(Profile profile) {
        switch(profile) {
            case SNAP:
                return new Params(60.0f, 0.5f, 0.10f, 15.0f);
            case TRACK:
                return new Params(30.0f, 1.0f, 0.20f, 15.0f);
            case LAZY:
                return new Params(15.0f, 2.0f, 0.30f, 20.0f);
            case LEGIT:
                return new Params(10.0f, 3.0f, 0.40f, 25.0f);
            default:
                return getParams(Profile.TRACK);
        }
    }

    public static Profile fromParams(float speed, float jitter, float variance) {
        Profile closest = Profile.TRACK;
        double closestDist = Double.MAX_VALUE;
        for (Profile p : Profile.values()) {
            Params pp = getParams(p);
            double dist = Math.pow(pp.rotationSpeed - speed, 2) + Math.pow(pp.jitter - jitter, 2) * 100 + Math.pow(pp.variance * 100 - variance, 2);
            if (dist < closestDist) {
                closestDist = dist;
                closest = p;
            }
        }
        return closest;
    }
}
