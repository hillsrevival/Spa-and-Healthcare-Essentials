package client.utils.combat;

import client.utils.movement.RotationUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.Vec3d;

public final class TargetPrediction {

    private static final Minecraft mc = Minecraft.getMinecraft();

    public enum Model {

        LINEAR, QUADRATIC, HYBRID
    }

    private TargetPrediction() {
    }

    public static Vec3d getObservedVelocity(Entity entity) {
        if (entity == null)
            return Vec3d.ZERO;
        return new Vec3d(entity.posX - entity.prevPosX, entity.posY - entity.prevPosY, entity.posZ - entity.prevPosZ);
    }

    public static Vec3d getPreviousObservedVelocity(Entity entity) {
        if (entity == null)
            return Vec3d.ZERO;
        Integer id = entity.getEntityId();
        long tick = entity.ticksExisted;
        double[] st = sampleState.get(id);
        if (st == null) {
            st = new double[10];
            st[0] = tick;
            st[1] = entity.posX;
            st[2] = entity.posY;
            st[3] = entity.posZ;
            sampleState.put(id, st);
            return Vec3d.ZERO;
        }
        long storedTick = (long) st[0];
        if (tick != storedTick) {
            if (tick == storedTick + 1) {
                st[7] = st[4];
                st[8] = st[5];
                st[9] = st[6];
                st[4] = entity.posX - st[1];
                st[5] = entity.posY - st[2];
                st[6] = entity.posZ - st[3];
            }
            st[0] = tick;
            st[1] = entity.posX;
            st[2] = entity.posY;
            st[3] = entity.posZ;
            if (sampleState.size() > 512) {
                sampleState.clear();
            }
        }
        return new Vec3d(st[7], st[8], st[9]);
    }

    private static final java.util.HashMap<Integer, double[]> sampleState = new java.util.HashMap<>();

    public static Vec3d predictPosition(Entity entity, double ticks, Model model) {
        if (entity == null)
            return Vec3d.ZERO;
        Vec3d pos = new Vec3d(entity.posX, entity.posY, entity.posZ);
        Vec3d vel = getObservedVelocity(entity);
        if (ticks <= 0)
            return pos;
        switch(model) {
            case QUADRATIC:
                {
                    Vec3d prevVel = getPreviousObservedVelocity(entity);
                    Vec3d accel = vel.subtract(prevVel);
                    return pos.add(vel.scale(ticks)).add(accel.scale(0.5 * ticks * ticks));
                }
            case HYBRID:
                {
                    if (ticks <= 1.0) {
                        return pos.add(vel.scale(ticks));
                    }
                    Vec3d prevVel = getPreviousObservedVelocity(entity);
                    Vec3d accel = vel.subtract(prevVel);
                    return pos.add(vel.scale(ticks)).add(accel.scale(0.5 * ticks * ticks));
                }
            case LINEAR:
            default:
                return pos.add(vel.scale(ticks));
        }
    }

    public static Vec3d predictNextTick(Entity entity) {
        return predictPosition(entity, 1.0, Model.LINEAR);
    }

    public static Vec3d predict(Entity entity, double ticks) {
        return predictPosition(entity, ticks, Model.LINEAR);
    }

    public static Vec3d getPredictedAimPoint(EntityLivingBase entity, RotationUtils.AimPoint mode, double ticks) {
        if (entity == null)
            return Vec3d.ZERO;
        if (ticks <= 0)
            return RotationUtils.getAimPoint(entity, mode);
        Vec3d baseAim = RotationUtils.getAimPoint(entity, mode);
        Vec3d predictedDelta = new Vec3d(entity.motionX * ticks, entity.motionY * ticks, entity.motionZ * ticks);
        return baseAim.add(predictedDelta);
    }

    public static double getApproachVelocity(EntityLivingBase opponent) {
        if (opponent == null || mc.player == null)
            return 0;
        Vec3d toPlayer = new Vec3d(mc.player.posX - opponent.posX, 0, mc.player.posZ - opponent.posZ);
        if (toPlayer.lengthVector() < 0.001)
            return 0;
        toPlayer = toPlayer.normalize();
        Vec3d oppVel = getObservedVelocity(opponent);
        Vec3d myVel = new Vec3d(mc.player.posX - mc.player.prevPosX, 0, mc.player.posZ - mc.player.prevPosZ);
        Vec3d rel = new Vec3d(oppVel.xCoord - myVel.xCoord, 0, oppVel.zCoord - myVel.zCoord);
        return rel.dotProduct(toPlayer);
    }

    private static final double GROUND_FRICTION = 0.546;

    private static final double AIR_FRICTION = 0.91;

    private static final int KB_AIR_TICKS = 10;

    public static Vec3d predictPostKnockbackVelocity(EntityLivingBase victim, boolean attackerSprinting, int kbEnchantLevel) {
        if (victim == null || mc.player == null) {
            return new Vec3d(victim == null ? 0 : victim.motionX, victim == null ? 0 : victim.motionY, victim == null ? 0 : victim.motionZ);
        }
        double dX = mc.player.posX - victim.posX;
        double dZ = mc.player.posZ - victim.posZ;
        double len = Math.sqrt(dX * dX + dZ * dZ);
        if (len < 1.0E-4) {
            dX = 1.0;
            dZ = 0.0;
            len = 1.0;
        }
        double vx = victim.motionX / 2.0 - (dX / len) * 0.4;
        double vz = victim.motionZ / 2.0 - (dZ / len) * 0.4;
        double vy = victim.onGround ? Math.min(victim.motionY / 2.0 + 0.4, 0.4) : victim.motionY;
        int kbStrength = kbEnchantLevel + (attackerSprinting ? 1 : 0);
        if (kbStrength > 0) {
            double strength = 0.5 * kbStrength;
            double radYaw = Math.toRadians(mc.player.rotationYaw);
            double lookX = -Math.sin(radYaw);
            double lookZ = Math.cos(radYaw);
            vx = vx / 2.0 + lookX * strength;
            vz = vz / 2.0 + lookZ * strength;
        }
        return new Vec3d(vx, vy, vz);
    }

    public static Vec3d predictPostKnockbackPosition(EntityLivingBase victim, boolean attackerSprinting, int kbEnchantLevel) {
        if (victim == null)
            return Vec3d.ZERO;
        Vec3d postKB = predictPostKnockbackVelocity(victim, attackerSprinting, kbEnchantLevel);
        return new Vec3d(victim.posX + postKB.xCoord, victim.posY + postKB.yCoord, victim.posZ + postKB.zCoord);
    }

    @Deprecated
    public static Vec3d predictPostKnockbackPosition(EntityLivingBase opponent, float attackYaw, int kbLevel) {
        return predictPostKnockbackPosition(opponent, false, kbLevel);
    }

    public static double predictKnockbackDisplacement(EntityLivingBase victim, boolean sprintHit, int ticksAfterHit) {
        if (victim == null || ticksAfterHit <= 0)
            return 0.0;
        Vec3d v = predictPostKnockbackVelocity(victim, sprintHit, 0);
        return accumulateDisplacement(v.xCoord, v.zCoord, v.yCoord, ticksAfterHit);
    }

    public static double predictSeparationAfterKnockback(EntityLivingBase victim, boolean sprintHit, int ticksAfterHit) {
        if (victim == null || mc.player == null)
            return Double.MAX_VALUE;
        Vec3d v = predictPostKnockbackVelocity(victim, sprintHit, 0);
        double dx = accumulateAxis(v.xCoord, v.yCoord, ticksAfterHit) - (mc.player.posX - victim.posX);
        double dz = accumulateAxis(v.zCoord, v.yCoord, ticksAfterHit) - (mc.player.posZ - victim.posZ);
        double len = Math.sqrt(dx * dx + dz * dz);
        double chase = predictChaseDisplacement(ticksAfterHit);
        if (len > 1.0E-4 && chase > 0.0) {
            double scale = Math.max(0.0, (len - chase) / len);
            dx *= scale;
            dz *= scale;
        }
        return Math.sqrt(dx * dx + dz * dz);
    }

    private static double predictChaseDisplacement(int ticks) {
        if (ticks <= 0 || mc.player == null)
            return 0.0;
        double speed = Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ) * 0.6;
        boolean grounded = mc.player.onGround;
        double accel = Math.max(0.02, mc.player.getAIMoveSpeed());
        double friction = grounded ? GROUND_FRICTION : AIR_FRICTION;
        double terminal = accel / (1.0 - friction);
        double displacement = 0.0;
        for (int t = 0; t < ticks; t++) {
            speed += accel;
            if (speed > terminal) {
                speed = terminal;
            }
            displacement += speed;
            speed *= friction;
        }
        return displacement;
    }

    private static double accumulateDisplacement(double vx, double vz, double vy, int ticks) {
        double sx = accumulateAxis(vx, vy, ticks);
        double sz = accumulateAxis(vz, vy, ticks);
        return Math.sqrt(sx * sx + sz * sz);
    }

    private static double accumulateAxis(double v, double vy, int ticks) {
        boolean airborne = vy > 0.1;
        double delta = 0.0;
        for (int t = 0; t < ticks; t++) {
            delta += v;
            v *= (airborne && t < KB_AIR_TICKS) ? AIR_FRICTION : GROUND_FRICTION;
        }
        return delta;
    }

    public static boolean willBeInReachAfterKnockback(EntityLivingBase opponent, boolean attackerSprinting, int kbEnchantLevel, double reach) {
        if (opponent == null || mc.player == null)
            return false;
        Vec3d postKB = predictPostKnockbackPosition(opponent, attackerSprinting, kbEnchantLevel);
        double dist = postKB.distanceTo(new Vec3d(mc.player.posX, mc.player.posY, mc.player.posZ));
        return dist <= reach;
    }

    @Deprecated
    public static boolean willBeInReachAfterKnockback(EntityLivingBase opponent, float attackYaw, int kbLevel, double reach) {
        return willBeInReachAfterKnockback(opponent, false, kbLevel, reach);
    }
}
