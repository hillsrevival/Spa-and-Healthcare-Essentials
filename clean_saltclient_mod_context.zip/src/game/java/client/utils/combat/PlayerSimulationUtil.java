package client.utils.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import java.util.List;

public final class PlayerSimulationUtil {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final double GRAVITY = 0.08;

    private static final double AIR_FRICTION = 0.91;

    private static final double AIR_DRAG = 0.98;

    private PlayerSimulationUtil() {
    }

    public static Vec3d simulatePosition(EntityLivingBase entity, int ticks) {
        return simulatePosition(entity, ticks, null);
    }

    public static Vec3d simulatePosition(EntityLivingBase entity, int ticks, Vec3d velocity) {
        if (entity == null || mc.world == null)
            return Vec3d.ZERO;
        if (ticks <= 0)
            return new Vec3d(entity.posX, entity.posY, entity.posZ);
        double x = entity.posX;
        double y = entity.posY;
        double z = entity.posZ;
        Vec3d seed = velocity != null ? velocity : TargetPrediction.getObservedVelocity(entity);
        double vx = seed.xCoord;
        double vy = seed.yCoord;
        double vz = seed.zCoord;
        boolean onGround = entity.onGround;
        double width = entity.width;
        double height = entity.height;
        for (int i = 0; i < ticks; i++) {
            double newX = x + vx;
            if (!canMoveTo(newX - width / 2, y, z - width / 2, newX + width / 2, y + height, z + width / 2)) {
                vx = 0;
                newX = x;
            }
            double newZ = z + vz;
            if (!canMoveTo(newX - width / 2, y, newZ - width / 2, newX + width / 2, y + height, newZ + width / 2)) {
                vz = 0;
                newZ = z;
            }
            double newY = y + vy;
            if (vy < 0) {
                if (!canMoveTo(newX - width / 2, newY, newZ - width / 2, newX + width / 2, newY + height, newZ + width / 2)) {
                    vy = 0;
                    newY = y;
                    onGround = true;
                } else {
                    onGround = false;
                }
            } else if (vy > 0) {
                if (!canMoveTo(newX - width / 2, newY, newZ - width / 2, newX + width / 2, newY + height, newZ + width / 2)) {
                    vy = 0;
                    newY = y;
                }
                onGround = false;
            }
            x = newX;
            y = newY;
            z = newZ;
            if (!onGround) {
                vy = (vy - GRAVITY) * AIR_DRAG;
                vx *= AIR_FRICTION;
                vz *= AIR_FRICTION;
            }
        }
        return new Vec3d(x, y, z);
    }

    public static Vec3d predictWithFractionalTicks(EntityLivingBase entity, double ticks) {
        if (entity == null)
            return Vec3d.ZERO;
        if (ticks <= 0)
            return new Vec3d(entity.posX, entity.posY, entity.posZ);
        int whole = (int) Math.floor(ticks);
        double frac = ticks - whole;
        Vec3d base = whole == 0 ? new Vec3d(entity.posX, entity.posY, entity.posZ) : simulatePosition(entity, whole);
        if (frac <= 0)
            return base;
        Vec3d vel = TargetPrediction.getObservedVelocity(entity);
        return new Vec3d(base.xCoord + vel.xCoord * frac, base.yCoord + vel.yCoord * frac, base.zCoord + vel.zCoord * frac);
    }

    private static boolean canMoveTo(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
        if (mc.world == null)
            return true;
        AxisAlignedBB box = new AxisAlignedBB(minX, minY, minZ, maxX, maxY, maxZ);
        List<AxisAlignedBB> collisionBoxes = mc.world.getCollisionBoxes(null, box);
        return collisionBoxes.isEmpty();
    }

    public static Vec3d predictNextTick(EntityLivingBase entity) {
        return simulatePosition(entity, 1);
    }

    public static Vec3d predictWithFallback(EntityLivingBase entity, int ticks) {
        try {
            Vec3d simulated = simulatePosition(entity, ticks);
            if (simulated.xCoord != 0 || simulated.yCoord != 0 || simulated.zCoord != 0) {
                return simulated;
            }
        } catch (Exception e) {
        }
        return TargetPrediction.predict(entity, ticks);
    }
}
