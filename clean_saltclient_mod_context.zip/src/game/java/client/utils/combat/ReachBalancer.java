package client.utils.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;

public final class ReachBalancer {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static double baseReach = 3.0;

    private static double maxReach = 3.03;

    private static double minReach = 2.6;

    private static double approachBonus = 0.03;

    private static double retreatPenalty = 0.08;

    private static int kbImmunityTicks = 3;

    private ReachBalancer() {
    }

    public static void configure(double base, double max, double min, double approachBonus_, double retreatPenalty_) {
        baseReach = base;
        maxReach = max;
        minReach = min;
        approachBonus = approachBonus_;
        retreatPenalty = retreatPenalty_;
    }

    public static double getEffectiveReach(EntityLivingBase target) {
        if (target == null)
            return baseReach;
        if (mc.player == null)
            return baseReach;
        double reach = baseReach;
        if (target.hurtTime > 0 && target.hurtTime >= target.maxHurtTime - kbImmunityTicks)
            return clamp(reach);
        double approach = TargetPrediction.getApproachVelocity(target);
        if (approach > 0.05) {
            double bonus = Math.min(approach * 0.5, approachBonus);
            reach = baseReach + bonus;
        } else if (approach < -0.05) {
            double penalty = Math.min(Math.abs(approach) * 1.5, retreatPenalty);
            reach = baseReach - penalty;
        }
        return clamp(reach);
    }

    private static double clamp(double reach) {
        double low = Math.min(minReach, maxReach);
        double high = Math.max(minReach, maxReach);
        return Math.max(low, Math.min(high, reach));
    }

    public static double getBaseReach() {
        return baseReach;
    }
}
