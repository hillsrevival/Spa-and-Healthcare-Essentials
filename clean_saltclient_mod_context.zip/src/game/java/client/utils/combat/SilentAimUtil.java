package client.utils.combat;

import client.utils.movement.RotationUtils;
import client.Client;
import net.lax1dude.eaglercraft.Keyboard;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.math.Vec3d;
import java.util.Random;

public class SilentAimUtil {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final Random random = new Random();

    private static boolean active = false;

    private static String currentOwner = null;

    private static Mode mode = null;

    private static float savedClientYaw;

    private static float savedClientPitch;

    private static float simpleServerYaw;

    private static float simpleServerPitch;

    private static boolean simpleSetThisTick = false;

    private static float realYaw;

    private static float realPitch;

    private static float serverYaw;

    private static float serverPitch;

    private static float lastServerYaw;

    private static float lastServerPitch;

    private static boolean hasLastServer = false;

    private static double yawDriftX = 0.0;

    private static double yawDriftZ = 0.0;

    private static boolean firstTickOfStreak = false;

    private static float jitterYawPhase = 0.0f;

    private static float jitterPitchPhase = 0.0f;

    private static float jitterYawAmplitude = 0.0f;

    private static float jitterPitchAmplitude = 0.0f;

    private static float jitterYawSpeed = 0.0f;

    private static float jitterPitchSpeed = 0.0f;

    private static long lastJitterUpdate = 0L;

    private static float pendingYawDelta = 0.0f;

    private static float pendingPitchDelta = 0.0f;

    private static float idLastServerYaw = 0.0f;

    private static float idLastServerPitch = 0.0f;

    private static boolean idInitialized = false;

    private static float contPendYaw = 0.0f;

    private static float contPendPitch = 0.0f;

    private static float piYawIntegral = 0.0f;

    private static float piPitchIntegral = 0.0f;

    private static float piYawPropScale = 1.0f;

    private static float piPitchPropScale = 1.0f;

    private static float piYawIntScale = 1.0f;

    private static float piPitchIntScale = 1.0f;

    private static boolean piOnTarget = false;

    private static boolean savedFwdKey = false;

    private static boolean savedLeftKey = false;

    private static boolean savedRightKey = false;

    private static boolean savedBackKey = false;

    private static boolean movementKeysRemapped = false;

    private SilentAimUtil() {
    }

    public enum Mode {

        SIMPLE, CONTINUOUS
    }

    public static boolean onEnable() {
        return onEnable(null);
    }

    public static boolean onEnable(String ownerName) {
        if (active) {
            return ownerName != null && ownerName.equals(currentOwner);
        }
        active = true;
        currentOwner = ownerName;
        mode = null;
        hasLastServer = false;
        firstTickOfStreak = false;
        yawDriftX = 0.0;
        yawDriftZ = 0.0;
        return true;
    }

    public static boolean forceTake(String ownerName) {
        if (ownerName == null)
            return false;
        if (active) {
            if (ownerName.equals(currentOwner))
                return true;
            if (rotationCriticalOwners.contains(currentOwner)) {
                return false;
            }
            currentOwner = ownerName;
            return true;
        }
        return onEnable(ownerName);
    }

    private static final java.util.Set<String> rotationCriticalOwners = new java.util.HashSet<>();

    public static void setRotationCritical(String ownerName, boolean critical) {
        if (ownerName == null)
            return;
        if (critical) {
            rotationCriticalOwners.add(ownerName);
        } else {
            rotationCriticalOwners.remove(ownerName);
        }
    }

    public static boolean isRotationCritical(String ownerName) {
        return ownerName != null && rotationCriticalOwners.contains(ownerName);
    }

    public static String getCurrentOwner() {
        return active ? currentOwner : null;
    }

    public static void onDisable() {
        onDisable(null);
    }

    public static void onDisable(String ownerName) {
        if (active && currentOwner != null && ownerName != null && !currentOwner.equals(ownerName)) {
            return;
        }
        resetJitterState();
        resetIntegerDelta();
        resetPIController();
        restoreMovementKeys();
        if (active) {
            if (mode == Mode.CONTINUOUS) {
                restoreEntityRotation();
                Client.INSTANCE.renderRotationOverride = false;
            } else if (mode == Mode.SIMPLE) {
                if (mc.player != null) {
                    mc.player.rotationYaw = savedClientYaw;
                    mc.player.rotationPitch = savedClientPitch;
                }
            }
        }
        active = false;
        currentOwner = null;
        mode = null;
        hasLastServer = false;
        firstTickOfStreak = false;
        simpleSetThisTick = false;
        Client.INSTANCE.renderRotationOverride = false;
    }

    public static boolean isOwnedBy(String ownerName) {
        return active && ownerName != null && ownerName.equals(currentOwner);
    }

    public static boolean isActive() {
        return active;
    }

    public static boolean faceTarget(Vec3d target) {
        if (!active || mc.player == null)
            return false;
        mode = Mode.SIMPLE;
        savedClientYaw = mc.player.rotationYaw;
        savedClientPitch = mc.player.rotationPitch;
        realYaw = savedClientYaw;
        realPitch = savedClientPitch;
        float[] needed = RotationUtils.getNeededRotations(target);
        mc.player.rotationYaw = needed[0];
        mc.player.rotationPitch = needed[1];
        simpleServerYaw = needed[0];
        simpleServerPitch = needed[1];
        simpleSetThisTick = true;
        Client.INSTANCE.renderYaw = savedClientYaw;
        Client.INSTANCE.renderPitch = savedClientPitch;
        Client.INSTANCE.scaffoldYaw = needed[0];
        Client.INSTANCE.scaffoldPitch = needed[1];
        Client.INSTANCE.renderRotationOverride = true;
        return RotationUtils.getAngleDifference(needed[0], needed[1], savedClientYaw, savedClientPitch) < 1.0f;
    }

    public static boolean faceTargetGCD(Vec3d target, float prevYaw, float prevPitch) {
        if (!active || mc.player == null)
            return false;
        mode = Mode.SIMPLE;
        savedClientYaw = mc.player.rotationYaw;
        savedClientPitch = mc.player.rotationPitch;
        realYaw = savedClientYaw;
        realPitch = savedClientPitch;
        float[] needed = RotationUtils.getNeededRotations(target);
        float[] gcdFixed = RotationUtils.fixRotations(prevYaw, prevPitch, needed[0], needed[1]);
        mc.player.rotationYaw = gcdFixed[0];
        mc.player.rotationPitch = gcdFixed[1];
        simpleServerYaw = gcdFixed[0];
        simpleServerPitch = gcdFixed[1];
        simpleSetThisTick = true;
        Client.INSTANCE.renderYaw = savedClientYaw;
        Client.INSTANCE.renderPitch = savedClientPitch;
        Client.INSTANCE.scaffoldYaw = gcdFixed[0];
        Client.INSTANCE.scaffoldPitch = gcdFixed[1];
        Client.INSTANCE.renderRotationOverride = true;
        return RotationUtils.getAngleDifference(gcdFixed[0], gcdFixed[1], savedClientYaw, savedClientPitch) < 1.0f;
    }

    public static void setupSilentRotation(float yaw, float pitch) {
        if (!active || mc.player == null)
            return;
        mode = Mode.SIMPLE;
        savedClientYaw = mc.player.rotationYaw;
        savedClientPitch = mc.player.rotationPitch;
        realYaw = savedClientYaw;
        realPitch = savedClientPitch;
        mc.player.rotationYaw = yaw;
        mc.player.rotationPitch = pitch;
        simpleServerYaw = yaw;
        simpleServerPitch = pitch;
        simpleSetThisTick = true;
        Client.INSTANCE.renderYaw = savedClientYaw;
        Client.INSTANCE.renderPitch = savedClientPitch;
        Client.INSTANCE.scaffoldYaw = yaw;
        Client.INSTANCE.scaffoldPitch = pitch;
        Client.INSTANCE.renderRotationOverride = true;
    }

    public static void restore() {
        if (!active || mode != Mode.SIMPLE || mc.player == null)
            return;
        if (simpleSetThisTick) {
            float mouseDeltaYaw = RotationUtils.wrapDegrees(mc.player.rotationYaw - simpleServerYaw);
            float mouseDeltaPitch = mc.player.rotationPitch - simpleServerPitch;
            float restoredYaw = RotationUtils.wrapDegrees(savedClientYaw + mouseDeltaYaw);
            float restoredPitch = RotationUtils.clamp(savedClientPitch + mouseDeltaPitch, -90, 90);
            mc.player.rotationYaw = restoredYaw;
            mc.player.rotationPitch = restoredPitch;
            mc.player.prevRotationYaw = restoredYaw;
            mc.player.prevRotationPitch = restoredPitch;
        } else {
        }
        Client.INSTANCE.renderRotationOverride = false;
        simpleSetThisTick = false;
    }

    public static void startStreak() {
        if (!active || mc.player == null)
            return;
        mode = Mode.CONTINUOUS;
        realYaw = mc.player.rotationYaw;
        realPitch = mc.player.rotationPitch;
        lastServerYaw = realYaw;
        lastServerPitch = realPitch;
        hasLastServer = false;
        firstTickOfStreak = true;
    }

    public static boolean tick(Vec3d target, float minSpeed, float maxSpeed, boolean useGCD, boolean jitter) {
        return tick(target, null, minSpeed, maxSpeed, useGCD, jitter);
    }

    public static boolean tick(Vec3d target, Vec3d eyesPos, float minSpeed, float maxSpeed, boolean useGCD, boolean jitter) {
        if (!active || mc.player == null || target == null)
            return false;
        if (mode != Mode.CONTINUOUS) {
            mode = Mode.CONTINUOUS;
            realYaw = mc.player.rotationYaw;
            realPitch = mc.player.rotationPitch;
            lastServerYaw = realYaw;
            lastServerPitch = realPitch;
            hasLastServer = false;
            firstTickOfStreak = true;
        }
        if (hasLastServer) {
            float mouseDeltaYaw = RotationUtils.wrapDegrees(mc.player.rotationYaw - lastServerYaw);
            float mouseDeltaPitch = mc.player.rotationPitch - lastServerPitch;
            realYaw = RotationUtils.wrapDegrees(realYaw + mouseDeltaYaw);
            realPitch = RotationUtils.clamp(realPitch + mouseDeltaPitch, -90, 90);
        } else if (!firstTickOfStreak) {
            realYaw = mc.player.rotationYaw;
            realPitch = mc.player.rotationPitch;
        }
        Vec3d eyes = eyesPos != null ? eyesPos : RotationUtils.getEyesPos();
        float[] needed = RotationUtils.getNeededRotations(target, eyes);
        float startYaw, startPitch;
        if (hasLastServer) {
            startYaw = lastServerYaw;
            startPitch = lastServerPitch;
        } else {
            startYaw = realYaw;
            startPitch = realPitch;
        }
        float speed = minSpeed + random.nextFloat() * (maxSpeed - minSpeed);
        float[] smoothed = smoothRotate(startYaw, startPitch, needed[0], needed[1], speed);
        if (jitter) {
            updateJitterState();
            yawDriftX = (float) (Math.sin(jitterYawPhase * 0.7) * 0.12);
            yawDriftZ = (float) (Math.cos(jitterYawPhase * 0.5) * 0.12);
            Vec3d driftedTarget = new Vec3d(target.xCoord + yawDriftX, target.yCoord, target.zCoord + yawDriftZ);
            needed = RotationUtils.getNeededRotations(driftedTarget, eyes);
            smoothed = smoothRotate(startYaw, startPitch, needed[0], needed[1], speed);
            smoothed[0] = smoothed[0] + getSinusoidalYawJitter();
            smoothed[1] = smoothed[1] + getSinusoidalPitchJitter();
        }
        if (useGCD) {
            float prevYaw = hasLastServer ? lastServerYaw : realYaw;
            float prevPitch = hasLastServer ? lastServerPitch : realPitch;
            smoothed = RotationUtils.fixRotations(prevYaw, prevPitch, smoothed[0], smoothed[1]);
            smoothed[1] = RotationUtils.clamp(smoothed[1], -90, 90);
        }
        serverYaw = smoothed[0];
        serverPitch = smoothed[1];
        lastServerYaw = serverYaw;
        lastServerPitch = serverPitch;
        hasLastServer = true;
        firstTickOfStreak = false;
        Client.INSTANCE.renderYaw = realYaw;
        Client.INSTANCE.renderPitch = realPitch;
        Client.INSTANCE.scaffoldYaw = serverYaw;
        Client.INSTANCE.scaffoldPitch = serverPitch;
        Client.INSTANCE.renderRotationOverride = true;
        mc.player.rotationYaw = serverYaw;
        mc.player.rotationPitch = serverPitch;
        float angle = RotationUtils.getAngleDifference(serverYaw, serverPitch, needed[0], needed[1]);
        return angle < ANGLE_THRESHOLD;
    }

    public static boolean tickToward(float targetYaw, float targetPitch, float minSpeed, float maxSpeed, boolean pitchJitter, boolean gridLock) {
        if (!active || mc.player == null)
            return false;
        if (mode != Mode.CONTINUOUS) {
            mode = Mode.CONTINUOUS;
            realYaw = mc.player.rotationYaw;
            realPitch = mc.player.rotationPitch;
            lastServerYaw = realYaw;
            lastServerPitch = realPitch;
            hasLastServer = false;
            firstTickOfStreak = true;
        }
        if (hasLastServer) {
            float mouseDeltaYaw = RotationUtils.wrapDegrees(mc.player.rotationYaw - lastServerYaw);
            float mouseDeltaPitch = mc.player.rotationPitch - lastServerPitch;
            realYaw = RotationUtils.wrapDegrees(realYaw + mouseDeltaYaw);
            realPitch = RotationUtils.clamp(realPitch + mouseDeltaPitch, -90, 90);
        } else if (!firstTickOfStreak) {
            realYaw = mc.player.rotationYaw;
            realPitch = mc.player.rotationPitch;
        }
        float startYaw = hasLastServer ? lastServerYaw : realYaw;
        float startPitch = hasLastServer ? lastServerPitch : realPitch;
        if (gridLock) {
            int k = Math.round(RotationUtils.wrapDegrees(targetYaw - realYaw) / 45.0f);
            targetYaw = RotationUtils.wrapDegrees(realYaw + 45.0f * k);
        }
        float speed = minSpeed + random.nextFloat() * (maxSpeed - minSpeed);
        float yawDelta = RotationUtils.wrapDegrees(targetYaw - startYaw);
        float pitchDelta = targetPitch - startPitch;
        float totalDelta = Math.abs(yawDelta) + Math.abs(pitchDelta);
        float newYaw, newPitch;
        if (totalDelta <= speed || totalDelta < 0.05f) {
            newYaw = RotationUtils.wrapDegrees(targetYaw);
            newPitch = RotationUtils.clamp(targetPitch, -90, 90);
        } else {
            float scale = speed / totalDelta;
            newYaw = RotationUtils.wrapDegrees(startYaw + yawDelta * scale);
            newPitch = RotationUtils.clamp(startPitch + pitchDelta * scale, -90, 90);
        }
        if (pitchJitter) {
            updateJitterState();
            newPitch = RotationUtils.clamp(newPitch + getSinusoidalPitchJitter(), -90, 90);
        }
        serverYaw = newYaw;
        serverPitch = newPitch;
        lastServerYaw = serverYaw;
        lastServerPitch = serverPitch;
        hasLastServer = true;
        firstTickOfStreak = false;
        Client.INSTANCE.renderYaw = realYaw;
        Client.INSTANCE.renderPitch = realPitch;
        Client.INSTANCE.scaffoldYaw = serverYaw;
        Client.INSTANCE.scaffoldPitch = serverPitch;
        Client.INSTANCE.renderRotationOverride = true;
        mc.player.rotationYaw = serverYaw;
        mc.player.rotationPitch = serverPitch;
        return Math.abs(RotationUtils.wrapDegrees(serverYaw - targetYaw)) < 0.01f && Math.abs(serverPitch - targetPitch) < 5.0f;
    }

    public static boolean tickTowardQuant(float targetYaw, float targetPitch, float minSpeed, float maxSpeed, boolean pitchJitter, boolean gridLock) {
        if (!active || mc.player == null)
            return false;
        if (mode != Mode.CONTINUOUS) {
            mode = Mode.CONTINUOUS;
            realYaw = mc.player.rotationYaw;
            realPitch = mc.player.rotationPitch;
            lastServerYaw = realYaw;
            lastServerPitch = realPitch;
            hasLastServer = false;
            firstTickOfStreak = true;
            contPendYaw = 0.0f;
            contPendPitch = 0.0f;
        }
        if (hasLastServer) {
            float mouseDeltaYaw = RotationUtils.wrapDegrees(mc.player.rotationYaw - lastServerYaw);
            float mouseDeltaPitch = mc.player.rotationPitch - lastServerPitch;
            realYaw = RotationUtils.wrapDegrees(realYaw + mouseDeltaYaw);
            realPitch = RotationUtils.clamp(realPitch + mouseDeltaPitch, -90, 90);
        } else if (!firstTickOfStreak) {
            realYaw = mc.player.rotationYaw;
            realPitch = mc.player.rotationPitch;
        }
        float startYaw = hasLastServer ? lastServerYaw : realYaw;
        float startPitch = hasLastServer ? lastServerPitch : realPitch;
        if (gridLock) {
            int k = Math.round(RotationUtils.wrapDegrees(targetYaw - realYaw) / 45.0f);
            targetYaw = RotationUtils.wrapDegrees(realYaw + 45.0f * k);
        }
        if (pitchJitter) {
            updateJitterState();
            targetPitch = targetPitch + getSinusoidalPitchJitter();
        }
        float speed = minSpeed + random.nextFloat() * (maxSpeed - minSpeed);
        float yawErr = RotationUtils.wrapDegrees(targetYaw - startYaw);
        float pitchErr = targetPitch - startPitch;
        float total = Math.abs(yawErr) + Math.abs(pitchErr);
        float quantum = getMouseScale() * 0.15f;
        if (quantum < 0.001f)
            quantum = 0.001f;
        float newYaw = startYaw;
        float newPitch = startPitch;
        if (total <= speed || total < 0.05f) {
            int ySteps = (int) (yawErr / quantum);
            int pSteps = (int) (pitchErr / quantum);
            newYaw = RotationUtils.wrapDegrees(startYaw + ySteps * quantum);
            newPitch = RotationUtils.clamp(startPitch + pSteps * quantum, -90, 90);
            contPendYaw = 0.0f;
            contPendPitch = 0.0f;
        } else {
            float yawStepDeg = speed * Math.abs(yawErr) / total;
            float pitchStepDeg = speed * Math.abs(pitchErr) / total;
            if (Math.round(yawErr / quantum) != 0) {
                contPendYaw += Math.signum(yawErr) * (yawStepDeg / quantum);
                float remaining = Math.abs(yawErr) / quantum;
                if (Math.abs(contPendYaw) > remaining) {
                    contPendYaw = Math.signum(yawErr) * remaining;
                }
                int applied = (int) contPendYaw;
                contPendYaw -= applied;
                newYaw = RotationUtils.wrapDegrees(startYaw + applied * quantum);
            }
            if (Math.round(pitchErr / quantum) != 0) {
                contPendPitch += Math.signum(pitchErr) * (pitchStepDeg / quantum);
                float remaining = Math.abs(pitchErr) / quantum;
                if (Math.abs(contPendPitch) > remaining) {
                    contPendPitch = Math.signum(pitchErr) * remaining;
                }
                int applied = (int) contPendPitch;
                contPendPitch -= applied;
                newPitch = RotationUtils.clamp(startPitch + applied * quantum, -90, 90);
            }
        }
        serverYaw = newYaw;
        serverPitch = newPitch;
        lastServerYaw = serverYaw;
        lastServerPitch = serverPitch;
        hasLastServer = true;
        firstTickOfStreak = false;
        Client.INSTANCE.renderYaw = realYaw;
        Client.INSTANCE.renderPitch = realPitch;
        Client.INSTANCE.scaffoldYaw = serverYaw;
        Client.INSTANCE.scaffoldPitch = serverPitch;
        Client.INSTANCE.renderRotationOverride = true;
        mc.player.rotationYaw = serverYaw;
        mc.player.rotationPitch = serverPitch;
        return Math.abs(RotationUtils.wrapDegrees(serverYaw - targetYaw)) < quantum && Math.abs(serverPitch - targetPitch) < quantum;
    }

    public static void clearQuantPending() {
        contPendYaw = 0.0f;
        contPendPitch = 0.0f;
    }

    private static final float ANGLE_THRESHOLD = 7.0f;

    public static void accumulateDeltas() {
        if (!active || mode != Mode.CONTINUOUS || !hasLastServer || mc.player == null)
            return;
        float mouseDeltaYaw = RotationUtils.wrapDegrees(mc.player.rotationYaw - lastServerYaw);
        float mouseDeltaPitch = mc.player.rotationPitch - lastServerPitch;
        realYaw = RotationUtils.wrapDegrees(realYaw + mouseDeltaYaw);
        realPitch = RotationUtils.clamp(realPitch + mouseDeltaPitch, -90, 90);
    }

    public static void setServerRotation(float yaw, float pitch) {
        if (!active || mode != Mode.CONTINUOUS)
            return;
        serverYaw = yaw;
        serverPitch = pitch;
        lastServerYaw = yaw;
        lastServerPitch = pitch;
        hasLastServer = true;
        firstTickOfStreak = false;
        Client.INSTANCE.scaffoldYaw = yaw;
        Client.INSTANCE.scaffoldPitch = pitch;
    }

    public static boolean holdStreakTick() {
        if (!maintainStreakRotation())
            return false;
        applyMovementCorrection(realYaw, serverYaw);
        return true;
    }

    public static boolean holdParkedTick() {
        return maintainStreakRotation();
    }

    public static boolean hasServerRotation() {
        return active && mode == Mode.CONTINUOUS && hasLastServer;
    }

    private static boolean maintainStreakRotation() {
        if (!isContinuous() || mc.player == null)
            return false;
        if (!hasLastServer)
            return false;
        accumulateDeltas();
        int holdK = Math.round(RotationUtils.wrapDegrees(serverYaw - realYaw) / 45.0f);
        serverYaw = RotationUtils.wrapDegrees(realYaw + 45.0f * holdK);
        lastServerYaw = serverYaw;
        mc.player.rotationYaw = serverYaw;
        mc.player.rotationPitch = serverPitch;
        Client.INSTANCE.renderYaw = realYaw;
        Client.INSTANCE.renderPitch = realPitch;
        Client.INSTANCE.scaffoldYaw = serverYaw;
        Client.INSTANCE.scaffoldPitch = serverPitch;
        Client.INSTANCE.renderRotationOverride = true;
        return true;
    }

    public static void revertToRealForPacket() {
        if (!active || mode != Mode.CONTINUOUS || mc.player == null)
            return;
        if (!hasLastServer)
            return;
        mc.player.rotationYaw = realYaw;
        mc.player.rotationPitch = realPitch;
        Client.INSTANCE.scaffoldYaw = realYaw;
        Client.INSTANCE.scaffoldPitch = realPitch;
        serverYaw = realYaw;
        serverPitch = realPitch;
        lastServerYaw = realYaw;
        lastServerPitch = realPitch;
    }

    public static void endStreak() {
        if (!active || mode != Mode.CONTINUOUS)
            return;
        restoreEntityRotation();
        Client.INSTANCE.renderRotationOverride = false;
    }

    public static void resetStreak() {
        if (!active || mode != Mode.CONTINUOUS)
            return;
        restoreEntityRotation();
        Client.INSTANCE.renderRotationOverride = false;
        hasLastServer = false;
        firstTickOfStreak = false;
    }

    public static float getRealYaw() {
        return realYaw;
    }

    public static float getRealPitch() {
        return realPitch;
    }

    public static float getServerYaw() {
        return serverYaw;
    }

    public static float getServerPitch() {
        return serverPitch;
    }

    public static boolean isContinuous() {
        return active && mode == Mode.CONTINUOUS;
    }

    public static boolean isSimple() {
        return active && mode == Mode.SIMPLE;
    }

    public static float getSinusoidalYawJitter() {
        updateJitterState();
        float primary = (float) (Math.sin(jitterYawPhase) * jitterYawAmplitude);
        float secondary = (float) (Math.sin(jitterYawPhase * 2.7f + 1.3f) * jitterYawAmplitude * 0.3f);
        return primary + secondary;
    }

    public static float getSinusoidalPitchJitter() {
        updateJitterState();
        float primary = (float) (Math.sin(jitterPitchPhase) * jitterPitchAmplitude);
        float secondary = (float) (Math.sin(jitterPitchPhase * 3.1f + 0.7f) * jitterPitchAmplitude * 0.25f);
        return primary + secondary;
    }

    private static void updateJitterState() {
        long now = System.currentTimeMillis();
        if (now - lastJitterUpdate > 200 + random.nextInt(300)) {
            lastJitterUpdate = now;
            jitterYawSpeed = 0.05f + random.nextFloat() * 0.15f;
            jitterPitchSpeed = 0.04f + random.nextFloat() * 0.12f;
            jitterYawAmplitude = 0.15f + random.nextFloat() * 0.25f;
            jitterPitchAmplitude = 0.1f + random.nextFloat() * 0.2f;
        }
        jitterYawPhase += jitterYawSpeed;
        jitterPitchPhase += jitterPitchSpeed;
        if (jitterYawPhase > Math.PI * 2) {
            jitterYawPhase -= (float) Math.PI * 2;
        }
        if (jitterPitchPhase > Math.PI * 2) {
            jitterPitchPhase -= (float) Math.PI * 2;
        }
    }

    public static void resetJitterState() {
        jitterYawPhase = 0.0f;
        jitterPitchPhase = 0.0f;
        jitterYawAmplitude = 0.0f;
        jitterPitchAmplitude = 0.0f;
        jitterYawSpeed = 0.0f;
        jitterPitchSpeed = 0.0f;
        lastJitterUpdate = 0L;
    }

    public static float getMouseScale() {
        if (mc.gameSettings == null)
            return 0.125f;
        float sens = mc.gameSettings.mouseSensitivity;
        float base = sens * 0.6f + 0.2f;
        return base * base * base * 8.0f;
    }

    private static float[] applyIntegerDeltas() {
        if (!idInitialized && mc.player != null) {
            idLastServerYaw = mc.player.rotationYaw;
            idLastServerPitch = mc.player.rotationPitch;
            idInitialized = true;
        }
        int yawSteps = (int) pendingYawDelta;
        int pitchSteps = (int) pendingPitchDelta;
        pendingYawDelta -= yawSteps;
        pendingPitchDelta -= pitchSteps;
        float mouseScale = getMouseScale();
        float yawRot = yawSteps * mouseScale * 0.15f;
        float pitchRot = pitchSteps * mouseScale * 0.15f;
        float newYaw = idLastServerYaw + yawRot;
        float newPitch = RotationUtils.clamp(idLastServerPitch + pitchRot, -90, 90);
        return new float[] { newYaw, newPitch };
    }

    public static boolean faceTargetSmoothGCD(float targetYaw, float targetPitch, float speed, boolean useJitter) {
        if (!active || mc.player == null)
            return false;
        mode = Mode.SIMPLE;
        savedClientYaw = mc.player.rotationYaw;
        savedClientPitch = mc.player.rotationPitch;
        if (!idInitialized) {
            idLastServerYaw = savedClientYaw;
            idLastServerPitch = savedClientPitch;
            idInitialized = true;
            pendingYawDelta = 0.0f;
            pendingPitchDelta = 0.0f;
        }
        float yawError = RotationUtils.wrapDegrees(targetYaw - idLastServerYaw);
        float pitchError = targetPitch - idLastServerPitch;
        if (useJitter) {
            yawError += getSinusoidalYawJitter();
            pitchError += getSinusoidalPitchJitter();
        }
        float mouseScale = getMouseScale();
        float rotPerStep = mouseScale * 0.15f;
        if (rotPerStep > 0.001f) {
            float yawStepsNeeded = yawError / rotPerStep;
            float pitchStepsNeeded = pitchError / rotPerStep;
            float yawSteps = Math.signum(yawStepsNeeded) * Math.min(Math.abs(yawStepsNeeded), speed);
            float pitchSteps = Math.signum(pitchStepsNeeded) * Math.min(Math.abs(pitchStepsNeeded), speed);
            pendingYawDelta += yawSteps;
            pendingPitchDelta += pitchSteps;
        }
        float[] result = applyIntegerDeltas();
        float finalYaw = result[0];
        float finalPitch = result[1];
        idLastServerYaw = finalYaw;
        idLastServerPitch = finalPitch;
        mc.player.rotationYaw = finalYaw;
        mc.player.rotationPitch = finalPitch;
        simpleServerYaw = finalYaw;
        simpleServerPitch = finalPitch;
        simpleSetThisTick = true;
        Client.INSTANCE.renderYaw = savedClientYaw;
        Client.INSTANCE.renderPitch = savedClientPitch;
        Client.INSTANCE.scaffoldYaw = finalYaw;
        Client.INSTANCE.scaffoldPitch = finalPitch;
        Client.INSTANCE.renderRotationOverride = true;
        float angle = RotationUtils.getAngleDifference(finalYaw, finalPitch, targetYaw, targetPitch);
        return angle < ANGLE_THRESHOLD;
    }

    public static boolean faceTargetSmoothGCD(Vec3d target, float speed, boolean useJitter) {
        float[] needed = RotationUtils.getNeededRotations(target);
        return faceTargetSmoothGCD(needed[0], needed[1], speed, useJitter);
    }

    public static void resetIntegerDelta() {
        pendingYawDelta = 0.0f;
        pendingPitchDelta = 0.0f;
        idInitialized = false;
        if (mc.player != null) {
            idLastServerYaw = mc.player.rotationYaw;
            idLastServerPitch = mc.player.rotationPitch;
        }
    }

    private static final float PITCH_PROP_GAIN = 0.45f;

    private static final float PITCH_INT_GAIN = 0.91f;

    private static final float YAW_PROP_ON = 0.05f;

    private static final float YAW_PROP_OFF = 0.1f;

    private static final float YAW_INT_GAIN = 0.33f;

    private static final float INT_STEP = 0.05f;

    private static final float DIST_DECAY = 0.8f;

    public static void initPIController() {
        piYawIntegral = 0.0f;
        piPitchIntegral = 0.0f;
        piYawPropScale = 0.8f + random.nextFloat() * 0.4f;
        piPitchPropScale = 0.85f + random.nextFloat() * 0.3f;
        piYawIntScale = 0.85f + random.nextFloat() * 0.3f;
        piPitchIntScale = 0.85f + random.nextFloat() * 0.3f;
        piOnTarget = false;
    }

    public static float[] piAimAdjustment(float managedYaw, float managedPitch, float targetYaw, float targetPitch, float prevYaw, float prevPitch, double dist, double targetSpeed, boolean onTarget) {
        float yawErr = RotationUtils.wrapDegrees(targetYaw - managedYaw);
        float pitchErr = RotationUtils.wrapDegrees(targetPitch - managedPitch);
        float prevYawStep = managedYaw - prevYaw;
        float prevPitchStep = managedPitch - prevPitch;
        if (dist < DIST_DECAY) {
            double s = dist / DIST_DECAY;
            pitchErr *= (float) (s * s);
            yawErr *= (float) s;
        }
        float pPropGain = PITCH_PROP_GAIN * piPitchPropScale;
        float pIntGain = PITCH_INT_GAIN * piPitchIntScale;
        float yPropGain = (onTarget ? YAW_PROP_ON : YAW_PROP_OFF) * piYawPropScale;
        float yIntGain = YAW_INT_GAIN * piYawIntScale;
        boolean continuing = Math.signum(yawErr) == Math.signum(prevYawStep);
        if (continuing && Math.abs(yawErr) < 20.0f) {
            yPropGain *= 2.5f;
        }
        float pitchCtrlErr = pitchErr - prevPitchStep + prevYawStep * INT_STEP * (random.nextFloat() >= 0.5f ? -1.0f : 1.0f);
        float yawCtrlErr = yawErr - prevYawStep;
        piPitchIntegral += pitchCtrlErr * INT_STEP;
        piYawIntegral += yawCtrlErr * INT_STEP;
        float pitchAdj = pPropGain * pitchCtrlErr + pIntGain * piPitchIntegral;
        float yawAdj = yPropGain * yawCtrlErr + yIntGain * piYawIntegral;
        if (Math.abs(yawErr) > 120.0f) {
            piYawIntegral = 0.0f;
            yawAdj = 0.0f;
        }
        piOnTarget = onTarget;
        return new float[] { managedYaw + yawErr + yawAdj / 3.0f, managedPitch + pitchAdj };
    }

    public static void resetPIController() {
        piYawIntegral = 0.0f;
        piPitchIntegral = 0.0f;
        piOnTarget = false;
    }

    private static final int[] COMPASS_STRAFE = { 0, 1, 1, 1, 0, -1, -1, -1 };

    private static final int[] COMPASS_FORWARD = { 1, 1, 0, -1, -1, -1, 0, 1 };

    private static final float GRID_TOLERANCE = 1.0f;

    private static int compassIndex(int strafe, int forward) {
        for (int i = 0; i < 8; i++) {
            if (COMPASS_STRAFE[i] == strafe && COMPASS_FORWARD[i] == forward) {
                return i;
            }
        }
        return -1;
    }

    public static void applyMovementCorrection(float realYaw, float serverYaw) {
        if (mc.player == null || mc.gameSettings == null)
            return;
        if (movementKeysRemapped) {
            restoreMovementKeys();
        }
        int strafe = (mc.gameSettings.keyBindLeft.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindRight.isKeyDown() ? 1 : 0);
        int forward = (mc.gameSettings.keyBindForward.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindBack.isKeyDown() ? 1 : 0);
        if (strafe == 0 && forward == 0)
            return;
        float offset = RotationUtils.wrapDegrees(serverYaw - realYaw);
        if (Math.abs(offset) < 5.0f)
            return;
        int newStrafe;
        int newForward;
        int k = Math.round(offset / 45.0f);
        float gridErr = offset - 45.0f * k;
        int idx = compassIndex(strafe, forward);
        if (idx >= 0 && Math.abs(gridErr) <= GRID_TOLERANCE) {
            int rIdx = ((idx + k) % 8 + 8) % 8;
            newStrafe = COMPASS_STRAFE[rIdx];
            newForward = COMPASS_FORWARD[rIdx];
        } else {
            float delta = RotationUtils.wrapDegrees(realYaw - serverYaw);
            float rad = delta * ((float) Math.PI / 180.0f);
            float cos = (float) Math.cos(rad);
            float sin = (float) Math.sin(rad);
            float rs = strafe * cos - forward * sin;
            float rf = strafe * sin + forward * cos;
            float absFwd = Math.abs(rf);
            float absStrafe = Math.abs(rs);
            float maxAbs = Math.max(absFwd, absStrafe);
            float thresh = Math.max(0.1f, maxAbs * 0.25f);
            newForward = rf >= thresh ? 1 : (rf <= -thresh ? -1 : 0);
            newStrafe = rs >= thresh ? 1 : (rs <= -thresh ? -1 : 0);
            if (newForward == 0 && newStrafe == 0) {
                if (absFwd >= absStrafe)
                    newForward = rf >= 0 ? 1 : -1;
                else
                    newStrafe = rs >= 0 ? 1 : -1;
            }
        }
        if (!movementKeysRemapped) {
            savedFwdKey = mc.gameSettings.keyBindForward.isKeyDown();
            savedLeftKey = mc.gameSettings.keyBindLeft.isKeyDown();
            savedRightKey = mc.gameSettings.keyBindRight.isKeyDown();
            savedBackKey = mc.gameSettings.keyBindBack.isKeyDown();
        }
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), newForward > 0);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), newForward < 0);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), newStrafe > 0);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), newStrafe < 0);
        movementKeysRemapped = true;
    }

    public static boolean isMovementInputBlocked() {
        return mc.currentScreen != null && !mc.currentScreen.allowUserInput;
    }

    public static void setKeyFromHardware(KeyBinding key) {
        boolean pressed = !isMovementInputBlocked() && Keyboard.isKeyDown(key.getKeyCode());
        KeyBinding.setKeyBindState(key.getKeyCode(), pressed);
    }

    public static void restoreMovementKeys() {
        if (!movementKeysRemapped)
            return;
        if (mc.gameSettings == null)
            return;
        setKeyFromHardware(mc.gameSettings.keyBindForward);
        setKeyFromHardware(mc.gameSettings.keyBindLeft);
        setKeyFromHardware(mc.gameSettings.keyBindRight);
        setKeyFromHardware(mc.gameSettings.keyBindBack);
        movementKeysRemapped = false;
    }

    public static boolean isMovementRemapped() {
        return movementKeysRemapped;
    }

    private static void restoreEntityRotation() {
        if (mc.player == null)
            return;
        if (hasLastServer) {
            float mouseDeltaYaw = RotationUtils.wrapDegrees(mc.player.rotationYaw - lastServerYaw);
            float mouseDeltaPitch = mc.player.rotationPitch - lastServerPitch;
            float restoredYaw = RotationUtils.wrapDegrees(realYaw + mouseDeltaYaw);
            float restoredPitch = RotationUtils.clamp(realPitch + mouseDeltaPitch, -90, 90);
            mc.player.rotationYaw = restoredYaw;
            mc.player.rotationPitch = restoredPitch;
            mc.player.prevRotationYaw = restoredYaw;
            mc.player.prevRotationPitch = restoredPitch;
            lastServerYaw = restoredYaw;
            lastServerPitch = restoredPitch;
        }
    }

    private static float[] smoothRotate(float curYaw, float curPitch, float targetYaw, float targetPitch, float speed) {
        float deltaYaw = RotationUtils.wrapDegrees(targetYaw - curYaw);
        float deltaPitch = targetPitch - curPitch;
        float totalDelta = Math.abs(deltaYaw) + Math.abs(deltaPitch);
        if (totalDelta < 0.1f) {
            return new float[] { targetYaw, targetPitch };
        }
        if (totalDelta > speed) {
            float scale = speed / totalDelta;
            deltaYaw *= scale;
            deltaPitch *= scale;
        }
        float newYaw = RotationUtils.wrapDegrees(curYaw + deltaYaw);
        float newPitch = RotationUtils.clamp(curPitch + deltaPitch, -90, 90);
        return new float[] { newYaw, newPitch };
    }
}
