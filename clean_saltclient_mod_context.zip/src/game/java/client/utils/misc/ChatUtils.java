package client.utils.misc;

import net.minecraft.client.Minecraft;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;

public class ChatUtils {

    private static boolean enabled = true;

    public static void setEnabled(boolean enabled) {
        ChatUtils.enabled = enabled;
    }

    public static boolean isEnabled() {
        return enabled;
    }

    public static void component(ITextComponent component) {
        if (enabled)
            Minecraft.getMinecraft().ingameGUI.getChatGUI().printChatMessage(new TextComponentString("\u00a7c[\u00a7bSalt\u00a7c]\u00a7f ").appendSibling(component));
    }

    public static void message(String message) {
        component(new TextComponentString(message));
    }

    public static void warning(String message) {
        component(new TextComponentString("\u00a7c[\u00a76\u00a7lWARNING\u00a7c]\u00a7f " + message));
    }

    public static void error(String message) {
        component(new TextComponentString("\u00a7c[\u00a74\u00a7lERROR\u00a7c]\u00a7f " + message));
    }

    public static void success(String message) {
        component(new TextComponentString("\u00a7a[\u00a72\u00a7lSUCCESS\u00a7a]\u00a7f " + message));
    }

    public static void failure(String message) {
        component(new TextComponentString("\u00a7c[\u00a74\u00a7lFAILURE\u00a7c]\u00a7f " + message));
    }

    public static void cmd(String message) {
        if (enabled)
            Minecraft.getMinecraft().ingameGUI.getChatGUI().printChatMessage(new TextComponentString("\u00a7c[\u00a7bSalt\u00a7c]\u00a7f \u00a70\u00a7l<\u00a7aCMD\u00a70\u00a7l>\u00a7f " + message));
    }

    public static void info(String message) {
        component(new TextComponentString("\u00a7b[\u00a79\u00a7lINFO\u00a7b]\u00a7f " + message));
    }
}
