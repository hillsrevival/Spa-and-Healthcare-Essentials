package client.utils.misc;

import net.minecraft.client.Minecraft;

public final class TimerUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private TimerUtils() {
    }

    public static void setTimerSpeed(float speed) {
        if (mc.timer != null) {
            mc.timer.timerSpeed = speed;
        }
    }

    public static float getTimerSpeed() {
        if (mc.timer == null)
            return 1.0f;
        return mc.timer.timerSpeed;
    }

    public static void resetTimer() {
        if (mc.timer != null) {
            mc.timer.timerSpeed = 1.0f;
        }
    }
}
