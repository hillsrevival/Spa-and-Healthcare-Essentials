package client.utils.misc;

public final class ProfilerScope implements AutoCloseable {

    static final ProfilerScope DISABLED = new ProfilerScope(0L);

    private final long token;

    private boolean closed;

    ProfilerScope(long token) {
        this.token = token;
    }

    @Override
    public void close() {
        if (closed)
            return;
        closed = true;
        PerformanceProfiler.end(token);
    }
}
