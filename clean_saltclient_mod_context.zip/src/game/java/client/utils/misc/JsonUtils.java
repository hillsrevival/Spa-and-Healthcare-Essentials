package client.utils.misc;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class JsonUtils {

    public static String getJsonString(JSONObject json, String key) {
        if (!json.has(key))
            throw new JSONException("Missing " + key);
        return json.getString(key);
    }

    public static String getJsonString(JSONObject json, String key, String fallback) {
        return json.has(key) ? json.getString(key) : fallback;
    }

    public static int getJsonInt(JSONObject json, String key) {
        if (!json.has(key))
            throw new JSONException("Missing " + key);
        return json.getInt(key);
    }

    public static int getJsonInt(JSONObject json, String key, int fallback) {
        return json.has(key) ? json.getInt(key) : fallback;
    }

    public static float getJsonFloat(JSONObject json, String key) {
        if (!json.has(key))
            throw new JSONException("Missing " + key);
        return (float) json.getDouble(key);
    }

    public static float getJsonFloat(JSONObject json, String key, float fallback) {
        return json.has(key) ? (float) json.getDouble(key) : fallback;
    }

    public static double getJsonDouble(JSONObject json, String key) {
        if (!json.has(key))
            throw new JSONException("Missing " + key);
        return json.getDouble(key);
    }

    public static double getJsonDouble(JSONObject json, String key, double fallback) {
        return json.has(key) ? json.getDouble(key) : fallback;
    }

    public static boolean getJsonBool(JSONObject json, String key) {
        if (!json.has(key))
            throw new JSONException("Missing " + key);
        return json.getBoolean(key);
    }

    public static boolean getJsonBool(JSONObject json, String key, boolean fallback) {
        return json.has(key) ? json.getBoolean(key) : fallback;
    }

    public static JSONObject getJsonObject(JSONObject json, String key) {
        if (!json.has(key))
            throw new JSONException("Missing " + key);
        return json.getJSONObject(key);
    }

    public static JSONObject getJsonObject(JSONObject json, String key, JSONObject fallback) {
        return json.has(key) ? json.getJSONObject(key) : fallback;
    }

    public static JSONArray getJsonArray(JSONObject json, String key) {
        if (!json.has(key))
            throw new JSONException("Missing " + key);
        return json.getJSONArray(key);
    }

    public static JSONArray getJsonArray(JSONObject json, String key, JSONArray fallback) {
        return json.has(key) ? json.getJSONArray(key) : fallback;
    }

    public static String prettyPrint(JSONObject json) {
        return json.toString(2);
    }

    public static String prettyPrint(JSONArray json) {
        return json.toString(2);
    }
}
