package client.utils.misc;

import org.teavm.jso.JSBody;

public class PlayerCounter {

    private static boolean initialized = false;

    private static final long COUNT_CACHE_TTL_MS = 250;

    private static final CachedValue<Integer> playerCountCache = new CachedValue<>();

    private static final CachedValue<Integer> discordCountCache = new CachedValue<>();

    public static void init() {
        if (initialized)
            return;
        initialized = true;
        startAsyncLoops();
    }

    public static int getPlayerCount() {
        return playerCountCache.getOrCompute(COUNT_CACHE_TTL_MS, PlayerCounter::readCachedCount);
    }

    public static int getDiscordMemberCount() {
        return discordCountCache.getOrCompute(COUNT_CACHE_TTL_MS, PlayerCounter::readCachedDiscordCount);
    }

    @JSBody(script = "return (typeof window._gcPlayerCount === 'number') ? window._gcPlayerCount : -1;")
    private static native int readCachedCount();

    @JSBody(script = "return (typeof window._gcDiscordMembers === 'number') ? window._gcDiscordMembers : -1;")
    private static native int readCachedDiscordCount();

    @JSBody(script = "" + "if (window._gcStatsInit) return;" + "window._gcStatsInit = true;" + "window._gcPlayerCount = -1;" + "window._gcDiscordMembers = -1;" + "var BASE = 'https://galactic.galacticclient.workers.dev';" + "var DISCORD = 'https://discord.com/api/v9/invites/3z2Fv5Efa4?with_counts=true';" + "var DISCORD_FB = 'https://discord.galacticflagsfrfr7123.workers.dev/';" + "var chars = 'abcdef0123456789';" + "var uuid;" + "try { uuid = localStorage.getItem('gc_player_uuid'); } catch(e) { uuid = null; }" + "if (!uuid || uuid.length < 8) {" + "  uuid = '';" + "  for (var i = 0; i < 16; i++) uuid += chars[Math.floor(Math.random() * 16)];" + "  try { localStorage.setItem('gc_player_uuid', uuid); } catch(e) {}" + "}" + "var doPlayerPing = function() {" + "  try {" + "    fetch(BASE + '/heartbeat?uuid=' + encodeURIComponent(uuid))" + "      .then(function(r) { return r.json(); })" + "      .then(function(d) {" + "        if (typeof d.count === 'number') window._gcPlayerCount = d.count;" + "      }).catch(function() {});" + "  } catch(e) {}" + "};" + "var doDiscordPing = function() {" + "  try {" + "    var settled = false;" + "    var finish = function(n) {" + "      if (!settled && typeof n === 'number' && n >= 0) {" + "        settled = true;" + "        window._gcDiscordMembers = n;" + "      }" + "    };" + "    var fallback = function() {" + "      fetch(DISCORD_FB)" + "        .then(function(r) { return r.json(); })" + "        .then(function(d) {" + "          if (typeof d.members === 'number') finish(d.members);" + "        }).catch(function() {});" + "    };" + "    var timer = setTimeout(function() { fallback(); }, 5000);" + "    fetch(DISCORD)" + "      .then(function(r) { return r.json(); })" + "      .then(function(d) {" + "        clearTimeout(timer);" + "        if (typeof d.approximate_member_count === 'number')" + "          finish(d.approximate_member_count);" + "        else fallback();" + "      }).catch(function() {" + "        clearTimeout(timer);" + "        fallback();" + "      });" + "  } catch(e) {}" + "};" + "doPlayerPing();" + "doDiscordPing();" + "setInterval(doPlayerPing, 900000);" + "setInterval(doDiscordPing, 300000);")
    private static native void startAsyncLoops();
}
