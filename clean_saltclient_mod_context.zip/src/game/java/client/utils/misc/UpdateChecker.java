package client.utils.misc;

import org.json.JSONObject;
import org.teavm.jso.JSBody;
import org.teavm.jso.JSFunctor;
import org.teavm.jso.JSObject;

public final class UpdateChecker {

    private static final String VERSION_URL = "https://raw.githubusercontent.com/Galactic-Info/info/main/version.json";

    private static final String DOWNLOAD_URL_ENDPOINT = "https://galactic.galactic-info.workers.dev/download.json";

    private static final String FALLBACK_URL = "https://gitflic.ru/project/galacticclient/galactic-client/release";

    private static final String CLIENT_VERSION = "8.2.0";

    public enum UpdateState {

        CHECKING, UP_TO_DATE, OUTDATED, FETCH_FAILED
    }

    private static UpdateState state = UpdateState.CHECKING;

    private static String latestVersion = null;

    private static String latestUrl = null;

    private static boolean fetchStarted = false;

    private UpdateChecker() {
    }

    @JSFunctor
    public interface FetchCallback extends JSObject {

        void onComplete(String data);
    }

    @JSBody(params = { "uri", "callback" }, script = "fetch(uri, { cache: \"no-cache\", mode: \"cors\" })" + ".then(function(res) { return res.text(); })" + ".then(function(text) { callback(text); })" + ".catch(function(err) { console.error(err); callback(null); });")
    private static native void doFetch(String uri, FetchCallback callback);

    @JSBody(params = { "url" }, script = "if (typeof window !== \"undefined\" && window.open) {" + "  window.open(url, \"_blank\");" + "} else if (typeof EaglercraftLocator !== \"undefined\") {" + "  EaglercraftLocator.openLink(url);" + "}")
    public static native void openUrl(String url);

    public static void checkForUpdates() {
        if (fetchStarted)
            return;
        fetchStarted = true;
        state = UpdateState.CHECKING;
        try {
            doFetch(VERSION_URL, (data) -> {
                try {
                    if (data != null && !data.isEmpty()) {
                        JSONObject json = new JSONObject(data);
                        String version = JsonUtils.getJsonString(json, "version", null);
                        if (version != null && !version.isEmpty()) {
                            latestVersion = version;
                            if (compareVersions(version, CLIENT_VERSION) > 0) {
                                state = UpdateState.OUTDATED;
                                String url = JsonUtils.getJsonString(json, "download_url", null);
                                if (url != null && !url.isEmpty()) {
                                    latestUrl = url;
                                } else {
                                    fetchDownloadLink();
                                }
                            } else {
                                state = UpdateState.UP_TO_DATE;
                            }
                        } else {
                            state = UpdateState.FETCH_FAILED;
                        }
                    } else {
                        state = UpdateState.FETCH_FAILED;
                    }
                } catch (Exception e) {
                    state = UpdateState.FETCH_FAILED;
                }
            });
        } catch (Throwable t) {
            state = UpdateState.FETCH_FAILED;
        }
    }

    private static void fetchDownloadLink() {
        try {
            doFetch(DOWNLOAD_URL_ENDPOINT, (data) -> {
                try {
                    if (data != null && !data.isEmpty()) {
                        String url = JsonUtils.getJsonString(new JSONObject(data), "download_url", null);
                        if (url != null && !url.isEmpty()) {
                            latestUrl = url;
                        }
                    }
                } catch (Exception e) {
                }
            });
        } catch (Throwable t) {
        }
    }

    public static UpdateState getState() {
        return state;
    }

    public static String getLatestVersion() {
        return latestVersion;
    }

    public static String getDownloadUrl() {
        if (latestUrl != null && !latestUrl.isEmpty()) {
            return latestUrl;
        }
        return FALLBACK_URL;
    }

    public static String getClientVersion() {
        return CLIENT_VERSION;
    }

    private static int compareVersions(String v1, String v2) {
        String[] parts1 = v1.split("\\.");
        String[] parts2 = v2.split("\\.");
        int len = Math.max(parts1.length, parts2.length);
        for (int i = 0; i < len; i++) {
            int n1 = i < parts1.length ? parseIntSafe(parts1[i]) : 0;
            int n2 = i < parts2.length ? parseIntSafe(parts2[i]) : 0;
            if (n1 != n2)
                return n1 - n2;
        }
        return 0;
    }

    private static int parseIntSafe(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }
}
