package client.utils.misc;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;

public final class KeyBindingHelper {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private KeyBindingHelper() {
    }

    public static void setPressedAndTick(KeyBinding key, boolean pressed) {
        KeyBinding.setKeyBindState(key.getKeyCode(), pressed);
        if (pressed) {
            KeyBinding.onTick(key.getKeyCode());
        }
    }

    public static void setPressed(KeyBinding key, boolean pressed) {
        KeyBinding.setKeyBindState(key.getKeyCode(), pressed);
    }

    public static boolean isDown(KeyBinding key) {
        return key.isKeyDown();
    }

    public static void releaseMovementKeys() {
        setPressed(mc.gameSettings.keyBindForward, false);
        setPressed(mc.gameSettings.keyBindBack, false);
        setPressed(mc.gameSettings.keyBindLeft, false);
        setPressed(mc.gameSettings.keyBindRight, false);
    }

    public static boolean isMoving() {
        return mc.gameSettings.keyBindForward.isKeyDown() || mc.gameSettings.keyBindBack.isKeyDown() || mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown();
    }

    public static float getMoveForward() {
        float f = 0;
        if (mc.gameSettings.keyBindForward.isKeyDown())
            f += 1;
        if (mc.gameSettings.keyBindBack.isKeyDown())
            f -= 1;
        return f;
    }

    public static float getMoveStrafe() {
        float f = 0;
        if (mc.gameSettings.keyBindLeft.isKeyDown())
            f += 1;
        if (mc.gameSettings.keyBindRight.isKeyDown())
            f -= 1;
        return f;
    }
}
