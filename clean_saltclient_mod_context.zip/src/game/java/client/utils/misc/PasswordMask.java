package client.utils.misc;

public final class PasswordMask {

    private static final String[] COMMANDS = { "/login ", "/register ", "/l ", "/reg ", "/log ", "/changepassword ", "/changepass ", "/cpass " };

    private PasswordMask() {
    }

    public static String getMaskedText(String text) {
        if (text == null || text.isEmpty())
            return text;
        String lower = text.toLowerCase();
        for (String cmd : COMMANDS) {
            if (lower.startsWith(cmd)) {
                int spaceIdx = text.indexOf(' ');
                if (spaceIdx >= 0 && spaceIdx < text.length() - 1) {
                    StringBuilder masked = new StringBuilder(text.length());
                    masked.append(text.substring(0, spaceIdx + 1));
                    for (int i = spaceIdx + 1; i < text.length(); i++) {
                        masked.append('~');
                    }
                    return masked.toString();
                }
            }
        }
        return text;
    }

    public static boolean isPasswordCommand(String text) {
        if (text == null || text.isEmpty())
            return false;
        String lower = text.toLowerCase();
        for (String cmd : COMMANDS) {
            if (lower.startsWith(cmd))
                return true;
        }
        return false;
    }

    public static int getPasswordStartIndex(String text) {
        if (text == null || text.isEmpty())
            return -1;
        String lower = text.toLowerCase();
        for (String cmd : COMMANDS) {
            if (lower.startsWith(cmd)) {
                int spaceIdx = text.indexOf(' ');
                if (spaceIdx >= 0)
                    return spaceIdx + 1;
            }
        }
        return -1;
    }
}
