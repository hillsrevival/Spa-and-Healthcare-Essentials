package client.utils.misc;

import java.util.ArrayDeque;
import java.util.Deque;

public final class ClickRateTracker {

    private static final long WINDOW_MS = 1000;

    private final Deque<Long> clickTimes = new ArrayDeque<>();

    public void recordClick() {
        long now = System.currentTimeMillis();
        clickTimes.addLast(now);
        pruneOld(now);
    }

    public int getCPS() {
        pruneOld(System.currentTimeMillis());
        return clickTimes.size();
    }

    public boolean isClicking() {
        pruneOld(System.currentTimeMillis());
        return !clickTimes.isEmpty();
    }

    public void clear() {
        clickTimes.clear();
    }

    private void pruneOld(long now) {
        while (!clickTimes.isEmpty() && clickTimes.peekFirst() < now - WINDOW_MS) {
            clickTimes.pollFirst();
        }
    }
}
