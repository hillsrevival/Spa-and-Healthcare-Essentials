package client.utils.misc;

public final class PerformanceProfiler {

    public static boolean active = false;

    public static int sampleRate = 1;

    public static int minCalls = 10;

    private static final int MAX = 128;

    private static final String[] names = new String[MAX];

    private static final String[] cats = new String[MAX];

    private static int count = 0;

    private static final long[] totalNs = new long[MAX];

    private static final long[] calls = new long[MAX];

    private static final long[] maxNs = new long[MAX];

    private static final long[] minNs = new long[MAX];

    private static final long[] sumSqNs = new long[MAX];

    private static final boolean[] touched = new boolean[MAX];

    private static final long[] slowBk = new long[MAX * 4];

    private static final long[] SLOW_TH = { 100_000L, 500_000L, 1_000_000L, 5_000_000L };

    public static final int RUN_TICK = register("Minecraft.runTick", "Tick");

    public static final int RENDER_WORLD = register("EntityRenderer.renderWorld", "Rendering");

    public static final int SETUP_TERRAIN = register("RenderGlobal.setupTerrain", "Rendering");

    public static final int RENDER_ENTITIES = register("RenderGlobal.renderEntities", "Rendering");

    public static final int RENDER_SKY = register("RenderGlobal.renderSky", "Rendering");

    public static final int REBUILD_CHUNK = register("RenderChunk.rebuildChunk", "Chunk");

    public static final int RENDER_MODEL_SMOOTH = register("BlockModelRenderer.renderModelSmooth", "Rendering");

    public static final int RENDER_MODEL_FLAT = register("BlockModelRenderer.renderModelFlat", "Rendering");

    public static final int RENDER_FLUID = register("BlockFluidRenderer.renderFluid", "Rendering");

    public static final int RENDER_BLOCK = register("BlockRendererDispatcher.renderBlock", "Rendering");

    public static final int GET_LIGHT_FOR = register("World.getLightFor", "Lighting");

    public static final int GET_COLLISION_BOXES = register("World.getCollisionBoxes", "Physics");

    public static final int MOVE_ENTITY = register("Entity.moveEntity", "Physics");

    public static final int RENDER_PARTICLES = register("ParticleManager.renderParticles", "Rendering");

    public static final int DRAW_STRING = register("FontRenderer.drawString", "GUI");

    private static final int[] stkId = new int[64];

    private static final long[] stkT0 = new long[64];

    private static int stkDepth = 0;

    private static final int MAX_EDGES = 128;

    private static final int[] ePar = new int[MAX_EDGES];

    private static final int[] eChi = new int[MAX_EDGES];

    private static final long[] eTime = new long[MAX_EDGES];

    private static final long[] eCnt = new long[MAX_EDGES];

    private static int eSize = 0;

    private static long ticks, frames, frameId;

    private static long frameStart, worstFrameNs;

    private static long worstFrameId;

    private static final long[] worstSlotNs = new long[MAX];

    private static long sessionStart, profilerSelfNs;

    private static int sampleCtr;

    private static final long[] prevTotal = new long[MAX];

    public static long chunksRebuilt, chunksRendered, entitiesRendered;

    public static long particlesRendered, blockModelsRendered;

    public static long fluidModelsRendered, tileEntitiesRendered;

    public static long collisionQueries, collisionBoxesTested;

    public static long worstCollisionNs, collisionTotalNs;

    public static long getLightCalls, skyLookups, blockLookups;

    private static final int A_MAX = 8;

    private static final String[] A_NAME = { "BlockPos", "AxisAlignedBB", "Vec3d", "ArrayList", "HashSet", "EnumSet", "Event", "Other" };

    private static final long[] A_COUNT = new long[A_MAX];

    private static final long[] A_BYTES = { 24L, 48L, 40L, 24L, 32L, 16L, 16L, 32L };

    private static final int EVT_MAX = 64;

    private static final String[] evtName = new String[EVT_MAX];

    private static final long[] evtPosted = new long[EVT_MAX];

    private static final long[] evtSkipped = new long[EVT_MAX];

    private static final long[] evtTime = new long[EVT_MAX];

    private static final long[] evtInvokes = new long[EVT_MAX];

    private static final long[] evtListeners = new long[EVT_MAX];

    private static int evtCount = 0;

    private static final int MOD_MAX = 128;

    private static final String[] modName = new String[MOD_MAX];

    private static final long[] modTime = new long[MOD_MAX];

    private static final long[] modCalls = new long[MOD_MAX];

    private static int modCount = 0;

    public static int register(String name, String category) {
        int id = findId(name);
        if (id >= 0)
            return id;
        if (count >= MAX)
            return -1;
        id = count++;
        names[id] = name;
        cats[id] = category != null ? category : "Other";
        minNs[id] = Long.MAX_VALUE;
        return id;
    }

    public static int register(String name) {
        return register(name, null);
    }

    private static int findId(String name) {
        for (int i = 0; i < count; i++) {
            if (name.equals(names[i]))
                return i;
        }
        return -1;
    }

    public static int getMethodCount() {
        return count;
    }

    public static String getMethodName(int id) {
        return id < count ? names[id] : "?";
    }

    public static String getCategory(int id) {
        return id < count ? cats[id] : "Other";
    }

    public static long begin(int id) {
        if (!active)
            return 0L;
        if (sampleRate > 1 && ++sampleCtr % sampleRate != 0)
            return 0L;
        long t0 = System.nanoTime();
        if (stkDepth < 64) {
            stkId[stkDepth] = id;
            stkT0[stkDepth] = t0;
        }
        stkDepth++;
        return t0;
    }

    public static long begin(String name) {
        if (!active)
            return 0L;
        int id = findId(name);
        if (id < 0)
            id = register(name, "Other");
        return begin(id);
    }

    public static void end(long token) {
        if (token == 0L || stkDepth == 0)
            return;
        stkDepth--;
        int id = stkDepth > 63 ? 0 : stkId[stkDepth];
        long t0 = stkDepth > 63 ? token : stkT0[stkDepth];
        record(id, t0);
    }

    public static ProfilerScope open(int id) {
        long t = begin(id);
        return t != 0L ? new ProfilerScope(t) : ProfilerScope.DISABLED;
    }

    public static ProfilerScope open(String name) {
        long t = begin(name);
        return t != 0L ? new ProfilerScope(t) : ProfilerScope.DISABLED;
    }

    public static void profile(int id, Runnable r) {
        long t = begin(id);
        if (t == 0L) {
            r.run();
            return;
        }
        try {
            r.run();
        } finally {
            end(t);
        }
    }

    public static void allocBlockPos() {
        if (active)
            A_COUNT[0]++;
    }

    public static void allocAABB() {
        if (active)
            A_COUNT[1]++;
    }

    public static void allocVec3d() {
        if (active)
            A_COUNT[2]++;
    }

    public static void allocArrayList() {
        if (active)
            A_COUNT[3]++;
    }

    public static void allocHashSet() {
        if (active)
            A_COUNT[4]++;
    }

    public static void allocEnumSet() {
        if (active)
            A_COUNT[5]++;
    }

    public static void allocEvent() {
        if (active)
            A_COUNT[6]++;
    }

    public static void allocOther() {
        if (active)
            A_COUNT[7]++;
    }

    public static int evtRegister(String name) {
        if (!active)
            return -1;
        for (int i = 0; i < evtCount; i++) if (name.equals(evtName[i])) {
            evtPosted[i]++;
            return i;
        }
        if (evtCount >= EVT_MAX)
            return 0;
        int i = evtCount++;
        evtName[i] = name;
        evtPosted[i] = 1;
        return i;
    }

    public static void evtSkip(int idx) {
        if (active && idx >= 0)
            evtSkipped[idx]++;
    }

    public static void evtExec(int idx, long dt, int listenerCount) {
        if (active && idx >= 0) {
            evtTime[idx] += dt;
            evtInvokes[idx]++;
            evtListeners[idx] += listenerCount;
        }
    }

    public static int modRegister(String name) {
        if (!active)
            return -1;
        for (int i = 0; i < modCount; i++) if (name.equals(modName[i]))
            return i;
        if (modCount >= MOD_MAX)
            return 0;
        int i = modCount++;
        modName[i] = name;
        return i;
    }

    public static void modExec(int idx, long dt) {
        if (active && idx >= 0) {
            modTime[idx] += dt;
            modCalls[idx]++;
        }
    }

    public static void startSession() {
        for (int i = 0; i < count; i++) {
            totalNs[i] = 0;
            calls[i] = 0;
            maxNs[i] = 0;
            minNs[i] = Long.MAX_VALUE;
            sumSqNs[i] = 0;
            touched[i] = false;
            worstSlotNs[i] = 0;
            for (int b = 0; b < 4; b++) slowBk[i * 4 + b] = 0;
        }
        for (int i = 0; i < MAX_EDGES; i++) {
            ePar[i] = -1;
            eChi[i] = -1;
            eTime[i] = 0;
            eCnt[i] = 0;
        }
        eSize = 0;
        stkDepth = 0;
        ticks = 0;
        frames = 0;
        frameId = 0;
        worstFrameNs = 0;
        worstFrameId = 0;
        sessionStart = System.nanoTime();
        frameStart = sessionStart;
        profilerSelfNs = 0;
        sampleCtr = 0;
        chunksRebuilt = 0;
        chunksRendered = 0;
        entitiesRendered = 0;
        particlesRendered = 0;
        blockModelsRendered = 0;
        fluidModelsRendered = 0;
        tileEntitiesRendered = 0;
        collisionQueries = 0;
        collisionBoxesTested = 0;
        worstCollisionNs = 0;
        collisionTotalNs = 0;
        getLightCalls = 0;
        skyLookups = 0;
        blockLookups = 0;
        for (int i = 0; i < A_MAX; i++) A_COUNT[i] = 0;
        for (int i = 0; i < EVT_MAX; i++) {
            evtName[i] = null;
            evtPosted[i] = 0;
            evtSkipped[i] = 0;
            evtTime[i] = 0;
            evtInvokes[i] = 0;
            evtListeners[i] = 0;
        }
        evtCount = 0;
        for (int i = 0; i < MOD_MAX; i++) {
            modName[i] = null;
            modTime[i] = 0;
            modCalls[i] = 0;
        }
        modCount = 0;
        active = true;
    }

    public static void stopSession() {
        for (int i = 0; i < count; i++) prevTotal[i] = totalNs[i];
        active = false;
        stkDepth = 0;
    }

    public static void reset() {
        stopSession();
        for (int i = 0; i < MAX; i++) prevTotal[i] = 0;
    }

    public static void countTick() {
        if (active)
            ticks++;
    }

    public static void countFrame() {
        if (!active)
            return;
        frames++;
        long now = System.nanoTime();
        long fn = now - frameStart;
        frameStart = now;
        frameId++;
        if (fn > worstFrameNs) {
            worstFrameNs = fn;
            worstFrameId = frameId;
            for (int i = 0; i < count; i++) worstSlotNs[i] = totalNs[i];
        }
    }

    public static String getReport() {
        long wallNs = System.nanoTime() - sessionStart;
        double wallSec = wallNs / 1e9;
        long[] selfNs = new long[count];
        for (int i = 0; i < count; i++) selfNs[i] = totalNs[i];
        for (int i = 0; i < eSize; i++) {
            if (ePar[i] < count)
                selfNs[ePar[i]] -= eTime[i];
        }
        for (int i = 0; i < count; i++) if (selfNs[i] < 0)
            selfNs[i] = 0;
        int[] ord = new int[count];
        for (int i = 0; i < count; i++) ord[i] = i;
        for (int i = 1; i < count; i++) {
            int k = ord[i];
            long kv = totalNs[k];
            int j = i - 1;
            while (j >= 0 && totalNs[ord[j]] < kv) {
                ord[j + 1] = ord[j];
                j--;
            }
            ord[j + 1] = k;
        }
        boolean hasPrev = false;
        for (int i = 0; i < count; i++) if (prevTotal[i] > 0) {
            hasPrev = true;
            break;
        }
        StringBuilder r = new StringBuilder(8192);
        r.append("========================================\n");
        r.append("  SaltClient Profiler Report\n");
        r.append("========================================\n");
        r.append("Session : ").append(fmtDur(wallSec));
        r.append("  Ticks: ").append(ticks);
        r.append("  Frames: ").append(frames);
        if (ticks > 0)
            r.append("  Avg tick: ").append(fmtNs(wallNs / ticks));
        if (frames > 0) {
            r.append("\nAvg FPS : ");
            appendDouble(r, frames / wallSec, 1);
            r.append("  Avg frame: ").append(fmtNs(wallNs / frames));
        }
        r.append("\nOverhead: ").append(fmtNs(profilerSelfNs)).append(" (");
        appendDouble(r, wallNs > 0 ? profilerSelfNs * 100.0 / wallNs : 0, 3);
        r.append("%)\n\n");
        r.append("--- Instrumentation ---\n");
        int shown = 0, inactive = 0;
        for (int i = 0; i < count; i++) {
            if (!touched[i]) {
                r.append("  UNUSED: ").append(names[i]).append('\n');
                inactive++;
            } else if (calls[i] >= minCalls)
                shown++;
        }
        if (inactive == 0)
            r.append("  All methods active.\n");
        int filtered = count - shown - inactive;
        r.append("Showing ").append(shown).append('/').append(count).append(" methods");
        if (filtered > 0)
            r.append(" (").append(filtered).append(" filtered <").append(minCalls).append(" calls)");
        r.append(".\n\n");
        r.append("--- Categories ---\n");
        String[] uniqueCats = new String[16];
        int ucCount = 0;
        for (int i = 0; i < count; i++) {
            String c = cats[i];
            boolean found = false;
            for (int j = 0; j < ucCount; j++) if (c.equals(uniqueCats[j])) {
                found = true;
                break;
            }
            if (!found)
                uniqueCats[ucCount++] = c;
        }
        for (int c = 0; c < ucCount; c++) {
            long catTotal = 0;
            for (int i = 0; i < count; i++) if (uniqueCats[c].equals(cats[i]))
                catTotal += totalNs[i];
            if (catTotal == 0)
                continue;
            r.append("  ").append(lpad(uniqueCats[c], 12)).append("  ");
            r.append(fmtMs(catTotal)).append("  ");
            appendDouble(r, catTotal * 100.0 / wallNs, 1);
            r.append("%\n");
        }
        r.append('\n');
        r.append("=== TOP 25 METHODS ===\n");
        r.append(lpad("Method", 38)).append(lpad("Total", 9)).append(lpad("Self", 9));
        r.append(lpad("%Sess", 7)).append(lpad("Calls", 10));
        r.append(lpad("Avg", 9)).append(lpad("Min", 9));
        r.append(lpad("Max", 9)).append(lpad("StdDev", 9));
        r.append("  Slow(>100u/>500u/>1m/>5m)\n");
        for (int i = 0; i < 130; i++) r.append('-');
        r.append('\n');
        int topN = 0;
        for (int oi = 0; oi < count; oi++) {
            int idx = ord[oi];
            if (calls[idx] < minCalls)
                continue;
            if (topN >= 25)
                break;
            topN++;
            long tot = totalNs[idx];
            long slf = selfNs[idx];
            double avg = tot / (double) calls[idx];
            double sd = stddev(idx);
            r.append(lpad(names[idx], 38));
            r.append(lpad(fmtMs(tot), 9)).append(lpad(fmtMs(slf), 9));
            r.append(fmtPct(tot * 100.0 / wallNs, 7));
            r.append(lpad(String.valueOf(calls[idx]), 10));
            r.append(lpad(fmtNs(avg), 9)).append(lpad(fmtNs(minNs[idx]), 9));
            r.append(lpad(fmtNs(maxNs[idx]), 9)).append(lpad(fmtNs(sd), 9));
            r.append("  ");
            for (int b = 0; b < 4; b++) {
                r.append(slowBk[idx * 4 + b]).append('/');
            }
            r.setLength(r.length() - 1);
            r.append('\n');
            for (int ei = 0; ei < eSize; ei++) {
                if (eChi[ei] == idx && eTime[ei] > 0 && totalNs[ePar[ei]] > 0) {
                    double pPct = eTime[ei] * 100.0 / totalNs[ePar[ei]];
                    r.append(lpad("", 38)).append("  ");
                    appendDouble(r, pPct, 1);
                    r.append("% of ").append(names[ePar[ei]]).append('\n');
                    break;
                }
            }
            if (hasPrev && prevTotal[idx] > 0) {
                double d = (tot - prevTotal[idx]) * 100.0 / prevTotal[idx];
                r.append(lpad("", 38)).append("  vs prev: ");
                if (d >= 0)
                    r.append('+');
                appendDouble(r, d, 1);
                r.append("%\n");
            }
        }
        r.append('\n');
        if (worstFrameNs > 0) {
            r.append("--- Worst Frame ---\n");
            r.append("  Frame #").append(worstFrameId).append("  ").append(fmtMs(worstFrameNs)).append('\n');
            int[] wo = sortedCopy(worstSlotNs, count, false);
            for (int oi = 0; oi < count; oi++) {
                int idx = wo[oi];
                if (worstSlotNs[idx] == 0)
                    continue;
                r.append("    ").append(lpad(names[idx], 36)).append(fmtMs(worstSlotNs[idx])).append('\n');
            }
            r.append('\n');
        }
        if (eSize > 0) {
            r.append("--- Call Tree ---\n");
            boolean[] hasPar = new boolean[count];
            for (int i = 0; i < eSize; i++) if (eChi[i] < count)
                hasPar[eChi[i]] = true;
            for (int i = 0; i < count; i++) {
                if (touched[i] && !hasPar[i])
                    printTree(r, i, "", true, selfNs);
            }
            r.append('\n');
        }
        r.append("========= HOTSPOTS =========\n");
        int rank = 0;
        for (int oi = 0; oi < count; oi++) {
            int idx = ord[oi];
            if (calls[idx] == 0)
                continue;
            double pct = totalNs[idx] * 100.0 / wallNs;
            if (pct < 0.5)
                continue;
            rank++;
            if (rank > 5)
                break;
            r.append(rank).append(". ").append(names[idx]).append("  ");
            appendDouble(r, pct, 1);
            r.append("%\n");
        }
        if (rank == 0)
            r.append("  No significant hotspots.\n");
        for (int oi = 0; oi < count; oi++) {
            int idx = ord[oi];
            if (calls[idx] < 100000)
                continue;
            double avg = totalNs[idx] / (double) calls[idx];
            double sd = stddev(idx);
            if (sd > avg * 5 && avg > 10000) {
                r.append("\n  >> ").append(names[idx]);
                r.append(" high variance (avg ").append(fmtNs(avg));
                r.append(", stddev ").append(fmtNs(sd)).append(") - GC spikes?\n");
            }
        }
        r.append('\n');
        if (chunksRebuilt + entitiesRendered + particlesRendered > 0) {
            r.append("--- Render Statistics ---\n");
            ac(r, "Chunks rebuilt", chunksRebuilt);
            ac(r, "Chunks rendered", chunksRendered);
            ac(r, "Entities rendered", entitiesRendered);
            ac(r, "Particles rendered", particlesRendered);
            ac(r, "Block models", blockModelsRendered);
            ac(r, "Fluid models", fluidModelsRendered);
            ac(r, "Tile entities", tileEntitiesRendered);
            if (chunksRebuilt > 0 && calls[REBUILD_CHUNK] > 0) {
                r.append("  Avg chunk rebuild: ").append(fmtNs(totalNs[REBUILD_CHUNK] / calls[REBUILD_CHUNK])).append('\n');
            }
            r.append('\n');
        }
        if (collisionQueries > 0) {
            r.append("--- Collision Statistics ---\n");
            ac(r, "Queries", collisionQueries);
            ac(r, "AABBs tested", collisionBoxesTested);
            r.append("  Avg AABBs/query: ");
            appendDouble(r, collisionBoxesTested / (double) collisionQueries, 1);
            r.append("\n  Avg query: ").append(fmtNs(collisionTotalNs / collisionQueries));
            r.append("\n  Worst query: ").append(fmtNs(worstCollisionNs)).append('\n').append('\n');
        }
        if (getLightCalls > 0) {
            r.append("--- Lighting ---\n");
            ac(r, "getLightFor", getLightCalls);
            ac(r, "Sky lookups", skyLookups);
            ac(r, "Block lookups", blockLookups);
            r.append('\n');
        }
        long totA = 0;
        for (int i = 0; i < A_MAX; i++) totA += A_COUNT[i];
        if (totA > 0) {
            r.append("--- Allocations ---\n");
            long totB = 0;
            for (int i = 0; i < A_MAX; i++) {
                if (A_COUNT[i] == 0)
                    continue;
                long b = A_COUNT[i] * A_BYTES[i];
                totB += b;
                r.append("  ").append(lpad(A_NAME[i], 16)).append(lpad(String.valueOf(A_COUNT[i]), 12));
                r.append("  ~").append(fmtBytes(b)).append('\n');
            }
            r.append("  ").append(lpad("TOTAL", 16)).append(lpad(String.valueOf(totA), 12));
            r.append("  ~").append(fmtBytes(totB)).append("\n\n");
        }
        if (evtCount > 0) {
            r.append("--- Events ---\n");
            r.append(lpad("Event", 32)).append(lpad("Post", 8)).append(lpad("Skip", 8));
            r.append(lpad("Time", 10)).append(lpad("AvgLst", 8)).append('\n');
            for (int i = 0; i < evtCount; i++) {
                if (evtPosted[i] == 0)
                    continue;
                r.append(lpad(evtName[i], 32));
                r.append(lpad(String.valueOf(evtPosted[i]), 8));
                r.append(lpad(String.valueOf(evtSkipped[i]), 8));
                r.append(lpad(fmtMs(evtTime[i]), 10));
                double al = evtInvokes[i] > 0 ? evtListeners[i] / (double) evtInvokes[i] : 0;
                appendDouble(r, al, 2);
                r.append(lpad("", 8 - 4)).append('\n');
            }
            r.append('\n');
        }
        if (modCount > 0) {
            r.append("--- Modules ---\n");
            r.append(lpad("Module", 24)).append(lpad("Time", 10)).append(lpad("Calls", 10)).append(lpad("Avg", 10)).append('\n');
            int[] mo = new int[modCount];
            for (int i = 0; i < modCount; i++) mo[i] = i;
            for (int i = 1; i < modCount; i++) {
                int k = mo[i];
                long kv = modTime[k];
                int j = i - 1;
                while (j >= 0 && modTime[mo[j]] < kv) {
                    mo[j + 1] = mo[j];
                    j--;
                }
                mo[j + 1] = k;
            }
            for (int oi = 0; oi < modCount; oi++) {
                int idx = mo[oi];
                if (modTime[idx] == 0)
                    continue;
                double a = modCalls[idx] > 0 ? modTime[idx] / (double) modCalls[idx] : 0;
                r.append(lpad(modName[idx], 24)).append(lpad(fmtMs(modTime[idx]), 10));
                r.append(lpad(String.valueOf(modCalls[idx]), 10)).append(lpad(fmtNs(a), 10)).append('\n');
            }
            r.append('\n');
        }
        r.append("Total=INCLUSIVE  Self=exclusive\n");
        return r.toString();
    }

    private static void record(int id, long t0) {
        long now = System.nanoTime();
        long dt = now - t0;
        if (id < 0 || id >= count)
            return;
        touched[id] = true;
        totalNs[id] += dt;
        calls[id]++;
        if (dt > maxNs[id])
            maxNs[id] = dt;
        if (dt < minNs[id])
            minNs[id] = dt;
        sumSqNs[id] += dt * dt;
        for (int b = 0; b < 4; b++) if (dt > SLOW_TH[b])
            slowBk[id * 4 + b]++;
        if (stkDepth > 0 && stkDepth <= 64) {
            int par = stkId[stkDepth - 1];
            int edge = -1;
            for (int i = 0; i < eSize; i++) {
                if (ePar[i] == par && eChi[i] == id) {
                    edge = i;
                    break;
                }
            }
            if (edge >= 0) {
                eTime[edge] += dt;
                eCnt[edge]++;
            } else if (eSize < MAX_EDGES) {
                ePar[eSize] = par;
                eChi[eSize] = id;
                eTime[eSize] = dt;
                eCnt[eSize] = 1;
                eSize++;
            }
        }
    }

    private static void printTree(StringBuilder r, int slot, String prefix, boolean isLast, long[] selfNs) {
        if (calls[slot] == 0)
            return;
        r.append(prefix);
        r.append(isLast ? " \\-- " : " |-- ");
        r.append(names[slot]).append("  ").append(fmtMs(totalNs[slot]));
        r.append(" (self ").append(fmtMs(selfNs[slot])).append(")\n");
        String childPre = prefix + (isLast ? "     " : " |   ");
        int[] ch = new int[eSize];
        int cc = 0;
        for (int i = 0; i < eSize; i++) {
            if (ePar[i] == slot && calls[eChi[i]] > 0)
                ch[cc++] = eChi[i];
        }
        for (int i = 1; i < cc; i++) {
            int k = ch[i];
            long kv = totalNs[k];
            int j = i - 1;
            while (j >= 0 && totalNs[ch[j]] < kv) {
                ch[j + 1] = ch[j];
                j--;
            }
            ch[j + 1] = k;
        }
        for (int i = 0; i < cc; i++) printTree(r, ch[i], childPre, i == cc - 1, selfNs);
    }

    private static double stddev(int idx) {
        if (calls[idx] < 2)
            return 0;
        double mean = totalNs[idx] / (double) calls[idx];
        double meanSq = sumSqNs[idx] / (double) calls[idx];
        double v = meanSq - mean * mean;
        return v > 0 ? Math.sqrt(v) : 0;
    }

    private static int[] sortedCopy(long[] arr, int len, boolean asc) {
        int[] ord = new int[len];
        for (int i = 0; i < len; i++) ord[i] = i;
        for (int i = 1; i < len; i++) {
            int k = ord[i];
            long kv = arr[k];
            int j = i - 1;
            while (j >= 0 && (asc ? arr[ord[j]] > kv : arr[ord[j]] < kv)) {
                ord[j + 1] = ord[j];
                j--;
            }
            ord[j + 1] = k;
        }
        return ord;
    }

    private static void appendDouble(StringBuilder r, double v, int dec) {
        if (v < 0) {
            r.append('-');
            v = -v;
        }
        long ipart = (long) v;
        r.append(ipart);
        if (dec > 0) {
            r.append('.');
            double frac = v - ipart;
            for (int i = 0; i < dec; i++) {
                frac *= 10;
                r.append((char) ('0' + (int) frac));
                frac -= (int) frac;
            }
        }
    }

    private static String fmtDur(double s) {
        if (s < 60) {
            StringBuilder sb = new StringBuilder(16);
            appendDouble(sb, s, 1);
            sb.append('s');
            return sb.toString();
        }
        return (int) (s / 60) + "m " + (int) (s % 60) + "s";
    }

    private static String fmtMs(long ns) {
        StringBuilder sb = new StringBuilder(16);
        if (ns >= 1_000_000) {
            appendDouble(sb, ns / 1e6, 1);
            sb.append("ms");
        } else {
            sb.append(ns / 1_000);
            sb.append("us");
        }
        return sb.toString();
    }

    private static String fmtNs(long ns) {
        return fmtNs((double) ns);
    }

    private static String fmtNs(double ns) {
        StringBuilder sb = new StringBuilder(16);
        if (ns >= 1e6) {
            appendDouble(sb, ns / 1e6, 1);
            sb.append("ms");
        } else if (ns >= 1e3) {
            appendDouble(sb, ns / 1e3, 1);
            sb.append("us");
        } else {
            sb.append((long) ns);
            sb.append("ns");
        }
        return sb.toString();
    }

    private static String fmtBytes(long b) {
        StringBuilder sb = new StringBuilder(16);
        if (b >= 1_048_576) {
            appendDouble(sb, b / 1_048_576.0, 1);
            sb.append("MB");
        } else if (b >= 1_024) {
            appendDouble(sb, b / 1_024.0, 1);
            sb.append("KB");
        } else {
            sb.append(b);
            sb.append("B");
        }
        return sb.toString();
    }

    private static String lpad(String s, int len) {
        int need = len - s.length();
        if (need <= 0)
            return s.length() > len ? s.substring(0, len) : s;
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < need; i++) sb.append(' ');
        sb.append(s);
        return sb.toString();
    }

    private static String fmtPct(double pct, int width) {
        StringBuilder sb = new StringBuilder(width);
        appendDouble(sb, pct, 1);
        sb.append('%');
        while (sb.length() < width) sb.insert(0, ' ');
        return sb.toString();
    }

    private static void ac(StringBuilder r, String label, long val) {
        r.append("  ").append(lpad(label, 20)).append(val).append('\n');
    }
}
