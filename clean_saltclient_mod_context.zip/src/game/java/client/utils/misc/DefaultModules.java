package client.utils.misc;

import client.module.Module;
import client.module.ModuleManager;

public final class DefaultModules {

    private static final String FLAG_KEY = "default_modules";

    private static final String[] DEFAULT_MODULE_NAMES = { "AutoSprint", "Notifications", "ActiveModuleHud", "CreamyKeys", "GuiBlur", "UnderY0", "ViaBlocks" };

    private DefaultModules() {
    }

    public static boolean hasEnabled() {
        byte[] data = client.config.ConfigIO.read(FLAG_KEY);
        return data != null && data.length > 0 && data[0] != 0;
    }

    public static void markEnabled() {
        client.config.ConfigIO.write(FLAG_KEY, new byte[] { 1 });
    }

    public static void enableDefaults() {
        try {
            for (String name : DEFAULT_MODULE_NAMES) {
                Module mod = ModuleManager.getModuleByName(name);
                if (mod == null)
                    continue;
                if (mod.isToggled())
                    continue;
                Module.setSuppressToggleNotifications(true);
                mod.setToggled(true);
                Module.setSuppressToggleNotifications(false);
            }
        } catch (Exception e) {
        } finally {
            markEnabled();
        }
    }
}
