package client.utils.misc;

import org.json.JSONArray;
import org.json.JSONObject;
import org.teavm.jso.JSBody;
import org.teavm.jso.JSFunctor;
import org.teavm.jso.JSObject;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerList;

public final class DefaultServerFetcher {

    private static final String FETCH_URL = "https://raw.githubusercontent.com/Galactic-Info/info/main/server.json";

    private static final String FLAG_KEY = "server_fetched";

    private DefaultServerFetcher() {
    }

    @JSFunctor
    public interface FetchCallback extends JSObject {

        void onComplete(String data);
    }

    @JSBody(params = { "uri", "callback" }, script = "fetch(uri, { cache: \"default\", mode: \"cors\" })" + ".then(function(res) { return res.text(); })" + ".then(function(text) { callback(text); })" + ".catch(function(err) { console.error(err); callback(null); });")
    private static native void doFetch(String uri, FetchCallback callback);

    public static boolean hasFetched() {
        byte[] data = client.config.ConfigIO.read(FLAG_KEY);
        return data != null && data.length > 0 && data[0] != 0;
    }

    public static void markFetched() {
        client.config.ConfigIO.write(FLAG_KEY, new byte[] { 1 });
    }

    public static void fetchAndAddServer() {
        try {
            doFetch(FETCH_URL, (data) -> {
                try {
                    if (data != null && !data.isEmpty()) {
                        java.util.List<ServerData> servers = parseServerJson(data);
                        if (servers != null) {
                            for (ServerData server : servers) {
                                addServerToList(server);
                            }
                            markFetched();
                        }
                    }
                } catch (Exception e) {
                }
            });
        } catch (Throwable t) {
        }
    }

    private static java.util.List<ServerData> parseServerJson(String json) {
        if (json == null || json.isEmpty())
            return null;
        JSONObject root = new JSONObject(json);
        java.util.List<ServerData> result = new java.util.ArrayList<>();
        if (root.has("servers")) {
            JSONArray servers = JsonUtils.getJsonArray(root, "servers");
            for (int i = 0; i < servers.length(); i++) {
                ServerData server = parseSingleServer(servers.getJSONObject(i));
                if (server != null)
                    result.add(server);
            }
        } else {
            ServerData server = parseSingleServer(root);
            if (server != null)
                result.add(server);
        }
        return result.isEmpty() ? null : result;
    }

    private static ServerData parseSingleServer(JSONObject json) {
        String name = JsonUtils.getJsonString(json, "name", null);
        String address = JsonUtils.getJsonString(json, "address", null);
        if (name == null || address == null)
            return null;
        if (name.isEmpty() || address.isEmpty())
            return null;
        return new ServerData(name, address, false);
    }

    private static void addServerToList(ServerData newServer) {
        try {
            ServerList serverList = ServerList.getServerList();
            if (serverList == null)
                return;
            for (int i = 0; i < serverList.countServers(); i++) {
                ServerData existing = serverList.getServerData(i);
                if (existing.serverName.equals(newServer.serverName) && existing.serverIP.equals(newServer.serverIP)) {
                    return;
                }
            }
            serverList.addServerData(newServer);
            serverList.saveServerList();
        } catch (Exception e) {
        }
    }
}
