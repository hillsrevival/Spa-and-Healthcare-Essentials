package client.utils.misc;

import java.util.TreeMap;

public final class RomanNumeralUtil {

    private static final TreeMap<Integer, String> ROMAN_MAP = new TreeMap<>();

    static {
        ROMAN_MAP.put(1000, "M");
        ROMAN_MAP.put(900, "CM");
        ROMAN_MAP.put(500, "D");
        ROMAN_MAP.put(400, "CD");
        ROMAN_MAP.put(100, "C");
        ROMAN_MAP.put(90, "XC");
        ROMAN_MAP.put(50, "L");
        ROMAN_MAP.put(40, "XL");
        ROMAN_MAP.put(10, "X");
        ROMAN_MAP.put(9, "IX");
        ROMAN_MAP.put(5, "V");
        ROMAN_MAP.put(4, "IV");
        ROMAN_MAP.put(1, "I");
    }

    private RomanNumeralUtil() {
    }

    public static String toRoman(int number) {
        if (number <= 0)
            return "0";
        if (number > 3999)
            return String.valueOf(number);
        int floor = ROMAN_MAP.floorKey(number);
        if (number == floor) {
            return ROMAN_MAP.get(number);
        }
        return ROMAN_MAP.get(floor) + toRoman(number - floor);
    }

    public static int fromRoman(String roman) {
        if (roman == null || roman.isEmpty())
            return -1;
        roman = roman.toUpperCase();
        int result = 0;
        int i = 0;
        while (i < roman.length()) {
            if (i + 1 < roman.length()) {
                String two = roman.substring(i, i + 2);
                if (ROMAN_MAP.containsValue(two)) {
                    for (java.util.Map.Entry<Integer, String> e : ROMAN_MAP.entrySet()) {
                        if (e.getValue().equals(two)) {
                            result += e.getKey();
                            i += 2;
                            break;
                        }
                    }
                    continue;
                }
            }
            char c = roman.charAt(i);
            int val = romanDigitValue(c);
            if (val == -1)
                return -1;
            result += val;
            i++;
        }
        return result;
    }

    private static int romanDigitValue(char digit) {
        switch(digit) {
            case 'I':
                return 1;
            case 'V':
                return 5;
            case 'X':
                return 10;
            case 'L':
                return 50;
            case 'C':
                return 100;
            case 'D':
                return 500;
            case 'M':
                return 1000;
            default:
                return -1;
        }
    }
}
