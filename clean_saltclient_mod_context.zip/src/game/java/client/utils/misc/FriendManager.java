package client.utils.misc;

import java.util.HashSet;
import java.util.Set;
import client.Client;
import client.config.FriendConfig;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class FriendManager {

    private static final Set<String> friends = new HashSet<>();

    private static final FriendConfig friendConfig = new FriendConfig();

    private FriendManager() {
    }

    public static boolean addFriend(String name) {
        if (name == null)
            return false;
        boolean added = friends.add(name.toLowerCase());
        if (added)
            save();
        return added;
    }

    public static boolean removeFriend(String name) {
        if (name == null)
            return false;
        boolean removed = friends.remove(name.toLowerCase());
        if (removed)
            save();
        return removed;
    }

    public static boolean isFriend(String name) {
        if (name == null)
            return false;
        return friends.contains(name.toLowerCase());
    }

    public static boolean isFriend(Entity entity) {
        if (entity == null)
            return false;
        if (entity instanceof EntityPlayer) {
            return isFriend(((EntityPlayer) entity).getName());
        }
        return false;
    }

    public static Set<String> getFriends() {
        return friends;
    }

    public static void clearFriends() {
        if (friends.isEmpty())
            return;
        friends.clear();
        save();
    }

    private static void save() {
        if (Client.INSTANCE.isLoading())
            return;
        friendConfig.save();
    }

    public static void loadFriends() {
        friendConfig.load();
    }
}
