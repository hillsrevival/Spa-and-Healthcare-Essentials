package client.utils.misc;

import java.util.function.Supplier;

public class CachedValue<T> {

    private boolean cached = false;

    private T value;

    private long cachedAt = 0L;

    public void setValue(T value) {
        this.value = value;
        this.cached = true;
        this.cachedAt = System.currentTimeMillis();
    }

    public T getCachedValue() {
        return value;
    }

    public boolean isCached() {
        return cached;
    }

    public T getOrCompute(long ttlMillis, Supplier<T> supplier) {
        if (!cached || System.currentTimeMillis() - cachedAt >= ttlMillis) {
            setValue(supplier.get());
        }
        return value;
    }

    public void clear() {
        this.cached = false;
        this.value = null;
    }
}
