package client.utils.misc;

import client.utils.render.ClientFontRenderer;
import client.utils.render.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class NotificationSystem {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final List<Notification> activeNotifications = new ArrayList<>();

    private static final long DEFAULT_DURATION = 3000;

    private static final long ANIMATION_DURATION = 300;

    private static final int MAX_NOTIFICATIONS = 5;

    private static final int WIDTH = 200;

    private static final int HEIGHT = 30;

    private static final int SPACING = 4;

    private static final int MARGIN = 4;

    private NotificationSystem() {
    }

    public static void show(String message, NotificationType type) {
        show(message, type, DEFAULT_DURATION);
    }

    public static synchronized void show(String message, NotificationType type, long duration) {
        if (message == null || message.isEmpty())
            return;
        while (activeNotifications.size() >= MAX_NOTIFICATIONS) {
            activeNotifications.remove(0);
        }
        activeNotifications.add(new Notification(message, type, duration));
    }

    public static void info(String message) {
        show(message, NotificationType.INFO);
    }

    public static void success(String message) {
        show(message, NotificationType.SUCCESS);
    }

    public static void warning(String message) {
        show(message, NotificationType.WARNING);
    }

    public static void error(String message) {
        show(message, NotificationType.ERROR);
    }

    public static synchronized void showWithAction(String message, NotificationType type, String actionLabel, Runnable action) {
        if (message == null || message.isEmpty())
            return;
        if (actionLabel == null || action == null) {
            show(message, type);
            return;
        }
        while (activeNotifications.size() >= MAX_NOTIFICATIONS) {
            activeNotifications.remove(0);
        }
        Notification n = new Notification(message, type, DEFAULT_DURATION);
        n.actionLabel = actionLabel;
        n.action = action;
        activeNotifications.add(n);
    }

    public static synchronized void render() {
        if (mc.player == null)
            return;
        ScaledResolution sr = new ScaledResolution(mc);
        int screenWidth = sr.getScaledWidth();
        int screenHeight = sr.getScaledHeight();
        long now = System.currentTimeMillis();
        Iterator<Notification> iter = activeNotifications.iterator();
        while (iter.hasNext()) {
            Notification n = iter.next();
            if (now > n.createdAt + n.duration + ANIMATION_DURATION) {
                iter.remove();
            }
        }
        int yOffset = MARGIN;
        for (Notification n : activeNotifications) {
            renderNotification(n, screenWidth, yOffset, now);
            yOffset += HEIGHT + SPACING;
        }
    }

    private static void renderNotification(Notification n, int screenWidth, int yOffset, long now) {
        long elapsed = now - n.createdAt;
        long remaining = n.createdAt + n.duration - now;
        float alpha = 1.0f;
        float xOffset = 0;
        if (elapsed < ANIMATION_DURATION) {
            float progress = (float) elapsed / ANIMATION_DURATION;
            xOffset = (1.0f - easeOutCubic(progress)) * (WIDTH + MARGIN);
        } else if (remaining < ANIMATION_DURATION) {
            float progress = 1.0f - ((float) remaining / ANIMATION_DURATION);
            alpha = 1.0f - easeInCubic(progress);
            xOffset = easeInCubic(progress) * (WIDTH + MARGIN) * 0.3f;
        }
        int x = (int) (screenWidth - WIDTH - MARGIN + xOffset);
        int y = yOffset;
        int bgAlpha = (int) (220 * alpha);
        int bgArgb = (bgAlpha << 24) | 0x1A1A1A;
        RenderUtils.drawRoundedRect2D(x + 2, y + 2, x + WIDTH + 2, y + HEIGHT + 2, 7, 0x30000000);
        RenderUtils.drawRoundedRect2D(x, y, x + WIDTH, y + HEIGHT, 6, bgArgb);
        int barArgb = ((int) (255 * alpha) << 24) | n.type.color;
        RenderUtils.drawRoundedRect2D(x, y, x + 4, y + HEIGHT, 2, barArgb);
        int textArgb = ((int) (255 * alpha) << 24) | 0xFFFFFF;
        String message = n.message;
        if (ClientFontRenderer.getStringWidth(message) > WIDTH - 12) {
            while (ClientFontRenderer.getStringWidth(message + "...") > WIDTH - 12 && message.length() > 0) {
                message = message.substring(0, message.length() - 1);
            }
            message = message + "...";
        }
        ClientFontRenderer.drawStringWithShadow(message, x + 8, y + (HEIGHT - ClientFontRenderer.fontHeight()) / 2 - 4, textArgb);
        if (n.actionLabel != null && !n.actionLabel.isEmpty()) {
            int actionArgb = ((int) (200 * alpha) << 24) | 0xFFAA00;
            ClientFontRenderer.drawStringWithShadow("[" + n.actionLabel + "]", x + 8, y + HEIGHT - 12, actionArgb);
        }
        n.lastRenderX = x;
        n.lastRenderY = y;
        n.hasRenderPos = true;
    }

    public static synchronized boolean handleClick(int mouseX, int mouseY) {
        long now = System.currentTimeMillis();
        for (Notification n : activeNotifications) {
            if (!n.hasRenderPos || n.action == null)
                continue;
            long remaining = n.createdAt + n.duration - now;
            if (remaining <= 0)
                continue;
            if (mouseX >= n.lastRenderX && mouseX <= n.lastRenderX + WIDTH && mouseY >= n.lastRenderY && mouseY <= n.lastRenderY + HEIGHT) {
                try {
                    n.action.run();
                } catch (Exception e) {
                }
                activeNotifications.remove(n);
                return true;
            }
        }
        return false;
    }

    private static float easeOutCubic(float t) {
        return 1.0f - (float) Math.pow(1.0f - t, 3);
    }

    private static float easeInCubic(float t) {
        return t * t * t;
    }

    public enum NotificationType {

        INFO(0x3B82F6), SUCCESS(0x22C55E), WARNING(0xF59E0B), ERROR(0xEF4444);

        public final int color;

        NotificationType(int color) {
            this.color = color;
        }
    }

    private static final class Notification {

        final String message;

        final NotificationType type;

        final long duration;

        final long createdAt;

        Runnable action;

        String actionLabel;

        transient int lastRenderX, lastRenderY;

        transient boolean hasRenderPos;

        Notification(String message, NotificationType type, long duration) {
            this.message = message;
            this.type = type;
            this.duration = duration;
            this.createdAt = System.currentTimeMillis();
        }
    }

    public static synchronized void clear() {
        activeNotifications.clear();
    }
}
