package client.utils.misc;

public class TickTimer {

    private int ticks = 0;

    public TickTimer() {
    }

    public void tick() {
        ticks++;
    }

    public boolean passed(int delay) {
        return ticks >= delay;
    }

    public boolean passedAndReset(int delay) {
        if (ticks >= delay) {
            ticks = 0;
            return true;
        }
        return false;
    }

    public void reset() {
        ticks = 0;
    }

    public int getTicks() {
        return ticks;
    }

    public void setTicks(int ticks) {
        this.ticks = ticks;
    }
}
