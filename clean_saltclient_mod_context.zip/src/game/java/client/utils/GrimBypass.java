package client.utils;

import client.utils.combat.CombatUtils;
import client.utils.movement.RotationUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

public final class GrimBypass {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private GrimBypass() {
    }

    public static final double MAX_REACH = 3.03;

    public static final float MAX_ROT_SPEED = 60.0f;

    public static final float DEFAULT_ROT_SPEED = 30.0f;

    public static final float DEFAULT_FAILSWING_THRESHOLD = 15.0f;

    public static final float DEFAULT_JITTER = 1.0f;

    public static final float DEFAULT_VARIANCE = 0.25f;

    public static final float FAILSWING_MAX_ANGLE = 15.0f;

    public static class Config {

        public float rotationSpeed = DEFAULT_ROT_SPEED;

        public RotationUtils.AimPoint aimPoint = RotationUtils.AimPoint.BODY;

        public float jitter = DEFAULT_JITTER;

        public float variance = DEFAULT_VARIANCE;

        public boolean gcdFix = true;

        public boolean noFailswing = true;

        public double maxReach = MAX_REACH;

        public float failswingThreshold = FAILSWING_MAX_ANGLE;

        public float minCooldown = 0.5f;

        public Config() {
        }

        public Config withRotationSpeed(float speed) {
            this.rotationSpeed = speed;
            return this;
        }

        public Config withAimPoint(RotationUtils.AimPoint aim) {
            this.aimPoint = aim;
            return this;
        }

        public Config withJitter(float jitter) {
            this.jitter = jitter;
            return this;
        }

        public Config withVariance(float variance) {
            this.variance = variance;
            return this;
        }

        public Config withGCD(boolean gcd) {
            this.gcdFix = gcd;
            return this;
        }

        public Config withNoFailswing(boolean noFail) {
            this.noFailswing = noFail;
            return this;
        }

        public Config withMaxReach(double reach) {
            this.maxReach = reach;
            return this;
        }

        public Config withFailswingThreshold(float threshold) {
            this.failswingThreshold = threshold;
            return this;
        }

        public Config withMinCooldown(float cooldown) {
            this.minCooldown = cooldown;
            return this;
        }
    }

    public static class RotationResult {

        public final float yaw;

        public final float pitch;

        public final boolean canAttack;

        public final float angleDiff;

        public RotationResult(float yaw, float pitch, boolean canAttack, float angleDiff) {
            this.yaw = yaw;
            this.pitch = pitch;
            this.canAttack = canAttack;
            this.angleDiff = angleDiff;
        }
    }

    public static RotationResult applyRotation(Entity target, float prevServerYaw, float prevServerPitch, Config config) {
        if (mc.player == null || target == null) {
            return new RotationResult(prevServerYaw, prevServerPitch, false, 999);
        }
        Vec3d aimVec = RotationUtils.getAimPoint(target, config.aimPoint);
        float[] needed = RotationUtils.getNeededRotations(aimVec);
        float speed = config.rotationSpeed;
        if (config.variance > 0.0f) {
            float v = speed * config.variance;
            speed = speed - v + (float) (Math.random() * v * 2.0);
        }
        float[] smoothRots = RotationUtils.smoothRotate(prevServerYaw, prevServerPitch, needed[0], needed[1], speed);
        if (config.jitter > 0) {
            smoothRots = RotationUtils.addJitter(smoothRots[0], smoothRots[1], config.jitter);
        }
        float[] finalRots;
        if (config.gcdFix) {
            finalRots = RotationUtils.fixRotations(prevServerYaw, prevServerPitch, smoothRots[0], smoothRots[1]);
        } else {
            finalRots = smoothRots;
        }
        float angleDiff = RotationUtils.getAngleDifference(finalRots[0], finalRots[1], needed[0], needed[1]);
        boolean canAttack = !config.noFailswing || angleDiff <= config.failswingThreshold;
        if (canAttack && config.maxReach > 0) {
            canAttack = CombatUtils.isReachValid(target, config.maxReach);
        }
        return new RotationResult(finalRots[0], finalRots[1], canAttack, angleDiff);
    }

    public static RotationResult applyRotation(Vec3d target, float prevServerYaw, float prevServerPitch, Config config) {
        if (mc.player == null || target == null) {
            return new RotationResult(prevServerYaw, prevServerPitch, false, 999);
        }
        float[] needed = RotationUtils.getNeededRotations(target);
        float speed = config.rotationSpeed;
        if (config.variance > 0.0f) {
            float v = speed * config.variance;
            speed = speed - v + (float) (Math.random() * v * 2.0);
        }
        float[] smoothRots = RotationUtils.smoothRotate(prevServerYaw, prevServerPitch, needed[0], needed[1], speed);
        if (config.jitter > 0) {
            smoothRots = RotationUtils.addJitter(smoothRots[0], smoothRots[1], config.jitter);
        }
        float[] finalRots;
        if (config.gcdFix) {
            finalRots = RotationUtils.fixRotations(prevServerYaw, prevServerPitch, smoothRots[0], smoothRots[1]);
        } else {
            finalRots = smoothRots;
        }
        float angleDiff = RotationUtils.getAngleDifference(finalRots[0], finalRots[1], needed[0], needed[1]);
        boolean canAttack = !config.noFailswing || angleDiff <= config.failswingThreshold;
        return new RotationResult(finalRots[0], finalRots[1], canAttack, angleDiff);
    }

    public static boolean isReachValid(Entity target, double maxReach) {
        if (mc.player == null || target == null)
            return false;
        return CombatUtils.isReachValid(target, maxReach);
    }

    public static double getReachDistance(Entity target) {
        if (mc.player == null || target == null)
            return Double.MAX_VALUE;
        return CombatUtils.getReachDistance(target);
    }

    public static boolean isWeaponReady(float minPercent) {
        return CombatUtils.isWeaponReady(minPercent);
    }

    public static boolean isRotationOnEntity(float yaw, float pitch, Entity entity, double maxReach) {
        return RotationUtils.isRotationOnEntity(yaw, pitch, entity, maxReach);
    }

    public static float[] correctMovement(float moveForward, float moveStrafe, float oldYaw, float newYaw) {
        return RotationUtils.correctMovement(moveForward, moveStrafe, oldYaw, newYaw);
    }

    public static Config defaultCombatConfig() {
        return new Config().withRotationSpeed(30.0f).withAimPoint(RotationUtils.AimPoint.BODY).withJitter(1.0f).withVariance(0.25f).withGCD(true).withNoFailswing(true).withMaxReach(MAX_REACH).withFailswingThreshold(FAILSWING_MAX_ANGLE).withMinCooldown(0.5f);
    }

    public static Config defaultCrystalConfig() {
        return new Config().withRotationSpeed(35.0f).withAimPoint(RotationUtils.AimPoint.CENTER).withJitter(1.5f).withVariance(0.3f).withGCD(true).withNoFailswing(true).withMaxReach(MAX_REACH).withFailswingThreshold(25.0f).withMinCooldown(0.5f);
    }

    public static Config defaultBlockConfig() {
        return new Config().withRotationSpeed(30.0f).withAimPoint(RotationUtils.AimPoint.CENTER).withJitter(0.5f).withVariance(0.1f).withGCD(true).withNoFailswing(false).withMaxReach(4.5).withMinCooldown(0.0f);
    }
}
