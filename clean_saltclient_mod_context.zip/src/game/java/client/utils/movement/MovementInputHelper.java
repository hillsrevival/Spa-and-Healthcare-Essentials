package client.utils.movement;

import client.utils.misc.KeyBindingHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.MathHelper;

public final class MovementInputHelper {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private MovementInputHelper() {
    }

    public static void applyDirectionalMovement(double targetOffsetX, double targetOffsetZ) {
        if (mc.player == null)
            return;
        if (Math.abs(targetOffsetX) < 0.1 && Math.abs(targetOffsetZ) < 0.1) {
            KeyBindingHelper.releaseMovementKeys();
            return;
        }
        float targetYaw = (float) Math.toDegrees(Math.atan2(targetOffsetZ, targetOffsetX)) - 90.0f;
        float playerYaw = mc.player.rotationYaw;
        float relativeYaw = MathHelper.wrapDegrees(targetYaw - playerYaw);
        float relativeYawRad = (float) Math.toRadians(relativeYaw);
        float forwardFactor = (float) Math.cos(relativeYawRad);
        float strafeFactor = (float) Math.sin(relativeYawRad);
        boolean moveForward = forwardFactor > 0.1f;
        boolean moveBackward = forwardFactor < -0.1f;
        boolean moveRight = strafeFactor > 0.1f;
        boolean moveLeft = strafeFactor < -0.1f;
        MovementUtils.holdForward(moveForward);
        MovementUtils.holdBack(moveBackward);
        MovementUtils.holdLeft(moveLeft);
        MovementUtils.holdRight(moveRight);
    }

    public static void releaseAllInput() {
        MovementUtils.holdForward(false);
        MovementUtils.holdBack(false);
        MovementUtils.holdLeft(false);
        MovementUtils.holdRight(false);
    }

    public static double getMovementStep() {
        if (mc.player == null)
            return 0;
        return Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ);
    }

    public static boolean isMovingToward(double targetX, double targetZ) {
        if (mc.player == null)
            return false;
        double dx = targetX - mc.player.posX;
        double dz = targetZ - mc.player.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist < 0.1)
            return false;
        double dirX = dx / dist;
        double dirZ = dz / dist;
        double dot = mc.player.motionX * dirX + mc.player.motionZ * dirZ;
        return dot > 0;
    }
}
