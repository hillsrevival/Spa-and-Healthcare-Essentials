package client.utils.movement;

import net.minecraft.client.Minecraft;

public final class MovementKeySnapshot {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private boolean forward;

    private boolean back;

    private boolean left;

    private boolean right;

    public void save() {
        forward = mc.gameSettings.keyBindForward.isKeyDown();
        back = mc.gameSettings.keyBindBack.isKeyDown();
        left = mc.gameSettings.keyBindLeft.isKeyDown();
        right = mc.gameSettings.keyBindRight.isKeyDown();
    }

    public boolean savedForward() {
        return forward;
    }

    public boolean savedBack() {
        return back;
    }

    public void clearForward() {
        forward = false;
    }

    public void clearBack() {
        back = false;
    }

    public void clearLeft() {
        left = false;
    }

    public void clearRight() {
        right = false;
    }

    public boolean savedLeft() {
        return left;
    }

    public boolean savedRight() {
        return right;
    }

    public void restore() {
        MovementUtils.holdForward(forward);
        MovementUtils.holdBack(back);
        MovementUtils.holdLeft(left);
        MovementUtils.holdRight(right);
    }
}
