package client.utils.movement;

import net.minecraft.client.Minecraft;

public final class MovementInputLock {

    private static boolean locked = false;

    private static String lockHolder = null;

    private MovementInputLock() {
    }

    public static boolean lock(String holder) {
        if (locked && !holder.equals(lockHolder))
            return false;
        locked = true;
        lockHolder = holder;
        return true;
    }

    public static void unlock(String holder) {
        if (holder.equals(lockHolder)) {
            locked = false;
            lockHolder = null;
        }
    }

    public static boolean isLocked() {
        return locked;
    }

    public static boolean isLockedBy(String holder) {
        return locked && holder.equals(lockHolder);
    }

    public static void forceUnlock() {
        locked = false;
        lockHolder = null;
    }
}
