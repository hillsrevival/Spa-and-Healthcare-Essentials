package client.utils.movement;

import client.event.Event;
import client.event.events.TickEvent;
import net.minecraft.client.Minecraft;

public class PlayerMovementTaskManager {

    private static final PlayerMovementTaskManager INSTANCE = new PlayerMovementTaskManager();

    private MovementTask activeTask;

    private PlayerMovementTaskManager() {
    }

    public static PlayerMovementTaskManager getInstance() {
        return INSTANCE;
    }

    public void submit(MovementTask task) {
        this.activeTask = task;
    }

    public void cancel(MovementTask task) {
        if (this.activeTask != null && this.activeTask.equals(task)) {
            this.activeTask.setCompleted(true);
        }
    }

    public boolean hasActiveTask() {
        return activeTask != null && !activeTask.isCompleted();
    }

    public MovementTask getActiveTask() {
        return activeTask;
    }

    public void onTick(TickEvent event) {
        if (Minecraft.getMinecraft().player == null)
            return;
        if (activeTask == null)
            return;
        if (Minecraft.getMinecraft().currentScreen != null)
            return;
        activeTask.updateCompletion();
        if (activeTask.isCompleted()) {
            if (activeTask.shouldRestoreInputOnCompletion()) {
                MovementInputHelper.releaseAllInput();
            } else {
                MovementUtils.holdForward(false);
                MovementUtils.holdBack(false);
                MovementUtils.holdLeft(false);
                MovementUtils.holdRight(false);
                MovementUtils.setSneaking(false);
            }
            activeTask = null;
            return;
        }
        activeTask.applyMovementInput();
    }
}
