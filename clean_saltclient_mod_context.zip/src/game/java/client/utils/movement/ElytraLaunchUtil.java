package client.utils.movement;

import client.Client;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.MovementInput;

public final class ElytraLaunchUtil {

    private static final int TAKEOFF_IDLE = 0;

    private static final int TAKEOFF_JUMP = 1;

    private static final int TAKEOFF_AWAIT = 2;

    private static boolean glideArmed = false;

    private static int glideTicks = 0;

    private static boolean glideEdgeRelease = false;

    private static int takeoffPhase = TAKEOFF_IDLE;

    private static int takeoffTicks = 0;

    private ElytraLaunchUtil() {
    }

    public static void reset() {
        glideArmed = false;
        glideTicks = 0;
        glideEdgeRelease = false;
        takeoffPhase = TAKEOFF_IDLE;
        takeoffTicks = 0;
    }

    public static boolean tryStartFireworkTakeoff() {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP p = mc.player;
        if (p == null || mc.world == null) {
            return false;
        }
        if (Client.INSTANCE.freecamActive) {
            return false;
        }
        if (takeoffPhase != TAKEOFF_IDLE) {
            return true;
        }
        if (p.isElytraFlying() || !p.onGround || p.isRiding() || p.isSpectator() || p.capabilities.isFlying || p.capabilities.allowFlying || p.isInWater()) {
            return false;
        }
        if (!isFirework(p.getHeldItemMainhand()) || !elytraUsable(p)) {
            return false;
        }
        takeoffPhase = TAKEOFF_JUMP;
        takeoffTicks = 0;
        return true;
    }

    public static void onPlayerTick(EntityPlayerSP p) {
        if (p == null || Client.INSTANCE.freecamActive) {
            return;
        }
        MovementInput input = p.movementInput;
        if (input == null) {
            return;
        }
        tickTakeoff(p, input);
        tickGlide(p, input);
    }

    private static void tickTakeoff(EntityPlayerSP p, MovementInput input) {
        if (takeoffPhase == TAKEOFF_IDLE) {
            return;
        }
        takeoffTicks++;
        if (takeoffTicks > 100 || !elytraUsable(p) || p.capabilities.isFlying || p.isInWater() || !isFirework(p.getHeldItemMainhand())) {
            takeoffPhase = TAKEOFF_IDLE;
            return;
        }
        if (takeoffPhase == TAKEOFF_JUMP) {
            if (p.onGround) {
                input.jump = true;
                if (takeoffTicks > 14) {
                    takeoffPhase = TAKEOFF_IDLE;
                }
                return;
            }
            input.jump = false;
            if (p.isElytraFlying()) {
                takeoffPhase = TAKEOFF_AWAIT;
            } else if (p.motionY < 0.0D) {
                input.jump = true;
                takeoffPhase = TAKEOFF_AWAIT;
            }
            return;
        }
        if (p.isElytraFlying()) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.playerController != null && isFirework(p.getHeldItemMainhand())) {
                mc.playerController.processRightClick(p, p.world, EnumHand.MAIN_HAND);
                p.swingArm(EnumHand.MAIN_HAND);
            }
            takeoffPhase = TAKEOFF_IDLE;
        } else {
            input.jump = false;
            if (p.onGround && takeoffTicks > 20) {
                takeoffPhase = TAKEOFF_IDLE;
            }
        }
    }

    private static void tickGlide(EntityPlayerSP p, MovementInput input) {
        if (glideArmed) {
            glideTicks++;
            if (p.isElytraFlying() || p.onGround || p.capabilities.isFlying || !elytraUsable(p) || p.isInWater() || glideTicks > 60 || takeoffPhase != TAKEOFF_IDLE) {
                glideArmed = false;
                return;
            }
            if (p.motionY < 0.0D) {
                if (input.jump && !glideEdgeRelease) {
                    input.jump = false;
                    glideEdgeRelease = true;
                } else {
                    input.jump = true;
                    glideArmed = false;
                }
            }
            return;
        }
        if (takeoffPhase == TAKEOFF_IDLE && p.onGround && input.jump && elytraUsable(p) && !p.capabilities.isFlying && !p.capabilities.allowFlying && !p.isInWater() && !p.isElytraFlying() && !p.isRiding()) {
            glideArmed = true;
            glideTicks = 0;
            glideEdgeRelease = false;
        }
    }

    private static boolean elytraUsable(EntityPlayerSP p) {
        ItemStack chest = p.getItemStackFromSlot(EntityEquipmentSlot.CHEST);
        return chest != null && !chest.func_190926_b() && chest.getItem() == Items.ELYTRA && ItemElytra.isBroken(chest);
    }

    private static boolean isFirework(ItemStack stack) {
        return stack != null && !stack.func_190926_b() && stack.getItem() == Items.FIREWORKS;
    }
}
