package client.utils.movement;

public final class InertialFloatSmoother {

    private float accumulatedInput;

    private float currentValue;

    private float velocity;

    public float update(float inputDelta, float responseFactor) {
        this.accumulatedInput += inputDelta;
        inputDelta = (this.accumulatedInput - this.currentValue) * responseFactor;
        this.velocity += (inputDelta - this.velocity) * 0.5f;
        if (inputDelta > 0.0f && inputDelta > this.velocity || inputDelta < 0.0f && inputDelta < this.velocity) {
            inputDelta = this.velocity;
        }
        this.currentValue += inputDelta;
        return inputDelta;
    }

    public float getCurrentValue() {
        return currentValue;
    }

    public float getVelocity() {
        return velocity;
    }

    public void reset() {
        accumulatedInput = 0;
        currentValue = 0;
        velocity = 0;
    }

    public void reset(float value) {
        accumulatedInput = value;
        currentValue = value;
        velocity = 0;
    }
}
