package client.utils.movement;

import client.utils.misc.MathUtils;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;

public class RotationUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final Random random = new Random();

    private static boolean fakeRotation = false;

    private static float serverYaw;

    private static float serverPitch;

    private static float savedClientYaw;

    private static float savedClientPitch;

    private static boolean silentActive = false;

    public enum AimPoint {

        CENTER, HEAD, BODY, NEAREST, RANDOM
    }

    public enum RotationMode {

        SMOOTH, LAZYFLICK, LOCK
    }

    public static Vec3d getEyesPos() {
        if (mc.player == null)
            return new Vec3d(0, 0, 0);
        return new Vec3d(mc.player.posX, mc.player.posY + (double) mc.player.getEyeHeight(), mc.player.posZ);
    }

    public static Vec3d getClientLookVec() {
        if (mc.player == null)
            return new Vec3d(0, 0, 0);
        float f = (float) (Math.cos(-mc.player.rotationYaw * 0.017453292F - (float) Math.PI));
        float f1 = (float) (Math.sin(-mc.player.rotationYaw * 0.017453292F - (float) Math.PI));
        float f2 = (float) (-Math.cos(-mc.player.rotationPitch * 0.017453292F));
        float f3 = (float) (Math.sin(-mc.player.rotationPitch * 0.017453292F));
        return new Vec3d(f1 * f2, f3, f * f2);
    }

    public static Vec3d getServerLookVec() {
        float f = (float) (Math.cos(-serverYaw * 0.017453292F - (float) Math.PI));
        float f1 = (float) (Math.sin(-serverYaw * 0.017453292F - (float) Math.PI));
        float f2 = (float) (-Math.cos(-serverPitch * 0.017453292F));
        float f3 = (float) (Math.sin(-serverPitch * 0.017453292F));
        return new Vec3d(f1 * f2, f3, f * f2);
    }

    public static Vec3d getLookVec(float yaw, float pitch) {
        float f = (float) (Math.cos(-yaw * 0.017453292F - (float) Math.PI));
        float f1 = (float) (Math.sin(-yaw * 0.017453292F - (float) Math.PI));
        float f2 = (float) (-Math.cos(-pitch * 0.017453292F));
        float f3 = (float) (Math.sin(-pitch * 0.017453292F));
        return new Vec3d(f1 * f2, f3, f * f2);
    }

    public static float getGCD() {
        float sensitivity = mc.gameSettings.mouseSensitivity;
        float f = sensitivity * 0.6f + 0.2f;
        return f * f * f * 1.2f;
    }

    public static float fixRotation(float prevRotation, float rotation) {
        float gcd = getGCD();
        float delta = wrapDegrees(rotation - prevRotation);
        float correctedDelta = Math.round(delta / gcd) * gcd;
        return prevRotation + correctedDelta;
    }

    public static float[] fixRotations(float prevYaw, float prevPitch, float yaw, float pitch) {
        return new float[] { fixRotation(prevYaw, yaw), fixRotation(prevPitch, pitch) };
    }

    public static float[] fixRotations(float yaw, float pitch) {
        if (mc.player == null)
            return new float[] { yaw, pitch };
        return fixRotations(mc.player.prevRotationYaw, mc.player.prevRotationPitch, yaw, pitch);
    }

    public static Vec3d getAimPoint(Entity entity, AimPoint mode) {
        AxisAlignedBB box = entity.getEntityBoundingBox();
        double x, y, z;
        switch(mode) {
            case HEAD:
                x = box.minX + (box.maxX - box.minX) * 0.5;
                y = box.maxY - 0.1;
                z = box.minZ + (box.maxZ - box.minZ) * 0.5;
                break;
            case BODY:
                x = box.minX + (box.maxX - box.minX) * 0.5;
                y = box.minY + (box.maxY - box.minY) * 0.6;
                z = box.minZ + (box.maxZ - box.minZ) * 0.5;
                break;
            case NEAREST:
                Vec3d eyesPos = getEyesPos();
                Vec3d lookVec = getServerLookVec();
                if (lookVec.lengthVector() < 0.001)
                    lookVec = getClientLookVec();
                double margin = 0.1;
                double nearX = clamp(eyesPos.xCoord, box.minX, box.maxX);
                double nearY = clamp(eyesPos.yCoord, box.minY, box.maxY);
                double nearZ = clamp(eyesPos.zCoord, box.minZ, box.maxZ);
                double cx = box.minX + (box.maxX - box.minX) * 0.5;
                double cy = box.minY + (box.maxY - box.minY) * 0.4;
                double cz = box.minZ + (box.maxZ - box.minZ) * 0.5;
                x = nearX + (cx - nearX) * margin;
                y = nearY + (cy - nearY) * margin;
                z = nearZ + (cz - nearZ) * margin;
                break;
            case RANDOM:
                x = box.minX + random.nextDouble() * (box.maxX - box.minX);
                y = box.minY + random.nextDouble() * (box.maxY - box.minY);
                z = box.minZ + random.nextDouble() * (box.maxZ - box.minZ);
                break;
            default:
                x = box.getCenter().xCoord;
                y = box.getCenter().yCoord;
                z = box.getCenter().zCoord;
                break;
        }
        return new Vec3d(x, y, z);
    }

    public static float[] getNeededRotations(Vec3d vec) {
        return getNeededRotations(vec, getEyesPos());
    }

    public static float[] getNeededRotations(Vec3d vec, Vec3d eyesPos) {
        double diffX = vec.xCoord - eyesPos.xCoord;
        double diffY = vec.yCoord - eyesPos.yCoord;
        double diffZ = vec.zCoord - eyesPos.zCoord;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90F;
        float pitch = (float) -Math.toDegrees(Math.atan2(diffY, diffXZ));
        return new float[] { wrapDegrees(yaw), wrapDegrees(pitch) };
    }

    private static float[] getNeededRotations2(Vec3d vec) {
        Vec3d eyesPos = getEyesPos();
        double diffX = vec.xCoord - eyesPos.xCoord;
        double diffY = vec.yCoord - eyesPos.yCoord;
        double diffZ = vec.zCoord - eyesPos.zCoord;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90F;
        float pitch = (float) -Math.toDegrees(Math.atan2(diffY, diffXZ));
        return new float[] { mc.player.rotationYaw + wrapDegrees(yaw - mc.player.rotationYaw), mc.player.rotationPitch + wrapDegrees(pitch - mc.player.rotationPitch) };
    }

    public static double getAngleToLastReportedLookVec(Vec3d vec) {
        float[] needed = getNeededRotations(vec);
        float lastReportedYaw = wrapDegrees(serverYaw);
        float lastReportedPitch = wrapDegrees(serverPitch);
        float diffYaw = wrapDegrees(lastReportedYaw - needed[0]);
        float diffPitch = wrapDegrees(lastReportedPitch - needed[1]);
        return Math.sqrt(diffYaw * diffYaw + diffPitch * diffPitch);
    }

    public static float getAngleToClientRotation(Vec3d vec) {
        float[] needed = getNeededRotations(vec);
        float diffYaw = wrapDegrees(mc.player.rotationYaw) - needed[0];
        float diffPitch = wrapDegrees(mc.player.rotationPitch) - needed[1];
        float angle = (float) Math.sqrt(diffYaw * diffYaw + diffPitch * diffPitch);
        return angle;
    }

    public static float getHorizontalAngleToClientRotation(Vec3d vec) {
        float[] needed = getNeededRotations(vec);
        float angle = wrapDegrees(mc.player.rotationYaw) - needed[0];
        return angle;
    }

    public static float getAngleToServerRotation(Vec3d vec) {
        float[] needed = getNeededRotations(vec);
        float diffYaw = wrapDegrees(serverYaw - needed[0]);
        float diffPitch = wrapDegrees(serverPitch - needed[1]);
        float angle = (float) Math.sqrt(diffYaw * diffYaw + diffPitch * diffPitch);
        return angle;
    }

    public static float getAngleDifference(float yaw1, float pitch1, float yaw2, float pitch2) {
        float diffYaw = wrapDegrees(yaw1 - yaw2);
        float diffPitch = wrapDegrees(pitch1 - pitch2);
        return (float) Math.sqrt(diffYaw * diffYaw + diffPitch * diffPitch);
    }

    public static float[] smoothRotate(float currentYaw, float currentPitch, float targetYaw, float targetPitch, float speed) {
        float deltaYaw = wrapDegrees(targetYaw - currentYaw);
        float deltaPitch = targetPitch - currentPitch;
        float totalDelta = Math.abs(deltaYaw) + Math.abs(deltaPitch);
        if (totalDelta > speed) {
            float scale = speed / totalDelta;
            deltaYaw *= scale;
            deltaPitch *= scale;
        }
        float newPitch = clamp(currentPitch + deltaPitch, -90, 90);
        return new float[] { wrapDegrees(currentYaw + deltaYaw), newPitch };
    }

    public static float[] smoothRotateL2(float currentYaw, float currentPitch, float targetYaw, float targetPitch, float speed) {
        float deltaYaw = wrapDegrees(targetYaw - currentYaw);
        float deltaPitch = targetPitch - currentPitch;
        double magnitude = Math.sqrt((double) deltaYaw * deltaYaw + (double) deltaPitch * deltaPitch);
        if (magnitude > speed) {
            float scale = (float) (speed / magnitude);
            deltaYaw *= scale;
            deltaPitch *= scale;
        }
        float newPitch = clamp(currentPitch + deltaPitch, -90, 90);
        return new float[] { wrapDegrees(currentYaw + deltaYaw), newPitch };
    }

    public static float[] smoothRotateSplit(float currentYaw, float currentPitch, float targetYaw, float targetPitch, float yawSpeed, float pitchSpeed) {
        float deltaYaw = wrapDegrees(targetYaw - currentYaw);
        float deltaPitch = targetPitch - currentPitch;
        if (deltaYaw > yawSpeed)
            deltaYaw = yawSpeed;
        else if (deltaYaw < -yawSpeed)
            deltaYaw = -yawSpeed;
        if (deltaPitch > pitchSpeed)
            deltaPitch = pitchSpeed;
        else if (deltaPitch < -pitchSpeed)
            deltaPitch = -pitchSpeed;
        float newPitch = clamp(currentPitch + deltaPitch, -90, 90);
        return new float[] { wrapDegrees(currentYaw + deltaYaw), newPitch };
    }

    private static final InertialFloatSmoother yawInertia = new InertialFloatSmoother();

    private static final InertialFloatSmoother pitchInertia = new InertialFloatSmoother();

    public static float[] smoothRotateInertial(float currentYaw, float currentPitch, float targetYaw, float targetPitch, float responseFactor) {
        float deltaYaw = wrapDegrees(targetYaw - currentYaw);
        float deltaPitch = targetPitch - currentPitch;
        if (deltaPitch > 90)
            deltaPitch = 90;
        if (deltaPitch < -90)
            deltaPitch = -90;
        float smoothedYaw = yawInertia.update(deltaYaw, responseFactor);
        float smoothedPitch = pitchInertia.update(deltaPitch, responseFactor);
        float newYaw = wrapDegrees(currentYaw + smoothedYaw);
        float newPitch = clamp(currentPitch + smoothedPitch, -90, 90);
        return new float[] { newYaw, newPitch };
    }

    public static void resetInertialSmoothing() {
        yawInertia.reset();
        pitchInertia.reset();
    }

    public static float[] lazyFlick(float currentYaw, float currentPitch, float targetYaw, float targetPitch, float initialSpeed, float completionSpeed) {
        float totalDelta = getAngleDifference(currentYaw, currentPitch, targetYaw, targetPitch);
        if (totalDelta < 2.0f) {
            return new float[] { targetYaw, targetPitch };
        }
        if (totalDelta > initialSpeed * 1.5f) {
            float fastSpeed = initialSpeed;
            return smoothRotate(currentYaw, currentPitch, targetYaw, targetPitch, fastSpeed);
        } else {
            return smoothRotate(currentYaw, currentPitch, targetYaw, targetPitch, completionSpeed);
        }
    }

    public static float[] addJitter(float yaw, float pitch, float amount) {
        float jitterYaw = yaw + (random.nextFloat() - 0.5f) * amount;
        float jitterPitch = pitch + (random.nextFloat() - 0.5f) * amount;
        jitterPitch = clamp(jitterPitch, -90, 90);
        return new float[] { jitterYaw, jitterPitch };
    }

    public static float limitAngleChange(float current, float intended, float maxChange) {
        float change = wrapDegrees(intended - current);
        change = clamp(change, -maxChange, maxChange);
        return wrapDegrees(current + change);
    }

    public static boolean isRotationOnEntity(float yaw, float pitch, Entity entity, double maxReach) {
        Vec3d eyesPos = getEyesPos();
        Vec3d lookVec = getLookVec(yaw, pitch);
        Vec3d endPos = eyesPos.addVector(lookVec.xCoord * maxReach, lookVec.yCoord * maxReach, lookVec.zCoord * maxReach);
        return entity.getEntityBoundingBox().calculateIntercept(eyesPos, endPos) != null;
    }

    public static boolean faceVectorPacket(Vec3d vec) {
        if (mc.player == null)
            return false;
        if (!silentActive) {
            savedClientYaw = mc.player.rotationYaw;
            savedClientPitch = mc.player.rotationPitch;
            silentActive = true;
        }
        fakeRotation = true;
        float[] rotations = getNeededRotations(vec);
        serverYaw = limitAngleChange(serverYaw, rotations[0], 30);
        serverPitch = rotations[1];
        mc.player.rotationYaw = serverYaw;
        mc.player.rotationPitch = serverPitch;
        return Math.abs(wrapDegrees(serverYaw - rotations[0])) < 1F;
    }

    public static void faceVectorPacketInstant(Vec3d vec) {
        if (mc.player == null)
            return;
        if (!silentActive) {
            savedClientYaw = mc.player.rotationYaw;
            savedClientPitch = mc.player.rotationPitch;
            silentActive = true;
        }
        float[] rotations = getNeededRotations(vec);
        serverYaw = rotations[0];
        serverPitch = rotations[1];
        mc.player.rotationYaw = serverYaw;
        mc.player.rotationPitch = serverPitch;
    }

    public static boolean faceVectorPacketGCD(Vec3d vec) {
        if (mc.player == null)
            return false;
        if (!silentActive) {
            savedClientYaw = mc.player.rotationYaw;
            savedClientPitch = mc.player.rotationPitch;
            silentActive = true;
        }
        fakeRotation = true;
        float[] rotations = getNeededRotations(vec);
        float targetYaw = limitAngleChange(serverYaw, rotations[0], 30);
        float targetPitch = rotations[1];
        float[] gcdFixed = fixRotations(serverYaw, serverPitch, targetYaw, targetPitch);
        serverYaw = gcdFixed[0];
        serverPitch = gcdFixed[1];
        mc.player.rotationYaw = serverYaw;
        mc.player.rotationPitch = serverPitch;
        return Math.abs(wrapDegrees(serverYaw - rotations[0])) < 1F;
    }

    public static boolean faceVectorClient(Vec3d vec) {
        float[] rotations = getNeededRotations(vec);
        float oldYaw = mc.player.prevRotationYaw;
        float oldPitch = mc.player.prevRotationPitch;
        mc.player.rotationYaw = limitAngleChange(oldYaw, rotations[0], 30);
        mc.player.rotationPitch = rotations[1];
        return Math.abs(wrapDegrees(oldYaw - rotations[0])) + Math.abs(oldPitch - rotations[1]) < 1F;
    }

    public static boolean faceEntityPacket(Entity entity, AimPoint aim) {
        Vec3d point = getAimPoint(entity, aim);
        return faceVectorPacket(point);
    }

    public static boolean faceEntityPacket(Entity entity) {
        Vec3d eyesPos = getEyesPos();
        Vec3d lookVec = getServerLookVec();
        AxisAlignedBB bb = entity.getEntityBoundingBox();
        if (faceVectorPacket(bb.getCenter()))
            return true;
        return bb.calculateIntercept(eyesPos, eyesPos.add(lookVec.scale(6))) != null;
    }

    public static boolean faceEntityClient(Entity entity) {
        Vec3d eyesPos = getEyesPos();
        Vec3d lookVec = getServerLookVec();
        AxisAlignedBB bb = entity.getEntityBoundingBox();
        if (faceVectorClient(bb.getCenter()))
            return true;
        return bb.calculateIntercept(eyesPos, eyesPos.add(lookVec.scale(6))) != null;
    }

    public static boolean faceVectorForWalking(Vec3d vec) {
        float[] rotations = getNeededRotations(vec);
        float oldYaw = mc.player.prevRotationYaw;
        mc.player.rotationYaw = limitAngleChange(oldYaw, rotations[0], 30);
        mc.player.rotationPitch = 0;
        return Math.abs(oldYaw - rotations[0]) < 1F;
    }

    public static float getAngleToEntity(Entity entity) {
        if (mc.player == null || entity == null)
            return 0;
        Vec3d look = mc.player.getLookVec();
        double diffX = entity.posX - mc.player.posX;
        double diffY = entity.posY - (mc.player.posY + mc.player.getEyeHeight());
        double diffZ = entity.posZ - mc.player.posZ;
        double len = Math.sqrt(diffX * diffX + diffY * diffY + diffZ * diffZ);
        if (len < 1.0E-4)
            return 0;
        double dot = (look.xCoord * diffX + look.yCoord * diffY + look.zCoord * diffZ) / len;
        if (dot > 1.0)
            dot = 1.0;
        if (dot < -1.0)
            dot = -1.0;
        return (float) Math.toDegrees(Math.acos(dot));
    }

    public static float[] correctMovement(float moveForward, float moveStrafe, float oldYaw, float newYaw) {
        float yawDiff = wrapDegrees(newYaw - oldYaw);
        double rad = yawDiff * Math.PI / 180.0;
        double sin = Math.sin(rad);
        double cos = Math.cos(rad);
        float newForward = (float) (moveForward * cos - moveStrafe * sin);
        float newStrafe = (float) (moveForward * sin + moveStrafe * cos);
        return new float[] { newForward, newStrafe };
    }

    public static void restoreClientRotation() {
        if (silentActive && mc.player != null) {
            mc.player.rotationYaw = savedClientYaw;
            mc.player.rotationPitch = savedClientPitch;
            silentActive = false;
        }
    }

    public static void updateServerRotation() {
        if (mc.player == null)
            return;
        if (fakeRotation) {
            fakeRotation = false;
            return;
        }
        serverYaw = limitAngleChange(serverYaw, mc.player.rotationYaw, 30);
        serverPitch = mc.player.rotationPitch;
    }

    public static float getServerYaw() {
        return serverYaw;
    }

    public static float getServerPitch() {
        return serverPitch;
    }

    public static void resetRotation() {
        fakeRotation = false;
        silentActive = false;
        if (mc.player != null) {
            serverYaw = mc.player.rotationYaw;
            serverPitch = mc.player.rotationPitch;
        }
    }

    public static float wrapDegrees(float value) {
        return MathUtils.wrapDegrees(value);
    }

    public static float clamp(float value, float min, float max) {
        return MathUtils.clamp(value, min, max);
    }

    public static double clamp(double value, double min, double max) {
        return MathUtils.clamp(value, min, max);
    }
}
