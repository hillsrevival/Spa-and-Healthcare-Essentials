package client.utils.movement;

import net.minecraft.client.Minecraft;

public abstract class MovementTask {

    protected double remainingX;

    protected double remainingZ;

    private boolean completed;

    private boolean restoreInputOnCompletion = true;

    private double completionTolerance = 0.2;

    private boolean ignoreX;

    private boolean ignoreZ;

    private boolean sneakNearTarget;

    public abstract boolean hasReachedTarget();

    public void applyMovementInput() {
        if (Minecraft.getMinecraft().player == null)
            return;
        if (Minecraft.getMinecraft().currentScreen != null)
            return;
        if (remainingX == 0.0 && remainingZ == 0.0)
            return;
        if (sneakNearTarget && Math.abs(remainingX) < 2.0 && Math.abs(remainingZ) < 2.0) {
            MovementUtils.setSneaking(true);
        } else {
            MovementUtils.setSneaking(false);
        }
        MovementInputHelper.applyDirectionalMovement(remainingX, remainingZ);
    }

    public void updateCompletion() {
        if (Minecraft.getMinecraft().player == null)
            return;
        if (Minecraft.getMinecraft().currentScreen != null)
            return;
        if (hasReachedTarget()) {
            completed = true;
        }
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public boolean shouldRestoreInputOnCompletion() {
        return restoreInputOnCompletion;
    }

    public void setRestoreInputOnCompletion(boolean restore) {
        this.restoreInputOnCompletion = restore;
    }

    public double getCompletionTolerance() {
        return completionTolerance;
    }

    public void setCompletionTolerance(double tolerance) {
        this.completionTolerance = tolerance;
    }

    public boolean shouldIgnoreX() {
        return ignoreX;
    }

    public void setIgnoreX(boolean ignoreX) {
        this.ignoreX = ignoreX;
    }

    public boolean shouldIgnoreZ() {
        return ignoreZ;
    }

    public void setIgnoreZ(boolean ignoreZ) {
        this.ignoreZ = ignoreZ;
    }

    public boolean shouldSneakNearTarget() {
        return sneakNearTarget;
    }

    public void setSneakNearTarget(boolean sneak) {
        this.sneakNearTarget = sneak;
    }
}
