package client.utils.movement;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.MobEffects;

public final class MovementUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private MovementUtils() {
    }

    public static void setSprinting(boolean sprinting) {
        if (mc.player == null)
            return;
        if (sprinting && !canSprint())
            return;
        mc.player.setSprinting(sprinting);
    }

    public static boolean isSprinting() {
        return mc.player != null && mc.player.isSprinting();
    }

    public static boolean canSprint() {
        if (mc.player == null)
            return false;
        return mc.player.movementInput.field_192832_b >= 0.8F && !mc.player.isCollidedHorizontally && !mc.player.isSneaking() && (mc.player.getFoodStats().getFoodLevel() > 6 || mc.player.capabilities.allowFlying) && !mc.player.isHandActive() && !mc.player.isPotionActive(MobEffects.BLINDNESS);
    }

    public static void stopSprint() {
        if (mc.player == null)
            return;
        mc.player.setSprinting(false);
    }

    public static void reSprint() {
        if (mc.player == null)
            return;
        if (canSprint()) {
            mc.player.setSprinting(true);
        }
    }

    public static void setSneaking(boolean sneaking) {
        if (mc.player == null)
            return;
        mc.player.setSneaking(sneaking);
    }

    public static boolean isSneaking() {
        return mc.player != null && mc.player.isSneaking();
    }

    public static void scaleHorizontal(double factor) {
        if (mc.player == null)
            return;
        mc.player.motionX *= factor;
        mc.player.motionZ *= factor;
    }

    public static void scaleVertical(double factor) {
        if (mc.player == null)
            return;
        mc.player.motionY *= factor;
    }

    public static void setMotion(double x, double y, double z) {
        if (mc.player == null)
            return;
        mc.player.motionX = x;
        mc.player.motionY = y;
        mc.player.motionZ = z;
    }

    public static void zeroHorizontal() {
        if (mc.player == null)
            return;
        mc.player.motionX = 0;
        mc.player.motionZ = 0;
    }

    public static void applyKnockbackReduction(double hReduce, double vReduce) {
        if (mc.player == null)
            return;
        if (mc.player.hurtTime <= 0)
            return;
        if (hReduce > 0) {
            scaleHorizontal(1.0 - hReduce);
        }
        if (vReduce > 0 && mc.player.hurtTime == mc.player.maxHurtTime) {
            scaleVertical(1.0 - vReduce);
        }
    }

    public static void holdForward(boolean state) {
        if (mc.gameSettings == null)
            return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), state);
    }

    public static void holdBack(boolean state) {
        if (mc.gameSettings == null)
            return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), state);
    }

    public static void holdLeft(boolean state) {
        if (mc.gameSettings == null)
            return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), state);
    }

    public static void holdRight(boolean state) {
        if (mc.gameSettings == null)
            return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), state);
    }

    public static void holdAttack(boolean state) {
        if (mc.gameSettings == null)
            return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), state);
    }

    public static void holdUseItem(boolean state) {
        if (mc.gameSettings == null)
            return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), state);
    }

    public static void holdSneak(boolean state) {
        if (mc.gameSettings == null)
            return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), state);
    }

    public static void holdJump(boolean state) {
        if (mc.gameSettings == null)
            return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), state);
    }

    public static boolean isMoving() {
        if (mc.player == null)
            return false;
        return mc.player.moveForward != 0.0f || mc.player.moveStrafing != 0.0f;
    }

    public static boolean isOnGround() {
        return mc.player != null && mc.player.onGround;
    }

    public static boolean isAirBorne() {
        return mc.player != null && mc.player.isAirBorne;
    }

    public static float getMovementYaw() {
        if (mc.player == null)
            return 0;
        if (!isMoving())
            return mc.player.rotationYaw;
        float strafe = mc.player.moveStrafing;
        float forward = mc.player.moveForward;
        float yaw = (float) Math.toDegrees(Math.atan2(-strafe, forward)) + mc.player.rotationYaw;
        return RotationUtils.wrapDegrees(yaw);
    }

    public static double getHorizontalSpeed() {
        if (mc.player == null)
            return 0;
        double dx = mc.player.motionX;
        double dz = mc.player.motionZ;
        return Math.sqrt(dx * dx + dz * dz);
    }
}
