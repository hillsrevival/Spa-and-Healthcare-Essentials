package client.utils.movement;

import net.minecraft.client.Minecraft;

public class TargetPositionMovementTask extends MovementTask {

    private double targetX;

    private double targetZ;

    public TargetPositionMovementTask(double targetX, double targetZ) {
        this.targetX = targetX;
        this.targetZ = targetZ;
    }

    public void setTarget(double targetX, double targetZ) {
        this.targetX = targetX;
        this.targetZ = targetZ;
    }

    public double getTargetX() {
        return targetX;
    }

    public double getTargetZ() {
        return targetZ;
    }

    @Override
    public boolean hasReachedTarget() {
        if (Minecraft.getMinecraft().player == null)
            return false;
        this.remainingX = shouldIgnoreX() ? 0.0 : targetX - Minecraft.getMinecraft().player.posX;
        this.remainingZ = shouldIgnoreZ() ? 0.0 : targetZ - Minecraft.getMinecraft().player.posZ;
        double tolerance = shouldSneakNearTarget() ? 0.1 : getCompletionTolerance();
        return Math.abs(remainingX) <= tolerance && Math.abs(remainingZ) <= tolerance;
    }
}
