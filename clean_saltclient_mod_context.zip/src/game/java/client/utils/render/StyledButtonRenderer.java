package client.utils.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import client.gui.clickgui.AnimationUtil;
import client.gui.clickgui.ClickGUI;

public final class StyledButtonRenderer {

    private static final int BTN_RADIUS = 4;

    private static final float PROXIMITY_DIST = 40.0f;

    private StyledButtonRenderer() {
    }

    public static void drawButton(Minecraft mc, GuiButton btn, float[] hoverProgress, int idx, int mouseX, int mouseY, float alpha) {
        if (!btn.visible) {
            return;
        }
        boolean hovered = mouseX >= btn.xPosition && mouseX <= btn.xPosition + btn.width && mouseY >= btn.yPosition && mouseY <= btn.yPosition + btn.getHeight() && btn.enabled;
        int bcx = btn.xPosition + btn.width / 2;
        int bcy = btn.yPosition + btn.getHeight() / 2;
        float dx = mouseX - bcx;
        float dy = mouseY - bcy;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);
        float proximity = hovered ? 1.0f : Math.max(0.0f, 1.0f - dist / PROXIMITY_DIST);
        if (!btn.enabled) {
            proximity = 0.0f;
        }
        float hoverTarget = proximity;
        if (hoverProgress != null && idx < hoverProgress.length) {
            hoverProgress[idx] = AnimationUtil.lerp(hoverProgress[idx], hoverTarget, 0.18f);
            if (Math.abs(hoverProgress[idx] - hoverTarget) < 0.01f) {
                hoverProgress[idx] = hoverTarget;
            }
        }
        float hp = (hoverProgress != null && idx < hoverProgress.length) ? hoverProgress[idx] : 0.0f;
        int bx = btn.xPosition;
        int by = btn.yPosition;
        int bw = btn.width;
        int bh = btn.getHeight();
        int accentColor = ClickGUI.getAccent();
        int accentBright = ClickGUI.getAccentBright();
        String label = btn.displayString;
        int bgColor = AnimationUtil.lerpColor(ClickGUI.BG_PANEL, ClickGUI.BG_HOVER, hp);
        int bgWithAlpha = ((int) (alpha * 255) << 24) | (bgColor & 0x00FFFFFF);
        RenderUtils.drawRoundedRect2D(bx, by, bx + bw, by + bh, BTN_RADIUS, bgWithAlpha);
        int baseText = btn.enabled ? ClickGUI.TEXT_NORMAL : ClickGUI.TEXT_DIM;
        int textColor = AnimationUtil.lerpColor(baseText, accentBright, hp);
        int textWithAlpha = ((int) (alpha * 255) << 24) | (textColor & 0x00FFFFFF);
        int labelW = mc.fontRendererObj.getStringWidth(label);
        mc.fontRendererObj.drawStringWithShadow(label, bx + (bw - labelW) / 2, by + (bh - 8) / 2, textWithAlpha);
        if (proximity > 0.1f && !hovered && btn.enabled) {
            int proxAlpha = (int) (30 * proximity * alpha);
            int proxColor = (proxAlpha << 24) | (accentColor & 0x00FFFFFF);
            RenderUtils.drawRoundedStroke2D(bx - 1, by - 1, bx + bw + 1, by + bh + 1, BTN_RADIUS + 1, 1.0f, proxColor);
        }
    }
}
