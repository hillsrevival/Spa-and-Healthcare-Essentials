package client.utils.render;

public final class StencilClipUtil {

    private StencilClipUtil() {
    }

    public static void pushClip(int x1, int y1, int x2, int y2) {
    }

    public static void popClip() {
    }

    public static int getDepth() {
        return 0;
    }

    public static boolean isSupported() {
        return false;
    }
}
