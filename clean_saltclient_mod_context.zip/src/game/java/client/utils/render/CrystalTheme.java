package client.utils.render;

/**
 * SaltClient crystal-blue palette. All colors are ARGB ints.
 */
public final class CrystalTheme {

    public static final int BG_DEEP = 0xF0060C18;
    public static final int BG_PANEL = 0xE60B1A2E;
    public static final int BG_PANEL_ALT = 0xE6102542;
    public static final int BG_HOVER = 0xE6173A63;
    public static final int BORDER = 0xFF2A6C99;
    public static final int BORDER_SOFT = 0x602A6C99;

    public static final int ACCENT = 0xFF4FC3F7;
    public static final int ACCENT_BRIGHT = 0xFF9BE7FF;
    public static final int ACCENT_DIM = 0xFF1E6F9F;
    public static final int ACCENT_DEEP = 0xFF0E3F66;

    public static final int TEXT = 0xFFE6F6FF;
    public static final int TEXT_DIM = 0xFF8FB4CC;

    public static final int GOOD = 0xFF5CF2C0;
    public static final int WARN = 0xFFFFD166;
    public static final int BAD = 0xFFFF6B8A;

    private CrystalTheme() {
    }

    public static int withAlpha(int color, int alpha) {
        return ((alpha & 0xFF) << 24) | (color & 0x00FFFFFF);
    }

    public static int lerp(int a, int b, float t) {
        if (t < 0f)
            t = 0f;
        if (t > 1f)
            t = 1f;
        int aa = (a >>> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >>> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int ra = (int) (aa + (ba - aa) * t);
        int rr = (int) (ar + (br - ar) * t);
        int rg = (int) (ag + (bg - ag) * t);
        int rb = (int) (ab + (bb - ab) * t);
        return (ra << 24) | (rr << 16) | (rg << 8) | rb;
    }

    /** Slow ice shimmer between the dim and bright accent, phase-shifted by offset. */
    public static int shimmer(long timeMs, int offset) {
        double s = Math.sin((timeMs + offset * 90L) / 650.0);
        float t = (float) ((s + 1.0) * 0.5);
        return lerp(ACCENT_DIM, ACCENT_BRIGHT, t);
    }
}
