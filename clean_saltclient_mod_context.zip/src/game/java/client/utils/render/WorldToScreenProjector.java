package client.utils.render;

import net.minecraft.client.Minecraft;
import net.minecraft.util.math.Vec3d;

public final class WorldToScreenProjector {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private WorldToScreenProjector() {
    }

    public static float[] project(double worldX, double worldY, double worldZ) {
        if (mc.player == null || mc.world == null)
            return null;
        Vec3d cameraPos = mc.player.getPositionEyes(mc.getRenderPartialTicks());
        double relX = worldX - cameraPos.xCoord;
        double relY = worldY - cameraPos.yCoord;
        double relZ = worldZ - cameraPos.zCoord;
        float playerYaw = mc.player.rotationYaw;
        float playerPitch = mc.player.rotationPitch;
        float yawRad = (float) Math.toRadians(playerYaw);
        double cosYaw = Math.cos(yawRad);
        double sinYaw = Math.sin(yawRad);
        double x1 = relX * cosYaw - relZ * sinYaw;
        double z1 = relX * sinYaw + relZ * cosYaw;
        float pitchRad = (float) Math.toRadians(playerPitch);
        double cosPitch = Math.cos(pitchRad);
        double sinPitch = Math.sin(pitchRad);
        double y2 = relY * cosPitch - z1 * sinPitch;
        double z2 = relY * sinPitch + z1 * cosPitch;
        if (z2 <= 0.1)
            return null;
        float fov = mc.gameSettings.fovSetting;
        float fovRad = (float) Math.toRadians(fov);
        float tanHalfFov = (float) Math.tan(fovRad / 2.0f);
        float aspectRatio = (float) mc.displayWidth / (float) mc.displayHeight;
        float screenXNorm = (float) (x1 / (z2 * tanHalfFov * aspectRatio));
        float screenYNorm = (float) (y2 / (z2 * tanHalfFov));
        net.minecraft.client.gui.ScaledResolution sr = new net.minecraft.client.gui.ScaledResolution(mc);
        float screenX = sr.getScaledWidth() / 2.0f + screenXNorm * sr.getScaledWidth() / 2.0f;
        float screenY = sr.getScaledHeight() / 2.0f - screenYNorm * sr.getScaledHeight() / 2.0f;
        return new float[] { screenX, screenY };
    }

    public static float[] project(Vec3d worldPos) {
        if (worldPos == null)
            return null;
        return project(worldPos.xCoord, worldPos.yCoord, worldPos.zCoord);
    }

    public static boolean project(double worldX, double worldY, double worldZ, float[] out) {
        if (mc.player == null || mc.world == null) {
            out[0] = Float.NaN;
            out[1] = Float.NaN;
            return false;
        }
        float pt = mc.getRenderPartialTicks();
        double eyeX = mc.player.prevPosX + (mc.player.posX - mc.player.prevPosX) * pt;
        double eyeY = mc.player.prevPosY + (mc.player.posY - mc.player.prevPosY) * pt + mc.player.getEyeHeight();
        double eyeZ = mc.player.prevPosZ + (mc.player.posZ - mc.player.prevPosZ) * pt;
        double relX = worldX - eyeX;
        double relY = worldY - eyeY;
        double relZ = worldZ - eyeZ;
        float yawRad = (float) Math.toRadians(mc.player.rotationYaw);
        double cosYaw = Math.cos(yawRad);
        double sinYaw = Math.sin(yawRad);
        double x1 = relX * cosYaw - relZ * sinYaw;
        double z1 = relX * sinYaw + relZ * cosYaw;
        float pitchRad = (float) Math.toRadians(mc.player.rotationPitch);
        double cosPitch = Math.cos(pitchRad);
        double sinPitch = Math.sin(pitchRad);
        double y2 = relY * cosPitch - z1 * sinPitch;
        double z2 = relY * sinPitch + z1 * cosPitch;
        if (z2 <= 0.1) {
            out[0] = Float.NaN;
            out[1] = Float.NaN;
            return false;
        }
        float fovRad = (float) Math.toRadians(mc.gameSettings.fovSetting);
        float tanHalfFov = (float) Math.tan(fovRad / 2.0f);
        float aspectRatio = (float) mc.displayWidth / (float) mc.displayHeight;
        float screenXNorm = (float) (x1 / (z2 * tanHalfFov * aspectRatio));
        float screenYNorm = (float) (y2 / (z2 * tanHalfFov));
        net.minecraft.client.gui.ScaledResolution sr = mc.scaledResolution;
        if (sr == null) {
            sr = new net.minecraft.client.gui.ScaledResolution(mc);
        }
        out[0] = sr.getScaledWidth() / 2.0f + screenXNorm * sr.getScaledWidth() / 2.0f;
        out[1] = sr.getScaledHeight() / 2.0f - screenYNorm * sr.getScaledHeight() / 2.0f;
        return true;
    }

    public static boolean isOnScreen(double worldX, double worldY, double worldZ) {
        float[] screen = project(worldX, worldY, worldZ);
        if (screen == null)
            return false;
        net.minecraft.client.gui.ScaledResolution sr = new net.minecraft.client.gui.ScaledResolution(mc);
        return screen[0] >= 0 && screen[0] <= sr.getScaledWidth() && screen[1] >= 0 && screen[1] <= sr.getScaledHeight();
    }
}
