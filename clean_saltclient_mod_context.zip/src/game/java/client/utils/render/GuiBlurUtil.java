package client.utils.render;

import static net.lax1dude.eaglercraft.internal.PlatformOpenGL.*;
import static net.lax1dude.eaglercraft.opengl.RealOpenGLEnums.*;
import net.lax1dude.eaglercraft.EagRuntime;
import net.lax1dude.eaglercraft.internal.IFramebufferGL;
import net.lax1dude.eaglercraft.internal.IProgramGL;
import net.lax1dude.eaglercraft.internal.IShaderGL;
import net.lax1dude.eaglercraft.internal.IUniformGL;
import net.lax1dude.eaglercraft.internal.IBufferGL;
import net.lax1dude.eaglercraft.internal.IVertexArrayGL;
import net.lax1dude.eaglercraft.internal.buffer.FloatBuffer;
import net.lax1dude.eaglercraft.internal.buffer.ByteBuffer;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.GLSLHeader;
import net.minecraft.client.Minecraft;

public final class GuiBlurUtil {

    private static final int _GL_FBO = 0x8D40;

    private static final int _GL_CA0 = 0x8CE0;

    private static final int _GL_AB = 0x8892;

    private static float blurRadius = 8.0f;

    private static int dimAlpha = 180;

    private static boolean enabled = true;

    private static IProgramGL blurProgram = null;

    private static IUniformGL u_texture, u_direction, u_radius;

    private static IFramebufferGL blurFBO1, blurFBO2;

    private static int captureTex = -1;

    private static int blurTex1 = -1;

    private static int blurTex2 = -1;

    private static IVertexArrayGL quadVAO;

    private static IBufferGL quadVBO;

    private static int lastWidth = -1, lastHeight = -1;

    private static boolean initialized = false;

    private static boolean compileFailed = false;

    private GuiBlurUtil() {
    }

    private static final String PREC = "precision highp float;\n" + "precision highp int;\n";

    private static final String VERT_SRC = "EAGLER_IN(0, vec2, a_pos)\n" + "EAGLER_OUT(vec2, v_uv)\n" + "void main() {\n" + "    v_uv = a_pos * 0.5 + 0.5;\n" + "    EAGLER_VERT_POSITION = vec4(a_pos, 0.0, 1.0);\n" + "}\n";

    private static final String FRAG_SRC = "EAGLER_IN(vec2, v_uv)\n" + "uniform sampler2D u_texture;\n" + "uniform vec2 u_direction;\n" + "uniform float u_radius;\n" + "EAGLER_FRAG_OUT()\n" + "void main() {\n" + "    vec4 s = vec4(0.0);\n" + "    float tw = 0.0;\n" + "    float sigma = max(u_radius, 0.1);\n" + "    for (int i = -12; i <= 12; i++) {\n" + "        float x = float(i);\n" + "        float w = exp(-0.5 * x * x / (sigma * sigma));\n" + "        vec2 off = v_uv + x * u_direction;\n" + "        s += EAGLER_TEXTURE_2D(u_texture, off) * w;\n" + "        tw += w;\n" + "    }\n" + "    EAGLER_FRAG_COLOR = s / max(tw, 0.00001);\n" + "}\n";

    public static boolean init(int w, int h) {
        if (compileFailed)
            return false;
        if (w == lastWidth && h == lastHeight && initialized)
            return true;
        if (!initialized) {
            if (!compileShader()) {
                compileFailed = true;
                return false;
            }
            setupQuad();
            initialized = true;
        }
        destroyFBOs();
        lastWidth = w;
        lastHeight = h;
        captureTex = createTexture(w, h);
        int hw = Math.max(1, w / 2);
        int hh = Math.max(1, h / 2);
        blurFBO1 = _wglCreateFramebuffer();
        _wglBindFramebuffer(_GL_FBO, blurFBO1);
        blurTex1 = createTexture(hw, hh);
        _wglFramebufferTexture2D(_GL_FBO, _GL_CA0, GL_TEXTURE_2D, EaglercraftGPU.getNativeTexture(blurTex1), 0);
        _wglBindFramebuffer(_GL_FBO, null);
        blurFBO2 = _wglCreateFramebuffer();
        _wglBindFramebuffer(_GL_FBO, blurFBO2);
        blurTex2 = createTexture(hw, hh);
        _wglFramebufferTexture2D(_GL_FBO, _GL_CA0, GL_TEXTURE_2D, EaglercraftGPU.getNativeTexture(blurTex2), 0);
        _wglBindFramebuffer(_GL_FBO, null);
        return true;
    }

    private static boolean compileShader() {
        IShaderGL vs = _wglCreateShader(GL_VERTEX_SHADER);
        _wglShaderSource(vs, GLSLHeader.getVertexHeaderCompat(VERT_SRC, PREC));
        _wglCompileShader(vs);
        if (_wglGetShaderi(vs, GL_COMPILE_STATUS) != GL_TRUE) {
            System.err.println("[GuiBlurUtil] VS error: " + _wglGetShaderInfoLog(vs));
            _wglDeleteShader(vs);
            return false;
        }
        IShaderGL fs = _wglCreateShader(GL_FRAGMENT_SHADER);
        _wglShaderSource(fs, GLSLHeader.getFragmentHeaderCompat(FRAG_SRC, PREC));
        _wglCompileShader(fs);
        if (_wglGetShaderi(fs, GL_COMPILE_STATUS) != GL_TRUE) {
            System.err.println("[GuiBlurUtil] FS error: " + _wglGetShaderInfoLog(fs));
            _wglDeleteShader(vs);
            _wglDeleteShader(fs);
            return false;
        }
        blurProgram = _wglCreateProgram();
        _wglAttachShader(blurProgram, vs);
        _wglAttachShader(blurProgram, fs);
        if (EaglercraftGPU.checkOpenGLESVersion() == 200) {
            _wglBindAttribLocation(blurProgram, 0, "a_pos");
        }
        _wglLinkProgram(blurProgram);
        _wglDetachShader(blurProgram, vs);
        _wglDetachShader(blurProgram, fs);
        _wglDeleteShader(vs);
        _wglDeleteShader(fs);
        if (_wglGetProgrami(blurProgram, GL_LINK_STATUS) != GL_TRUE) {
            System.err.println("[GuiBlurUtil] Link error: " + _wglGetProgramInfoLog(blurProgram));
            _wglDeleteProgram(blurProgram);
            blurProgram = null;
            return false;
        }
        u_texture = _wglGetUniformLocation(blurProgram, "u_texture");
        u_direction = _wglGetUniformLocation(blurProgram, "u_direction");
        u_radius = _wglGetUniformLocation(blurProgram, "u_radius");
        return true;
    }

    private static void setupQuad() {
        quadVAO = EaglercraftGPU.createGLVertexArray();
        quadVBO = _wglGenBuffers();
        FloatBuffer verts = EagRuntime.allocateFloatBuffer(12);
        verts.put(new float[] { -1, -1, 1, -1, -1, 1, 1, -1, 1, 1, -1, 1 });
        verts.flip();
        EaglercraftGPU.bindVAOGLArrayBufferNow(quadVBO);
        _wglBufferData(_GL_AB, verts, GL_STATIC_DRAW);
        EagRuntime.freeFloatBuffer(verts);
        EaglercraftGPU.bindGLVertexArray(quadVAO);
        EaglercraftGPU.enableVertexAttribArray(0);
        EaglercraftGPU.vertexAttribPointer(0, 2, GL_FLOAT, false, 0, 0);
    }

    private static int createTexture(int w, int h) {
        int tex = GlStateManager.generateTexture();
        GlStateManager.bindTexture(tex);
        _wglTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        _wglTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        _wglTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        _wglTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        EaglercraftGPU.glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, (ByteBuffer) null);
        return tex;
    }

    private static void destroyFBOs() {
        if (blurFBO1 != null) {
            _wglDeleteFramebuffer(blurFBO1);
            blurFBO1 = null;
        }
        if (blurFBO2 != null) {
            _wglDeleteFramebuffer(blurFBO2);
            blurFBO2 = null;
        }
        if (captureTex > 0) {
            GlStateManager.deleteTexture(captureTex);
            captureTex = -1;
        }
        if (blurTex1 > 0) {
            GlStateManager.deleteTexture(blurTex1);
            blurTex1 = -1;
        }
        if (blurTex2 > 0) {
            GlStateManager.deleteTexture(blurTex2);
            blurTex2 = -1;
        }
    }

    public static void captureScreen() {
        if (!enabled || compileFailed)
            return;
        Minecraft mc = Minecraft.getMinecraft();
        int dw = mc.displayWidth;
        int dh = mc.displayHeight;
        if (!init(dw, dh))
            return;
        GlStateManager.bindTexture(captureTex);
        _wglCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, dw, dh);
    }

    public static void renderBlur(float guiAlpha) {
        if (!enabled || compileFailed || blurProgram == null)
            return;
        Minecraft mc = Minecraft.getMinecraft();
        int dw = mc.displayWidth;
        int dh = mc.displayHeight;
        int hw = Math.max(1, dw / 2);
        int hh = Math.max(1, dh / 2);
        _wglBindFramebuffer(_GL_FBO, blurFBO1);
        GlStateManager.viewport(0, 0, hw, hh);
        GlStateManager.clearColor(0.0f, 0.0f, 0.0f, 0.0f);
        GlStateManager.clear(16384);
        EaglercraftGPU.bindGLShaderProgram(blurProgram);
        GlStateManager.bindTexture(captureTex);
        _wglUniform1i(u_texture, 0);
        _wglUniform2f(u_direction, 1.0f / hw, 0.0f);
        _wglUniform1f(u_radius, blurRadius);
        drawQuad();
        _wglBindFramebuffer(_GL_FBO, blurFBO2);
        GlStateManager.viewport(0, 0, hw, hh);
        GlStateManager.clearColor(0.0f, 0.0f, 0.0f, 0.0f);
        GlStateManager.clear(16384);
        GlStateManager.bindTexture(blurTex1);
        _wglUniform1i(u_texture, 0);
        _wglUniform2f(u_direction, 0.0f, 1.0f / hh);
        _wglUniform1f(u_radius, blurRadius);
        drawQuad();
        _wglBindFramebuffer(_GL_FBO, null);
        GlStateManager.viewport(0, 0, dw, dh);
        EaglercraftGPU.bindGLShaderProgram(null);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.disableDepth();
        GlStateManager.color(1.0f, 1.0f, 1.0f, guiAlpha);
        net.minecraft.client.renderer.Tessellator tes = net.minecraft.client.renderer.Tessellator.getInstance();
        net.lax1dude.eaglercraft.opengl.WorldRenderer wr = tes.getWorldRenderer();
        GlStateManager.bindTexture(blurTex2);
        GlStateManager.enableTexture2D();
        wr.begin(GL_QUADS, net.minecraft.client.renderer.vertex.DefaultVertexFormats.POSITION_TEX);
        wr.pos(0, dh, 0).tex(0, 0).endVertex();
        wr.pos(dw, dh, 0).tex(1, 0).endVertex();
        wr.pos(dw, 0, 0).tex(1, 1).endVertex();
        wr.pos(0, 0, 0).tex(0, 1).endVertex();
        tes.draw();
        int alpha = (int) (dimAlpha * guiAlpha);
        GlStateManager.disableTexture2D();
        GlStateManager.color(0.04f, 0.04f, 0.06f, alpha / 255.0f);
        wr.begin(GL_QUADS, net.minecraft.client.renderer.vertex.DefaultVertexFormats.POSITION);
        wr.pos(0, dh, 0).endVertex();
        wr.pos(dw, dh, 0).endVertex();
        wr.pos(dw, 0, 0).endVertex();
        wr.pos(0, 0, 0).endVertex();
        tes.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.enableDepth();
        GlStateManager.disableBlend();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public static void onClose() {
    }

    public static void destroy() {
        destroyFBOs();
        if (blurProgram != null) {
            _wglDeleteProgram(blurProgram);
            blurProgram = null;
        }
        if (quadVAO != null) {
            EaglercraftGPU.destroyGLVertexArray(quadVAO);
            quadVAO = null;
        }
        if (quadVBO != null) {
            _wglDeleteBuffers(quadVBO);
            quadVBO = null;
        }
        initialized = false;
        compileFailed = false;
        lastWidth = -1;
        lastHeight = -1;
    }

    private static void drawQuad() {
        EaglercraftGPU.bindGLVertexArray(quadVAO);
        _wglDrawArrays(GL_TRIANGLES, 0, 6);
    }

    public static boolean isEnabled() {
        return enabled && !compileFailed;
    }

    public static void setEnabled(boolean e) {
        enabled = e;
    }

    public static float getBlurRadius() {
        return blurRadius;
    }

    public static void setBlurRadius(float r) {
        blurRadius = Math.max(1.0f, Math.min(20.0f, r));
    }

    public static int getDimAlpha() {
        return dimAlpha;
    }

    public static void setDimAlpha(int a) {
        dimAlpha = Math.max(0, Math.min(255, a));
    }
}
