package client.utils.render;

import net.lax1dude.eaglercraft.Mouse;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import client.module.BooleanSetting;
import client.module.Module;
import client.module.NumberSetting;
import client.module.Setting;

public class HudElement {

    private static HudElement editingElement = null;

    private static boolean hudEditorOpen = false;

    public static boolean isHudEditorOpen() {
        return hudEditorOpen;
    }

    public static void setHudEditorOpen(boolean open) {
        hudEditorOpen = open;
    }

    public static boolean isAnyEditing() {
        return editingElement != null;
    }

    public boolean shouldRender() {
        return editingElement == null || editingElement == this;
    }

    private final Module module;

    private final int defaultX;

    private final int defaultY;

    private final NumberSetting posX;

    private final NumberSetting posY;

    private final BooleanSetting editPos;

    private boolean wasMouseDown = false;

    private final Minecraft mc = Minecraft.getMinecraft();

    public HudElement(Module module, int defaultX, int defaultY) {
        this.module = module;
        this.defaultX = defaultX;
        this.defaultY = defaultY;
        this.posX = new NumberSetting("HudX", defaultX, 0, 1000);
        this.posY = new NumberSetting("HudY", defaultY, 0, 1000);
        this.editPos = new BooleanSetting("EditPos", false);
        module.setHudElement(this);
    }

    public void addSettings() {
        module.addSetting(posX);
        module.addSetting(posY);
        module.addSetting(editPos);
    }

    public void updateDrag(int width, int height) {
        if (hudEditorOpen)
            return;
        if (editingElement != null && editingElement != this) {
            return;
        }
        if (editPos.getValue() && editingElement == null) {
            editingElement = this;
        }
        if (!editPos.getValue() && editingElement == this) {
            editingElement = null;
            wasMouseDown = false;
            return;
        }
        if (editingElement != this) {
            return;
        }
        ScaledResolution sr = new ScaledResolution(mc);
        int mouseX = Mouse.getX() * sr.getScaledWidth() / mc.displayWidth;
        int mouseY = sr.getScaledHeight() - (Mouse.getY() * sr.getScaledHeight() / mc.displayHeight) - 1;
        int x = Math.max(0, Math.min(mouseX - width / 2, sr.getScaledWidth() - width));
        int y = Math.max(0, Math.min(mouseY - height / 2, sr.getScaledHeight() - height));
        posX.setValue((double) x);
        posY.setValue((double) y);
        if (Mouse.isButtonDown(0)) {
            wasMouseDown = true;
        } else {
            if (wasMouseDown) {
                wasMouseDown = false;
                exitEditMode();
                return;
            }
        }
        if (Mouse.isButtonDown(1)) {
            exitEditMode();
        }
    }

    private void exitEditMode() {
        editingElement = null;
        wasMouseDown = false;
        if (editPos.getValue()) {
            editPos.setValue(false);
        }
    }

    public int getX() {
        ScaledResolution sr = new ScaledResolution(mc);
        return Math.max(0, Math.min(posX.getValue().intValue(), sr.getScaledWidth()));
    }

    public int getY() {
        ScaledResolution sr = new ScaledResolution(mc);
        return Math.max(0, Math.min(posY.getValue().intValue(), sr.getScaledHeight()));
    }

    public boolean isDefaultX() {
        return posX.getValue().intValue() == defaultX;
    }

    public boolean isDefaultY() {
        return posY.getValue().intValue() == defaultY;
    }

    public void renderDragBox(int x, int y, int w, int h) {
        if (editingElement != this)
            return;
        Gui.drawRect(x - 1, y - 1, x + w + 1, y + h + 1, 0x60FF0000);
    }

    public boolean isEditing() {
        return editingElement == this;
    }

    public NumberSetting getPosX() {
        return posX;
    }

    public NumberSetting getPosY() {
        return posY;
    }

    public BooleanSetting getEditPos() {
        return editPos;
    }

    public Module getModule() {
        return module;
    }

    public void resetToDefault() {
        posX.setValue((double) defaultX);
        posY.setValue((double) defaultY);
    }

    public void setPosition(int x, int y) {
        posX.setValue((double) x);
        posY.setValue((double) y);
    }

    public boolean isHiddenSetting(Setting<?> s) {
        return s == posX || s == posY || s == editPos;
    }
}
