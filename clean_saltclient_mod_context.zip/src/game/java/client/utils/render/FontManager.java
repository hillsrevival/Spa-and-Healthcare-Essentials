package client.utils.render;

import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;
import net.lax1dude.eaglercraft.opengl.ImageData;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import org.teavm.jso.JSBody;
import org.teavm.jso.typedarrays.Uint8Array;

/**
 * SaltClient global font override. Renders a glyph atlas from a system font with a canvas
 * and swaps it into every FontRenderer, so all text in the client changes at once.
 */
public final class FontManager {

    public static final String[] STYLES = { "Default", "Clean", "Mono", "Serif", "Rounded", "Impact", "Narrow", "Custom" };

    private static final String[] FAMILIES = {
        null,
        "'Segoe UI', 'Helvetica Neue', Roboto, Arial, sans-serif",
        "Consolas, 'Lucida Console', 'Courier New', monospace",
        "Georgia, 'Times New Roman', serif",
        "'Trebuchet MS', Verdana, sans-serif",
        "Impact, 'Arial Black', sans-serif",
        "Bahnschrift, 'Arial Narrow', Arial, sans-serif",
        null
    };

    private static final int CELL = 32;

    private static ResourceLocation location = null;

    private static int[] widths = null;

    private static String appliedKey = "Default";

    private static String desiredKey = "Default";

    private static String desiredFamily = null;

    private static boolean desiredBold = false;

    private static boolean desiredItalic = false;

    private static double desiredSize = 0.95;

    private static boolean pending = false;

    private FontManager() {
    }

    public static boolean hasOverride() {
        return location != null && widths != null;
    }

    public static ResourceLocation getLocation() {
        return location;
    }

    public static int[] getWidths() {
        return widths;
    }

    /** Records the wanted font. The atlas is built on the next pump(). */
    public static void request(String style, String customFamily, boolean bold, boolean italic, double sizeScale) {
        String family = null;
        for (int i = 0; i < STYLES.length; i++) {
            if (STYLES[i].equalsIgnoreCase(style)) {
                family = FAMILIES[i];
                if (i == STYLES.length - 1 && customFamily != null && !customFamily.trim().isEmpty()) {
                    family = "'" + customFamily.trim().replace("'", "") + "', sans-serif";
                }
                break;
            }
        }
        String key = family == null ? "Default" : (family + "|" + bold + "|" + italic + "|" + sizeScale);
        if (key.equals(desiredKey))
            return;
        desiredKey = key;
        desiredFamily = family;
        desiredBold = bold;
        desiredItalic = italic;
        desiredSize = sizeScale;
        pending = true;
    }

    public static void reset() {
        request("Default", null, false, false, 0.95);
    }

    /** Call from any frequently-run place (menu draw, module update). Cheap when nothing changed. */
    public static void pump() {
        if (!pending)
            return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.getTextureManager() == null || mc.fontRendererObj == null)
            return;
        pending = false;
        if (desiredKey.equals(appliedKey))
            return;
        try {
            if (desiredFamily == null) {
                clear(mc);
            } else {
                build(mc, desiredFamily, desiredBold, desiredItalic, desiredSize);
            }
            appliedKey = desiredKey;
            ClientFontRenderer.clearCache();
        } catch (Throwable t) {
            System.err.println("[FontManager] could not apply font: " + t);
            clear(mc);
            appliedKey = "Default";
        }
    }

    private static void clear(Minecraft mc) {
        if (location != null) {
            try {
                mc.getTextureManager().deleteTexture(location);
            } catch (Throwable ignored) {
            }
        }
        location = null;
        widths = null;
    }

    private static void build(Minecraft mc, String family, boolean bold, boolean italic, double sizeScale) {
        String chars = FontRenderer.ATLAS_CHARS;
        int n = CELL * 16;
        double size = CELL * Math.max(0.6, Math.min(1.2, sizeScale));
        Uint8Array alpha = renderAtlas(chars, family, CELL, size, CELL * 0.82, CELL * 0.05, bold ? "bold" : "normal", italic);
        if (alpha == null)
            throw new IllegalStateException("canvas unavailable");
        int[] pixels = new int[n * n];
        for (int p = 0; p < pixels.length; p++) {
            int a = alpha.get(p) & 0xFF;
            pixels[p] = (a << 24) | 0x00FFFFFF;
        }
        int[] w = new int[256];
        for (int idx = 0; idx < 256; idx++) {
            int cx = (idx % 16) * CELL;
            int cy = (idx / 16) * CELL;
            int right = -1;
            for (int x = CELL - 1; x >= 0 && right < 0; x--) {
                for (int y = 0; y < CELL; y++) {
                    if (((pixels[(cy + y) * n + cx + x] >>> 24) & 0xFF) > 24) {
                        right = x;
                        break;
                    }
                }
            }
            int l1 = right + 1;
            w[idx] = (int) (0.5D + (double) l1 * (8.0D / CELL)) + 1;
            if (idx < chars.length() && chars.charAt(idx) == ' ')
                w[idx] = 4;
        }
        clear(mc);
        DynamicTexture tex = new DynamicTexture(new ImageData(n, n, pixels, true));
        location = mc.getTextureManager().getDynamicTextureLocation("saltclient_font", tex);
        mc.getTextureManager().bindTexture(location);
        EaglercraftGPU.glTexParameteri(RealOpenGLEnums.GL_TEXTURE_2D, RealOpenGLEnums.GL_TEXTURE_MAG_FILTER, RealOpenGLEnums.GL_LINEAR);
        EaglercraftGPU.glTexParameteri(RealOpenGLEnums.GL_TEXTURE_2D, RealOpenGLEnums.GL_TEXTURE_MIN_FILTER, RealOpenGLEnums.GL_LINEAR);
        widths = w;
    }

    @JSBody(params = { "chars", "family", "cell", "size", "base", "pad", "weight", "italic" }, script = "" + "var N = cell * 16;" + "var c = document.createElement('canvas'); c.width = N; c.height = N;" + "var ctx = c.getContext('2d'); if (!ctx) return null;" + "ctx.clearRect(0, 0, N, N); ctx.fillStyle = '#ffffff'; ctx.textBaseline = 'alphabetic';" + "ctx.font = (italic ? 'italic ' : '') + weight + ' ' + size + 'px ' + family;" + "for (var i = 0; i < 256 && i < chars.length; i++) {" + "  var ch = chars.charAt(i);" + "  if (ch.charCodeAt(0) === 0 || ch === ' ') continue;" + "  var cx = (i % 16) * cell, cy = Math.floor(i / 16) * cell;" + "  ctx.save(); ctx.beginPath(); ctx.rect(cx, cy, cell, cell); ctx.clip();" + "  ctx.fillText(ch, cx + pad, cy + base); ctx.restore();" + "}" + "var d = ctx.getImageData(0, 0, N, N).data;" + "var out = new Uint8Array(N * N);" + "for (var p = 0; p < N * N; p++) out[p] = d[p * 4 + 3];" + "return out;")
    private static native Uint8Array renderAtlas(String chars, String family, int cell, double size, double base, double pad, String weight, boolean italic);
}
