package client.utils.render;

import static net.lax1dude.eaglercraft.internal.PlatformOpenGL.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.lax1dude.eaglercraft.opengl.WorldRenderer;
import net.minecraft.util.math.AxisAlignedBB;
import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.lax1dude.eaglercraft.opengl.RealOpenGLEnums;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;

public class RenderUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final AxisAlignedBB DEFAULT_AABB = new AxisAlignedBB(0, 0, 0, 1, 1, 1);

    public static double camX, camY, camZ;

    public static void updateCameraPos(float partialTicks) {
        if (mc.player == null)
            return;
        camX = mc.player.lastTickPosX + (mc.player.posX - mc.player.lastTickPosX) * partialTicks;
        camY = mc.player.lastTickPosY + (mc.player.posY - mc.player.lastTickPosY) * partialTicks;
        camZ = mc.player.lastTickPosZ + (mc.player.posZ - mc.player.lastTickPosZ) * partialTicks;
    }

    public static void setColor(float red, float green, float blue, float alpha) {
    }

    public static void setColor(int red, int green, int blue, int alpha) {
        setColor(red / 255f, green / 255f, blue / 255f, alpha / 255f);
    }

    public static void setColor(int rgba) {
        float alpha = ((rgba >> 24) & 0xFF) / 255f;
        float red = ((rgba >> 16) & 0xFF) / 255f;
        float green = ((rgba >> 8) & 0xFF) / 255f;
        float blue = (rgba & 0xFF) / 255f;
        setColor(red, green, blue, alpha);
    }

    private static final int GL_LINE_SMOOTH = 0x0B20;

    public static void enableLineSmooth() {
        try {
            _wglEnable(GL_LINE_SMOOTH);
        } catch (Exception e) {
        }
    }

    public static void disableLineSmooth() {
        try {
            _wglDisable(GL_LINE_SMOOTH);
        } catch (Exception e) {
        }
    }

    public static void prepareGL() {
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
        GlStateManager.disableTexture2D();
        GlStateManager.disableDepth();
        enableLineSmooth();
        EaglercraftGPU.glLineWidth(2.0F);
    }

    public static void restoreGL() {
        disableLineSmooth();
        GlStateManager.enableDepth();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        EaglercraftGPU.glLineWidth(1.0F);
    }

    public static void drawLine(double x1, double y1, double z1, double x2, double y2, double z2, float red, float green, float blue, float alpha) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        wr.begin(Tessellator.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        addColoredEdge(wr, x1, y1, z1, x2, y2, z2, red, green, blue, alpha);
        tessellator.draw();
    }

    public static void drawSolidBox() {
        drawSolidBox(DEFAULT_AABB, 1f, 1f, 1f, 1f);
    }

    public static void drawSolidBox(AxisAlignedBB bb) {
        drawSolidBox(bb, 1f, 1f, 1f, 1f);
    }

    public static void drawSolidBox(AxisAlignedBB bb, float red, float green, float blue, float alpha) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        wr.begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        addColoredVertex(wr, bb.minX, bb.minY, bb.minZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.maxX, bb.minY, bb.minZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.maxX, bb.minY, bb.maxZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.minX, bb.minY, bb.maxZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.minX, bb.maxY, bb.minZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.minX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.maxX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.maxX, bb.maxY, bb.minZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.minX, bb.minY, bb.minZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.minX, bb.maxY, bb.minZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.maxX, bb.maxY, bb.minZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.maxX, bb.minY, bb.minZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.maxX, bb.minY, bb.minZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.maxX, bb.maxY, bb.minZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.maxX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.maxX, bb.minY, bb.maxZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.minX, bb.minY, bb.maxZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.maxX, bb.minY, bb.maxZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.maxX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.minX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.minX, bb.minY, bb.minZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.minX, bb.minY, bb.maxZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.minX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredVertex(wr, bb.minX, bb.maxY, bb.minZ, red, green, blue, alpha);
        tessellator.draw();
    }

    public static void drawOutlinedBox() {
        drawOutlinedBox(DEFAULT_AABB, 1f, 1f, 1f, 1f);
    }

    public static void drawOutlinedBox(AxisAlignedBB bb) {
        drawOutlinedBox(bb, 1f, 1f, 1f, 1f);
    }

    public static void drawOutlinedBox(AxisAlignedBB bb, float red, float green, float blue, float alpha) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        wr.begin(Tessellator.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        addColoredEdge(wr, bb.minX, bb.minY, bb.minZ, bb.maxX, bb.minY, bb.minZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.maxX, bb.minY, bb.minZ, bb.maxX, bb.minY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.maxX, bb.minY, bb.maxZ, bb.minX, bb.minY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.minX, bb.minY, bb.maxZ, bb.minX, bb.minY, bb.minZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.minX, bb.minY, bb.minZ, bb.minX, bb.maxY, bb.minZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.maxX, bb.minY, bb.minZ, bb.maxX, bb.maxY, bb.minZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.maxX, bb.minY, bb.maxZ, bb.maxX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.minX, bb.minY, bb.maxZ, bb.minX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.minX, bb.maxY, bb.minZ, bb.maxX, bb.maxY, bb.minZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.maxX, bb.maxY, bb.minZ, bb.maxX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.maxX, bb.maxY, bb.maxZ, bb.minX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.minX, bb.maxY, bb.maxZ, bb.minX, bb.maxY, bb.minZ, red, green, blue, alpha);
        tessellator.draw();
    }

    public static void drawCrossBox() {
        drawCrossBox(DEFAULT_AABB, 1f, 1f, 1f, 1f);
    }

    public static void drawCrossBox(AxisAlignedBB bb) {
        drawCrossBox(bb, 1f, 1f, 1f, 1f);
    }

    public static void drawCrossBox(AxisAlignedBB bb, float red, float green, float blue, float alpha) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        wr.begin(Tessellator.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        addColoredEdge(wr, bb.minX, bb.minY, bb.minZ, bb.maxX, bb.maxY, bb.minZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.maxX, bb.minY, bb.minZ, bb.maxX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.maxX, bb.minY, bb.maxZ, bb.minX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.minX, bb.minY, bb.maxZ, bb.minX, bb.maxY, bb.minZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.maxX, bb.minY, bb.minZ, bb.minX, bb.maxY, bb.minZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.maxX, bb.minY, bb.maxZ, bb.maxX, bb.maxY, bb.minZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.minX, bb.minY, bb.maxZ, bb.maxX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.minX, bb.minY, bb.minZ, bb.minX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.minX, bb.maxY, bb.minZ, bb.maxX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.maxX, bb.maxY, bb.minZ, bb.minX, bb.maxY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.maxX, bb.minY, bb.minZ, bb.minX, bb.minY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.maxX, bb.minY, bb.maxZ, bb.minX, bb.minY, bb.minZ, red, green, blue, alpha);
        tessellator.draw();
    }

    public static void drawNode(AxisAlignedBB bb) {
        drawNode(bb, 1f, 1f, 1f, 1f);
    }

    public static void drawNode(AxisAlignedBB bb, float red, float green, float blue, float alpha) {
        double midX = (bb.minX + bb.maxX) / 2;
        double midY = (bb.minY + bb.maxY) / 2;
        double midZ = (bb.minZ + bb.maxZ) / 2;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        wr.begin(Tessellator.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        addColoredEdge(wr, midX, midY, bb.maxZ, bb.minX, midY, midZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.minX, midY, midZ, midX, midY, bb.minZ, red, green, blue, alpha);
        addColoredEdge(wr, midX, midY, bb.minZ, bb.maxX, midY, midZ, red, green, blue, alpha);
        addColoredEdge(wr, bb.maxX, midY, midZ, midX, midY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, midX, bb.maxY, midZ, bb.maxX, midY, midZ, red, green, blue, alpha);
        addColoredEdge(wr, midX, bb.maxY, midZ, bb.minX, midY, midZ, red, green, blue, alpha);
        addColoredEdge(wr, midX, bb.maxY, midZ, midX, midY, bb.minZ, red, green, blue, alpha);
        addColoredEdge(wr, midX, bb.maxY, midZ, midX, midY, bb.maxZ, red, green, blue, alpha);
        addColoredEdge(wr, midX, bb.minY, midZ, bb.maxX, midY, midZ, red, green, blue, alpha);
        addColoredEdge(wr, midX, bb.minY, midZ, bb.minX, midY, midZ, red, green, blue, alpha);
        addColoredEdge(wr, midX, bb.minY, midZ, midX, midY, bb.minZ, red, green, blue, alpha);
        addColoredEdge(wr, midX, bb.minY, midZ, midX, midY, bb.maxZ, red, green, blue, alpha);
        tessellator.draw();
    }

    public static void prepareHUD() {
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
        GlStateManager.disableTexture2D();
        enableLineSmooth();
    }

    public static void restoreHUD() {
        disableLineSmooth();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void drawRect2D(float x1, float y1, float x2, float y2, float red, float green, float blue, float alpha) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        wr.begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        wr.pos(x1, y2, 0).color(red, green, blue, alpha).endVertex();
        wr.pos(x2, y2, 0).color(red, green, blue, alpha).endVertex();
        wr.pos(x2, y1, 0).color(red, green, blue, alpha).endVertex();
        wr.pos(x1, y1, 0).color(red, green, blue, alpha).endVertex();
        tessellator.draw();
    }

    public static void drawRect2D(float x1, float y1, float x2, float y2, int argb) {
        drawRect2D(x1, y1, x2, y2, ColorUtils.red(argb), ColorUtils.green(argb), ColorUtils.blue(argb), ColorUtils.alpha(argb));
    }

    public static void drawBorderedRect2D(float x, float y, float w, float h, float borderThickness, float bgR, float bgG, float bgB, float bgA, float brR, float brG, float brB, float brA) {
        drawRect2D(x, y, x + w, y + h, bgR, bgG, bgB, bgA);
        drawRect2D(x, y, x + w, y + borderThickness, brR, brG, brB, brA);
        drawRect2D(x, y + h - borderThickness, x + w, y + h, brR, brG, brB, brA);
        drawRect2D(x, y, x + borderThickness, y + h, brR, brG, brB, brA);
        drawRect2D(x + w - borderThickness, y, x + w, y + h, brR, brG, brB, brA);
    }

    public static void drawBorderedRect2D(float x, float y, float w, float h, float borderThickness, int bgArgb, int borderArgb) {
        drawBorderedRect2D(x, y, w, h, borderThickness, ColorUtils.red(bgArgb), ColorUtils.green(bgArgb), ColorUtils.blue(bgArgb), ColorUtils.alpha(bgArgb), ColorUtils.red(borderArgb), ColorUtils.green(borderArgb), ColorUtils.blue(borderArgb), ColorUtils.alpha(borderArgb));
    }

    public static void drawHudPanel(float x, float y, float w, float h, float bgAlpha) {
        prepareHUD();
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        wr.begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        addQuadVerts(wr, x, y, x + w, y + h, 0.15f, 0.15f, 0.22f, bgAlpha);
        tessellator.draw();
        wr.begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        addQuadVerts(wr, x, y, x + w, y + 1, 0.3f, 0.3f, 0.45f, 0.3f);
        addQuadVerts(wr, x, y + h - 1, x + w, y + h, 0.3f, 0.3f, 0.45f, 0.3f);
        addQuadVerts(wr, x, y, x + 1, y + h, 0.3f, 0.3f, 0.45f, 0.3f);
        addQuadVerts(wr, x + w - 1, y, x + w, y + h, 0.3f, 0.3f, 0.45f, 0.3f);
        tessellator.draw();
        restoreHUD();
    }

    public static void drawRoundedRect2D(float x1, float y1, float x2, float y2, float radius, int argb) {
        drawRoundedRect2D(x1, y1, x2, y2, radius, ColorUtils.red(argb), ColorUtils.green(argb), ColorUtils.blue(argb), ColorUtils.alpha(argb));
    }

    public static void drawRoundedRect2D(float x1, float y1, float x2, float y2, float radius, float r, float g, float b, float a) {
        if (x2 - x1 <= 0 || y2 - y1 <= 0)
            return;
        radius = Math.min(radius, (x2 - x1) / 2.0f);
        radius = Math.min(radius, (y2 - y1) / 2.0f);
        if (radius < 0.5f) {
            drawRect2D(x1, y1, x2, y2, r, g, b, a);
            return;
        }
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
        GlStateManager.disableTexture2D();
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        wr.begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        addQuadVerts(wr, x1 + radius, y1 + radius, x2 - radius, y2 - radius, r, g, b, a);
        addQuadVerts(wr, x1 + radius, y1, x2 - radius, y1 + radius, r, g, b, a);
        addQuadVerts(wr, x1 + radius, y2 - radius, x2 - radius, y2, r, g, b, a);
        addQuadVerts(wr, x1, y1 + radius, x1 + radius, y2 - radius, r, g, b, a);
        addQuadVerts(wr, x2 - radius, y1 + radius, x2, y2 - radius, r, g, b, a);
        tessellator.draw();
        wr.begin(Tessellator.GL_TRIANGLES, DefaultVertexFormats.POSITION_COLOR);
        int segs = 10;
        emitCornerFill(wr, x1 + radius, y1 + radius, radius, 180, segs, r, g, b, a);
        emitCornerFill(wr, x2 - radius, y1 + radius, radius, 270, segs, r, g, b, a);
        emitCornerFill(wr, x2 - radius, y2 - radius, radius, 0, segs, r, g, b, a);
        emitCornerFill(wr, x1 + radius, y2 - radius, radius, 90, segs, r, g, b, a);
        tessellator.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void drawRoundedStroke2D(float x1, float y1, float x2, float y2, float radius, float thickness, int argb) {
        if (x2 - x1 <= 0 || y2 - y1 <= 0)
            return;
        radius = Math.min(radius, (x2 - x1) / 2.0f);
        radius = Math.min(radius, (y2 - y1) / 2.0f);
        float inner = Math.max(0, radius - thickness);
        float cr = ColorUtils.red(argb);
        float cg = ColorUtils.green(argb);
        float cb = ColorUtils.blue(argb);
        float ca = ColorUtils.alpha(argb);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(RealOpenGLEnums.GL_SRC_ALPHA, RealOpenGLEnums.GL_ONE_MINUS_SRC_ALPHA, RealOpenGLEnums.GL_ONE, RealOpenGLEnums.GL_ZERO);
        GlStateManager.disableTexture2D();
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        wr.begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        addQuadVerts(wr, x1 + radius, y1, x2 - radius, y1 + thickness, cr, cg, cb, ca);
        addQuadVerts(wr, x1 + radius, y2 - thickness, x2 - radius, y2, cr, cg, cb, ca);
        addQuadVerts(wr, x1, y1 + radius, x1 + thickness, y2 - radius, cr, cg, cb, ca);
        addQuadVerts(wr, x2 - thickness, y1 + radius, x2, y2 - radius, cr, cg, cb, ca);
        int segs = 10;
        emitCornerStroke(wr, x1 + radius, y1 + radius, radius, inner, 180, segs, cr, cg, cb, ca);
        emitCornerStroke(wr, x2 - radius, y1 + radius, radius, inner, 270, segs, cr, cg, cb, ca);
        emitCornerStroke(wr, x2 - radius, y2 - radius, radius, inner, 0, segs, cr, cg, cb, ca);
        emitCornerStroke(wr, x1 + radius, y2 - radius, radius, inner, 90, segs, cr, cg, cb, ca);
        tessellator.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void drawRoundedBorderedRect2D(float x, float y, float w, float h, float radius, float thickness, int bgArgb, int borderArgb) {
        drawRoundedRect2D(x, y, x + w, y + h, radius, bgArgb);
        drawRoundedStroke2D(x, y, x + w, y + h, radius, thickness, borderArgb);
    }

    private static void addQuadVerts(WorldRenderer wr, float x1, float y1, float x2, float y2, float r, float g, float b, float a) {
        wr.pos(x1, y2, 0).color(r, g, b, a).endVertex();
        wr.pos(x2, y2, 0).color(r, g, b, a).endVertex();
        wr.pos(x2, y1, 0).color(r, g, b, a).endVertex();
        wr.pos(x1, y1, 0).color(r, g, b, a).endVertex();
    }

    private static void emitCornerFill(WorldRenderer wr, float cx, float cy, float rad, float startDeg, int segs, float r, float g, float b, float a) {
        for (int i = 0; i < segs; i++) {
            float a1 = (float) Math.toRadians(startDeg + i * 90.0f / segs);
            float a2 = (float) Math.toRadians(startDeg + (i + 1) * 90.0f / segs);
            float p1x = cx + (float) Math.cos(a1) * rad;
            float p1y = cy + (float) Math.sin(a1) * rad;
            float p2x = cx + (float) Math.cos(a2) * rad;
            float p2y = cy + (float) Math.sin(a2) * rad;
            wr.pos(cx, cy, 0).color(r, g, b, a).endVertex();
            wr.pos(p2x, p2y, 0).color(r, g, b, a).endVertex();
            wr.pos(p1x, p1y, 0).color(r, g, b, a).endVertex();
        }
    }

    private static void emitCornerStroke(WorldRenderer wr, float cx, float cy, float outerR, float innerR, float startDeg, int segs, float r, float g, float b, float a) {
        for (int i = 0; i < segs; i++) {
            float a1 = (float) Math.toRadians(startDeg + i * 90.0f / segs);
            float a2 = (float) Math.toRadians(startDeg + (i + 1) * 90.0f / segs);
            float ox1 = cx + (float) Math.cos(a1) * outerR;
            float oy1 = cy + (float) Math.sin(a1) * outerR;
            float ox2 = cx + (float) Math.cos(a2) * outerR;
            float oy2 = cy + (float) Math.sin(a2) * outerR;
            float ix1 = cx + (float) Math.cos(a1) * innerR;
            float iy1 = cy + (float) Math.sin(a1) * innerR;
            float ix2 = cx + (float) Math.cos(a2) * innerR;
            float iy2 = cy + (float) Math.sin(a2) * innerR;
            wr.pos(ox1, oy1, 0).color(r, g, b, a).endVertex();
            wr.pos(ix1, iy1, 0).color(r, g, b, a).endVertex();
            wr.pos(ix2, iy2, 0).color(r, g, b, a).endVertex();
            wr.pos(ox2, oy2, 0).color(r, g, b, a).endVertex();
        }
    }

    private static void addColoredVertex(WorldRenderer wr, double x, double y, double z, float red, float green, float blue, float alpha) {
        wr.pos(x, y, z).color(red, green, blue, alpha).endVertex();
    }

    private static void addColoredEdge(WorldRenderer wr, double x1, double y1, double z1, double x2, double y2, double z2, float red, float green, float blue, float alpha) {
        addColoredVertex(wr, x1, y1, z1, red, green, blue, alpha);
        addColoredVertex(wr, x2, y2, z2, red, green, blue, alpha);
    }

    public static float[] resolveTracerColor(String mode, float[] customRgb, int index) {
        if (mode == null || mode.equals("Default"))
            return null;
        if (mode.equals("Rainbow")) {
            float hue = ((System.currentTimeMillis() / 15L) + (index * 40L)) % 360L;
            return hsbToRgb(hue / 360.0f, 1.0f, 1.0f);
        }
        switch(mode) {
            case "Red":
                return new float[] { 1, 0, 0 };
            case "Green":
                return new float[] { 0, 1, 0 };
            case "Blue":
                return new float[] { 0, 0.4f, 1 };
            case "Yellow":
                return new float[] { 1, 1, 0 };
            case "Purple":
                return new float[] { 0.6f, 0.2f, 1 };
            case "Pink":
                return new float[] { 1, 0.4f, 0.7f };
            case "Orange":
                return new float[] { 1, 0.5f, 0 };
            case "White":
                return new float[] { 1, 1, 1 };
            case "Cyan":
                return new float[] { 0, 1, 1 };
            case "Custom":
                return customRgb != null ? customRgb : null;
            default:
                return null;
        }
    }

    public static float[] hsbToRgb(float h, float s, float b) {
        int i = (int) (h * 6.0f);
        float f = h * 6.0f - i;
        float p = b * (1.0f - s);
        float q = b * (1.0f - f * s);
        float t = b * (1.0f - (1.0f - f) * s);
        switch(i % 6) {
            case 0:
                return new float[] { b, t, p };
            case 1:
                return new float[] { q, b, p };
            case 2:
                return new float[] { p, b, t };
            case 3:
                return new float[] { p, q, b };
            case 4:
                return new float[] { t, p, b };
            case 5:
                return new float[] { b, p, q };
            default:
                return new float[] { 1, 1, 1 };
        }
    }
}
