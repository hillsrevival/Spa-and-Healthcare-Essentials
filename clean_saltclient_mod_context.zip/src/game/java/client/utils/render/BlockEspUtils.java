package client.utils.render;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;
import net.lax1dude.eaglercraft.opengl.WorldRenderer;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;
import client.utils.world.WorldUtils;

public final class BlockEspUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private BlockEspUtils() {
    }

    public interface ColorFn {

        void colorOf(int index, int tag, float[] out3);
    }

    public static final class BoxBatch {

        private double[] coords = new double[6 * 64];

        private float[] colors = new float[3 * 64];

        private byte[] tags = new byte[64];

        private int count = 0;

        public void add(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, float r, float g, float b) {
            addTagged(minX, minY, minZ, maxX, maxY, maxZ, (byte) 0, r, g, b);
        }

        public void addTagged(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, byte tag, float r, float g, float b) {
            int n = count;
            if (n == tags.length) {
                int cap = n * 2;
                double[] nc = new double[6 * cap];
                float[] nf = new float[3 * cap];
                byte[] nt = new byte[cap];
                System.arraycopy(coords, 0, nc, 0, 6 * n);
                System.arraycopy(colors, 0, nf, 0, 3 * n);
                System.arraycopy(tags, 0, nt, 0, n);
                coords = nc;
                colors = nf;
                tags = nt;
            }
            int o = n * 6;
            coords[o] = minX;
            coords[o + 1] = minY;
            coords[o + 2] = minZ;
            coords[o + 3] = maxX;
            coords[o + 4] = maxY;
            coords[o + 5] = maxZ;
            int c = n * 3;
            colors[c] = r;
            colors[c + 1] = g;
            colors[c + 2] = b;
            tags[n] = tag;
            count = n + 1;
        }

        public void clear() {
            count = 0;
        }

        public int size() {
            return count;
        }

        public boolean isEmpty() {
            return count == 0;
        }
    }

    public static void drawBatch(BoxBatch batch, float fillAlpha, float outlineAlpha, float lineWidth) {
        if (batch.isEmpty() || (fillAlpha <= 0.0f && outlineAlpha <= 0.0f))
            return;
        double ox = RenderUtils.camX, oy = RenderUtils.camY, oz = RenderUtils.camZ;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        RenderUtils.prepareGL();
        EaglercraftGPU.glLineWidth(lineWidth);
        try {
            if (fillAlpha > 0.0f) {
                wr.begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
                for (int i = 0; i < batch.count; i++) {
                    int o = i * 6;
                    int c = i * 3;
                    emitBoxFaces(wr, batch.coords[o] - ox, batch.coords[o + 1] - oy, batch.coords[o + 2] - oz, batch.coords[o + 3] - ox, batch.coords[o + 4] - oy, batch.coords[o + 5] - oz, batch.colors[c], batch.colors[c + 1], batch.colors[c + 2], fillAlpha);
                }
                tessellator.draw();
            }
            if (outlineAlpha > 0.0f) {
                RenderUtils.enableLineSmooth();
                wr.begin(Tessellator.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
                for (int i = 0; i < batch.count; i++) {
                    int o = i * 6;
                    int c = i * 3;
                    emitBoxEdges(wr, batch.coords[o] - ox, batch.coords[o + 1] - oy, batch.coords[o + 2] - oz, batch.coords[o + 3] - ox, batch.coords[o + 4] - oy, batch.coords[o + 5] - oz, batch.colors[c], batch.colors[c + 1], batch.colors[c + 2], outlineAlpha);
                }
                tessellator.draw();
                RenderUtils.disableLineSmooth();
            }
        } finally {
            RenderUtils.restoreGL();
        }
    }

    public static void drawBatchTracers(BoxBatch batch, ColorFn colorFn, float alpha, float lineWidth) {
        if (batch.isEmpty() || alpha <= 0.0f)
            return;
        double ox = RenderUtils.camX, oy = RenderUtils.camY, oz = RenderUtils.camZ;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        RenderUtils.prepareGL();
        EaglercraftGPU.glLineWidth(lineWidth);
        RenderUtils.enableLineSmooth();
        try {
            wr.begin(Tessellator.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
            for (int i = 0; i < batch.count; i++) {
                int o = i * 6;
                int c = i * 3;
                float r, g, b;
                if (colorFn != null) {
                    colorFn.colorOf(i, batch.tags[i], SCRATCH_COLOR);
                    r = SCRATCH_COLOR[0];
                    g = SCRATCH_COLOR[1];
                    b = SCRATCH_COLOR[2];
                } else {
                    r = batch.colors[c];
                    g = batch.colors[c + 1];
                    b = batch.colors[c + 2];
                }
                double cx = (batch.coords[o] + batch.coords[o + 3]) * 0.5 - ox;
                double cy = (batch.coords[o + 1] + batch.coords[o + 4]) * 0.5 - oy;
                double cz = (batch.coords[o + 2] + batch.coords[o + 5]) * 0.5 - oz;
                wr.pos(0.0, 0.0, 0.0).color(r, g, b, alpha).endVertex();
                wr.pos(cx, cy, cz).color(r, g, b, alpha).endVertex();
            }
            tessellator.draw();
        } finally {
            RenderUtils.disableLineSmooth();
            RenderUtils.restoreGL();
        }
    }

    private static final BoxBatch SCRATCH = new BoxBatch();

    private static final float[] SCRATCH_COLOR = new float[3];

    public static void drawScannerBoxes(BlockScanner scanner, ColorFn colorFn, float fillAlpha, float outlineAlpha, float lineWidth) {
        if (scanner.size() == 0 || (fillAlpha <= 0.0f && outlineAlpha <= 0.0f))
            return;
        SCRATCH.clear();
        final BoxBatch target = SCRATCH;
        scanner.forEachPosition(new PositionVisitor() {

            @Override
            public void visit(int x, int y, int z, int tag) {
                int index = target.size();
                colorFn.colorOf(index, tag, SCRATCH_COLOR);
                target.addTagged(x, y, z, x + 1, y + 1, z + 1, (byte) tag, SCRATCH_COLOR[0], SCRATCH_COLOR[1], SCRATCH_COLOR[2]);
            }
        });
        drawBatch(SCRATCH, fillAlpha, outlineAlpha, lineWidth);
    }

    public static void drawScannerTracers(BlockScanner scanner, ColorFn colorFn, float alpha, float lineWidth) {
        if (scanner.size() == 0 || alpha <= 0.0f)
            return;
        SCRATCH.clear();
        final BoxBatch target = SCRATCH;
        scanner.forEachPosition(new PositionVisitor() {

            @Override
            public void visit(int x, int y, int z, int tag) {
                int index = target.size();
                colorFn.colorOf(index, tag, SCRATCH_COLOR);
                target.addTagged(x, y, z, x + 1, y + 1, z + 1, (byte) tag, SCRATCH_COLOR[0], SCRATCH_COLOR[1], SCRATCH_COLOR[2]);
            }
        });
        drawBatchTracers(SCRATCH, null, alpha, lineWidth);
    }

    public interface Matcher {

        int match(IBlockState state, int x, int y, int z);
    }

    public interface PositionVisitor {

        void visit(int x, int y, int z, int tag);
    }

    public static final class BlockScanner {

        private final Map<Long, ChunkEntry> cache = new HashMap<Long, ChunkEntry>();

        private World lastWorld;

        private int chunksPerTick = 4;

        private int rescanIntervalTicks = 0;

        private int tick = 0;

        public void setChunksPerTick(int n) {
            chunksPerTick = Math.max(1, n);
        }

        public void setRescanIntervalTicks(int n) {
            rescanIntervalTicks = n;
        }

        public void clear() {
            cache.clear();
        }

        public int size() {
            int total = 0;
            for (ChunkEntry entry : cache.values()) {
                total += entry.count;
            }
            return total;
        }

        public void update(int centerCX, int centerCZ, int radiusChunks, int yMin, int yMax, Matcher matcher) {
            if (mc.world == null) {
                if (!cache.isEmpty())
                    cache.clear();
                lastWorld = null;
                return;
            }
            if (mc.world != lastWorld) {
                cache.clear();
                lastWorld = mc.world;
            }
            tick++;
            pruneCache(cache, centerCX, centerCZ, radiusChunks);
            int scanned = 0;
            for (int ring = 0; ring <= radiusChunks; ring++) {
                for (int dx = -ring; dx <= ring; dx++) {
                    for (int dz = -ring; dz <= ring; dz++) {
                        if (Math.max(Math.abs(dx), Math.abs(dz)) != ring)
                            continue;
                        int cx = centerCX + dx;
                        int cz = centerCZ + dz;
                        long key = chunkKey(cx, cz);
                        ChunkEntry existing = cache.get(key);
                        if (existing != null && (rescanIntervalTicks <= 0 || tick - existing.scannedTick < rescanIntervalTicks)) {
                            continue;
                        }
                        Chunk chunk = WorldUtils.getChunk(cx, cz);
                        if (chunk == null)
                            continue;
                        ChunkEntry fresh = scanChunk(chunk, cx, cz, yMin, yMax, matcher);
                        fresh.scannedTick = tick;
                        cache.put(key, fresh);
                        if (++scanned >= chunksPerTick)
                            return;
                    }
                }
            }
        }

        public void forEachPosition(PositionVisitor visitor) {
            for (ChunkEntry entry : cache.values()) {
                for (int i = 0; i < entry.count; i++) {
                    long p = entry.positions[i];
                    visitor.visit(unpackX(p), unpackY(p), unpackZ(p), entry.tags[i]);
                }
            }
        }

        private ChunkEntry scanChunk(Chunk chunk, int cx, int cz, int yMin, int yMax, Matcher matcher) {
            ChunkEntry entry = new ChunkEntry();
            ExtendedBlockStorage[] storages = chunk.getBlockStorageArray();
            int baseX = cx << 4;
            int baseZ = cz << 4;
            for (int s = 0; s < storages.length; s++) {
                ExtendedBlockStorage storage = storages[s];
                if (storage == null || storage.isEmpty())
                    continue;
                int sectionBaseY = storage.getYLocation();
                int localYMin = Math.max(0, yMin - sectionBaseY);
                int localYMax = Math.min(15, yMax - sectionBaseY);
                if (localYMin > localYMax)
                    continue;
                for (int y = localYMin; y <= localYMax; y++) {
                    for (int z = 0; z < 16; z++) {
                        for (int x = 0; x < 16; x++) {
                            IBlockState state = storage.get(x, y, z);
                            int tag = matcher.match(state, baseX + x, sectionBaseY + y, baseZ + z);
                            if (tag > 0) {
                                entry.add(packPos(baseX + x, sectionBaseY + y, baseZ + z), tag);
                            }
                        }
                    }
                }
            }
            return entry;
        }
    }

    private static final class ChunkEntry {

        long[] positions = new long[16];

        byte[] tags = new byte[16];

        int count = 0;

        int scannedTick = 0;

        void add(long packed, int tag) {
            if (count == positions.length) {
                long[] np = new long[positions.length * 2];
                byte[] nt = new byte[tags.length * 2];
                System.arraycopy(positions, 0, np, 0, count);
                System.arraycopy(tags, 0, nt, 0, count);
                positions = np;
                tags = nt;
            }
            positions[count] = packed;
            tags[count] = (byte) tag;
            count++;
        }
    }

    private static void pruneCache(Map<Long, ChunkEntry> cache, int centerCX, int centerCZ, int radiusChunks) {
        java.util.Iterator<Map.Entry<Long, ChunkEntry>> it = cache.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Long, ChunkEntry> e = it.next();
            long key = e.getKey();
            int cx = (int) (key >> 32);
            int cz = (int) key;
            boolean inRange = Math.abs(cx - centerCX) <= radiusChunks + 1 && Math.abs(cz - centerCZ) <= radiusChunks + 1;
            if (!inRange || WorldUtils.getChunk(cx, cz) == null) {
                it.remove();
            }
        }
    }

    private static long chunkKey(int cx, int cz) {
        return ((long) cx << 32) | ((long) cz & 0xFFFFFFFFL);
    }

    private static long packPos(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (long) (y & 0xFFF);
    }

    private static int unpackX(long packed) {
        return (int) (packed >> 38);
    }

    private static int unpackY(long packed) {
        return (int) (packed << 52 >> 52);
    }

    private static int unpackZ(long packed) {
        return (int) (packed << 26 >> 38);
    }

    private static void emitBoxFaces(WorldRenderer wr, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, float r, float g, float b, float a) {
        wr.pos(minX, minY, minZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, minY, minZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, minY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(minX, minY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(minX, maxY, minZ).color(r, g, b, a).endVertex();
        wr.pos(minX, maxY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, maxY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, maxY, minZ).color(r, g, b, a).endVertex();
        wr.pos(minX, minY, minZ).color(r, g, b, a).endVertex();
        wr.pos(minX, maxY, minZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, maxY, minZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, minY, minZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, minY, minZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, maxY, minZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, maxY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, minY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(minX, minY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, minY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, maxY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(minX, maxY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(minX, minY, minZ).color(r, g, b, a).endVertex();
        wr.pos(minX, minY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(minX, maxY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(minX, maxY, minZ).color(r, g, b, a).endVertex();
    }

    private static void emitBoxEdges(WorldRenderer wr, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, float r, float g, float b, float a) {
        edge(wr, minX, minY, minZ, maxX, minY, minZ, r, g, b, a);
        edge(wr, maxX, minY, minZ, maxX, minY, maxZ, r, g, b, a);
        edge(wr, maxX, minY, maxZ, minX, minY, maxZ, r, g, b, a);
        edge(wr, minX, minY, maxZ, minX, minY, minZ, r, g, b, a);
        edge(wr, minX, minY, minZ, minX, maxY, minZ, r, g, b, a);
        edge(wr, maxX, minY, minZ, maxX, maxY, minZ, r, g, b, a);
        edge(wr, maxX, minY, maxZ, maxX, maxY, maxZ, r, g, b, a);
        edge(wr, minX, minY, maxZ, minX, maxY, maxZ, r, g, b, a);
        edge(wr, minX, maxY, minZ, maxX, maxY, minZ, r, g, b, a);
        edge(wr, maxX, maxY, minZ, maxX, maxY, maxZ, r, g, b, a);
        edge(wr, maxX, maxY, maxZ, minX, maxY, maxZ, r, g, b, a);
        edge(wr, minX, maxY, maxZ, minX, maxY, minZ, r, g, b, a);
    }

    private static void edge(WorldRenderer wr, double x1, double y1, double z1, double x2, double y2, double z2, float r, float g, float b, float a) {
        wr.pos(x1, y1, z1).color(r, g, b, a).endVertex();
        wr.pos(x2, y2, z2).color(r, g, b, a).endVertex();
    }
}
