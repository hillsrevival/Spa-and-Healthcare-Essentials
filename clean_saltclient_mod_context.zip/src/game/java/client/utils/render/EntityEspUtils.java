package client.utils.render;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.lax1dude.eaglercraft.opengl.WorldRenderer;
import net.lax1dude.eaglercraft.opengl.EaglercraftGPU;

public final class EntityEspUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final float[] SCRATCH_COLOR = new float[3];

    private EntityEspUtils() {
    }

    public interface EntityColorFn {

        void colorOf(Entity entity, int index, float[] out3);
    }

    public interface EntityBoxAdjuster {

        void adjust(Entity entity, double[] box6);
    }

    public static void interpPos(Entity e, float partialTicks, double[] out) {
        out[0] = e.prevPosX + (e.posX - e.prevPosX) * partialTicks - RenderUtils.camX;
        out[1] = e.prevPosY + (e.posY - e.prevPosY) * partialTicks - RenderUtils.camY;
        out[2] = e.prevPosZ + (e.posZ - e.prevPosZ) * partialTicks - RenderUtils.camZ;
    }

    public static void drawEntityBoxes(List<? extends Entity> entities, float partialTicks, EntityColorFn colorFn, float fillAlpha, float outlineAlpha, double grow, EntityBoxAdjuster adjuster, float lineWidth) {
        if (entities.isEmpty() || (fillAlpha <= 0.0f && outlineAlpha <= 0.0f))
            return;
        if (mc.player == null)
            return;
        double ox = RenderUtils.camX, oy = RenderUtils.camY, oz = RenderUtils.camZ;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        double[] box = BOX_SCRATCH;
        RenderUtils.prepareGL();
        EaglercraftGPU.glLineWidth(lineWidth);
        try {
            if (fillAlpha > 0.0f) {
                wr.begin(Tessellator.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
                for (int i = 0; i < entities.size(); i++) {
                    Entity e = entities.get(i);
                    computeBox(e, partialTicks, grow, box, adjuster, ox, oy, oz);
                    colorFn.colorOf(e, i, SCRATCH_COLOR);
                    emitFaces(wr, box[0], box[1], box[2], box[3], box[4], box[5], SCRATCH_COLOR[0], SCRATCH_COLOR[1], SCRATCH_COLOR[2], fillAlpha);
                }
                tessellator.draw();
            }
            if (outlineAlpha > 0.0f) {
                RenderUtils.enableLineSmooth();
                wr.begin(Tessellator.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
                for (int i = 0; i < entities.size(); i++) {
                    Entity e = entities.get(i);
                    computeBox(e, partialTicks, grow, box, adjuster, ox, oy, oz);
                    colorFn.colorOf(e, i, SCRATCH_COLOR);
                    emitEdges(wr, box[0], box[1], box[2], box[3], box[4], box[5], SCRATCH_COLOR[0], SCRATCH_COLOR[1], SCRATCH_COLOR[2], outlineAlpha);
                }
                tessellator.draw();
                RenderUtils.disableLineSmooth();
            }
        } finally {
            RenderUtils.restoreGL();
        }
    }

    public static void drawEntityTracers(List<? extends Entity> entities, float partialTicks, EntityColorFn colorFn, float alpha, double heightFactor, float lineWidth) {
        if (entities.isEmpty() || alpha <= 0.0f)
            return;
        if (mc.player == null)
            return;
        double ox = RenderUtils.camX, oy = RenderUtils.camY, oz = RenderUtils.camZ;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        RenderUtils.prepareGL();
        EaglercraftGPU.glLineWidth(lineWidth);
        RenderUtils.enableLineSmooth();
        try {
            wr.begin(Tessellator.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
            for (int i = 0; i < entities.size(); i++) {
                Entity e = entities.get(i);
                double x = e.prevPosX + (e.posX - e.prevPosX) * partialTicks - ox;
                double y = e.prevPosY + (e.posY - e.prevPosY) * partialTicks - oy;
                double z = e.prevPosZ + (e.posZ - e.prevPosZ) * partialTicks - oz;
                double endY = y + e.height * heightFactor;
                colorFn.colorOf(e, i, SCRATCH_COLOR);
                wr.pos(0.0, 0.0, 0.0).color(SCRATCH_COLOR[0], SCRATCH_COLOR[1], SCRATCH_COLOR[2], alpha).endVertex();
                wr.pos(x, endY, z).color(SCRATCH_COLOR[0], SCRATCH_COLOR[1], SCRATCH_COLOR[2], alpha).endVertex();
            }
            tessellator.draw();
        } finally {
            RenderUtils.disableLineSmooth();
            RenderUtils.restoreGL();
        }
    }

    public static void distanceColor(Entity entity, double maxDist, float[] out3) {
        double dist = mc.player.getDistanceToEntity(entity);
        float p = (float) Math.min(dist / maxDist, 1.0);
        out3[0] = 1.0f - p;
        out3[1] = p;
        out3[2] = 0.0f;
    }

    private static final double[] BOX_SCRATCH = new double[6];

    private static void computeBox(Entity e, float partialTicks, double grow, double[] box, EntityBoxAdjuster adjuster, double ox, double oy, double oz) {
        double x = e.prevPosX + (e.posX - e.prevPosX) * partialTicks - ox;
        double y = e.prevPosY + (e.posY - e.prevPosY) * partialTicks - oy;
        double z = e.prevPosZ + (e.posZ - e.prevPosZ) * partialTicks - oz;
        double hw = e.width / 2.0 + grow;
        box[0] = x - hw;
        box[1] = y;
        box[2] = z - hw;
        box[3] = x + hw;
        box[4] = y + e.height + grow;
        box[5] = z + hw;
        if (adjuster != null) {
            adjuster.adjust(e, box);
        }
    }

    private static void emitFaces(WorldRenderer wr, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, float r, float g, float b, float a) {
        wr.pos(minX, minY, minZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, minY, minZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, minY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(minX, minY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(minX, maxY, minZ).color(r, g, b, a).endVertex();
        wr.pos(minX, maxY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, maxY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, maxY, minZ).color(r, g, b, a).endVertex();
        wr.pos(minX, minY, minZ).color(r, g, b, a).endVertex();
        wr.pos(minX, maxY, minZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, maxY, minZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, minY, minZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, minY, minZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, maxY, minZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, maxY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, minY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(minX, minY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, minY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(maxX, maxY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(minX, maxY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(minX, minY, minZ).color(r, g, b, a).endVertex();
        wr.pos(minX, minY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(minX, maxY, maxZ).color(r, g, b, a).endVertex();
        wr.pos(minX, maxY, minZ).color(r, g, b, a).endVertex();
    }

    private static void emitEdges(WorldRenderer wr, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, float r, float g, float b, float a) {
        edge(wr, minX, minY, minZ, maxX, minY, minZ, r, g, b, a);
        edge(wr, maxX, minY, minZ, maxX, minY, maxZ, r, g, b, a);
        edge(wr, maxX, minY, maxZ, minX, minY, maxZ, r, g, b, a);
        edge(wr, minX, minY, maxZ, minX, minY, minZ, r, g, b, a);
        edge(wr, minX, minY, minZ, minX, maxY, minZ, r, g, b, a);
        edge(wr, maxX, minY, minZ, maxX, maxY, minZ, r, g, b, a);
        edge(wr, maxX, minY, maxZ, maxX, maxY, maxZ, r, g, b, a);
        edge(wr, minX, minY, maxZ, minX, maxY, maxZ, r, g, b, a);
        edge(wr, minX, maxY, minZ, maxX, maxY, minZ, r, g, b, a);
        edge(wr, maxX, maxY, minZ, maxX, maxY, maxZ, r, g, b, a);
        edge(wr, maxX, maxY, maxZ, minX, maxY, maxZ, r, g, b, a);
        edge(wr, minX, maxY, maxZ, minX, maxY, minZ, r, g, b, a);
    }

    private static void edge(WorldRenderer wr, double x1, double y1, double z1, double x2, double y2, double z2, float r, float g, float b, float a) {
        wr.pos(x1, y1, z1).color(r, g, b, a).endVertex();
        wr.pos(x2, y2, z2).color(r, g, b, a).endVertex();
    }
}
