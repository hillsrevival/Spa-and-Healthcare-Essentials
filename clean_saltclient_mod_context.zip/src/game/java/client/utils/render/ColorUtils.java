package client.utils.render;

public final class ColorUtils {

    private ColorUtils() {
    }

    public static float red(int argb) {
        return ((argb >> 16) & 0xFF) / 255.0f;
    }

    public static float green(int argb) {
        return ((argb >> 8) & 0xFF) / 255.0f;
    }

    public static float blue(int argb) {
        return (argb & 0xFF) / 255.0f;
    }

    public static float alpha(int argb) {
        return ((argb >> 24) & 0xFF) / 255.0f;
    }

    public static int toARGB(float r, float g, float b, float a) {
        int ai = clampColor(a);
        int ri = clampColor(r);
        int gi = clampColor(g);
        int bi = clampColor(b);
        return (ai << 24) | (ri << 16) | (gi << 8) | bi;
    }

    public static int toARGB(int r, int g, int b, int a) {
        return (clampColor(a) << 24) | (clampColor(r) << 16) | (clampColor(g) << 8) | clampColor(b);
    }

    public static int toRGB(float r, float g, float b) {
        return toARGB(r, g, b, 1.0f);
    }

    public static int withAlpha(int argb, float newAlpha) {
        return (clampColor(newAlpha) << 24) | (argb & 0x00FFFFFF);
    }

    public static int withAlpha(int argb, int newAlpha) {
        return (clampColor(newAlpha) << 24) | (argb & 0x00FFFFFF);
    }

    public static int scaleAlpha(int argb, float factor) {
        float current = alpha(argb);
        return withAlpha(argb, current * factor);
    }

    public static int rainbow(float offset, float speed, float alpha) {
        float hue = ((offset * speed) % 360.0f + 360.0f) % 360.0f;
        float[] hsb = hsbToRgb(hue, 1.0f, 1.0f);
        return toARGB(hsb[0], hsb[1], hsb[2], alpha);
    }

    public static int rainbow(float offset, float speed) {
        return rainbow(offset, speed, 1.0f);
    }

    public static int rainbowWithSpeed(float offsetDeg, long cycleMs) {
        return rainbowWithSpeed(offsetDeg, cycleMs, 1.0f);
    }

    public static int rainbowWithSpeed(float offsetDeg, long cycleMs, float alpha) {
        float hue = hueNow(offsetDeg, cycleMs);
        float[] hsb = hsbToRgb(hue, 1.0f, 1.0f);
        return toARGB(hsb[0], hsb[1], hsb[2], alpha);
    }

    public static float[] rainbowWithSpeedRgb(float offsetDeg, long cycleMs) {
        float hue = hueNow(offsetDeg, cycleMs);
        return hsbToRgb(hue, 1.0f, 1.0f);
    }

    private static float hueNow(float offsetDeg, long cycleMs) {
        if (cycleMs <= 0)
            cycleMs = 1;
        float hue = (System.currentTimeMillis() % cycleMs) / (float) cycleMs * 360.0f + offsetDeg;
        return ((hue % 360.0f) + 360.0f) % 360.0f;
    }

    private static int clampColor(float value) {
        int i = (int) (value * 255.0f);
        if (i < 0)
            return 0;
        if (i > 255)
            return 255;
        return i;
    }

    private static int clampColor(int value) {
        if (value < 0)
            return 0;
        if (value > 255)
            return 255;
        return value;
    }

    private static float[] hsbToRgb(float hue, float saturation, float brightness) {
        float h = (hue % 360.0f) / 60.0f;
        float s = saturation;
        float b = brightness;
        float c = b * s;
        float x = c * (1.0f - Math.abs(h % 2.0f - 1.0f));
        float m = b - c;
        float r, g, bl;
        if (h < 1.0f) {
            r = c;
            g = x;
            bl = 0;
        } else if (h < 2.0f) {
            r = x;
            g = c;
            bl = 0;
        } else if (h < 3.0f) {
            r = 0;
            g = c;
            bl = x;
        } else if (h < 4.0f) {
            r = 0;
            g = x;
            bl = c;
        } else if (h < 5.0f) {
            r = x;
            g = 0;
            bl = c;
        } else {
            r = c;
            g = 0;
            bl = x;
        }
        return new float[] { r + m, g + m, bl + m };
    }
}
