package client.utils.render;

import net.lax1dude.eaglercraft.opengl.GlStateManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import java.util.LinkedHashMap;
import java.util.Map;

public final class ClientFontRenderer {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final int MAX_CACHE = 1024;

    private static final LinkedHashMap<String, Integer> widthCache = new LinkedHashMap<String, Integer>(MAX_CACHE, 0.75f, true) {

        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Integer> eldest) {
            return size() > MAX_CACHE;
        }
    };

    private ClientFontRenderer() {
    }

    public static FontRenderer getFontRenderer() {
        return mc.fontRendererObj;
    }

    private static FontRenderer fr() {
        return mc.fontRendererObj;
    }

    public static int fontHeight() {
        return fr().FONT_HEIGHT;
    }

    public static int getStringWidth(String text) {
        if (text == null)
            return 0;
        Integer cached = widthCache.get(text);
        if (cached != null)
            return cached;
        int width = fr().getStringWidth(text);
        widthCache.put(text, width);
        return width;
    }

    public static float getScaledStringWidth(String text, float scale) {
        return getStringWidth(text) * scale;
    }

    public static void clearCache() {
        widthCache.clear();
    }

    public static int drawStringWithShadow(String text, float x, float y, int color) {
        return fr().drawStringWithShadow(text, x, y, color);
    }

    public static int drawString(String text, float x, float y, int color) {
        return fr().drawString(text, (int) x, (int) y, color);
    }

    public static int drawString(String text, float x, float y, int color, boolean shadow) {
        if (shadow) {
            return fr().drawStringWithShadow(text, x, y, color);
        } else {
            return fr().drawString(text, (int) x, (int) y, color);
        }
    }

    public static int drawCenteredStringWithShadow(String text, float x, float y, int color) {
        return fr().drawStringWithShadow(text, x - getStringWidth(text) / 2.0f, y, color);
    }

    public static int drawCenteredString(String text, float x, float y, int color) {
        return fr().drawString(text, (int) (x - getStringWidth(text) / 2.0f), (int) y, color);
    }

    public static int drawCenteredString(String text, float x, float y, int color, boolean shadow) {
        if (shadow) {
            return drawCenteredStringWithShadow(text, x, y, color);
        } else {
            return drawCenteredString(text, x, y, color);
        }
    }

    public static int drawRightAlignedStringWithShadow(String text, float rightX, float y, int color) {
        return fr().drawStringWithShadow(text, rightX - getStringWidth(text), y, color);
    }

    public static int drawRightAlignedString(String text, float rightX, float y, int color) {
        return fr().drawString(text, (int) (rightX - getStringWidth(text)), (int) y, color);
    }

    public static int drawScaledString(String text, float x, float y, int color, float scale, boolean shadow) {
        if (text == null || text.isEmpty())
            return (int) x;
        if (scale <= 0.0f)
            return (int) x;
        if (Math.abs(scale - 1.0f) < 0.001f) {
            return drawString(text, x, y, color, shadow);
        }
        GlStateManager.pushMatrix();
        GlStateManager.scale(scale, scale, scale);
        int result;
        if (shadow) {
            result = fr().drawStringWithShadow(text, x, y, color);
        } else {
            result = fr().drawString(text, (int) x, (int) y, color);
        }
        GlStateManager.popMatrix();
        return result;
    }

    public static int drawScaledCenteredString(String text, float x, float y, int color, float scale, boolean shadow) {
        if (text == null || text.isEmpty())
            return (int) x;
        if (scale <= 0.0f)
            return (int) x;
        if (Math.abs(scale - 1.0f) < 0.001f) {
            return drawCenteredString(text, x, y, color, shadow);
        }
        float halfWidth = getStringWidth(text) / 2.0f;
        GlStateManager.pushMatrix();
        GlStateManager.scale(scale, scale, scale);
        int result;
        if (shadow) {
            result = fr().drawStringWithShadow(text, x - halfWidth, y, color);
        } else {
            result = fr().drawString(text, (int) (x - halfWidth), (int) y, color);
        }
        GlStateManager.popMatrix();
        return result;
    }

    public static int drawSpacedString(String text, float x, float y, int color, float spacing, boolean shadow) {
        if (text == null || text.isEmpty())
            return (int) x;
        if (spacing == 0.0f) {
            return drawString(text, x, y, color, shadow);
        }
        FontRenderer f = fr();
        float posX = x;
        for (int i = 0; i < text.length(); ) {
            char c = text.charAt(i);
            if (c == '\u00A7' && i + 1 < text.length()) {
                char code = text.charAt(i + 1);
                String formatPair = "\u00A7" + code;
                int charWidth = f.getCharWidth(code);
                if (shadow) {
                    f.drawStringWithShadow(formatPair, posX, y, color);
                } else {
                    f.drawString(formatPair, (int) posX, (int) y, color);
                }
                i += 2;
                continue;
            }
            String ch = String.valueOf(c);
            if (shadow) {
                f.drawStringWithShadow(ch, posX, y, color);
            } else {
                f.drawString(ch, (int) posX, (int) y, color);
            }
            posX += f.getCharWidth(c) + spacing;
            i++;
        }
        return (int) posX;
    }

    public static int getSpacedStringWidth(String text, float spacing) {
        if (text == null || text.isEmpty())
            return 0;
        if (spacing == 0.0f)
            return getStringWidth(text);
        FontRenderer f = fr();
        int width = 0;
        int visibleChars = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\u00A7' && i + 1 < text.length()) {
                i++;
                continue;
            }
            width += f.getCharWidth(c);
            visibleChars++;
        }
        if (visibleChars > 1) {
            width += (int) (spacing * (visibleChars - 1));
        }
        return width;
    }

    public static int drawStringWithCustomShadow(String text, float x, float y, int color, int shadowColor, float shadowOffsetX, float shadowOffsetY) {
        if (text == null || text.isEmpty())
            return (int) x;
        FontRenderer f = fr();
        f.drawString(text, (int) (x + shadowOffsetX), (int) (y + shadowOffsetY), shadowColor);
        return f.drawString(text, (int) x, (int) y, color);
    }

    public static int drawStringWithCustomShadowAlpha(String text, float x, float y, int color, int shadowAlpha, float shadowOffsetX, float shadowOffsetY) {
        if (text == null || text.isEmpty())
            return (int) x;
        int rgb = color & 0x00FFFFFF;
        int shadowColor = (shadowAlpha << 24) | rgb;
        return drawStringWithCustomShadow(text, x, y, color, shadowColor, shadowOffsetX, shadowOffsetY);
    }

    public static String trimStringToWidth(String text, int maxWidth) {
        if (text == null)
            return "";
        if (getStringWidth(text) <= maxWidth)
            return text;
        FontRenderer f = fr();
        String trimmed = f.trimStringToWidth(text, maxWidth);
        if (trimmed.length() >= 3) {
            String withEllipsis = trimmed.substring(0, trimmed.length() - 3) + "...";
            if (getStringWidth(withEllipsis) <= maxWidth) {
                return withEllipsis;
            }
        }
        return trimmed;
    }

    public static int drawGradientString(String text, float x, float y, int leftColor, int rightColor, boolean shadow) {
        if (text == null || text.isEmpty())
            return (int) x;
        FontRenderer f = fr();
        int totalWidth = getStringWidth(text);
        if (totalWidth == 0)
            return (int) x;
        float posX = x;
        int lA = (leftColor >> 24) & 0xFF;
        int lR = (leftColor >> 16) & 0xFF;
        int lG = (leftColor >> 8) & 0xFF;
        int lB = leftColor & 0xFF;
        int rA = (rightColor >> 24) & 0xFF;
        int rR = (rightColor >> 16) & 0xFF;
        int rG = (rightColor >> 8) & 0xFF;
        int rB = rightColor & 0xFF;
        for (int i = 0; i < text.length(); ) {
            char c = text.charAt(i);
            if (c == '\u00A7' && i + 1 < text.length()) {
                char code = text.charAt(i + 1);
                String pair = "\u00A7" + code;
                if (shadow) {
                    f.drawStringWithShadow(pair, posX, y, leftColor);
                } else {
                    f.drawString(pair, (int) posX, (int) y, leftColor);
                }
                i += 2;
                continue;
            }
            float t = totalWidth > 0 ? (posX - x) / totalWidth : 0.0f;
            t = Math.max(0.0f, Math.min(1.0f, t));
            int a = (int) (lA + (rA - lA) * t);
            int r = (int) (lR + (rR - lR) * t);
            int g = (int) (lG + (rG - lG) * t);
            int b = (int) (lB + (rB - lB) * t);
            int color = (a << 24) | (r << 16) | (g << 8) | b;
            String ch = String.valueOf(c);
            if (shadow) {
                f.drawStringWithShadow(ch, posX, y, color);
            } else {
                f.drawString(ch, (int) posX, (int) y, color);
            }
            posX += f.getCharWidth(c);
            i++;
        }
        return (int) posX;
    }

    public static int drawCenteredGradientString(String text, float x, float y, int leftColor, int rightColor, boolean shadow) {
        return drawGradientString(text, x - getStringWidth(text) / 2.0f, y, leftColor, rightColor, shadow);
    }

    public static int drawStringWithGlow(String text, float x, float y, int color, int glowAlpha, int glowRadius) {
        if (text == null || text.isEmpty())
            return (int) x;
        FontRenderer f = fr();
        int rgb = color & 0x00FFFFFF;
        for (int r = glowRadius; r >= 1; r--) {
            int a = (glowAlpha * r) / (glowRadius * 2);
            int glowColor = (a << 24) | rgb;
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    if (dx * dx + dy * dy <= r * r) {
                        f.drawString(text, (int) (x + dx), (int) (y + dy), glowColor);
                    }
                }
            }
        }
        return f.drawStringWithShadow(text, x, y, color);
    }
}
