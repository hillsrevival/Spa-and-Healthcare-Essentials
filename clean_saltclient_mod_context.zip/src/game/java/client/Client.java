package client;

import client.config.ConfigManager;
import client.config.ConfigIO;
import client.config.ProfileManager;
import client.event.EventBus;
import client.utils.misc.PlayerCounter;
import net.lax1dude.eaglercraft.EagRuntime;
import net.lax1dude.eaglercraft.Keyboard;

public class Client {

    public static final Client INSTANCE = new Client();

    private final EventBus eventBus = new EventBus();

    private final ConfigManager configManager = new ConfigManager();

    private final ProfileManager profileManager = new ProfileManager();

    private boolean loading = false;

    public boolean freecamActive = false;

    public boolean renderRotationOverride = false;

    public float renderYaw = 0.0F;

    public float renderPitch = 0.0F;

    public float scaffoldYaw = 0.0F;

    public float scaffoldPitch = 0.0F;

    public boolean physicsConsistentAim = false;

    private int guiKey = Keyboard.KEY_RSHIFT;

    private boolean autoWss = true;

    private static final String GUI_KEY_FILE = "gui_key";

    private static final String AUTO_WSS_FILE = "auto_wss";

    public EventBus getEventBus() {
        return eventBus;
    }

    public static EventBus bus() {
        return INSTANCE.eventBus;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public ProfileManager getProfileManager() {
        return profileManager;
    }

    public boolean isLoading() {
        return loading;
    }

    public void setLoading(boolean loading) {
        this.loading = loading;
    }

    public int getGuiKey() {
        return guiKey;
    }

    public void setGuiKey(int key) {
        guiKey = key;
        configManager.getJsonConfig().saveNow();
    }

    public boolean isAutoWss() {
        return autoWss;
    }

    public void setAutoWss(boolean v) {
        autoWss = v;
        configManager.getJsonConfig().saveNow();
    }

    public void toggleAutoWss() {
        setAutoWss(!autoWss);
    }

    public void loadConfig() {
        loading = true;
        configManager.loadAll();
        loading = false;
        try {
            if (!client.config.ConfigIO.exists("mig_godbridge")) {
                client.module.Module scaffold = client.module.ModuleManager.getModuleByName("Scaffold");
                if (scaffold != null) {
                    client.module.Setting<?> modeSetting = scaffold.getSettingByName("Mode");
                    if (modeSetting instanceof client.module.ModeSetting) {
                        client.module.ModeSetting ms = (client.module.ModeSetting) modeSetting;
                        if ("TellyBridge".equals(ms.getValue())) {
                            ms.setMode("GodBridge");
                        }
                    }
                }
                client.config.ConfigIO.write("mig_godbridge", new byte[] { 1 });
            }
        } catch (Throwable t) {
            System.err.println("[Client] godbridge migration: " + t);
        }
        saveConfig();
        // SaltClient: external player-count ping disabled
    }

    private int saveScheduled = 0;

    public void saveConfig() {
        if (loading)
            return;
        saveScheduled = 2;
    }

    private void saveConfigNow() {
        if (loading)
            return;
        configManager.saveAll();
    }

    public void tick() {
        if (saveScheduled > 0) {
            saveScheduled--;
            if (saveScheduled == 0) {
                saveConfigNow();
            }
        }
        configManager.tick();
    }
}
