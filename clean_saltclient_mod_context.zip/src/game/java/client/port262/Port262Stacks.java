package client.port262;

import java.io.IOException;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public final class Port262Stacks {

    private Port262Stacks() {
    }

    public static ItemStack readStack(Port262Buffer buf) throws IOException {
        int count = buf.readVarInt();
        if (count <= 0) {
            return null;
        }
        int itemId = buf.readVarInt();
        skipComponentLists(buf);
        Item item = resolve(itemId);
        if (item == null) {
            return null;
        }
        return new ItemStack(item, Math.min(count, item.getItemStackLimit()), 0);
    }

    public static void skipStack(Port262Buffer buf) throws IOException {
        int count = buf.readVarInt();
        if (count > 0) {
            buf.readVarInt();
            skipComponentLists(buf);
        }
    }

    public static ItemStack itemFor(int itemId, int count) {
        Item item = resolve(itemId);
        if (item == null || count <= 0) {
            return null;
        }
        return new ItemStack(item, Math.min(count, item.getItemStackLimit()), 0);
    }

    public static void skipComponents(Port262Buffer buf, int count) throws IOException {
        for (int i = 0; i < count; i++) {
            skipComponent(buf);
        }
    }

    private static Item resolve(int itemId) {
        String name = Port262ItemMap.name(itemId);
        if (name == null) {
            return null;
        }
        try {
            return Item.getByNameOrId("minecraft:" + name);
        } catch (Throwable t) {
            return null;
        }
    }

    private static void skipComponentLists(Port262Buffer buf) throws IOException {
        int added = buf.readVarInt();
        for (int i = 0; i < added; i++) {
            skipComponent(buf);
        }
        int removed = buf.readVarInt();
        for (int i = 0; i < removed; i++) {
            buf.readVarInt();
        }
    }

    private static void skipComponent(Port262Buffer buf) throws IOException {
        int type = buf.readVarInt();
        switch(type) {
            case 0:
            case 6:
            case 9:
                Port262Nbt.readAnonymous(buf);
                return;
            case 1:
            case 2:
            case 3:
            case 12:
            case 19:
            case 31:
            case 41:
            case 46:
            case 63:
                buf.readVarInt();
                return;
            case 4:
            case 20:
            case 22:
            case 34:
                return;
            case 5:
                buf.readBool();
                buf.readBool();
                buf.readFloat();
                return;
            case 7:
                buf.readFloat();
                return;
            case 10:
            case 27:
            case 35:
            case 71:
                buf.readString(2048);
                return;
            case 11:
                int lore = buf.readVarInt();
                for (int i = 0; i < lore; i++) {
                    Port262Nbt.readAnonymous(buf);
                }
                return;
            case 13:
                int ench = buf.readVarInt();
                for (int i = 0; i < ench; i++) {
                    buf.readVarInt();
                    buf.readVarInt();
                }
                return;
            case 18:
                buf.readBool();
                int hidden = buf.readVarInt();
                for (int i = 0; i < hidden; i++) {
                    buf.readVarInt();
                }
                return;
            case 21:
                buf.readBool();
                return;
            case 29:
                buf.readVarInt();
                buf.readFloat();
                return;
            case 44:
                buf.readFixedInt();
                return;
            case 80:
                int holder = buf.readVarInt();
                if (holder == 0) {
                    buf.readString(2048);
                    buf.readBool();
                    return;
                }
                return;
            default:
                throw new Port262SkipException("unhandled item component type " + type);
        }
    }
}
