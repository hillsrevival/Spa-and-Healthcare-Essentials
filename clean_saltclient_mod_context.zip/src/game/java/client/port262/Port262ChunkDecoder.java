package client.port262;

import java.io.IOException;
import io.netty.buffer.Unpooled;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.network.PacketBuffer;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;

public final class Port262ChunkDecoder {

    private static final int WIRE_SECTIONS = 24;

    private static final int BOTTOM_SECTIONS = 4;

    private Port262ChunkDecoder() {
    }

    public static Chunk decode(byte[] blob, int chunkX, int chunkZ, World world) throws IOException {
        if (world == null) {
            client.tuff.TuffDebugLog.log("[26.2] chunk decode skipped: no world yet (" + chunkX + "," + chunkZ + ")");
            return null;
        }
        PacketBuffer raw = new PacketBuffer(Unpooled.wrappedBuffer(blob));
        Port262Buffer buf = new Port262Buffer(raw);
        ChunkPrimer primer = new ChunkPrimer();
        ExtendedBlockStorage[] bottom = new ExtendedBlockStorage[BOTTOM_SECTIONS];
        ExtendedBlockStorage[] top = new ExtendedBlockStorage[Port262HeightStore.TOP_SECTION_COUNT];
        int section = 0;
        while (buf.readableBytes() > 0 && section < WIRE_SECTIONS) {
            raw.readShort();
            raw.readShort();
            if (section < BOTTOM_SECTIONS) {
                decodeSectionIntoStore(buf, bottom, section, (section - BOTTOM_SECTIONS) << 4, false);
            } else if (section < WIRE_SECTIONS - Port262HeightStore.TOP_SECTION_COUNT) {
                decodeBlockSection(buf, primer, section - BOTTOM_SECTIONS);
            } else {
                decodeSectionIntoStore(buf, top, section - (WIRE_SECTIONS - Port262HeightStore.TOP_SECTION_COUNT), (section - BOTTOM_SECTIONS) << 4, true);
            }
            skipBiomeContainer(buf);
            section++;
        }
        Chunk chunk = new Chunk(world, primer, chunkX, chunkZ);
        chunk.generateSkylightMap();
        Port262HeightStore.attachStores(chunk, bottom, top);
        return chunk;
    }

    private static void decodeSectionIntoStore(Port262Buffer buf, ExtendedBlockStorage[] store, int idx, int yBase, boolean fillSky) throws IOException {
        int bits = buf.readUByte();
        int[] palette = readPalette(buf, bits, 8);
        if (bits == 0) {
            int combined = Port262BlockMap.map(palette[0]);
            if (combined != 0) {
                ExtendedBlockStorage section = Port262HeightStore.createSection(yBase >> 4, true, fillSky);
                IBlockState state = Block.getStateById(combined);
                for (int x = 0; x < 16; x++) {
                    for (int z = 0; z < 16; z++) {
                        for (int y = 0; y < 16; y++) {
                            section.set(x, y, z, state);
                        }
                    }
                }
                store[idx] = section;
            }
            return;
        }
        int entriesPerLong = 64 / bits;
        int longCount = (4096 + entriesPerLong - 1) / entriesPerLong;
        long[] data = new long[longCount];
        for (int i = 0; i < longCount; i++) {
            data[i] = buf.readFixedLong();
        }
        int mask = (1 << bits) - 1;
        boolean any = false;
        IBlockState[] states = new IBlockState[4096];
        for (int i = 0; i < 4096; i++) {
            int value = (int) ((data[i / entriesPerLong] >>> ((i % entriesPerLong) * bits)) & mask);
            int globalId = palette != null ? palette[value] : value;
            int combined = Port262BlockMap.map(globalId);
            if (combined != 0) {
                states[i] = Block.getStateById(combined);
                any = true;
            }
        }
        if (!any) {
            return;
        }
        ExtendedBlockStorage section = Port262HeightStore.createSection(yBase >> 4, true, fillSky);
        for (int i = 0; i < 4096; i++) {
            if (states[i] != null) {
                section.set(i & 15, (i >> 8) & 15, (i >> 4) & 15, states[i]);
            }
        }
        store[idx] = section;
    }

    private static void decodeBlockSection(Port262Buffer buf, ChunkPrimer primer, int sectionY) throws IOException {
        int bits = buf.readUByte();
        int[] palette = readPalette(buf, bits, 8);
        if (bits == 0) {
            int combined = Port262BlockMap.map(palette[0]);
            if (combined != 0) {
                for (int i = 0; i < 4096; i++) {
                    int x = i & 15;
                    int z = (i >> 4) & 15;
                    int y = (i >> 8) & 15;
                    primer.setBlockState(x, (sectionY << 4) | y, z, Block.getStateById(combined));
                }
            }
            return;
        }
        int entriesPerLong = 64 / bits;
        int longCount = (4096 + entriesPerLong - 1) / entriesPerLong;
        long[] data = new long[longCount];
        for (int i = 0; i < longCount; i++) {
            data[i] = buf.readFixedLong();
        }
        int mask = (1 << bits) - 1;
        for (int i = 0; i < 4096; i++) {
            int value = (int) ((data[i / entriesPerLong] >>> ((i % entriesPerLong) * bits)) & mask);
            int globalId = palette != null ? palette[value] : value;
            int combined = Port262BlockMap.map(globalId);
            if (combined != 0) {
                int x = i & 15;
                int z = (i >> 4) & 15;
                int y = (i >> 8) & 15;
                primer.setBlockState(x, (sectionY << 4) | y, z, Block.getStateById(combined));
            }
        }
    }

    private static void skipBiomeContainer(Port262Buffer buf) throws IOException {
        int bits = buf.readUByte();
        int[] palette = readPalette(buf, bits, 6);
        if (bits == 0) {
            return;
        }
        int entriesPerLong = 64 / bits;
        int longCount = (64 + entriesPerLong - 1) / entriesPerLong;
        buf.skipBytes(longCount * 8L);
    }

    private static int[] readPalette(Port262Buffer buf, int bits, int maxIndirectBits) throws IOException {
        if (bits == 0) {
            return new int[] { buf.readVarInt() };
        }
        if (bits <= maxIndirectBits) {
            int n = buf.readVarInt();
            if (n < 0 || n > 65536) {
                throw new IOException("26.2 palette size out of range: " + n);
            }
            int[] palette = new int[n];
            for (int i = 0; i < n; i++) {
                palette[i] = buf.readVarInt();
            }
            return palette;
        }
        return null;
    }
}
