package client.port262;

public final class Port262EffectMap {

    public static final String[] NAMES = { "Speed", "Slowness", "Haste", "MiningFatigue", "Strength", "InstantHealth", "InstantDamage", "JumpBoost", "Nausea", "Regeneration", "Resistance", "FireResistance", "WaterBreathing", "Invisibility", "Blindness", "NightVision", "Hunger", "Weakness", "Poison", "Wither", "HealthBoost", "Absorption", "Saturation", "Glowing", "Levitation", "Luck", "BadLuck", "SlowFalling", "ConduitPower", "DolphinsGrace", "BadOmen", "HeroOfTheVillage", "Darkness", "TrialOmen", "RaidOmen", "WindCharged", "Weaving", "Oozing", "Infested", "BreathOfTheNautilus" };

    private Port262EffectMap() {
    }

    public static String name(int id) {
        if (id < 0 || id >= NAMES.length) {
            return null;
        }
        return NAMES[id];
    }
}
