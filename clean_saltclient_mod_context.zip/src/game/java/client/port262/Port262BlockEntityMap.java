package client.port262;

import java.util.List;
import java.util.Map;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.ResourceLocation;

public final class Port262BlockEntityMap {

    private Port262BlockEntityMap() {
    }

    public static int metadataFor(String modernId) {
        String id = bare(modernId);
        if (id == null) {
            return -1;
        }
        switch(id) {
            case "mob_spawner":
                return 1;
            case "command_block":
            case "chain_command_block":
            case "repeating_command_block":
                return 2;
            case "beacon":
                return 3;
            case "skull":
                return 4;
            case "flower_pot":
                return 5;
            case "banner":
                return 6;
            case "structure_block":
                return 7;
            case "end_gateway":
                return 8;
            case "sign":
            case "hanging_sign":
                return 9;
            case "shulker_box":
                return 10;
            case "bed":
                return 11;
            default:
                return id.endsWith("_shulker_box") ? 10 : -1;
        }
    }

    public static NBTTagCompound rewrite(String modernId, Map<String, Object> nbt, int x, int y, int z) {
        String id = bare(modernId);
        if (id == null) {
            return null;
        }
        String teId = teIdFor(id);
        if (teId == null) {
            return null;
        }
        NBTTagCompound out = new NBTTagCompound();
        out.setString("id", teId);
        out.setInteger("x", x);
        out.setInteger("y", y);
        out.setInteger("z", z);
        try {
            switch(teId) {
                case "minecraft:chest":
                    rewriteContainer(nbt, out);
                    break;
                case "minecraft:furnace":
                    rewriteContainer(nbt, out);
                    break;
                case "minecraft:hopper":
                case "minecraft:dispenser":
                case "minecraft:dropper":
                case "minecraft:brewing_stand":
                    rewriteContainer(nbt, out);
                    break;
                case "minecraft:shulker_box":
                    rewriteContainer(nbt, out);
                    break;
                case "minecraft:sign":
                    rewriteSign(nbt, out);
                    break;
                case "minecraft:mob_spawner":
                    rewriteSpawner(nbt, out);
                    break;
                case "minecraft:skull":
                    rewriteSkull(nbt, out);
                    break;
                case "minecraft:banner":
                    rewriteBanner(nbt, out);
                    break;
                case "minecraft:beacon":
                    rewriteBeacon(nbt, out);
                    break;
                case "minecraft:bed":
                    out.setInteger("color", intOf(nbt.get("color"), 0));
                    break;
                case "minecraft:flower_pot":
                    rewriteFlowerPot(nbt, out);
                    break;
                case "minecraft:end_gateway":
                    rewriteEndGateway(nbt, out);
                    break;
                case "minecraft:command_block":
                case "minecraft:structure_block":
                default:
                    NBTTagCompound pass = Port262NbtOut.writeCompound(nbt);
                    out.merge(pass);
                    break;
            }
        } catch (Throwable t) {
            return null;
        }
        return out;
    }

    private static String teIdFor(String id) {
        switch(id) {
            case "chest":
            case "trapped_chest":
            case "ender_chest":
                return "minecraft:chest";
            case "furnace":
            case "smoker":
            case "blast_furnace":
                return "minecraft:furnace";
            case "hopper":
                return "minecraft:hopper";
            case "dispenser":
                return "minecraft:dispenser";
            case "dropper":
                return "minecraft:dropper";
            case "brewing_stand":
                return "minecraft:brewing_stand";
            case "shulker_box":
            case "barrel":
                return "minecraft:shulker_box";
            case "sign":
            case "hanging_sign":
                return "minecraft:sign";
            case "mob_spawner":
            case "trial_spawner":
                return "minecraft:mob_spawner";
            case "skull":
                return "minecraft:skull";
            case "banner":
            case "wall_banner":
                return "minecraft:banner";
            case "beacon":
                return "minecraft:beacon";
            case "bed":
                return "minecraft:bed";
            case "flower_pot":
                return "minecraft:flower_pot";
            case "end_gateway":
                return "minecraft:end_gateway";
            case "command_block":
            case "chain_command_block":
            case "repeating_command_block":
                return "minecraft:command_block";
            case "structure_block":
                return "minecraft:structure_block";
            default:
                if (id.endsWith("_shulker_box")) {
                    return "minecraft:shulker_box";
                }
                return null;
        }
    }

    private static void rewriteContainer(Map<String, Object> nbt, NBTTagCompound out) {
        List<Object> items = listOf(nbt.get("items"));
        if (items == null) {
            items = listOf(nbt.get("Items"));
        }
        NBTTagList outItems = new NBTTagList();
        if (items != null) {
            for (Object o : items) {
                if (!(o instanceof Map)) {
                    continue;
                }
                Map<String, Object> it = (Map<String, Object>) softCast(o);
                NBTTagCompound tag = rewriteItemStack(it);
                if (tag != null) {
                    outItems.appendTag(tag);
                }
            }
        }
        out.setTag("Items", outItems);
        Object lock = nbt.get("lock");
        if (lock instanceof String) {
            out.setString("Lock", (String) lock);
        }
    }

    @SuppressWarnings("unchecked")
    public static NBTTagCompound rewriteItemStack(Map<String, Object> it) {
        Object slot = it.get("Slot");
        if (!(slot instanceof Byte)) {
            return null;
        }
        String modernName = bare(strOf(it.get("id")));
        Item item = resolveItem(modernName);
        if (item == null) {
            return null;
        }
        ResourceLocation reg = Item.REGISTRY.getNameForObject(item);
        if (reg == null) {
            return null;
        }
        int count = intOf(it.get("count"), 1);
        int damage = 0;
        Object comps = it.get("components");
        if (comps instanceof Map) {
            Object dmg = ((Map<String, Object>) comps).get("minecraft:damage");
            if (dmg instanceof Number) {
                damage = ((Number) dmg).intValue();
            }
        }
        NBTTagCompound tag = new NBTTagCompound();
        tag.setByte("Slot", (Byte) slot);
        tag.setString("id", reg.toString());
        tag.setByte("Count", (byte) Math.min(count, 64));
        tag.setShort("Damage", (short) damage);
        return tag;
    }

    private static Item resolveItem(String name) {
        if (name == null) {
            return null;
        }
        try {
            Item direct = Item.getByNameOrId("minecraft:" + name);
            if (direct != null) {
                return direct;
            }
            String renamed = renameItem(name);
            if (renamed != null) {
                return Item.getByNameOrId("minecraft:" + renamed);
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static String renameItem(String name) {
        switch(name) {
            case "oak_planks":
            case "spruce_planks":
            case "birch_planks":
            case "jungle_planks":
            case "acacia_planks":
            case "dark_oak_planks":
            case "mangrove_planks":
            case "cherry_planks":
            case "bamboo_planks":
            case "crimson_planks":
            case "warped_planks":
                return "planks";
            case "oak_log":
            case "spruce_log":
            case "birch_log":
            case "jungle_log":
            case "acacia_log":
            case "dark_oak_log":
            case "mangrove_log":
            case "cherry_log":
            case "pale_oak_log":
                return "log";
            case "crimson_stem":
            case "warped_stem":
                return "log2";
            case "oak_leaves":
            case "spruce_leaves":
            case "birch_leaves":
            case "jungle_leaves":
            case "acacia_leaves":
            case "dark_oak_leaves":
                return "leaves";
            case "oak_sapling":
            case "spruce_sapling":
            case "birch_sapling":
            case "jungle_sapling":
            case "acacia_sapling":
            case "dark_oak_sapling":
                return "sapling";
            case "grass_block":
                return "grass";
            case "short_grass":
            case "grass":
                return "tallgrass";
            case "stone_bricks":
                return "stonebrick";
            case "oak_slab":
            case "spruce_slab":
            case "birch_slab":
            case "jungle_slab":
            case "acacia_slab":
            case "dark_oak_slab":
                return "wooden_slab";
            case "white_wool":
            case "orange_wool":
            case "magenta_wool":
            case "light_blue_wool":
            case "yellow_wool":
            case "lime_wool":
            case "pink_wool":
            case "gray_wool":
            case "light_gray_wool":
            case "cyan_wool":
            case "purple_wool":
            case "blue_wool":
            case "brown_wool":
            case "green_wool":
            case "red_wool":
            case "black_wool":
                return "wool";
            case "white_carpet":
            case "orange_carpet":
            case "magenta_carpet":
            case "light_blue_carpet":
            case "yellow_carpet":
            case "lime_carpet":
            case "pink_carpet":
            case "gray_carpet":
            case "light_gray_carpet":
            case "cyan_carpet":
            case "purple_carpet":
            case "blue_carpet":
            case "brown_carpet":
            case "green_carpet":
            case "red_carpet":
            case "black_carpet":
                return "carpet";
            default:
                return null;
        }
    }

    private static void rewriteSign(Map<String, Object> nbt, NBTTagCompound out) {
        Map<String, Object> front = compoundOf(nbt.get("front_text"));
        List<Object> messages = null;
        if (front != null) {
            messages = listOf(front.get("messages"));
        }
        if (messages == null) {
            messages = listOf(nbt.get("messages"));
        }
        for (int i = 0; i < 4; i++) {
            String json = "{\"text\":\"\"}";
            Object line = (messages != null && i < messages.size()) ? messages.get(i) : null;
            if (line != null) {
                try {
                    json = net.minecraft.util.text.ITextComponent.Serializer.componentToJson(Port262Text.fromNbt(line));
                } catch (Throwable ignored) {
                }
            }
            out.setString("Text" + (i + 1), json);
        }
    }

    private static void rewriteSpawner(Map<String, Object> nbt, NBTTagCompound out) {
        Map<String, Object> spawnData = compoundOf(nbt.get("spawn_data"));
        if (spawnData == null) {
            spawnData = compoundOf(nbt.get("SpawnData"));
        }
        if (spawnData != null) {
            NBTTagCompound sd = new NBTTagCompound();
            Map<String, Object> entity = compoundOf(spawnData.get("entity"));
            Map<String, Object> src = entity != null ? entity : spawnData;
            String entityId = legacyEntityName(bare(strOf(src.get("id"))));
            if (entityId != null) {
                sd.setString("id", entityId);
            }
            out.setTag("SpawnData", sd);
        }
        List<Object> potentials = listOf(nbt.get("spawn_potentials"));
        if (potentials == null) {
            potentials = listOf(nbt.get("SpawnPotentials"));
        }
        if (potentials != null) {
            NBTTagList outPotentials = new NBTTagList();
            for (Object o : potentials) {
                if (!(o instanceof Map)) {
                    continue;
                }
                Map<String, Object> pot = (Map<String, Object>) softCast(o);
                Map<String, Object> entity = compoundOf(pot.get("entity"));
                if (entity == null) {
                    entity = compoundOf(pot.get("Entity"));
                }
                String entityId = entity != null ? legacyEntityName(bare(strOf(entity.get("id")))) : null;
                if (entityId == null) {
                    continue;
                }
                NBTTagCompound entry = new NBTTagCompound();
                entry.setInteger("Weight", intOf(pot.get("weight"), intOf(pot.get("Weight"), 1)));
                NBTTagCompound ent = new NBTTagCompound();
                ent.setString("id", entityId);
                entry.setTag("Entity", ent);
                outPotentials.appendTag(entry);
            }
            out.setTag("SpawnPotentials", outPotentials);
        }
        out.setShort("Delay", (short) intOf(nbt.get("delay"), 0));
        out.setShort("MinSpawnDelay", (short) intOf(nbt.get("min_delay"), 200));
        out.setShort("MaxSpawnDelay", (short) intOf(nbt.get("max_delay"), 800));
        out.setShort("SpawnCount", (short) intOf(nbt.get("spawn_count"), 4));
        out.setShort("MaxNearbyEntities", (short) intOf(nbt.get("max_nearby_entities"), 6));
        out.setShort("RequiredPlayerRange", (short) intOf(nbt.get("required_player_range"), 16));
        out.setShort("SpawnRange", (short) intOf(nbt.get("spawn_range"), 4));
    }

    private static String legacyEntityName(String id) {
        if (id == null) {
            return null;
        }
        switch(id) {
            case "zombified_piglin":
            case "zombie_pigman":
                return "zombie_pigman";
            case "snow_golem":
                return "snowman";
            case "iron_golem":
                return "villager_golem";
            case "ender_dragon":
                return "dragon";
            default:
                return id;
        }
    }

    private static void rewriteSkull(Map<String, Object> nbt, NBTTagCompound out) {
        Map<String, Object> profile = compoundOf(nbt.get("profile"));
        if (profile != null) {
            NBTTagCompound owner = new NBTTagCompound();
            String name = strOf(profile.get("name"));
            if (name != null) {
                owner.setString("Name", name);
                out.setString("ExtraType", name);
            }
            String uuid = uuidString(profile.get("id"));
            if (uuid != null) {
                owner.setString("Id", uuid);
            }
            Map<String, Object> props = compoundOf(profile.get("properties"));
            if (props != null) {
                NBTTagCompound outProps = new NBTTagCompound();
                List<Object> textures = listOf(props.get("textures"));
                if (textures != null) {
                    NBTTagList texList = new NBTTagList();
                    for (Object o : textures) {
                        if (!(o instanceof Map)) {
                            continue;
                        }
                        Map<String, Object> tex = (Map<String, Object>) softCast(o);
                        NBTTagCompound texTag = new NBTTagCompound();
                        Object value = tex.get("value");
                        if (value instanceof String) {
                            texTag.setString("Value", (String) value);
                        }
                        Object sig = tex.get("signature");
                        if (sig instanceof String) {
                            texTag.setString("Signature", (String) sig);
                        }
                        texList.appendTag(texTag);
                    }
                    outProps.setTag("textures", texList);
                }
                owner.setTag("Properties", outProps);
            }
            out.setTag("Owner", owner);
            out.setByte("SkullType", (byte) 3);
        } else {
            out.setByte("SkullType", (byte) 0);
        }
        out.setByte("Rot", (byte) intOf(nbt.get("rotation"), 0));
    }

    private static String uuidString(Object v) {
        if (v instanceof String) {
            return (String) v;
        }
        if (v instanceof int[] && ((int[]) v).length == 4) {
            int[] a = (int[]) v;
            return String.format("%08x-%04x-%04x-%04x-%012x", (long) a[0], (short) (a[1] >>> 16), (short) (a[1] & 0xFFFF), (short) (a[2] >>> 16), ((long) (a[2] & 0xFFFF) << 32) | (a[3] & 0xFFFFFFFFL));
        }
        return null;
    }

    private static void rewriteBanner(Map<String, Object> nbt, NBTTagCompound out) {
        out.setInteger("Base", 0);
        List<Object> patterns = listOf(nbt.get("patterns"));
        if (patterns == null) {
            patterns = listOf(nbt.get("Patterns"));
        }
        if (patterns != null) {
            NBTTagList outPatterns = new NBTTagList();
            for (Object o : patterns) {
                if (!(o instanceof Map)) {
                    continue;
                }
                Map<String, Object> pat = (Map<String, Object>) softCast(o);
                String code = bannerCode(bare(strOf(pat.get("pattern"))));
                if (code == null) {
                    continue;
                }
                NBTTagCompound entry = new NBTTagCompound();
                entry.setString("Pattern", code);
                entry.setInteger("Color", dyeDamage(bare(strOf(pat.get("color"))), intOf(pat.get("Color"), 0)));
                outPatterns.appendTag(entry);
            }
            out.setTag("Patterns", outPatterns);
        }
        Object name = nbt.get("custom_name");
        if (name instanceof String) {
            out.setString("CustomName", (String) name);
        }
    }

    private static String bannerCode(String name) {
        if (name == null) {
            return null;
        }
        switch(name) {
            case "base":
                return "b";
            case "square_bottom_left":
                return "bl";
            case "square_bottom_right":
                return "br";
            case "square_top_left":
                return "tl";
            case "square_top_right":
                return "tr";
            case "stripe_bottom":
                return "bs";
            case "stripe_top":
                return "ts";
            case "stripes":
                return "cs";
            case "stripe_center":
            case "straight_cross":
                return "sc";
            case "cross":
                return "cr";
            case "diagonal_left":
                return "ld";
            case "diagonal_right":
                return "rd";
            case "diagonal_up_left":
                return "lud";
            case "diagonal_up_right":
                return "rud";
            case "diagonally_left":
            case "diagonal_cross":
                return "dls";
            case "border":
                return "bo";
            case "curly_border":
                return "cbo";
            case "half_horizontal":
                return "hh";
            case "half_horizontal_bottom":
                return "hhb";
            case "half_vertical":
                return "vh";
            case "half_vertical_right":
                return "vhr";
            case "triangle_bottom":
                return "bt";
            case "triangle_top":
                return "tt";
            case "triangles_bottom":
                return "bts";
            case "triangles_top":
                return "tts";
            case "gradient":
                return "gra";
            case "gradient_up":
                return "gru";
            case "bricks":
                return "mc";
            case "globe":
                return "glb";
            case "creeper":
                return "cre";
            case "skull":
                return "sku";
            case "flower":
                return "flo";
            case "mojang":
                return "moj";
            case "piglin":
                return "pig";
            default:
                return null;
        }
    }

    private static int dyeDamage(String name, int fallback) {
        if (name == null) {
            return fallback;
        }
        switch(name) {
            case "white":
                return 0;
            case "orange":
                return 1;
            case "magenta":
                return 2;
            case "light_blue":
                return 3;
            case "yellow":
                return 4;
            case "lime":
                return 5;
            case "pink":
                return 6;
            case "gray":
                return 7;
            case "light_gray":
            case "silver":
                return 8;
            case "cyan":
                return 9;
            case "purple":
                return 10;
            case "blue":
                return 11;
            case "brown":
                return 12;
            case "green":
                return 13;
            case "red":
                return 14;
            case "black":
                return 15;
            default:
                return fallback;
        }
    }

    private static void rewriteBeacon(Map<String, Object> nbt, NBTTagCompound out) {
        out.setInteger("Primary", potionId(nbt.get("primary_effect"), 0));
        out.setInteger("Secondary", potionId(nbt.get("secondary_effect"), 0));
        out.setInteger("Levels", intOf(nbt.get("level"), 0));
    }

    private static int potionId(Object v, int fallback) {
        String name = null;
        if (v instanceof String) {
            name = bare((String) v);
        } else if (v instanceof Map) {
            name = bare(strOf(((Map<?, ?>) v).get("id")));
        }
        if (name == null) {
            return fallback;
        }
        switch(name) {
            case "speed":
                return 1;
            case "haste":
                return 3;
            case "strength":
                return 5;
            case "jump_boost":
                return 8;
            case "regeneration":
                return 10;
            case "resistance":
                return 11;
            default:
                return 0;
        }
    }

    private static void rewriteFlowerPot(Map<String, Object> nbt, NBTTagCompound out) {
        Map<String, Object> item = compoundOf(nbt.get("item"));
        String flower = item != null ? bare(strOf(item.get("id"))) : bare(strOf(nbt.get("item")));
        if (flower != null && resolveItem(flower) != null) {
            out.setString("Item", "minecraft:" + flower);
        }
        out.setInteger("Data", intOf(nbt.get("data"), 0));
    }

    private static void rewriteEndGateway(Map<String, Object> nbt, NBTTagCompound out) {
        out.setLong("Age", longOf(nbt.get("age"), 0L));
        List<Object> exit = listOf(nbt.get("exit_portal"));
        if (exit == null) {
            Map<String, Object> old = compoundOf(nbt.get("ExitPortal"));
            if (old != null) {
                NBTTagCompound portal = new NBTTagCompound();
                portal.setInteger("X", intOf(old.get("X"), 0));
                portal.setInteger("Y", intOf(old.get("Y"), 0));
                portal.setInteger("Z", intOf(old.get("Z"), 0));
                out.setTag("ExitPortal", portal);
            }
        } else if (exit.size() >= 3) {
            NBTTagCompound portal = new NBTTagCompound();
            portal.setInteger("X", intOf(exit.get(0), 0));
            portal.setInteger("Y", intOf(exit.get(1), 0));
            portal.setInteger("Z", intOf(exit.get(2), 0));
            out.setTag("ExitPortal", portal);
        }
        Object exact = nbt.get("exact_teleport");
        if (exact == null) {
            exact = nbt.get("ExactTeleport");
        }
        if (exact instanceof Byte) {
            out.setBoolean("ExactTeleport", (Byte) exact != 0);
        }
    }

    private static String bare(String s) {
        if (s == null) {
            return null;
        }
        int i = s.indexOf(':');
        return i >= 0 && i + 1 < s.length() ? s.substring(i + 1) : s;
    }

    private static String strOf(Object o) {
        return o instanceof String ? (String) o : null;
    }

    private static int intOf(Object o, int fallback) {
        return o instanceof Number ? ((Number) o).intValue() : fallback;
    }

    private static long longOf(Object o, long fallback) {
        return o instanceof Number ? ((Number) o).longValue() : fallback;
    }

    @SuppressWarnings("unchecked")
    private static List<Object> listOf(Object o) {
        return o instanceof List ? (List<Object>) o : null;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> compoundOf(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : null;
    }

    private static <T> T softCast(Object o) {
        @SuppressWarnings("unchecked")
        T t = (T) o;
        return t;
    }
}
