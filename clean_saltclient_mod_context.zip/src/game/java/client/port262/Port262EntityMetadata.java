package client.port262;

import java.io.IOException;
import io.netty.buffer.Unpooled;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.server.SPacketEntityMetadata;
import net.minecraft.util.math.MathHelper;

public final class Port262EntityMetadata {

    private Port262EntityMetadata() {
    }

    public static Packet decode(int entityId, Port262Buffer buf) throws IOException {
        PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(128));
        scratch.writeVarIntToBuffer(entityId);
        while (true) {
            int key = buf.readUByte();
            if (key == 255) {
                break;
            }
            int serializer = buf.readVarInt();
            convert(scratch, key, serializer, buf);
        }
        scratch.writeByte(255);
        SPacketEntityMetadata out = new SPacketEntityMetadata();
        out.readPacketData(scratch);
        return out;
    }

    private static void convert(PacketBuffer out, int key, int serializer, Port262Buffer buf) throws IOException {
        switch(key) {
            case 0:
                if (serializer != 0) {
                    skipValue(serializer, buf);
                    return;
                }
                byte flags = buf.readByte();
                out.writeByte(key);
                out.writeByte(0);
                out.writeByte(flags);
                return;
            case 1:
                if (serializer != 1) {
                    skipValue(serializer, buf);
                    return;
                }
                int air = buf.readVarInt();
                out.writeByte(key);
                out.writeByte(1);
                out.writeVarIntToBuffer(air);
                return;
            case 2:
                if (serializer != 6) {
                    skipValue(serializer, buf);
                    return;
                }
                String name = readOptionalComponentText(buf);
                out.writeByte(key);
                out.writeByte(3);
                out.writeString(name);
                return;
            case 3:
                if (serializer != 8) {
                    skipValue(serializer, buf);
                    return;
                }
                boolean visible = buf.readBool();
                out.writeByte(key);
                out.writeByte(7);
                out.writeBoolean(visible);
                return;
            case 4:
                if (serializer != 8) {
                    skipValue(serializer, buf);
                    return;
                }
                boolean silent = buf.readBool();
                out.writeByte(key);
                out.writeByte(7);
                out.writeBoolean(silent);
                return;
            case 5:
                if (serializer != 8) {
                    skipValue(serializer, buf);
                    return;
                }
                boolean gravity = buf.readBool();
                out.writeByte(key);
                out.writeByte(7);
                out.writeBoolean(gravity);
                return;
            case 8:
                if (serializer == 0) {
                    byte hand = buf.readByte();
                    out.writeByte(6);
                    out.writeByte(0);
                    out.writeByte(hand);
                    return;
                }
                if (serializer == 7) {
                    ItemStackHolder stack = new ItemStackHolder();
                    stack.value = Port262Stacks.readStack(buf);
                    out.writeByte(6);
                    out.writeByte(5);
                    out.writeBoolean(stack.value != null);
                    if (stack.value != null) {
                        out.writeItemStackToBuffer(stack.value);
                    }
                    return;
                }
                skipValue(serializer, buf);
                return;
            case 9:
                if (serializer != 3) {
                    skipValue(serializer, buf);
                    return;
                }
                float health = buf.readFloat();
                out.writeByte(7);
                out.writeByte(2);
                out.writeFloat(MathHelper.clamp(health, 0.0F, 1024.0F));
                return;
            case 10:
                if (serializer != 1) {
                    skipValue(serializer, buf);
                    return;
                }
                int color = buf.readVarInt();
                out.writeByte(8);
                out.writeByte(1);
                out.writeVarIntToBuffer(color);
                return;
            case 11:
                if (serializer != 8) {
                    skipValue(serializer, buf);
                    return;
                }
                boolean ambience = buf.readBool();
                out.writeByte(9);
                out.writeByte(7);
                out.writeBoolean(ambience);
                return;
            case 12:
                if (serializer != 1) {
                    skipValue(serializer, buf);
                    return;
                }
                int arrows = buf.readVarInt();
                out.writeByte(10);
                out.writeByte(1);
                out.writeVarIntToBuffer(arrows);
                return;
            default:
                skipValue(serializer, buf);
                return;
        }
    }

    private static String readOptionalComponentText(Port262Buffer buf) throws IOException {
        if (!buf.readBool()) {
            return "";
        }
        Object node = Port262Nbt.readAnonymous(buf);
        return Port262Text.plainText(node);
    }

    private static void skipValue(int serializer, Port262Buffer buf) throws IOException {
        switch(serializer) {
            case 0:
                buf.readByte();
                return;
            case 1:
            case 12:
            case 14:
            case 15:
            case 19:
            case 20:
            // cat/cow/wolf/frog variants
            case 21:
            // cat/cow/wolf/frog variants
            case 22:
            // cat/cow/wolf/frog variants
            case 23:
            case 24:
            // pig/chicken/zombie_nautilus/sound variants
            case 25:
            // pig/chicken/zombie_nautilus/sound variants
            case 26:
            // pig/chicken/zombie_nautilus/sound variants
            case 27:
            case 28:
            // ... variant ids
            case 29:
            // ... variant ids
            case 30:
            // ... variant ids
            case 31:
            case 32:
            // sniffer/armadillo/copper golem states
            case 35:
            // sniffer/armadillo/copper golem states
            case 36:
            // sniffer/armadillo/copper golem states
            case 37:
            case 38:
            case 42:
                buf.readVarInt();
                return;
            case 2:
                buf.readVarLong();
                return;
            case 3:
                buf.readFloat();
                return;
            case 4:
                buf.readString(65536);
                return;
            case 5:
                Port262Nbt.readAnonymous(buf);
                return;
            case 6:
                if (buf.readBool()) {
                    Port262Nbt.readAnonymous(buf);
                }
                return;
            case 7:
                Port262Stacks.skipStack(buf);
                return;
            case 8:
                buf.readBool();
                return;
            case 9:
                buf.readFloat();
                buf.readFloat();
                buf.readFloat();
                return;
            case 10:
                buf.readPosition();
                return;
            case 11:
                if (buf.readBool()) {
                    buf.readPosition();
                }
                return;
            case 13:
                if (buf.readBool()) {
                    buf.readUuidMsb();
                    buf.readUuidLsb();
                }
                return;
            case 18:
                buf.readVarInt();
                buf.readVarInt();
                buf.readVarInt();
                return;
            case 33:
                if (buf.readBool()) {
                    buf.readString(32767);
                    buf.readPosition();
                }
                return;
            case 39:
                buf.readFloat();
                buf.readFloat();
                buf.readFloat();
                return;
            case 40:
                buf.readFloat();
                buf.readFloat();
                buf.readFloat();
                buf.readFloat();
                return;
            default:
                throw new Port262SkipException("unhandled metadata serializer " + serializer);
        }
    }

    private static final class ItemStackHolder {

        net.minecraft.item.ItemStack value;
    }
}
