package client.port262.packets.config;

import java.io.IOException;
import client.port262.Packet262In;
import client.port262.Packet262Out;
import client.port262.Port262Buffer;
import client.port262.Port262Connection;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.server.SPacketCustomPayload;
import net.minecraft.network.play.server.SPacketDisconnect;
import net.minecraft.util.text.TextComponentString;

public final class Config262Packets {

    private Config262Packets() {
    }

    public static class SKeepAlive extends Packet262In {

        public static final int ID = 0x04;

        public long id;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            id = buf.readFixedLong();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            conn.sendOut(new CKeepAlive(id));
            return null;
        }
    }

    public static class SPing extends Packet262In {

        public static final int ID = 0x05;

        public int id;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            id = buf.readFixedInt();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            conn.sendOut(new CPong(id));
            return null;
        }
    }

    public static class SCustomPayload extends Packet262In {

        public static final int ID = 0x01;

        public String channel;

        public byte[] data;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            channel = buf.readString(256);
            data = buf.readRestBuffer();
        }

        @Override
        public Packet process(Port262Connection conn) {
            if ("minecraft:brand".equals(channel) && data.length >= 2) {
                int len = ((data[0] & 0xFF) << 8) | (data[1] & 0xFF);
                if (len >= 0 && 2 + len <= data.length) {
                    conn.serverBrand = new String(data, 2, len, java.nio.charset.StandardCharsets.UTF_8);
                }
            }
            return null;
        }
    }

    public static class SRegistryData extends Packet262In {

        public static final int ID = 0x07;

        public String registryId;

        public int entryCount;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            registryId = buf.readString(256);
            entryCount = buf.readVarInt();
            for (int i = 0; i < entryCount; i++) {
                buf.readString(256);
                if (buf.readBool()) {
                    buf.skipAnonymousNbt();
                }
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SFeatureFlags extends Packet262In {

        public static final int ID = 0x0C;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            int n = buf.readVarInt();
            for (int i = 0; i < n; i++) {
                buf.readString(256);
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class STags extends Packet262In {

        public static final int ID = 0x0D;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            int groups = buf.readVarInt();
            for (int g = 0; g < groups; g++) {
                buf.readString(256);
                int tagCount = buf.readVarInt();
                for (int t = 0; t < tagCount; t++) {
                    buf.readString(256);
                    int entries = buf.readVarInt();
                    for (int e = 0; e < entries; e++) {
                        buf.readString(1024);
                    }
                }
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SSelectKnownPacks extends Packet262In {

        public static final int ID = 0x0E;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            int n = buf.readVarInt();
            for (int i = 0; i < n; i++) {
                buf.readString(256);
                buf.readString(256);
                buf.readString(256);
            }
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            conn.sendOut(new CSelectKnownPacks());
            return null;
        }
    }

    public static class SAddResourcePack extends Packet262In {

        public static final int ID = 0x09;

        public long packUuidMsb;

        public long packUuidLsb;

        public String url;

        public boolean forced;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            packUuidMsb = buf.readUuidMsb();
            packUuidLsb = buf.readUuidLsb();
            url = buf.readString(65536);
            if (buf.readBool()) {
                buf.readString(40);
            }
            forced = buf.readBool();
            if (buf.readBool()) {
                buf.skipAnonymousNbt();
            }
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            conn.sendOut(new CResourcePackReceive(packUuidMsb, packUuidLsb, 1));
            return null;
        }
    }

    public static class SRemoveResourcePack extends Packet262In {

        public static final int ID = 0x08;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            if (buf.readBool()) {
                buf.readUuidMsb();
                buf.readUuidLsb();
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SDisconnect extends Packet262In {

        public static final int ID = 0x02;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            buf.skipAnonymousNbt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketDisconnect(new TextComponentString("Disconnected by server (26.2 configuration)"));
        }
    }

    public static class SFinishConfiguration extends Packet262In {

        public static final int ID = 0x03;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            conn.sendOut(new CFinishConfiguration());
            conn.enterPlayState();
            return null;
        }
    }

    public static class SCookieRequest extends Packet262In {

        public static final int ID = 0x00;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            buf.readString(256);
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SStoreCookie extends Packet262In {

        public static final int ID = 0x0A;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            buf.readString(256);
            buf.readRestBuffer();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class STransfer extends Packet262In {

        public static final int ID = 0x0B;

        public String host;

        public int port;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            host = buf.readString(65536);
            port = buf.readUShort();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SCustomReportDetails extends Packet262In {

        public static final int ID = 0x0F;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            int n = buf.readVarInt();
            for (int i = 0; i < n; i++) {
                buf.readString(256);
                buf.readString(4096);
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SResetChat extends Packet262In {

        public static final int ID = 0x06;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SClearDialog extends Packet262In {

        public static final int ID = 0x11;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SShowDialog extends Packet262In {

        public static final int ID = 0x12;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            buf.skipAnonymousNbt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SCodeOfConduct extends Packet262In {

        public static final int ID = 0x13;

        public String contents;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            contents = buf.readString(65536);
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            conn.sendOut(new CAcceptCodeOfConduct());
            return null;
        }
    }

    public static class CCustomPayload extends Packet262Out {

        public static final int ID = 0x02;

        public final String channel;

        public final byte[] data;

        public CCustomPayload(String channel, byte[] data) {
            this.channel = channel;
            this.data = data;
        }

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return false;
        }

        @Override
        public void fromPacket(Packet pkt) {
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeString(channel, 256);
            buf.writeBytes(data);
        }
    }

    public static class CKeepAlive extends Packet262Out {

        public static final int ID = 0x04;

        public final long id;

        public CKeepAlive(long id) {
            this.id = id;
        }

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return false;
        }

        @Override
        public void fromPacket(Packet pkt) {
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeFixedLong(id);
        }
    }

    public static class CPong extends Packet262Out {

        public static final int ID = 0x05;

        public final int id;

        public CPong(int id) {
            this.id = id;
        }

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return false;
        }

        @Override
        public void fromPacket(Packet pkt) {
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeFixedInt(id);
        }
    }

    public static class CSelectKnownPacks extends Packet262Out {

        public static final int ID = 0x07;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return false;
        }

        @Override
        public void fromPacket(Packet pkt) {
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(0);
        }
    }

    public static class CResourcePackReceive extends Packet262Out {

        public static final int ID = 0x06;

        public final long uuidMsb;

        public final long uuidLsb;

        public final int result;

        public CResourcePackReceive(long uuidMsb, long uuidLsb, int result) {
            this.uuidMsb = uuidMsb;
            this.uuidLsb = uuidLsb;
            this.result = result;
        }

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return false;
        }

        @Override
        public void fromPacket(Packet pkt) {
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeUuid(uuidMsb, uuidLsb);
            buf.writeVarInt(result);
        }
    }

    public static class CFinishConfiguration extends Packet262Out {

        public static final int ID = 0x03;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return false;
        }

        @Override
        public void fromPacket(Packet pkt) {
        }

        @Override
        public void write(Port262Buffer buf) {
        }
    }

    public static class CAcceptCodeOfConduct extends Packet262Out {

        public static final int ID = 0x09;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return false;
        }

        @Override
        public void fromPacket(Packet pkt) {
        }

        @Override
        public void write(Port262Buffer buf) {
        }
    }

    public static class CClientInformation extends Packet262Out {

        public static final int ID = 0x00;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return false;
        }

        @Override
        public void fromPacket(Packet pkt) {
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeString("en_US", 16);
            buf.writeByte(8);
            buf.writeVarInt(0);
            buf.writeBool(true);
            buf.writeByte(0x7F);
            buf.writeVarInt(1);
            buf.writeBool(false);
            buf.writeBool(true);
            buf.writeVarInt(0);
        }
    }

    public static byte[] brandPayload(String brand) {
        byte[] brandBytes = brand.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        byte[] out = new byte[2 + brandBytes.length];
        out[0] = (byte) ((brandBytes.length >> 8) & 0xFF);
        out[1] = (byte) (brandBytes.length & 0xFF);
        System.arraycopy(brandBytes, 0, out, 2, brandBytes.length);
        return out;
    }

    public static Packet to1122CustomPayload(String channel, byte[] data) {
        io.netty.buffer.ByteBuf netty = io.netty.buffer.Unpooled.buffer(data.length);
        netty.writeBytes(data);
        return new SPacketCustomPayload(channel, new PacketBuffer(netty));
    }
}
