package client.port262.packets.login;

import java.io.IOException;
import client.port262.Packet262In;
import client.port262.Packet262Out;
import client.port262.Port262Buffer;
import client.port262.Port262Connection;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketDisconnect;
import net.minecraft.util.text.TextComponentString;

public final class Login262Packets {

    private Login262Packets() {
    }

    public static class CHandshake extends Packet262Out {

        private final int protocol;

        private final String address;

        private final int port;

        private final int nextState;

        public CHandshake(int protocol, String address, int port, int nextState) {
            this.protocol = protocol;
            this.address = address;
            this.port = port;
            this.nextState = nextState;
        }

        @Override
        public int getId() {
            return 0x00;
        }

        @Override
        public boolean matches(Packet pkt) {
            return false;
        }

        @Override
        public void fromPacket(Packet pkt) {
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(protocol);
            buf.writeString(address, 255);
            buf.writeUShort(port);
            buf.writeVarInt(nextState);
        }
    }

    public static class CLoginStart extends Packet262Out {

        public static final int ID = 0x00;

        private final String username;

        private final long uuidMsb;

        private final long uuidLsb;

        public CLoginStart(String username, long uuidMsb, long uuidLsb) {
            this.username = username;
            this.uuidMsb = uuidMsb;
            this.uuidLsb = uuidLsb;
        }

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return false;
        }

        @Override
        public void fromPacket(Packet pkt) {
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeString(username, 16);
            buf.writeUuid(uuidMsb, uuidLsb);
        }
    }

    public static class CLoginAcknowledged extends Packet262Out {

        public static final int ID = 0x03;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return false;
        }

        @Override
        public void fromPacket(Packet pkt) {
        }

        @Override
        public void write(Port262Buffer buf) {
        }
    }

    public static class SLoginSuccess extends Packet262In {

        public static final int ID = 0x02;

        public long uuidMsb;

        public long uuidLsb;

        public String username;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            uuidMsb = buf.readUuidMsb();
            uuidLsb = buf.readUuidLsb();
            username = buf.readString(16);
            int propCount = buf.readVarInt();
            for (int i = 0; i < propCount; i++) {
                buf.readString(64);
                buf.readString(1024);
                if (buf.readBool()) {
                    buf.readString(1024);
                }
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SLoginDisconnect extends Packet262In {

        public static final int ID = 0x00;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            buf.skipAnonymousNbt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketDisconnect(new TextComponentString("Disconnected by server (26.2 login)"));
        }
    }
}
