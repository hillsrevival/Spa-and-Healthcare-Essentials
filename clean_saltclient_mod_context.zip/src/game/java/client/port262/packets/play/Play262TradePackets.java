package client.port262.packets.play;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import io.netty.buffer.Unpooled;
import net.lax1dude.eaglercraft.EaglercraftUUID;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.attributes.AbstractAttributeMap;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketCustomPayload;
import net.minecraft.network.play.server.SPacketCombatEvent;
import net.minecraft.network.play.server.SPacketCustomPayload;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.village.MerchantRecipe;
import net.minecraft.village.MerchantRecipeList;
import client.port262.Packet262In;
import client.port262.Packet262Out;
import client.port262.Port262Buffer;
import client.port262.Port262Connection;
import client.port262.Port262ItemMap;
import client.port262.Port262Nbt;
import client.port262.Port262Stacks;
import client.port262.Port262Text;

public final class Play262TradePackets {

    private Play262TradePackets() {
    }

    public static class STradeList extends Packet262In {

        public static final int ID = 52;

        public static final class Trade {

            public ItemStack input1;

            public ItemStack output;

            public ItemStack input2;

            public boolean disabled;

            public int uses;

            public int maxUses;
        }

        public int windowId;

        public final List<Trade> trades = new ArrayList<Trade>();

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            windowId = buf.readVarInt();
            int count = buf.readVarInt();
            if (count < 0 || count > 256) {
                throw new IOException("26.2 trade_list count out of range: " + count);
            }
            for (int i = 0; i < count; i++) {
                Trade trade = new Trade();
                trade.input1 = readCompactItem(buf);
                trade.output = Port262Stacks.readStack(buf);
                if (buf.readBool()) {
                    trade.input2 = readCompactItem(buf);
                }
                trade.disabled = buf.readBool();
                trade.uses = buf.readFixedInt();
                trade.maxUses = buf.readFixedInt();
                buf.readFixedInt();
                buf.readFixedInt();
                buf.readFloat();
                buf.readFixedInt();
                trades.add(trade);
            }
            buf.readVarInt();
            buf.readVarInt();
            buf.readBool();
            buf.readBool();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            ItemStack barrier = barrierStack();
            MerchantRecipeList list = new MerchantRecipeList();
            int limit = Math.min(trades.size(), 255);
            for (int i = 0; i < limit; i++) {
                Trade trade = trades.get(i);
                ItemStack buy1 = trade.input1 != null ? trade.input1 : barrier;
                ItemStack sell = trade.output != null ? trade.output : barrier;
                ItemStack buy2 = trade.input2 != null ? trade.input2 : ItemStack.field_190927_a;
                MerchantRecipe recipe = new MerchantRecipe(buy1, buy2, sell, trade.uses, trade.maxUses);
                if (trade.disabled) {
                    recipe.compensateToolUses();
                }
                list.add(recipe);
            }
            PacketBuffer payload = new PacketBuffer(Unpooled.buffer(64));
            payload.writeInt(windowId);
            list.writeToBuf(payload);
            return new SPacketCustomPayload("MC|TrList", payload);
        }

        private ItemStack readCompactItem(Port262Buffer buf) throws IOException {
            int itemId = buf.readVarInt();
            int count = buf.readVarInt();
            int components = buf.readVarInt();
            Port262Stacks.skipComponents(buf, components);
            return Port262Stacks.itemFor(itemId, count);
        }

        private ItemStack barrierStack() {
            try {
                return new ItemStack(Item.getItemFromBlock(Blocks.BARRIER));
            } catch (Throwable t) {
                return ItemStack.field_190927_a;
            }
        }
    }

    public static class SUpdateAttributes extends Packet262In {

        public static final int ID = 131;

        private static final String[] ATTRS = new String[31];

        static {
            ATTRS[0] = "generic.armor";
            ATTRS[1] = "generic.armorToughness";
            ATTRS[2] = "generic.attackDamage";
            ATTRS[4] = "generic.attackSpeed";
            ATTRS[12] = "generic.flyingSpeed";
            ATTRS[13] = "generic.followRange";
            ATTRS[16] = "generic.knockbackResistance";
            ATTRS[17] = "generic.luck";
            ATTRS[19] = "generic.maxHealth";
            ATTRS[20] = "generic.movementSpeed";
            ATTRS[23] = "zombie.spawnReinforcements";
        }

        public static final class Mod {

            public String id;

            public double amount;

            public int operation;
        }

        public static final class Prop {

            public int key;

            public double value;

            public final List<Mod> modifiers = new ArrayList<Mod>();
        }

        public int entityId;

        public final List<Prop> properties = new ArrayList<Prop>();

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            int count = buf.readVarInt();
            if (count < 0 || count > 64) {
                throw new IOException("26.2 attribute count out of range: " + count);
            }
            for (int i = 0; i < count; i++) {
                Prop prop = new Prop();
                prop.key = buf.readVarInt();
                prop.value = buf.readDouble();
                int mods = buf.readVarInt();
                if (mods < 0 || mods > 1024) {
                    throw new IOException("26.2 attribute modifier count out of range: " + mods);
                }
                for (int j = 0; j < mods; j++) {
                    Mod mod = new Mod();
                    mod.id = buf.readString(2048);
                    mod.amount = buf.readDouble();
                    mod.operation = buf.readByte();
                    prop.modifiers.add(mod);
                }
                properties.add(prop);
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc == null || mc.world == null) {
                return null;
            }
            Entity entity = mc.world.getEntityByID(entityId);
            if (!(entity instanceof EntityLivingBase)) {
                return null;
            }
            AbstractAttributeMap map = ((EntityLivingBase) entity).getAttributeMap();
            for (int i = 0; i < properties.size(); i++) {
                Prop prop = properties.get(i);
                String name = prop.key >= 0 && prop.key < ATTRS.length ? ATTRS[prop.key] : null;
                if (name == null) {
                    continue;
                }
                IAttributeInstance instance = map.getAttributeInstanceByName(name);
                if (instance == null) {
                    continue;
                }
                instance.setBaseValue(prop.value);
                instance.removeAllModifiers();
                for (int j = 0; j < prop.modifiers.size(); j++) {
                    Mod mod = prop.modifiers.get(j);
                    EaglercraftUUID uuid = EaglercraftUUID.nameUUIDFromBytes(mod.id.getBytes(StandardCharsets.UTF_8));
                    instance.applyModifier(new AttributeModifier(uuid, mod.id, mod.amount, mod.operation));
                }
            }
            return null;
        }
    }

    public static class SEnterCombat extends Packet262In {

        public static final int ID = 67;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            SPacketCombatEvent out = new SPacketCombatEvent();
            out.eventType = SPacketCombatEvent.Event.ENTER_COMBAT;
            return out;
        }
    }

    public static class SEndCombat extends Packet262In {

        public static final int ID = 66;

        public int duration;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            duration = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            SPacketCombatEvent out = new SPacketCombatEvent();
            out.eventType = SPacketCombatEvent.Event.END_COMBAT;
            out.duration = duration;
            out.entityId = -1;
            return out;
        }
    }

    public static class SDeathCombat extends Packet262In {

        public static final int ID = 68;

        public int playerId;

        public ITextComponent message;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            playerId = buf.readVarInt();
            Object node = Port262Nbt.readAnonymous(buf);
            ITextComponent converted = Port262Text.fromNbt(node);
            message = converted != null ? converted : new TextComponentString("");
        }

        @Override
        public Packet process(Port262Connection conn) {
            SPacketCombatEvent out = new SPacketCombatEvent();
            out.eventType = SPacketCombatEvent.Event.ENTITY_DIED;
            out.playerId = playerId;
            out.entityId = -1;
            out.deathMessage = message;
            return out;
        }
    }

    public static class CSelectTrade extends Packet262Out {

        public static final int ID = 51;

        public int slot;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketCustomPayload && "MC|TrSel".equals(((CPacketCustomPayload) pkt).getChannelName());
        }

        @Override
        public void fromPacket(Packet pkt) {
            try {
                slot = ((CPacketCustomPayload) pkt).getBufferData().readInt();
            } catch (Throwable t) {
                slot = 0;
            }
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(slot);
        }
    }
}
