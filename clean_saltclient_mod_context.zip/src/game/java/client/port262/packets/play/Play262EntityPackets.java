package client.port262.packets.play;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import io.netty.buffer.Unpooled;
import net.lax1dude.eaglercraft.EaglercraftUUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.server.SPacketAnimation;
import net.minecraft.network.play.server.SPacketCollectItem;
import net.minecraft.network.play.server.SPacketDestroyEntities;
import net.minecraft.network.play.server.SPacketEntity;
import net.minecraft.network.play.server.SPacketEntityEffect;
import net.minecraft.network.play.server.SPacketEntityEquipment;
import net.minecraft.network.play.server.SPacketEntityHeadLook;
import net.minecraft.network.play.server.SPacketEntityMetadata;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketEntityTeleport;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketRemoveEntityEffect;
import net.minecraft.network.play.server.SPacketSetPassengers;
import net.minecraft.network.play.server.SPacketSpawnExperienceOrb;
import net.minecraft.network.play.server.SPacketSpawnMob;
import net.minecraft.network.play.server.SPacketSpawnObject;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import client.port262.Packet262In;
import client.port262.Port262BlockMap;
import client.port262.Port262Buffer;
import client.port262.Port262Connection;
import client.port262.Port262EntityMap;
import client.port262.Port262EffectMap;
import client.port262.Port262EntityMetadata;
import client.port262.Port262Stacks;

public final class Play262EntityPackets {

    private Play262EntityPackets() {
    }

    private static final Map<String, Integer> RESOLVED = new HashMap<String, Integer>();

    private static int legacyEntityId(String name) {
        Integer cached = RESOLVED.get(name);
        if (cached != null) {
            return cached.intValue();
        }
        int id;
        try {
            ResourceLocation rl = new ResourceLocation(name);
            Class<? extends Entity> cls = EntityList.field_191308_b.getObject(rl);
            id = cls != null ? EntityList.field_191308_b.getIDForObject(cls) : -1;
        } catch (Throwable t) {
            id = -1;
        }
        RESOLVED.put(name, Integer.valueOf(id));
        return id;
    }

    private static boolean isLiving(int legacyId) {
        try {
            Class<?> cls = EntityList.getClassFromID(legacyId);
            return cls != null && EntityLivingBase.class.isAssignableFrom(cls);
        } catch (Throwable t) {
            return false;
        }
    }

    private static void debug(String msg) {
        client.tuff.TuffDebugLog.log("[26.2] " + msg);
    }

    public static class SSpawnEntity extends Packet262In {

        public static final int ID = 1;

        public int entityId;

        public int type;

        public double x;

        public double y;

        public double z;

        public short vx;

        public short vy;

        public short vz;

        public int pitch;

        public int yaw;

        public int headPitch;

        public int objectData;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            buf.readUuidMsb();
            buf.readUuidLsb();
            type = buf.readVarInt();
            x = buf.readDouble();
            y = buf.readDouble();
            z = buf.readDouble();
            int n = buf.readVarInt();
            if (n >= 3) {
                vx = buf.readShort();
                vy = buf.readShort();
                vz = buf.readShort();
            }
            pitch = buf.readByte();
            yaw = buf.readByte();
            headPitch = buf.readByte();
            objectData = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            String name = Port262EntityMap.legacyName(type);
            if (name == null) {
                debug("spawn_entity: no 1.12.2 equivalent for type " + type + " (dropped)");
                return null;
            }
            int legacyId = legacyEntityId(name);
            if (legacyId < 0) {
                debug("spawn_entity: unknown 1.12.2 entity '" + name + "' (dropped)");
                return null;
            }
            if ("experience_orb".equals(name)) {
                PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(40));
                scratch.writeVarIntToBuffer(entityId);
                scratch.writeDouble(x);
                scratch.writeDouble(y);
                scratch.writeDouble(z);
                scratch.writeShort(1);
                SPacketSpawnExperienceOrb out = new SPacketSpawnExperienceOrb();
                out.readPacketData(scratch);
                return out;
            }
            if (isLiving(legacyId)) {
                PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(64));
                scratch.writeVarIntToBuffer(entityId);
                scratch.writeUuid(new EaglercraftUUID(entityId, 0x262L));
                scratch.writeVarIntToBuffer(legacyId);
                scratch.writeDouble(x);
                scratch.writeDouble(y);
                scratch.writeDouble(z);
                scratch.writeByte(yaw);
                scratch.writeByte(pitch);
                scratch.writeByte(headPitch);
                scratch.writeShort(vx);
                scratch.writeShort(vy);
                scratch.writeShort(vz);
                scratch.writeByte(255);
                SPacketSpawnMob out = new SPacketSpawnMob();
                out.readPacketData(scratch);
                return out;
            }
            int data = 0;
            if ("falling_block".equals(name) && objectData > 0) {
                data = Port262BlockMap.map(objectData);
            }
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(64));
            scratch.writeVarIntToBuffer(entityId);
            scratch.writeUuid(new EaglercraftUUID(entityId, 0x263L));
            scratch.writeByte(legacyId);
            scratch.writeDouble(x);
            scratch.writeDouble(y);
            scratch.writeDouble(z);
            scratch.writeByte(pitch);
            scratch.writeByte(yaw);
            scratch.writeInt(data);
            scratch.writeShort(vx);
            scratch.writeShort(vy);
            scratch.writeShort(vz);
            SPacketSpawnObject out = new SPacketSpawnObject();
            out.readPacketData(scratch);
            return out;
        }
    }

    public static class SAnimation extends Packet262In {

        public static final int ID = 2;

        public int entityId;

        public int animation;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            animation = buf.readUByte();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            int mapped;
            switch(animation) {
                case 0:
                case 3:
                    mapped = 0;
                    break;
                case 1:
                    mapped = 1;
                    break;
                case 2:
                    mapped = 2;
                    break;
                case 4:
                    mapped = 4;
                    break;
                case 5:
                    mapped = 5;
                    break;
                default:
                    return null;
            }
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(8));
            scratch.writeVarIntToBuffer(entityId);
            scratch.writeByte(mapped);
            SPacketAnimation out = new SPacketAnimation();
            out.readPacketData(scratch);
            return out;
        }
    }

    public static class SEntityStatus extends Packet262In {

        public static final int ID = 34;

        public int entityId;

        public int opcode;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readFixedInt();
            opcode = buf.readByte();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(8));
            scratch.writeInt(entityId);
            scratch.writeByte(opcode);
            SPacketEntityStatus out = new SPacketEntityStatus();
            out.readPacketData(scratch);
            return out;
        }
    }

    public static class SSyncEntityPosition extends Packet262In {

        public static final int ID = 35;

        public int entityId;

        public double x;

        public double y;

        public double z;

        public float yaw;

        public float pitch;

        public boolean onGround;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            x = buf.readDouble();
            y = buf.readDouble();
            z = buf.readDouble();
            buf.readDouble();
            buf.readDouble();
            buf.readDouble();
            yaw = buf.readFloat();
            pitch = buf.readFloat();
            onGround = buf.readBool();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            return teleportWire(entityId, x, y, z, yaw, pitch, onGround);
        }
    }

    public static class SRelEntityMove extends Packet262In {

        public static final int ID = 53;

        public int entityId;

        public short dx;

        public short dy;

        public short dz;

        public boolean onGround;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            dx = buf.readShort();
            dy = buf.readShort();
            dz = buf.readShort();
            onGround = buf.readBool();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketEntity.S15PacketEntityRelMove(entityId, dx, dy, dz, onGround);
        }
    }

    public static class SEntityMoveLook extends Packet262In {

        public static final int ID = 54;

        public int entityId;

        public short dx;

        public short dy;

        public short dz;

        public int yaw;

        public int pitch;

        public boolean onGround;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            dx = buf.readShort();
            dy = buf.readShort();
            dz = buf.readShort();
            yaw = buf.readByte();
            pitch = buf.readByte();
            onGround = buf.readBool();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketEntity.S17PacketEntityLookMove(entityId, dx, dy, dz, (byte) yaw, (byte) pitch, onGround);
        }
    }

    public static class SEntityLook extends Packet262In {

        public static final int ID = 56;

        public int entityId;

        public int yaw;

        public int pitch;

        public boolean onGround;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            yaw = buf.readByte();
            pitch = buf.readByte();
            onGround = buf.readBool();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketEntity.S16PacketEntityLook(entityId, (byte) yaw, (byte) pitch, onGround);
        }
    }

    public static class SEntityTeleport extends Packet262In {

        public static final int ID = 125;

        public int entityId;

        public double x;

        public double y;

        public double z;

        public int yaw;

        public int pitch;

        public boolean onGround;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            x = buf.readDouble();
            y = buf.readDouble();
            z = buf.readDouble();
            yaw = buf.readByte();
            pitch = buf.readByte();
            onGround = buf.readBool();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            return teleportWire(entityId, x, y, z, yaw * 360.0F / 256.0F, pitch * 360.0F / 256.0F, onGround);
        }
    }

    public static class SHeadRotation extends Packet262In {

        public static final int ID = 83;

        public int entityId;

        public int headYaw;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            headYaw = buf.readByte();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(8));
            scratch.writeVarIntToBuffer(entityId);
            scratch.writeByte(headYaw);
            SPacketEntityHeadLook out = new SPacketEntityHeadLook();
            out.readPacketData(scratch);
            return out;
        }
    }

    public static class SEntityMetadata extends Packet262In {

        public static final int ID = 99;

        public int entityId;

        public Packet translated;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            translated = Port262EntityMetadata.decode(entityId, buf);
        }

        @Override
        public Packet process(Port262Connection conn) {
            return translated;
        }
    }

    public static class SAttachEntity extends Packet262In {

        public static final int ID = 100;

        public int entityId;

        public int vehicleId;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readFixedInt();
            vehicleId = buf.readFixedInt();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(12));
            scratch.writeInt(entityId);
            scratch.writeInt(vehicleId > 0 ? vehicleId : -1);
            net.minecraft.network.play.server.SPacketEntityAttach out = new net.minecraft.network.play.server.SPacketEntityAttach();
            out.readPacketData(scratch);
            return out;
        }
    }

    public static class SSetPassengers extends Packet262In {

        public static final int ID = 107;

        public int entityId;

        public int[] passengers = new int[0];

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            int count = buf.readVarInt();
            if (count < 0 || count > 256) {
                throw new IOException("26.2 passenger count out of range: " + count);
            }
            passengers = new int[count];
            for (int i = 0; i < count; i++) {
                passengers[i] = buf.readVarInt();
            }
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(8 + passengers.length * 5));
            scratch.writeVarIntToBuffer(entityId);
            scratch.writeVarIntToBuffer(passengers.length);
            for (int passenger : passengers) {
                scratch.writeVarIntToBuffer(passenger);
            }
            SPacketSetPassengers out = new SPacketSetPassengers();
            out.readPacketData(scratch);
            return out;
        }
    }

    public static class SEntityVelocity extends Packet262In {

        public static final int ID = 101;

        public int entityId;

        public short vx;

        public short vy;

        public short vz;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            int n = buf.readVarInt();
            if (n >= 3) {
                vx = buf.readShort();
                vy = buf.readShort();
                vz = buf.readShort();
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketEntityVelocity(entityId, vx / 8000.0D, vy / 8000.0D, vz / 8000.0D);
        }
    }

    public static class SEntityEquipment extends Packet262In {

        public static final int ID = 102;

        public int entityId;

        public int[] slots = new int[0];

        public ItemStack[] stacks = new ItemStack[0];

        private int emitted;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            java.util.List<Integer> slotList = new java.util.ArrayList<Integer>();
            java.util.List<ItemStack> stackList = new java.util.ArrayList<ItemStack>();
            while (true) {
                int head = buf.readUByte();
                int slot = head & 0x7F;
                boolean more = (head & 0x80) != 0;
                ItemStack stack = Port262Stacks.readStack(buf);
                if (stack != null && slot <= 5) {
                    slotList.add(Integer.valueOf(slot));
                    stackList.add(stack);
                }
                if (!more) {
                    break;
                }
            }
            slots = new int[slotList.size()];
            for (int i = 0; i < slots.length; i++) {
                slots[i] = slotList.get(i).intValue();
            }
            stacks = stackList.toArray(new ItemStack[0]);
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            Packet first = null;
            for (int i = 0; i < slots.length; i++) {
                PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(16));
                scratch.writeVarIntToBuffer(entityId);
                scratch.writeVarIntToBuffer(slots[i]);
                scratch.writeItemStackToBuffer(stacks[i]);
                SPacketEntityEquipment out = new SPacketEntityEquipment();
                out.readPacketData(scratch);
                if (first == null) {
                    first = out;
                } else {
                    conn.dispatch(out);
                }
            }
            emitted = slots.length;
            return first;
        }

        public int getEmitted() {
            return emitted;
        }
    }

    public static class SEntityEffect extends Packet262In {

        public static final int ID = 132;

        public int entityId;

        public int effectId;

        public int amplifier;

        public int duration;

        public int flags;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            effectId = buf.readVarInt();
            amplifier = buf.readVarInt();
            duration = buf.readVarInt();
            flags = buf.readUByte();
        }

        @Override
        public Packet process(Port262Connection conn) {
            Potion potion = potionById(effectId);
            if (potion == null) {
                return null;
            }
            boolean ambient = (flags & 0x01) != 0;
            boolean particles = (flags & 0x02) == 0;
            PotionEffect effect = new PotionEffect(potion, duration, amplifier, ambient, particles);
            return new SPacketEntityEffect(entityId, effect);
        }
    }

    public static class SRemoveEntityEffect extends Packet262In {

        public static final int ID = 78;

        public int entityId;

        public int effectId;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
            effectId = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            Potion potion = potionById(effectId);
            return potion != null ? new SPacketRemoveEntityEffect(entityId, potion) : null;
        }
    }

    public static class SCollect extends Packet262In {

        public static final int ID = 124;

        public int collectedEntityId;

        public int collectorEntityId;

        public int pickupItemCount;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            collectedEntityId = buf.readVarInt();
            collectorEntityId = buf.readVarInt();
            pickupItemCount = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketCollectItem(collectedEntityId, collectorEntityId, pickupItemCount);
        }
    }

    public static class SEntityDestroy extends Packet262In {

        public static final int ID = 77;

        public int[] entityIds = new int[0];

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            int count = buf.readVarInt();
            if (count < 0 || count > 4096) {
                throw new IOException("26.2 destroy count out of range: " + count);
            }
            entityIds = new int[count];
            for (int i = 0; i < count; i++) {
                entityIds[i] = buf.readVarInt();
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketDestroyEntities(entityIds);
        }
    }

    public static class SHurtAnimation extends Packet262In {

        public static final int ID = 42;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            buf.readVarInt();
            buf.readFloat();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    private static Packet teleportWire(int entityId, double x, double y, double z, float yaw, float pitch, boolean onGround) throws IOException {
        PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(40));
        scratch.writeVarIntToBuffer(entityId);
        scratch.writeDouble(x);
        scratch.writeDouble(y);
        scratch.writeDouble(z);
        scratch.writeByte((int) (yaw * 256.0F / 360.0F));
        scratch.writeByte((int) (pitch * 256.0F / 360.0F));
        scratch.writeBoolean(onGround);
        SPacketEntityTeleport out = new SPacketEntityTeleport();
        out.readPacketData(scratch);
        return out;
    }

    private static Potion potionById(int effectId) {
        String name = Port262EffectMap.name(effectId);
        if (name == null) {
            return null;
        }
        try {
            return Potion.getPotionFromResourceLocation("minecraft:" + name);
        } catch (Throwable t) {
            return null;
        }
    }
}
