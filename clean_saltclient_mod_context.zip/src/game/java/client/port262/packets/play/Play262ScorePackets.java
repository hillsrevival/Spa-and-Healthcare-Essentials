package client.port262.packets.play;

import java.io.IOException;
import java.util.Arrays;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketDisplayObjective;
import net.minecraft.network.play.server.SPacketScoreboardObjective;
import net.minecraft.network.play.server.SPacketTeams;
import net.minecraft.network.play.server.SPacketUpdateScore;
import net.minecraft.scoreboard.IScoreCriteria;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.text.TextFormatting;
import client.port262.Packet262In;
import client.port262.Port262Buffer;
import client.port262.Port262Connection;
import client.port262.Port262Nbt;
import client.port262.Port262Text;

public final class Play262ScorePackets {

    private Play262ScorePackets() {
    }

    static String clampName(String s, int max) {
        if (s == null) {
            return "";
        }
        return s.length() <= max ? s : s.substring(0, max);
    }

    static void consumeNumberFormat(Port262Buffer buf) throws IOException {
        if (buf.readBool()) {
            int fmt = buf.readVarInt();
            if (fmt == 1 || fmt == 2) {
                Port262Nbt.readAnonymous(buf);
            }
        }
    }

    private static IScoreCriteria criteriaFor(final String name, final IScoreCriteria.EnumRenderType renderType) {
        return new IScoreCriteria() {

            public String getName() {
                return name;
            }

            public boolean isReadOnly() {
                return false;
            }

            public IScoreCriteria.EnumRenderType getRenderType() {
                return renderType;
            }
        };
    }

    private static ScoreObjective objectiveCarrier(String name, IScoreCriteria.EnumRenderType renderType) {
        return new ScoreObjective(new Scoreboard(), name, criteriaFor(name, renderType));
    }

    private static Team.EnumVisible visibilityFor(int v) {
        switch(v) {
            case 1:
                return Team.EnumVisible.NEVER;
            case 2:
                return Team.EnumVisible.HIDE_FOR_OTHER_TEAMS;
            case 3:
                return Team.EnumVisible.HIDE_FOR_OWN_TEAM;
            default:
                return Team.EnumVisible.ALWAYS;
        }
    }

    private static Team.CollisionRule collisionFor(int v) {
        switch(v) {
            case 1:
                return Team.CollisionRule.NEVER;
            case 2:
                return Team.CollisionRule.HIDE_FOR_OTHER_TEAMS;
            case 3:
                return Team.CollisionRule.HIDE_FOR_OWN_TEAM;
            default:
                return Team.CollisionRule.ALWAYS;
        }
    }

    private static TextFormatting colorFor(int v) {
        if (v >= 0 && v <= 15) {
            TextFormatting fmt = TextFormatting.fromColorIndex(v);
            if (fmt != null) {
                return fmt;
            }
        }
        return TextFormatting.RESET;
    }

    public static class SScoreboardObjective extends Packet262In {

        public static final int ID = 106;

        public String name = "";

        public int action;

        public String display = "";

        public int renderType;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            name = buf.readString();
            action = buf.readByte();
            if (action == 0 || action == 2) {
                display = Port262Text.legacyText(Port262Nbt.readAnonymous(buf), 32);
                renderType = buf.readVarInt();
                consumeNumberFormat(buf);
            }
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            String objName = clampName(name, 16);
            if (action == 1) {
                return new SPacketScoreboardObjective(objectiveCarrier(objName, IScoreCriteria.EnumRenderType.INTEGER), 1);
            }
            IScoreCriteria.EnumRenderType rt = renderType == 1 ? IScoreCriteria.EnumRenderType.HEARTS : IScoreCriteria.EnumRenderType.INTEGER;
            ScoreObjective carrier = objectiveCarrier(objName, rt);
            carrier.setDisplayName(display);
            return new SPacketScoreboardObjective(carrier, action == 2 ? 2 : 0);
        }
    }

    public static class SScoreboardDisplayObjective extends Packet262In {

        public static final int ID = 98;

        public int position;

        public String name = "";

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            position = buf.readVarInt();
            name = buf.readString();
        }

        @Override
        public Packet process(Port262Connection conn) {
            int pos;
            switch(position) {
                case 0:
                    pos = 0;
                    break;
                case 2:
                    pos = 2;
                    break;
                default:
                    pos = 1;
                    break;
            }
            if (name == null || name.isEmpty()) {
                return new SPacketDisplayObjective(pos, null);
            }
            return new SPacketDisplayObjective(pos, objectiveCarrier(clampName(name, 16), IScoreCriteria.EnumRenderType.INTEGER));
        }
    }

    public static class SScoreboardScore extends Packet262In {

        public static final int ID = 110;

        public String holder = "";

        public String objective = "";

        public int value;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            holder = buf.readString();
            objective = buf.readString();
            value = buf.readVarInt();
            if (buf.readBool()) {
                Port262Nbt.readAnonymous(buf);
            }
            consumeNumberFormat(buf);
        }

        @Override
        public Packet process(Port262Connection conn) {
            ScoreObjective carrier = objectiveCarrier(clampName(objective, 16), IScoreCriteria.EnumRenderType.INTEGER);
            Score score = new Score(new Scoreboard(), carrier, clampName(holder, 40));
            score.setScorePoints(value);
            return new SPacketUpdateScore(score);
        }
    }

    public static class SResetScore extends Packet262In {

        public static final int ID = 79;

        public String holder = "";

        public String objective = null;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            holder = buf.readString();
            if (buf.readBool()) {
                objective = buf.readString();
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            String holderName = clampName(holder, 40);
            if (objective == null) {
                return new SPacketUpdateScore(holderName);
            }
            return new SPacketUpdateScore(holderName, objectiveCarrier(clampName(objective, 16), IScoreCriteria.EnumRenderType.INTEGER));
        }
    }

    public static class STeams extends Packet262In {

        public static final int ID = 109;

        public String team = "";

        public int mode;

        public String display = "";

        public int flags;

        public int visibility;

        public int collision;

        public int color;

        public String prefix = "";

        public String suffix = "";

        public String[] players = new String[0];

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            team = buf.readString();
            mode = buf.readByte();
            if (mode == 0 || mode == 2) {
                display = Port262Text.legacyText(Port262Nbt.readAnonymous(buf), 32);
                flags = buf.readUByte();
                visibility = buf.readVarInt();
                collision = buf.readVarInt();
                color = buf.readVarInt();
                prefix = Port262Text.legacyText(Port262Nbt.readAnonymous(buf), 16);
                suffix = Port262Text.legacyText(Port262Nbt.readAnonymous(buf), 16);
            }
            if (mode == 0 || mode == 3 || mode == 4) {
                int count = buf.readVarInt();
                if (count < 0 || count > 1024) {
                    throw new IOException("26.2 teams member count out of range: " + count);
                }
                players = new String[count];
                for (int i = 0; i < count; i++) {
                    players[i] = clampName(buf.readString(), 40);
                }
            }
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            ScorePlayerTeam carrier = new ScorePlayerTeam(new Scoreboard(), clampName(team, 16));
            if (mode == 0 || mode == 2) {
                carrier.setTeamName(clampName(display, 32));
                carrier.setAllowFriendlyFire((flags & 0x01) != 0);
                carrier.setSeeFriendlyInvisiblesEnabled((flags & 0x02) != 0);
                carrier.setNameTagVisibility(visibilityFor(visibility));
                carrier.setCollisionRule(collisionFor(collision));
                carrier.setChatFormat(colorFor(color));
                carrier.setNamePrefix(prefix);
                carrier.setNameSuffix(suffix);
            }
            if (mode == 0) {
                Packet create = new SPacketTeams(carrier, 0);
                if (players.length > 0) {
                    conn.dispatch(create);
                    return new SPacketTeams(carrier, Arrays.asList(players), 3);
                }
                return create;
            }
            if (mode == 1) {
                return new SPacketTeams(carrier, 1);
            }
            if (mode == 2) {
                return new SPacketTeams(carrier, 2);
            }
            if (mode == 3 || mode == 4) {
                if (players.length == 0) {
                    return null;
                }
                return new SPacketTeams(carrier, Arrays.asList(players), mode);
            }
            return null;
        }
    }
}
