package client.port262.packets.play;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.crafting.ShapedRecipes;
import net.minecraft.item.crafting.ShapelessRecipes;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlaceRecipe;
import net.minecraft.network.play.client.CPacketRecipeInfo;
import net.minecraft.network.play.server.SPacketRecipeBook;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import client.port262.Packet262In;
import client.port262.Packet262Out;
import client.port262.Port262;
import client.port262.Port262Buffer;
import client.port262.Port262Connection;
import client.port262.Port262Stacks;

public final class Play262RecipePackets {

    private Play262RecipePackets() {
    }

    static ResourceLocation rlFor(int displayId) {
        return new ResourceLocation("port262", "r" + displayId);
    }

    static IRecipe registerRecipe(int displayId, IRecipe recipe, Port262Connection conn) {
        ResourceLocation rl = rlFor(displayId);
        IRecipe existing = CraftingManager.func_193373_a(rl);
        if (existing != null) {
            conn.trackRecipeDisplay(displayId, existing);
            return existing;
        }
        try {
            CraftingManager.func_193372_a(rl, recipe);
        } catch (IllegalStateException dup) {
            IRecipe raced = CraftingManager.func_193373_a(rl);
            if (raced == null) {
                return null;
            }
            recipe = raced;
        }
        conn.trackRecipeDisplay(displayId, recipe);
        return recipe;
    }

    static IRecipe matchByOutput(ItemStack output) {
        if (output == null || output.func_190926_b()) {
            return null;
        }
        for (IRecipe r : CraftingManager.field_193380_a) {
            if ((r instanceof ShapedRecipes || r instanceof ShapelessRecipes) && r.getRecipeOutput().getItem() == output.getItem()) {
                return r;
            }
        }
        return null;
    }

    static ItemStack[] readSlotDisplay(Port262Buffer buf) throws IOException {
        int type = buf.readVarInt();
        switch(type) {
            case 0:
            case 1:
                return new ItemStack[0];
            case 2:
                return readSlotDisplay(buf);
            case 3:
                {
                    ItemStack[] src = readSlotDisplay(buf);
                    buf.readVarInt();
                    return src;
                }
            case 4:
                {
                    int itemId = buf.readVarInt();
                    ItemStack st = Port262Stacks.itemFor(itemId, 1);
                    return st != null && !st.func_190926_b() ? new ItemStack[] { st } : new ItemStack[0];
                }
            case 5:
                {
                    ItemStack st = Port262Stacks.readStack(buf);
                    return st != null && !st.func_190926_b() ? new ItemStack[] { st } : new ItemStack[0];
                }
            case 6:
                buf.readString();
                return new ItemStack[0];
            case 7:
                {
                    readSlotDisplay(buf);
                    return readSlotDisplay(buf);
                }
            case 8:
                {
                    ItemStack[] base = readSlotDisplay(buf);
                    readSlotDisplay(buf);
                    if (buf.readBool()) {
                        buf.readString();
                        buf.skipAnonymousNbt();
                        buf.readBool();
                    } else {
                        buf.readVarInt();
                    }
                    return base;
                }
            case 9:
                {
                    ItemStack[] input = readSlotDisplay(buf);
                    readSlotDisplay(buf);
                    return input;
                }
            case 10:
                {
                    int count = buf.readVarInt();
                    if (count < 0 || count > 256) {
                        throw new IOException("26.2 SlotDisplay composite count out of range: " + count);
                    }
                    List<ItemStack> out = new ArrayList<ItemStack>();
                    for (int i = 0; i < count; i++) {
                        for (ItemStack st : readSlotDisplay(buf)) {
                            out.add(st);
                        }
                    }
                    return out.toArray(new ItemStack[out.size()]);
                }
            default:
                throw new IOException("26.2 unknown SlotDisplay type " + type);
        }
    }

    static class CraftDisplay {

        boolean shaped;

        int width;

        int height;

        List<ItemStack[]> ingredients = new ArrayList<ItemStack[]>();

        ItemStack[] result = new ItemStack[0];
    }

    static CraftDisplay readRecipeDisplay(Port262Buffer buf) throws IOException {
        int type = buf.readVarInt();
        if (type == 2) {
            readSlotDisplay(buf);
            readSlotDisplay(buf);
            readSlotDisplay(buf);
            readSlotDisplay(buf);
            buf.readVarInt();
            buf.readFloat();
            return null;
        }
        if (type == 3) {
            readSlotDisplay(buf);
            readSlotDisplay(buf);
            readSlotDisplay(buf);
            return null;
        }
        if (type == 4) {
            readSlotDisplay(buf);
            readSlotDisplay(buf);
            readSlotDisplay(buf);
            readSlotDisplay(buf);
            readSlotDisplay(buf);
            return null;
        }
        if (type != 0 && type != 1) {
            throw new IOException("26.2 unknown RecipeDisplay type " + type);
        }
        CraftDisplay cd = new CraftDisplay();
        cd.shaped = type == 1;
        if (cd.shaped) {
            cd.width = buf.readVarInt();
            cd.height = buf.readVarInt();
            if (cd.width < 1 || cd.width > 8 || cd.height < 1 || cd.height > 8) {
                throw new IOException("26.2 shaped recipe grid out of range: " + cd.width + "x" + cd.height);
            }
        }
        int ingCount = buf.readVarInt();
        if (ingCount < 0 || ingCount > 64) {
            throw new IOException("26.2 recipe ingredient count out of range: " + ingCount);
        }
        for (int i = 0; i < ingCount; i++) {
            cd.ingredients.add(readSlotDisplay(buf));
        }
        cd.result = readSlotDisplay(buf);
        readSlotDisplay(buf);
        return cd;
    }

    static void readIDSet(Port262Buffer buf) throws IOException {
        if (buf.readBool()) {
            buf.readString();
        } else {
            buf.readVarInt();
        }
    }

    public static class SDeclareRecipes extends Packet262In {

        public static final int ID = 133;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SCraftRecipeResponse extends Packet262In {

        public static final int ID = 63;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SRecipeBookAdd extends Packet262In {

        public static final int ID = 74;

        static class BookEntry {

            int displayId;

            CraftDisplay disp;

            int flags;
        }

        final List<BookEntry> entries = new ArrayList<BookEntry>();

        boolean replace;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            int count = buf.readVarInt();
            if (count < 0 || count > 8192) {
                throw new IOException("26.2 recipe_book_add count out of range: " + count);
            }
            for (int i = 0; i < count; i++) {
                BookEntry e = new BookEntry();
                e.displayId = buf.readVarInt();
                e.disp = readRecipeDisplay(buf);
                if (buf.readBool()) {
                    buf.readVarInt();
                }
                buf.readVarInt();
                if (buf.readBool()) {
                    int reqCount = buf.readVarInt();
                    if (reqCount < 0 || reqCount > 256) {
                        throw new IOException("26.2 craftingRequirements count out of range: " + reqCount);
                    }
                    for (int r = 0; r < reqCount; r++) {
                        readIDSet(buf);
                    }
                }
                e.flags = buf.readUByte();
                entries.add(e);
            }
            replace = buf.readBool();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            List<IRecipe> all = new ArrayList<IRecipe>();
            List<IRecipe> allHighlight = new ArrayList<IRecipe>();
            List<IRecipe> silent = new ArrayList<IRecipe>();
            List<IRecipe> silentHighlight = new ArrayList<IRecipe>();
            List<IRecipe> toast = new ArrayList<IRecipe>();
            for (BookEntry e : entries) {
                if (e.disp == null) {
                    continue;
                }
                IRecipe recipe = translateEntry(e, conn);
                if (recipe == null) {
                    continue;
                }
                all.add(recipe);
                if ((e.flags & 0x02) != 0) {
                    allHighlight.add(recipe);
                }
                if (replace) {
                    continue;
                }
                if ((e.flags & 0x01) != 0) {
                    toast.add(recipe);
                } else {
                    silent.add(recipe);
                    if ((e.flags & 0x02) != 0) {
                        silentHighlight.add(recipe);
                    }
                }
            }
            if (all.isEmpty()) {
                return null;
            }
            if (replace) {
                return new SPacketRecipeBook(SPacketRecipeBook.State.INIT, all, allHighlight, conn.recipeBookOpen(), conn.recipeBookFiltering());
            }
            if (!silent.isEmpty()) {
                conn.dispatch(new SPacketRecipeBook(SPacketRecipeBook.State.INIT, silent, silentHighlight, conn.recipeBookOpen(), conn.recipeBookFiltering()));
            }
            if (!toast.isEmpty()) {
                return new SPacketRecipeBook(SPacketRecipeBook.State.ADD, toast, new ArrayList<IRecipe>(), conn.recipeBookOpen(), conn.recipeBookFiltering());
            }
            return null;
        }

        private IRecipe translateEntry(BookEntry e, Port262Connection conn) throws IOException {
            CraftDisplay cd = e.disp;
            ItemStack result = cd.result.length > 0 ? cd.result[0] : null;
            if (result == null || result.func_190926_b()) {
                return null;
            }
            for (ItemStack[] group : cd.ingredients) {
                if (group.length == 0) {
                    IRecipe matched = matchByOutput(result);
                    if (matched != null) {
                        conn.trackRecipeDisplay(e.displayId, matched);
                    }
                    return matched;
                }
            }
            if (cd.ingredients.isEmpty()) {
                return null;
            }
            Ingredient[] ings = new Ingredient[cd.ingredients.size()];
            for (int i = 0; i < ings.length; i++) {
                ings[i] = Ingredient.func_193369_a(cd.ingredients.get(i));
            }
            IRecipe recipe;
            if (cd.shaped) {
                if (cd.ingredients.size() != cd.width * cd.height) {
                    return null;
                }
                NonNullList<Ingredient> grid = NonNullList.func_191197_a(ings.length, Ingredient.func_193369_a());
                for (int i = 0; i < ings.length; i++) {
                    grid.set(i, ings[i]);
                }
                recipe = new ShapedRecipes("", cd.width, cd.height, grid, result);
            } else {
                NonNullList<Ingredient> list = NonNullList.func_191197_a(ings.length, Ingredient.func_193369_a());
                for (int i = 0; i < ings.length; i++) {
                    list.set(i, ings[i]);
                }
                recipe = new ShapelessRecipes("", result, list);
            }
            IRecipe registered = registerRecipe(e.displayId, recipe, conn);
            return registered;
        }
    }

    public static class SRecipeBookRemove extends Packet262In {

        public static final int ID = 75;

        final List<Integer> displayIds = new ArrayList<Integer>();

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            int count = buf.readVarInt();
            if (count < 0 || count > 8192) {
                throw new IOException("26.2 recipe_book_remove count out of range: " + count);
            }
            for (int i = 0; i < count; i++) {
                displayIds.add(Integer.valueOf(buf.readVarInt()));
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            List<IRecipe> removed = new ArrayList<IRecipe>();
            for (Integer id : displayIds) {
                IRecipe recipe = conn.recipeForDisplay(id.intValue());
                if (recipe != null) {
                    removed.add(recipe);
                }
            }
            if (removed.isEmpty()) {
                return null;
            }
            return new SPacketRecipeBook(SPacketRecipeBook.State.REMOVE, removed, new ArrayList<IRecipe>(), conn.recipeBookOpen(), conn.recipeBookFiltering());
        }
    }

    public static class SRecipeBookSettings extends Packet262In {

        public static final int ID = 76;

        boolean craftingOpen;

        boolean craftingFiltering;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            craftingOpen = buf.readBool();
            craftingFiltering = buf.readBool();
            buf.readBool();
            buf.readBool();
            buf.readBool();
            buf.readBool();
            buf.readBool();
            buf.readBool();
        }

        @Override
        public Packet process(Port262Connection conn) {
            conn.setRecipeBookSettings(craftingOpen, craftingFiltering);
            return null;
        }
    }

    public static class CCraftRecipeRequest extends Packet262Out {

        public static final int ID = 39;

        private int windowId;

        private int displayId = -1;

        private boolean makeAll;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketPlaceRecipe;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketPlaceRecipe place = (CPacketPlaceRecipe) pkt;
            windowId = place.func_194318_a();
            makeAll = place.func_194319_c();
            Port262Connection conn = Port262.getConnection();
            IRecipe recipe = place.func_194317_b();
            displayId = conn != null && recipe != null ? conn.displayForRecipe(recipe) : -1;
            if (displayId < 0) {
                client.tuff.TuffDebugLog.log("[26.2] place-recipe for untracked recipe " + (recipe == null ? "null" : recipe.getClass().getSimpleName()) + " — sending 0");
            }
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(windowId);
            buf.writeVarInt(Math.max(displayId, 0));
            buf.writeBool(makeAll);
        }
    }

    public static class CRecipeBookInfo extends Packet262Out {

        public static final int ID = 46;

        private boolean bookOpen;

        private boolean filterActive;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketRecipeInfo && ((CPacketRecipeInfo) pkt).func_194156_a() == CPacketRecipeInfo.Purpose.SETTINGS;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketRecipeInfo info = (CPacketRecipeInfo) pkt;
            bookOpen = info.func_192624_c();
            filterActive = info.func_192625_d();
            Port262Connection conn = Port262.getConnection();
            if (conn != null) {
                conn.setRecipeBookSettings(bookOpen, filterActive);
            }
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(0);
            buf.writeBool(bookOpen);
            buf.writeBool(filterActive);
        }
    }

    public static class CDisplayedRecipe extends Packet262Out {

        public static final int ID = 47;

        private int displayId;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketRecipeInfo && ((CPacketRecipeInfo) pkt).func_194156_a() == CPacketRecipeInfo.Purpose.SHOWN;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketRecipeInfo info = (CPacketRecipeInfo) pkt;
            Port262Connection conn = Port262.getConnection();
            IRecipe recipe = info.func_193648_b();
            displayId = conn != null && recipe != null ? conn.displayForRecipe(recipe) : -1;
            if (displayId < 0) {
                client.tuff.TuffDebugLog.log("[26.2] displayed-recipe for untracked recipe — sending 0");
            }
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(Math.max(displayId, 0));
        }
    }
}
