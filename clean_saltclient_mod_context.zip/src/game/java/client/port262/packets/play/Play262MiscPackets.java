package client.port262.packets.play;

import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketInput;
import net.minecraft.network.play.client.CPacketSteerBoat;
import net.minecraft.network.play.client.CPacketTabComplete;
import net.minecraft.network.play.client.CPacketVehicleMove;
import net.minecraft.network.play.server.SPacketOpenWindow;
import net.minecraft.network.play.server.SPacketTabComplete;
import net.minecraft.util.text.TextComponentString;
import client.port262.Packet262In;
import client.port262.Packet262Out;
import client.port262.Port262Buffer;
import client.port262.Port262Connection;

public final class Play262MiscPackets {

    private Play262MiscPackets() {
    }

    public static class STabComplete extends Packet262In {

        public static final int ID = 15;

        public String[] matches = new String[0];

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            buf.readVarInt();
            buf.readVarInt();
            buf.readVarInt();
            int count = buf.readVarInt();
            if (count < 0 || count > 256) {
                throw new IOException("26.2 tab-complete match count out of range: " + count);
            }
            String[] out = new String[count];
            for (int i = 0; i < count; i++) {
                out[i] = buf.readString(1024);
                if (buf.readBool()) {
                    buf.skipAnonymousNbt();
                }
            }
            this.matches = out;
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketTabComplete(matches);
        }
    }

    public static class SOpenHorseWindow extends Packet262In {

        public static final int ID = 41;

        public int windowId;

        public int slotCount;

        public int entityId;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            windowId = buf.readVarInt();
            slotCount = buf.readVarInt();
            entityId = buf.readFixedInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            if (slotCount < 0 || slotCount > 64) {
                return null;
            }
            return new SPacketOpenWindow(windowId, "EntityHorse", new TextComponentString("Horse"), slotCount, entityId);
        }
    }

    public static class SStatistics extends Packet262In {

        public static final int ID = 3;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SUpdateLight extends Packet262In {

        public static final int ID = 48;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class CTabCompleteRequest extends Packet262Out {

        public static final int ID = 15;

        private int transactionCounter = 0;

        public int transactionId;

        public String text = "";

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketTabComplete;
        }

        @Override
        public void fromPacket(Packet pkt) {
            String message = ((CPacketTabComplete) pkt).getMessage();
            if (message == null) {
                message = "";
            }
            this.text = message.startsWith("/") ? message.substring(1) : message;
            this.transactionId = transactionCounter++;
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(transactionId);
            buf.writeString(text, 256);
        }
    }

    public static class SBundleDelimiter extends Packet262In {

        public static final int ID = 0;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SPing extends Packet262In {

        public static final int ID = 61;

        public int id;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            id = buf.readFixedInt();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            CPong pong = new CPong();
            pong.id = id;
            conn.sendOut(pong);
            return null;
        }
    }

    public static class SStartConfiguration extends Packet262In {

        public static final int ID = 118;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            conn.enterConfigurationState();
            return null;
        }
    }

    public static class SDeclareCommands extends Packet262In {

        public static final int ID = 16;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class STags extends Packet262In {

        public static final int ID = 134;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SAddResourcePack extends Packet262In {

        public static final int ID = 81;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SRemoveResourcePack extends Packet262In {

        public static final int ID = 80;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SUpdateViewDistance extends Packet262In {

        public static final int ID = 95;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SSimulationDistance extends Packet262In {

        public static final int ID = 111;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SStopSound extends Packet262In {

        public static final int ID = 119;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SServerData extends Packet262In {

        public static final int ID = 86;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class CConfigurationAcknowledged extends Packet262Out {

        public static final int ID = 16;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return false;
        }

        @Override
        public void fromPacket(Packet pkt) {
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
        }
    }

    public static class CPong extends Packet262Out {

        public static final int ID = 45;

        public int id;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return false;
        }

        @Override
        public void fromPacket(Packet pkt) {
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeFixedInt(id);
        }
    }

    public interface PlayerInputBits {

        int FORWARD = 0x01;

        int BACKWARD = 0x02;

        int LEFT = 0x04;

        int RIGHT = 0x08;

        int JUMP = 0x10;

        int SHIFT = 0x20;

        int SPRINT = 0x40;
    }

    public static class CPlayerInput extends Packet262Out {

        public static final int ID = 43;

        public int flags;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketInput;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketInput p = (CPacketInput) pkt;
            int f = 0;
            if (p.func_192620_b() > 0.0F) {
                f |= PlayerInputBits.FORWARD;
            }
            if (p.func_192620_b() < 0.0F) {
                f |= PlayerInputBits.BACKWARD;
            }
            if (p.getStrafeSpeed() > 0.0F) {
                f |= PlayerInputBits.LEFT;
            }
            if (p.getStrafeSpeed() < 0.0F) {
                f |= PlayerInputBits.RIGHT;
            }
            if (p.isJumping()) {
                f |= PlayerInputBits.JUMP;
            }
            if (p.isSneaking()) {
                f |= PlayerInputBits.SHIFT;
            }
            if (connection != null && (connection.playerInputFlags() & PlayerInputBits.SPRINT) != 0) {
                f |= PlayerInputBits.SPRINT;
            }
            flags = f;
            if (connection != null) {
                connection.setPlayerInputFlags(f);
            }
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeByte(flags);
        }
    }

    public static class CEntityAction extends Packet262Out {

        public static final int ID = 42;

        public int entityId;

        public int actionId = -1;

        public int jumpBoost;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketEntityAction;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketEntityAction p = (CPacketEntityAction) pkt;
            int stored = connection != null ? connection.playerInputFlags() : 0;
            actionId = -1;
            switch(p.getAction()) {
                case STOP_SLEEPING:
                    actionId = 0;
                    break;
                case START_SPRINTING:
                    actionId = 1;
                    stored |= PlayerInputBits.SPRINT;
                    break;
                case STOP_SPRINTING:
                    actionId = 2;
                    stored &= ~PlayerInputBits.SPRINT;
                    break;
                case START_RIDING_JUMP:
                    actionId = 3;
                    break;
                case STOP_RIDING_JUMP:
                    actionId = 4;
                    break;
                case OPEN_INVENTORY:
                    actionId = 5;
                    break;
                case START_FALL_FLYING:
                    actionId = 6;
                    break;
                case START_SNEAKING:
                    stored |= PlayerInputBits.SHIFT;
                    break;
                case STOP_SNEAKING:
                    stored &= ~PlayerInputBits.SHIFT;
                    break;
                default:
                    break;
            }
            if (connection != null) {
                connection.setPlayerInputFlags(stored);
            }
            jumpBoost = p.getAuxData();
            entityId = 0;
            if (Minecraft.getMinecraft().player != null) {
                entityId = Minecraft.getMinecraft().player.getEntityId();
            }
        }

        @Override
        public boolean shouldSend() {
            return actionId >= 0;
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(entityId);
            buf.writeVarInt(actionId);
            buf.writeVarInt(jumpBoost);
        }
    }

    public static class CVehicleMove extends Packet262Out {

        public static final int ID = 34;

        public double x;

        public double y;

        public double z;

        public float yaw;

        public float pitch;

        public boolean onGround;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketVehicleMove;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketVehicleMove p = (CPacketVehicleMove) pkt;
            x = p.getX();
            y = p.getY();
            z = p.getZ();
            yaw = p.getYaw();
            pitch = p.getPitch();
            onGround = Minecraft.getMinecraft().player != null && Minecraft.getMinecraft().player.onGround;
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeDouble(x);
            buf.writeDouble(y);
            buf.writeDouble(z);
            buf.writeFloat(yaw);
            buf.writeFloat(pitch);
            buf.writeBool(onGround);
        }
    }

    public static class CSteerBoat extends Packet262Out {

        public static final int ID = 35;

        public boolean leftPaddle;

        public boolean rightPaddle;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketSteerBoat;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketSteerBoat p = (CPacketSteerBoat) pkt;
            leftPaddle = p.getLeft();
            rightPaddle = p.getRight();
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeBool(leftPaddle);
            buf.writeBool(rightPaddle);
        }
    }
}
