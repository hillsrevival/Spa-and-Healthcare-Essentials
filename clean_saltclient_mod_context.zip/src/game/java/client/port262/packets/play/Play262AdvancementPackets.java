package client.port262.packets.play;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import io.netty.buffer.Unpooled;
import net.minecraft.advancements.FrameType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketSeenAdvancements;
import net.minecraft.network.play.server.SPacketAdvancementInfo;
import net.minecraft.network.play.server.SPacketSelectAdvancementsTab;
import net.minecraft.init.Blocks;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import client.port262.Packet262In;
import client.port262.Packet262Out;
import client.port262.Port262Buffer;
import client.port262.Port262Connection;
import client.port262.Port262Nbt;
import client.port262.Port262Stacks;
import client.port262.Port262Text;

public final class Play262AdvancementPackets {

    private Play262AdvancementPackets() {
    }

    static ResourceLocation rlFor(String id) {
        if (id == null || id.isEmpty()) {
            return new ResourceLocation("minecraft", "unknown");
        }
        if (id.indexOf(':') < 0) {
            return new ResourceLocation("minecraft", id);
        }
        return new ResourceLocation(id);
    }

    static ITextComponent componentFor(Object node) {
        ITextComponent comp = Port262Text.fromNbt(node);
        if (comp == null) {
            comp = new TextComponentString(Port262Text.plainText(node));
        }
        return comp;
    }

    static ItemStack fallbackIcon() {
        return new ItemStack(Item.getItemFromBlock(Blocks.BARRIER));
    }

    static FrameType frameFor(int v) {
        if (v < 0 || v >= FrameType.values().length) {
            v = 0;
        }
        return FrameType.values()[v];
    }

    public static class SAdvancements extends Packet262In {

        public static final int ID = 130;

        static class AdvEntry {

            String id;

            String parentId;

            DisplayData disp;

            String[][] requirements = new String[0][];
        }

        static class DisplayData {

            Object titleNbt;

            Object descNbt;

            ItemStack icon;

            int frame;

            int flags;

            String background;

            float x;

            float y;
        }

        static class ProgressEntry {

            String id;

            final List<String> names = new ArrayList<String>();

            final List<Long> dates = new ArrayList<Long>();
        }

        final List<AdvEntry> entries = new ArrayList<AdvEntry>();

        final List<String> removed = new ArrayList<String>();

        final List<ProgressEntry> progress = new ArrayList<ProgressEntry>();

        boolean reset;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            reset = buf.readBool();
            int count = buf.readVarInt();
            if (count < 0 || count > 4096) {
                throw new IOException("26.2 advancements mapping count out of range: " + count);
            }
            for (int i = 0; i < count; i++) {
                AdvEntry e = new AdvEntry();
                e.id = buf.readString();
                if (buf.readBool()) {
                    e.parentId = buf.readString();
                }
                if (buf.readBool()) {
                    DisplayData d = new DisplayData();
                    d.titleNbt = Port262Nbt.readAnonymous(buf);
                    d.descNbt = Port262Nbt.readAnonymous(buf);
                    d.icon = Port262Stacks.readStack(buf);
                    d.frame = buf.readVarInt();
                    d.flags = buf.readFixedInt();
                    if ((d.flags & 0x01) != 0) {
                        d.background = buf.readString();
                    }
                    d.x = buf.readFloat();
                    d.y = buf.readFloat();
                    e.disp = d;
                }
                int outer = buf.readVarInt();
                if (outer < 0 || outer > 1024) {
                    throw new IOException("26.2 advancements requirements count out of range: " + outer);
                }
                e.requirements = new String[outer][];
                for (int r = 0; r < outer; r++) {
                    int inner = buf.readVarInt();
                    if (inner < 0 || inner > 1024) {
                        throw new IOException("26.2 advancements requirement row out of range: " + inner);
                    }
                    e.requirements[r] = new String[inner];
                    for (int c = 0; c < inner; c++) {
                        e.requirements[r][c] = buf.readString();
                    }
                }
                boolean sendsTelemetry = buf.readBool();
                entries.add(e);
            }
            int removedCount = buf.readVarInt();
            if (removedCount < 0 || removedCount > 4096) {
                throw new IOException("26.2 advancements removed count out of range: " + removedCount);
            }
            for (int i = 0; i < removedCount; i++) {
                removed.add(buf.readString());
            }
            int progressCount = buf.readVarInt();
            if (progressCount < 0 || progressCount > 4096) {
                throw new IOException("26.2 advancements progress count out of range: " + progressCount);
            }
            for (int i = 0; i < progressCount; i++) {
                ProgressEntry p = new ProgressEntry();
                p.id = buf.readString();
                int critCount = buf.readVarInt();
                if (critCount < 0 || critCount > 4096) {
                    throw new IOException("26.2 advancements criterion count out of range: " + critCount);
                }
                for (int c = 0; c < critCount; c++) {
                    p.names.add(buf.readString());
                    if (buf.readBool()) {
                        p.dates.add(Long.valueOf(buf.readFixedLong()));
                    } else {
                        p.dates.add(null);
                    }
                }
                progress.add(p);
            }
            buf.readBool();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(256));
            scratch.writeBoolean(reset);
            scratch.writeVarIntToBuffer(entries.size());
            for (AdvEntry e : entries) {
                scratch.func_192572_a(rlFor(e.id));
                if (e.parentId != null) {
                    scratch.writeBoolean(true);
                    scratch.func_192572_a(rlFor(e.parentId));
                } else {
                    scratch.writeBoolean(false);
                }
                if (e.disp != null) {
                    scratch.writeBoolean(true);
                    writeDisplay(scratch, e.disp);
                } else {
                    scratch.writeBoolean(false);
                }
                Set<String> criteria = criteriaFor(e);
                scratch.writeVarIntToBuffer(criteria.size());
                for (String name : criteria) {
                    scratch.writeString(name);
                }
                scratch.writeVarIntToBuffer(e.requirements.length);
                for (String[] row : e.requirements) {
                    scratch.writeVarIntToBuffer(row.length);
                    for (String s : row) {
                        scratch.writeString(s);
                    }
                }
            }
            scratch.writeVarIntToBuffer(removed.size());
            for (String r : removed) {
                scratch.func_192572_a(rlFor(r));
            }
            scratch.writeVarIntToBuffer(progress.size());
            for (ProgressEntry p : progress) {
                scratch.func_192572_a(rlFor(p.id));
                scratch.writeVarIntToBuffer(p.names.size());
                for (int i = 0; i < p.names.size(); i++) {
                    scratch.writeString(p.names.get(i));
                    Long date = p.dates.get(i);
                    scratch.writeBoolean(date != null);
                    if (date != null) {
                        scratch.func_192574_a(new Date(date.longValue()));
                    }
                }
            }
            SPacketAdvancementInfo pkt = new SPacketAdvancementInfo();
            pkt.readPacketData(scratch);
            return pkt;
        }

        private Set<String> criteriaFor(AdvEntry e) {
            Set<String> set = new LinkedHashSet<String>();
            for (String[] row : e.requirements) {
                for (String s : row) {
                    if (s != null && !s.isEmpty()) {
                        set.add(s);
                    }
                }
            }
            for (ProgressEntry p : progress) {
                if (p.id != null && p.id.equals(e.id)) {
                    for (String name : p.names) {
                        if (name != null && !name.isEmpty()) {
                            set.add(name);
                        }
                    }
                }
            }
            return set;
        }

        private void writeDisplay(PacketBuffer scratch, DisplayData d) throws IOException {
            scratch.writeTextComponent(componentFor(d.titleNbt));
            scratch.writeTextComponent(componentFor(d.descNbt));
            ItemStack icon = d.icon != null ? d.icon : fallbackIcon();
            scratch.writeItemStackToBuffer(icon);
            scratch.writeEnumValue(frameFor(d.frame));
            scratch.writeInt(d.flags & 0x07);
            if ((d.flags & 0x01) != 0 && d.background != null) {
                scratch.func_192572_a(rlFor(d.background));
            }
            scratch.writeFloat(d.x);
            scratch.writeFloat(d.y);
        }
    }

    public static class SSelectAdvancementTab extends Packet262In {

        public static final int ID = 85;

        public String tabId;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            tabId = buf.readBool() ? buf.readString() : null;
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketSelectAdvancementsTab(tabId != null ? rlFor(tabId) : null);
        }
    }

    public static class CAdvancementTab extends Packet262Out {

        public static final int ID = 50;

        private boolean openedTab;

        private String tabId;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketSeenAdvancements;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketSeenAdvancements seen = (CPacketSeenAdvancements) pkt;
            openedTab = seen.func_194162_b() == CPacketSeenAdvancements.Action.OPENED_TAB;
            ResourceLocation tab = seen.func_194165_c();
            tabId = openedTab && tab != null ? tab.toString() : null;
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(openedTab ? 0 : 1);
            if (openedTab && tabId != null) {
                buf.writeString(tabId);
            }
        }
    }
}
