package client.port262.packets.play;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import io.netty.buffer.Unpooled;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.server.SPacketBlockChange;
import net.minecraft.network.play.server.SPacketChunkData;
import net.minecraft.network.play.server.SPacketJoinGame;
import net.minecraft.network.play.server.SPacketMaps;
import net.minecraft.network.play.server.SPacketMultiBlockChange;
import net.minecraft.network.play.server.SPacketSpawnPosition;
import net.minecraft.network.play.server.SPacketTimeUpdate;
import net.minecraft.network.play.server.SPacketUnloadChunk;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.GameType;
import net.minecraft.world.World;
import net.minecraft.world.WorldType;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.storage.MapDecoration;
import client.port262.Packet262In;
import client.port262.Packet262Out;
import client.port262.Port262BlockEntityMap;
import client.port262.Port262BlockMap;
import client.port262.Port262Buffer;
import client.port262.Port262ChunkDecoder;
import client.port262.Port262Connection;
import client.port262.Port262Nbt;

public final class Play262WorldPackets {

    private Play262WorldPackets() {
    }

    public static class SJoinGame extends Packet262In {

        public static final int ID = 49;

        public int entityId;

        public boolean isHardcore;

        public int dimensionNameCount;

        public int maxPlayers;

        public int viewDistance;

        public int simulationDistance;

        public boolean reducedDebugInfo;

        public boolean enableRespawnScreen;

        public boolean doLimitedCrafting;

        public int spawnDimensionId;

        public String dimensionName = "";

        public long hashedSeed;

        public int gamemode;

        public int previousGamemode;

        public boolean isDebug;

        public boolean isFlat;

        public int portalCooldown;

        public int seaLevel;

        public boolean enforcesSecureChat;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readFixedInt();
            isHardcore = buf.readBool();
            dimensionNameCount = buf.readVarInt();
            for (int i = 0; i < dimensionNameCount; i++) {
                buf.readString(32767);
            }
            maxPlayers = buf.readVarInt();
            viewDistance = buf.readVarInt();
            simulationDistance = buf.readVarInt();
            reducedDebugInfo = buf.readBool();
            enableRespawnScreen = buf.readBool();
            doLimitedCrafting = buf.readBool();
            spawnDimensionId = buf.readVarInt();
            dimensionName = buf.readString(32767);
            hashedSeed = buf.readFixedLong();
            gamemode = buf.readByte();
            previousGamemode = buf.readUByte();
            isDebug = buf.readBool();
            isFlat = buf.readBool();
            if (buf.readBool()) {
                buf.readString(32767);
                buf.readPosition();
            }
            portalCooldown = buf.readVarInt();
            seaLevel = buf.readVarInt();
            enforcesSecureChat = buf.readBool();
        }

        @Override
        public Packet process(Port262Connection conn) {
            GameType gameType = toGameType(gamemode);
            int dimension = toLegacyDimension(dimensionName);
            WorldType worldType = isFlat ? WorldType.FLAT : WorldType.DEFAULT;
            client.tuff.TuffDebugLog.log("[26.2] JoinGame: entity=" + entityId + " dim=" + dimensionName + " (-> " + dimension + ") mode=" + gamemode + " seed=" + hashedSeed);
            return new SPacketJoinGame(entityId, gameType, isHardcore, dimension, EnumDifficulty.NORMAL, maxPlayers, worldType, reducedDebugInfo);
        }
    }

    public static class SSpawnPosition extends Packet262In {

        public static final int ID = 97;

        public long location;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            buf.readString(32767);
            location = buf.readPosition();
            buf.readFloat();
            buf.readFloat();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketSpawnPosition(BlockPos.fromLong(location));
        }
    }

    public static class SUpdateTime extends Packet262In {

        public static final int ID = 113;

        public long age;

        public long dayTime;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            age = buf.readFixedLong();
            int clocks = buf.readVarInt();
            long first = 0L;
            long daylight = -1L;
            for (int i = 0; i < clocks; i++) {
                int id = buf.readVarInt();
                long totalTicks = buf.readVarLong();
                buf.readFloat();
                buf.readFloat();
                if (i == 0) {
                    first = totalTicks;
                }
                if (id == 0) {
                    daylight = totalTicks;
                }
            }
            dayTime = daylight >= 0 ? daylight : first;
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketTimeUpdate(age, dayTime, true);
        }
    }

    public static class SMapChunk extends Packet262In {

        public static final int ID = 45;

        public int chunkX;

        public int chunkZ;

        public int heightmapCount;

        private Packet translated;

        public Packet getTranslated() {
            return translated;
        }

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            chunkX = buf.readFixedInt();
            chunkZ = buf.readFixedInt();
            heightmapCount = buf.readVarInt();
            for (int i = 0; i < heightmapCount; i++) {
                buf.readVarInt();
                buf.skipLengthPrefixedLongs();
            }
            byte[] blob = buf.readLengthPrefixedBytes();
            Chunk decoded = Port262ChunkDecoder.decode(blob, chunkX, chunkZ, Minecraft.getMinecraft().world);
            if (decoded != null) {
                readBlockEntities(buf, decoded, Minecraft.getMinecraft().world);
                translated = new SPacketChunkData(decoded, 65535);
            } else {
                translated = null;
            }
        }

        private static void readBlockEntities(Port262Buffer buf, Chunk chunk, World world) throws IOException {
            int count = buf.readVarInt();
            if (count < 0 || count > 4096) {
                throw new IOException("26.2 chunk block-entity count out of range: " + count);
            }
            for (int i = 0; i < count; i++) {
                int packedXZ = buf.readUByte();
                int bx = (packedXZ >> 4) & 15;
                int bz = packedXZ & 15;
                int by = buf.readShort();
                buf.readVarInt();
                Map<String, Object> nbt = Port262Nbt.readRootCompound(buf);
                if (nbt == null || by < 0 || by > 255) {
                    continue;
                }
                int wx = (chunk.xPosition << 4) + bx;
                int wz = (chunk.zPosition << 4) + bz;
                String id = nbt.get("id") instanceof String ? (String) nbt.get("id") : null;
                NBTTagCompound tag = Port262BlockEntityMap.rewrite(id, nbt, wx, by, wz);
                if (tag == null || world == null) {
                    continue;
                }
                TileEntity te = TileEntity.create(world, tag);
                if (te != null) {
                    chunk.getTileEntityMap().put(new BlockPos(wx, by, wz), te);
                }
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            return translated;
        }
    }

    public static class SBlockEntityData extends Packet262In {

        public static final int ID = 6;

        public long location;

        public Map<String, Object> nbt;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            location = buf.readPosition();
            buf.readVarInt();
            nbt = Port262Nbt.readRootCompound(buf);
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            if (nbt == null) {
                return null;
            }
            String id = nbt.get("id") instanceof String ? (String) nbt.get("id") : null;
            int metadata = Port262BlockEntityMap.metadataFor(id);
            if (metadata < 0) {
                return null;
            }
            BlockPos pos = BlockPos.fromLong(location);
            NBTTagCompound tag = Port262BlockEntityMap.rewrite(id, nbt, pos.getX(), pos.getY(), pos.getZ());
            if (tag == null) {
                return null;
            }
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(512));
            scratch.writeBlockPos(pos);
            scratch.writeByte(metadata);
            scratch.writeNBTTagCompoundToBuffer(tag);
            SPacketUpdateTileEntity out = new SPacketUpdateTileEntity();
            out.readPacketData(scratch);
            return out;
        }
    }

    public static class SUnloadChunk extends Packet262In {

        public static final int ID = 37;

        public int chunkX;

        public int chunkZ;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            chunkZ = buf.readFixedInt();
            chunkX = buf.readFixedInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketUnloadChunk(chunkX, chunkZ);
        }
    }

    public static class SBlockChange extends Packet262In {

        public static final int ID = 8;

        public long location;

        public int stateId;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            location = buf.readPosition();
            stateId = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(9));
            scratch.writeBlockPos(BlockPos.fromLong(location));
            scratch.writeVarIntToBuffer(Port262BlockMap.map(stateId));
            SPacketBlockChange out = new SPacketBlockChange();
            out.readPacketData(scratch);
            return out;
        }
    }

    public static class SMultiBlockChange extends Packet262In {

        public static final int ID = 84;

        public long chunkCoordinates;

        public long[] records = new long[0];

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            chunkCoordinates = buf.readFixedLong();
            int count = buf.readVarInt();
            if (count < 0 || count > 65536) {
                throw new IOException("26.2 multi block change record count out of range: " + count);
            }
            records = new long[count];
            for (int i = 0; i < count; i++) {
                records[i] = buf.readVarLong();
            }
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            int sectionX = (int) (chunkCoordinates >> 42);
            int sectionZ = (int) ((chunkCoordinates << 22) >> 42);
            int sectionY = (int) ((chunkCoordinates << 44) >> 44);
            if (sectionY < 0 || sectionY > 15) {
                for (long record : records) {
                    int stateId = (int) (record >> 12);
                    int localX = (int) ((record >> 8) & 15L);
                    int localZ = (int) ((record >> 4) & 15L);
                    int localY = (int) (record & 15L);
                    PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(9));
                    scratch.writeBlockPos(new BlockPos((sectionX << 4) + localX, (sectionY << 4) | localY, (sectionZ << 4) + localZ));
                    scratch.writeVarIntToBuffer(Port262BlockMap.map(stateId));
                    SPacketBlockChange out = new SPacketBlockChange();
                    out.readPacketData(scratch);
                    conn.dispatch(out);
                }
                return null;
            }
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(8 + records.length * 6));
            scratch.writeInt(sectionX << 4);
            scratch.writeInt(sectionZ << 4);
            scratch.writeVarIntToBuffer(records.length);
            for (long record : records) {
                int stateId = (int) (record >> 12);
                int localX = (int) ((record >> 8) & 15L);
                int localZ = (int) ((record >> 4) & 15L);
                int localY = (int) (record & 15L);
                int worldY = (sectionY << 4) | localY;
                scratch.writeShort((localX << 12) | (localZ << 8) | worldY);
                scratch.writeVarIntToBuffer(Port262BlockMap.map(stateId));
            }
            SPacketMultiBlockChange out = new SPacketMultiBlockChange();
            out.readPacketData(scratch);
            return out;
        }
    }

    public static class SUpdateViewPosition extends Packet262In {

        public static final int ID = 94;

        public int chunkX;

        public int chunkZ;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            chunkX = buf.readVarInt();
            chunkZ = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SChunkBatchStart extends Packet262In {

        public static final int ID = 12;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
        }

        @Override
        public Packet process(Port262Connection conn) {
            return null;
        }
    }

    public static class SChunkBatchFinished extends Packet262In {

        public static final int ID = 11;

        public int batchSize;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            batchSize = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            conn.sendOut(new CChunkBatchReceived(8.0f));
            return null;
        }
    }

    public static class CChunkBatchReceived extends Packet262Out {

        public static final int ID = 11;

        public final float chunksPerTick;

        public CChunkBatchReceived(float chunksPerTick) {
            this.chunksPerTick = chunksPerTick;
        }

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return false;
        }

        @Override
        public void fromPacket(Packet pkt) {
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeFloat(chunksPerTick);
        }
    }

    public static class SMapData extends Packet262In {

        public static final int ID = 51;

        public int mapId;

        public byte scale;

        public boolean hasIcons;

        public final List<MapDecoration> icons = new ArrayList<MapDecoration>();

        public int columns;

        public int rows;

        public int minX;

        public int minZ;

        public byte[] data = new byte[0];

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            mapId = buf.readVarInt();
            scale = buf.readByte();
            buf.readBool();
            hasIcons = buf.readBool();
            if (hasIcons) {
                int count = buf.readVarInt();
                if (count < 0 || count > 1024) {
                    throw new IOException("26.2 map icon count out of range: " + count);
                }
                for (int i = 0; i < count; i++) {
                    int type = buf.readVarInt();
                    byte x = buf.readByte();
                    byte z = buf.readByte();
                    int direction = buf.readUByte();
                    if (type >= 0 && type <= 9) {
                        icons.add(new MapDecoration(MapDecoration.Type.values()[type], x, z, (byte) direction));
                    }
                    if (buf.readBool()) {
                        Port262Nbt.readAnonymous(buf);
                    }
                }
            }
            columns = buf.readUByte();
            if (columns != 0) {
                rows = buf.readUByte();
                minX = buf.readUByte();
                minZ = buf.readUByte();
                data = buf.readLengthPrefixedBytes();
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            List<MapDecoration> decorations = icons;
            if (!hasIcons) {
                MapDecoration[] cached = conn.mapDecorationsFor(mapId);
                decorations = cached != null ? java.util.Arrays.asList(cached) : new ArrayList<MapDecoration>(0);
            } else {
                conn.trackMapDecorations(mapId, icons.toArray(new MapDecoration[icons.size()]));
            }
            byte[] full = new byte[128 * 128];
            if (columns != 0 && data.length == columns * rows) {
                for (int j = 0; j < rows; j++) {
                    for (int i = 0; i < columns; i++) {
                        full[minX + i + (minZ + j) * 128] = data[i + j * columns];
                    }
                }
            }
            return new SPacketMaps(mapId, scale, true, decorations, full, minX, minZ, columns, rows);
        }
    }

    static GameType toGameType(int mode) {
        switch(mode) {
            case 1:
                return GameType.CREATIVE;
            case 2:
                return GameType.ADVENTURE;
            case 3:
                return GameType.SPECTATOR;
            default:
                return GameType.SURVIVAL;
        }
    }

    static int toLegacyDimension(String name) {
        if (name == null) {
            return 0;
        }
        if (name.contains("nether")) {
            return -1;
        }
        if (name.contains("end")) {
            return 1;
        }
        return 0;
    }
}
