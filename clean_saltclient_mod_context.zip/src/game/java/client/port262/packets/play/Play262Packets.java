package client.port262.packets.play;

import java.io.IOException;
import client.port262.Packet262In;
import client.port262.Packet262Out;
import client.port262.Port262Buffer;
import client.port262.Port262Connection;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.server.SPacketCustomPayload;
import net.minecraft.network.play.server.SPacketDisconnect;
import net.minecraft.network.play.server.SPacketKeepAlive;
import net.minecraft.util.text.TextComponentString;

public final class Play262Packets {

    private Play262Packets() {
    }

    public static class SKeepAlive extends Packet262In {

        public static final int ID = 44;

        public long id;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            id = buf.readFixedLong();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketKeepAlive(id);
        }
    }

    public static class SKickDisconnect extends Packet262In {

        public static final int ID = 32;

        public String reason = "Disconnected by server (26.2)";

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            Object node = client.port262.Port262Nbt.readAnonymous(buf);
            String text = client.port262.Port262Text.plainText(node);
            if (text != null && !text.trim().isEmpty()) {
                reason = text.trim();
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketDisconnect(new TextComponentString(reason));
        }
    }

    public static class SPluginMessage extends Packet262In {

        public static final int ID = 24;

        public String channel;

        public byte[] data;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            channel = buf.readString(256);
            data = buf.readRestBuffer();
        }

        @Override
        public Packet process(Port262Connection conn) {
            io.netty.buffer.ByteBuf netty = io.netty.buffer.Unpooled.buffer(data.length);
            netty.writeBytes(data);
            return new SPacketCustomPayload(channel, new PacketBuffer(netty));
        }
    }

    public static class CKeepAlive extends Packet262Out {

        public static final int ID = 28;

        public long id;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof net.minecraft.network.play.client.CPacketKeepAlive;
        }

        @Override
        public void fromPacket(Packet pkt) {
            id = ((net.minecraft.network.play.client.CPacketKeepAlive) pkt).getKey();
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeFixedLong(id);
        }
    }

    public static class CPluginMessage extends Packet262Out {

        public static final int ID = 22;

        public String channel;

        public byte[] data;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof net.minecraft.network.play.client.CPacketCustomPayload;
        }

        @Override
        public void fromPacket(Packet pkt) {
            net.minecraft.network.play.client.CPacketCustomPayload c = (net.minecraft.network.play.client.CPacketCustomPayload) pkt;
            channel = c.getChannelName();
            io.netty.buffer.ByteBuf buf = c.getBufferData();
            data = new byte[buf.readableBytes()];
            buf.getBytes(buf.readerIndex(), data);
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeString(channel, 256);
            buf.writeBytes(data);
        }
    }
}
