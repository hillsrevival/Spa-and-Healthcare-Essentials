package client.port262.packets.play;

import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketWorldBorder;
import net.minecraft.world.border.WorldBorder;
import client.port262.Packet262In;
import client.port262.Port262Buffer;
import client.port262.Port262Connection;

public final class Play262BorderPackets {

    private Play262BorderPackets() {
    }

    private static boolean worldReady() {
        return Minecraft.getMinecraft().world != null;
    }

    public static class SInitializeWorldBorder extends Packet262In {

        public static final int ID = 43;

        public double x;

        public double z;

        public double oldDiameter;

        public double newDiameter;

        public int speed;

        public int portalBoundary;

        public int warningBlocks;

        public int warningTime;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            x = buf.readDouble();
            z = buf.readDouble();
            oldDiameter = buf.readDouble();
            newDiameter = buf.readDouble();
            speed = buf.readVarInt();
            portalBoundary = buf.readVarInt();
            warningBlocks = buf.readVarInt();
            warningTime = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            if (!worldReady()) {
                return null;
            }
            WorldBorder b = new WorldBorder();
            b.setCenter(x, z);
            if (speed > 0 && newDiameter != oldDiameter) {
                b.setTransition(oldDiameter, newDiameter, speed);
            } else {
                b.setTransition(newDiameter);
            }
            b.setSize(portalBoundary);
            b.setWarningDistance(warningBlocks);
            b.setWarningTime(warningTime);
            return new SPacketWorldBorder(b, SPacketWorldBorder.Action.INITIALIZE);
        }
    }

    public static class SWorldBorderCenter extends Packet262In {

        public static final int ID = 88;

        public double x;

        public double z;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            x = buf.readDouble();
            z = buf.readDouble();
        }

        @Override
        public Packet process(Port262Connection conn) {
            if (!worldReady()) {
                return null;
            }
            WorldBorder b = new WorldBorder();
            b.setCenter(x, z);
            return new SPacketWorldBorder(b, SPacketWorldBorder.Action.SET_CENTER);
        }
    }

    public static class SWorldBorderLerpSize extends Packet262In {

        public static final int ID = 89;

        public double oldDiameter;

        public double newDiameter;

        public int speed;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            oldDiameter = buf.readDouble();
            newDiameter = buf.readDouble();
            speed = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            if (!worldReady()) {
                return null;
            }
            WorldBorder b = new WorldBorder();
            if (speed > 0 && newDiameter != oldDiameter) {
                b.setTransition(oldDiameter, newDiameter, speed);
            } else {
                b.setTransition(newDiameter);
            }
            return new SPacketWorldBorder(b, SPacketWorldBorder.Action.LERP_SIZE);
        }
    }

    public static class SWorldBorderSize extends Packet262In {

        public static final int ID = 90;

        public double diameter;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            diameter = buf.readDouble();
        }

        @Override
        public Packet process(Port262Connection conn) {
            if (!worldReady()) {
                return null;
            }
            WorldBorder b = new WorldBorder();
            b.setTransition(diameter);
            return new SPacketWorldBorder(b, SPacketWorldBorder.Action.SET_SIZE);
        }
    }

    public static class SWorldBorderWarningDelay extends Packet262In {

        public static final int ID = 91;

        public int warningTime;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            warningTime = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            if (!worldReady()) {
                return null;
            }
            WorldBorder b = new WorldBorder();
            b.setWarningTime(warningTime);
            return new SPacketWorldBorder(b, SPacketWorldBorder.Action.SET_WARNING_TIME);
        }
    }

    public static class SWorldBorderWarningReach extends Packet262In {

        public static final int ID = 92;

        public int warningBlocks;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            warningBlocks = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            if (!worldReady()) {
                return null;
            }
            WorldBorder b = new WorldBorder();
            b.setWarningDistance(warningBlocks);
            return new SPacketWorldBorder(b, SPacketWorldBorder.Action.SET_WARNING_BLOCKS);
        }
    }
}
