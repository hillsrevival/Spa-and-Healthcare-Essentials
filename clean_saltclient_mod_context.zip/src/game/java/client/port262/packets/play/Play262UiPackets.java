package client.port262.packets.play;

import java.io.IOException;
import io.netty.buffer.Unpooled;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.client.CPacketClientStatus;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.network.play.server.SPacketChangeGameState;
import net.minecraft.network.play.server.SPacketEffect;
import net.minecraft.network.play.server.SPacketEntityHeadLook;
import net.minecraft.network.play.server.SPacketHeldItemChange;
import net.minecraft.network.play.server.SPacketPlayerListHeaderFooter;
import net.minecraft.network.play.server.SPacketPlayerListItem;
import net.minecraft.network.play.server.SPacketRespawn;
import net.minecraft.network.play.server.SPacketServerDifficulty;
import net.minecraft.network.play.server.SPacketSetExperience;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.network.play.server.SPacketTitle;
import net.minecraft.network.play.server.SPacketUpdateBossInfo;
import net.minecraft.network.play.server.SPacketUpdateHealth;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.BossInfo;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.WorldType;
import net.lax1dude.eaglercraft.EaglercraftUUID;
import client.port262.Packet262In;
import client.port262.Packet262Out;
import client.port262.Port262Buffer;
import client.port262.Port262Connection;
import client.port262.Port262Nbt;
import client.port262.Port262SoundMap;
import client.port262.Port262Text;

public final class Play262UiPackets {

    private Play262UiPackets() {
    }

    private static void debug(String msg) {
        client.tuff.TuffDebugLog.log("[26.2] " + msg);
    }

    public static class SSystemChat extends Packet262In {

        public static final int ID = 121;

        public ITextComponent component;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            Object node = Port262Nbt.readAnonymous(buf);
            boolean overlay = buf.readBool();
            component = Port262Text.fromNbt(node);
            if (overlay) {
                component = new OverlayMarker(component);
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            if (component instanceof OverlayMarker) {
                return new SPacketChat(((OverlayMarker) component).inner, ChatType.GAME_INFO);
            }
            return new SPacketChat(component);
        }
    }

    private static final class OverlayMarker extends TextComponentString {

        final ITextComponent inner;

        OverlayMarker(ITextComponent inner) {
            super("");
            this.inner = inner;
        }
    }

    public static class SPlayerChat extends Packet262In {

        public static final int ID = 65;

        public String plainMessage = "";

        public ITextComponent unsigned;

        public int chatType;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            buf.readVarInt();
            buf.readUuidMsb();
            buf.readUuidLsb();
            buf.readVarInt();
            if (buf.readBool()) {
                buf.skipBytes(256);
            }
            plainMessage = buf.readString(32767);
            buf.readFixedLong();
            buf.readFixedLong();
            int prev = buf.readVarInt();
            for (int i = 0; i < prev; i++) {
                int id = buf.readVarInt();
                if (id == 0) {
                    buf.skipBytes(256);
                }
            }
            if (buf.readBool()) {
                unsigned = Port262Text.fromNbt(Port262Nbt.readAnonymous(buf));
            }
            int filter = buf.readVarInt();
            if (filter == 2) {
                int maskCount = buf.readVarInt();
                for (int i = 0; i < maskCount; i++) {
                    buf.readFixedLong();
                }
            }
            int typeHolder = buf.readVarInt();
            if (typeHolder <= 0) {
                throw new client.port262.Port262SkipException("inline chat type data");
            }
            chatType = typeHolder - 1;
            Port262Nbt.readAnonymous(buf);
            if (buf.readBool()) {
                Port262Nbt.readAnonymous(buf);
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            ITextComponent body = unsigned != null ? unsigned : new TextComponentString(plainMessage);
            ChatType type;
            switch(chatType) {
                case 2:
                    type = ChatType.GAME_INFO;
                    break;
                default:
                    type = ChatType.CHAT;
                    break;
            }
            return new SPacketChat(body, type);
        }
    }

    public static class SActionBar extends Packet262In {

        public static final int ID = 87;

        public ITextComponent component;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            component = Port262Text.fromNbt(Port262Nbt.readAnonymous(buf));
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketChat(component, ChatType.GAME_INFO);
        }
    }

    public static class STitleText extends Packet262In {

        public static final int ID = 114;

        public ITextComponent component;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            component = Port262Text.fromNbt(Port262Nbt.readAnonymous(buf));
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketTitle(SPacketTitle.Type.TITLE, component);
        }
    }

    public static class STitleSubtitle extends Packet262In {

        public static final int ID = 112;

        public ITextComponent component;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            component = Port262Text.fromNbt(Port262Nbt.readAnonymous(buf));
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketTitle(SPacketTitle.Type.SUBTITLE, component);
        }
    }

    public static class STitleTime extends Packet262In {

        public static final int ID = 115;

        public int fadeIn;

        public int stay;

        public int fadeOut;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            fadeIn = buf.readFixedInt();
            stay = buf.readFixedInt();
            fadeOut = buf.readFixedInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketTitle(fadeIn, stay, fadeOut);
        }
    }

    public static class SClearTitles extends Packet262In {

        public static final int ID = 14;

        public boolean reset;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            reset = buf.readBool();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketTitle(reset ? SPacketTitle.Type.RESET : SPacketTitle.Type.CLEAR, (ITextComponent) null);
        }
    }

    public static class SPlayerListHeader extends Packet262In {

        public static final int ID = 122;

        public ITextComponent header;

        public ITextComponent footer;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            header = Port262Text.fromNbt(Port262Nbt.readAnonymous(buf));
            footer = Port262Text.fromNbt(Port262Nbt.readAnonymous(buf));
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(64));
            scratch.writeTextComponent(header != null ? header : new TextComponentString(""));
            scratch.writeTextComponent(footer != null ? footer : new TextComponentString(""));
            SPacketPlayerListHeaderFooter out = new SPacketPlayerListHeaderFooter();
            out.readPacketData(scratch);
            return out;
        }
    }

    public static class SPlayerInfo extends Packet262In {

        public static final int ID = 70;

        public static final int ACT_ADD = 0x01;

        public static final int ACT_CHAT = 0x02;

        public static final int ACT_GAMEMODE = 0x04;

        public static final int ACT_LISTED = 0x08;

        public static final int ACT_LATENCY = 0x10;

        public static final int ACT_DISPLAY = 0x20;

        public static final int ACT_HAT = 0x40;

        public static final int ACT_ORDER = 0x80;

        public int actions;

        public EaglercraftUUID uuid;

        public String name = "";

        public int gamemode;

        public int latency;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            actions = buf.readUByte();
            int count = buf.readVarInt();
            if (count < 1) {
                actions = 0;
                return;
            }
            uuid = new EaglercraftUUID(buf.readUuidMsb(), buf.readUuidLsb());
            if ((actions & ACT_ADD) != 0) {
                name = buf.readString(16);
                int props = buf.readVarInt();
                for (int i = 0; i < props; i++) {
                    buf.readString(32767);
                    buf.readString(32767);
                    if (buf.readBool()) {
                        buf.readString(32767);
                    }
                }
            }
            if ((actions & ACT_CHAT) != 0) {
                if (buf.readBool()) {
                    buf.readUuidMsb();
                    buf.readUuidLsb();
                    buf.readFixedLong();
                    int keyLen = buf.readVarInt();
                    buf.skipBytes(keyLen);
                    int sigLen = buf.readVarInt();
                    buf.skipBytes(sigLen);
                }
            }
            if ((actions & ACT_GAMEMODE) != 0) {
                gamemode = buf.readVarInt();
            }
            if ((actions & ACT_LISTED) != 0) {
                buf.readVarInt();
            }
            if ((actions & ACT_LATENCY) != 0) {
                latency = buf.readVarInt();
            }
            if ((actions & ACT_DISPLAY) != 0) {
                if (buf.readBool()) {
                    Port262Nbt.readAnonymous(buf);
                }
            }
            if ((actions & ACT_ORDER) != 0) {
                buf.readVarInt();
            }
            if ((actions & ACT_HAT) != 0) {
                buf.readBool();
            }
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            if (actions == 0 || uuid == null) {
                return null;
            }
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(64));
            if ((actions & ACT_ADD) != 0) {
                scratch.writeVarIntToBuffer(0);
                scratch.writeVarIntToBuffer(1);
                scratch.writeUuid(uuid);
                scratch.writeString(name.length() > 0 ? name : "player");
                scratch.writeVarIntToBuffer(0);
                scratch.writeVarIntToBuffer(clampGamemode(gamemode));
                scratch.writeVarIntToBuffer(latency);
                scratch.writeBoolean(false);
            } else if ((actions & ACT_GAMEMODE) != 0) {
                scratch.writeVarIntToBuffer(1);
                scratch.writeVarIntToBuffer(1);
                scratch.writeUuid(uuid);
                scratch.writeVarIntToBuffer(clampGamemode(gamemode));
            } else if ((actions & ACT_LATENCY) != 0) {
                scratch.writeVarIntToBuffer(2);
                scratch.writeVarIntToBuffer(1);
                scratch.writeUuid(uuid);
                scratch.writeVarIntToBuffer(latency);
            } else if ((actions & ACT_DISPLAY) != 0) {
                return null;
            } else {
                return null;
            }
            SPacketPlayerListItem out = new SPacketPlayerListItem();
            out.readPacketData(scratch);
            return out;
        }

        private static int clampGamemode(int mode) {
            if (mode < 0 || mode > 3) {
                return 0;
            }
            return mode;
        }
    }

    public static class SPlayerRemove extends Packet262In {

        public static final int ID = 69;

        public EaglercraftUUID[] uuids = new EaglercraftUUID[0];

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            int count = buf.readVarInt();
            if (count < 0 || count > 256) {
                throw new IOException("26.2 player_remove count out of range: " + count);
            }
            uuids = new EaglercraftUUID[count];
            for (int i = 0; i < count; i++) {
                uuids[i] = new EaglercraftUUID(buf.readUuidMsb(), buf.readUuidLsb());
            }
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(16 * uuids.length + 8));
            scratch.writeVarIntToBuffer(4);
            scratch.writeVarIntToBuffer(uuids.length);
            for (EaglercraftUUID uuid : uuids) {
                scratch.writeUuid(uuid);
            }
            SPacketPlayerListItem out = new SPacketPlayerListItem();
            out.readPacketData(scratch);
            return out;
        }
    }

    public static class SUpdateHealth extends Packet262In {

        public static final int ID = 104;

        public float health;

        public int food;

        public float saturation;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            health = buf.readFloat();
            food = buf.readVarInt();
            saturation = buf.readFloat();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketUpdateHealth(health, food, saturation);
        }
    }

    public static class SExperience extends Packet262In {

        public static final int ID = 103;

        public float bar;

        public int level;

        public int total;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            bar = buf.readFloat();
            level = buf.readVarInt();
            total = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketSetExperience(bar, total, level);
        }
    }

    public static class SHeldItemSlot extends Packet262In {

        public static final int ID = 105;

        public int slot;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            slot = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketHeldItemChange(slot >= 0 && slot < 9 ? slot : 0);
        }
    }

    public static class SGameStateChange extends Packet262In {

        public static final int ID = 38;

        public int reason;

        public float value;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            reason = buf.readUByte();
            value = buf.readFloat();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketChangeGameState(reason, value);
        }
    }

    public static class SRespawn extends Packet262In {

        public static final int ID = 82;

        public int dimensionId;

        public String dimensionName = "";

        public int gamemode;

        public boolean isFlat;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            dimensionId = buf.readVarInt();
            dimensionName = buf.readString(32767);
            buf.readFixedLong();
            gamemode = buf.readByte();
            buf.readUByte();
            buf.readBool();
            isFlat = buf.readBool();
            if (buf.readBool()) {
                buf.readString(32767);
                buf.readPosition();
            }
            buf.readVarInt();
            buf.readVarInt();
            buf.readUByte();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketRespawn(Play262WorldPackets.toLegacyDimension(dimensionName), EnumDifficulty.NORMAL, isFlat ? WorldType.FLAT : WorldType.DEFAULT, Play262WorldPackets.toGameType(gamemode));
        }
    }

    public static class SDifficulty extends Packet262In {

        public static final int ID = 10;

        public int difficulty;

        public boolean locked;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            difficulty = buf.readVarInt();
            locked = buf.readBool();
        }

        @Override
        public Packet process(Port262Connection conn) {
            EnumDifficulty diff;
            switch(difficulty) {
                case 0:
                    diff = EnumDifficulty.PEACEFUL;
                    break;
                case 1:
                    diff = EnumDifficulty.EASY;
                    break;
                case 3:
                    diff = EnumDifficulty.HARD;
                    break;
                default:
                    diff = EnumDifficulty.NORMAL;
                    break;
            }
            return new SPacketServerDifficulty(diff, locked);
        }
    }

    public static class SCamera extends Packet262In {

        public static final int ID = 93;

        public int entityId;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            entityId = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(8));
            scratch.writeVarIntToBuffer(entityId);
            net.minecraft.network.play.server.SPacketCamera out = new net.minecraft.network.play.server.SPacketCamera();
            out.readPacketData(scratch);
            return out;
        }
    }

    public static class SWorldEvent extends Packet262In {

        public static final int ID = 46;

        public int effectId;

        public long location;

        public int data;

        public boolean global;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            effectId = buf.readFixedInt();
            location = buf.readPosition();
            data = buf.readFixedInt();
            global = buf.readBool();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketEffect(effectId, BlockPos.fromLong(location), data, global);
        }
    }

    public static class SSoundEffect extends Packet262In {

        public static final int ID = 117;

        public String soundName;

        public int category;

        public int x;

        public int y;

        public int z;

        public float volume;

        public float pitch;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            soundName = readSoundHolder(buf);
            category = buf.readVarInt();
            x = buf.readFixedInt();
            y = buf.readFixedInt();
            z = buf.readFixedInt();
            volume = buf.readFloat();
            pitch = buf.readFloat();
            buf.readFixedLong();
        }

        @Override
        public Packet process(Port262Connection conn) {
            SoundEvent event = resolveSound(soundName);
            if (event == null) {
                return null;
            }
            return new SPacketSoundEffect(event, category(category), x / 4096.0D, y / 4096.0D, z / 4096.0D, volume, pitch);
        }
    }

    public static class SEntitySoundEffect extends Packet262In {

        public static final int ID = 116;

        public String soundName;

        public int category;

        public int entityId;

        public float volume;

        public float pitch;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            soundName = readSoundHolder(buf);
            category = buf.readVarInt();
            entityId = buf.readVarInt();
            volume = buf.readFloat();
            pitch = buf.readFloat();
            buf.readFixedLong();
        }

        @Override
        public Packet process(Port262Connection conn) {
            SoundEvent event = resolveSound(soundName);
            if (event == null) {
                return null;
            }
            double x = 0.0D;
            double y = 0.0D;
            double z = 0.0D;
            Minecraft mc = Minecraft.getMinecraft();
            if (mc != null && mc.world != null) {
                Entity entity = mc.world.getEntityByID(entityId);
                if (entity != null) {
                    x = entity.posX;
                    y = entity.posY;
                    z = entity.posZ;
                }
            }
            return new SPacketSoundEffect(event, category(category), x, y, z, volume, pitch);
        }
    }

    public static class SBossBar extends Packet262In {

        public static final int ID = 9;

        public long uuidMsb;

        public long uuidLsb;

        public int action;

        public ITextComponent name;

        public float health = 1.0F;

        public int color;

        public int dividers;

        public int flags;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            uuidMsb = buf.readUuidMsb();
            uuidLsb = buf.readUuidLsb();
            action = buf.readVarInt();
            switch(action) {
                case 0:
                    name = Port262Text.fromNbt(Port262Nbt.readAnonymous(buf));
                    health = buf.readFloat();
                    color = buf.readVarInt();
                    dividers = buf.readVarInt();
                    flags = buf.readUByte();
                    break;
                case 1:
                    break;
                case 2:
                    health = buf.readFloat();
                    break;
                case 3:
                    name = Port262Text.fromNbt(Port262Nbt.readAnonymous(buf));
                    break;
                case 4:
                    color = buf.readVarInt();
                    dividers = buf.readVarInt();
                    break;
                case 5:
                    flags = buf.readUByte();
                    break;
                default:
                    break;
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            BossInfo.Color colorEnum = BossInfo.Color.values()[Math.min(Math.max(color, 0), 6)];
            BossInfo.Overlay overlayEnum = BossInfo.Overlay.values()[Math.min(Math.max(dividers, 0), 4)];
            ITextComponent shown = name != null ? name : new TextComponentString("Boss");
            BossInfo data = new BossInfo(new EaglercraftUUID(uuidMsb, uuidLsb), shown, colorEnum, overlayEnum) {
            };
            data.setPercent(Math.min(Math.max(health, 0.0F), 1.0F));
            data.setDarkenSky((flags & 0x01) != 0);
            data.setPlayEndBossMusic((flags & 0x02) != 0);
            data.setCreateFog((flags & 0x04) != 0);
            SPacketUpdateBossInfo.Operation op;
            switch(action) {
                case 1:
                    op = SPacketUpdateBossInfo.Operation.REMOVE;
                    break;
                case 2:
                    op = SPacketUpdateBossInfo.Operation.UPDATE_PCT;
                    break;
                case 3:
                    op = SPacketUpdateBossInfo.Operation.UPDATE_NAME;
                    break;
                case 4:
                    op = SPacketUpdateBossInfo.Operation.UPDATE_STYLE;
                    break;
                case 5:
                    op = SPacketUpdateBossInfo.Operation.UPDATE_PROPERTIES;
                    break;
                default:
                    op = SPacketUpdateBossInfo.Operation.ADD;
                    break;
            }
            return new SPacketUpdateBossInfo(op, data);
        }
    }

    public static class CChatMessage extends Packet262Out {

        public static final int ID = 9;

        public String message = "";

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketChatMessage && !((CPacketChatMessage) pkt).getMessage().startsWith("/");
        }

        @Override
        public void fromPacket(Packet pkt) {
            message = ((CPacketChatMessage) pkt).getMessage();
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeString(message, 32767);
            buf.writeFixedLong(System.currentTimeMillis());
            buf.writeFixedLong(0L);
            buf.writeBool(false);
            buf.writeVarInt(0);
            buf.writeBytes(new byte[] { 0, 0, 0 });
            buf.writeByte(0);
        }
    }

    public static class CChatCommand extends Packet262Out {

        public static final int ID = 7;

        public String command = "";

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketChatMessage && ((CPacketChatMessage) pkt).getMessage().startsWith("/");
        }

        @Override
        public void fromPacket(Packet pkt) {
            String message = ((CPacketChatMessage) pkt).getMessage();
            command = message.startsWith("/") ? message.substring(1) : message;
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeString(command, 32767);
        }
    }

    public static class CClientCommand extends Packet262Out {

        public static final int ID = 12;

        public int action;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketClientStatus;
        }

        @Override
        public void fromPacket(Packet pkt) {
            try {
                PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(4));
                pkt.writePacketData(scratch);
                action = scratch.readVarIntFromBuffer();
            } catch (IOException ex) {
                action = 1;
            }
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(action);
        }
    }

    public static class CHeldItemChange extends Packet262Out {

        public static final int ID = 53;

        public int slot;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketHeldItemChange;
        }

        @Override
        public void fromPacket(Packet pkt) {
            slot = ((CPacketHeldItemChange) pkt).getSlotId();
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeUShort(slot & 0xFFFF);
        }
    }

    public static class CArmAnimation extends Packet262Out {

        public static final int ID = 63;

        public int hand;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketAnimation;
        }

        @Override
        public void fromPacket(Packet pkt) {
            hand = ((CPacketAnimation) pkt).getHand() == net.minecraft.util.EnumHand.OFF_HAND ? 1 : 0;
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(hand);
        }
    }

    private static String readSoundHolder(Port262Buffer buf) throws IOException {
        int holder = buf.readVarInt();
        if (holder == 0) {
            String name = buf.readString(2048);
            buf.readBool();
            return name;
        }
        return Port262SoundMap.name(holder - 1);
    }

    private static SoundEvent resolveSound(String name) {
        if (name == null) {
            return null;
        }
        try {
            return SoundEvent.REGISTRY.getObject(new net.minecraft.util.ResourceLocation(name));
        } catch (Throwable t) {
            return null;
        }
    }

    private static SoundCategory category(int index) {
        SoundCategory[] values = SoundCategory.values();
        if (index < 0 || index >= values.length) {
            index = 0;
        }
        return values[index];
    }
}
