package client.port262.packets.play;

import java.io.IOException;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketBlockBreakAnim;
import net.minecraft.network.play.server.SPacketCooldown;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.network.play.server.SPacketParticles;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import client.port262.Packet262In;
import client.port262.Port262BlockMap;
import client.port262.Port262Buffer;
import client.port262.Port262Connection;
import client.port262.Port262ParticleMap;
import client.port262.Port262Stacks;

public final class Play262EffectPackets {

    private Play262EffectPackets() {
    }

    public static class SWorldParticles extends Packet262In {

        public static final int ID = 47;

        public boolean longDistance;

        public double x;

        public double y;

        public double z;

        public float offsetX;

        public float offsetY;

        public float offsetZ;

        public float velocityOffset;

        public int amount;

        public DecodedParticle particle = new DecodedParticle();

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            longDistance = buf.readBool();
            buf.readBool();
            x = buf.readDouble();
            y = buf.readDouble();
            z = buf.readDouble();
            offsetX = buf.readFloat();
            offsetY = buf.readFloat();
            offsetZ = buf.readFloat();
            velocityOffset = buf.readFloat();
            amount = buf.readFixedInt();
            particle = new DecodedParticle();
            particle.decode(buf);
        }

        @Override
        public Packet process(Port262Connection conn) {
            EnumParticleTypes target = particle.target();
            if (target == null) {
                return null;
            }
            if (target == EnumParticleTypes.BLOCK_CRACK || target == EnumParticleTypes.BLOCK_DUST || target == EnumParticleTypes.FALLING_DUST) {
                int legacy = Port262BlockMap.map(particle.blockState);
                return new SPacketParticles(target, longDistance, (float) x, (float) y, (float) z, offsetX, offsetY, offsetZ, velocityOffset, amount, legacy);
            }
            if (target == EnumParticleTypes.ITEM_CRACK) {
                if (particle.item == null || particle.item.func_190926_b()) {
                    return null;
                }
                int id = Item.getIdFromItem(particle.item.getItem());
                int meta = particle.item.getItemDamage();
                return new SPacketParticles(target, longDistance, (float) x, (float) y, (float) z, offsetX, offsetY, offsetZ, velocityOffset, amount, id, meta);
            }
            if (target == EnumParticleTypes.REDSTONE || target == EnumParticleTypes.SPELL_MOB) {
                return new SPacketParticles(target, longDistance, (float) x, (float) y, (float) z, particle.r, particle.g, particle.b, 1.0F, 0);
            }
            return new SPacketParticles(target, longDistance, (float) x, (float) y, (float) z, offsetX, offsetY, offsetZ, velocityOffset, amount);
        }
    }

    public static class SExplosion extends Packet262In {

        public static final int ID = 36;

        public double x;

        public double y;

        public double z;

        public float radius;

        public boolean hasKnockback;

        public double knockbackX;

        public double knockbackY;

        public double knockbackZ;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            x = buf.readDouble();
            y = buf.readDouble();
            z = buf.readDouble();
            radius = buf.readFloat();
            buf.readFixedInt();
            hasKnockback = buf.readBool();
            if (hasKnockback) {
                knockbackX = buf.readDouble();
                knockbackY = buf.readDouble();
                knockbackZ = buf.readDouble();
            }
            new DecodedParticle().decode(buf);
            readSoundHolder(buf);
            int blockEntries = buf.readVarInt();
            if (blockEntries < 0 || blockEntries > 4096) {
                throw new IOException("26.2 explosion block particle count out of range: " + blockEntries);
            }
            for (int i = 0; i < blockEntries; i++) {
                new DecodedParticle().decode(buf);
                buf.readFloat();
                buf.readFloat();
                buf.readVarInt();
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            Vec3d motion = hasKnockback ? new Vec3d(knockbackX, knockbackY, knockbackZ) : null;
            return new SPacketExplosion(x, y, z, radius, java.util.Collections.<BlockPos>emptyList(), motion);
        }
    }

    public static class SBlockBreakAnimation extends Packet262In {

        public static final int ID = 5;

        public int breakerId;

        public long location;

        public int destroyStage;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            breakerId = buf.readVarInt();
            location = buf.readPosition();
            destroyStage = buf.readByte();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketBlockBreakAnim(breakerId, BlockPos.fromLong(location), destroyStage);
        }
    }

    public static class SSetCooldown extends Packet262In {

        public static final int ID = 22;

        public String cooldownGroup;

        public int cooldownTicks;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            cooldownGroup = buf.readString(256);
            cooldownTicks = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            if (cooldownGroup == null || cooldownGroup.isEmpty()) {
                return null;
            }
            String name = cooldownGroup.indexOf(':') >= 0 ? cooldownGroup : "minecraft:" + cooldownGroup;
            Item item = Item.getByNameOrId(name);
            if (item == null) {
                return null;
            }
            return new SPacketCooldown(item, cooldownTicks);
        }
    }

    static final class DecodedParticle {

        public int id = -1;

        public int blockState;

        public ItemStack item;

        public float r;

        public float g;

        public float b;

        EnumParticleTypes target() {
            if (id < 0 || id >= Port262ParticleMap.PARTICLES.length) {
                return null;
            }
            return Port262ParticleMap.PARTICLES[id];
        }

        void decode(Port262Buffer buf) throws IOException {
            id = buf.readVarInt();
            String[] names = Port262ParticleMap.NAMES;
            String name = (id >= 0 && id < names.length) ? names[id] : "unknown_" + id;
            switch(name) {
                case "block":
                case "block_marker":
                case "falling_dust":
                case "dust_pillar":
                case "block_crumble":
                    blockState = buf.readVarInt();
                    break;
                case "dust":
                    r = buf.readFloat();
                    g = buf.readFloat();
                    b = buf.readFloat();
                    buf.readFloat();
                    break;
                case "dust_color_transition":
                    r = buf.readFloat();
                    g = buf.readFloat();
                    b = buf.readFloat();
                    buf.readFloat();
                    buf.readFloat();
                    buf.readFloat();
                    buf.readFloat();
                    break;
                case "entity_effect":
                case "tinted_leaves":
                case "flash":
                    {
                        int argb = buf.readFixedInt();
                        if (name.equals("entity_effect")) {
                            r = ((argb >> 16) & 255) / 255.0F;
                            g = ((argb >> 8) & 255) / 255.0F;
                            b = (argb & 255) / 255.0F;
                            if (argb == 0) {
                                r = 1.0F;
                            }
                        }
                        break;
                    }
                case "effect":
                case "instant_effect":
                    {
                        int color = buf.readFixedInt();
                        buf.readFloat();
                        if (name.equals("effect")) {
                            r = ((color >> 16) & 255) / 255.0F;
                            g = ((color >> 8) & 255) / 255.0F;
                            b = (color & 255) / 255.0F;
                            if (color == 0) {
                                r = 1.0F;
                            }
                        }
                        break;
                    }
                case "item":
                    item = Port262Stacks.readStack(buf);
                    break;
                case "sculk_charge":
                    buf.readFloat();
                    break;
                case "shriek":
                    buf.readVarInt();
                    break;
                case "vibration":
                    {
                        int positionType = buf.readVarInt();
                        if (positionType == 0) {
                            buf.readPosition();
                        } else {
                            buf.readVarInt();
                            buf.readFloat();
                        }
                        buf.readVarInt();
                        break;
                    }
                case "trail":
                    buf.readDouble();
                    buf.readDouble();
                    buf.readDouble();
                    buf.readUByte();
                    break;
                case "dragon_breath":
                    buf.readFloat();
                    break;
                default:
                    break;
            }
        }
    }

    private static void readSoundHolder(Port262Buffer buf) throws IOException {
        int holder = buf.readVarInt();
        if (holder == 0) {
            buf.readString(2048);
            buf.readBool();
        }
    }
}
