package client.port262.packets.play;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import io.netty.buffer.Unpooled;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketClickWindow;
import net.minecraft.network.play.client.CPacketCloseWindow;
import net.minecraft.network.play.client.CPacketCreativeInventoryAction;
import net.minecraft.network.play.client.CPacketPlayerAbilities;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUpdateSign;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.server.SPacketBlockAction;
import net.minecraft.network.play.server.SPacketBlockChange;
import net.minecraft.network.play.server.SPacketCloseWindow;
import net.minecraft.network.play.server.SPacketOpenWindow;
import net.minecraft.network.play.server.SPacketPlayerAbilities;
import net.minecraft.network.play.server.SPacketSetSlot;
import net.minecraft.network.play.server.SPacketSignEditorOpen;
import net.minecraft.network.play.server.SPacketWindowItems;
import net.minecraft.network.play.server.SPacketWindowProperty;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import client.port262.Packet262In;
import client.port262.Packet262Out;
import client.port262.Port262;
import client.port262.Port262BlockMap;
import client.port262.Port262Buffer;
import client.port262.Port262Connection;
import client.port262.Port262ItemMap;
import client.port262.Port262Nbt;
import client.port262.Port262Stacks;
import client.port262.Port262Text;

public final class Play262InteractPackets {

    private Play262InteractPackets() {
    }

    private static final Map<String, Integer> ITEM_IDS = new HashMap<String, Integer>();

    static {
        for (int i = 0; i < Port262ItemMap.NAMES.length; i++) {
            String name = Port262ItemMap.NAMES[i];
            if (!ITEM_IDS.containsKey(name)) {
                ITEM_IDS.put(name, Integer.valueOf(i));
            }
        }
    }

    private static int itemIdOf(ItemStack stack) {
        try {
            ResourceLocation rl = Item.REGISTRY.getNameForObject(stack.getItem());
            if (rl == null) {
                return -1;
            }
            String path = rl.toString();
            int colon = path.indexOf(':');
            String bare = colon >= 0 ? path.substring(colon + 1) : path;
            Integer id = ITEM_IDS.get(bare);
            return id != null ? id.intValue() : -1;
        } catch (Throwable t) {
            return -1;
        }
    }

    static void writeSlot(Port262Buffer buf, ItemStack stack) throws IOException {
        if (stack == null || stack.func_190926_b()) {
            buf.writeVarInt(0);
            return;
        }
        int itemId = itemIdOf(stack);
        int count = stack.func_190916_E();
        if (itemId < 0 || count <= 0) {
            buf.writeVarInt(0);
            return;
        }
        buf.writeVarInt(count);
        buf.writeVarInt(itemId);
        buf.writeVarInt(0);
        buf.writeVarInt(0);
    }

    static ItemStack readSlot(Port262Buffer buf) throws IOException {
        return Port262Stacks.readStack(buf);
    }

    static void writeNbtString(Port262Buffer buf, String value) throws IOException {
        byte[] bytes = (value == null ? "" : value).getBytes(StandardCharsets.UTF_8);
        buf.writeUShort(bytes.length);
        buf.writeBytes(bytes);
    }

    static void writeTextComponentNbt(Port262Buffer buf, String text) throws IOException {
        buf.writeByte(0x0A);
        buf.writeByte(0x08);
        writeNbtString(buf, "text");
        writeNbtString(buf, text);
        buf.writeByte(0x00);
    }

    private static int sequenceCounter = 1;

    private static int nextSequence() {
        sequenceCounter++;
        if (sequenceCounter <= 0) {
            sequenceCounter = 1;
        }
        return sequenceCounter;
    }

    private static boolean playerSneaking() {
        try {
            EntityPlayer p = Minecraft.getMinecraft().player;
            return p != null && p.isSneaking();
        } catch (Throwable t) {
            return false;
        }
    }

    private static float playerYaw() {
        try {
            EntityPlayer p = Minecraft.getMinecraft().player;
            return p != null ? p.rotationYaw : 0.0F;
        } catch (Throwable t) {
            return 0.0F;
        }
    }

    private static float playerPitch() {
        try {
            EntityPlayer p = Minecraft.getMinecraft().player;
            return p != null ? p.rotationPitch : 0.0F;
        } catch (Throwable t) {
            return 0.0F;
        }
    }

    static String guiIdFor(int menuType) {
        switch(menuType) {
            case 7:
            case 20:
                return "minecraft:anvil";
            case 11:
                return "minecraft:crafting_table";
            case 12:
                return "minecraft:enchanting_table";
            case 18:
                return "minecraft:villager";
            default:
                return "minecraft:container";
        }
    }

    static int slotCountFor(int menuType) {
        switch(menuType) {
            case 0:
                return 9;
            case 1:
                return 18;
            case 2:
                return 27;
            case 3:
                return 36;
            case 4:
                return 45;
            case 5:
                return 54;
            case 6:
                return 9;
            case 8:
                return 1;
            case 9:
                return 3;
            case 10:
                return 5;
            case 13:
                return 3;
            case 14:
                return 3;
            case 15:
                return 5;
            case 16:
                return 1;
            case 17:
                return 4;
            case 19:
                return 27;
            case 20:
                return 0;
            case 21:
                return 3;
            case 22:
                return 3;
            case 23:
                return 1;
            case 24:
                return 9;
            case 7:
            case 11:
            case 12:
            case 18:
                return 0;
            default:
                return 27;
        }
    }

    public static class SAckDigging extends Packet262In {

        public static final int ID = 4;

        public long location;

        public int stateId;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            location = buf.readPosition();
            stateId = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(9));
            scratch.writeBlockPos(BlockPos.fromLong(location));
            scratch.writeVarIntToBuffer(Port262BlockMap.map(stateId));
            SPacketBlockChange out = new SPacketBlockChange();
            out.readPacketData(scratch);
            return out;
        }
    }

    public static class SBlockAction extends Packet262In {

        public static final int ID = 7;

        public long location;

        public int actionId;

        public int actionParam;

        public int stateId;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            location = buf.readPosition();
            actionId = buf.readUByte();
            actionParam = buf.readUByte();
            stateId = buf.readVarInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            int combined = Port262BlockMap.map(stateId);
            Block block = Block.getBlockById(combined >> 4);
            return new SPacketBlockAction(BlockPos.fromLong(location), block, actionId, actionParam);
        }
    }

    public static class SCloseWindow extends Packet262In {

        public static final int ID = 17;

        public int windowId;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            windowId = buf.readUByte();
        }

        @Override
        public Packet process(Port262Connection conn) {
            conn.forgetContainer(windowId);
            return new SPacketCloseWindow(windowId);
        }
    }

    public static class SWindowItems extends Packet262In {

        public static final int ID = 18;

        public int windowId;

        public int stateId;

        public ItemStack[] items = new ItemStack[0];

        public ItemStack carried;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            windowId = buf.readUByte();
            stateId = buf.readVarInt();
            int count = buf.readVarInt();
            if (count < 0 || count > 256) {
                throw new IOException("26.2 window_items count out of range: " + count);
            }
            items = new ItemStack[count];
            for (int i = 0; i < count; i++) {
                items[i] = readSlot(buf);
            }
            carried = readSlot(buf);
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            conn.trackContainerState(windowId, stateId);
            if (carried != null) {
                conn.dispatch(new SPacketSetSlot(-1, -1, carried));
            } else {
                conn.dispatch(new SPacketSetSlot(-1, -1, ItemStack.field_190927_a));
            }
            NonNullList<ItemStack> list = NonNullList.func_191197_a(items.length, ItemStack.field_190927_a);
            for (int i = 0; i < items.length; i++) {
                if (items[i] != null) {
                    list.set(i, items[i]);
                }
            }
            return new SPacketWindowItems(windowId, list);
        }
    }

    public static class SCraftProgressBar extends Packet262In {

        public static final int ID = 19;

        public int windowId;

        public int property;

        public int value;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            windowId = buf.readUByte();
            property = (short) buf.readUShort();
            value = (short) buf.readUShort();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketWindowProperty(windowId, property, value);
        }
    }

    public static class SSetSlot extends Packet262In {

        public static final int ID = 20;

        public int windowId;

        public int stateId;

        public int slot;

        public ItemStack item;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            windowId = buf.readUByte();
            stateId = buf.readVarInt();
            slot = (short) buf.readUShort();
            item = readSlot(buf);
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            conn.trackContainerState(windowId, stateId);
            ItemStack stack = item != null ? item : ItemStack.field_190927_a;
            return new SPacketSetSlot(windowId, slot, stack);
        }
    }

    public static class SOpenWindow extends Packet262In {

        public static final int ID = 59;

        public int windowId;

        public int menuType;

        public String title = "";

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            windowId = buf.readUByte();
            menuType = buf.readVarInt();
            Object node = Port262Nbt.readAnonymous(buf);
            if (node != null) {
                ITextComponent comp = Port262Text.fromNbt(node);
                if (comp != null) {
                    title = comp.getUnformattedText();
                }
            }
        }

        @Override
        public Packet process(Port262Connection conn) {
            String guiId = guiIdFor(menuType);
            int slotCount = slotCountFor(menuType);
            String shown = title == null || title.isEmpty() ? "Inventory" : title;
            return new SPacketOpenWindow(windowId, guiId, new TextComponentString(shown), slotCount);
        }
    }

    public static class SOpenSignEntity extends Packet262In {

        public static final int ID = 60;

        public long location;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            location = buf.readPosition();
            buf.readUByte();
        }

        @Override
        public Packet process(Port262Connection conn) {
            return new SPacketSignEditorOpen(BlockPos.fromLong(location));
        }
    }

    public static class SAbilities extends Packet262In {

        public static final int ID = 64;

        public int flags;

        public float flyingSpeed;

        public float walkingSpeed;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            flags = buf.readUByte();
            flyingSpeed = buf.readFloat();
            walkingSpeed = buf.readFloat();
        }

        @Override
        public Packet process(Port262Connection conn) {
            SPacketPlayerAbilities out = new SPacketPlayerAbilities();
            out.setInvulnerable((flags & 0x01) != 0);
            out.setFlying((flags & 0x02) != 0);
            out.setAllowFlying((flags & 0x04) != 0);
            out.setCreativeMode((flags & 0x08) != 0);
            out.setFlySpeed(flyingSpeed);
            out.setWalkSpeed(walkingSpeed);
            return out;
        }
    }

    public static class SSetCursorItem extends Packet262In {

        public static final int ID = 96;

        public ItemStack item;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            item = readSlot(buf);
        }

        @Override
        public Packet process(Port262Connection conn) {
            ItemStack stack = item != null ? item : ItemStack.field_190927_a;
            return new SPacketSetSlot(-1, -1, stack);
        }
    }

    public static class SSetPlayerInventory extends Packet262In {

        public static final int ID = 108;

        public int slotId;

        public ItemStack item;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            slotId = buf.readVarInt();
            item = Port262Stacks.readStack(buf);
        }

        @Override
        public Packet process(Port262Connection conn) {
            ItemStack stack = item != null ? item : ItemStack.field_190927_a;
            return new SPacketSetSlot(0, slotId, stack);
        }
    }

    public static class CAttack extends Packet262Out {

        public static final int ID = 1;

        public int entityId;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketUseEntity && ((CPacketUseEntity) pkt).getAction() == CPacketUseEntity.Action.ATTACK;
        }

        @Override
        public void fromPacket(Packet pkt) {
            try {
                PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(8));
                pkt.writePacketData(scratch);
                entityId = scratch.readVarIntFromBuffer();
            } catch (IOException ex) {
                entityId = -1;
            }
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(entityId);
            buf.writeBool(playerSneaking());
        }
    }

    public static class CUseEntity extends Packet262Out {

        public static final int ID = 26;

        public int entityId;

        public boolean offHand;

        public boolean hasLocation;

        public double locX;

        public double locY;

        public double locZ;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            if (!(pkt instanceof CPacketUseEntity)) {
                return false;
            }
            CPacketUseEntity.Action action = ((CPacketUseEntity) pkt).getAction();
            return action == CPacketUseEntity.Action.INTERACT || action == CPacketUseEntity.Action.INTERACT_AT;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketUseEntity use = (CPacketUseEntity) pkt;
            offHand = use.getHand() == net.minecraft.util.EnumHand.OFF_HAND;
            try {
                PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(12));
                pkt.writePacketData(scratch);
                entityId = scratch.readVarIntFromBuffer();
            } catch (IOException ex) {
                entityId = -1;
            }
            if (use.getAction() == CPacketUseEntity.Action.INTERACT_AT && use.getHitVec() != null) {
                hasLocation = true;
                locX = use.getHitVec().xCoord;
                locY = use.getHitVec().yCoord;
                locZ = use.getHitVec().zCoord;
            } else {
                hasLocation = false;
            }
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(entityId);
            buf.writeVarInt(offHand ? 1 : 0);
            buf.writeBool(hasLocation);
            if (hasLocation) {
                buf.writeFloat((float) locX);
                buf.writeFloat((float) locY);
                buf.writeFloat((float) locZ);
            }
            buf.writeBool(playerSneaking());
        }
    }

    public static class CWindowClick extends Packet262Out {

        public static final int ID = 18;

        public int windowId;

        public int slotId;

        public int button;

        public int mode;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketClickWindow;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketClickWindow click = (CPacketClickWindow) pkt;
            windowId = click.getWindowId();
            slotId = click.getSlotId();
            button = click.getUsedButton();
            ClickType type = click.getClickType();
            mode = type != null ? type.ordinal() : 0;
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            Port262Connection conn = Port262.getConnection();
            int stateId = conn != null ? conn.containerStateId(windowId) : 0;
            buf.writeByte(windowId);
            buf.writeVarInt(stateId);
            buf.writeUShort(slotId & 0xFFFF);
            buf.writeByte(button);
            buf.writeVarInt(mode);
            buf.writeVarInt(0);
            buf.writeVarInt(0);
        }
    }

    public static class CCloseWindow extends Packet262Out {

        public static final int ID = 19;

        public int windowId;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketCloseWindow;
        }

        @Override
        public void fromPacket(Packet pkt) {
            try {
                PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(2));
                pkt.writePacketData(scratch);
                windowId = scratch.readUnsignedByte();
            } catch (IOException ex) {
                windowId = 0;
            }
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            Port262Connection conn = Port262.getConnection();
            if (conn != null) {
                conn.forgetContainer(windowId);
            }
            buf.writeByte(windowId);
        }
    }

    public static class CAbilities extends Packet262Out {

        public static final int ID = 40;

        public boolean flying;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketPlayerAbilities;
        }

        @Override
        public void fromPacket(Packet pkt) {
            try {
                PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(2));
                pkt.writePacketData(scratch);
                flying = (scratch.readUnsignedByte() & 0x02) != 0;
            } catch (IOException ex) {
                flying = false;
            }
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeByte(flying ? 1 : 0);
        }
    }

    public static class CBlockDig extends Packet262Out {

        public static final int ID = 41;

        public int status;

        public long location;

        public int face;

        public int sequence;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketPlayerDigging;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketPlayerDigging dig = (CPacketPlayerDigging) pkt;
            status = dig.getAction().ordinal();
            BlockPos pos = dig.getPosition();
            location = pos != null ? pos.toLong() : BlockPos.ORIGIN.toLong();
            face = dig.getFacing() != null ? dig.getFacing().getIndex() : 0;
            sequence = nextSequence();
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(status);
            buf.writePosition(location);
            buf.writeByte(face);
            buf.writeVarInt(sequence);
        }
    }

    public static class CSetCreativeSlot extends Packet262Out {

        public static final int ID = 56;

        public int slotId;

        public ItemStack stack;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            if (!(pkt instanceof CPacketCreativeInventoryAction)) {
                return false;
            }
            return ((CPacketCreativeInventoryAction) pkt).getSlotId() >= 0;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketCreativeInventoryAction creative = (CPacketCreativeInventoryAction) pkt;
            slotId = creative.getSlotId();
            stack = creative.getStack();
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeUShort(slotId & 0xFFFF);
            writeSlot(buf, stack);
        }
    }

    public static class CUpdateSign extends Packet262Out {

        public static final int ID = 61;

        public long location;

        public String[] lines = new String[] { "", "", "", "" };

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketUpdateSign;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketUpdateSign sign = (CPacketUpdateSign) pkt;
            BlockPos pos = sign.getPosition();
            location = pos != null ? pos.toLong() : BlockPos.ORIGIN.toLong();
            String[] raw = sign.getLines();
            for (int i = 0; i < 4; i++) {
                lines[i] = raw != null && i < raw.length && raw[i] != null ? raw[i] : "";
            }
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writePosition(location);
            buf.writeByte(1);
            for (int i = 0; i < 4; i++) {
                writeTextComponentNbt(buf, lines[i]);
            }
        }
    }

    public static class CBlockPlace extends Packet262Out {

        public static final int ID = 66;

        public boolean offHand;

        public long location;

        public int face;

        public float cursorX;

        public float cursorY;

        public float cursorZ;

        public int sequence;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketPlayerTryUseItemOnBlock;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketPlayerTryUseItemOnBlock place = (CPacketPlayerTryUseItemOnBlock) pkt;
            offHand = place.getHand() == net.minecraft.util.EnumHand.OFF_HAND;
            BlockPos pos = place.getPos();
            location = pos != null ? pos.toLong() : BlockPos.ORIGIN.toLong();
            face = place.getDirection() != null ? place.getDirection().getIndex() : 0;
            cursorX = place.getFacingX();
            cursorY = place.getFacingY();
            cursorZ = place.getFacingZ();
            sequence = nextSequence();
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(offHand ? 1 : 0);
            buf.writePosition(location);
            buf.writeVarInt(face);
            buf.writeFloat(cursorX);
            buf.writeFloat(cursorY);
            buf.writeFloat(cursorZ);
            buf.writeVarInt(sequence);
        }
    }

    public static class CUseItem extends Packet262Out {

        public static final int ID = 67;

        public boolean offHand;

        public int sequence;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketPlayerTryUseItem;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketPlayerTryUseItem use = (CPacketPlayerTryUseItem) pkt;
            offHand = use.getHand() == net.minecraft.util.EnumHand.OFF_HAND;
            sequence = nextSequence();
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(offHand ? 1 : 0);
            buf.writeVarInt(sequence);
            buf.writeFloat(playerYaw());
            buf.writeFloat(playerPitch());
        }
    }
}
