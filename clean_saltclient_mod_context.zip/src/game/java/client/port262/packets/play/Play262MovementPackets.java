package client.port262.packets.play;

import java.io.IOException;
import java.util.EnumSet;
import io.netty.buffer.Unpooled;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketClientSettings;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketMoveVehicle;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import client.port262.Packet262In;
import client.port262.Packet262Out;
import client.port262.Port262Buffer;
import client.port262.Port262Connection;

public final class Play262MovementPackets {

    private Play262MovementPackets() {
    }

    public static class CPlayerPosition extends Packet262Out {

        public static final int ID = 30;

        public double x;

        public double y;

        public double z;

        public boolean onGround;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketPlayer.Position;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketPlayer.Position p = (CPacketPlayer.Position) pkt;
            x = p.getX(0.0D);
            y = p.getY(0.0D);
            z = p.getZ(0.0D);
            onGround = p.isOnGround();
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeDouble(x);
            buf.writeDouble(y);
            buf.writeDouble(z);
            buf.writeByte(onGround ? 0x01 : 0x00);
        }
    }

    public static class CPlayerPositionLook extends Packet262Out {

        public static final int ID = 31;

        public double x;

        public double y;

        public double z;

        public float yaw;

        public float pitch;

        public boolean onGround;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketPlayer.PositionRotation;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketPlayer.PositionRotation p = (CPacketPlayer.PositionRotation) pkt;
            x = p.getX(0.0D);
            y = p.getY(0.0D);
            z = p.getZ(0.0D);
            yaw = p.getYaw(0.0F);
            pitch = p.getPitch(0.0F);
            onGround = p.isOnGround();
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeDouble(x);
            buf.writeDouble(y);
            buf.writeDouble(z);
            buf.writeFloat(yaw);
            buf.writeFloat(pitch);
            buf.writeByte(onGround ? 0x01 : 0x00);
        }
    }

    public static class CLook extends Packet262Out {

        public static final int ID = 32;

        public float yaw;

        public float pitch;

        public boolean onGround;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketPlayer.Rotation;
        }

        @Override
        public void fromPacket(Packet pkt) {
            CPacketPlayer.Rotation p = (CPacketPlayer.Rotation) pkt;
            yaw = p.getYaw(0.0F);
            pitch = p.getPitch(0.0F);
            onGround = p.isOnGround();
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeFloat(yaw);
            buf.writeFloat(pitch);
            buf.writeByte(onGround ? 0x01 : 0x00);
        }
    }

    public static class CPlayerFlying extends Packet262Out {

        public static final int ID = 33;

        public boolean onGround;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt.getClass() == CPacketPlayer.class;
        }

        @Override
        public void fromPacket(Packet pkt) {
            onGround = ((CPacketPlayer) pkt).isOnGround();
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeByte(onGround ? 0x01 : 0x00);
        }
    }

    public static class CConfirmTeleport extends Packet262Out {

        public static final int ID = 0;

        public int teleportId;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketConfirmTeleport;
        }

        @Override
        public void fromPacket(Packet pkt) {
            teleportId = ((CPacketConfirmTeleport) pkt).getTeleportId();
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            buf.writeVarInt(teleportId);
        }
    }

    public static class CClientSettings extends Packet262Out {

        public static final int ID = 14;

        public String locale = "en_US";

        public int viewDistance = 8;

        public int chatFlags;

        public boolean chatColors = true;

        public int skinParts = 0x7F;

        public int mainHand = 1;

        String error;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public boolean matches(Packet pkt) {
            return pkt instanceof CPacketClientSettings;
        }

        @Override
        public void fromPacket(Packet pkt) {
            try {
                PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(48));
                pkt.writePacketData(scratch);
                locale = scratch.readStringFromBuffer(16);
                viewDistance = scratch.readByte();
                chatFlags = scratch.readVarIntFromBuffer();
                chatColors = scratch.readBoolean();
                skinParts = scratch.readUnsignedByte();
                mainHand = scratch.readVarIntFromBuffer();
            } catch (IOException ex) {
                error = "client settings parse failed: " + ex.getMessage();
            }
        }

        @Override
        public void write(Port262Buffer buf) throws IOException {
            if (error != null) {
                throw new IOException(error);
            }
            buf.writeString(locale, 16);
            buf.writeByte(viewDistance);
            buf.writeVarInt(chatFlags);
            buf.writeBool(chatColors);
            buf.writeByte(skinParts);
            buf.writeVarInt(mainHand);
            buf.writeBool(false);
            buf.writeBool(true);
            buf.writeVarInt(0);
        }
    }

    public static class SPlayerPosLook extends Packet262In {

        public static final int ID = 72;

        public int teleportId;

        public double x;

        public double y;

        public double z;

        public float yaw;

        public float pitch;

        public int flags;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            teleportId = buf.readVarInt();
            x = buf.readDouble();
            y = buf.readDouble();
            z = buf.readDouble();
            buf.readDouble();
            buf.readDouble();
            buf.readDouble();
            yaw = buf.readFloat();
            pitch = buf.readFloat();
            flags = buf.readFixedInt();
        }

        @Override
        public Packet process(Port262Connection conn) {
            EnumSet<SPacketPlayerPosLook.EnumFlags> relative = EnumSet.noneOf(SPacketPlayerPosLook.EnumFlags.class);
            if ((flags & 0x01) != 0) {
                relative.add(SPacketPlayerPosLook.EnumFlags.X);
            }
            if ((flags & 0x02) != 0) {
                relative.add(SPacketPlayerPosLook.EnumFlags.Y);
            }
            if ((flags & 0x04) != 0) {
                relative.add(SPacketPlayerPosLook.EnumFlags.Z);
            }
            if ((flags & 0x08) != 0) {
                relative.add(SPacketPlayerPosLook.EnumFlags.Y_ROT);
            }
            if ((flags & 0x10) != 0) {
                relative.add(SPacketPlayerPosLook.EnumFlags.X_ROT);
            }
            return new SPacketPlayerPosLook(x, y, z, yaw, pitch, relative, teleportId);
        }
    }

    public static class SVehicleMove extends Packet262In {

        public static final int ID = 57;

        public double x;

        public double y;

        public double z;

        public float yaw;

        public float pitch;

        @Override
        public int getId() {
            return ID;
        }

        @Override
        public void read(Port262Buffer buf) throws IOException {
            x = buf.readDouble();
            y = buf.readDouble();
            z = buf.readDouble();
            yaw = buf.readFloat();
            pitch = buf.readFloat();
        }

        @Override
        public Packet process(Port262Connection conn) throws IOException {
            PacketBuffer scratch = new PacketBuffer(Unpooled.buffer(32));
            scratch.writeDouble(x);
            scratch.writeDouble(y);
            scratch.writeDouble(z);
            scratch.writeFloat(yaw);
            scratch.writeFloat(pitch);
            SPacketMoveVehicle out = new SPacketMoveVehicle();
            out.readPacketData(scratch);
            return out;
        }
    }
}
