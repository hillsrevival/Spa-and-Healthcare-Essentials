package client.port262;

import java.io.IOException;
import net.minecraft.network.Packet;

public abstract class Packet262Out {

    public abstract int getId();

    public abstract boolean matches(Packet pkt);

    public abstract void fromPacket(Packet pkt);

    public abstract void write(Port262Buffer buf) throws IOException;

    protected Port262Connection connection;

    public void setConnection(Port262Connection connection) {
        this.connection = connection;
    }

    public boolean shouldSend() {
        return true;
    }
}
