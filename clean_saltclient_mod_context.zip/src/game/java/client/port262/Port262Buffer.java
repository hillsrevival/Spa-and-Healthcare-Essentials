package client.port262;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.PacketBuffer;

public final class Port262Buffer {

    private final PacketBuffer buf;

    public Port262Buffer(PacketBuffer buf) {
        this.buf = buf;
    }

    public PacketBuffer raw() {
        return buf;
    }

    public int readableBytes() {
        return buf.readableBytes();
    }

    public int readVarInt() throws IOException {
        return buf.readVarIntFromBuffer();
    }

    public void writeVarInt(int value) throws IOException {
        buf.writeVarIntToBuffer(value);
    }

    public long readFixedLong() throws IOException {
        return buf.readLong();
    }

    public void writeFixedLong(long value) throws IOException {
        buf.writeLong(value);
    }

    public int readFixedInt() throws IOException {
        return buf.readInt();
    }

    public void writeFixedInt(int value) throws IOException {
        buf.writeInt(value);
    }

    public boolean readBool() throws IOException {
        return buf.readBoolean();
    }

    public void writeBool(boolean value) throws IOException {
        buf.writeBoolean(value);
    }

    public int readUShort() throws IOException {
        return buf.readUnsignedShort();
    }

    public void writeUShort(int value) throws IOException {
        buf.writeShort(value & 0xFFFF);
    }

    public byte readByte() throws IOException {
        return buf.readByte();
    }

    public void writeByte(int value) throws IOException {
        buf.writeByte(value);
    }

    public int readUByte() throws IOException {
        return buf.readUnsignedByte();
    }

    public float readFloat() throws IOException {
        return buf.readFloat();
    }

    public void writeFloat(float value) throws IOException {
        buf.writeFloat(value);
    }

    public double readDouble() throws IOException {
        return buf.readDouble();
    }

    public void writeDouble(double value) throws IOException {
        buf.writeDouble(value);
    }

    public short readShort() throws IOException {
        return buf.readShort();
    }

    public long readVarLong() throws IOException {
        return buf.readVarLong();
    }

    public void writeVarLong(long value) throws IOException {
        buf.writeVarLong(value);
    }

    public String readString() throws IOException {
        return readString(32767);
    }

    public String readString(int maxLength) throws IOException {
        return buf.readStringFromBuffer(maxLength);
    }

    public void writeString(String value) throws IOException {
        writeString(value, 32767);
    }

    public void writeString(String value, int maxLength) throws IOException {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        if (bytes.length > maxLength) {
            throw new IOException("26.2 string too long: " + bytes.length + " > " + maxLength);
        }
        writeVarInt(bytes.length);
        buf.writeBytes(bytes);
    }

    public byte[] readLengthPrefixedBytes() throws IOException {
        int len = readVarInt();
        if (len < 0 || len > buf.readableBytes()) {
            throw new IOException("26.2 byte array overruns buffer: " + len);
        }
        byte[] out = new byte[len];
        buf.readBytes(out);
        return out;
    }

    public void skipLengthPrefixedLongs() throws IOException {
        long len = readVarInt();
        skipBytes(len * 8L);
    }

    public void skipLengthPrefixedBytes() throws IOException {
        long len = readVarInt();
        skipBytes(len);
    }

    public byte[] readRestBuffer() throws IOException {
        int n = buf.readableBytes();
        byte[] out = new byte[n];
        buf.readBytes(out);
        return out;
    }

    public void writeBytes(byte[] data) throws IOException {
        buf.writeBytes(data);
    }

    public long readUuidMsb() throws IOException {
        return buf.readLong();
    }

    public long readUuidLsb() throws IOException {
        return buf.readLong();
    }

    public void writeUuid(long msb, long lsb) throws IOException {
        buf.writeLong(msb);
        buf.writeLong(lsb);
    }

    public long readPosition() throws IOException {
        return buf.readLong();
    }

    public void writePosition(long packed) throws IOException {
        buf.writeLong(packed);
    }

    public void skipAnonymousNbt() throws IOException {
        int rootType = readByte() & 0xFF;
        if (rootType != 0x0A) {
            throw new IOException("26.2 NBT root is not a compound: " + rootType);
        }
        skipTagPayload(0x0A);
    }

    private void skipTagPayload(int type) throws IOException {
        switch(type) {
            case 0x00:
                return;
            case 0x01:
                skipBytes(1);
                return;
            case 0x02:
                skipBytes(2);
                return;
            case 0x03:
                skipBytes(4);
                return;
            case 0x04:
                skipBytes(8);
                return;
            case 0x05:
                skipBytes(4);
                return;
            case 0x06:
                skipBytes(8);
                return;
            case 0x07:
                {
                    int len = readFixedInt();
                    skipBytes(len);
                    return;
                }
            case 0x08:
                {
                    int len = readUShort();
                    skipBytes(len);
                    return;
                }
            case 0x09:
                {
                    int elemType = readByte() & 0xFF;
                    int len = readFixedInt();
                    for (int i = 0; i < len; i++) {
                        skipTagPayload(elemType);
                    }
                    return;
                }
            case 0x0A:
                {
                    while (true) {
                        int childType = readByte() & 0xFF;
                        if (childType == 0x00) {
                            return;
                        }
                        skipTagPayload(0x08);
                        skipTagPayload(childType);
                    }
                }
            case 0x0B:
                {
                    int len = readFixedInt();
                    skipBytes(len * 4L);
                    return;
                }
            case 0x0C:
                {
                    int len = readFixedInt();
                    skipBytes(len * 8L);
                    return;
                }
            default:
                throw new IOException("26.2 NBT unknown tag type: " + type);
        }
    }

    public void skipBytes(long n) throws IOException {
        if (n < 0) {
            throw new IOException("26.2 NBT negative skip length: " + n);
        }
        if (n > buf.readableBytes()) {
            throw new IOException("26.2 NBT skip overruns buffer: " + n + " > " + buf.readableBytes());
        }
        buf.readerIndex(buf.readerIndex() + (int) n);
    }

    public ByteBuf readRemaining() {
        return buf.readBytes(buf.readableBytes());
    }
}
