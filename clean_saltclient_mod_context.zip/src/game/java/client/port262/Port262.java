package client.port262;

import net.minecraft.world.World;

public final class Port262 {

    public static final int PROTOCOL_ID = 776;

    public static final String CLIENT_BRAND = "galactic";

    private static boolean bridgeRequested = false;

    private static Port262Connection connection = null;

    private Port262() {
    }

    public static boolean isBridgeRequested() {
        return bridgeRequested;
    }

    public static void setBridgeRequested(boolean value) {
        bridgeRequested = value;
    }

    public static boolean isActive() {
        return connection != null;
    }

    public static Port262Connection getConnection() {
        return connection;
    }

    public static void activate(Port262Connection conn) {
        connection = conn;
        World.updateY0Active(true);
        World.updatePort262Active(true);
        conn.start();
    }

    public static void deactivate() {
        connection = null;
        bridgeRequested = false;
        World.updatePort262Active(false);
        World.updateY0Active(client.tuff.Y0NetworkHandler.isY0Active());
    }
}
