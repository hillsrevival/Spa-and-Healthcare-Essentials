package client.port262;

public class Port262SkipException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public Port262SkipException(String message) {
        super(message);
    }
}
