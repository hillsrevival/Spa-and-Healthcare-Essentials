package client.port262;

import java.io.IOException;
import net.minecraft.network.Packet;

public abstract class Packet262In {

    public abstract int getId();

    public abstract void read(Port262Buffer buf) throws IOException;

    public abstract Packet process(Port262Connection conn) throws IOException;
}
