package client.port262;

import net.minecraft.block.state.IBlockState;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;

public final class Port262HeightStore {

    public static final int TOP_SECTION_MIN = 16;

    public static final int TOP_SECTION_COUNT = 4;

    public static final int MAX_WORLD_Y = 319;

    private Port262HeightStore() {
    }

    public static boolean isTopRange(int y) {
        return y >= 256 && y <= MAX_WORLD_Y;
    }

    public static int toArrayIndex(int sectionY) {
        return sectionY - TOP_SECTION_MIN;
    }

    public static ExtendedBlockStorage[] getY320Storage(Chunk chunk) {
        if (chunk.y320StorageArrays == null) {
            chunk.y320StorageArrays = new ExtendedBlockStorage[TOP_SECTION_COUNT];
        }
        return chunk.y320StorageArrays;
    }

    public static IBlockState getBlockState(Chunk chunk, int x, int y, int z) {
        if (chunk.y320StorageArrays == null) {
            return null;
        }
        int idx = toArrayIndex(y >> 4);
        if (idx < 0 || idx >= TOP_SECTION_COUNT) {
            return null;
        }
        ExtendedBlockStorage section = chunk.y320StorageArrays[idx];
        if (section == null) {
            return null;
        }
        return section.get(x & 15, y & 15, z & 15);
    }

    public static ExtendedBlockStorage createSection(int sectionY, boolean hasSky, boolean fillSky) {
        ExtendedBlockStorage section = new ExtendedBlockStorage(sectionY << 4, hasSky);
        if (hasSky && fillSky) {
            int sky = EnumSkyBlock.SKY.defaultLightValue;
            for (int x = 0; x < 16; x++) {
                for (int z = 0; z < 16; z++) {
                    for (int y = 0; y < 16; y++) {
                        section.setExtSkylightValue(x, y, z, sky);
                    }
                }
            }
        }
        return section;
    }

    public static void attachStores(Chunk chunk, ExtendedBlockStorage[] bottom, ExtendedBlockStorage[] top) {
        if (top != null) {
            boolean any = false;
            for (ExtendedBlockStorage s : top) {
                if (s != null) {
                    any = true;
                    break;
                }
            }
            if (any && chunk.y320StorageArrays == null) {
                chunk.y320StorageArrays = top;
            }
        }
        if (bottom != null) {
            boolean any = false;
            for (ExtendedBlockStorage s : bottom) {
                if (s != null) {
                    any = true;
                    break;
                }
            }
            if (any && chunk.y0StorageArrays == null) {
                chunk.y0StorageArrays = bottom;
            }
        }
    }
}
