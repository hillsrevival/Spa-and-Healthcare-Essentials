package client.port262;

public final class Port262EntityMap {

    public static final String[] LEGACY_NAMES = { "boat", "boat", "", "area_effect_cloud", "", "armor_stand", "arrow", "", "boat", "boat", "bat", "", "boat", "boat", "blaze", "", "", "", "", "", "", "ocelot", "cave_spider", "boat", "boat", "chest_minecart", "chicken", "", "", "commandblock_minecart", "cow", "", "creeper", "boat", "boat", "", "donkey", "dragon_fireball", "", "egg", "elder_guardian", "enderman", "endermite", "ender_dragon", "ender_pearl", "ender_crystal", "evocation_illager", "evocation_fangs", "xp_bottle", "xp_orb", "eye_of_ender_signal", "falling_block", "fireball", "fireworks_rocket", "", "", "furnace_minecart", "ghast", "", "giant", "item_frame", "", "", "guardian", "", "hopper_minecart", "horse", "husk", "illusion_illager", "", "villager_golem", "item", "", "item_frame", "boat", "boat", "leash_knot", "", "llama", "llama_spit", "magma_cube", "boat", "boat", "", "", "minecart", "mooshroom", "mule", "", "boat", "boat", "ocelot", "", "painting", "boat", "boat", "", "", "parrot", "", "pig", "", "", "", "polar_bear", "potion", "potion", "", "rabbit", "", "", "sheep", "shulker", "shulker_bullet", "silverfish", "skeleton", "skeleton_horse", "slime", "small_fireball", "", "snowball", "snowman", "spawner_minecart", "spectral_arrow", "spider", "boat", "boat", "squid", "stray", "", "", "", "tnt", "tnt_minecart", "", "", "", "", "vex", "villager", "vindication_illager", "villager", "", "", "witch", "wither", "wither_skeleton", "wither_skull", "wolf", "", "zombie", "zombie_horse", "", "zombie_villager", "zombie_pigman", "", "" };

    private Port262EntityMap() {
    }

    public static String legacyName(int id) {
        if (id < 0 || id >= LEGACY_NAMES.length) {
            return null;
        }
        String name = LEGACY_NAMES[id];
        return name.isEmpty() ? null : name;
    }
}
