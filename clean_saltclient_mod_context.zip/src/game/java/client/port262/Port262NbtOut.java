package client.port262;

import java.util.List;
import java.util.Map;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagByteArray;
import net.minecraft.nbt.NBTTagByte;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagFloat;
import net.minecraft.nbt.NBTTagIntArray;
import net.minecraft.nbt.NBTTagInt;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagLongArray;
import net.minecraft.nbt.NBTTagLong;
import net.minecraft.nbt.NBTTagShort;
import net.minecraft.nbt.NBTTagString;

public final class Port262NbtOut {

    private Port262NbtOut() {
    }

    public static NBTTagCompound writeCompound(Map<String, Object> map) {
        NBTTagCompound out = new NBTTagCompound();
        if (map == null) {
            return out;
        }
        for (Map.Entry<String, Object> e : map.entrySet()) {
            NBTBase tag = toTag(e.getValue());
            if (tag != null) {
                out.setTag(e.getKey(), tag);
            }
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    private static NBTBase toTag(Object v) {
        if (v == null) {
            return null;
        }
        if (v instanceof Byte) {
            return new NBTTagByte((Byte) v);
        }
        if (v instanceof Short) {
            return new NBTTagShort((Short) v);
        }
        if (v instanceof Integer) {
            return new NBTTagInt((Integer) v);
        }
        if (v instanceof Long) {
            return new NBTTagLong((Long) v);
        }
        if (v instanceof Float) {
            return new NBTTagFloat((Float) v);
        }
        if (v instanceof Double) {
            return new NBTTagDouble((Double) v);
        }
        if (v instanceof String) {
            return new NBTTagString((String) v);
        }
        if (v instanceof byte[]) {
            return new NBTTagByteArray((byte[]) v);
        }
        if (v instanceof int[]) {
            return new NBTTagIntArray((int[]) v);
        }
        if (v instanceof long[]) {
            return new NBTTagLongArray((long[]) v);
        }
        if (v instanceof Map) {
            return writeCompound((Map<String, Object>) v);
        }
        if (v instanceof List) {
            return writeList((List<Object>) v);
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private static NBTTagList writeList(List<Object> list) {
        NBTTagList out = new NBTTagList();
        if (list == null || list.isEmpty()) {
            return out;
        }
        Class<?> elemType = null;
        for (Object o : list) {
            if (o != null) {
                elemType = o.getClass();
                break;
            }
        }
        if (elemType == null) {
            return out;
        }
        for (Object o : list) {
            if (o == null) {
                continue;
            }
            o = coerce(o, elemType);
            NBTBase tag = toTag(o);
            if (tag != null) {
                out.appendTag(tag);
            }
        }
        return out;
    }

    private static Object coerce(Object o, Class<?> elemType) {
        if (o instanceof Number && Number.class.isAssignableFrom(elemType)) {
            Number n = (Number) o;
            if (elemType == Byte.class) {
                return n.byteValue();
            }
            if (elemType == Short.class) {
                return n.shortValue();
            }
            if (elemType == Integer.class) {
                return n.intValue();
            }
            if (elemType == Long.class) {
                return n.longValue();
            }
            if (elemType == Float.class) {
                return n.floatValue();
            }
            if (elemType == Double.class) {
                return n.doubleValue();
            }
        }
        return o;
    }
}
