package client.port262;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import io.netty.buffer.Unpooled;
import net.lax1dude.eaglercraft.EaglercraftUUID;
import net.lax1dude.eaglercraft.internal.IWebSocketClient;
import net.minecraft.client.Minecraft;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.storage.MapDecoration;
import client.event.events.PacketInputEvent;
import client.Client;
import client.port262.packets.config.Config262Packets;
import client.port262.packets.login.Login262Packets;
import client.port262.packets.play.Play262AdvancementPackets;
import client.port262.packets.play.Play262InteractPackets;
import client.port262.packets.play.Play262MiscPackets;
import client.port262.packets.play.Play262MovementPackets;
import client.port262.packets.play.Play262Packets;
import client.port262.packets.play.Play262RecipePackets;
import client.port262.packets.play.Play262ScorePackets;
import client.port262.packets.play.Play262TradePackets;
import client.port262.packets.play.Play262UiPackets;
import client.port262.packets.play.Play262WorldPackets;

public final class Port262Connection {

    private final IWebSocketClient webSocket;

    private final INetHandler netHandler;

    private PacketRegistry262.State state = PacketRegistry262.State.LOGIN;

    private final Map<Integer, Integer> containerStateIds = new HashMap<Integer, Integer>();

    private final Map<Integer, IRecipe> recipeDisplays = new HashMap<Integer, IRecipe>();

    private boolean recipeBookOpen = false;

    private boolean recipeBookFiltering = false;

    private final Map<Integer, MapDecoration[]> mapDecorations = new HashMap<Integer, MapDecoration[]>();

    private int playerInputFlags = 0;

    public String serverBrand = null;

    public String loginUsername = null;

    public EaglercraftUUID loginUuid = null;

    private int unknownLogged = 0;

    private long lastUnknownLogTime = 0L;

    public Port262Connection(IWebSocketClient webSocket, INetHandler netHandler) {
        this.webSocket = webSocket;
        this.netHandler = netHandler;
    }

    public void start() {
        log("[26.2] Tunnel starting (protocol " + Port262.PROTOCOL_ID + ")");
        String uri = webSocket.getCurrentURI();
        String host = sanitizeHost(uri);
        Minecraft mc = Minecraft.getMinecraft();
        String username = mc.getSession().getProfile().getName();
        EaglercraftUUID uuid = mc.getSession().getProfile().getId();
        try {
            Login262Packets.CHandshake handshake = new Login262Packets.CHandshake(Port262.PROTOCOL_ID, host, 25565, 2);
            sendOut(handshake);
            Login262Packets.CLoginStart loginStart = new Login262Packets.CLoginStart(username, uuid.getMostSignificantBits(), uuid.getLeastSignificantBits());
            sendOut(loginStart);
        } catch (IOException ex) {
            log("[26.2] Login sequence send failed: " + ex.getMessage());
            disconnectLocal("26.2 tunnel could not send login sequence");
            return;
        }
        log("[26.2] Handshake + LoginStart sent (" + username + ")");
    }

    private static String sanitizeHost(String uri) {
        if (uri == null) {
            return "unknown";
        }
        String host = uri;
        int scheme = host.indexOf("://");
        if (scheme >= 0) {
            host = host.substring(scheme + 3);
        }
        int slash = host.indexOf('/');
        if (slash >= 0) {
            host = host.substring(0, slash);
        }
        return host;
    }

    public PacketRegistry262.State getState() {
        return state;
    }

    public void trackContainerState(int windowId, int stateId) {
        containerStateIds.put(Integer.valueOf(windowId), Integer.valueOf(stateId));
    }

    public int containerStateId(int windowId) {
        Integer v = containerStateIds.get(Integer.valueOf(windowId));
        return v != null ? v.intValue() : 0;
    }

    public void forgetContainer(int windowId) {
        containerStateIds.remove(Integer.valueOf(windowId));
    }

    public void trackRecipeDisplay(int displayId, IRecipe recipe) {
        if (recipe != null) {
            recipeDisplays.put(Integer.valueOf(displayId), recipe);
        }
    }

    public IRecipe recipeForDisplay(int displayId) {
        return recipeDisplays.get(Integer.valueOf(displayId));
    }

    public int displayForRecipe(IRecipe recipe) {
        for (Map.Entry<Integer, IRecipe> e : recipeDisplays.entrySet()) {
            if (e.getValue() == recipe) {
                return e.getKey().intValue();
            }
        }
        return -1;
    }

    public void setRecipeBookSettings(boolean open, boolean filtering) {
        this.recipeBookOpen = open;
        this.recipeBookFiltering = filtering;
    }

    public boolean recipeBookOpen() {
        return recipeBookOpen;
    }

    public boolean recipeBookFiltering() {
        return recipeBookFiltering;
    }

    public void trackMapDecorations(int mapId, MapDecoration[] icons) {
        mapDecorations.put(Integer.valueOf(mapId), icons);
    }

    public MapDecoration[] mapDecorationsFor(int mapId) {
        return mapDecorations.get(Integer.valueOf(mapId));
    }

    public int playerInputFlags() {
        return playerInputFlags;
    }

    public void setPlayerInputFlags(int flags) {
        this.playerInputFlags = flags;
    }

    public void enterPlayState() {
        state = PacketRegistry262.State.PLAY;
        log("[26.2] PLAY state reached — native 26.2 tunnel established");
        log("[26.2] Server brand: " + (serverBrand != null ? serverBrand : "unknown"));
    }

    public void enterConfigurationState() {
        state = PacketRegistry262.State.CONFIGURATION;
        try {
            sendOut(new Play262MiscPackets.CConfigurationAcknowledged());
        } catch (IOException ex) {
            log("[26.2] configuration_acknowledged send failed: " + ex.getMessage());
        }
        log("[26.2] start_configuration — re-entering CONFIGURATION");
    }

    public void processInbound(int packetId, PacketBuffer raw) {
        try {
            if (state == PacketRegistry262.State.PLAY) {
            }
            Packet262In pkt = PacketRegistry262.create(state, packetId);
            if (pkt == null) {
                logUnknown(state, packetId);
                return;
            }
            Port262Buffer buf = new Port262Buffer(raw);
            pkt.read(buf);
            Packet translated = pkt.process(this);
            if (translated != null && netHandler != null) {
                dispatchTranslated(translated);
            }
            if (pkt instanceof Login262Packets.SLoginSuccess) {
                Login262Packets.SLoginSuccess success = (Login262Packets.SLoginSuccess) pkt;
                this.loginUsername = success.username;
                this.loginUuid = new EaglercraftUUID(success.uuidMsb, success.uuidLsb);
                sendOut(new Login262Packets.CLoginAcknowledged());
                state = PacketRegistry262.State.CONFIGURATION;
                log("[26.2] Login acknowledged — entering configuration (" + success.username + ")");
                sendOut(new Config262Packets.CClientInformation());
                sendOut(new Config262Packets.CCustomPayload("minecraft:brand", Config262Packets.brandPayload(Port262.CLIENT_BRAND)));
            }
            if (pkt instanceof Play262WorldPackets.SMapChunk) {
                Play262WorldPackets.SMapChunk chunk = (Play262WorldPackets.SMapChunk) pkt;
                log("[26.2] chunk (" + chunk.chunkX + "," + chunk.chunkZ + ") decoded" + (chunk.getTranslated() != null ? "" : " (world not ready, skipped)"));
            }
        } catch (client.port262.Port262SkipException skip) {
            log("[26.2] Skipped packet id=" + packetId + " state=" + state + ": " + skip.getMessage());
        } catch (RuntimeException broken) {
            log("[26.2] Decode failure id=" + packetId + " state=" + state + ": " + broken);
        } catch (IOException ex) {
            log("[26.2] DECODE ERROR id=" + packetId + " state=" + state + ": " + ex.getMessage());
            disconnectLocal("26.2 protocol decode error (id " + packetId + ")");
        }
    }

    public void dispatch(Packet translated) {
        dispatchTranslated(translated);
    }

    private void dispatchTranslated(Packet translated) {
        PacketInputEvent event = new PacketInputEvent(translated);
        Client.bus().post(event);
        if (event.isCancelled()) {
            return;
        }
        try {
            ((Packet) event.getPacket()).processPacket(netHandler);
        } catch (Throwable t) {
            log("[26.2] Translated packet dispatch failed: " + t);
        }
    }

    public boolean processOutbound(Packet pkt) {
        Packet262Out[] translators = playOutbound();
        for (Packet262Out translator : translators) {
            if (translator.matches(pkt)) {
                translator.setConnection(this);
                translator.fromPacket(pkt);
                if (!translator.shouldSend()) {
                    return true;
                }
                try {
                    sendOut(translator);
                } catch (IOException ex) {
                    log("[26.2] Outbound encode failed: " + ex.getMessage());
                }
                return true;
            }
        }
        log("[26.2] Outbound 1.12.2 packet has no 26.2 translator yet: " + pkt.getClass().getSimpleName() + " (dropped)");
        return true;
    }

    private Packet262Out[] playOutbound() {
        return new Packet262Out[] { new Play262TradePackets.CSelectTrade(), new Play262Packets.CKeepAlive(), new Play262Packets.CPluginMessage(), new Play262MovementPackets.CPlayerPosition(), new Play262MovementPackets.CPlayerPositionLook(), new Play262MovementPackets.CLook(), new Play262MovementPackets.CPlayerFlying(), new Play262MovementPackets.CConfirmTeleport(), new Play262MovementPackets.CClientSettings(), new Play262UiPackets.CChatCommand(), new Play262UiPackets.CChatMessage(), new Play262UiPackets.CClientCommand(), new Play262UiPackets.CHeldItemChange(), new Play262UiPackets.CArmAnimation(), new Play262InteractPackets.CAbilities(), new Play262InteractPackets.CAttack(), new Play262InteractPackets.CUseEntity(), new Play262InteractPackets.CBlockDig(), new Play262InteractPackets.CBlockPlace(), new Play262InteractPackets.CUseItem(), new Play262InteractPackets.CWindowClick(), new Play262InteractPackets.CCloseWindow(), new Play262InteractPackets.CSetCreativeSlot(), new Play262InteractPackets.CUpdateSign(), new Play262AdvancementPackets.CAdvancementTab(), new Play262RecipePackets.CCraftRecipeRequest(), new Play262RecipePackets.CRecipeBookInfo(), new Play262RecipePackets.CDisplayedRecipe(), new Play262MiscPackets.CTabCompleteRequest(), new Play262MiscPackets.CPlayerInput(), new Play262MiscPackets.CEntityAction(), new Play262MiscPackets.CVehicleMove(), new Play262MiscPackets.CSteerBoat(), new Play262MiscPackets.CConfigurationAcknowledged(), new Play262MiscPackets.CPong() };
    }

    public void sendOut(Packet262Out pkt) throws IOException {
        PacketBuffer raw = new PacketBuffer(Unpooled.buffer(256));
        Port262Buffer buf = new Port262Buffer(raw);
        buf.writeVarInt(pkt.getId());
        pkt.write(buf);
        byte[] frame = new byte[raw.readableBytes()];
        raw.getBytes(0, frame);
        webSocket.send(frame);
    }

    public void disconnectLocal(String reason) {
        log("[26.2] Disconnecting: " + reason);
        Port262.deactivate();
        if (netHandler != null) {
            netHandler.onDisconnect(new TextComponentString(reason));
        }
    }

    private void logUnknown(PacketRegistry262.State st, int id) {
        long now = System.currentTimeMillis();
        if (unknownLogged < 32 || now - lastUnknownLogTime > 5000L) {
            log("[26.2] Unknown " + st + " packet id " + id + " (skipped, no dispatch)");
            unknownLogged++;
            lastUnknownLogTime = now;
        }
    }

    private static void log(String msg) {
        client.tuff.TuffDebugLog.log(msg);
    }
}
