package client.port262;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import client.port262.packets.config.Config262Packets;
import client.port262.packets.login.Login262Packets;
import client.port262.packets.play.Play262AdvancementPackets;
import client.port262.packets.play.Play262BorderPackets;
import client.port262.packets.play.Play262EffectPackets;
import client.port262.packets.play.Play262EntityPackets;
import client.port262.packets.play.Play262InteractPackets;
import client.port262.packets.play.Play262MiscPackets;
import client.port262.packets.play.Play262MovementPackets;
import client.port262.packets.play.Play262Packets;
import client.port262.packets.play.Play262RecipePackets;
import client.port262.packets.play.Play262ScorePackets;
import client.port262.packets.play.Play262TradePackets;
import client.port262.packets.play.Play262UiPackets;
import client.port262.packets.play.Play262WorldPackets;

public final class PacketRegistry262 {

    public enum State {

        LOGIN, CONFIGURATION, PLAY
    }

    private static final Map<State, Map<Integer, Supplier<Packet262In>>> REGISTRY = new HashMap<>();

    static {
        Map<Integer, Supplier<Packet262In>> login = new HashMap<>();
        login.put(Login262Packets.SLoginSuccess.ID, Login262Packets.SLoginSuccess::new);
        login.put(Login262Packets.SLoginDisconnect.ID, Login262Packets.SLoginDisconnect::new);
        REGISTRY.put(State.LOGIN, login);
        Map<Integer, Supplier<Packet262In>> config = new HashMap<>();
        config.put(Config262Packets.SCookieRequest.ID, Config262Packets.SCookieRequest::new);
        config.put(Config262Packets.SCustomPayload.ID, Config262Packets.SCustomPayload::new);
        config.put(Config262Packets.SDisconnect.ID, Config262Packets.SDisconnect::new);
        config.put(Config262Packets.SFinishConfiguration.ID, Config262Packets.SFinishConfiguration::new);
        config.put(Config262Packets.SKeepAlive.ID, Config262Packets.SKeepAlive::new);
        config.put(Config262Packets.SPing.ID, Config262Packets.SPing::new);
        config.put(Config262Packets.SResetChat.ID, Config262Packets.SResetChat::new);
        config.put(Config262Packets.SRegistryData.ID, Config262Packets.SRegistryData::new);
        config.put(Config262Packets.SRemoveResourcePack.ID, Config262Packets.SRemoveResourcePack::new);
        config.put(Config262Packets.SAddResourcePack.ID, Config262Packets.SAddResourcePack::new);
        config.put(Config262Packets.SStoreCookie.ID, Config262Packets.SStoreCookie::new);
        config.put(Config262Packets.STransfer.ID, Config262Packets.STransfer::new);
        config.put(Config262Packets.SFeatureFlags.ID, Config262Packets.SFeatureFlags::new);
        config.put(Config262Packets.STags.ID, Config262Packets.STags::new);
        config.put(Config262Packets.SSelectKnownPacks.ID, Config262Packets.SSelectKnownPacks::new);
        config.put(Config262Packets.SCustomReportDetails.ID, Config262Packets.SCustomReportDetails::new);
        config.put(Config262Packets.SClearDialog.ID, Config262Packets.SClearDialog::new);
        config.put(Config262Packets.SShowDialog.ID, Config262Packets.SShowDialog::new);
        config.put(Config262Packets.SCodeOfConduct.ID, Config262Packets.SCodeOfConduct::new);
        REGISTRY.put(State.CONFIGURATION, config);
        Map<Integer, Supplier<Packet262In>> play = new HashMap<>();
        play.put(Play262Packets.SKeepAlive.ID, Play262Packets.SKeepAlive::new);
        play.put(Play262Packets.SKickDisconnect.ID, Play262Packets.SKickDisconnect::new);
        play.put(Play262Packets.SPluginMessage.ID, Play262Packets.SPluginMessage::new);
        play.put(Play262WorldPackets.SJoinGame.ID, Play262WorldPackets.SJoinGame::new);
        play.put(Play262WorldPackets.SSpawnPosition.ID, Play262WorldPackets.SSpawnPosition::new);
        play.put(Play262WorldPackets.SUpdateTime.ID, Play262WorldPackets.SUpdateTime::new);
        play.put(Play262WorldPackets.SMapChunk.ID, Play262WorldPackets.SMapChunk::new);
        play.put(Play262WorldPackets.SUnloadChunk.ID, Play262WorldPackets.SUnloadChunk::new);
        play.put(Play262WorldPackets.SBlockChange.ID, Play262WorldPackets.SBlockChange::new);
        play.put(Play262WorldPackets.SBlockEntityData.ID, Play262WorldPackets.SBlockEntityData::new);
        play.put(Play262WorldPackets.SMultiBlockChange.ID, Play262WorldPackets.SMultiBlockChange::new);
        play.put(Play262WorldPackets.SUpdateViewPosition.ID, Play262WorldPackets.SUpdateViewPosition::new);
        play.put(Play262WorldPackets.SChunkBatchStart.ID, Play262WorldPackets.SChunkBatchStart::new);
        play.put(Play262WorldPackets.SChunkBatchFinished.ID, Play262WorldPackets.SChunkBatchFinished::new);
        play.put(Play262EntityPackets.SSpawnEntity.ID, Play262EntityPackets.SSpawnEntity::new);
        play.put(Play262EntityPackets.SAnimation.ID, Play262EntityPackets.SAnimation::new);
        play.put(Play262EntityPackets.SEntityStatus.ID, Play262EntityPackets.SEntityStatus::new);
        play.put(Play262EntityPackets.SSyncEntityPosition.ID, Play262EntityPackets.SSyncEntityPosition::new);
        play.put(Play262EntityPackets.SRelEntityMove.ID, Play262EntityPackets.SRelEntityMove::new);
        play.put(Play262EntityPackets.SEntityMoveLook.ID, Play262EntityPackets.SEntityMoveLook::new);
        play.put(Play262EntityPackets.SEntityLook.ID, Play262EntityPackets.SEntityLook::new);
        play.put(Play262EntityPackets.SEntityTeleport.ID, Play262EntityPackets.SEntityTeleport::new);
        play.put(Play262EntityPackets.SHeadRotation.ID, Play262EntityPackets.SHeadRotation::new);
        play.put(Play262EntityPackets.SEntityMetadata.ID, Play262EntityPackets.SEntityMetadata::new);
        play.put(Play262EntityPackets.SAttachEntity.ID, Play262EntityPackets.SAttachEntity::new);
        play.put(Play262EntityPackets.SSetPassengers.ID, Play262EntityPackets.SSetPassengers::new);
        play.put(Play262EntityPackets.SEntityVelocity.ID, Play262EntityPackets.SEntityVelocity::new);
        play.put(Play262EntityPackets.SEntityEquipment.ID, Play262EntityPackets.SEntityEquipment::new);
        play.put(Play262EntityPackets.SEntityEffect.ID, Play262EntityPackets.SEntityEffect::new);
        play.put(Play262EntityPackets.SRemoveEntityEffect.ID, Play262EntityPackets.SRemoveEntityEffect::new);
        play.put(Play262EntityPackets.SCollect.ID, Play262EntityPackets.SCollect::new);
        play.put(Play262EntityPackets.SEntityDestroy.ID, Play262EntityPackets.SEntityDestroy::new);
        play.put(Play262EntityPackets.SHurtAnimation.ID, Play262EntityPackets.SHurtAnimation::new);
        play.put(Play262UiPackets.SSystemChat.ID, Play262UiPackets.SSystemChat::new);
        play.put(Play262UiPackets.SPlayerChat.ID, Play262UiPackets.SPlayerChat::new);
        play.put(Play262UiPackets.SActionBar.ID, Play262UiPackets.SActionBar::new);
        play.put(Play262UiPackets.STitleText.ID, Play262UiPackets.STitleText::new);
        play.put(Play262UiPackets.STitleSubtitle.ID, Play262UiPackets.STitleSubtitle::new);
        play.put(Play262UiPackets.STitleTime.ID, Play262UiPackets.STitleTime::new);
        play.put(Play262UiPackets.SClearTitles.ID, Play262UiPackets.SClearTitles::new);
        play.put(Play262UiPackets.SPlayerListHeader.ID, Play262UiPackets.SPlayerListHeader::new);
        play.put(Play262UiPackets.SPlayerInfo.ID, Play262UiPackets.SPlayerInfo::new);
        play.put(Play262UiPackets.SPlayerRemove.ID, Play262UiPackets.SPlayerRemove::new);
        play.put(Play262UiPackets.SUpdateHealth.ID, Play262UiPackets.SUpdateHealth::new);
        play.put(Play262UiPackets.SExperience.ID, Play262UiPackets.SExperience::new);
        play.put(Play262UiPackets.SHeldItemSlot.ID, Play262UiPackets.SHeldItemSlot::new);
        play.put(Play262UiPackets.SGameStateChange.ID, Play262UiPackets.SGameStateChange::new);
        play.put(Play262UiPackets.SRespawn.ID, Play262UiPackets.SRespawn::new);
        play.put(Play262UiPackets.SDifficulty.ID, Play262UiPackets.SDifficulty::new);
        play.put(Play262UiPackets.SCamera.ID, Play262UiPackets.SCamera::new);
        play.put(Play262UiPackets.SWorldEvent.ID, Play262UiPackets.SWorldEvent::new);
        play.put(Play262UiPackets.SSoundEffect.ID, Play262UiPackets.SSoundEffect::new);
        play.put(Play262UiPackets.SEntitySoundEffect.ID, Play262UiPackets.SEntitySoundEffect::new);
        play.put(Play262UiPackets.SBossBar.ID, Play262UiPackets.SBossBar::new);
        play.put(Play262InteractPackets.SAckDigging.ID, Play262InteractPackets.SAckDigging::new);
        play.put(Play262InteractPackets.SBlockAction.ID, Play262InteractPackets.SBlockAction::new);
        play.put(Play262InteractPackets.SCloseWindow.ID, Play262InteractPackets.SCloseWindow::new);
        play.put(Play262InteractPackets.SWindowItems.ID, Play262InteractPackets.SWindowItems::new);
        play.put(Play262InteractPackets.SCraftProgressBar.ID, Play262InteractPackets.SCraftProgressBar::new);
        play.put(Play262InteractPackets.SSetSlot.ID, Play262InteractPackets.SSetSlot::new);
        play.put(Play262InteractPackets.SOpenWindow.ID, Play262InteractPackets.SOpenWindow::new);
        play.put(Play262InteractPackets.SOpenSignEntity.ID, Play262InteractPackets.SOpenSignEntity::new);
        play.put(Play262InteractPackets.SAbilities.ID, Play262InteractPackets.SAbilities::new);
        play.put(Play262InteractPackets.SSetCursorItem.ID, Play262InteractPackets.SSetCursorItem::new);
        play.put(Play262TradePackets.STradeList.ID, Play262TradePackets.STradeList::new);
        play.put(Play262TradePackets.SUpdateAttributes.ID, Play262TradePackets.SUpdateAttributes::new);
        play.put(Play262TradePackets.SEnterCombat.ID, Play262TradePackets.SEnterCombat::new);
        play.put(Play262TradePackets.SEndCombat.ID, Play262TradePackets.SEndCombat::new);
        play.put(Play262TradePackets.SDeathCombat.ID, Play262TradePackets.SDeathCombat::new);
        play.put(Play262ScorePackets.SScoreboardObjective.ID, Play262ScorePackets.SScoreboardObjective::new);
        play.put(Play262ScorePackets.SScoreboardDisplayObjective.ID, Play262ScorePackets.SScoreboardDisplayObjective::new);
        play.put(Play262ScorePackets.SScoreboardScore.ID, Play262ScorePackets.SScoreboardScore::new);
        play.put(Play262ScorePackets.SResetScore.ID, Play262ScorePackets.SResetScore::new);
        play.put(Play262ScorePackets.STeams.ID, Play262ScorePackets.STeams::new);
        play.put(Play262AdvancementPackets.SAdvancements.ID, Play262AdvancementPackets.SAdvancements::new);
        play.put(Play262AdvancementPackets.SSelectAdvancementTab.ID, Play262AdvancementPackets.SSelectAdvancementTab::new);
        play.put(Play262BorderPackets.SInitializeWorldBorder.ID, Play262BorderPackets.SInitializeWorldBorder::new);
        play.put(Play262BorderPackets.SWorldBorderCenter.ID, Play262BorderPackets.SWorldBorderCenter::new);
        play.put(Play262BorderPackets.SWorldBorderLerpSize.ID, Play262BorderPackets.SWorldBorderLerpSize::new);
        play.put(Play262BorderPackets.SWorldBorderSize.ID, Play262BorderPackets.SWorldBorderSize::new);
        play.put(Play262BorderPackets.SWorldBorderWarningDelay.ID, Play262BorderPackets.SWorldBorderWarningDelay::new);
        play.put(Play262BorderPackets.SWorldBorderWarningReach.ID, Play262BorderPackets.SWorldBorderWarningReach::new);
        play.put(Play262RecipePackets.SDeclareRecipes.ID, Play262RecipePackets.SDeclareRecipes::new);
        play.put(Play262RecipePackets.SRecipeBookAdd.ID, Play262RecipePackets.SRecipeBookAdd::new);
        play.put(Play262RecipePackets.SRecipeBookRemove.ID, Play262RecipePackets.SRecipeBookRemove::new);
        play.put(Play262RecipePackets.SRecipeBookSettings.ID, Play262RecipePackets.SRecipeBookSettings::new);
        play.put(Play262RecipePackets.SCraftRecipeResponse.ID, Play262RecipePackets.SCraftRecipeResponse::new);
        play.put(Play262MovementPackets.SPlayerPosLook.ID, Play262MovementPackets.SPlayerPosLook::new);
        play.put(Play262MovementPackets.SVehicleMove.ID, Play262MovementPackets.SVehicleMove::new);
        play.put(Play262EffectPackets.SWorldParticles.ID, Play262EffectPackets.SWorldParticles::new);
        play.put(Play262EffectPackets.SExplosion.ID, Play262EffectPackets.SExplosion::new);
        play.put(Play262EffectPackets.SBlockBreakAnimation.ID, Play262EffectPackets.SBlockBreakAnimation::new);
        play.put(Play262EffectPackets.SSetCooldown.ID, Play262EffectPackets.SSetCooldown::new);
        play.put(Play262WorldPackets.SMapData.ID, Play262WorldPackets.SMapData::new);
        play.put(Play262InteractPackets.SSetPlayerInventory.ID, Play262InteractPackets.SSetPlayerInventory::new);
        play.put(Play262MiscPackets.STabComplete.ID, Play262MiscPackets.STabComplete::new);
        play.put(Play262MiscPackets.SOpenHorseWindow.ID, Play262MiscPackets.SOpenHorseWindow::new);
        play.put(Play262MiscPackets.SStatistics.ID, Play262MiscPackets.SStatistics::new);
        play.put(Play262MiscPackets.SUpdateLight.ID, Play262MiscPackets.SUpdateLight::new);
        play.put(Play262MiscPackets.SBundleDelimiter.ID, Play262MiscPackets.SBundleDelimiter::new);
        play.put(Play262MiscPackets.SPing.ID, Play262MiscPackets.SPing::new);
        play.put(Play262MiscPackets.SStartConfiguration.ID, Play262MiscPackets.SStartConfiguration::new);
        play.put(Play262MiscPackets.SDeclareCommands.ID, Play262MiscPackets.SDeclareCommands::new);
        play.put(Play262MiscPackets.STags.ID, Play262MiscPackets.STags::new);
        play.put(Play262MiscPackets.SAddResourcePack.ID, Play262MiscPackets.SAddResourcePack::new);
        play.put(Play262MiscPackets.SRemoveResourcePack.ID, Play262MiscPackets.SRemoveResourcePack::new);
        play.put(Play262MiscPackets.SUpdateViewDistance.ID, Play262MiscPackets.SUpdateViewDistance::new);
        play.put(Play262MiscPackets.SSimulationDistance.ID, Play262MiscPackets.SSimulationDistance::new);
        play.put(Play262MiscPackets.SStopSound.ID, Play262MiscPackets.SStopSound::new);
        play.put(Play262MiscPackets.SServerData.ID, Play262MiscPackets.SServerData::new);
        REGISTRY.put(State.PLAY, play);
    }

    private PacketRegistry262() {
    }

    public static Packet262In create(State state, int id) throws IOException {
        Map<Integer, Supplier<Packet262In>> map = REGISTRY.get(state);
        if (map == null) {
            return null;
        }
        Supplier<Packet262In> supplier = map.get(id);
        return supplier != null ? supplier.get() : null;
    }
}
