package client.port262;

import java.util.List;
import java.util.Map;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.event.ClickEvent;

public final class Port262Text {

    private Port262Text() {
    }

    public static ITextComponent fromNbt(Object node) {
        if (node instanceof String) {
            return new TextComponentString((String) node);
        }
        if (node instanceof List) {
            TextComponentString root = new TextComponentString("");
            for (Object child : (List<?>) node) {
                root.appendSibling(fromNbt(child));
            }
            return root;
        }
        if (node instanceof Map) {
            return fromCompound((Map<?, ?>) node);
        }
        return new TextComponentString("");
    }

    @SuppressWarnings("unchecked")
    private static ITextComponent fromCompound(Map<?, ?> tag) {
        ITextComponent base;
        Object text = tag.get("text");
        if (text instanceof String) {
            base = new TextComponentString((String) text);
        } else {
            Object translate = tag.get("translate");
            if (translate instanceof String) {
                Object with = tag.get("with");
                if (with instanceof List) {
                    List<Object> args = (List<Object>) with;
                    Object[] converted = new Object[args.size()];
                    for (int i = 0; i < args.size(); i++) {
                        converted[i] = fromNbt(args.get(i));
                    }
                    base = new TextComponentTranslation((String) translate, converted);
                } else {
                    base = new TextComponentTranslation((String) translate);
                }
            } else {
                base = new TextComponentString("");
            }
        }
        Object extra = tag.get("extra");
        if (extra instanceof List) {
            for (Object child : (List<?>) extra) {
                base.appendSibling(fromNbt(child));
            }
        }
        net.minecraft.util.text.Style style = base.getStyle();
        Object color = tag.get("color");
        if (color instanceof String) {
            TextFormatting fmt = TextFormatting.getValueByName(((String) color).toUpperCase());
            if (fmt != null && fmt.isColor()) {
                style.setColor(fmt);
            }
        }
        style.setBold(asBool(tag.get("bold")));
        style.setItalic(asBool(tag.get("italic")));
        style.setUnderlined(asBool(tag.get("underlined")));
        style.setStrikethrough(asBool(tag.get("strikethrough")));
        style.setObfuscated(asBool(tag.get("obfuscated")));
        Object click = tag.get("clickEvent");
        if (click instanceof Map) {
            Object action = ((Map<?, ?>) click).get("action");
            Object value = ((Map<?, ?>) click).get("value");
            if (action instanceof String && value instanceof String) {
                ClickEvent.Action mapped = mapClickAction((String) action);
                if (mapped != null) {
                    style.setClickEvent(new ClickEvent(mapped, (String) value));
                }
            }
        }
        return base;
    }

    private static ClickEvent.Action mapClickAction(String action) {
        if ("open_url".equals(action)) {
            return ClickEvent.Action.OPEN_URL;
        }
        if ("run_command".equals(action)) {
            return ClickEvent.Action.RUN_COMMAND;
        }
        if ("suggest_command".equals(action)) {
            return ClickEvent.Action.SUGGEST_COMMAND;
        }
        if ("change_page".equals(action)) {
            return ClickEvent.Action.CHANGE_PAGE;
        }
        return null;
    }

    private static Boolean asBool(Object value) {
        if (value instanceof Boolean) {
            return (Boolean) value ? Boolean.TRUE : Boolean.FALSE;
        }
        if (value instanceof String && ((String) value).isEmpty()) {
            return Boolean.TRUE;
        }
        return null;
    }

    public static String plainText(Object node) {
        try {
            ITextComponent component = fromNbt(node);
            return component == null ? "" : component.getUnformattedText();
        } catch (Throwable t) {
            return "";
        }
    }

    public static String legacyText(Object node, int maxLen) {
        if (maxLen <= 0) {
            return "";
        }
        try {
            ITextComponent component = fromNbt(node);
            if (component == null) {
                return "";
            }
            String formatted = component.getFormattedText();
            if (formatted == null) {
                return "";
            }
            if (formatted.length() <= maxLen) {
                return formatted;
            }
            StringBuilder plain = new StringBuilder();
            for (int i = 0; i < formatted.length() && plain.length() < maxLen; i++) {
                char c = formatted.charAt(i);
                if (c == '\u00a7' && i + 1 < formatted.length()) {
                    i++;
                    continue;
                }
                plain.append(c);
            }
            return plain.length() <= maxLen ? plain.toString() : plain.substring(0, maxLen);
        } catch (Throwable t) {
            return "";
        }
    }
}
