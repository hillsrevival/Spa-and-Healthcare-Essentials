package client.port262;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class Port262Nbt {

    private static final int MAX_DEPTH = 32;

    private static final int MAX_LIST = 0x80000;

    private Port262Nbt() {
    }

    public static Object readAnonymous(Port262Buffer buf) throws IOException {
        int type = buf.readUByte();
        return readPayload(type, buf, 0);
    }

    public static Map<String, Object> readRootCompound(Port262Buffer buf) throws IOException {
        int type = buf.readUByte();
        if (type == 0x00) {
            return null;
        }
        if (type != 0x0A) {
            throw new IOException("26.2 NBT root is not a compound: " + type);
        }
        return (Map<String, Object>) readPayload(type, buf, 0);
    }

    @SuppressWarnings("unchecked")
    private static Object readPayload(int type, Port262Buffer buf, int depth) throws IOException {
        if (depth > MAX_DEPTH) {
            throw new IOException("26.2 NBT nesting too deep");
        }
        switch(type) {
            case 0x00:
                return null;
            case 0x01:
                return buf.readByte();
            case 0x02:
                return buf.readShort();
            case 0x03:
                return buf.readFixedInt();
            case 0x04:
                return buf.readFixedLong();
            case 0x05:
                return buf.readFloat();
            case 0x06:
                return buf.readDouble();
            case 0x07:
                {
                    int len = buf.readFixedInt();
                    if (len < 0 || len > buf.readableBytes()) {
                        throw new IOException("26.2 NBT byte array overruns: " + len);
                    }
                    byte[] out = new byte[len];
                    buf.raw().readBytes(out);
                    return out;
                }
            case 0x08:
                return readNbtString(buf);
            case 0x09:
                {
                    int elemType = buf.readUByte();
                    int len = buf.readFixedInt();
                    if (len < 0 || len > MAX_LIST) {
                        throw new IOException("26.2 NBT list too long: " + len);
                    }
                    List<Object> out = new ArrayList<Object>(Math.min(len, 256));
                    for (int i = 0; i < len; i++) {
                        out.add(readPayload(elemType, buf, depth + 1));
                    }
                    return out;
                }
            case 0x0A:
                {
                    Map<String, Object> out = new LinkedHashMap<String, Object>();
                    while (true) {
                        int childType = buf.readUByte();
                        if (childType == 0x00) {
                            return out;
                        }
                        String name = readNbtString(buf);
                        out.put(name, readPayload(childType, buf, depth + 1));
                    }
                }
            case 0x0B:
                {
                    int len = buf.readFixedInt();
                    if (len < 0 || len > MAX_LIST) {
                        throw new IOException("26.2 NBT int array too long: " + len);
                    }
                    int[] out = new int[len];
                    for (int i = 0; i < len; i++) {
                        out[i] = buf.readFixedInt();
                    }
                    return out;
                }
            case 0x0C:
                {
                    int len = buf.readFixedInt();
                    if (len < 0 || len > MAX_LIST) {
                        throw new IOException("26.2 NBT long array too long: " + len);
                    }
                    long[] out = new long[len];
                    for (int i = 0; i < len; i++) {
                        out[i] = buf.readFixedLong();
                    }
                    return out;
                }
            default:
                throw new IOException("26.2 NBT unknown tag type: " + type);
        }
    }

    private static String readNbtString(Port262Buffer buf) throws IOException {
        int len = buf.readUShort();
        if (len < 0 || len > 65535) {
            throw new IOException("26.2 NBT string length out of range: " + len);
        }
        byte[] out = new byte[len];
        buf.raw().readBytes(out);
        return new String(out, java.nio.charset.StandardCharsets.UTF_8);
    }
}
