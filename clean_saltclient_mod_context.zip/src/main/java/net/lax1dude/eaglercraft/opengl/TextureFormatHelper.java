package net.lax1dude.eaglercraft.opengl;

import static net.lax1dude.eaglercraft.opengl.RealOpenGLEnums.*;
import static net.lax1dude.eaglercraft.opengl.ExtGLEnums.*;

public class TextureFormatHelper {

    public static int getFormatFromInternal(int internalFormat) {
        switch(internalFormat) {
            case _GL_R8:
            case 0x822D:
            case 0x822E:
                return GL_RED;
            case _GL_RG8:
            case 0x822F:
            case 0x8230:
                return _GL_RG;
            case GL_RGB8:
            case _GL_RGB16F:
            case 0x8815:
                return GL_RGB;
            case GL_RGBA8:
            case 0x881A:
            case 0x8814:
                return GL_RGBA;
            default:
                throw new UnsupportedOperationException();
        }
    }

    public static int getTypeFromInternal(int internalFormat) {
        switch(internalFormat) {
            case _GL_R8:
            case _GL_RG8:
            case GL_RGB8:
            case GL_RGBA8:
                return GL_UNSIGNED_BYTE;
            case 0x822D:
            case 0x822F:
            case _GL_RGB16F:
            case 0x881A:
                return _GL_HALF_FLOAT;
            case 0x822E:
            case 0x8230:
            case 0x8815:
            case 0x8814:
                return GL_FLOAT;
            default:
                throw new UnsupportedOperationException();
        }
    }

    public static int trivializeInternalFormatToGLES20(int internalFormat) {
        switch(internalFormat) {
            case _GL_R8:
                return GL_LUMINANCE;
            case GL_RGB8:
                return GL_RGB;
            case GL_RGBA8:
                return GL_RGBA;
            default:
                throw new UnsupportedOperationException();
        }
    }
}
