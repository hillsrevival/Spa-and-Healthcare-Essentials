package net.lax1dude.eaglercraft.opengl;

import net.lax1dude.eaglercraft.opengl.SoftGLVertexArray.Attrib;

class SoftGLVertexState {

    final Attrib[] attribs = new Attrib[24];

    int[] attribDivisors = new int[24];

    int hasAttribDivisorMask = 0;

    int oldEnabled = 0;

    int oldEnabledCnt = -1;

    SoftGLVertexState() {
    }
}
