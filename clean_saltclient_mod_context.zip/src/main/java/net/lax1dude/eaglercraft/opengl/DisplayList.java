package net.lax1dude.eaglercraft.opengl;

import net.lax1dude.eaglercraft.internal.IVertexArrayGL;
import net.lax1dude.eaglercraft.internal.IBufferGL;

class DisplayList {

    IVertexArrayGL vertexArray = null;

    IBufferGL vertexBuffer = null;

    int attribs = -1;

    int mode = -1;

    int count = 0;

    boolean bindQuad16 = false;

    boolean bindQuad32 = false;
}
