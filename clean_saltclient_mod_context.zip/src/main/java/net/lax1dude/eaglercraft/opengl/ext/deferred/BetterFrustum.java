/*
 * The MIT License
 *
 * Copyright (c) 2015-2022 Kai Burjack
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package net.lax1dude.eaglercraft.opengl.ext.deferred;

import net.lax1dude.eaglercraft.vector.Matrix4f;
import net.lax1dude.eaglercraft.vector.Vector2f;
import net.lax1dude.eaglercraft.vector.Vector3f;
import net.lax1dude.eaglercraft.vector.Vector4f;

public class BetterFrustum {

    public static final int PLANE_NX = 0;

    public static final int PLANE_PX = 1;

    public static final int PLANE_NY = 2;

    public static final int PLANE_PY = 3;

    public static final int PLANE_NZ = 4;

    public static final int PLANE_PZ = 5;

    public static final int INTERSECT = -1;

    public static final int INSIDE = -2;

    public static final int OUTSIDE = -3;

    public static final int PLANE_MASK_NX = 1 << PLANE_NX;

    public static final int PLANE_MASK_PX = 1 << PLANE_PX;

    public static final int PLANE_MASK_NY = 1 << PLANE_NY;

    public static final int PLANE_MASK_PY = 1 << PLANE_PY;

    public static final int PLANE_MASK_NZ = 1 << PLANE_NZ;

    public static final int PLANE_MASK_PZ = 1 << PLANE_PZ;

    private float nxX, nxY, nxZ, nxW;

    private float pxX, pxY, pxZ, pxW;

    private float nyX, nyY, nyZ, nyW;

    private float pyX, pyY, pyZ, pyW;

    private float nzX, nzY, nzZ, nzW;

    private float pzX, pzY, pzZ, pzW;

    private final Vector4f[] planes = new Vector4f[6];

    {
        for (int i = 0; i < 6; i++) {
            planes[i] = new Vector4f();
        }
    }

    public BetterFrustum() {
    }

    public BetterFrustum(Matrix4f m) {
        set(m, true);
    }

    public BetterFrustum(Matrix4f m, boolean allowTestSpheres) {
        set(m, allowTestSpheres);
    }

    public BetterFrustum set(Matrix4f m) {
        return set(m, true);
    }

    public BetterFrustum set(Matrix4f m, boolean allowTestSpheres) {
        float invl;
        nxX = m.m03 + m.m00;
        nxY = m.m13 + m.m10;
        nxZ = m.m23 + m.m20;
        nxW = m.m33 + m.m30;
        if (allowTestSpheres) {
            invl = 1.0f / (float) Math.sqrt(nxX * nxX + nxY * nxY + nxZ * nxZ);
            nxX *= invl;
            nxY *= invl;
            nxZ *= invl;
            nxW *= invl;
        }
        planes[0].set(nxX, nxY, nxZ, nxW);
        pxX = m.m03 - m.m00;
        pxY = m.m13 - m.m10;
        pxZ = m.m23 - m.m20;
        pxW = m.m33 - m.m30;
        if (allowTestSpheres) {
            invl = 1.0f / (float) Math.sqrt(pxX * pxX + pxY * pxY + pxZ * pxZ);
            pxX *= invl;
            pxY *= invl;
            pxZ *= invl;
            pxW *= invl;
        }
        planes[1].set(pxX, pxY, pxZ, pxW);
        nyX = m.m03 + m.m01;
        nyY = m.m13 + m.m11;
        nyZ = m.m23 + m.m21;
        nyW = m.m33 + m.m31;
        if (allowTestSpheres) {
            invl = 1.0f / (float) Math.sqrt(nyX * nyX + nyY * nyY + nyZ * nyZ);
            nyX *= invl;
            nyY *= invl;
            nyZ *= invl;
            nyW *= invl;
        }
        planes[2].set(nyX, nyY, nyZ, nyW);
        pyX = m.m03 - m.m01;
        pyY = m.m13 - m.m11;
        pyZ = m.m23 - m.m21;
        pyW = m.m33 - m.m31;
        if (allowTestSpheres) {
            invl = 1.0f / (float) Math.sqrt(pyX * pyX + pyY * pyY + pyZ * pyZ);
            pyX *= invl;
            pyY *= invl;
            pyZ *= invl;
            pyW *= invl;
        }
        planes[3].set(pyX, pyY, pyZ, pyW);
        nzX = m.m03 + m.m02;
        nzY = m.m13 + m.m12;
        nzZ = m.m23 + m.m22;
        nzW = m.m33 + m.m32;
        if (allowTestSpheres) {
            invl = 1.0f / (float) Math.sqrt(nzX * nzX + nzY * nzY + nzZ * nzZ);
            nzX *= invl;
            nzY *= invl;
            nzZ *= invl;
            nzW *= invl;
        }
        planes[4].set(nzX, nzY, nzZ, nzW);
        pzX = m.m03 - m.m02;
        pzY = m.m13 - m.m12;
        pzZ = m.m23 - m.m22;
        pzW = m.m33 - m.m32;
        if (allowTestSpheres) {
            invl = 1.0f / (float) Math.sqrt(pzX * pzX + pzY * pzY + pzZ * pzZ);
            pzX *= invl;
            pzY *= invl;
            pzZ *= invl;
            pzW *= invl;
        }
        planes[5].set(pzX, pzY, pzZ, pzW);
        return this;
    }

    public boolean testPoint(Vector3f point) {
        return testPoint(point.x, point.y, point.z);
    }

    public boolean testPoint(float x, float y, float z) {
        return nxX * x + nxY * y + nxZ * z + nxW >= 0 && pxX * x + pxY * y + pxZ * z + pxW >= 0 && nyX * x + nyY * y + nyZ * z + nyW >= 0 && pyX * x + pyY * y + pyZ * z + pyW >= 0 && nzX * x + nzY * y + nzZ * z + nzW >= 0 && pzX * x + pzY * y + pzZ * z + pzW >= 0;
    }

    public boolean testSphere(Vector3f center, float radius) {
        return testSphere(center.x, center.y, center.z, radius);
    }

    public boolean testSphere(float x, float y, float z, float r) {
        return nxX * x + nxY * y + nxZ * z + nxW >= -r && pxX * x + pxY * y + pxZ * z + pxW >= -r && nyX * x + nyY * y + nyZ * z + nyW >= -r && pyX * x + pyY * y + pyZ * z + pyW >= -r && nzX * x + nzY * y + nzZ * z + nzW >= -r && pzX * x + pzY * y + pzZ * z + pzW >= -r;
    }

    public int intersectSphere(Vector3f center, float radius) {
        return intersectSphere(center.x, center.y, center.z, radius);
    }

    public int intersectSphere(float x, float y, float z, float r) {
        boolean inside = true;
        float dist;
        dist = nxX * x + nxY * y + nxZ * z + nxW;
        if (dist >= -r) {
            inside &= dist >= r;
            dist = pxX * x + pxY * y + pxZ * z + pxW;
            if (dist >= -r) {
                inside &= dist >= r;
                dist = nyX * x + nyY * y + nyZ * z + nyW;
                if (dist >= -r) {
                    inside &= dist >= r;
                    dist = pyX * x + pyY * y + pyZ * z + pyW;
                    if (dist >= -r) {
                        inside &= dist >= r;
                        dist = nzX * x + nzY * y + nzZ * z + nzW;
                        if (dist >= -r) {
                            inside &= dist >= r;
                            dist = pzX * x + pzY * y + pzZ * z + pzW;
                            if (dist >= -r) {
                                inside &= dist >= r;
                                return inside ? INSIDE : INTERSECT;
                            }
                        }
                    }
                }
            }
        }
        return OUTSIDE;
    }

    public boolean testAab(Vector3f min, Vector3f max) {
        return testAab(min.x, min.y, min.z, max.x, max.y, max.z);
    }

    public boolean testAab(float minX, float minY, float minZ, float maxX, float maxY, float maxZ) {
        return nxX * (nxX < 0 ? minX : maxX) + nxY * (nxY < 0 ? minY : maxY) + nxZ * (nxZ < 0 ? minZ : maxZ) >= -nxW && pxX * (pxX < 0 ? minX : maxX) + pxY * (pxY < 0 ? minY : maxY) + pxZ * (pxZ < 0 ? minZ : maxZ) >= -pxW && nyX * (nyX < 0 ? minX : maxX) + nyY * (nyY < 0 ? minY : maxY) + nyZ * (nyZ < 0 ? minZ : maxZ) >= -nyW && pyX * (pyX < 0 ? minX : maxX) + pyY * (pyY < 0 ? minY : maxY) + pyZ * (pyZ < 0 ? minZ : maxZ) >= -pyW && nzX * (nzX < 0 ? minX : maxX) + nzY * (nzY < 0 ? minY : maxY) + nzZ * (nzZ < 0 ? minZ : maxZ) >= -nzW && pzX * (pzX < 0 ? minX : maxX) + pzY * (pzY < 0 ? minY : maxY) + pzZ * (pzZ < 0 ? minZ : maxZ) >= -pzW;
    }

    public boolean testPlaneXY(Vector2f min, Vector2f max) {
        return testPlaneXY(min.x, min.y, max.x, max.y);
    }

    public boolean testPlaneXY(float minX, float minY, float maxX, float maxY) {
        return nxX * (nxX < 0 ? minX : maxX) + nxY * (nxY < 0 ? minY : maxY) >= -nxW && pxX * (pxX < 0 ? minX : maxX) + pxY * (pxY < 0 ? minY : maxY) >= -pxW && nyX * (nyX < 0 ? minX : maxX) + nyY * (nyY < 0 ? minY : maxY) >= -nyW && pyX * (pyX < 0 ? minX : maxX) + pyY * (pyY < 0 ? minY : maxY) >= -pyW && nzX * (nzX < 0 ? minX : maxX) + nzY * (nzY < 0 ? minY : maxY) >= -nzW && pzX * (pzX < 0 ? minX : maxX) + pzY * (pzY < 0 ? minY : maxY) >= -pzW;
    }

    public boolean testPlaneXZ(float minX, float minZ, float maxX, float maxZ) {
        return nxX * (nxX < 0 ? minX : maxX) + nxZ * (nxZ < 0 ? minZ : maxZ) >= -nxW && pxX * (pxX < 0 ? minX : maxX) + pxZ * (pxZ < 0 ? minZ : maxZ) >= -pxW && nyX * (nyX < 0 ? minX : maxX) + nyZ * (nyZ < 0 ? minZ : maxZ) >= -nyW && pyX * (pyX < 0 ? minX : maxX) + pyZ * (pyZ < 0 ? minZ : maxZ) >= -pyW && nzX * (nzX < 0 ? minX : maxX) + nzZ * (nzZ < 0 ? minZ : maxZ) >= -nzW && pzX * (pzX < 0 ? minX : maxX) + pzZ * (pzZ < 0 ? minZ : maxZ) >= -pzW;
    }

    public int intersectAab(Vector3f min, Vector3f max) {
        return intersectAab(min.x, min.y, min.z, max.x, max.y, max.z);
    }

    public int intersectAab(float minX, float minY, float minZ, float maxX, float maxY, float maxZ) {
        int plane = PLANE_NX;
        boolean inside = true;
        if (nxX * (nxX < 0 ? minX : maxX) + nxY * (nxY < 0 ? minY : maxY) + nxZ * (nxZ < 0 ? minZ : maxZ) >= -nxW) {
            plane = PLANE_PX;
            inside &= nxX * (nxX < 0 ? maxX : minX) + nxY * (nxY < 0 ? maxY : minY) + nxZ * (nxZ < 0 ? maxZ : minZ) >= -nxW;
            if (pxX * (pxX < 0 ? minX : maxX) + pxY * (pxY < 0 ? minY : maxY) + pxZ * (pxZ < 0 ? minZ : maxZ) >= -pxW) {
                plane = PLANE_NY;
                inside &= pxX * (pxX < 0 ? maxX : minX) + pxY * (pxY < 0 ? maxY : minY) + pxZ * (pxZ < 0 ? maxZ : minZ) >= -pxW;
                if (nyX * (nyX < 0 ? minX : maxX) + nyY * (nyY < 0 ? minY : maxY) + nyZ * (nyZ < 0 ? minZ : maxZ) >= -nyW) {
                    plane = PLANE_PY;
                    inside &= nyX * (nyX < 0 ? maxX : minX) + nyY * (nyY < 0 ? maxY : minY) + nyZ * (nyZ < 0 ? maxZ : minZ) >= -nyW;
                    if (pyX * (pyX < 0 ? minX : maxX) + pyY * (pyY < 0 ? minY : maxY) + pyZ * (pyZ < 0 ? minZ : maxZ) >= -pyW) {
                        plane = PLANE_NZ;
                        inside &= pyX * (pyX < 0 ? maxX : minX) + pyY * (pyY < 0 ? maxY : minY) + pyZ * (pyZ < 0 ? maxZ : minZ) >= -pyW;
                        if (nzX * (nzX < 0 ? minX : maxX) + nzY * (nzY < 0 ? minY : maxY) + nzZ * (nzZ < 0 ? minZ : maxZ) >= -nzW) {
                            plane = PLANE_PZ;
                            inside &= nzX * (nzX < 0 ? maxX : minX) + nzY * (nzY < 0 ? maxY : minY) + nzZ * (nzZ < 0 ? maxZ : minZ) >= -nzW;
                            if (pzX * (pzX < 0 ? minX : maxX) + pzY * (pzY < 0 ? minY : maxY) + pzZ * (pzZ < 0 ? minZ : maxZ) >= -pzW) {
                                inside &= pzX * (pzX < 0 ? maxX : minX) + pzY * (pzY < 0 ? maxY : minY) + pzZ * (pzZ < 0 ? maxZ : minZ) >= -pzW;
                                return inside ? INSIDE : INTERSECT;
                            }
                        }
                    }
                }
            }
        }
        return plane;
    }

    public float distanceToPlane(float minX, float minY, float minZ, float maxX, float maxY, float maxZ, int plane) {
        return planes[plane].x * (planes[plane].x < 0 ? maxX : minX) + planes[plane].y * (planes[plane].y < 0 ? maxY : minY) + planes[plane].z * (planes[plane].z < 0 ? maxZ : minZ) + planes[plane].w;
    }

    public int intersectAab(Vector3f min, Vector3f max, int mask) {
        return intersectAab(min.x, min.y, min.z, max.x, max.y, max.z, mask);
    }

    public int intersectAab(float minX, float minY, float minZ, float maxX, float maxY, float maxZ, int mask) {
        int plane = PLANE_NX;
        boolean inside = true;
        if ((mask & PLANE_MASK_NX) == 0 || nxX * (nxX < 0 ? minX : maxX) + nxY * (nxY < 0 ? minY : maxY) + nxZ * (nxZ < 0 ? minZ : maxZ) >= -nxW) {
            plane = PLANE_PX;
            inside &= nxX * (nxX < 0 ? maxX : minX) + nxY * (nxY < 0 ? maxY : minY) + nxZ * (nxZ < 0 ? maxZ : minZ) >= -nxW;
            if ((mask & PLANE_MASK_PX) == 0 || pxX * (pxX < 0 ? minX : maxX) + pxY * (pxY < 0 ? minY : maxY) + pxZ * (pxZ < 0 ? minZ : maxZ) >= -pxW) {
                plane = PLANE_NY;
                inside &= pxX * (pxX < 0 ? maxX : minX) + pxY * (pxY < 0 ? maxY : minY) + pxZ * (pxZ < 0 ? maxZ : minZ) >= -pxW;
                if ((mask & PLANE_MASK_NY) == 0 || nyX * (nyX < 0 ? minX : maxX) + nyY * (nyY < 0 ? minY : maxY) + nyZ * (nyZ < 0 ? minZ : maxZ) >= -nyW) {
                    plane = PLANE_PY;
                    inside &= nyX * (nyX < 0 ? maxX : minX) + nyY * (nyY < 0 ? maxY : minY) + nyZ * (nyZ < 0 ? maxZ : minZ) >= -nyW;
                    if ((mask & PLANE_MASK_PY) == 0 || pyX * (pyX < 0 ? minX : maxX) + pyY * (pyY < 0 ? minY : maxY) + pyZ * (pyZ < 0 ? minZ : maxZ) >= -pyW) {
                        plane = PLANE_NZ;
                        inside &= pyX * (pyX < 0 ? maxX : minX) + pyY * (pyY < 0 ? maxY : minY) + pyZ * (pyZ < 0 ? maxZ : minZ) >= -pyW;
                        if ((mask & PLANE_MASK_NZ) == 0 || nzX * (nzX < 0 ? minX : maxX) + nzY * (nzY < 0 ? minY : maxY) + nzZ * (nzZ < 0 ? minZ : maxZ) >= -nzW) {
                            plane = PLANE_PZ;
                            inside &= nzX * (nzX < 0 ? maxX : minX) + nzY * (nzY < 0 ? maxY : minY) + nzZ * (nzZ < 0 ? maxZ : minZ) >= -nzW;
                            if ((mask & PLANE_MASK_PZ) == 0 || pzX * (pzX < 0 ? minX : maxX) + pzY * (pzY < 0 ? minY : maxY) + pzZ * (pzZ < 0 ? minZ : maxZ) >= -pzW) {
                                inside &= pzX * (pzX < 0 ? maxX : minX) + pzY * (pzY < 0 ? maxY : minY) + pzZ * (pzZ < 0 ? maxZ : minZ) >= -pzW;
                                return inside ? INSIDE : INTERSECT;
                            }
                        }
                    }
                }
            }
        }
        return plane;
    }

    public int intersectAab(Vector3f min, Vector3f max, int mask, int startPlane) {
        return intersectAab(min.x, min.y, min.z, max.x, max.y, max.z, mask, startPlane);
    }

    public int intersectAab(float minX, float minY, float minZ, float maxX, float maxY, float maxZ, int mask, int startPlane) {
        int plane = startPlane;
        boolean inside = true;
        Vector4f p = planes[startPlane];
        if ((mask & 1 << startPlane) != 0 && p.x * (p.x < 0 ? minX : maxX) + p.y * (p.y < 0 ? minY : maxY) + p.z * (p.z < 0 ? minZ : maxZ) < -p.w) {
            return plane;
        }
        if ((mask & PLANE_MASK_NX) == 0 || nxX * (nxX < 0 ? minX : maxX) + nxY * (nxY < 0 ? minY : maxY) + nxZ * (nxZ < 0 ? minZ : maxZ) >= -nxW) {
            plane = PLANE_PX;
            inside &= nxX * (nxX < 0 ? maxX : minX) + nxY * (nxY < 0 ? maxY : minY) + nxZ * (nxZ < 0 ? maxZ : minZ) >= -nxW;
            if ((mask & PLANE_MASK_PX) == 0 || pxX * (pxX < 0 ? minX : maxX) + pxY * (pxY < 0 ? minY : maxY) + pxZ * (pxZ < 0 ? minZ : maxZ) >= -pxW) {
                plane = PLANE_NY;
                inside &= pxX * (pxX < 0 ? maxX : minX) + pxY * (pxY < 0 ? maxY : minY) + pxZ * (pxZ < 0 ? maxZ : minZ) >= -pxW;
                if ((mask & PLANE_MASK_NY) == 0 || nyX * (nyX < 0 ? minX : maxX) + nyY * (nyY < 0 ? minY : maxY) + nyZ * (nyZ < 0 ? minZ : maxZ) >= -nyW) {
                    plane = PLANE_PY;
                    inside &= nyX * (nyX < 0 ? maxX : minX) + nyY * (nyY < 0 ? maxY : minY) + nyZ * (nyZ < 0 ? maxZ : minZ) >= -nyW;
                    if ((mask & PLANE_MASK_PY) == 0 || pyX * (pyX < 0 ? minX : maxX) + pyY * (pyY < 0 ? minY : maxY) + pyZ * (pyZ < 0 ? minZ : maxZ) >= -pyW) {
                        plane = PLANE_NZ;
                        inside &= pyX * (pyX < 0 ? maxX : minX) + pyY * (pyY < 0 ? maxY : minY) + pyZ * (pyZ < 0 ? maxZ : minZ) >= -pyW;
                        if ((mask & PLANE_MASK_NZ) == 0 || nzX * (nzX < 0 ? minX : maxX) + nzY * (nzY < 0 ? minY : maxY) + nzZ * (nzZ < 0 ? minZ : maxZ) >= -nzW) {
                            plane = PLANE_PZ;
                            inside &= nzX * (nzX < 0 ? maxX : minX) + nzY * (nzY < 0 ? maxY : minY) + nzZ * (nzZ < 0 ? maxZ : minZ) >= -nzW;
                            if ((mask & PLANE_MASK_PZ) == 0 || pzX * (pzX < 0 ? minX : maxX) + pzY * (pzY < 0 ? minY : maxY) + pzZ * (pzZ < 0 ? minZ : maxZ) >= -pzW) {
                                inside &= pzX * (pzX < 0 ? maxX : minX) + pzY * (pzY < 0 ? maxY : minY) + pzZ * (pzZ < 0 ? maxZ : minZ) >= -pzW;
                                return inside ? INSIDE : INTERSECT;
                            }
                        }
                    }
                }
            }
        }
        return plane;
    }

    public boolean testLineSegment(Vector3f a, Vector3f b) {
        return testLineSegment(a.x, a.y, a.z, b.x, b.y, b.z);
    }

    private float fma(float f1, float f2, float f3) {
        return (f1 * f2) + f3;
    }

    public boolean testLineSegment(float aX, float aY, float aZ, float bX, float bY, float bZ) {
        float da, db;
        da = fma(nxX, aX, fma(nxY, aY, fma(nxZ, aZ, nxW)));
        db = fma(nxX, bX, fma(nxY, bY, fma(nxZ, bZ, nxW)));
        if (da < 0.0f && db < 0.0f)
            return false;
        if (da * db < 0.0f) {
            float p = Math.abs(da) / Math.abs(db - da);
            float dx = fma(bX - aX, p, aX), dy = fma(bY - aY, p, aY), dz = fma(bZ - aZ, p, aZ);
            if (da < 0.0f) {
                aX = dx;
                aY = dy;
                aZ = dz;
            } else {
                bX = dx;
                bY = dy;
                bZ = dz;
            }
        }
        da = fma(pxX, aX, fma(pxY, aY, fma(pxZ, aZ, pxW)));
        db = fma(pxX, bX, fma(pxY, bY, fma(pxZ, bZ, pxW)));
        if (da < 0.0f && db < 0.0f)
            return false;
        if (da * db < 0.0f) {
            float p = Math.abs(da) / Math.abs(db - da);
            float dx = fma(bX - aX, p, aX), dy = fma(bY - aY, p, aY), dz = fma(bZ - aZ, p, aZ);
            if (da < 0.0f) {
                aX = dx;
                aY = dy;
                aZ = dz;
            } else {
                bX = dx;
                bY = dy;
                bZ = dz;
            }
        }
        da = fma(nyX, aX, fma(nyY, aY, fma(nyZ, aZ, nyW)));
        db = fma(nyX, bX, fma(nyY, bY, fma(nyZ, bZ, nyW)));
        if (da < 0.0f && db < 0.0f)
            return false;
        if (da * db < 0.0f) {
            float p = Math.abs(da) / Math.abs(db - da);
            float dx = fma(bX - aX, p, aX), dy = fma(bY - aY, p, aY), dz = fma(bZ - aZ, p, aZ);
            if (da < 0.0f) {
                aX = dx;
                aY = dy;
                aZ = dz;
            } else {
                bX = dx;
                bY = dy;
                bZ = dz;
            }
        }
        da = fma(pyX, aX, fma(pyY, aY, fma(pyZ, aZ, pyW)));
        db = fma(pyX, bX, fma(pyY, bY, fma(pyZ, bZ, pyW)));
        if (da < 0.0f && db < 0.0f)
            return false;
        if (da * db < 0.0f) {
            float p = Math.abs(da) / Math.abs(db - da);
            float dx = fma(bX - aX, p, aX), dy = fma(bY - aY, p, aY), dz = fma(bZ - aZ, p, aZ);
            if (da < 0.0f) {
                aX = dx;
                aY = dy;
                aZ = dz;
            } else {
                bX = dx;
                bY = dy;
                bZ = dz;
            }
        }
        da = fma(nzX, aX, fma(nzY, aY, fma(nzZ, aZ, nzW)));
        db = fma(nzX, bX, fma(nzY, bY, fma(nzZ, bZ, nzW)));
        if (da < 0.0f && db < 0.0f)
            return false;
        if (da * db < 0.0f) {
            float p = Math.abs(da) / Math.abs(db - da);
            float dx = fma(bX - aX, p, aX), dy = fma(bY - aY, p, aY), dz = fma(bZ - aZ, p, aZ);
            if (da < 0.0f) {
                aX = dx;
                aY = dy;
                aZ = dz;
            } else {
                bX = dx;
                bY = dy;
                bZ = dz;
            }
        }
        da = fma(pzX, aX, fma(pzY, aY, fma(pzZ, aZ, pzW)));
        db = fma(pzX, bX, fma(pzY, bY, fma(pzZ, bZ, pzW)));
        return da >= 0.0f || db >= 0.0f;
    }
}
