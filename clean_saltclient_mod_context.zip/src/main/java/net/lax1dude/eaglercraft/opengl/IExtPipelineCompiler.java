package net.lax1dude.eaglercraft.opengl;

import net.lax1dude.eaglercraft.internal.IProgramGL;

public interface IExtPipelineCompiler {

    String[] getShaderSource(int stateCoreBits, int stateExtBits, Object[] userPointer);

    int getExtensionStatesCount();

    int getCurrentExtensionStateBits(int stateCoreBits);

    int getCoreStateMask(int stateExtBits);

    void initializeNewShader(IProgramGL compiledProg, int stateCoreBits, int stateExtBits, Object[] userPointer);

    void updatePipeline(IProgramGL compiledProg, int stateCoreBits, int stateExtBits, Object[] userPointer);

    void destroyPipeline(IProgramGL shaderProgram, int stateCoreBits, int stateExtBits, Object[] userPointer);
}
