package net.lax1dude.eaglercraft.opengl;

import net.lax1dude.eaglercraft.internal.IVertexArrayGL;
import net.lax1dude.eaglercraft.internal.IBufferGL;
import net.lax1dude.eaglercraft.opengl.FixedFunctionShader.FixedFunctionState;

public class HighPolyMesh {

    IVertexArrayGL vertexArray;

    IBufferGL vertexBuffer;

    IBufferGL indexBuffer;

    int vertexCount;

    int indexCount;

    boolean hasTexture;

    public HighPolyMesh(IVertexArrayGL vertexArray, IBufferGL vertexBuffer, IBufferGL indexBuffer, int vertexCount, int indexCount, boolean hasTexture) {
        this.vertexArray = vertexArray;
        this.vertexBuffer = vertexBuffer;
        this.indexBuffer = indexBuffer;
        this.vertexCount = vertexCount;
        this.indexCount = indexCount;
        this.hasTexture = hasTexture;
    }

    HighPolyMesh() {
    }

    public boolean isNull() {
        return vertexArray == null;
    }

    public int getVertexCount() {
        return vertexCount;
    }

    public int getIndexCount() {
        return indexCount;
    }

    public boolean getHasTexture() {
        return hasTexture;
    }

    public int getAttribBits() {
        return hasTexture ? (FixedFunctionState.STATE_HAS_ATTRIB_TEXTURE | FixedFunctionState.STATE_HAS_ATTRIB_NORMAL) : FixedFunctionState.STATE_HAS_ATTRIB_NORMAL;
    }
}
