package net.lax1dude.eaglercraft.opengl;

public class OpenGlHelper {

    public static final int defaultTexUnit = RealOpenGLEnums.GL_TEXTURE0;

    public static final int lightmapTexUnit = RealOpenGLEnums.GL_TEXTURE1;

    public static void setLightmapTextureCoords(int unit, float x, float y) {
        GlStateManager.setActiveTexture(lightmapTexUnit);
        GlStateManager.texCoords2D(x, y);
        GlStateManager.setActiveTexture(defaultTexUnit);
    }
}
